# Chapter 28: Drugs and Alcohol

**Chapter 28 of 37 · Drugs and Alcohol · 10 eras · about 110 minutes**

**People in this land have used tobacco for at least 12,000 years, and when Americans turned against a drug, the punishment fell hardest on the people who had the least power.**

Judges in the Massachusetts Bay Colony ordered a colonist named Robert Coles in 1634 to wear a letter D for a year. The D was made of red cloth, set on a white background, and it hung from his neck over his clothes whenever he was among other people. It was his fourth punishment for drunkenness in three years. Governor John Winthrop wrote in his journal that Coles, "having been oft (often) punished for drunkenness, was now ordered to wear a red D about his neck for a year."

This chapter follows tobacco, alcohol and other drugs through all ten eras, from a fire pit 12,300 years old to the fentanyl deaths of the 2020s. Again and again a drug is sold freely, then feared, then taxed or banned, and sometimes allowed again.

Each time, look at who gets punished. Coles was a free colonist with the right to vote. The laws that came later fell on Native people, Chinese immigrants, Black Americans and poor drinkers. No member of the Sackler family, which owned the company that made the painkiller OxyContin, has been charged with a crime. The businessman whose ginger medicine left tens of thousands of people unable to use their hands and feet never served a day in jail. Look, too, for the people who quit and then helped others quit.

**Three questions this chapter answers**

- How long have people here used tobacco, and what did they use it for?
- What happened when the whole country banned alcohol from 1920 to 1933?
- Who has been punished for drugs, and who has not?

**Five minutes?** Read "Poisoned alcohol and jake leg" in 1900 to 1950.

**Can skip:** "Drinks for voters" and "The tavern as the town's meeting place" in 1700 to 1750, and "Chewing tobacco" in 1800 to 1850. The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 5 minutes**

People in this land used plants that change how the body and the mind feel for thousands of years before Europeans came. The oldest one found so far is tobacco. In the records written later, many of these uses were part of prayer and ceremony. Native people offered tobacco in prayer, men in the Southeast drank Black Drink to make themselves pure, and the O'odham drank cactus wine at a rain ceremony. The Apache drank their corn beer mostly at everyday social times.

**Beer and wine, but no liquor.** Before Europeans came, people made beer and wine mainly in the Southwest, and people elsewhere used alcohol only here and there. Nobody in this land made distilled liquor, such as rum or whiskey. To distill a drink, people heat it and catch the steam, which cools into a liquor stronger than beer or wine.

### How old is tobacco use here?

People in North America were using tobacco about 12,300 years ago. Scientists found burned tobacco in a hearth, an old fire pit, at the Wishbone site, in the desert of western North America. The find is 9,000 years older than any earlier evidence of tobacco use, and it was first published online in October 2021. How the people at that fire used the tobacco is not known.

A pipe found in central Washington State is about 1,430 years old. Chemists found nicotine, the drug in tobacco, inside it. The pipe also held traces of a wild tobacco that grows here, mixed with a plant called smooth sumac.

**Tobacco as an offering.** The "Keep It Sacred" program of the Inter-Tribal Council of Michigan describes tobacco used as an offering, which it calls traditional tobacco. People grow or gather it for ceremony or for medicine. It is the plant known by its Latin name, *Nicotiana rustica*. People offer it to the Creator, or to another person, place or being, by burning it in a fire or smoking it in a pipe.

In the program's words, the smoke carries "thoughts and prayers to the spirit world." The smoke is generally not breathed into the lungs. The program's writers state that traditional tobacco used this way is not linked to addiction, a need for a drug so strong that stopping is very hard, or to harm to health. They set it apart from commercial tobacco, the kind sold in stores. The ways people used tobacco differed from one nation to another.

### Black Drink, cacao, peyote and datura

Black Drink was a tea made from the leaves of yaupon holly or dahoon holly, two kinds of holly bush. It contains caffeine, the drug in coffee that keeps people awake. Chemists found traces of it inside beaker cups from Cahokia, in what is now Illinois, dated from 1050 to 1250. These hollies grow far to the south of Cahokia, so people carried the leaves north. Records from later centuries describe men in the Southeast drinking Black Drink in a ceremony to make themselves pure.

**Chocolate from the south.** Cacao is the bean that chocolate is made from, and it grows in Mexico and Central America. Jars at Pueblo Bonito, in Chaco Canyon in New Mexico, held traces of a cacao drink. They date from about 1000 to 1125, and the beans came north by trade. It is the first known use of cacao drinks north of the Mexican border. Drinks made from cacao or holly turn up at 18 sites in the Southwest and northern Mexico, from about 750 to 1400.

**Peyote.** Peyote is a small cactus whose top holds mescaline, a drug that causes visions. Two dried peyote tops kept at the Witte Museum in San Antonio are about 5,700 years old. They were probably found in Shumla Cave, on the Rio Grande in Texas. When chemists tested them, they still held mescaline. The chemists wrote that Native North Americans knew what peyote does as long as 5,700 years ago.

**Datura.** Datura is a flowering plant that holds two drugs, scopolamine and atropine. They cause hallucinations, which means seeing and hearing things that are not there. In Pinwheel Cave in California, people chewed wads of datura and pressed them into the painted ceiling. Records from later times show Native Californians using datura to enter a trance, a state like a dream while awake. People used the cave from before 1500 into the years after Europeans arrived, so the wads have no exact date.

### Who made alcohol before 1500?

Native nations in the Southwest made beer and wine before Europeans came, and other nations used alcohol only here and there. Patrick J. Abbott, a doctor, found this in a 1996 study of how Native nations used alcohol before Europeans came. Most Native people first met alcohol when Europeans brought it in the 1500s and 1600s.

**Cactus wine.** The Akimel O'odham and the Tohono O'odham made wine from a cactus. Older books call them the Pima and the Papago. Each late summer the women gathered the red fruit of the saguaro cactus. They made most of it into jam and the last of the harvest into wine. People drank the wine at the rain ceremony held at their New Year, late in the summer. When Abbott wrote, many Tohono O'odham villages still held that ceremony.

**Corn beer.** The Apache made a corn beer called tiswin, which they learned to make from peoples of northern Mexico. They drank it mostly in everyday dealings with one another, and only sometimes in ceremony. The Apache reached the Southwest sometime between 1000 and 1550. For that reason, nobody knows whether they made tiswin here before 1500.

## The 1500s

**Era 2 of 10 · The 1500s · about 4 minutes**

Europeans learned to use tobacco from the peoples of the Americas in the 1500s and carried the habit home. A French official sent tobacco seeds to the queen of France in 1560, and English colonists at Roanoke smoked it the Algonquian way in 1585. Spanish colonists brought wine with them to Florida.

Most Native people in this land first met alcohol in the 1500s and 1600s, when Europeans arrived. A regular trade in alcohol with Native nations began in the 1600s.

### Why nicotine is named after a Frenchman

Jean Nicot was the French ambassador to Portugal, the official who spoke for the king of France there. In 1560 he sent tobacco seeds to Queen Catherine de Médicis of France, with a letter about the plant's uses as a medicine. The next year he gave her tobacco leaves and showed her how to grind them into a powder to sniff for headaches. The people around the French king and queen took up the powder and sniffed it too.

The word nicotine comes from Nicot's name. So does *Nicotiana*, the name the Swedish scientist Carl Linnaeus gave the tobacco plants in 1753.

Tobacco reached England in 1565, perhaps brought from Florida by Sir John Hawkins. By 1588 English men and women of high rank were using it, and so were some well-trained doctors.

### Thomas Hariot

> **Who:** An English mathematician who smoked tobacco the Algonquian way at Roanoke and wrote down how the Algonquian people used it.
>
> **When and where:** Roanoke Island, in what is now North Carolina, 1585 to 1586. London until his death in 1621.

**He smoked the Algonquian plant uppowoc and died of nose cancer.**

Thomas Hariot studied mathematics and the stars. In 1585 he sailed to Roanoke Island with a group of English ships and men sent to start a colony. Most of the colonists were soldiers. Hariot and the artist John White were the best known of the few who were not.

**Whose island it was.** Roanoke Island was the land of the Roanoke, Secotan and Croatoan peoples. Their leading werowance, or chief, was Wingina, and he let the English build a fort on the north end of the island. Hariot learned the Algonquian language from two Native men of the region, Manteo and Wanchese.

**The plant.** The people called it uppowoc. They planted it in plots of its own, dried the leaves, ground them to powder and drew the smoke through clay pipes. They believed the smoke opened the passages of the body and kept them healthy. As an offering, they threw the powder into sacred fires, and onto the water in storms and after escaping a danger.

Hariot wrote that the English "vsed to suck it after their maner" on the island. In today's words, they smoked it the way the Algonquian people did, and they went on smoking it after they came home.

**The killing of Wingina.** Wingina had let the English build their fort in 1585, and the next year they killed him. On June 1, 1586, men under the English commander Ralph Lane attacked his village. They shot Wingina and chased him down, and an Irishman named Edward Nugent cut off his head. A week later the English sailed home, and Hariot went with them.

Hariot described uppowoc in a book printed in 1588, *A Briefe and True Report of the New Found Land of Virginia*. In it he also wrote that near the end of the colony's year, some of the English had been "too fierce, in slaying some of the people." In the same sentence he wrote that the people had "iustly deserued" (justly deserved) it. He did not name the dead.

Hariot died in London on July 2, 1621, of cancer of the nose. The writers of Encyclopedia Virginia state that the cancer was "probably caused by heavy tobacco use."

### Spanish wine in Florida

Pedro Menéndez de Avilés and his Spanish colonists founded St. Augustine, in Florida, on September 8, 1565. They built it at Seloy, a town of the Timucua people.

Wine and olive oil came by ship in big Spanish storage jars called olive jars. Historians at the Florida Museum of Natural History write that the two were perhaps even more important to the Spanish than wheat and beef. They also write that the Spanish soon turned to the Timucua for food, cooking pots and wives. Their account does not say whether the Timucua women chose these marriages.

**Alcohol as a gift.** The historian Peter C. Mancall writes that some Europeans surely offered alcohol to Native people when they first met, though no record from this century names a case. No record from the 1500s describes the Spanish trading wine to Native nations as a regular business.

## The 1600s

**Era 3 of 10 · The 1600s · about 9 minutes**

Drinking came over on the first English ships, and colony leaders spent the 1600s trying to keep it in bounds. The colonists' first drinks were cider and beer, and they believed alcohol kept the body warm and strong. Their leaders licensed taverns and punished drunks with fines, iron shackles, the stocks and public shame. In Virginia, planters grew tobacco to sell in England, and the smoking habit spread.

**Liquor for furs.** English traders sold rum and French traders sold brandy to Native nations in exchange for furs. Colony leaders passed laws against these sales, and traders kept breaking them.

### Beer, cider and bad water

The first drinks the colonists made were cider and beer. They brewed beer from corn, wheat, oats, persimmons and green cornstalks. They tried to grow grapes for wine, but the vines they brought from Europe died of American pests and diseases.

Colonists believed that alcohol warmed the body, helped digestion and made people strong. The land here had plenty of clean water, but some colonists drank from dirty sources and got sick. At Jamestown, George Percy wrote that the settlers drank river water that was salty at high tide and "full of slime and filth" at low tide. He called it "the destruction of many of our men." In Europe, where rivers were often dirty, people drank alcohol in place of water, and the colonists kept that habit.

Officials of the Virginia Company of London complained about it. In a letter to Governor Francis Wyatt in 1622, they wrote that the colonists' drinking was harming the colony.

### Bolts, fines and the stocks

Virginia's first lawmakers passed a law against drunkenness in 1619, at the colony's first General Assembly. The first time a man was found drunk, the minister scolded him in private. The second time, the minister scolded him in public. For a third offense he had to lie for 12 hours in bolts, iron shackles, in the house of an officer called the provost marshal, and pay the marshal's fees.

If he still kept drinking, the governor and his council, the men who advised him, could give him whatever harsh punishment they chose.

**Massachusetts.** The lawmakers of Massachusetts passed a set of drinking laws between 1633 and 1647. Nobody could run a tavern without a license from the county court. A tavern keeper could not serve one person more than half a pint of wine at a time. Nobody could sit drinking for more than half an hour, or stay after nine at night.

**The fine.** A person found drunk in Massachusetts paid 10 shillings, half a pound in English money. The law defined drunk as unable to think clearly, which showed in the way the person talked or moved. A person who could not pay was to be jailed, or set for up to three hours in the stocks, a wooden frame that locked a person's ankles while the person sat in a public place.

**Prices.** The lawmakers also set what an innkeeper could charge. In Boston in 1634 a meal cost sixpence and a quart of beer a penny, with a fine of 10 shillings for charging more. A traveller named John Josselyn reported that a constable, a town officer who kept order, would stop a stranger in a Boston tavern from ordering more drink than the constable thought right.

### Samuel Cole

> **Who:** The keeper of the earliest tavern in Boston known to have had a license. He is not Robert Coles, whom Massachusetts judges punished for drunkenness.
>
> **When and where:** Boston, in the Massachusetts Bay Colony, 1634 to 1638.

**About twenty Narragansett men ate their peace-treaty meal at his inn.**

Samuel Adams Drake, a historian of Boston's taverns, dates the opening of Samuel Cole's tavern to March 4, 1634. A tavern was then called an ordinary.

Cole was a comfit-maker, a maker of sugar-coated sweets. He came to Boston in 1630, in the fleet of ships that brought Governor John Winthrop. His ordinary stood on Washington Street, and the house had a brew-house, a building for making beer.

**The Narragansett visit.** The English and the Narragansett people made a peace agreement in 1636, and Governor Henry Vane hosted Narragansett leaders in Boston. The Narragansett leader Miantonomi and two sons of the leader Canonicus ate at the governor's house. About twenty other Narragansett men ate their meal at Cole's inn.

The colony's judges let Cole sell his house as an inn in 1638, and he sold it to Robert Sedgwick. Cole died in 1666.

### Robert Coles

> **Who:** A colonist whom judges in Massachusetts punished four times for drunkenness, the last time by making him wear a red letter D. He is not Samuel Cole, the Boston tavern keeper.
>
> **When and where:** Roxbury and Agawam, now Ipswich, in the Massachusetts Bay Colony, 1631 to 1634.

**A paper on his back said DRUNKARD in large letters.**

**The first fine.** Robert Coles came to Massachusetts in 1630 with Governor John Winthrop's fleet. In 1631 the colony's judges fined him five marks, about 3 pounds, 6 shillings and 8 pence, for being drunk on the ship *Friendship* and at Winnisimmet, now Chelsea. The *Friendship* was carrying a spiced wine made from honey.

**The paper.** At Agawam in 1633 he was charged with drunkenness for the third time. He had been drunk, had encouraged John Shatswell's wife to drink, and had urged her to be unfaithful to her husband. The judges fined him 10 pounds and made him stand in public with a paper on his back. On it the word drunkard was written in large letters.

**The red D.** He was drunk again at Roxbury in 1634. This time the judges ordered him to wear the red D for a year, and they took away his right to vote.

**Afterward.** Coles got back his right to vote about two months later, on May 14, 1634. The records show no later charge of drunkenness against him, though the Roxbury church later put him out.

By 1637 he had moved to Providence, a town built on land that Roger Williams got in 1636 from the Narragansett leaders Canonicus and Miantonomi. Coles was one of the 13 men who first owned land there, and in 1640 he helped write the Providence Combination, a written plan for governing the town. He died in Warwick, Rhode Island, in 1655.

### Liquor for furs

Henry Hudson used liquor to test a group of Mahican leaders in September 1609. His ship lay near what is now Albany, in Mahican land. Hudson and his mate took the leaders into the ship's cabin and gave them "so much Wine and Aqua vitae," a strong liquor like brandy, "that they were all merrie."

**Why Hudson did it.** Robert Juet, who kept a journal on the ship, wrote that Hudson and the mate wanted to find out whether the leaders were planning "treacherie," a plan to betray them. In the end one of the men got drunk. Juet wrote that this was strange to the Mahican, "for they could not tell how to take it." The next day the people came back with tobacco and beads for Hudson, and a platter of venison.

**The regular trade.** The historian Peter C. Mancall dates the start of a regular trade in alcohol to the middle of the 1600s. From 1650 on, he writes, liquor was a common item in the fur trade. English traders sold rum to Native nations, and French traders sold brandy, in exchange for furs. Mancall writes that young men who controlled the furs from a season's hunt traded them for liquor, and more families became poor.

**What the liquor did.** Native and colonial witnesses both wrote down what happened when Native people drank the trade liquor. Drinkers fought each other and members of their own families. Some fell into fires or off cliffs, some drowned, and some killed other people. No one counted the deaths.

**The bans.** Colony leaders passed laws against the trade. In New Netherland, the Dutch colony that is now New York, Director General Willem Kieft, the colony's governor, and his council banned selling liquor to Native people on June 18, 1643. Their order said that "large quantities of strong liquors are daily sold to the Indians." The fine was 25 guilders, a guilder being a Dutch coin.

They passed the ban again in 1645. The next Director General, Petrus Stuyvesant, and his council passed it a third time in 1647, and raised the fine to 500 guilders plus the cost of any damage. The laws of the colonies name the officials who banned the trade. They rarely name the traders who broke the bans.

**A false belief.** Mancall writes that Native people organized against the trade themselves. Some colonists came to believe that Native people were born more likely to become alcoholics, people who cannot stop drinking. Mancall states that no evidence supports that belief.

### Tobacco and rum

King James I of England attacked smoking in 1604, in a pamphlet called *A Counterblaste to Tobacco*. He called it "lothsome (disgusting) to the eye, hatefull to the Nose, harmefull to the braine, dangerous to the Lungs." In the same pamphlet he insulted Native people. He mocked the English for copying "the barbarous and beastly maners of the wilde, godlesse, and slauish Indians."

**A milder leaf.** The tobacco that the Powhatan people grew tasted dark and bitter to the English. John Rolfe, a colonist at Jamestown who smoked heavily, got seeds of a milder Spanish tobacco from Trinidad and Caracas. He was growing it by July 1612. The colonists shipped 20,000 pounds of it to England in 1617 and grew 60,000 pounds in 1622. After 1622 English planters took over land that the Powhatan had already cleared, to grow more tobacco.

**Smoking rules in Massachusetts.** Massachusetts officials told constables in 1633 to report "tobacco takers" as idle people. By 1638 the lawmakers had canceled their earlier laws against tobacco, and that year they wrote that since then smoking was "more abused than before." So they banned smoking near any house, barn, corn or haystack, because a pipe that close might set them on fire.

They also banned smoking outdoors in the streets and fields, except on a journey or at a meal, and in the public rooms of an inn. They passed these rules again in 1647, and that version put the distance from buildings and crops at about 330 feet.

**Rum.** Rum is a strong liquor made from molasses, the thick syrup left over when sugar is made from sugarcane. The first known name for rum comes from the island of Barbados, in about 1651. A planter there called it "Kill-Divill" and "a hott hellish and terrible liquor." In the 1600s New England merchants began shipping fish and lumber to the islands of the West Indies. They traded them for molasses and made the molasses into rum at home.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 7 minutes**

Colonists drank more rum than any other strong drink between 1700 and 1750, and it was cheap. A gallon of rum made in the colonies cost 1 shilling 8 pence in Philadelphia in 1740. People drank in taverns, and they also met there to do the town's business. Colony leaders controlled drinking with tavern licenses and with rules for elections.

**Georgia's ban.** A Yamacraw leader named Tomochichi asked Georgia's leaders to stop the sale of rum, and they banned strong liquor for seven years, from 1735 to 1742. Nobody counted how much colonists drank in these years. The first estimates come from the 1770s.

### Rum, molasses and tobacco

Colonial distillers made rum from molasses shipped in from the sugar plantations of the Caribbean. Some of the molasses came in legally, and some was smuggled, which means merchants brought it in secretly without paying the tax on it. In Philadelphia in 1740, a gallon of colonial rum cost 1 shilling 8 pence. A gallon of rum from the Caribbean cost 2 shillings 5 pence.

**The Molasses Act.** At the urging of large sugar planters on the British islands in the Caribbean, the members of the British Parliament, the lawmakers of Britain, passed the Molasses Act in 1733. Under it, importers owed sixpence a gallon on molasses from the French islands. Colonial merchants kept smuggling French molasses anyway, much of it from Saint Domingue, now Haiti. The tax should have brought in 25,000 pounds in British money each year. British officials collected 259 pounds in 1735.

**Rum for people.** Rum was part of a trade in people. New England ships carried rum to Africa, enslaved Africans to the West Indies, and molasses back to New England. Distillers made an extra-strong rum for this trade, so that ships could carry more of it in less space. When the ships reached Africa, the captains added water to the rum. They traded it for people to sell into slavery.

**Tobacco and slavery.** Enslaved Africans outnumbered white indentured servants, workers bound to a master for a set number of years, on Virginia's tobacco farms by 1700. Virginia planters grew 29 million pounds of tobacco in 1709, the most the colony ever grew.

### Drinks for voters

Only white men aged 21 or older who owned land could vote in colonial Virginia. Enslaved people, free Black people, Native people, servants, white men with no land and all women could not. Each voter said his choice out loud in front of the crowd. Voters expected the men running for office to give them liquor and food.

**The dry weeks.** Virginia's lawmakers limited these gifts, called treats, in a law of 1705. Candidates could give treats before the sheriff read out the notice of an election, and again after the voting. The weeks in between were supposed to be "dry," with no treats. Some candidates got around the rule. They stayed away and had a friend, a servant or even a wife hand out the drinks.

### The tavern as the town's meeting place

Boston men used taverns as meeting places for a lodge, for the colony's lawmakers, and for signing up sailors in wartime. Francis Holmes kept the Bunch of Grapes on King Street, now State Street, from 1712. One traveller called it the best punch house in Boston. Punch was a mixed drink made with liquor.

**The first grand lodge.** Henry Price, a Boston tailor, organized a grand lodge of Freemasons at the Bunch of Grapes on July 30, 1733. The Freemasons were a society of men who met in lodges, and a grand lodge was a head lodge over the others.

**Vardy's.** Luke Vardy kept the Royal Exchange tavern. When Boston's town-house burned in the winter of 1747, the colony's lawmakers finished their meetings at Vardy's.

**A duel.** Two young men quarrelled at Vardy's in July 1728, over their cards or their wine. They fought with swords on Boston Common, and one of them killed the other, a man named Woodbridge. The killer's friends put him on a ship that sailed at once. The historian Samuel Adams Drake, who told the story in 1886, does not give the killer's name.

**Signing up sailors.** During a war between Britain and France in 1745, notices posted in Boston told sailors who wanted to join a privateer to report to the Widow Gray's Crown Tavern. A privateer was a privately owned ship allowed to attack enemy ships. Women kept several of Boston's taverns. Drake's list includes the Widow Gray, the Widow Anna Swords, a Mrs. Wardwell and a Mrs. Glover.

### Georgia bans rum, 1735 to 1742

James Oglethorpe and the first colonists of Georgia settled on Yamacraw Bluff, where Savannah stands today, in February 1733. Tomochichi, the leader of a Yamacraw town of about 200 Creek and Yamasee people, gave them the land on the bluff.

**Tomochichi's request.** Tomochichi saw more of his people drinking heavily. In 1734 he asked Oglethorpe and the Trustees, a board of men who met in London and ran the colony from there, to ban the sale of rum.

The Trustees banned rum and brandy in Georgia in 1735, and King George II and his council approved the law. It called these liquors "hurtful and pernicious (harmful) to Man's Body." The Trustees named an officer to enforce the ban and set fines that grew larger with each offense. Taverns could still sell beer and wine with a license.

**The Malcontents.** Colonists soon accused the officials who ran the ban of being dishonest, and they protested the ban. A group known as the Malcontents, a word for people who are unhappy and complain, argued that the ban hurt trade. Georgia merchants, they said, needed rum to trade for timber and other goods, which they then shipped to the British islands in the Caribbean. The Trustees ended the ban on September 29, 1742, and let rum in again for use in the lumber trade. Oglethorpe disagreed with their decision.

Traders from South Carolina had kept carrying rum up the Savannah River all along, against the Trustees' order. In a letter of 1737, Oglethorpe wrote that the Creek had learned drunkenness "from our Traders."

### Dr. Alexander Hamilton

> **Who:** A Scottish-born doctor from Annapolis, Maryland, who kept a diary of the taverns and drinking clubs he saw on a long ride north. He is not the Alexander Hamilton who later ran the Treasury.
>
> **When and where:** From Maryland to York, Maine, and back, May 30 to September 27, 1744.

**He drank three "bumpers" with the Hungarian Club and left at ten.**

Dr. Alexander Hamilton had moved to Annapolis in 1738 to work as a doctor, and in 1743 he was very sick. Mainly to get his health back, he set out on horseback on May 30, 1744. He rode 1,624 miles, from Maryland to Maine and back, and reached home on September 27.

**Crooked riders.** On May 31, at Tradaway's inn in Maryland, he met "a drunken Club" leaving. Most of the men had climbed onto their horses and sat on them crooked. At an inn near Philadelphia on June 5, the landlady did all the work because the landlord was drunk. Hamilton wrote that the liquor had taken away "the use of his tongue." The landlord sat without moving in a corner, smoking his pipe.

**The Hungarian Club.** On June 15 he ate supper in New York with the Hungarian Club at Todd's tavern. After supper the men drank "bumpers," glasses filled to the brim and drunk off at once, at each round. Hamilton did not want to drink and drank only three. He left at ten, "pretty well flushed (red in the face) with my three bumpers."

Some of the men, he wrote, thought nothing was finer than being able "to pour down seas of liquor, and remain unconquered, while others sank under the table." He wrote that some members were "very fond of making a stranger drunk."

**The doctors' club.** In Boston he met with a club of doctors at the Sun Tavern. "We drank punch, smoaked tobacco, and talked of sundry physical matters," he wrote, meaning various matters of medicine. In 1745 he started a club of his own in Annapolis, the Tuesday Club. He died on May 11, 1756.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 13 minutes**

Rum made fortunes in the colonies before the Revolution, and whiskey took its place after. By 1770 the colonies had more than 140 rum distilleries, making about 4.8 million gallons a year. Ship captains from Rhode Island carried rum to Africa and traded it for African people to sell into slavery. After the war, Americans switched to whiskey made from their own corn and rye.

**Who pushed back.** Native leaders asked colonists from the 1750s on to stop selling them liquor. The Philadelphia doctor Benjamin Rush argued in 1785 that heavy drinking was a disease. When members of Congress taxed whiskey in 1791, armed men in western Pennsylvania attacked the tax collectors, and President George Washington called up nearly 13,000 militiamen, part-time citizen soldiers, against them. In 1799 Handsome Lake, a Seneca religious leader, stopped drinking and preached against it.

### How much did the colonists drink?

Nobody measured how much colonists drank before the 1770s, and the estimates made since then each measure something different. The writer Ed Crews, in the *Colonial Williamsburg Journal*, reports an estimate that the average grown man in the 1770s may have drunk as much as three pints a week. The writer Ian Williams gives 3.7 gallons of rum a year for each colonist by the time of the Revolution. The historian Peter C. Mancall cites an estimate of perhaps seven shots of liquor a day by 1770.

**The first government count.** Government figures for 1790 showed that the average American over the age of 15 drank 34 gallons of beer and cider, 5 gallons of liquor and 1 gallon of wine in a year.

**Drink as medicine.** People believed alcohol was good for the body. They took whiskey for stomach pain and for a sore throat, and hot brandy punch for cholera, a disease that causes severe diarrhea. Pregnant women and women in labor drank a shot of liquor to ease the pain. Benjamin Franklin collected more than 200 words that meant drunk.

### Rum and the slave trade

Rhode Island had about 30 rum distilleries by 1764, 22 of them in the town of Newport. Rhode Island merchants traded the rum on the coast of West Africa for African people to enslave. In the hundred years before 1807, Rhode Islanders made at least 1,000 voyages to buy and carry enslaved people. They carried more than 100,000 Africans into slavery.

**The *Sally*.** Chapter 16 tells the voyage of the slave ship *Sally* stage by stage. Here is the rum's part in it. In 1764 the brothers Nicholas, John, Joseph and Moses Brown of Providence sent the ship to West Africa with 17,274 gallons of rum to trade, along with chains, shackles and guns. Its captain, Esek Hopkins, used the rum to buy 196 people.

At least 109 of the 196 died, by the count in Brown University's report on the voyage. Several were children, and one woman hanged herself below deck. When the captives rose up against the crew at sea, Hopkins's men fired on them. The ship's account book records that the crew "Destroyed 8," which means they killed eight people. After that, the account book says, "Some Drowned themselves Some Starved and others Sickened & Dyed."

**The Sugar Act.** Rum was made from molasses. Since the Molasses Act of 1733, colonial merchants had smuggled molasses from the French islands to avoid its tax of sixpence a gallon. In 1764, the year the *Sally* sailed, members of the British Parliament cut the tax on foreign molasses to threepence a gallon, in a law called the Sugar Act. They also pushed the British navy to stop the smuggling, and navy officers who caught smugglers could seize half of the smuggled goods they found.

**From rum to whiskey.** During the Revolution, British warships stopped much of the shipping, and molasses became costly and hard to get. Scotch-Irish farmers in Pennsylvania, Maryland, western Virginia and western North Carolina made whiskey from rye and corn instead. Before 1800, distillers in Kentucky were shipping whiskey down the rivers to New Orleans.

### Native leaders against the liquor trade

Hagler, a leader of the Catawba people in the hill country of the Carolinas, spoke to officials sent by North Carolina in 1754. He told them, "You Rot Your grain in Tubs, out of which you take and make Strong Spirits." Hagler and other Native leaders asked the colonists to stop the liquor trade, because it brought violence and despair.

**What the British official wanted.** Sir William Johnson, the British superintendent of Indian affairs for the northern colonies, handled dealings with Native nations, and he wanted the trade to go on. In 1764 he wrote to his bosses in London, the Lords of Trade, that rum could cause problems. He also wrote that "the Trade will never be so extensive" without rum. After the Revolution, traders carried liquor farther west, and they added water to it so they had more to sell.

**Handsome Lake.** United States troops burned the villages of the Haudenosaunee, also called the Iroquois, in New York in 1779. After the war, at Fort Stanwix in 1784, American negotiators backed by soldiers took huge sections of land from the Six Nations of the Haudenosaunee. By 1799 the Haudenosaunee had lost most of their land in New York and Pennsylvania, and many of them drank heavily.

One was Handsome Lake, a Seneca man from the Genesee River. In 1799, sick after many years of heavy drinking, he had visions. Soon after, he stopped drinking and began preaching against drunkenness. His teaching became the Longhouse Religion, which Haudenosaunee people still practice.

### Benjamin Rush

> **Who:** A Philadelphia doctor who signed the Declaration of Independence and wrote that heavy drinking was a disease.
>
> **When and where:** Philadelphia, 1785 to 1790.

**His chart put water at the top and the gallows at the bottom.**

Before Benjamin Rush, most Americans thought a drunkard simply lacked the will to stop. Rush argued that heavy drinking was an addiction.

**The book.** In 1785 he published a book about ardent spirits, meaning strong liquor such as rum, gin and whiskey. Its title was *An Inquiry into the Effects of Ardent Spirits Upon the Human Body and Mind*, and some records date the first printing to 1784.

Rush wrote that a person begins drinking by free choice, and the habit then becomes a need. In his words: "The use of strong drink is at first the effect of free agency. From habit it takes place from necessity." He said the only cure was to stop drinking completely. His advice to heavy drinkers was "Taste not, handle not."

**The thermometer.** An edition of 1790 added a chart that Rush called "A Moral and Physical Thermometer." Water and milk stood at the top. Lower down, punch led to "idleness, sickness and debt." At the bottom, gin, brandy and rum taken every day led to "murder, madness" and the gallows.

Few people changed their drinking at the time. The historian Mark Lender says that "the conception we have of addiction today can generally be traced back to Benjamin Rush."

### Why farmers went to war over a whiskey tax

Farmers in western Pennsylvania turned their grain into whiskey and used the whiskey as money. From 1791 some of them fought a new federal tax on whiskey, and in 1794 hundreds of them took up guns against it. The fight is called the Whiskey Rebellion.

**Why whiskey.** The roads over the mountains to the east were bad, and grain spoiled on the way. Whiskey kept, and it was easier to carry. Coins were scarce on the frontier, so people paid for goods and paid their workers in whiskey.

**Whose land it was.** The whiskey farmers worked land that the Shawnee, Delaware and Mingo peoples had used. Representatives of the Six Nations of the Haudenosaunee had signed that land over to Britain in 1768, at Fort Stanwix in New York. That was an earlier treaty than the one made at the same fort in 1784. The Shawnee and Delaware, who lived on much of the land, were at the meeting but did not sign.

**The tax.** Alexander Hamilton, the Treasury Secretary in charge of the country's money, asked for a tax on whiskey made in the United States in January 1791, to pay the debt from the Revolutionary War. Members of Congress voted it into law. The law set the tax at 7 cents a gallon, but big distillers paid less than that and small ones paid more.

A big distiller could instead pay a flat fee for each still, the equipment used to distill liquor, and that came to as little as 6 cents a gallon. A farmer with a small still paid about 9 cents a gallon. The law required payment in coin, which the farmers rarely had.

**Two men tarred and feathered.** A gang of armed men in disguise caught Robert Johnson, a new tax collector, at Pigeon Creek in Washington County, Pennsylvania, on September 6, 1791. Some records give the date as September 11. They tarred and feathered him, which meant pouring hot tar on his skin and sticking feathers to the tar. They cut off his hair and took his horse, so he had to walk a long way. Hamilton's 1794 report on the attacks names none of the men.

Officials sent a man named John Connor to serve court papers on Johnson's attackers. Men seized Connor, whipped him, and tarred and feathered him too. They took his money and his horse, blindfolded him and tied him up in the woods, where he stayed for five hours. No surviving record names who did it.

**The fight at Bower Hill.** John Neville, the regional tax inspector, went with a United States marshal to serve court papers on July 15, 1794. A marshal was an officer who carried out the orders of the national courts. At a farm about 10 miles south of Pittsburgh, men fired warning shots at them.

The next day, at least 30 men from the Mingo Creek militia surrounded Neville's house, called Bower Hill. Neville shot and killed one of them, Oliver Miller. Neville had the people he enslaved help him defend the house. They could not refuse.

The men came back on July 17, this time between 400 and 600 of them, led by Major James McFarlane, who had fought in the Revolution. By then 10 United States soldiers from Pittsburgh had come to defend the house, and Neville had left to hide nearby.

After about an hour of shooting, McFarlane called a stop. When he stepped into the open, someone in the house shot and killed him. The records do not say who fired. The attackers burned Neville's house and the quarters where the enslaved people lived. The soldiers surrendered, and the attackers sent them away.

**Known:** The dead at Bower Hill included McFarlane and one or two other militiamen.

**Not known:** How many men died there in all, and whether one of the soldiers later died of his wounds.

**The army.** Washington called up 12,950 militiamen from New Jersey, Maryland, Virginia and Pennsylvania. He went with them as far as Bedford, Pennsylvania, and Fort Cumberland, Maryland, then went back to Philadelphia. He left Henry Lee, the governor of Virginia, in command, and Hamilton went along as an adviser. The rebels scattered without a battle. About 12 soldiers died of illness or accidents.

**The Dreadful Night.** Soldiers under Lee broke into houses on the night of November 13, 1794, and seized people, rebels and witnesses alike. The soldiers drove the prisoners barefoot, in their nightclothes, over muddy roads and through streams, and locked them in animal pens and in cellars with no floors. The soldiers ruined the health of some of the prisoners, and at least one prisoner died. In all, the soldiers arrested about 150 men during the march west.

**The trials.** Soldiers marched twenty of the prisoners to Philadelphia and paraded them down Broad Street on Christmas Day 1794, as trophies of the march. Ten were tried for treason, the crime of making war against one's own country, and two were found guilty. Members of Congress voted to end the whiskey tax in 1802.

### Philip Vigol

> **Who:** A man from western Pennsylvania, one of the first two Americans found guilty of treason against the United States, for attacking whiskey-tax officers.
>
> **When and where:** Westmoreland and Fayette counties, Pennsylvania, 1794. Philadelphia, 1795.

**His party carried guns, beat drums and burned a tax officer's house.**

The court report spells Philip Vigol's name this way. Other records spell it Wigle, Weigel or Wigal.

**Reigan.** During the rebellion, Vigol went with an armed party, carrying guns and beating drums, to the house of Reigan, a tax officer in Westmoreland County. They forced Reigan to hand over his official papers and made him swear never to collect the tax again.

**Wells.** The same party then rode to the house of Wells, the tax officer in Fayette County, and swore to destroy Wells and his house. Wells had run and hidden. The men ransacked his house, which means they tore through it and wrecked it. Then they burned it, with everything inside, including the tax records. Later they found Wells, locked him up and made him swear to quit his job.

**The trial.** A jury in the United States court in Philadelphia found Vigol guilty of treason in 1795, and the judges sentenced him to death by hanging. At the trial, Justice William Paterson told the jury that fear excused a crime only when a person's life was in real danger at that moment. John Mitchell, the other man found guilty, was also sentenced to hang.

**The pardon.** President Washington pardoned Vigol and Mitchell in November 1795, which means he freed them from their punishment. The records differ on the day, November 2 or November 14. In his yearly message to Congress, Washington wrote, "The misled have abandoned their errors."

### George Washington's rum and whiskey

George Washington used alcohol to win votes and to keep soldiers working, and he handed it out to the people he enslaved on the days they worked. At the end of his life he owned one of the largest whiskey distilleries in the country.

**Votes.** Washington ran for the Virginia House of Burgesses, the colony's elected lawmaking body, in Frederick County in 1758. He gave the voters 28 gallons of rum, 50 gallons of rum punch and 82 gallons of wine, beer and cider. He won the seat.

**Soldiers and the enslaved.** As commander of the Continental Army, he wrote in June 1779 that he wanted "a pretty good stock of rum" at the forts for soldiers on work duty.

At his plantation, Mount Vernon, he gave the people he enslaved an allowance of liquor for each day's work. They could not refuse the work. Once he accused his overseer, James Butler, the man who ran their work, of giving the enslaved people 36 pints of rum. Butler answered that he had given "no more than a pint of rum & a pound of Meat to each man."

**The distillery.** His farm manager, James Anderson, advised him to build a whiskey distillery at Mount Vernon in 1797. It made 600 gallons that first year. In 1799, the year Washington died, it made almost 11,000 gallons, worth $7,500, when the average distillery in Virginia made about 650 gallons. Anderson's son, John, ran it with an assistant distiller and six enslaved workers. Their names were Hanson, Peter, Nat, Daniel, James and Timothy.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 8 minutes**

Americans of the early 1800s drank almost three times as much alcohol as Americans do now, and the first big campaign against drinking began. The average American of drinking age drank 7.1 gallons of pure alcohol in 1830, against 2.48 gallons in 2023. People drank at breakfast, in the fields and at work.

Ministers and reformers began asking people in 1826 to sign a pledge, a written promise not to drink, and more than a million signed. By the 1840s and 1850s drinking had fallen to about 3.5 gallons, half the 1830 figure.

**Other drugs.** Anyone could buy laudanum, a painkiller made of opium and alcohol, without a doctor's order, and doctors gave it to adults and to children. Among Native nations, leaders such as Little Turtle of the Miami asked members of Congress to stop the traders who sold liquor to their people.

### A dram with breakfast

Men, women and even children in the early 1800s drank "a healthful dram" with breakfast. A dram was a small drink of liquor. Farmers took cider, beer or whiskey into the fields. Employers stopped work in the middle of the morning so their workers could drink. When people got sick, a doctor's first medicine was often a drink of alcohol.

**Counting the alcohol.** Beer, cider, whiskey and rum hold different amounts of alcohol, so the usual way to compare them is to count only the pure alcohol inside the drinks. By the count of the historian W. J. Rorabaugh, Americans of drinking age drank an average of 5.8 gallons of pure alcohol each in 1790 and 7.1 gallons in 1830. In 2023 Americans aged 14 and older drank an average of 2.48 gallons each, by the count of the National Institute on Alcohol Abuse and Alcoholism.

Drinking fell to about 3.5 gallons of pure alcohol a person each year between 1840 and 1860. Those were the years when the temperance societies were most active.

### Temperance and the pledge

People in Connecticut, Virginia and New York had formed temperance societies, groups that urged drinking little or no alcohol, by 1808. Lyman Beecher, a minister in Connecticut, began giving talks against all drinking of liquor in 1825.

**The American Temperance Society.** Reformers in Boston founded the American Temperance Society on February 13, 1826. Its members signed a pledge not to drink liquor, such as whiskey and rum. The pledge still allowed beer, wine and alcohol taken as medicine. Within five years the society had 2,220 local groups and 170,000 members. By the late 1830s it had more than 8,000 groups and more than 1,250,000 members.

**No alcohol at all.** The reformers split in the late 1830s. Many moved to total abstinence, which means no alcohol at all, not even beer or wine. Some stopped trying to talk people out of drinking and began asking lawmakers to ban the sale of liquor.

**The first laws.** Massachusetts lawmakers banned selling hard liquor, such as whiskey and rum, in amounts of less than 15 gallons in 1838. Only people with money could buy 15 gallons at once, so under this law only the rich could buy hard liquor. The lawmakers canceled the law within two years. In the 1840s, lawmakers in many states let voters in each town or county decide on liquor licenses, the papers from the government that allowed a person to sell liquor.

**The Navy's ration.** Sailors in the Navy got a daily ration of liquor, a set share handed out each day. Almost 400 people signed a petition, a paper people sign to ask for something, to members of Congress in 1843, asking them to end it. The petition was more than 10 feet long.

### The Washingtonians, 1840

Six drinkers met at Chase's Tavern on Liberty Street in Baltimore on April 2, 1840, and began keeping each other sober. They were William K. Mitchell, John F. Hoss, David Anderson, George Steers, James McCurley and Archibald Campbell. They called their group the Washington Temperance Society.

**Telling stories.** The members stayed sober by telling each other the stories of their own drinking. Then they went looking for other drinkers and told them the same stories. Estimates of how many people joined run from tens of thousands up to 600,000. Within a few years the group faded away.

**Lincoln's speech.** Abraham Lincoln, then 33 years old, spoke to the Washingtonians of Springfield, Illinois, on February 22, 1842. He said that people had blamed and scolded drinkers, and the men who sold them liquor, too much, and that this was both unwise and unfair. "If you would win a man to your cause," he said, "first convince him that you are his sincere friend." He also said that "a drop of honey catches more flies than a gallon of gall," a bitter liquid.

### John B. Gough

> **Who:** An English-born bookbinder, a worker who sews and covers books, whose drinking cost him his work. His wife and baby died while he was drunk. He signed the temperance pledge and spent his life asking others to sign it.
>
> **When and where:** New York, and Worcester, Massachusetts, 1829 to 1845.

**Sent out to buy two quarts of rum, he drank them himself.**

**Drinking.** John B. Gough was born in Sandgate, England, in 1817, and came to America at the age of 12, landing in New York in August 1829. He learned bookbinding in New York City. After his mother died, he began drinking heavily. He lost one job after another and sang comic songs in theaters.

**Delirium tremens.** Once, when he stopped drinking all at once, he had delirium tremens, an illness of heavy drinkers who suddenly stop. The body shakes and the mind is confused, and the person sees things that are not there. The illness can kill. In *An Autobiography*, printed in 1845, Gough wrote: "Hideous faces appeared on the walls, and on the ceiling, and on the floors." He saw "millions of monstrous spiders" around him.

**His wife.** When his wife fell sick, the women nursing her sent him to buy two quarts of rum. He drank it himself. Ten days later his wife and their baby both died. Gough wrote that the whole town learned "that my wife and child were lying dead, and that I was drunk!"

**The pledge.** In Worcester, Massachusetts, in late October 1842, a stranger touched his shoulder and asked, "Why do you not sign the pledge?" The man was Joel Stratton, a waiter at the town's temperance hotel. The next evening Gough told his story to a meeting at the Worcester town hall. Then he signed the pledge.

About five months later he drank again, and then he signed the pledge a second time, in public. Between May 1843 and January 1845, he wrote, he traveled more than 12,000 miles and gave 605 talks. At those talks, 31,760 people signed the pledge.

### Whiskey and enslaved people at Christmas

Frederick Douglass, who was enslaved in Maryland in the 1830s, wrote in his book of 1845 that slaveholders used whiskey to control the people they enslaved. Enslaved people had the days between Christmas and New Year's off work. Slaveholders wanted them to spend those days drunk.

"It was deemed (thought to be) a disgrace not to get drunk at Christmas," Douglass wrote. Slaveholders made "bets on their slaves, as to who can drink the most whisky without getting drunk." In this way, Douglass wrote, they got "whole multitudes to drink to excess," which means far too much.

**Why they did it.** Douglass wrote that the slaveholders did this to keep enslaved people from rising up in an armed revolt. He wrote that he and the others felt "that we had almost as well be slaves to man as to rum."

### Liquor and Native nations

Little Turtle, also called Michikinikwa, was a leader of the Miami people. He urged members of Congress to stop traders from selling liquor to Native nations. Congress members gave the president the power to stop those sales in 1802. War Department officials then made rules that banned traders from bringing liquor onto Native land, and did little to enforce them.

**The traders.** Traders kept selling because they made more money on liquor than on other goods. They also watered it down. Members of Congress made it a crime in 1834, with a fine of up to $300, to bring liquor onto Native land.

**Native leaders.** Native leaders worked against drinking among their own people. The Shawnee religious leader Tenskwatawa and a Delaware woman named Beate told their followers to give up alcohol. Pawnee leaders limited drinking in their towns.

Leaders of the Mohican-Stockbridge people wrote to Congress in 1827. They had been living on part of the Oneida Reservation in New York. They wrote that one reason they had agreed to move to what is now Wisconsin was to "flee from" liquor in their community. The land in Wisconsin was the homeland of the Menominee people.

### Opium sold as medicine

Opium is a drug made from the opium poppy. It stops pain and brings sleep, and a person who takes it every day comes to need it. Laudanum was opium dissolved in alcohol. Until the early 1900s, anyone could buy laudanum without a doctor's order.

**For colds and for babies.** Doctors gave laudanum for colds, for heart disease and for pain, to adults and to children. Nurses fed it to babies with a spoon. Patients having surgery in the late 1700s and early 1800s got laudanum and alcohol first. Then the surgeon's helpers held them down while the surgeon cut.

**Morphine.** A German druggist named Friedrich Sertürner took a drug called morphine out of opium in 1804. In 1817 he tested morphine on himself and three boys, and all four nearly died. A German pharmacy that later became the drug company Merck began making morphine for sale in 1827.

### Chewing tobacco

The English writer Charles Dickens visited the United States in 1842. In his book *American Notes*, he complained about how common it was in Washington to chew tobacco and spit out the juice. In the courts of law, he wrote, "the judge has his spittoon, the crier his, the witness his, and the prisoner his." A spittoon is a bowl for spitting into, and the crier was the officer who called the court to order.

In hospitals, Dickens saw signs asking medical students to spit their tobacco juice into boxes and not onto the stairs. On a steamboat, he watched two young men chew and spit on the deck for a quarter of an hour before breakfast.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 16 minutes**

Lawmakers in thirteen states banned liquor between 1851 and 1855, while drugstores went on selling opium, morphine and cocaine openly in medicine bottles. Maine's lawmakers were the first of the thirteen, in 1851. In Portland, Maine, in 1855, soldiers fired on a crowd at the mayor's order and killed a young sailor. In the Civil War, surgeons gave wounded soldiers morphine and opium, and thousands of veterans came home addicted.

**Medicine and the law.** Their medicines held opium, morphine, cocaine (a drug made from coca leaves) and alcohol, and the labels did not have to say so. City, state and federal lawmakers passed laws against opium. A federal law of 1887 named Chinese people outright, and accounts differ about whom San Francisco's opium law of 1875 was aimed at.

**Women against the saloon.** Women marched into saloons to pray, and in 1874 they founded the Woman's Christian Temperance Union. In 1880 Kansas voters approved a ban on liquor in their state constitution, the state's highest set of laws.

### The Maine Law and the Portland Rum Riot

Lawmakers in Maine banned the sale of all alcoholic drinks on June 2, 1851. The law still allowed alcohol for medicine and for use in factories. Neal Dow, the mayor of Portland, had helped write it. By 1855, lawmakers in twelve more states had passed bans of their own. Judges threw out some of these laws, and lawmakers passed them again.

**Dow and the Irish.** For years Dow had ordered police raids on saloons in Portland. A saloon was a bar, mostly for men, that sold drinks by the glass. Irish immigrants ran many of the saloons Dow raided, and he gave speeches about "rum-swilling foreigners." About one in nine of Portland's 21,000 people was an Irish immigrant in 1850.

**The liquor at City Hall.** Dow was mayor again in 1855. He had city officials buy $1,600 worth of liquor for medicine and for use in workshops and factories, and he stored it at City Hall. The law required a city committee to make such a purchase, and no committee had been named.

Under the Maine Law, any three voters could ask a judge for a search warrant, a paper from a judge that allows a search. Three men got a warrant to search City Hall on June 2, 1855. The police would not let them in. By evening a crowd of between 1,000 and 3,000 people, most of them Irish, stood outside. Some threw stones at the door.

**The shooting.** Dow called out the militia, a force of part-time soldiers, and ordered them to fire. John Robbins, a 22-year-old sailor from Deer Isle, Maine, broke a hole in the door of the room where the liquor was kept. The soldiers shot him dead. He had planned to marry the next day. The soldiers kept firing as the crowd ran and wounded seven more people. The New England Historical Society's account of the riot does not name the soldiers who fired or their officers.

Dow was tried for buying the liquor improperly and found not guilty. Voters turned him out of office, and Maine lawmakers ended the ban in 1856.

### How the Civil War made thousands of addicts

Soldiers in the Civil War were given whiskey as a "stimulant," a drink to give them energy. Members of Congress put a tax on liquor and tobacco in 1862 to help pay for the war. Navy officials ended the sailors' daily ration of liquor on September 1, 1862.

**The needle.** Doctors had begun using a new tool just before the war, between 1853 and 1855. The hypodermic syringe is a hollow needle for pushing a drug under the skin, and with it doctors gave more morphine. In the war, surgeons gave morphine shots and opium pills to soldiers with gunshot wounds and to soldiers whose arms or legs they had cut off. Diarrhea spread through the army camps, and doctors gave opium for that too.

**Withdrawal.** Morphine and opium stop pain, and a person who keeps taking them comes to need them. When the drug stops, the body goes into withdrawal, the sickness that comes when the body loses a drug it depends on. The person sweats, aches and cannot sleep. Later come stomach cramps, diarrhea, sick stomach and vomiting.

**"Opium slavery."** Thousands of veterans came home addicted, and they called it "opium slavery." Addicted veterans found little sympathy. Many of them could not get medical care, and many died of accidental overdoses. An overdose is too much of a drug at once, enough to make a person very sick or kill them.

**Not known:** how many veterans were addicted. The historian Jonathan S. Jones, who read their letters and records, says there were thousands.

**Disputed:** a claim that 400,000 veterans came home with a "soldier's disease" of morphine addiction. The earliest known use of the phrase "soldier's disease" is from 1915, fifty years after the war.

### John Tackett Goolrick

> **Who:** A soldier for the Confederacy, the Southern states that broke away to keep slavery, in a unit that fired cannons, whose family's letters record his 30 years of morphine addiction.
>
> **When and where:** Petersburg and Richmond, Virginia, 1864. Fredericksburg, Virginia, 1865 to 1925.

**His family locked him in a farmhouse room for weeks.**

**The wound.** John Tackett Goolrick served in the Fredericksburg Artillery in Robert E. Lee's army, and he strongly supported the Confederacy's fight to keep slavery. In August 1864, at the siege of Petersburg, an attack in which an army surrounded the city to force it to give up, a bullet hit him in the left leg.

He was taken to Chimborazo, a hospital in Richmond. Jones, who read the family's letters, writes that surgeons there apparently gave him morphine for the pain. At Chimborazo, or in the years after, he became addicted. He stayed in the army until Lee surrendered at Appomattox in April 1865.

**The breakdown.** After the war he worked as a lawyer in Fredericksburg. His wife was Frances Bernard Goolrick. He took larger and larger doses of morphine. In 1896 he broke down and could no longer work, and the family ran short of money.

Frances told him that she would divorce him unless he gave up morphine completely. On February 5, 1896, she wrote to her brother, "I can bear neither for myself or the children, this life any longer."

**The locked room.** The family could have sent him to a state hospital for the mentally ill, which took addicted veterans. His brother wrote that sending him there would be "commented upon and asked about" in the newspapers. So the family took him to his brother's farmhouse outside Fredericksburg instead. They locked him in a room, and nurses they paid kept him there for several weeks while he went through withdrawal. His sister-in-law Nora wrote on March 10, 1896, "my heart aches to look at him."

Goolrick got well and went home. The family's letters suggest that he went back to morphine several times before he died in 1925.

### What was in the medicine bottle?

Many medicines sold in stores held opium, morphine, cocaine or alcohol, and some held mercury and lead, which are poisons. These were patent medicines, sold under a brand name. Their makers did not have to tell buyers what was in them.

**A syrup for babies.** Jeremiah Curtis and Benjamin A. Perkins began selling Mrs. Winslow's Soothing Syrup in 1849, as a medicine for babies who were teething. Each ounce held about 65 milligrams of morphine. One teaspoon held enough morphine to kill a young child. Writers for the American Medical Association, a group of doctors, called it a "baby killer" in 1911. No record gives a count of the children who died after taking it.

**A medicine for women.** Lydia E. Pinkham's Vegetable Compound was sold to women from the 1870s. It was 18 to 20 percent alcohol. The label said the alcohol was there only to dissolve the other ingredients and to keep the medicine from spoiling. Critics pointed out that women who had signed temperance pledges took it.

**Who was addicted.** The historian David T. Courtwright writes that people addicted to opium drugs in these years were most often middle-class or rich women who had started taking morphine for an illness. Surveys in the late 1800s found that two out of every three people addicted to laudanum or morphine were women. There was also a "hard core" of opium smokers, mainly Chinese workers and white criminals.

Courtwright writes that, for the size of the population, addiction to these drugs was at least as common in the late 1800s as in 1992. Most of the people who took these medicines left no record of what happened to them.

**Cocaine.** Cocaine came to America as a medicine in 1884, and doctors used it to numb the eye for surgery. Soon there were reports of doctors and druggists addicted to it. Oregon lawmakers banned cocaine in 1887, the first in any state to do so. Lawmakers in Montana, Colorado, Illinois and Massachusetts passed bans by 1898.

### John Stith Pemberton

> **Who:** A Georgia druggist, addicted to morphine after a war wound, who invented Coca-Cola.
>
> **When and where:** Columbus and Atlanta, Georgia, 1865 to 1888.

**The first Coca-Cola had cocaine in it and cost five cents.**

**The wound.** John Stith Pemberton had a medical degree and ran a drugstore in Columbus, Georgia. He fought for the Confederacy at the Battle of Columbus in April 1865 and took a sword wound to the chest. He took morphine for the pain and became addicted.

**The drink.** From 1866 he tried to make a painkiller that had no morphine in it. In 1885 he registered Pemberton's French Wine Coca, a wine mixed with coca, at his drugstore in Columbus. A ban on liquor took effect in Atlanta and Fulton County in 1886, so Pemberton made a version of his drink without wine and called it Coca-Cola. Jacob's Pharmacy in Atlanta first sold it on May 8, 1886, for five cents a glass. Pemberton claimed it cured headaches and morphine addiction.

The makers of Coca-Cola stopped using fresh coca leaves in 1903. They took out the last traces of cocaine by 1929.

**The end.** Pemberton was still addicted and poor when he sold his rights to the drink in 1888. He died of stomach cancer on August 16, 1888. His son Charles was addicted to opium. In June 1894 Charles was found unconscious with opium beside him, and he died ten days later, at the age of 40.

### Opium laws and Chinese immigrants

Chinese immigrants came to California during the Gold Rush, and some of them brought the habit of smoking opium. Opium dens opened in San Francisco's Chinatown in the 1850s. An opium den was a room where people paid to lie down and smoke opium.

**San Francisco, 1875.** The members of San Francisco's Board of Supervisors, the city's lawmakers, made it a crime in 1875 to keep or visit an opium den. Reporters for the *San Francisco Chronicle* wrote that the supervisors acted after they learned that Chinese owners were running dens for white customers. The police chief, Phillip Crowley, said his officers would "keep them from opening places where whites might resort to smoke." His officers often left alone the dens that sold only to Chinese people.

**Why they passed it.** Writers disagree about the reason for the 1875 law. George Fisher, of Stanford Law School, argues that the supervisors wanted to protect white opium smokers. Writers for the Drug Policy Alliance, a group that works to change drug laws, point out that the dens the law closed were mainly in Chinese immigrant neighborhoods.

**A false story.** Irish members of the Church of the Transfiguration, a Catholic church in New York, and its assistant pastor, a priest who helped lead the church, spread a false story in 1883. They said that Chinese men were luring girls as young as 11 and 12 into opium dens. Writers for the *New York Times* called the story "preposterous," which means too silly to believe. About a week later the story was shown to be a hoax, a lie made up on purpose.

**Laws that named race.** Later laws named race and nationality outright. Idaho lawmakers in 1887 set punishments for "every white person" who kept or used an opium den. Fisher calls the early drug laws "laws about whites." In his view, their makers cared only about what drugs did to white people.

In the same year as Idaho's law, members of Congress named Chinese people in a law of their own. They banned any "subject of the Emperor of China" from bringing opium into the United States. By 1896, lawmakers in 22 states had banned opium dens.

### Praying in the saloons: the WCTU

Eliza Jane Thompson led groups of women into the saloons of Hillsboro, Ohio, after she heard the lecturer Diocletian Lewis speak against drink on December 23, 1873. The women sang hymns and prayed until the owners closed. Women in 22 other states copied them. In Anoka, Minnesota, a saloon keeper and his wife poured cold water from an upstairs window onto the praying women.

**The WCTU.** Women met in Cleveland in November 1874 and founded the Woman's Christian Temperance Union, or WCTU. Its members worked to ban the making and selling of liquor. Frances Willard led the WCTU from 1879 until she died in 1898. She argued that women needed the vote to protect their homes from drunk men who beat women.

**Black women in the WCTU.** WCTU leaders set up a Department of Work Among Colored People in 1880. "Colored" was a word for Black people at the time. From 1883 Frances Watkins Harper, a Black poet and public speaker, ran it in the North.

Willard let the southern branches follow "states rights" on race, the idea that people in each state should settle such questions for themselves. In the 1880s Willard and the other national leaders let state and local branches form separate groups for Black women and white women. They did it to win over white women in the South, and Willard said women of both races wanted it. In practice, white members could use the separate groups to keep Black women out of their branches.

Harper called the split a short-term measure. She said it should last only until white members in the Deep South gave up "the spirit of caste," their belief that one race ranked above another.

**Ida B. Wells and Willard.** On speaking tours in Britain in 1893 and 1894, the journalist Ida B. Wells said that Willard had stayed silent about lynching, the killing of people by mobs without any trial. Wells said that the only public words Willard had spoken on the subject excused lynching. When people in Britain asked for proof, Wells sent them a copy of an interview Willard had given a New York newspaper in 1890, after a trip to the South.

In it, Willard said that "the colored race multiplies like the locusts of Egypt," comparing Black people to the swarms of insects sent on Egypt in the Bible. She said that "the grog shop (saloon) is its center of power" and that "the safety of woman, of childhood, of the home, is menaced (threatened)."

Defenders of lynching claimed that mobs killed Black men for raping white women, and Wells said Willard's words had been used to support that claim. Willard denied that she had stayed silent. She later spoke against lynching.

**The Anti-Saloon League.** Howard Hyde Russell, a minister, founded the Anti-Saloon League in Oberlin, Ohio, in 1893. Its leaders judged lawmakers only by how they voted on liquor, even if the lawmakers drank themselves. The league became a national group in 1895.

### Kansas goes dry, 1880

Kansas voters were the first in any state to put a ban on liquor into their state constitution. They elected John St. John, who wanted a ban, as governor in 1878. Kansas lawmakers wrote a ban on making and selling liquor into a change to the constitution, and voters approved it in November 1880.

The ban began on May 1, 1881. Two years later Topeka, the state capital, still had 43 illegal bars. Their owners stayed open by paying a fine of $100 each month. The ban stayed in the Kansas constitution until 1948.

### Liquor laws and Native nations

Members of Congress changed the 1834 law against bringing liquor onto Native land in 1854. The change stated that Native people themselves could not be charged under it. In 1895 they made it a crime to sell or give alcohol to anyone in Indian Territory, now Oklahoma, punished by a fine and one month to five years in prison.

**Allotments.** Members of Congress set a punishment of at least 60 days in prison, with no upper limit, in 1897 for giving alcohol to Native people who held allotments under the Dawes Act. Under that law of 1887, federal officials broke up land that a Native nation had held together into plots for single families, called allotments, and sold off the land that was left over. Native nations held about 138 million acres in 1887 and about 48 million by 1934.

**Who was in prison.** By 1900, about one in every 20 people in federal prisons had been found guilty under these liquor laws. The count does not say how many of them were Native people. Native people could not be charged with bringing liquor onto Native land. Under the law of 1895, though, anyone who sold or gave alcohol in Indian Territory could be charged, Native people included.

**Native leaders' own rules.** Native religious leaders made their own rules about drink and drugs. The Paiute religious leader Wovoka told followers of the Ghost Dance, a religious movement he led, not to drink. On the Comanche reservation in Oklahoma, Quanah Parker led ceremonies in which people took peyote, the small cactus that causes visions, as a sacred act of worship. He argued for the right to use peyote in this way.

### A gold cure and a cigarette machine

Dr. Leslie Keeley opened a clinic for heavy drinkers in Dwight, Illinois, in 1879. He gave them shots of his medicine four times a day, and other patients got it by mail. He called it the "Gold Cure" and said the shots held "bichloride of gold," a chemical made with gold. By 1900 more than 300,000 people had taken it. Other doctors criticized it.

**The cigarette machine.** A skilled worker rolling by hand could make about four cigarettes a minute. In 1880 James Albert Bonsack of Virginia built a machine that rolled about 200 a minute. James Buchanan Duke signed a deal with Bonsack to use the machines, in 1884 or 1885 by different accounts. By 1890 Duke sold 40 percent of the cigarettes in the country. That year he joined his four biggest rivals with his own business to form the American Tobacco Company.

**If you remember one thing:** By 1900 states were banning liquor and cities were banning opium dens, while anyone could still buy opium, morphine and cocaine in a medicine bottle that did not have to say so.

- 1851: Maine lawmakers ban the sale of all alcoholic drinks. Four years later soldiers in Portland shoot dead a sailor, John Robbins, at the mayor's order.
- 1874: Women in Cleveland found the Woman's Christian Temperance Union.
- 1887: Members of Congress ban any "subject of the Emperor of China" from bringing opium into the country.

**Next:** In 1906 drug makers had to start listing what was in the bottle, and in 1920 a ban on alcohol covered the whole country.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 19 minutes**

Drugs and alcohol came under federal control in the first half of the 1900s, first through labels and then through bans. From 1906, drug makers had to list opium, morphine and alcohol on their labels. From 1915, everyone who sold opium or cocaine had to register and keep records, and Treasury officials, who worked in the department that handles the government's money and taxes, took doctors to court for giving addicts their drug. In 1937 members of Congress taxed marijuana.

**Prohibition.** Under federal law, making, selling and carrying alcoholic drinks was banned anywhere in the United States from 1920 to 1933. This ban is called Prohibition. People kept drinking in hidden bars and made liquor at home, and federal agents made more than half a million arrests a year. Treasury officials had more poison added to factory alcohol. Bootleggers, people who made or sold liquor against the law, stole that alcohol and sold it as drink, and the poison killed thousands of drinkers.

**Cigarettes.** Americans smoked an average of 54 cigarettes a year each in 1900, and by 1963 the figure was 4,345.

### Carry Nation

> **Who:** A Kansas woman who smashed saloons to force officials to enforce the state's ban on liquor.
>
> **When and where:** Kiowa, Wichita and Topeka, Kansas, 1900 to 1901, and Kansas City, Missouri, 1901. Arrested more than 30 times through 1910.

**She walked into Dobson's Saloon carrying rocks.**

Kansas voters had put a ban on liquor into their state constitution in 1880, and it took effect in 1881, but saloons stayed open.

**Her name.** She was born Caroline Amelia Moore in Garrard County, Kentucky, in 1846. Official records spell her name Carrie. Later she spelled it Carry, and she said her name meant "Carry A Nation for Prohibition."

**Two husbands.** In 1867 she married Charles Gloyd, a doctor who drank heavily. They separated before their daughter, Charlien, was born in 1868, and Gloyd died of alcoholism, the illness of being addicted to alcohol, in 1869. In 1874 she married David A. Nation, a lawyer and minister. In Medicine Lodge, Kansas, she started a branch of the Woman's Christian Temperance Union and pressed officials to enforce the ban. She kept at it for about five years.

**Kiowa.** On June 5, 1900, she wrote later, she heard a voice telling her, "GO TO KIOWA." Two days later she walked into Dobson's Saloon in Kiowa, Kansas, carrying rocks. She said, "Men, I have come to save you from a drunkard's fate," and smashed the saloon's stock of liquor. She smashed two more saloons in Kiowa.

**The hatchet.** She wrecked a saloon in Wichita in January 1901 and spent two weeks in jail. Her husband joked that she should use a hatchet next time. "That is the most sensible thing you have said since I married you," she answered. In February 1901, in Topeka, she met the governor and spoke to Kansas lawmakers.

She was arrested more than 30 times between 1900 and 1910. She paid her fines with money from her speeches and by selling small pins shaped like hatchets. In 1901 she opened a home in Kansas City, Missouri, for the wives and children of men who drank. Kansas officials did not really enforce the ban until 1907. She died on June 9, 1911.

### Why the label had to say morphine

The reporter Samuel Hopkins Adams wrote 11 articles about patent medicines, the brand-name medicines whose makers did not have to say what was in them, for *Collier's* magazine in 1905. He wrote that Americans would spend about $75 million that year on medicines that held large amounts of alcohol and opium.

By official tests, Hostetter's Bitters was 44 percent alcohol. One bottle of a medicine called Peruna, he wrote, held as much alcohol as five bottles of beer. He called the opium syrups sold for babies medicines "which stunt or kill helpless infants."

**The 1906 law.** President Theodore Roosevelt signed the Pure Food and Drug Act on June 30, 1906. Under it, drug makers had to print on the label whether a medicine held any of 10 drugs. They included alcohol, morphine, opium and cannabis, the plant marijuana comes from. The law did not ban any of these drugs. Chemists led by Harvey W. Wiley, at the Department of Agriculture, enforced it.

**What changed.** After the law passed, the makers of Mrs. Winslow's Soothing Syrup took out the morphine. The historian David T. Courtwright writes that after 1900 fewer people became addicted through medicine. Doctors had grown more careful, and after the 1906 law and the articles of reporters like Adams, more people were wary of dosing themselves.

### The Harrison Act, 1914: doctors and addicts

Members of Congress passed the Harrison Narcotics Act in 1914. Under it, every seller of opium and cocaine had to register with the government and keep records.

**The claims.** In the years before the law passed, some officials and newspaper writers blamed drug use on Black and Chinese people. A citizens' panel called the Committee on the Acquirement of the Drug Habit wrote in 1903 that if a Chinese man "cannot get along without his dope we can get along without him." In place of "a Chinese man," the panel used an insulting name for Chinese people.

**Hamilton Wright.** Theodore Roosevelt named Dr. Hamilton Wright the first United States opium commissioner, the official in charge of the country's work against opium, in 1908. Wright told members of Congress that cocaine was often "the direct incentive to the crime of rape of white women by Negroes." He was claiming that cocaine drove Black men (Negroes, in the word of the time) to rape white women, that is, to force them to have sex.

A *New York Times* headline of 1914 read "Negro Cocaine 'Fiends' Are a New Southern Menace."

**The dispute.** Historians disagree about how much these claims shaped the drug laws. David T. Courtwright writes that cocaine became linked in the public mind with crime sprees, especially by Black men. George Fisher of Stanford Law School points out that the first state cocaine bans, from 1887 to 1898, came before these newspaper stories. He argues that racial hatred came later, in the way police and other officers enforced the laws.

**The law.** Representative Francis Burton Harrison of New York proposed the law, and President Woodrow Wilson signed it on December 17, 1914. It took effect on March 1, 1915. In the law, narcotics meant drugs made from opium or from coca, the plant that cocaine comes from. Doctors and druggists who handed out these drugs had to register too, and every seller had to pay a small tax.

**Doctors in court.** Treasury officials read the law to mean that a doctor could not give an addict regular doses of a drug, and they took doctors who did to court. The justices of the Supreme Court agreed with them on March 3, 1919, in the case of *Webb v. United States*. A doctor could not write a prescription, a doctor's written order for a drug, for an addict just to keep the addict comfortable. Dr. Webb had written more than 80 morphine prescriptions a week, at 50 cents each.

**The clinics.** City officials then opened 35 public clinics that sold morphine cheaply to addicts who registered. Treasury officials closed every one of them. The last, in Shreveport, Louisiana, closed on February 10, 1923. After that, an addict could get drugs only from dealers, or go to prison.

**Heroin.** Heroin is a drug made from morphine. Young men in the poor immigrant neighborhoods of cities began sniffing small packets of heroin powder in the 1910s and early 1920s. President Calvin Coolidge signed a law on June 7, 1924, that banned bringing opium into the country to make heroin. Representative Stephen G. Porter of Pennsylvania had introduced it.

**The narcotic farm.** Officials of the Public Health Service, the federal health agency, opened a hospital for addicts in Lexington, Kentucky, in 1935. It was called a "narcotic farm," and prisoners could be sent there. One doctor remembered it as "more like a prison than a hospital and more like a hospital than a prison." Courtwright writes that several studies found that 90 percent or more of the people released from Lexington soon went back to drugs.

### Cigarettes become an everyday habit

Americans smoked an average of 54 cigarettes a year each in 1900, by the count of the Centers for Disease Control and Prevention. By 1963 the figure was 4,345. The justices of the Supreme Court ordered James B. Duke's American Tobacco Company broken into four smaller companies in 1911.

**"Tobacco as much as bullets."** General John Pershing led the American army sent to Europe in World War I. Asked what America needed to win the war, he answered, "Tobacco as much as bullets." People in community groups, businesses and relief groups such as the Red Cross, the Salvation Army and the Young Men's Christian Association set up "tobacco funds" to send cigarettes to soldiers. Editors at the *New York Sun* asked readers to give as a way of "proving your patriotism."

**The first cancer studies.** The scientist Ernst Wynder and others began studies in the 1940s that linked smoking cigarettes to lung cancer.

### Prohibition: the law and the people who wrote it

Wayne Wheeler of the Anti-Saloon League played a major part in winning a national ban on liquor. Wheeler and other prohibitionists gained support from the fight to win the vote for women. Frances Willard of the WCTU had joined the two causes in 1879, when she asked for votes for women as a way to protect their homes from drink.

**The war.** In World War I, League leaders also used Americans' anger at Germany to win support. German Americans had been a major force against a ban, and after members of Congress declared war on Germany in April 1917, their protests were ignored.

**The amendment.** Members of Congress approved the Eighteenth Amendment to the Constitution on December 18, 1917. An amendment is a change added to the Constitution. Lawmakers in the 36th state voted for it on January 16, 1919, which made it part of the Constitution. Only the lawmakers of Connecticut and Rhode Island never voted for it.

**What it banned.** The amendment banned making, selling and carrying alcoholic drinks. It did not ban owning them or drinking them. Wheeler helped draft the Volstead Act, the law that set out the rules for the ban. It is named for Andrew Volstead of Minnesota, who led the House committee in charge of laws about courts and crimes. President Wilson refused to sign it and sent it back, and members of Congress passed it anyway on October 28, 1919. The ban began on January 17, 1920.

**The gaps.** A family could make up to 200 gallons of wine and cider a year at home. Doctors could prescribe whiskey as medicine, and they wrote about 11 million prescriptions for it a year through the 1920s. Officials caught 1,000 doctors and 400 druggists selling signed prescription forms to bootleggers in 1931. Twelve of the doctors and 13 of the druggists were charged with crimes.

**Speakeasies.** People drank in speakeasies, hidden bars that sold liquor against the law. By the end of the 1920s New York City alone had about 30,000 of them, by the count of the writer Deborah Blum. Officials in some states, among them Maryland and New York, refused to enforce the federal ban.

### Izzy Einstein

> **Who:** A Jewish immigrant and former postal clerk who became a federal Prohibition agent. He arrested people while wearing disguises.
>
> **When and where:** New York City, 1920 to 1925.
>
> **Movie:** *Izzy and Moe* (1985), a television film directed by Jackie Cooper, with Jackie Gleason as Izzy Einstein and Art Carney as Moe Smith. It is about the two agents.

**One Sunday he and his partner made 71 raids in 12 hours.**

**Eight languages.** Isidor "Izzy" Einstein was born in 1880 to a Jewish family in Austria-Hungary. He came to the United States around 1901, speaking Yiddish, Hungarian, Polish and German, and some Russian, French, Spanish and Italian. He worked as a salesman and then as a postal clerk, and he struggled to support his family on a clerk's pay.

**More than 100 disguises.** With no police training, he joined the new federal Prohibition service in 1920. He brought in his friend Moe Smith, who owned a cigar store. The two men said they used more than 100 disguises, among them a streetcar conductor, a gravedigger, a fisherman, an iceman and an opera singer. They usually carried no guns. Sometimes Einstein told a doorman that he was a Prohibition agent. The doorman laughed and let him in.

**The count.** One Sunday, with reporters following them, they made 71 raids in a little more than 12 hours. Together they made 4,932 arrests by one count, and more than 5,000 by the count of the National Archives. Of the people they arrested, 95 percent were found guilty. Thousands of bartenders, bootleggers and speakeasy owners went to jail because of their work.

**Fired.** Their boss, General Lincoln C. Andrews, fired them along with 36 other men in November 1925, when he reorganized the New York office. Writers at *Time* magazine suggested that their fame in the newspapers had annoyed their bosses. Both men went on to sell insurance. In 1932 Einstein published a book, *Prohibition Agent No. 1*. He died on February 17, 1938.

### Prohibition agents: who enforced the ban

The federal government had 1,450 front-line Prohibition agents in 1930. From 1921 to 1930 the agents made more than half a million arrests a year and seized more than 45,000 cars, by the count of the historian Richard F. Hamm.

**Political jobs.** Politicians handed out many of the agents' jobs. Judge William S. Kenyon said in 1927 that "three-fourths of the 2,500 dry agents are ward heelers and sycophants named by the politicians." He meant that most agents were political helpers and flatterers. When agents had to pass a civil service test, the kind of test used to give out many government jobs, 60 percent failed it.

**Fired for bribes.** In the six years from 1920, 752 Prohibition officials were fired, most for drunkenness or for taking bribes. Mabel Walker Willebrandt was the Assistant Attorney General, a top lawyer in the Justice Department, in charge of Prohibition cases from 1921 to 1929. She said the agents were "as devoid of honesty and integrity" as the lawbreakers, meaning they were just as dishonest.

**The dead.** By their own count, Prohibition agents killed 89 people. The Association Against the Prohibition Amendment, a group working to end the ban, counted about 1,000 people killed in enforcing it. Near the Capitol in Washington in 1924, an agent shooting at a bootlegger's car hit Senator Frank L. Greene of Vermont in the head. Greene never got back the full use of one arm.

The writer Daniel Okrent describes the first agent to kill a suspected bootlegger. That agent had joined under a false name. He had killed a man at the age of 14, and he got his badge while he was still locked up in Dannemora State Prison.

### Poisoned alcohol and jake leg

Prohibition, the national ban on alcohol, lasted from 1920 to 1933. In 1926 and 1927, Treasury Department officials under President Calvin Coolidge ordered more poison put into factory alcohol, and the poison killed thousands of people who drank it.

Factory alcohol, used for fuel and in factories, had chemicals added to it so that no one could drink it. This is called denatured alcohol. Bootleggers, people who made or sold liquor against the law, stole it, paid chemists to take the chemicals out and sold it as liquor.

**More poison.** The officials then ordered makers to add far more poison. By 1927 the mixes included kerosene, gasoline, benzene and mercury salts, and up to 10 percent methyl alcohol, also called wood alcohol, which blinds and kills people who drink it. *Time* magazine reported in January 1927 that three ordinary drinks of the new mix could cause blindness. The records do not name the official who signed the order.

**Christmas 1926.** More than 60 people had come to Bellevue Hospital in New York sick from poisoned liquor by dusk on Christmas Day 1926, and eight of them had died. In the next two days, 23 more people died in the city.

**Known:** the poisoned alcohol killed thousands of Americans.

**Disputed:** how many. Deborah Blum gives 400 dead in New York City in 1926 and 700 in 1927, and another count gives 585 in the city in 1926. For the whole country, one estimate gives more than 5,000 dead, and Blum gives an estimate of at least 10,000 by 1933.

**What officials said.** Charles Norris was New York City's chief medical examiner, the doctor in charge of finding out why people in the city died. He said, "The government knows it is not stopping drinking by putting poison in alcohol." The government, he said, "must be charged with the moral responsibility for the deaths that poisoned liquor causes, although it cannot be held legally responsible."

Seymour Lowman, the Treasury official in charge of Prohibition from 1927 as Assistant Secretary of the Treasury, said drinkers were "dying off fast from poison 'hooch.'" If the result was a sober America, he said, "a good job will have been done." Wayne Wheeler said that a person who drank this alcohol "is a deliberate suicide." Senator Edward I. Edwards of New Jersey called the program "legalized murder."

**Jake leg.** Tens of thousands of people were poisoned in 1930 after they drank Jamaica ginger, a medicine that was 70 to 80 percent alcohol. Under Prohibition one form of it could still be bought without a doctor's order, so people drank it to get alcohol.

The poison came from Harry Gross, the president of Hub Products Corporation in Boston, who wanted a cheaper ingredient for his Jamaica ginger. He chose a chemical called TOCP, used in making lacquer, a shiny coating for wood and metal. People at the Celluloid Corporation, which made TOCP, told him it was not poisonous.

TOCP destroys nerve cells in the spinal cord, the bundle of nerves inside the backbone that carries signals from the brain to the body. People who drank Gross's Jamaica ginger lost the use of their hands and feet. They walked with their toes flopping down. People called the illness "jake leg" and the walk the "jake walk." For most of them the damage never healed.

**Not known:** the exact number harmed. The figure most often given is between 30,000 and 50,000. Most were poor, and many were immigrants.

**Gross's sentence.** A judge fined Gross and his partner Max Reisman $1,000 each. The judge also gave each of them a two-year jail sentence that they did not have to serve. Blues singers recorded songs about jake leg in 1930.

### Alcoholics Anonymous, 1935

Two heavy drinkers named Bill Wilson and Dr. Bob Smith met in Akron, Ohio, in 1935, through a Christian group called the Oxford Group. Together they started Alcoholics Anonymous, or AA (anonymous means without names), where drinkers help each other stop drinking. At meetings, members share their own stories of drinking and of getting sober.

AA members published the group's Twelve Steps, a list of steps for staying sober, in 1939, in a book that members call the Big Book. Wilson and Smith had never heard of the Washingtonians, the Baltimore drinkers of 1840 who also helped each other stay sober by telling their stories.

### Did drinking fall under Prohibition?

Drinking fell under Prohibition, and then much of it came back. The economists Miron and Zwiebel found in a 1991 study that drinking fell at first to about 30 percent of what it had been before the ban. Over the next several years it rose again, to about 60 to 70 percent. Deaths from cirrhosis, damage to the liver from heavy drinking, fell by nearly two-thirds. Blum writes that insurance companies charted a rise in alcoholism of more than 300 percent in the 1920s.

**Known:** drinking fell sharply when the ban began.

**Not known:** how much drinking changed over the whole ban, because the counts point different ways.

**Pauline Sabin.** Pauline Sabin, a leader of the Republican Party in New York, first backed the ban. "I felt I should approve of it because it would help my two sons," she said. She changed her mind. By 1929 she said that "children are growing up with a total lack of respect for the Constitution and for the law." In May 1929, in Chicago, she founded the Women's Organization for National Prohibition Reform to end the ban.

**Repeal.** President Franklin Roosevelt signed a law on March 22, 1933, that allowed beer with 3.2 percent alcohol by weight. Delegates in Utah made it the 36th state to approve the Twenty-first Amendment, which ended national Prohibition, on December 5, 1933. After that, lawmakers in each state and town made their own rules about when, where and to whom alcohol could be sold. Liquor stayed banned in Kansas until 1948.

### Marijuana and the 1937 tax

Marijuana is made from the dried leaves and flowers of the cannabis plant. Harry J. Anslinger ran the Federal Bureau of Narcotics, the federal drug police, from 1930 to 1962. "The best cure for addiction? Never let it happen," he said.

**Anslinger's stories.** His articles against marijuana in the 1930s often told stories that blamed the drug for crimes by Black and Mexican people. One story in his files began, "Two Negroes took a girl fourteen years old..." The historian Courtwright writes that Anslinger played on Americans' fear of immigrants and of other races. Anslinger told the story of Victor Licata, who killed his family with an axe in Florida in 1933, as a marijuana crime. Doctors had found that Licata had a severe mental illness when he was young.

**The tax.** Anslinger drafted the Marihuana Tax Act, and doctors of the American Medical Association objected to it. President Franklin Roosevelt signed it on August 2, 1937, and it took effect on October 1. Selling marijuana without a federal tax stamp, which cost $1 an ounce, became a crime.

**The first arrests.** Federal narcotics agents and Denver police arrested Samuel R. Caldwell, a 57-year-old laborer, for selling marijuana on October 2, 1937. They arrested Moses Baca, 26, for having it. The tax stamps had not yet been printed. Judge J. Foster Symes sentenced Caldwell to four years of hard labor at Leavenworth prison and a $1,000 fine, and Baca to 18 months. "Under its influence men become beasts," Symes said of marijuana. Caldwell was released in 1940 and died in 1941.

**A study.** Mayor Fiorello La Guardia of New York named a committee to study marijuana in 1938. In their report of 1944, the committee's members disputed Anslinger's claims.

### Liquor laws and Native nations

Federal bans on liquor on Native land stayed in force through all of these years. Members of Congress made it a crime in 1910 to bring alcohol onto the land of the Pueblo nations of New Mexico, as a condition of New Mexico becoming a state.

That same year Attorney General George Wickersham, the nation's top lawyer, asked for lighter punishments for selling, giving or bringing liquor to Native people. He wanted these to be lesser crimes, which his lawyers could charge without a grand jury, a group of citizens who decide whether there is enough proof for a trial. The punishments stayed as they were.

The Native American Church was organized in Oklahoma in 1918. Its members take peyote as a sacred act of worship.

**If you remember one thing:** In these fifty years federal lawmakers took charge of drugs and alcohol, with labels in 1906, a drug law in 1914, a national ban on alcohol from 1920 to 1933 and a tax on marijuana in 1937.

**One number:** Americans smoked 54 cigarettes a year each in 1900 and 4,345 in 1963, about 80 times as many.

**Next:** After 1950 scientists showed that cigarettes cause cancer, and a president declared a war on drugs.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 15 minutes**

Americans learned in these fifty years that smoking kills, and the federal fight against drugs grew from $81 million a year in 1969 to $18.4 billion in 2000. About 42 of every 100 American adults smoked cigarettes in 1965, and by 1997 the number was about 25. In 1996 a fired tobacco scientist told a national television audience that his company changed its tobacco to strengthen the effect of nicotine. Drinking rose until 1981 and then fell.

**The war on drugs.** President Richard Nixon called drug abuse "public enemy number one" on June 17, 1971, and reporters named his program the war on drugs. Candy Lightner started Mothers Against Drunk Driving in 1980, after a drunk driver killed her daughter, and by 1988 lawmakers in every state had set the drinking age at 21.

Under a 1986 law passed by members of Congress and signed by President Ronald Reagan, 5 grams of crack, a kind of cocaine that can be smoked, carried the same prison term as 500 grams of powder cocaine. A company owned by the Sackler family began selling a strong painkiller called OxyContin in 1996.

### How much people drank and smoked

Americans aged 15 and over drank an average of 2.04 gallons of pure alcohol each in 1950. From 1970 the count covers people aged 14 and over, and by that count the figure rose to 2.76 gallons in 1981, the highest since Prohibition. By 1995 it had fallen to 2.15 gallons.

Scientists at the National Institute on Alcohol Abuse and Alcoholism work these figures out from sales of alcohol, not from asking people what they drank. Between 1974 and 1981, 68 to 71 of every 100 adults told the Gallup company, which asks adults questions about what they think and do, that they drank.

**Cigarettes.** Cigarette smoking peaked in 1963, at 4,345 cigarettes a year for each person. By 1998 the figure was 2,261. In the late 1990s the Centers for Disease Control and Prevention (CDC) counted about 430,000 deaths a year from tobacco, one of every five deaths in the country.

**The Surgeon General's report.** The studies that Ernst Wynder and others began in the 1940s went on into the 1950s. In 1964 a committee of experts working for the Surgeon General, the nation's top public health doctor, concluded that smoking causes lung cancer and cancer of the voice box. Nixon signed a law on April 1, 1970, that banned cigarette ads on radio and television from January 2, 1971.

### Billie Holiday and the narcotics agents

The singer Billie Holiday was arrested for drugs three times. Federal narcotics agents made the last two arrests, the last one in her hospital bed.

**New York, 1947.** Holiday was arrested on May 16, 1947, for having narcotics in her New York apartment. In court she said, "It was called 'The United States of America versus Billie Holiday'. And that's just the way it felt." She pleaded guilty, and a judge sent her to Alderson Federal Prison Camp in West Virginia.

After she was found guilty, she lost the police license she needed to sing in New York City clubs that sold alcohol. The federal agent George Hunter White arrested her again in a San Francisco hotel on January 22, 1949.

**The hospital bed.** Holiday was in Metropolitan Hospital in New York in 1959, being treated for liver and heart disease. On May 31, Harry Anslinger ordered agents of his Federal Bureau of Narcotics to arrest her there for having drugs. The agents handcuffed her to her hospital bed. A police guard stayed at her room until a judge ordered the handcuffs taken off.

She died in that room on July 17, 1959, at the age of 44. The cause was heart failure and fluid in her lungs, which came from cirrhosis, scarring of the liver. She had 70 cents in the bank.

**Disputed:** why the agents went after her. The writer Johann Hari has argued that Anslinger's agents targeted Holiday from 1939 because of her song "Strange Fruit," which is about lynching, killing by a mob. The jazz writer Lewis Porter disputes this. He points out that the claim first appears in Hari's own book, in 2015.

### Native nations and the end of the federal ban, 1953

Members of Congress changed the federal liquor laws for Native people on August 15, 1953. Since 1834 it had been a federal crime to bring liquor onto Native land. Under later laws it was also a crime to sell or give alcohol to many Native people even off that land. After the 1953 change, Native people could buy alcohol off their land like anyone else.

The law's title states its purpose: "to eliminate certain discriminatory legislation against Indians," meaning laws that treated Native people worse than others. The federal ban on liquor on Native land had lasted 20 years longer than national Prohibition.

**Each nation's choice.** On a nation's own land, a sale of alcohol now had to follow both state law and a law passed by that nation's government, approved by the Secretary of the Interior, the head of the federal department that handles dealings with Native nations.

Members of Congress gave each nation the choice of keeping its ban, and some nations kept it. The Oglala Sioux Tribe, on the Pine Ridge Reservation in South Dakota, was one, according to the National Alcohol Beverage Control Association, a group of state alcohol officials.

### LSD and marijuana

LSD is a drug that makes people see and hear things that are not there, and in the early 1960s it was legal. Timothy Leary, a teacher at Harvard University who studied how the mind works, ran experiments from 1960 in which he gave people psilocybin, a drug from certain mushrooms that causes visions. He also used LSD.

Harvard officials stopped paying him on April 30, 1963, and Harvard's president, Nathan Pusey, said he had "failed to keep his classroom appointments." Nixon later called Leary "the most dangerous man in America."

**Marijuana.** A man named Lowell Eggemeier lit a marijuana cigarette in San Francisco's Hall of Justice in 1964 and asked to be arrested. The writer Martin A. Lee dates the start of the modern campaign to make marijuana legal to that act. Oregon lawmakers made having a small amount of marijuana punishable by a fine instead of jail in 1973. In November 1996, California voters approved Proposition 215, 56 percent to 44 percent, and California became the first state to allow marijuana as a medicine.

### Nixon declares the war on drugs, 1970 and 1971

Nixon signed a law on October 27, 1970, that sorted drugs into five lists, called schedules. The lawmakers put marijuana and heroin on Schedule I, the list for drugs with a high risk of abuse and no accepted use as medicine. Under the same law, having a small amount of a drug became a lesser crime, with at most one year in jail for a first offense. Selling drugs carried harsher punishments than before.

**Heroin in Vietnam.** Two members of Congress, Morgan Murphy and Robert Steele, came back from the war in Vietnam in May 1971. They reported that "as many as 10 to 15 percent of our servicemen are addicted to heroin."

**"Public enemy number one."** Nixon spoke at the White House on June 17, 1971. "America's public enemy number one in the United States is drug abuse," he said. He asked for $155 million in new money, for a total of "over $350 million" a year to fight drugs. When he took office in 1969, the federal drug budget had been $81 million. While Nixon was president, about 70 of every 100 federal dollars spent against drugs went to treatment and prevention.

**Arrests.** Agents of Nixon's new Office of Drug Abuse Law Enforcement made 6,000 drug arrests in 18 months, from 1972 to 1973, and most of the people arrested were Black. In 1973 Governor Nelson Rockefeller of New York signed laws that set 15 years to life in prison for selling two ounces, or holding four ounces, of heroin, cocaine or marijuana.

**The Ehrlichman quote.** The journalist Dan Baum published notes in 2016 of a 1994 interview with John Ehrlichman, one of Nixon's top advisers. In Baum's notes, Ehrlichman said that "by getting the public to associate the hippies with marijuana and blacks with heroin," and then making both a crime and punishing them heavily ("criminalizing both heavily"), "we could disrupt those communities." Ehrlichman had died in 1999. His children and other officials who had worked for Nixon disputed the quote.

### Betty Ford

> **Who:** The wife of President Gerald Ford. She told the country she was addicted to pills and alcohol, and then she founded a treatment center.
>
> **When and where:** Long Beach and Rancho Mirage, California, 1978 to 1982.

**At times she took as many as 20 pills a day.**

**The pills.** A pinched nerve in Betty Ford's neck put her in the hospital for two weeks in 1964. Doctors gave her drugs for the pain, including strong painkillers and Valium, a drug that calms people. At times she took as many as 20 pills a day. She also drank. Her father and her brother Bob had both been addicted to alcohol.

**The intervention.** Her family held an intervention, a meeting to ask her to go into treatment, on April 1, 1978, after the Fords had left the White House. On April 11 she checked into the Naval hospital in Long Beach, California. She had arthritis, a disease that makes the joints swell and hurt, and a family spokesman read her statement: "I have found I am not only addicted to the medication I have been taking for my arthritis, but also to alcohol."

She later wrote, "I liked alcohol, it made me feel warm. And I loved pills. They took away my tension and my pain."

**The center.** She and Leonard Firestone, a former ambassador, founded the Betty Ford Center in Rancho Mirage, California, in 1982, for people recovering from addiction to alcohol and other drugs. It opened on October 4, 1982. She died on July 8, 2011.

### Why the drinking age is 21

Clarence Busch was drunk when he hit and killed 13-year-old Cari Lightner with his car on May 3, 1980. She was walking to a church festival in Fair Oaks, California. He drove away and left her body there. He had a long record of arrests for drunk driving.

**The sentence.** A judge ruled that Busch's alcoholism had made it harder for him to control his decisions. The judge gave him two years in prison for involuntary manslaughter, the crime of killing someone without meaning to. He entered prison in December 1980 and was paroled nine months later, which means he was let out early under watch.

He went back to prison in 1982 for breaking the rules of his parole, and he was freed again in February 1983. Police arrested him again in April 1985, drunk and driving without a license, after a crash.

**MADD.** Cari's mother, Candy Lightner, founded Mothers Against Drunk Driving, or MADD, in 1980. By MADD's count, nearly 25,000 people were killed in crashes involving alcohol in 1980. That was half of all traffic deaths.

**The drinking age.** Lawmakers in 29 states had lowered the drinking age to 18, 19 or 20 between 1970 and 1975, after the voting age was lowered to 18. Senator Frank Lautenberg of New Jersey wrote a law to raise the drinking age again, and Reagan signed it on July 17, 1984. Under it, a state that let people under 21 buy alcohol lost part of its federal money for highways. By 1988 every state had set the age at 21.

**Disputed:** how many lives the higher drinking age saved. A review for the Institute of Medicine, a national group of health experts, found strong evidence that it worked. The economists Jeffrey Miron and Elina Tetelbaum found in 2009 that the effect faded after a year or two.

### Crack cocaine and the 1986 law

Nancy Reagan, the president's wife, began a campaign in the early 1980s, with help from an advertising company, in which she told young people to "Just Say No" to drugs. Later studies found little or no change in how many young people used drugs after the campaign. The FBI's budget for fighting drugs rose from $8 million in 1980 to $95 million in 1984.

**Crack.** Crack is cocaine that dealers cooked with water and baking soda and dried into small rocks that can be smoked. Smoked crack reaches the brain in 6 to 8 seconds, and the high lasts 5 to 15 minutes. Around 1984 a dose cost as little as $2.50 in some cities. Hospital emergencies from cocaine more than doubled in one year, from 26,300 in 1985 to 55,200 in 1986.

**The 1986 law.** The basketball player Len Bias died from cocaine on June 19, 1986. Afterward, Speaker of the House Tip O'Neill had Democratic leaders write a new drug law, and Reagan signed it on October 27, 1986. In it, members of Congress added $1.7 billion to the fight against drugs and set 29 new minimum prison terms that judges had to give. The law set five years in federal prison for 5 grams of crack, the same as for 500 grams of powder cocaine.

**Who went to prison.** Most of the people sentenced for crack were Black. In 1992, 91 of every 100 people sentenced in federal court for crack were Black and about 3 were white, by the count of the US Sentencing Commission.

The people treated for crack were a more mixed group. Of those who entered treatment for crack in 2004, 53 of every 100 were Black and 38 were white. The historian Elizabeth Hinton writes that Reagan "led Congress in criminalizing drug users, especially African American drug users."

**The bag on television.** President George H. W. Bush held up a bag of crack on television on September 5, 1989. He said it had been "seized a few days ago in a park across the street from the White House." It came out later that agents of the Drug Enforcement Administration had been asked to make an arrest there, and that they had to lure the seller to the park to do it. So the sale across from the White House was one the agents had set up.

**The cost.** By 2000 the federal government spent $18.4 billion a year against drugs, more than 200 times the $81 million of 1969. Nearly half went to law enforcement, the police and agents who catch lawbreakers, and one-sixth went to treatment.

### Jeffrey Wigand

> **Who:** A scientist who ran research at a tobacco company and then told the public that the company changed its tobacco to strengthen the effect of nicotine.
>
> **When and where:** Brown & Williamson Tobacco, Louisville, Kentucky, 1989 to 1996.
>
> **Movie:** *The Insider* (1999), directed by Michael Mann, with Russell Crowe as Jeffrey Wigand. It is about Wigand.

**He said his company added ammonia to boost nicotine's effect.**

**Fired.** Jeffrey Wigand trained as a biochemist, a scientist who studies the chemistry of living things. He became vice president for research at Brown & Williamson Tobacco in Louisville, Kentucky, in January 1989. Brown & Williamson fired him on March 24, 1993. That September the company sued him and cut off his health insurance. In November 1993 he signed an agreement not to talk about his work.

**Testimony.** Under a judge's order, Wigand gave sworn testimony in Pascagoula, Mississippi, in late November 1995, for the state's lawsuit against the tobacco companies. The company's lawyers got a Kentucky court order against him and sued him for "theft, fraud, breach of contract," which means they said he stole, cheated and broke his agreement with the company. Lawyers for the CBS television network stopped the news program *60 Minutes* from showing an interview with him that November.

**On the air.** *60 Minutes* showed the interview on February 4, 1996. Wigand said the company added chemicals such as ammonia to its tobacco to increase the effect of nicotine. He said he had been harassed and had received death threats from people who did not give their names. The company hired investigators, who wrote a 500-page report attacking him and gave it to reporters. The reporters checked it and found that many of its charges were unproven or small.

After he was fired, Wigand taught science and Japanese at a high school in Louisville. He was named Kentucky's Teacher of the Year for 1996.

### OxyContin goes on sale, 1996

Opioids are strong painkillers made from the opium poppy, or from chemicals that act the same way in the body. Too much of an opioid slows a person's breathing until it stops.

**The Sacklers.** Three doctors, the brothers Arthur, Mortimer and Raymond Sackler, bought a drug company called Purdue Frederick in 1952. Their company, later named Purdue Pharma, began selling OxyContin in 1996. OxyContin is a pill of oxycodone, an opioid, made to release the drug slowly. Purdue sold it to be taken every 12 hours, but most patients found that it wore off after eight hours or less.

**The approval.** Dr. Curtis Wright, of the Food and Drug Administration (FDA), reviewed OxyContin before it went on sale. He approved a label that said the slow release "is believed to reduce the abuse liability of a drug," meaning the risk that people would misuse it. A year later Wright left the FDA and went to work for Purdue.

**The sales push.** Purdue's managers trained its salespeople to tell doctors that the risk of addiction was "less than one percent." More than 5,000 doctors, pharmacists and nurses went to Purdue meetings with all their costs paid. Richard Sackler, Raymond's son, ran the company's sales and marketing, and he became its president in 1999.

Prescriptions of OxyContin for pain not caused by cancer rose from about 670,000 in 1997 to about 6.2 million in 2002. From 1995 to 2001, Purdue took in $2.8 billion from sales of OxyContin. David Kessler, who led the FDA when the pill was approved, later called the approval "one of the worst medical mistakes."

**If you remember one thing:** Federal spending against drugs grew from $81 million a year in 1969 to $18.4 billion in 2000.

- 1964: A committee of experts working for the Surgeon General reports that smoking causes lung cancer.
- 1986: A new law gives a person caught with crack the same prison term as one caught with 100 times as much powder cocaine.
- 1996: The Sackler family's company starts selling the painkiller OxyContin.

**Next:** After 2000, deaths from opioids, starting with pills such as OxyContin, rose for more than twenty years.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 12 minutes**

Opioids, first pain pills such as OxyContin, then heroin, then fentanyl, killed about 806,000 Americans from 1999 to 2023, by the count of the Centers for Disease Control and Prevention (CDC). An overdose is too much of a drug at once, enough to make a person very sick or kill them.

Most of the deaths from 2013 on came from fentanyl made outside the law. Overdoses of all drugs killed 107,941 people in 2022, the peak year in the CDC's final figures. By the CDC's early count, the yearly total had fallen to about 67,000 in the 12 months ending in April 2026.

**The rest of the story.** A federal judge sentenced Purdue Pharma, the maker of OxyContin, in 2026, and the company shut down. No member of the Sackler family, who owned it, has been charged with a crime. Over the same years, voters and lawmakers in 24 states made marijuana legal for adults. In July 2026, 54 of every 100 adults told Gallup pollsters that they drink, the lowest share since Gallup began asking in 1939. About 9 of every 100 adults smoked cigarettes in 2025, by the CDC's count.

### Overdose deaths, 1999 to 2026

CDC scientists describe the opioid deaths as coming in three waves. The first wave began in 1999, after doctors wrote more and more prescriptions for opioid pills in the 1990s. Deaths from heroin rose from 2010. From 2013, deaths rose from opioids made in labs, mostly fentanyl made and sold outside the law.

**The death rate.** About 6 of every 100,000 Americans died of a drug overdose in 1999, by the CDC's count. The rate rose to about 33 of every 100,000 in 2022 and fell to about 23 in 2024.

**The counts.** Overdose deaths from all drugs rose to a peak in 2022 and then fell. CDC scientists give two kinds of count. The final count for a year is published about a year later. The early count is published within months, and the scientists warn that it is often incomplete.

By the final count, overdoses killed 107,941 Americans in 2022, about 300 a day, and opioids were involved in about three of every four of those deaths. The final count for 2024 was 79,384. The early count for the 12 months ending in April 2026 is 66,937.

**Who dies.** Some groups die at far higher rates than others. American Indian and Alaska Native people died of overdoses at a rate of 51.6 of every 100,000 in 2024, by the CDC's count. The rate was 33.8 for Black Americans and 24.7 for white Americans. By age, people aged 35 to 44 died at the highest rate, 44.2 of every 100,000.

### Fentanyl

Fentanyl is an opioid made in a lab. By the CDC's count, it is 50 to 100 times stronger than morphine. Too much of it slows a person's breathing until the breathing stops. A drug called naloxone can undo the overdose and save the person if someone gives it fast enough. Officials of the Food and Drug Administration (FDA) approved a naloxone spray for the nose that anyone can buy without a doctor's order on March 29, 2023.

**The rise and fall.** Deaths from fentanyl and similar lab-made opioids rose from 1 of every 100,000 Americans in 2013 to 22.7 in 2022, by the CDC's count. In 2024 the rate fell to 14.3.

**Who makes it.** Most of the illegal fentanyl sold in the United States has come from Mexico since about 2019. A 2025 report by the Congressional Research Service, which studies problems for members of Congress, names the makers. Mexican crime groups called cartels, especially the Sinaloa Cartel and the Jalisco New Generation Cartel, make it outside the law. Companies in China are the largest source of the chemicals they need. The cartels' members use machines to press fentanyl into fake pills made to look like real medicine.

### Why no Sackler went to prison

No member of the Sackler family has gone to prison. When Judge Madeline Cox Arleo sentenced Purdue Pharma in 2026, she said she could not send its leaders or owners to prison because Justice Department lawyers had charged only the company.

**The first guilty plea.** Purdue Pharma pleaded guilty in May 2007 to misleading the public about OxyContin. The company admitted that it had sold OxyContin as less addictive and less likely to be abused than other painkillers. It paid $600 million. Three of its leaders also pleaded guilty: its president, Michael Friedman, its top lawyer, Howard Udell, and its former chief medical officer, Paul Goldenheim. Together they paid $34.5 million. In 2009 Purdue changed OxyContin into a form that was harder to crush and snort or inject.

**Bankruptcy.** Purdue filed for bankruptcy, a court process for a business that cannot pay its debts, on September 15, 2019. Purdue hired a firm called AlixPartners to check the company's money records. In December 2019 the firm reported that members of the Sackler family had taken $10.7 billion out of the company after lawsuits and investigations began.

**The second guilty plea.** Purdue pleaded guilty to three federal crimes on November 24, 2020. One was a plot to cheat the United States. The other two were plots to pay doctors and others to push its pills. In that case, no company leader and no Sackler was charged.

**The settlement.** Five justices of the Supreme Court threw out a bankruptcy plan on June 27, 2024, because it would have protected the Sacklers from lawsuits. A year later, on June 16, 2025, 55 attorneys general, the top lawyers of states, agreed to a $7.4 billion settlement with Purdue and the Sacklers, a deal that ended lawsuits in return for money.

**The sentence.** Judge Arleo, in Newark, New Jersey, sentenced Purdue to $5.5 billion in fines and penalties for its 2020 guilty plea on April 28, 2026. For nearly seven hours she heard from people harmed by the crisis. More than 40 spoke in court, and more than 200 sent letters.

Ed Bisch's son Eddie died of an overdose in 2001. "Punishment by a fine means 'legal for a price,'" Bisch said. Alexis Pleus said her son Jeff had first been prescribed OxyContin for a football injury, before he died of an overdose. "We still deserve justice, and this isn't it," she said. "Your government failed you," Arleo told the families.

**Who gets the money.** Most of the $5.5 billion in fines and penalties will never be paid. Federal officials collect $225 million of it. Purdue's other money goes to the states and towns it owes, as part of the $7.4 billion settlement. Purdue and the Sacklers pay the settlement over 15 years, to fund treatment, prevention and recovery. It includes $865 million for people harmed one by one. Many victims said they could not qualify because they could not find their old prescription records.

**Purdue shuts down.** New York Attorney General Letitia James announced three days after the sentence, on May 1, 2026, that Purdue had shut down. A new company, Knoa Pharma, owned by a charity, took over. As part of the $7.4 billion, the Sacklers must pay $2.9 billion by 2029, and none of them may sell opioids in the United States. The Sackler family has always said it did nothing wrong.

**Other companies.** The three largest companies that ship drugs to pharmacies, McKesson, Cardinal Health and AmerisourceBergen, agreed in 2021 to pay up to $21 billion over 18 years. The drug maker Johnson & Johnson agreed to pay up to $5 billion. In 2022 the drug makers Teva and Allergan and the pharmacy chains CVS, Walgreens and Walmart agreed to pay up to about $18.5 billion more among them. Under the settlements, states and towns must spend at least 85 of every 100 dollars they get on the overdose crisis.

### Nan Goldin

> **Who:** A photographer who became addicted to OxyContin after surgery, overdosed on fentanyl, went through treatment, and led protests against the Sackler family.
>
> **When and where:** Berlin and New York, the 2010s to 2021.
>
> **Movie:** *All the Beauty and the Bloodshed* (2022), a documentary by Laura Poitras about Goldin's life and her protests.

**She threw OxyContin bottles into a museum's temple pool.**

**Addicted.** Nan Goldin is a photographer known for her book of photographs *The Ballad of Sexual Dependency* (1986). A doctor in Berlin prescribed OxyContin for her after surgery on her wrist. "Though I took it as directed I got addicted overnight," she wrote in the magazine *Artforum* in January 2018. "I went from three pills a day, as prescribed, to eighteen."

**The overdose.** When her doctors stopped prescribing it, she bought pills from a dealer in New York. "When I ran out of money for Oxy I copped dope," she wrote, which means she bought illegal drugs from dealers. "I ended up snorting fentanyl and I overdosed." She waited a year before she went into treatment, because she was afraid of withdrawal, the sickness that comes when the body loses a drug it depends on. Then she spent two and a half months in treatment.

**The protest.** Goldin started a group called P.A.I.N., which stands for Prescription Addiction Intervention Now, in 2018. On March 10, 2018, she and other members protested in the Sackler Wing of the Metropolitan Museum of Art in New York. They threw pill bottles labeled OxyContin into the pool around the Temple of Dendur, an Egyptian temple about 2,000 years old that stands in the wing. Then they lay on the floor and chanted, "Sacklers lie, people die."

**The names come down.** Officials at the National Portrait Gallery in London turned down a £1 million gift from the Sacklers in 2019, after Goldin threatened to pull her show. Leaders of the Tate galleries in London said they would take no more Sackler gifts. Officials of the Metropolitan Museum and members of the Sackler families announced on December 9, 2021, that seven of the museum's spaces would no longer carry the Sackler name.

### Marijuana becomes legal in 24 states

Voters in Colorado and Washington made marijuana legal for adults on November 6, 2012, the first two states to do so. Washington's law took effect first, on December 6, 2012. In 2018 Vermont's lawmakers became the first to make it legal without a vote of the public.

**The count.** By the count of the National Conference of State Legislatures, a group that serves state lawmakers, 24 states and the District of Columbia allow adults to use marijuana. The group's page was last updated in September 2026.

The 24 states are Alaska, Arizona, California, Colorado, Connecticut, Delaware, Illinois, Maine, Maryland, Massachusetts, Michigan, Minnesota, Missouri, Montana, Nevada, New Jersey, New Mexico, New York, Ohio, Oregon, Rhode Island, Vermont, Virginia and Washington. By the same count, 41 states allow marijuana as medicine. In November 2024, voters in Florida, North Dakota and South Dakota voted against making it legal.

**Federal law.** Under federal law, marijuana was still on Schedule I, the list for drugs with a high risk of abuse and no accepted use as medicine. President Donald Trump ordered officials on December 18, 2025, to speed up moving it to Schedule III, a list of drugs that doctors may order as medicine.

The Acting Attorney General moved marijuana sold under state medical licenses to Schedule III on April 28, 2026. All other marijuana stayed on Schedule I. In June 2026 officials of the Drug Enforcement Administration began hearings on moving the rest. As of late September 2026, they had not decided.

**Crack sentences.** Punishments for crack also changed. President Barack Obama signed the Fair Sentencing Act, written by Senator Dick Durbin, in 2010. Under it, the difference between crack and powder cocaine sentences dropped from 100 to 1 to 18 to 1. Under the First Step Act, which President Trump signed in 2018, the change also covered people already in prison. In its first year, more than 2,000 federal prisoners had their sentences shortened.

### Vaping and smoking

An e-cigarette heats a liquid, usually one with nicotine in it, into a mist that the user breathes in. Using one is called vaping. About 27.5 of every 100 high school students vaped in 2019, by the count of a national survey released by the CDC.

**The lung injuries.** A lung injury from vaping put 2,807 people in the hospital or killed them in 2019 and early 2020, by the CDC's count. Of them, 68 died. CDC scientists found that vitamin E acetate, a chemical added to illegal marijuana vaping liquids, was strongly linked to the injuries. They linked most cases to those liquids, which most of the sick people had bought from friends, family or dealers. The records do not name who made them.

**Age 21.** President Trump signed a law on December 20, 2019, that raised the age to buy any tobacco product, including e-cigarettes, from 18 to 21. By 2024 the share of high school students who vaped had fallen to 7.8 of every 100, by the CDC's count. The newest survey, released by the FDA in June 2026, counted middle school and high school students together: 5.2 of every 100 of them vaped in 2025.

**Cigarettes.** About 9.1 of every 100 adults smoked cigarettes in 2025, by the CDC's count, against 42.4 in 1965. Smoking and secondhand smoke, the smoke other people breathe in, still kill more than 480,000 Americans a year, by the CDC's newest count, from 2024.

### Drinking today

Americans aged 14 and over drank an average of 2.48 gallons of pure alcohol each in 2023, by the count of the National Institute on Alcohol Abuse and Alcoholism. That is below the peak of 2.76 gallons in 1981. Americans now drink more liquor and less beer than in 2000. Pure alcohol from beer fell from 1.23 gallons a person in 2000 to 0.99 in 2023, and pure alcohol from liquor rose from 0.64 gallons to 1.08.

**Fewer drinkers.** Gallup pollsters asked adults about drinking in July 2026, and 54 of every 100 said they drink, the lowest share since Gallup began asking in 1939. In 2023 the figure was 62. In the same 2026 poll, 51 of every 100 adults said that one or two drinks a day is bad for health.

**The harm.** The CDC counts about 178,000 deaths a year from drinking too much, from data for 2020 and 2021. On average, each of those people lost 24 years of life. Surgeon General Vivek Murthy reported on January 3, 2025, that alcohol causes about 100,000 cases of cancer and 20,000 cancer deaths a year in the United States. He asked Congress to put a cancer warning on alcohol labels.

Federal health officials dropped their old advice in January 2026, which had been to drink no more than one drink a day for women and two for men. The new advice says only, "Consume less alcohol for better health."

**Young people and AA.** About 41 of every 100 high school seniors said in 2025 that they had drunk alcohol in the past year, by the count of the Monitoring the Future survey. Alcoholics Anonymous estimates that it has more than two million members in more than 123,000 groups around the world.

**The three questions, answered**

- How long have people here used tobacco, and what did they use it for? For at least 12,300 years, since the fire at the Wishbone site. Native people offered it in prayer, burning it or smoking it in pipes, and the Algonquian people at Roanoke smoked it to keep the body healthy.
- What happened when the whole country banned alcohol from 1920 to 1933? Drinking fell at first to about 30 percent of what it had been, then rose to about 60 to 70 percent. Treasury officials had more poison added to factory alcohol, and the poison killed thousands of drinkers before delegates in Utah ended the ban on December 5, 1933.
- Who has been punished for drugs, and who has not? Robert Coles with his red D, the laborer Samuel Caldwell with four years of hard labor, Billie Holiday handcuffed to her hospital bed, and the people sentenced for crack, 91 of every 100 of them Black in 1992, were all punished. Harry Gross never served his jail sentence, and no member of the Sackler family has been charged with a crime.

**What changed:** Tobacco went from an offering in prayer to a habit that kills more than 480,000 Americans a year, and opium, cocaine and liquor went from open sale in the 1800s to bans in the 1900s, with liquor made legal again in 1933.

**Five dates to keep**

- 1634: Massachusetts judges order Robert Coles to wear a red D for a year.
- February 13, 1826: Reformers in Boston found the American Temperance Society.
- January 17, 1920: National Prohibition begins.
- June 17, 1971: President Nixon calls drug abuse "public enemy number one."
- 1996: Purdue Pharma begins selling OxyContin.

**Not known:** The number of people killed by poisoned alcohol during Prohibition is not known, and the estimates run from more than 5,000 to at least 10,000.

**Where to go:** The Temple of Dendur stands in the Metropolitan Museum of Art in New York, in the wing where Nan Goldin's group threw pill bottles into the pool in 2018 and that no longer carries the Sackler name.

**Next:** Chapter 29, Religion. It follows the many faiths of this land and the fight for the freedom to worship.
