# Chapter 21: Crime, Police, and Justice

**Chapter 21 of 37 · Crime, Police, and Justice · 10 eras · about 140 minutes**

**Americans stopped whipping and branding people in public and started locking them in prisons, and from the first colonial courts on, whether a person got a fair trial depended on who that person was.**

Clarence Earl Gideon sat in the Florida state prison at Raiford in 1961, with a five-year sentence for a break-in at a pool hall. He was 50 and had no money for a lawyer. Florida gave free lawyers only to people who could be sentenced to death, so the judge had refused him one. Gideon wrote to the US Supreme Court in pencil. In 1963 all nine justices agreed that a state must give a lawyer to a poor person charged with a serious crime. At his second trial, the jury found him not guilty after an hour.

This chapter follows crime and punishment in order, from the clan laws of the Cherokee to the police killings and trials of the 2020s. In the 1600s judges had people whipped, branded and hanged in front of their neighbors. By 2009 about 1.6 million people were locked inside American prisons. The people who kept order changed too: settlers took turns on a night watch, then cities hired police, then the national government hired agents. Thousands of people got no trial at all. Mobs burned, hanged and shot them, and for most of those killings nobody was ever punished.

**Three questions this chapter answers**

- How did punishment move from the whipping post to the prison cell?
- Who kept order before there were police?
- What happened to the people in mobs who killed without a trial?

**Five minutes?** Read "From street work to the cell, Philadelphia" in 1750 to 1800, then "Francis McIntosh, St. Louis, 1836" in 1800 to 1850.

**Can skip:** "Counterfeiting was a hanging crime", "A cabinet member convicted, 1929", "Leaders in court", "Whose courts: McGirt, 2020". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 4 minutes**

When one person killed another, the families of the two people settled it between them, and a life was owed for a life. No nation north of Mexico kept its laws in writing. Among the Cherokee, the dead person's clan had the duty to take a life from the killer's side. In accounts of other nations, the killer's relatives had the duty to give up a life in exchange. Some families took a payment instead: furs, other goods, or wampum, strings or belts of beads made from shells.

**Known:** The rules, which the nations remembered and later wrote down. Some come from the nations' own spoken traditions, and some from accounts by Native and European writers after about 1600.

**Not known:** The name of any person tried or punished before 1500. No written record names one.

### The Cherokee law of blood

Among the Cherokee, a killing was settled between two clans. A clan is a large family group. The Cherokee had seven clans, among them the Wolf, the Deer and the Paint, and a child belonged to the mother's clan.

**What the nation's newspaper said.** The editors of the *Cherokee Phoenix*, the Cherokee Nation's own newspaper, printed an article on the old rules in 1829. The article states that the Cherokee "as a nation, had nothing to do with murder." The nation's leaders did not punish a killing. The clans did. The clan of the dead person had the duty to take revenge by killing the killer.

If the killer ran away, his brother or his nearest relative "was liable to suffer in his stead," in the article's words. The clan could kill the brother or the relative in the killer's place. Every killing counted as murder, so a person who killed someone by accident could be killed in return. A man who killed his own brother answered to no law and no clan.

The same article states that about twenty years before 1829, the Cherokee clans met in a council, a large meeting to decide the nation's business, and ended these rules. The Cherokee Nation dates that council to 1810. From then on, murder was a crime against the Cherokee government.

### Words of comfort instead of revenge

The Haudenosaunee are five nations in what is now New York: the Mohawk, Oneida, Onondaga, Cayuga and Seneca. Their own tradition says the five nations were once caught in feuds, long runs of killings in which each side took revenge for the last death.

In that tradition, a man named Hiawatha, whose daughters had been murdered, strung shells into wampum. He used the strings to speak words of comfort instead of words of revenge. These words of condolence, comfort for people in grief, became central to the Great Law of Peace, and the five nations joined together under it.

The Haudenosaunee told the Great Law aloud for generations. Two written versions existed by 1910 at Six Nations of the Grand River, a Haudenosaunee community in Ontario. Seth Newhouse, a Mohawk, wrote one, and the chiefs of that community wrote the other. Arthur C. Parker printed them in English in 1916, for the New York State Museum.

**What the written law did to a murderer.** In that version, a chief who committed murder lost his title, and the other chiefs removed him. A war chief then ordered him to leave the land of the five nations and never come back.

An outsider adopted into one of the nations got a warning from a war chief for a first wrong. After a second wrong, the written law says, the person was to be sent out of the land of the five nations for good.

### Forgiveness at the Green Corn

Once a year, the people of each Muscogee town forgave every crime except murder. The Muscogee, also called the Creek, and other nations of the Southeast did this at the Green Corn Ceremony, held each midsummer when the first corn ripened. Its Muscogee name, the busk, comes from their word for "to fast." People fasted, and they lit the sacred fire again in the town square.

The trader James Adair wrote about the ceremony in the middle 1700s. So did the naturalist William Bartram, who studied plants and animals, and Benjamin Hawkins, a government agent, an official sent to deal with a Native nation. The most detailed descriptions were written in the late 1800s and early 1900s.

## The 1500s

**Era 2 of 10 · The 1500s · about 4 minutes**

The only European courts in this land sat at a few Spanish outposts, and there the same officials governed the settlers, commanded the soldiers and judged the cases. Spanish settlers founded St. Augustine, in Florida, in 1565. Juan de Oñate led a Spanish colony into New Mexico in 1598. Everywhere else, the Native nations kept their own laws. The two men who led those colonies, Pedro Menéndez de Avilés and Oñate, each decided what happened to hundreds of prisoners.

In a Spanish town, an official called an alcalde acted as the judge. His power covered smaller crimes and quarrels, but in practice he heard most of the cases in his area. A person who lost could appeal, asking a higher judge or the governor himself to change the decision.

### Killed without a trial, 1565

The Spanish commander Pedro Menéndez de Avilés had French Protestants killed after they surrendered to him, in September and October of 1565. Protestants are Christians outside the Catholic Church. The men had no trial.

**The count.** The National Park Service's handbook for Fort Matanzas lists 111 men killed the first time and 134 the second, about 245 in all, with 16 spared each time. Chuck Meide, speaking on the PBS program *Secrets of the Dead*, gives wider ranges for the two killings, from 110 to 200 and from 70 to 150.

### The Acoma trial, 1599

Juan de Oñate, the leader of the Spanish colony in New Mexico, put about 500 Acoma people on trial in February 1599. He had ordered the attack on their town a month before, and he sat as their judge.

The trial followed a fight at Acoma Pueblo, the Acoma people's town. Spanish soldiers under Juan de Zaldívar came to Acoma in December 1598 and demanded food. Acoma people killed Zaldívar and eleven or twelve of his soldiers. The Acoma people's own account says the soldiers had also raped an Acoma woman, which means they forced her into sex.

Oñate opened an inquiry on December 28, an official hearing to find out what had happened. He asked the Franciscan friars with the colony, Catholic religious brothers, whether a war on Acoma would be just, meaning right and fair. They said yes. In January 1599 Oñate sent Juan de Zaldívar's brother, Vicente de Zaldívar, with about 70 soldiers against Acoma. His soldiers broke into the town, killed Acoma men, women and children, and burned it.

**The count of the dead.** The counts differ. New Mexico's state historian gives about 600. The Pueblo leaders of the All Pueblo Council of Governors give 800, and a National Park Service page gives about 1,500.

The trial of the captives began on February 9, 1599, and lasted three days. Oñate named a defender for the prisoners, and the defender asked for mercy. Acoma witnesses said many of their people had been working in their fields during the first fight. They said that "some wanted to surrender but some refused, and so they fought."

**The sentences.** Oñate gave his sentence on February 12. He sentenced no one to death. Every man over 25 was to have one foot cut off and to be made a slave for twenty years, forced to work for Spanish colonists with no pay and no right to leave. Boys and young men from 12 to 25, and women and girls over 12, were also to be made slaves for twenty years.

Oñate sentenced the old people to be handed over as slaves to the Plains Apache. Two Hopi men, from a different people, had been captured in the fighting. Oñate sentenced each of them to have his right hand cut off and to be sent home to carry word of the punishment to his own people.

**The children.** Oñate declared the Acoma children under 12 innocent. He still ordered them taken from their families and handed to the friars. A National Park Service page states that about 70 girls were sent to convents in Mexico, houses where nuns live, and that in all probability none of them ever came home. The PBS program *POV* states that some scholars believe the children were later sold as slaves. The Pueblo leaders of the All Pueblo Council of Governors give the number of children taken as 60.

**The feet.** The Spanish record states the order, the ages of the prisoners, the twenty-year terms and the taking of the children, and on those points the accounts agree. It states Oñate's order to cut off a foot. It does not say how the cutting was to be done, or whether it was done to each man.

The Acoma people's own history says that 24 men had a foot cut off, and reporters for the Associated Press and NPR give the same number. The historian Marc Simmons first wrote that the feet were cut off, and he later came to doubt it. The historian John L. Kessell doubts it too. He wrote that "the historical record makes no mention of a one-footed Acoma slave."

## The 1600s

**Era 3 of 10 · The 1600s · about 16 minutes**

Judges in the English colonies punished crime on the body and in public. They ordered whippings, brandings and cut-off ears, and they sent people to sit in the stocks where their neighbors could see them. Ordinary settlers in Massachusetts Bay took turns walking a watch to keep order at night. A jail held people waiting for a trial or a punishment, people who had done small wrongs, and people who owed money. Locking people in a prison for years as the punishment itself did not begin until the 1790s.

Colonial judges in Massachusetts Bay and Plymouth also tried Native people who lived near the colonists. Virginia's lawmakers passed a law in 1669 under which a master who beat an enslaved person to death, after the person resisted him, was not charged with a crime. Judges in Massachusetts had 19 people hanged for witchcraft in 1692.

### Jamestown under martial law, 1610 to 1619

The leaders of the Jamestown colony in Virginia ruled it under martial law, rule by army officers instead of by ordinary courts, from 1610 to 1619. Jamestown stood in Tsenacomoco, the land of the Powhatan people.

Two of the colony's leaders issued the first orders in May and June of 1610, and Sir Thomas Dale added military rules on June 22, 1611. William Strachey printed the whole set in 1612 as the *Lawes Divine, Morall and Martiall*. Rule under these laws ended when Sir George Yeardley arrived in Virginia on April 18, 1619.

**The death crimes.** The historian Brent Tarter lists the punishments in the *Encyclopedia Virginia*. The punishment was death for murder, for robbery and for blasphemy, insulting God. It was also death to speak treason, words against the king's rule, to speak against the company that ran the colony, or to trade with Indians without permission.

The printed laws of 1612 also specify death for any man who would "ravish or force any woman, maid or Indian," which means rape. They specify death for "the horrible, and detestable sins of Sodomie" too, and they do not say which acts that word covered.

**The whipping crimes.** The punishment was a whipping for gambling, for missing church, for sex between two unmarried people, for killing farm animals without need, and for stealing crops or farm tools.

The sources disagree about adultery, sex between a married person and someone outside the marriage. The printed laws themselves specify death for it, and Tarter lists it among the whipping crimes.

**What George Percy wrote.** The colonist George Percy wrote an account of the colony's early years in 1625. He wrote about the building of a fort at Henricus in 1611, and about colonists there who ran away to live with the Native people nearby. When they were caught, Dale had them put to death: "Some he apointed to be hanged some burned some to be broken upon wheles others to be Staked and some to be shott to deathe." Percy wrote that Dale did these things "To terrefy the reste," meaning to frighten the other colonists.

Breaking on the wheel was a way of putting a person to death in Europe. The executioner broke the person's arms and legs with a heavy bar or club and tied the body to a large wooden wheel. Percy does not describe how it was done at Jamestown, and he does not explain what "Staked" meant.

Percy also wrote that Dale had men who robbed the colony's storehouse tied to trees and left there until they starved to death. Percy wrote his account partly to defend his own record in Virginia.

### Oñate convicted, 1614

Juan de Oñate was the leader who had sentenced the Acoma people in 1599. Spanish officials later put him on trial in Mexico City for what he had done in New Mexico. They charged him with 30 crimes in 1612 or 1613. They found him guilty of 12 in 1614. Among them were using too much force against the Acoma and hanging two Indians without cause.

The officials banished Oñate from New Mexico for life, ordering him to leave and never return. They also barred him from Mexico City for four or five years and fined him 6,000 ducats, which were Spanish coins. Whether he was later pardoned, officially forgiven and freed from the punishment, is not settled. No record shows that any Acoma person was asked to testify.

### The watch and the whipping post in Massachusetts

The court records of the Massachusetts Bay Colony from the early 1630s show who kept order and how the colony's judges punished people. The colonists had settled among the Massachusett people and the Pawtucket, who belonged to a larger group of nations led by Massachusett sachems, or leaders.

From the colony's first year, its judges tried Native people who lived near the colonists. They fined the Massachusett sachem Chickatabut one beaver skin in 1631 for shooting a pig that belonged to Sir Richard Saltonstall. Governor John Winthrop wrote in his journal that Chickatabut paid it right away.

**The watch.** The settlers themselves kept watch at night. On April 12, 1631, the judges ordered a watch of four men every night at Dorchester and four more at Watertown, "to begin att sunsett." Anyone who fired a gun after the watch was set had to pay a fine of 40 shillings, which was English money, or be whipped. In July the judges ordered a watch of six men and an officer every night at Boston.

The watchmen were settlers taking turns, and some of them did not take their turn. The judges fined Daniel Abbott "for refuseing to watch" and Richard Norman for "negligence in watching."

**The whipping post.** Whipping meant being struck on the bare back with a whip, often at a post in a public place. Bartholomew Hill got a whipping for stealing a loaf of bread from John Hoskins, and John Baker got one for shooting at birds on the Sabbath, the day of rest and worship.

John Goulworth confessed to a felony, a serious crime, and the judges had him whipped and then set in the stocks. The stocks were a wooden board with holes that locked a person's ankles while the person sat in a public place. For helping in a crime, John Boggust and John Pickryn had to sit in the stocks at Salem for four hours.

The pillory was a wooden frame on a post, set on a platform in a public place. It locked a person's neck and wrists while the person stood. Britannica's account for students states that it was meant to expose people to "public scorn and ridicule," and to cause "bodily discomfort," meaning the body ached from standing locked in place.

The bilboes were iron rings locked around the ankles and joined to a bar, so the person could not walk away. Edward Seale, punished for drunkenness, sat in the bilboes until the court day ended, "& then to bee severely whiped."

**The branding iron.** Richard Hopkins sold guns, powder and shot to Indians. The court sentenced him in September 1632 to be whipped and "branded with a hott iron on one of his cheekes." Branding meant pressing a red-hot iron into the skin. It burned a mark into the flesh that stayed for life. Robert Scarlett, "a knowen theife," got a whipping in 1635 and the letter T, for thief, branded on his forehead. Then his master, Benjamin Felton, had to send him out of the colony.

Officers of the colony also cut off ears. Three Quakers, members of a Christian group also called the Society of Friends, were held in the Boston prison in September 1658: Christopher Holder, John Copeland and John Rous. Their sentence stated that each man's right ear was to be "cut off by the Hangman."

On September 16 the deputy of the marshal, the colony's officer who carried out the court's orders, came to the prison with a group of men and shut the door. They cut off the right ear of each of the three men. George Bishop, a Quaker, recorded it in his book *New England Judged* in 1661.

**Not known:** How many strokes any of these whippings had, which of the deputy's men cut off the Quakers' ears, and with what tool.

### Philip Ratcliffe

> **Who:** A servant whose ears were cut off for speaking against the Massachusetts government and the church at Salem.
>
> **When and where:** Boston, June 1631.

**Whipped, ears cut off, fined 40 pounds and banished, for words.**

The judges of the Massachusetts Bay court at Boston sentenced Philip Ratcliffe on June 14, 1631. Their order states that he "shalbe whipped, haue his eares cutt of, fyned 40£, & banished." In today's spelling, he was to be whipped, have his ears cut off, pay a fine of 40 pounds, and leave the colony for good. Governor John Winthrop's journal calls him a servant of a Mr. Cradock.

His crime was "vttering mallitious & scandulous speeches against the govmt & the church of Salem." He had said hateful and shameful things about the colony's government and about the church at Salem. The record says what he said was "proved vpon oath," which means people swore in court that he said it.

Winthrop wrote in his journal that the sentence "was presently executed," which in his day meant it was carried out right away. Neither the court record nor Winthrop says who cut off Ratcliffe's ears, or how. The same judges that day ordered Philip Swaddon whipped for running away from his master, Robert Seely, to go to Virginia.

### When killing an enslaved person was no crime, 1669

The members of Virginia's assembly, the colony's lawmakers, passed "An act about the casuall killing of slaves" in October 1669, while Sir William Berkeley was governor. An enslaved person was a person owned by another person as property and forced to work for no pay.

Under the act, if an enslaved person resisted and died under "correction" by the master, or by someone the master sent, the death "shall not be accompted felony." Correction meant a beating. Under this law, a master who beat an enslaved person to death, after the person resisted him, was not charged with any crime.

The lawmakers gave their reason in the act. They wrote that no one would kill on purpose when the enslaved person was his own "estate," meaning his property. The act is printed in William Waller Hening's collection of Virginia's old laws, the *Statutes at Large*.

### A murder trial at Plymouth, 1675

The judges of Plymouth Colony tried three Wampanoag men in 1675 for killing another Native man, John Sassamon. Plymouth stood in the country of the Wampanoag. Sassamon, a Christian, had reportedly warned Plymouth's governor that men of the Wampanoag leader Metacom, whom the English called Philip, were planning an attack. Sassamon died at Assawompset Pond on January 29, 1675.

In March the judges ordered one of the three, a man named Tobias, to answer questions about the death. Three men put up their land, worth 100 pounds, as a promise that Tobias would come back to court in June: Tobias himself, a sachem named Tuspaquin, and Tuspaquin's son William.

In June the judges tried Tobias, Tobias's son Wampapaquan and a third man, Mattashunannamo, for Sassamon's murder. The charge stated that they had struck him or twisted his neck until he died, then pushed his body through a hole in the ice of the pond. The three men said they were innocent.

The jury was twelve English colonists. The judges added six Native men to advise the jury. The six had not taken the jurors' oath, but the record states that they "fully concurred," meaning they agreed with the verdict. The jury found all three men guilty, and the judges sentenced them to hang.

Plymouth officials hanged Tobias and Mattashunannamo on June 8, 1675. The judges put off Wampapaquan's hanging for a month. Within that month he was shot to death, and the colony's court record does not say who shot him. Later that June, Metacom's men and the English colonists went to war, starting at Swansea. The English called it King Philip's War.

### Salem, 1692

English settlers built Salem on Naumkeag, a home of the Pawtucket people. A plague brought by English traders killed many of the Pawtucket between 1616 and 1619, the City of Salem's tourism office states.

Colonial judges in Massachusetts tried people for witchcraft, using the Devil's power to hurt others, in 1692 and 1693. Accusers named more than 200 people, Smithsonian magazine reports. The judges had 19 of them hanged, and Sheriff George Corwin carried out the hangings. Corwin also had one man pressed to death under stones. At least five more accused people died in jail.

The first accusers were three girls in Salem Village: Betty Parris, who was 9, Abigail Williams, 11, and Ann Putnam Jr., about 12. They said three women were hurting them by witchcraft: Tituba, a woman enslaved in the house of the minister Samuel Parris, and Sarah Good and Sarah Osborn.

The magistrates, or local judges, John Hathorne and Jonathan Corwin questioned the three women on March 1, 1692. Tituba denied it. The magistrates kept at her with questions again and again, and then she confessed. Members of the Putnam family later made accusations in dozens of cases.

**The special court.** Governor William Phips set up a special court to try the accused on May 27, 1692. It was called a Court of Oyer and Terminer, words that mean "to hear and to decide," and William Stoughton was its chief judge.

The judges accepted spectral evidence: an accuser's word that the spirit of the accused person had come to her in a dream or a vision and hurt her. Only the accuser could say what she had seen. Stoughton was sure such evidence could be used. The minister Increase Mather wrote: "It were better that ten suspected witches should escape than one innocent person be condemned."

**Pressed to death.** Giles Corey refused to plead guilty or not guilty. Accounts give his age as 71 or 81. Under English law, a court could force a plea by pressing. The prisoner lay on the ground under a wooden board, and officers piled heavier and heavier stones on it until the prisoner answered or died.

Sheriff Corwin made Corey strip naked and lie face up on the ground. Then Corwin placed large rocks on the board one at a time. The pressing went on for two days, and Corey died on the third, September 19, 1692. Because he was never convicted, his children could keep his land under the law. The Massachusetts Historical Society gives that as his reason for refusing to plead.

**A child in the jail.** Sarah Good's daughter Dorothy was a small child when the magistrates had her jailed with her mother in March 1692. The warrant, the written order for her arrest, calls her four years old. Her father later said four or five, and one archive says six.

Her father, William Good, wrote in 1710 that she was kept in prison seven or eight months and "chain'd in the dungeon." He wrote that she was "so hardly used and terrifyed," meaning treated so harshly and frightened so badly, and that she had been a heavy cost to care for ever since. Sarah Good gave birth in jail, and her baby died there. Sarah Good was hanged on July 19, 1692.

Phips shut the special court in October 1692, after accusers named his own wife. The judges of the new court that replaced it would not allow spectral evidence, and they condemned 3 of 56 defendants. Phips had pardoned everyone still held by May 1693. The governor and lawmakers of Massachusetts passed an act in October 1711 that cancelled the convictions of many of the condemned, and they granted 600 pounds to the heirs. The state's lawmakers made a formal apology in 1957.

### Rebecca Nurse

> **Who:** A member of the Salem church whom a jury found not guilty of witchcraft, and who was then convicted and hanged.
>
> **When and where:** Salem, Massachusetts, March to July 1692.

**A jury found her not guilty, and the judges sent it back.**

Edward and Jonathan Putnam filed a complaint against Rebecca Nurse on March 23, 1692. They said she had hurt Ann Putnam Sr., Ann Putnam Jr. and Abigail Williams by witchcraft. Marshal George Herrick arrested her the next day, on a warrant signed by the magistrates John Hathorne and Jonathan Corwin. She had been sick for eight or nine days and could not leave the house.

At her questioning on March 24 she said, "I am as clear as the child unborn." When she moved her hands, the record states, the accusers fell into fits. Thirty-nine of her neighbors signed a statement that they had never had "Any: cause or grounds to suspect her."

Women searched her body for a mark of the Devil. The most experienced of them found nothing that could not come from a natural cause. On June 28 Nurse asked the court in a petition, a written request, for other women to examine her again, two of them midwives, women who help other women give birth. She signed the petition with her mark, because she could not write her name.

At her trial the jury found her not guilty. The judges objected. They pointed to something she had said about two other accused women, Goodwife Hobbs and her daughter: "they used to come among us." Goodwife was the title for a married woman, like "Mrs." today.

The jury went out again. Back in court Nurse did not answer, and one juror, Thomas Fisk, took her silence as evidence against her. The jury then found her guilty. Afterward she explained that she had meant the two women were fellow prisoners. She wrote that she was "something hard of hearing, and full of grief," and that no one had told her how the court took her words.

Governor Phips pardoned her. Several men from Salem then persuaded him to take the pardon back. On July 3 the minister Nicholas Noyes led the members of the Salem church in putting her out of the church, "by unanimous vote," which is called excommunication. Sheriff George Corwin had her hanged on July 19, 1692. Her house in Danvers still stands. Her case file, number 94, is in the University of Virginia's *Salem Witch Trials Documentary Archive*.

**If you remember one thing:** Colonial judges punished crime by hurting people where their neighbors could watch: they had people whipped, branded and hanged, and had their ears cut off.

- 1610: Jamestown's leaders put the colony under martial law, with death for murder, robbery and speaking against the company.
- 1669: Virginia's lawmakers wrote that a master who beat a resisting enslaved person to death had committed no felony.
- 1692: Massachusetts judges had 19 people hanged for witchcraft, and the sheriff pressed Giles Corey to death.

**Next:** In the next fifty years the colonies set up separate courts and patrols for enslaved people, and British judges shipped tens of thousands of convicts across the ocean.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 8 minutes**

An enslaved person accused of a crime faced a different kind of trial from a free white person. Under a Virginia law of 1723, a panel of local justices tried an enslaved person accused of a crime that carried death, with no jury. A white defendant in New York could turn away up to twenty jurors without giving a reason, and two enslaved men, Quack and Cuffee, went to trial there in 1741 with no lawyer. White men in South Carolina rode on slave patrols from 1704 to watch and control enslaved people.

Free colonists in Virginia took their quarrels over land and debts to a county court of local justices, which met about once a month. A lender could have a person who could not pay a debt locked in jail. British judges also sent about 52,200 convicts across the ocean to work in the colonies.

### The county court and the debtors' jail

Local courts sat in the Virginia settlements by 1622, made up of local judges called commissioners of the peace, later called justices of the peace. The justices usually met once a month. The members of Virginia's assembly named these courts county courts in 1642, and by the end of the colonial years Virginia had 61 counties.

The justices gave out licenses to marry and to keep taverns, recorded deeds and wills, and settled quarrels over land and over debts. A deed is a paper showing who owns land. Emily Salmon, writing in the *Encyclopedia Virginia*, calls serving as a justice "the logical stepping stone" to a seat in the House of Burgesses, Virginia's assembly.

**The debtors' jail.** A jail in these years held people waiting for a trial or a punishment, and people who owed money. From the first colonies until the middle 1800s, a lender could have a person who could not pay a debt locked in jail. Under English law, which the colonists brought with them, the prisoner even paid the cost of being kept there.

Robert C. Voigt, writing in the *Encyclopedia of North Carolina*, explains that jailing a debtor gave the lender "a forceful means" of collecting the money. A person in jail could not work to earn it.

### Convicts shipped from Britain

British judges sent about 52,200 convicts by ship to the American colonies between 1700 and 1775, a punishment called transportation. More than 20,000 of the convicts went to Virginia, and about 80 percent of all of them went to Maryland or Virginia. Emily Jones Salmon gives these numbers in the *Encyclopedia Virginia*.

Members of Parliament, Britain's lawmaking body, passed the Transportation Act in 1718. Under it British officials paid merchants to carry convicts across the ocean, and Jonathan Forward was the first merchant to hold the contract. The convicts were sold as soon as they landed, and Salmon does not name the sellers. Most of them were forced to work for their buyers for seven to fourteen years, mostly in tobacco fields. Others went to tradesmen, shipbuilders and ironworks.

Virginia's lawmakers tried to stop the shipments. They passed a law in 1722 meant to make shipping convicts too expensive. Forward complained, and the members of the Board of Trade, officials in London who watched over the colonies, overturned the law. Benjamin Franklin wrote against the shipments in 1751. The last convict ship reached the James River in Virginia in 1776.

### Slave patrols and courts without juries

White South Carolinians set up official slave patrols in 1704, copying the island colony of Barbados. A slave patrol was a group of white men who rode out to watch and control enslaved people. The patrollers were the same men who served in the militia, the colony's part-time citizen army. At first wealthy men, called gentlemen, rode alongside poorer white farmers. The patrollers were paid for the work from 1734 to 1737.

Enslaved people at Stono, in South Carolina, rebelled against the people who enslaved them in 1739. After that, the members of the South Carolina assembly ordered "constant, regular patrols" in the Negro Act of 1740. Negro was an old word for a Black person. In Charleston, the town's night watch patrolled the streets.

**What a patrol did.** A patrol's route ran 10 to 15 miles. In later years a typical patrol was a few men on horseback. They searched the cabins where enslaved people lived, broke up their gatherings and guarded the roads. The *South Carolina Encyclopedia* states that this patrol system lasted until the end of the Civil War.

**Courts with no jury.** A Virginia law of 1723 states how enslaved people were to be tried for crimes that carried death. Justices named for each case tried the accused person at the county courthouse. They could convict on a confession or on the oath of one witness. All of this was done "without the solemnity of a jury," which means with no jury at all. If they found the person guilty, they ordered the execution. The owner of the accused person could come and speak in the person's defense.

The justices could also convict on the word of Black or Native witnesses if it "shall seem convincing" to them. The law calls these witnesses "Negroes, Mulattos, or Indians," old words for Black people, for people with one Black and one white parent or ancestor, and for Native people.

The same law states a punishment for any Black or Native witness found to have lied. The person's ear was to be nailed to the pillory, and the person was to stand there for an hour. Then the ear was to be cut off. An hour later the other ear was to be nailed and cut off the same way.

Then the person was to get 39 lashes of the whip, "well laid on, on his or her bare back, at the common whipping-post." The justices had this warning read aloud to every such witness.

**Not known:** Who was to carry out this punishment, and how often it was done.

### The New York trials of 1741

New York judges tried about 200 people in 1741 for a plot to burn the city, after a string of fires that began in March. Daniel Horsmanden was one of the three judges. Officials burned 13 Black men at the stake and hanged 17 more. They also hanged four white people, two men and two women. John and Sarah Hughson and Peggy Kerry were hanged on June 12.

Burning at the stake meant chaining a person to an upright post with wood piled around it. Then the wood was set on fire, so the person burned to death.

**The witnesses.** The first witness before the grand jury, a group of citizens who decide whether a person should be charged with a crime, was Mary Burton. She was a 16-year-old servant of the tavern keeper John Hughson. At first she refused to talk. She began to talk as she was being taken to the dungeon at City Hall. Enslaved witnesses named Sandy and Fortune testified after being promised their lives. The grand jury told Sandy that enslaved people who confessed and named others "were certainly pardoned, and shipped off."

Judge Horsmanden questioned suspects himself before he sent them to the grand jury. White defendants had more protection under New York law: each could turn away up to twenty jurors without giving a reason. Quack and Cuffee, two enslaved men, had no lawyer.

Douglas Linder, who wrote an account of the trials for the Famous Trials project at the University of Missouri-Kansas City, writes of "grave questions about the contours of the suspected conspiracy." He means serious doubts about what the supposed plot really was and who was in it.

### Quack and Cuffee

> **Who:** Two enslaved men in New York City who were burned at the stake in the trials of 1741.
>
> **When and where:** New York City, tried and burned in May 1741.

**At the stake, each man was told the other had confessed.**

Quack was enslaved by a painter named Roosevelt, and Cuffee by Adolph Philipse. On May 12 the undersheriff, the sheriff's deputy, put Cuffee in a cell with a white prisoner, Arthur Price. He gave the two men "a tankard of punch now and then," a large cup of a mixed drink, so that Price could draw Cuffee into talking. Price then swore that Cuffee had spoken about the fires.

Attorney General Richard Bradley, the colony's chief lawyer, led the case against the two men. His side called eleven witnesses. Quack and Cuffee had to defend themselves. They called ten witnesses, and most of them said the two men had been somewhere else when the fires started. The men said they were innocent. The jury, Horsmanden wrote, was "soon returned" and found them guilty. Judge Horsmanden sentenced them to be "chained to a stake, and burnt to death" on Saturday, May 30, 1741.

The sheriff brought them to the stake at about three o'clock that afternoon, with piles of wood around them. Horsmanden wrote that the crowd "were very impatient" for the fire. The deputy secretary, a Mr. Moore, and Quack's owner, Mr. Roosevelt, told each man that the other had already confessed. Both men then confessed and named other people.

Moore asked the sheriff to wait while someone asked the governor for a reprieve, an order to put off the burning. The sheriff said he could not take the men back through the crowd without a strong guard. Horsmanden called the governor's answer "conditional and discretionary," meaning it came with conditions and left room for choice. He wrote that "the execution proceeded." He does not name the men who lit the fire.

The names they gave led to more trials. Horsmanden told the story in his own book, *A Journal of the Proceedings*, in 1744.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 11 minutes**

Pennsylvania's lawmakers began to replace the whip and the gallows with the prison cell. Before then, a convict in Pennsylvania could be fined, made to pay back what he took, whipped, branded or hanged. From 1786 he could also be put to hard labor in the streets. The lawmakers turned the Walnut Street Jail in Philadelphia into the country's first state prison in 1790. After that, a judge could send a convict there for years, to work and to spend part of the time alone in a cell.

The rights of accused people were written down too. Lawmakers in enough states approved the Bill of Rights, the first ten additions to the Constitution, in 1791, and four of them list rights for accused people. Not everyone got a trial. Armed settlers in Pennsylvania killed twenty Conestoga people in 1763, and no one was ever charged.

### Counterfeiting was a hanging crime

Colonial paper money carried the warning "To Counterfeit is Death." Counterfeiting means making fake money. Owen Sullivan was an engraver, a person who cuts designs into metal for printing, and he was born in Ireland. He ran gangs that passed fake bills from New England to New York.

The *Boston Evening Post* printed a report from Providence, Rhode Island, on October 9, 1752. It said that Sullivan "has lately had both his Ears crop'd, and been branded on both his Cheeks with the Letter C." Cropping meant cutting off part of the ear, and the C was for counterfeiting. He had been punished for faking Rhode Island's paper money. The newspaper does not name who cut and branded him.

New York judges later convicted him of faking and passing New York's bills, and he was hanged on May 10, 1756.

### The Conestoga killings, 1763

Armed white settlers from Paxton Township and nearby places in Pennsylvania killed all twenty people of the Conestoga town in December 1763. No one was ever charged with the killings. The Conestoga were descendants of the Susquehannock people. Their town stood near Lancaster, on land that the Penn family had set aside for them. The land was supposed to be under the Penn family's protection.

Native nations to the west were at war with the British in 1763, in what is called Pontiac's War. The killers claimed that the unarmed Conestoga were hiding spies for the enemy. The historian Michael Goode calls that charge "a fabrication," which means a lie. Earlier in the war, Lieutenant Governor James Hamilton had offered a reward of 25 pounds for each Native scalp. A scalp is the skin and hair cut away from the top of a person's head.

**The first attack.** Benjamin Franklin wrote about the killings in a pamphlet in 1764. He counted twenty people in the town: seven men, five women and eight children. At daybreak on December 14, 1763, fifty-seven men rode in with guns, short swords and hatchets. They found six people at home, three men, two women and a boy. The men shot them, stabbed them and killed them with hatchets.

Shehaes was a very old man who had been at a treaty meeting with William Penn in 1701. He was in his bed, and they cut him to pieces there. The attackers scalped all six. Then they burned the houses.

**The workhouse.** Lancaster's magistrates put the other fourteen Conestoga people in Lancaster's workhouse, a building where poor people were made to work, to keep them safe. On December 27 about fifty of the Paxton men broke open the workhouse door. Franklin wrote that the families knelt, with the children holding on to their parents, and said they were innocent.

The men killed all fourteen with guns and hatchets, among them children about a year old and babies still nursing. Will Soc was shot at the door. A company of British soldiers stationed nearby did nothing to stop the attack.

Franklin named some of the dead. They included Shehaes, his daughter Peggy, and her husband John Smith, a Cayuga, with their child of about three. They also included Betty and her son Peter, and Sally, whose Native name was Wyanjoy.

Governor John Penn offered a reward for the killers' names. In January 1764, as many as 200 of the Paxton men marched toward Philadelphia. They said they were protesting the government's failure to protect them, and they wanted to reach the Native refugees on Province Island, near the city. They stopped at Germantown when they heard that the city's militia had gathered. Franklin worked out a compromise: the marchers agreed to break up, and their leader, Matthew Smith, was allowed into the city to publish their complaints.

No one ever came forward with the killers' names. A modern introduction to Franklin's pamphlet, published by Miami University, states that no one was ever charged and tried.

### Three trials in Boston, 1770

Judges in Boston heard three murder trials in 1770. One was of a customs informer who had shot a boy. The other two were of a British captain and of eight British soldiers.

Ebenezer Richardson fired a gun from his house into a crowd of boys on February 22, 1770, and killed Christopher Seider, who was 10 or 11. Richardson was a customs informer, a man who told on smugglers to the customs officials, the officers who collected taxes on goods brought in by ship. A jury found Richardson guilty of murder on April 21. The judges thought he was innocent, and they put off sentencing him.

**The soldiers.** British soldiers fired into a crowd on March 5, 1770, and killed five people. Crispus Attucks, Samuel Gray and James Caldwell died that night. Samuel Maverick, 17, died the next morning, and Patrick Carr died nearly two weeks later. Captain Thomas Preston and eight soldiers were arrested and jailed.

No lawyer in Boston would defend them until John Adams agreed, with Josiah Quincy and Robert Auchmuty. Adams later wrote that in a free country, a lawyer "ought to be the very last thing that [an] accused Person should want." In his day, want meant lack: an accused person must never be left without a lawyer.

A jury found Preston not guilty on October 30. The soldiers' trial began on November 27. After two and a half hours, the jury found six soldiers not guilty. It found Hugh Montgomery and Mathew Kilroy guilty of manslaughter, killing someone without planning to, and manslaughter could be punished by death. The two men used an old English rule called benefit of clergy, which let a first-time offender who could read escape a death sentence once.

Instead of being hanged, each man was branded on the hand, at the base of the right thumb. On December 14, 1770, Sheriff Stephen Greenleaf pressed a red-hot iron onto each man's thumb in the courtroom, and it burned a mark into the skin that stayed for life. John Adams remembered in 1822 that when the sheriff came near, the two soldiers "burst into tears." The *Boston Gazette* reported that after the branding they were "discharged," which means let go.

### From street work to the cell, Philadelphia

Pennsylvania's lawmakers tried two new punishments in place of hanging between 1786 and 1790. The historian Louis Masur found that in the ten years before 1786, Pennsylvania officials had hanged about 40 people for robbery or burglary.

**The wheelbarrow men.** The lawmakers passed a law in 1786 under which judges sentenced convicts to "continued hard labour publicly and disgracefully imposed." People called the prisoners "wheelbarrow men." Ann Warder wrote in her diary on March 30, 1787, that the convicts cleaned the streets with "an iron collar around their neck and waist to which a long chain is fashioned and at the end a heavy ball."

Their heads were shaved, and a guard went with each gang. Warder wrote that at first the prisoners "preferred death" to being shown in public this way. Thirty wheelbarrow men escaped in one night in October 1788. The lawmakers ended the law by 1790.

**The reformers.** Thirty-seven Philadelphians formed the Philadelphia Society for Alleviating the Miseries of Public Prisons in 1787, a group to ease the suffering in the prisons. Among them were the doctor Benjamin Rush, Benjamin Franklin and Bishop William White. They drew on the ideas of John Howard, an English prison reformer.

In the city's old jail, men, women and children were held together, whatever their crime. Annie Anderson, writing in the *Encyclopedia of Greater Philadelphia*, states that the sheriff there forced money out of prisoners, sold them liquor from a bar and held back their food.

**The cells.** Pennsylvania's lawmakers passed a new law in April 1790. Under it the Walnut Street Jail became the Walnut Street Prison, a state prison for convicts from all of Pennsylvania. The lawmakers ordered a separate building of cells, called a penitentiary house, for "the more hardened and atrocious offenders," the convicts who had done the worst crimes. The word penitentiary comes from penitence, being sorry for wrongdoing.

Each cell was six feet wide, eight feet long and nine feet high, and thirty-six of them were built. Judges could sentence a prisoner to time alone in one of these cells, which is called solitary confinement.

The law professor David Shapiro studied the prison's records for the *Harvard Law Review* in 2019. He found that judges sent 748 people to the prison between 1795 and 1800, and sentenced 29 of them to time in solitary confinement. Margaret Price, convicted of counterfeiting in 1795, got four years with four months in solitary.

Prisoners worked in a nail factory inside the prison. Keepers locked a prisoner who refused to work in a cell. Caleb Lownes wrote in 1799 that such a prisoner stayed there "some weeks, without labour, bed, or furniture, of any kind, except a vessel to hold his drink, and another his mush, and a blanket."

### Rights for the accused, 1791

Lawmakers in enough states approved the first ten amendments to the Constitution, called the Bill of Rights, on December 15, 1791. An amendment is an addition or change to the Constitution. Four of them list rights of people accused of crimes:

- The Fourth Amendment requires officers to have a warrant, a judge's written order, to search a home. A judge may give one only when there is good reason to believe a crime took place.
- The Fifth forbids forcing anyone to be a witness against himself. That means no one can be forced to confess, or to say anything that could help prove him guilty.
- The Sixth requires, for an accused person, "a speedy and public trial, by an impartial jury," a jury whose members favor neither side, and the help of a lawyer.
- The Eighth forbids "cruel and unusual punishments" and bail set too high. Bail is money paid to the court so an accused person can go free until the trial.

At first these rules applied only to the federal government and its courts. State courts did not have to follow them.

### Patrick Lyon

> **Who:** A Philadelphia blacksmith held three months in the Walnut Street Prison for a bank robbery he did not commit.
>
> **When and where:** Philadelphia, 1798 to January 1799.

**He walked 150 miles to clear his name and was locked up.**

Patrick Lyon, a Philadelphia blacksmith born in Scotland, did a rush job for the Bank of Pennsylvania in 1798. He changed the locks on two of its iron vault doors. It was his last job before he left the city. He told the bank's carpenter that the doors were not right for a bank and the locks were not safe. A stranger came to his shop with the carpenter and spent a long time looking at the doors, keyholes and locks.

Then yellow fever spread through Philadelphia, and about 1,300 people died of it. Lyon left the city by boat for Lewes, Delaware, with his 19-year-old apprentice, a young man learning his trade. The apprentice died of the fever there.

On the night of August 31, while Lyon was away, someone took $162,821 from the bank's vault without breaking in. Lyon heard that he was the main suspect, and he walked back to Philadelphia to clear his name. "I had come 150 miles to surrender myself," he wrote.

High Constable John Haines, the chief of the city's constables, wanted the $2,000 reward. He and the bank's officers questioned Lyon. The bank's officers were sure that the man who changed the locks had made an extra key. A magistrate sent Lyon to the Walnut Street Prison and set his bail at $150,000.

Lyon called the prison "cold, damp, unwholesome and solitary." His cell was 12 feet by 4 feet. "I read until I was tired and walked until I was weary," he wrote. He caught yellow fever there and lived.

The robbers were Isaac Davis, a carpenter, and the bank's porter, Thomas Cunningham, who died of the fever. Davis was the stranger who had studied the locks. He confessed and gave back the money, and the governor promised him a pardon. Davis seems never to have spent a day in prison. The bank's officers still said Lyon had helped by making a key. He stayed in prison until January 1799, when a grand jury refused to charge him.

Lyon told what had happened to him in a book, his 1799 *Narrative*. He sued the bank's officers and the constable for keeping him in prison without cause. A jury awarded him $12,000 in 1805. The men he sued appealed, and in 1807 they paid him $9,000 to settle the case. The painter John Neagle later painted him as *Pat Lyon at the Forge*.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 11 minutes**

In the new prisons of New York and Pennsylvania, keepers locked convicts, people found guilty of crimes, alone in cells: at night in New York, and all day and night in Pennsylvania. Both kinds of prison kept prisoners silent. Officials in Boston and New York hired full-time police. Pennsylvania's lawmakers moved hangings inside jail walls in 1834, and Michigan's lawmakers voted to end the death penalty twelve years later.

In the South, white men still policed enslaved people. South Carolina's slave patrols, small groups of white men on horseback, searched the places where enslaved people lived and broke up their gatherings. Virginia's local judges, called justices, tried enslaved people with no jury. White mobs also killed people with no trial at all. A white mob in St. Louis burned Francis McIntosh to death in 1836, and no one was charged.

### The Cherokee Nation's police, 1808

Under the old Cherokee law of blood, a dead person's clan, not the nation, punished a killing. Leaders of the Cherokee Nation began to change that in 1808, when they set up their own police. Two years later the clans gave up revenge.

The Cherokee lived then in their own country, in parts of what are now Georgia, Tennessee, Alabama and North Carolina. The leaders on the Cherokee national council, who made the nation's laws, passed a written law at Brooms Town on September 11, 1808. Under it they set up "regulating parties," companies of men who made sure people obeyed those laws. The principal chief, or head leader, Black Fox signed it with Path Killer, Toochalar, and Charles Hicks, the council's secretary.

**The regulators.** Each company had six men: a captain, a lieutenant who was second in command, and four privates. The law states the pay: fifty dollars for the captain, forty for the lieutenant and thirty for each private. The regulators went after horse thieves and robbers. They also protected what children got from their dead parents and what widows owned.

A man found guilty of stealing a horse got "one hundred stripes on the bare back," one hundred blows of a whip. Blows like these cut the skin and leave welts, raised stripes of swollen skin, and scars.

If a regulator killed a man who fought back with a weapon, "the blood of him or them shall not be required." That meant the dead man's clan, his mother's large family group, could not kill in return.

**The end of clan revenge.** The seven clans met in council at Oostanallah on April 10, 1810, and passed an "act of oblivion for all lives." Oblivion means forgetting: the clans forgave every life that one clan still owed another. From then on, a person who killed someone "without malice intended," meaning by accident, would not be held guilty. A man who killed his brother in anger would be guilty of murder.

With this act the clans ended the law of blood. The editors of the *Cherokee Phoenix*, the nation's own newspaper, printed both laws on March 13, 1828.

### Two kinds of prison: Auburn and Eastern State

Prison keepers in New York and Pennsylvania ran two different kinds of prison in the 1820s. In both, they kept prisoners from talking to each other.

**Auburn.** At Auburn Prison in New York, prisoners worked together in groups during the day and slept alone in cells at night. They were not allowed to speak at any time. Elam Lynds became the head keeper in 1821. He had prisoners flogged for breaking even small rules. Flogging means beating a person's bare back with a whip, which cuts the skin and leaves welts and scars.

Lynds and John D. Cray made prisoners march in step with their arms locked together, a way of marching called the lockstep. Lynds dressed them in striped uniforms.

New York's officials used the same plan at Sing Sing, their third state prison. Officials in Connecticut, Massachusetts, Maryland and Washington, D.C., had taken up the Auburn plan by 1829. Officials in most other states chose it later.

**Eastern State.** Pennsylvania's officials opened Eastern State Penitentiary, a prison in Philadelphia, in October 1829. The architect John Haviland laid out seven blocks of cells joined to a center hall. He said he designed it for "watching, convenience, economy and ventilation." By economy he meant saving money, and by ventilation, fresh air.

Each prisoner lived and worked alone in a cell about 8 feet wide and 12 feet long, with its own small exercise yard. A Bible was the only thing he was allowed to keep. Prisoners made shoes and wove cloth in their cells. Whenever a prisoner left his cell, a guard put a hood over his head so that no other prisoner could see his face.

**The iron gag.** Guards punished prisoners who broke the rules. They gave them cold showers, and one account states that guards apparently did this once outdoors in winter. They also used the iron gag. The guards clamped an iron piece over the prisoner's tongue, like the bit in a horse's mouth, and chained it to his hands, which were held behind his back. With his hands chained to it, he could not take it out.

Prison officials put a prisoner named Mathias Maccumsey in the iron gag in 1833 as a punishment for talking, and he died. The prison doctor gave the cause as apoplexy, an old word for a sudden stroke. The historian Jennifer Lawrence Janofsky, writing in the *Encyclopedia of Greater Philadelphia*, states that the prison's leaders tried to cover up the death.

A committee of Pennsylvania lawmakers investigated charges in 1834 and 1835 that the prison's officials had been cruel to prisoners. The lawmakers did not find the warden, Samuel Wood, guilty of cruel and unusual punishment.

The English writer Charles Dickens visited Eastern State in 1842. He wrote that he believed the system "in its effects, to be cruel and wrong." He also wrote: "I hold the slow and daily tampering with the mysteries of the brain to be immeasurably worse than any torture of the body." He meant that keeping a person alone and silent for years did more harm to the mind than any torture does to the body.

Pennsylvania's prison officials gave up keeping prisoners alone in 1913. Eastern State was built for 250 prisoners, and by the middle 1920s it held about 1,700.

### Charles Williams

> **Who:** The first prisoner at Eastern State Penitentiary.
>
> **When and where:** Philadelphia, October 1829 to October 1831.

**Prisoner Number 1 got two years alone for stealing a watch.**

Charles Williams was an 18-year-old Black farmer. He had been found guilty of breaking into a house and stealing a silver watch, a gold seal and a gold key, worth $25 in all. A seal was a small stamp, often hung on a watch chain, for pressing a mark into wax. His sentence was two years alone and in silence, with work.

Guards led him into the new prison in October 1829 with a hood over his head. From then on he was Prisoner Number 1, and Jane Brox, who tells his story in the *Public Domain Review*, writes that he was not called Charles again while he was there.

His cell was twelve feet by eight. *Smithsonian* magazine reports that prisoners there spoke to the guards through a small feeding hole and worked alone in their cells. He was let out in October 1831, two years to the day after he went in.

### After Nat Turner's revolt, 1831

Nat Turner, an enslaved man, led a revolt in Southampton County, Virginia, in August 1831. Turner and the rebels who joined him killed 55 white men, women and children, by the count of the historian Patrick Breen. A Library of Virginia article gives the number as 57.

White people from Southampton and beyond killed Black people with no trial in the days after the revolt. Breen writes that they killed about three dozen in Southampton County. He also writes that armed units formed "to put down the revolt and in many cases get revenge." A Library of Virginia article states that they killed hundreds, with no exact count.

The county's justices tried the accused rebels in a court of oyer and terminer. In Virginia that meant local justices judged enslaved people with no jury. Breen counts thirty enslaved people and one free Black man sentenced to death. Nineteen were put to death on the justices' orders. Governor John Floyd changed the sentences of the other twelve so they would not die.

Turner hid for two months. He gave himself up on October 30, 1831. The justices tried him on November 5 and ordered him "hanged by the neck until he be dead" on November 11. He was hanged that day, as the justices had ordered. In the same court record, the justices set his value as property at $375. Virginia officials paid that sum to his owner.

### Hangings move inside the jail

Pennsylvania's lawmakers became the first in any state to ban public executions, hangings in front of crowds, in 1834. The Death Penalty Information Center, a group that collects facts about the death penalty, records this. After that, officials hanged prisoners who had been sentenced to death inside the county prisons.

Michigan's lawmakers voted to end the death penalty on May 18, 1846. An article by the news outlet Michigan Public states that Michigan was the first English-speaking government in the world to do so.

### Francis McIntosh, St. Louis, 1836

A white mob in St. Louis, Missouri, burned Francis McIntosh alive on April 28, 1836, and no one was ever charged. McIntosh was a free Black man, 26 years old, from Pittsburgh. He worked on the steamboat *Flora* as a cook and as a porter, who carried passengers' bags.

That day Deputy Constable William Mull, a local law officer, arrested McIntosh for getting in the way of officers who were arresting two sailors. Deputy Sheriff George Hammond, a county law officer, helped take him to jail. McIntosh was told he would get five years in prison. He stabbed both officers with a knife. Hammond bled to death. Mull was badly wounded, and accounts differ on whether he died later.

A crowd of several hundred white people gathered, and a city alderman, a member of the city council, was among them. Men from the crowd broke into the jail and took McIntosh out. They chained him to a locust tree near Seventh and Chestnut Streets, then piled wood around his knees and set it on fire. The crowd cheered as he burned, according to a history written at the University of Missouri-St. Louis. He died within about twenty minutes. By one report, he asked to be shot.

**What the judge told the jurors.** Judge Luke Lawless then spoke to the grand jury. He told the jurors to charge any person they could identify. But he said the killing might be the act of a whole crowd moved by one feeling, and if it was, it was beyond the reach of the law. He also blamed the writings of abolitionists, people who worked to end slavery. The jurors, led by their foreman, the head juror, John O'Fallon, charged no one.

Elijah Lovejoy, the editor of the *St. Louis Observer*, wrote against the killing and against the judge. A mob of people who were against ending slavery killed Lovejoy in Alton, Illinois, in November 1837.

A young lawyer named Abraham Lincoln spoke about the McIntosh killing in Springfield, Illinois, in January 1838. He said McIntosh had been "chained to a tree, and actually burned to death." He added that it was "all within a single hour from the time he had been a freeman, attending to his own business, and at peace with the world." Lincoln's words left out the stabbing and Hammond's death.

### Police take over from the night watch

The people of Boston had kept a town watch, men who walked the streets at night to keep order, since 1631.

**Boston.** A small day police force began work in Boston in 1838, with officers on duty full time beside the night watch. The crime historian Gary Potter calls this the first organized police force paid for with public money and with officers on duty full time, a 2017 *TIME* article reports. Boston's city officials replaced the watch and the day police with one Police Department of 250 officers in 1854.

**New York.** About 320,000 people lived in New York before 1845. A night watch and 182 other officers guarded them: 100 city marshals, 31 constables and 51 city police officers, all kinds of local law officers. New York's state lawmakers passed a Municipal Police Act, a law for a city police force, on May 7, 1844. Under it, city officials were to end the night watch.

The mayor and the city council argued over who would choose the officers. Mayor William Havemeyer and the council finally adopted the law for the city on May 23, 1845. Accounts differ on the size of the force: the website CultureNow states that the 1844 law allowed 1,200 officers, and another count gives 800. After a long argument, the officers first wore a navy blue uniform in 1853.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 21 minutes**

Mobs killed people with no trial in the South, in the West and in New Orleans, and the men in those mobs were almost never punished. After the Civil War, white mobs in the South killed Black people. A killing like this, by a mob, with no trial, is called a lynching. Mobs in the West killed Chinese immigrants, and a mob in New Orleans killed eleven Italian American men.

**The count.** The Equal Justice Initiative, a group in Montgomery, Alabama, founded by the lawyer Bryan Stevenson, published a report called *Lynching in America* in 2017. It records 4,075 Black people lynched in twelve Southern states between 1877 and 1950, more than one a week for 73 years. Counting lynchings in other states too, its total is more than 4,400.

The report states that the people who took part "were celebrated and acted with impunity," meaning with no fear of punishment, and that state and federal officials mostly let the killings happen.

Private detectives such as Allan Pinkerton's men worked for railroads and factory owners. Officials in Alabama and other states rented prisoners to mining companies and farm owners, and in Alabama more than 95 percent of the county prisoners and 90 percent of the state prisoners were Black. New York state senators on a committee that met in 1894 and 1895 estimated that New York City's police officers took more than $10 million a year in payments from people breaking the law.

### Vigilance committees in San Francisco, 1851 and 1856

A vigilance committee was a group of private citizens who arrested, tried and punished people themselves, outside the courts. About 700 San Francisco men formed one on June 9, 1851. The next day they held their own trial and hanged John Jenkins, a man from Sydney, Australia, for stealing a safe. At that time California law allowed a death sentence for that kind of theft.

That year the committee's members hanged four men. They held and questioned people at their headquarters without due process, the rules a court must follow to give an accused person a fair trial. Of the others they held, they whipped one, forced 28 out of California, handed 15 to the police and courts, and let 41 go.

San Francisco men formed the committee again on May 14, 1856, after James Casey shot the newspaper editor James King of William. William Tell Coleman led it, and its leaders claimed 6,000 members. The committee's members hanged four more men that year, among them Casey and Charles Cora. The boxer James "Yankee" Sullivan killed himself after being held in one of the committee's cells. The members broke up the committee on August 11, 1856. Members of the two committees hanged eight people in all.

### The Dakota trials, 1862

US Army officers tried 392 Dakota men after the war between the United States and the Dakota in Minnesota in 1862, and hanged 38 of them together at Mankato. The Minnesota River valley was the Dakota homeland.

Colonel Henry Sibley set up a military commission, a court of army officers, to try Dakota prisoners on September 28, 1862. The officers held the trials at the Lower Sioux Agency, also called the Lower Agency. US officials set it up in 1853 to run the new Dakota reservation, and it had a school, shops and homes for the government workers. The war began there in August 1862.

**Five-minute trials.** The trials took place in François LaBathe's summer kitchen, one of the only buildings there still standing. Some trials lasted no longer than five minutes. The officers sentenced 303 men to death and 16 to prison.

The law professor Carol Chomsky of the University of Minnesota wrote that "the evidence was sparse," meaning thin, and that the officers were "biased," meaning they had taken a side before they heard the cases. She wrote that the men on trial had no lawyers, and that the trials were held in a language they did not know.

President Abraham Lincoln and his lawyers read all 303 trial records. Lincoln wrote to the Senate that too much mercy might encourage another war, and that too much harshness would be "real cruelty."

He looked first for men found guilty of rape, which means forcing a person into sex, and he found two. Next he added men found to have taken part in "massacres," the killing of many civilians, people who were not soldiers. Men found only to have fought in battles stayed off his list. He approved 39 hangings, and one of those men was later reprieved, which means spared from hanging.

Army officers hanged 38 Dakota men together at Mankato on December 26, 1862. About 4,000 people watched, and 2,000 soldiers stood guard. An article by the Death Penalty Information Center states that it was the largest mass execution in United States history. Two of the 38 were not men Lincoln had approved for hanging: the officers hanged them by mistake. One was Caske, whose Dakota name was Wicaŋȟpi Wastedaŋpi. The other was Wasicuŋ, a white man the Dakota had adopted, whom the officers had found not guilty.

The bodies were cut down and put together in one shallow grave on a sandbar between Mankato's main street and the Minnesota River. Before morning, doctors had dug up most of them to use as cadavers, dead bodies that doctors and medical students cut open to study the human body.

A year later, the army's chief lawyer found that Sibley had never had the power to set up the trials. By then the 38 men had already been hanged.

### Police against the draft riots, 1863

Mobs in New York City attacked the police, burned buildings and killed Black New Yorkers from July 13 to 16, 1863. The rioters were fighting the new Civil War draft, a law that required men to serve in the army when called. The state militia, the state's part-time soldiers, had been sent to Gettysburg, so at first the Metropolitan Police were the only force in the city.

On the first day, rioters beat Police Superintendent John Kennedy, the head of the city's police officers, until he was nearly unconscious and cut his hand with a knife. Police Commissioners Thomas Acton and John Bergen, two of the officials who ran the police, took command. Their officers kept the rioting out of Lower Manhattan, below Union Square. Rioters burned two police station houses. They also burned the Colored Orphan Asylum, a home for Black children, and the more than 200 children inside all got out.

Rioters beat, tortured and killed Black New Yorkers. Village Preservation, a New York history group, records that William Jones, a Black cart driver, had gone out to buy a loaf of bread. A mob chased him on Clarkson Street, beat him, hanged him and set him on fire. Another Black man was attacked by a crowd of 400, hanged from a tree and set on fire. Hundreds of Black New Yorkers left the city, among them the doctor James McCune Smith and his family.

Secretary of War Edwin Stanton sent five regiments, units of soldiers, from Gettysburg to stop the riot, and it ended on July 16. By the official count, 119 or 120 people were killed in the riots. A New-York Historical Society article records the official count of 119 and states that it may be too low.

### Mobs that killed Chinese immigrants

White mobs in the West killed Chinese immigrants. After the killings at Los Angeles in 1871 and at Rock Springs in 1885, every man who was charged or arrested went free. The justices of the California Supreme Court had ruled in 1854 that Chinese people could not testify against white people in court.

**Los Angeles, 1871.** A white man named Robert Thompson was killed in Los Angeles on October 24, 1871, during a gunfight between two Chinese groups. A crowd of about 500 people, one tenth of the city, then attacked the Chinese part of town. They killed 18 Chinese men and boys, by the count of the Los Angeles Public Library, or 19 in the list of names the historian Scott Zesch published in 2008. Among the dead was a doctor, Gene Tong.

The mob hanged seven of them from the crossbar of Goller's wagon shop and three from a freight wagon. The next morning seventeen bodies lay in the jail yard.

Grand jurors in Los Angeles brought 25 charges of murder. Only ten men were tried, and seven or eight of them were found guilty of manslaughter. Judges later threw out the verdicts on a technical point of law. District Attorney Cameron Thom chose not to try the men again, and they went free in 1873.

**Rock Springs, 1885.** Rock Springs was a town in Wyoming, which was then a territory, land under the federal government that was not yet a state. Between 100 and 150 armed white miners, railroad workers and townspeople attacked the Chinese miners there on September 2, 1885. They killed 28, wounded 15, and robbed and burned all 79 homes in the town's Chinatown. Federal troops arrived nearly a week after the killings and stayed for 13 years.

Sixteen white miners were arrested and let out on bail, money paid as a promise to come back for trial. The historian Tom Rea, writing for WyoHistory.org, a Wyoming history website, states that "though the killing had been done in daylight, in front of other people, no one could be found who would swear to having seen any crimes." No charges were filed. Chinese diplomats, officials who spoke for China's government, listed nearly $150,000 in losses. Under pressure from the president, members of Congress agreed to pay.

**By 1885:** San Francisco's committees had hanged eight men, army officers had hanged 38 Dakota men at Mankato, and every man charged or arrested for the killings of Chinese immigrants at Los Angeles and Rock Springs had gone free.

### Prisoners rented out: convict leasing

State and county officials in Alabama and other states rented prisoners to private companies after the Civil War. This was called convict leasing. The companies' bosses made the prisoners work in mines, on farms and on railroads. The companies' owners paid the state or the county, not the prisoners.

The historian Mary Ellen Curtin gives the Alabama numbers in the *Encyclopedia of Alabama*. Officials there leased prisoners from 1875 to 1928. More than 95 percent of the county prisoners and 90 percent of the state prisoners there were Black. Most county prisoners had been found guilty of misdemeanors, small crimes such as being drunk in public. They had to work longer to pay off their court costs.

**The whip and the deaths.** The companies' bosses whipped prisoners who tried to escape or talked back, and they whipped others to make them work harder. Each year, four or five of every hundred state prisoners died. Of the 745 county prisoners in the mines in 1896, 181 had died in the two years before. At the Coalburg mine, 90 of every 1,000 prisoners died.

### Allan Pinkerton

> **Who:** A Scottish barrel maker who started a private detective agency in Chicago.
>
> **When and where:** Chicago and across the country, 1850 to 1884.

**His sign was an open eye over the words "We never sleep."**

Allan Pinkerton's detectives were paid by the companies that hired them. They were not police officers. Pinkerton was a cooper, a barrel maker, from Glasgow, Scotland, and in 1843 he settled in Dundee, Illinois. His house there was a hiding place for people escaping slavery. While cutting wood one day he found a gang of counterfeiters, people who made fake money, and told the sheriff, who arrested them.

Pinkerton and the lawyer Edward Rucker started a detective agency in Chicago in 1850, which became the Pinkerton National Detective Agency. The men who ran express companies, which carried money and packages by train, hired his detectives to catch criminals, and so did the men who ran the railroads.

His men kept photographs of known criminals, and some of them joined gangs in disguise. Pinkerton guarded Abraham Lincoln on his way to Washington in February 1861, against what Pinkerton said was a plan to kill him in Baltimore.

Pinkerton's detectives and local helpers raided the Missouri farm of the family of the outlaw Jesse James, a robber on the run from the law, in January 1875. They threw a firebomb into the house. It exploded and killed Jesse's eight-year-old half-brother, Archie. It wounded his mother, Zerelda Samuel. Jesse was not there. Afterward, many people took the side of the James family and blamed the agency for the raid.

Factory owners also hired Pinkerton men after the Civil War as armed guards against workers on strike, workers who had stopped work together to press their employers for changes. Pinkerton died in Chicago in 1884.

### The Haymarket trial, 1886

Someone threw a bomb at police at a workers' meeting in Haymarket Square in Chicago on May 4, 1886. Seven officers were killed and sixty were hurt. The bomb thrower was never identified.

Prosecutors charged eight anarchists, people who wanted to do away with all government. They tried the eight as accessories, people who help a crime happen without doing the act. The prosecutors said the men's speeches had led to the bombing. A jury found all eight guilty in three hours. The judge sentenced seven to hang and Oscar Neebe to 15 years in prison.

Four of the men, Albert Parsons, August Spies, George Engel and Adolph Fischer, were hanged on November 11, 1887, as the judge had sentenced them. Louis Lingg had already killed himself in his cell with an explosive someone had smuggled in. Governor Richard Oglesby changed the sentences of two men to life in prison.

Governor John Peter Altgeld pardoned the three men still in prison, Samuel Fielden, Oscar Neebe and Michael Schwab, in June 1893. The pardon freed them and cancelled their punishment. Altgeld wrote that their trial had been unfair.

### The first electric chair, 1890

William Kemmler became the first person put to death in an electric chair, on August 6, 1890, at Auburn Prison in New York. He had killed Matilda Ziegler in Buffalo in 1889 with a hatchet, or with an axe by one account. Electrocution means killing a person by sending a strong electric current through the body. The current stops the heart and burns the skin where the metal touches it.

A Buffalo dentist, Dr. Albert Southwick, had first suggested it in 1881. He argued that it was kinder than hanging, in which a person sentenced to death could hang for up to 30 minutes before dying. Kemmler's lawyers argued that the electric chair was a cruel and unusual punishment, which the Constitution forbids. The justices of the US Supreme Court turned them down.

Kemmler's chair had two metal plates covered with damp sponges, one on his head and one on his back. Warden Charles Durston, the head of the prison, gave the order, with 17 witnesses in the room. The first shock lasted 17 seconds. It was about 700 volts by one account, or 1,000 by another. A volt is a measure of how strongly electricity pushes through a wire or a body.

The first shock did not kill him. The witnesses smelled burning cloth and burning flesh. A second shock of about 1,030 volts went on for about two minutes, until smoke rose from his head, and Kemmler died. Doctors who examined the body found that the plate on his back had burned through to his spine, the HISTORY.com account states.

The chair ran on alternating current, a kind of electricity that flows back and forth many times a second. Harold Brown, whom New York officials hired to build the chair, used it. *Smithsonian* magazine reports that Thomas Edison, whose company sold the other kind, direct current, was secretly paying Brown to use alternating current. George Westinghouse's company built electric systems that used alternating current. After Kemmler's death Westinghouse called it "a brutal affair" and said: "They would have done better with an axe."

### Eleven men killed in a New Orleans prison, 1891

A mob in New Orleans broke into the city's prison on March 14, 1891, and killed eleven Italian American men. Five months earlier, the police chief, David Hennessy, had been shot. Nineteen Italian Americans were charged with his murder, among them a 14-year-old boy. Nine were tried. The jury found six not guilty, and the trial of the other three ended in a mistrial, with no verdict. A *Smithsonian* magazine article states that "there was no solid evidence against them."

A newspaper notice stated that citizens should "come prepared for action." A crowd of thousands gathered at the Henry Clay statue. The lawyer William Parkerson told them to "set aside the verdict of that infamous jury" (infamous means known for something bad).

**Who led the mob.** Parkerson and three other city leaders led the killers: the lawyer Walter Denegre, the politician and businessman James Houston, and John Wickliffe, the editor of the *New Delta* newspaper. John M. Parker, who later became governor of Louisiana, and Walter Flower, who later became mayor of New Orleans, were in the mob.

The prison warden, Lemuel Davis, let the 19 prisoners hide. The mob found eleven of them. Men dragged Emmanuele Polizzi outside, hanged him from a lamppost and shot him. He was mentally ill. They hanged Antonio Bagnetto, a peddler who sold fruit, from a tree and shot him. They shot or clubbed to death nine others inside the prison.

The eleven were Antonio Bagnetto, James Caruso, Loreto Comitis, Rocco Geraci, Joseph Macheca, Antonio Marchesi, Pietro Monasterio, Emmanuele Polizzi, Frank Romero, Antonio Scaffidi and Charles Traina. Three of them had been found not guilty, three had had no verdict, and five had never been tried.

**No one charged.** Grand jurors, who met under Judge Robert Marr, a friend of several men in the mob, said they could not identify the killers. They called the killers "several thousands of the first, best, and even the most law-abiding, of the citizens." They charged no one.

Italian officials called home their ambassador, their government's chief representative in the United States. President Benjamin Harrison agreed to pay the families $25,000 to make up for the killings, and federal officials paid $2,211.90 to each family. Mobs lynched at least eight more Italian Americans in Louisiana in the 1890s. No one was charged and tried in court for those killings either.

### Henry Smith

> **Who:** A Black man burned to death by a white mob in front of thousands of people, without a trial.
>
> **When and where:** Paris, Texas, February 1, 1893.

**Thousands came by train to watch a man burned to death.**

A white mob in Paris, Texas, tortured Henry Smith with hot irons and burned him to death on February 1, 1893, in front of thousands of people. He never had a trial, and no one was ever arrested for killing him.

**The accusation.** Myrtle Vance, a girl of three or four, was found dead in the woods near Paris in January 1893. Newspaper reports said that she had also been raped, which means forced into sex. The *New York Sun* called Smith her "ravisher," an old word for a man who rapes someone.

Her father, Henry Vance, was a Paris police officer. Several days before, he had arrested Henry Smith for being drunk and disorderly and had beaten him. Smith was accused of killing the girl. The two main accounts of what followed, by the journalist Ida B. Wells and the historian Terry Anne Scott, do not name the person who first accused him. Smith ran away to Arkansas.

Posses of Black and white men went after him. A posse is a group of men gathered to chase someone. They rode the Texas & Pacific and the St. Louis & San Francisco railways for free. Near Hope, Arkansas, a Black constable named Robinson, a local law officer, arrested Smith. Texas Governor James Hogg telegraphed Sheriff D. S. Hammond to hold Smith for a trial. Hogg also ordered that Smith not be taken to Paris. The sheriff and the county attorney answered that they were "helpless" against "an enraged public."

Men brought Smith to Paris by train. The mayor closed the schools. Trains brought people from Dallas, Fort Worth, Texarkana, Fort Smith in Arkansas, and other towns. The *New York Sun* stated that the crowd numbered 10,000, and other accounts state from 5,000 to 15,000. Men paraded Smith through town on a carnival float to a prairie near the railroad depot. There they tied him on a wooden platform ten feet high.

**The torture.** Henry Vance and men of his family burned Smith with red-hot irons for fifty minutes, starting at his feet. The *Sun* identifies them as the girl's father, her brother and two uncles. Another account identifies the father, his 15-year-old son and his brother-in-law. They burned out Smith's eyes and pushed hot irons down his throat.

Then men piled wood and cottonseed hulls, the dry outer shells of cotton seeds, around the platform, poured oil on it and set it on fire. The *New York Sun* reported the torture and the burning on February 2, 1893, and Wells reprinted the report in her book *The Red Record* in 1895. The *Sun* states that people carried off pieces of the burned wood.

Scott, writing on the website BlackPast, adds that Smith rolled out of the fire and fell ten feet to the ground. People in the crowd threw a rope around him and pulled him back into the fire. She writes that men cut his shirt from his body piece by piece and threw the pieces to the crowd.

**What the witnesses said.** The *Sun* stated that Smith had confessed at Hope. People who had seen the girl's body told Wells they saw no sign of the rape the newspapers reported. They said they saw only a small scrape and a bruise, mostly on her neck.

The Reverend King, a Black minister in Paris, said Smith was mentally ill. King said he had tried two years before to get him into an asylum, a hospital for mentally ill people. Men drove King out of Paris for speaking against the lynching. Wells wrote that he was "ridden out of Paris on a rail," carried out of town on a wooden pole.

The day after Smith was killed, Governor Hogg telegraphed the sheriff of Lamar County and asked for the killers to be arrested. A few days later a mob hanged Smith's stepson, William Butler, at Hickory Creek, five miles from Paris, and shot his body. Scott writes that no one was ever punished for killing William Butler either.

### Police who took payments: New York, 1894

Senator Clarence Lexow and other New York state senators, sitting as a committee, investigated the New York City police in 1894 and 1895. They found that officers took payments from people who broke the law, in return for letting them go on breaking it. Their report ran to 10,576 pages. In it, they estimated that officers extorted more than $10 million a year, forcing people by threats to pay.

The owners of brothels, houses where people paid for sex, paid police captains $30,000 a year. Owners of gambling houses paid $15 to $300 a month to stay open. Officers also paid bribes, secret payments for a favor, to be promoted. Captain Timothy Creedon told the committee he had paid $15,000 to become a captain, although he had scored 97.82 on the promotion test.

An Encyclopedia.com history of the hearings states that the chief of police, Thomas Byrnes, was said to be worth $350,000. The senators also found officers taking part in bribery, frightening voters, cheating in elections and beating people.

**Roosevelt's changes.** Mayor William Strong put Theodore Roosevelt on the city's Board of Police Commissioners in 1895. Roosevelt brought in civil service exams for new officers, tests that a person had to pass to get a government job, and raised the physical standards. He walked the streets at midnight to check that officers were on duty, and he started police patrols on bicycles. He left in 1897 to become assistant secretary of the navy.

### A court for children, Chicago, 1899

Illinois lawmakers voted to set up a court for children in Chicago in the spring of 1899. A 2019 article by the Chicago radio station WBEZ states that it was the first juvenile court in the world: a separate court for children accused of crimes, run to help the child instead of only punishing.

Before then, police arrested children, put them in handcuffs and held them overnight in jails and police stations with adult prisoners. In 1882 the Cook County jail in Chicago held more than 250 children aged 14 and under, and at least 20 of them were younger than 11. A 10-year-old boy who stole a pair of shoes waited almost two weeks in the county jail for a grand jury to hear his case.

Julia Lathrop worked at Hull House, a house on Chicago's Near West Side where Jane Addams and other women lived among poor immigrant families and helped them. Lathrop visited Illinois jails and wrote down what she found. Lucy Flower proposed a separate court for children. In 1907 a building for the children's court, with rooms where children were held, opened at Halsted and Ewing Streets.

**If you remember one thing:** White mobs killed Black, Chinese and Italian American people with no trial, and the courts punished almost none of the killers.

In 1850: A death sentence in New York was carried out with a rope, and a child arrested in Chicago could be held in jail with adult prisoners.

In 1900: New York's prisons used the electric chair, and Chicago had a court just for children, which WBEZ calls the first in the world.

**Next:** After 1900 the national government hired its own agents, and mobs went on taking Black prisoners out of jails.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 19 minutes**

The national government built a police force of its own, while some officers in the South whipped Black suspects or left Black prisoners to mobs. The US attorney general put 34 federal agents, agents of the national government, to work in 1908. By the 1930s the staff of their Bureau of Investigation kept the nation's fingerprint files and worked in a crime laboratory. Federal agents hunted gangsters such as John Dillinger, and they raided the gangs that sold alcohol during Prohibition, the years when making and selling it was against the law.

Mobs still took Black prisoners out of jails and killed them. A deputy sheriff and other white men in Mississippi whipped three Black men until they confessed to a murder. The sheriff in Chattanooga sent his guards away in 1906 on the night a mob came for Ed Johnson. Three times in the 1930s, the justices of the US Supreme Court threw out verdicts because of how Black defendants had been treated.

White men, many of them made deputies by the police and given a police officer's powers, burned Greenwood, the Black district of Tulsa, in 1921 and killed as many as 300 people. No white person was sent to prison for it.

### Ed Johnson

> **Who:** A Black man wrongly convicted, or found guilty, of rape and sentenced to death, then lynched after the justices of the US Supreme Court ordered that he be kept safe.
>
> **When and where:** Chattanooga, Tennessee, January to March 1906.

**The justices ordered him protected, and the sheriff sent his guards away.**

A jury found Ed Johnson guilty of a rape he did not commit. Rape means forcing a person into sex. The justices of the US Supreme Court stopped his hanging. A mob then lynched him on a bridge in Chattanooga, which means the men in it killed him with no trial.

A man attacked Nevada Taylor, a young white woman, from behind in January 1906, as she walked home from a streetcar stop. He choked her with a leather strap. A day or two later, officers arrested Ed Johnson, a Black man who worked as a porter at the Last Chance Saloon.

A witness, Will Hixson, may have given the police Johnson's name to collect a $375 reward. At the trial, thirteen witnesses swore that Johnson was at the saloon at the time of the attack. An all-white, all-male jury found him guilty of rape in February, and the judge sentenced him to hang. The court had chosen his lawyers, and they dropped his appeal. An appeal is a request for a higher court to look at the case again.

Two Black lawyers, Noah Parden and Styles Hutchins, took up the appeal. They asked a federal court for habeas corpus, an order to review whether a prisoner is held lawfully, and the federal judges turned them down.

Parden went to Washington and met Justice John Marshall Harlan of the US Supreme Court on March 17. Within two days the justices issued a stay, an order that stopped the hanging until they could hear the case, and ordered Sheriff Joseph Shipp to keep Johnson safe.

**The night of March 19.** The order appeared in Chattanooga's evening newspapers that day. That evening Shipp sent away the usual guards and left only the night jailer, Jeremiah Gibson. Between nine o'clock and midnight, a mob broke into the jail and took Johnson to the county bridge over the Tennessee River. Shipp came to the jail during the break-in and made no effort to stop the mob or to send for help.

The men put a rope around his neck, threw it over a beam and pulled him up. The rope broke or slipped, and he fell. They pulled him up a second time and shot him. One account says a deputy sheriff fired five more shots into his head. Johnson's gravestone gives his last words: "God Bless you all. I AM A Innocent Man."

**A trial in the Supreme Court.** For the first and only time, the justices of the US Supreme Court held a criminal trial themselves. The charge was contempt of court, the crime of defying a court's order. Twenty-five men were tried. The justices found six guilty in May 1909: Shipp, Luther Williams, Nick Nolan, Jeremiah Gibson, Henry Padgett and William Mayes.

Shipp, Williams and Nolan got 90 days in jail, and the other three got 60 days. Shipp was welcomed home as a hero. The case is *United States v. Shipp* (1909).

Judge Doug Meyer of the Hamilton County Criminal Court set aside Johnson's conviction in February 2000. He ruled that the all-white jury and the trial judge's refusal to move the trial out of Chattanooga had made it unfair. A memorial to Johnson was dedicated in Chattanooga on September 19, 2021.

### A federal police force, 1908 to 1934

Attorney General Charles Bonaparte ordered the lawyers of the Department of Justice on July 26, 1908, to send most of their investigations to his chief examiner, Stanley W. Finch. Finch handed each one to one of 34 agents. Nine of the agents came from the Secret Service, and Bonaparte hired 25 himself. The group was later called the Bureau of Investigation. Today it is the Federal Bureau of Investigation, or FBI.

Attorney General Harlan Fiske Stone made J. Edgar Hoover, then 29, the Bureau's director in 1924. Hoover fired agents he called "political hacks," men who had their jobs as favors from politicians. He required new agents to pass background checks and physical tests, and from January 1928 he trained them. The Bureau had 441 agents in 1924 and 339 five years later.

**Fingerprints.** Hoover set up a division to hold the country's fingerprint files on July 1, 1924. A fingerprint is the pattern of ridges on a fingertip, and it is different for every person. A print left on a glass or a gun can show who touched it. Police anywhere could send in prints and ask whether they matched a known criminal.

Bureau officials began keeping the national crime counts in 1930. The FBI's own history gives November 24, 1932, as the official birthday of its crime laboratory, which agent Charles Appel did most of the work to build.

**Gangsters.** Gunmen killed four lawmen, one of them a Bureau agent, at the train station in Kansas City in June 1933. The FBI's history names a gangster known as "Pretty Boy" Floyd as one of the gunmen. Agents and local police killed Floyd in a shootout on an Ohio farm in October 1934.

John Dillinger was a different gangster, and his gang robbed banks across the middle of the country. Agents led by Melvin Purvis found Dillinger in Chicago in July 1934 and shot him dead as he left a movie theater. In these years members of Congress also gave the Bureau's agents the power to carry guns and make arrests.

### Mobs and the courts, 1908 and 1930

White mobs attacked Black residents of Springfield, Illinois, for nearly three days in August 1908. They lynched two men, Scott Burton and William Donegan, and destroyed dozens of homes. The mobs drove nearly 2,000 Black residents out of the city for good. Officials called out the state militia, the state's part-time soldiers. About 150 people were arrested, and few of them were convicted, a National Park Service article states.

A white mob of 5,000 to 10,000 people broke into the Grant County Jail in Marion, Indiana, on August 7, 1930. They beat and hanged two Black men, Thomas Shipp and Abram Smith, both 19. A third prisoner, James Cameron, 16, survived. He was later convicted as an accessory, a person who helps with a crime, and served four years. He was pardoned, officially forgiven, in 1993.

The NAACP, a group that worked for the rights of Black Americans, named 27 suspects in the mob. All-white juries found the leaders who were tried not guilty.

### Tulsa, 1921: no one sent to prison

As many as 10,000 white Tulsans attacked Greenwood, the Black district of Tulsa, Oklahoma, on the night of May 31, 1921, and the police helped organize them. Greenwood stood on Muscogee (Creek) land. The attack lasted into the afternoon of June 1. The attackers burned 35 city blocks and killed Black residents.

**The count of the dead.** Estimates run from 50 to 300. Lawyers at the US Department of Justice wrote in 2025 that the massacre "killed as many as 300 Tulsans, perhaps even more." Some bodies were thrown in the Arkansas River, and some were buried in unmarked mass graves.

The attack began with an arrest. Tulsa police arrested Dick Rowland, a 19-year-old Black man, after a white man accused him of attacking Sarah Page, the white woman who ran an elevator he used. Police Chief John Gustafson later told a federal agent that Page had no scratches or bruises. She said Rowland had not said anything bad to her, and she would not press charges. A white crowd gathered at the courthouse. Armed Black men from Greenwood also came to the courthouse.

**The deputies.** Tulsa police then made hundreds of white men special deputies, men given a police officer's powers for a time. The Justice Department's 2025 review states that many of them had been calling for a lynching and had been drinking. Police officers helped organize these deputies into the forces that attacked Greenwood.

At Gustafson's later trial, a witness named John Oliphant said the police "were the chief fellows setting fires." The 2025 review reports that Oliphant named two men as the chief arsonists, the leaders in setting the fires: a police officer named Brown, and a man called "Cowboy Long."

Dr. A. C. Jackson, a Black surgeon, walked out of his house with his hands up to surrender. A young white man shot him, and Jackson died of his wounds. No one was ever charged with killing him.

**The camps.** Governor James Robertson declared martial law, rule by the military instead of by ordinary officials, at 11:30 in the morning on June 1. Police, special deputies and National Guard soldiers arrested Black Tulsans whether or not anyone suspected them of a crime. They held between 4,000 and 6,000 people under armed guard, at Convention Hall, at McNulty Park, a baseball park, and at the fairgrounds. Guard officers arrested some white residents for stealing, but they held no white residents in the camps.

**The grand jury.** A state grand jury, a group of citizens who decide whether to charge people with crimes, heard almost 200 witnesses. Its members charged about 70 men, many of them Greenwood's Black leaders, with starting a "riot." The *Tulsa Tribune* ran the headline "Roundup of 64 Indicted Blacks Is On: No Warrants Issued for Whites" on June 17. Indicted means charged with a crime. The grand jurors' report, printed on June 26, identified the armed Black men who had gone to the courthouse as a "direct cause."

Most of the cases were later thrown out, including the one against Dick Rowland. Some white men were accused of looting, stealing during a riot, and none of them went to prison. No white person was ever sent to prison for the killings or the burning.

The grand jurors also charged Police Chief Gustafson with neglect of duty, which means failing to do his job, and with dishonest dealings from before the massacre. He was convicted and removed from his job. Less than a year before the massacre, a mob had taken a white prisoner, Roy Belton, from the same jail and lynched him, and Gustafson had ordered his police not to step in.

Members of a state commission published a report on the massacre in February 2001 that recommended paying the survivors. Lawyers in the Civil Rights Division of the US Department of Justice published their own review, *Review and Evaluation: Tulsa Race Massacre*, in January 2025. The review states that police and white residents worked together in the attack.

The review also states that if today's civil rights laws had been in force in 1921, the attackers could have been tried and convicted. The youngest of them would now be more than 115 years old, so no one can be tried.

### The Osage murders, 1921 to 1929

Men murdered members of the Osage Nation in Oklahoma in the early 1920s to take their oil money. The Osage earned more than $30 million in 1923 from oil under their land, the Osage reservation, land set aside for the nation. Osage people held headrights, shares of that money, and when an owner died, a person who was not Osage could get the share.

**The guardians.** Under a 1921 law, local judges appointed white guardians to control the money of many Osage adults, and the judges handed many of these jobs to their friends. Guardians stole from the Osage people whose money they controlled, and some guardians and husbands killed Osage people to inherit their headrights.

**Mollie Burkhart's family.** The cattleman William Hale, known as the "King of the Osage Hills," set out to get the headrights of Mollie Burkhart's family. Mollie was married to his nephew, Ernest Burkhart. Hale's plan needed four women of the family to die in a set order: first Mollie's sister Anna, then their mother, then two more of Mollie's sisters. After those four deaths, all their headrights would pass to Ernest, and through his nephew Hale could take control of them. Federal agents later proved that Hale ordered the murders.

Members of Mollie's family died one after another:

- Anna Brown, Mollie's sister, was shot on May 22, 1921.
- Lizzie Q. Kyle, their mother, died in July 1921, and people suspected poison.
- Henry Roan, their cousin, was shot in January 1923 on Hale's orders, for his insurance money.
- Rita Smith, another sister, died on March 10, 1923, when men blew up her house. The bomb also killed her husband, Bill Smith, and Nettie Brookshire, who worked in their house.

Mollie herself was probably being poisoned.

**The count.** Counts of the dead differ. The Oklahoma Historical Society and the FBI each give about two dozen, and the Osage Nation counts more than 60. People who told others what they suspected got death threats, and some were killed. Someone threw a lawyer, W. W. Vaughn, from a train.

Members of the Osage Tribal Council asked federal officials to send detectives in April 1923, and Bureau of Investigation officials sent agents. Tom White led four agents who worked undercover, in secret and under false jobs, as a cattle buyer, an insurance salesman, an oil prospector and an herb doctor.

Ernest Burkhart pleaded guilty in June 1926 and got a life sentence. A jury convicted Hale in January 1929, and he was sent to prison for life. Kelsie Morrison and John Ramsey also got life sentences. Hale, Ramsey and Burkhart were later let out on parole, let out early and watched by officials. Governor Henry Bellmon pardoned Burkhart in 1965.

### A cabinet member convicted, 1929

Albert Fall was secretary of the interior, a member of the president's cabinet in charge of federal lands. He leased two oil fields that the government kept for the navy to two oil men. The fields were Teapot Dome in Wyoming and Elk Hills in California. Edward Doheny gave Fall a $100,000 "loan" with no interest, and Harry Sinclair gave him about $300,000 in bonds and cash.

A jury found Fall guilty on October 25, 1929, of taking a bribe, a secret payment for a favor, from Doheny. He was sentenced to one year in prison and a $100,000 fine. He was the first person convicted of a crime he committed as a cabinet member. A jury found Doheny not guilty of paying the bribe. Sinclair was jailed for contempt of Congress, which means refusing to obey Congress, and for trying to influence a jury. His term was six months by one account and nine by another.

### The end of convict leasing in Alabama, 1928

Alabama's officials rented county prisoners, more than 95 percent of them Black, to coal companies until 1928. This was called convict leasing. The companies' bosses forced the prisoners to work in the mines and whipped them for talking back, for trying to escape and to make them work harder. An explosion at the Banner mine killed 123 Black county prisoners on April 8, 1911.

**James Knox.** James Knox, a prisoner from Mobile, was killed at the Flat Top mine in 1924. His death was first reported as a suicide by swallowing poison. An autopsy, a doctor's examination of the body after death, showed that his heart had failed and that someone had injected the poison into his body after he died.

The City of Birmingham's history of the case states that his fatal injuries came from being whipped with a steel wire and held in hot water. The historian Mary Ellen Curtin, writing in the *Encyclopedia of Alabama*, describes him as a prisoner tortured by being lowered into "a vat of boiling water." Neither account names the men who whipped him, put him in the water or injected the poison. Alabama's officials ended convict leasing on June 30, 1928, after his death, the last in any state to do so.

### Eliot Ness and Al Capone

> **Who:** The Chicago gang boss who sold illegal beer and liquor during Prohibition, and the federal agent whose team raided his breweries.
>
> **When and where:** Chicago, 1925 to 1932.
>
> **Movie:** *The Untouchables* (1987), a film directed by Brian De Palma. It is a drama, not a documentary, and it changes many of the facts.

**The gang boss went to prison for not paying his taxes.**

Making and selling alcohol was against the law from 1920 to 1933, under the Eighteenth Amendment to the Constitution, and the ban was called Prohibition. Al Capone became the boss of a Chicago gang in 1925, after its leader, Johnny Torrio, was wounded and quit. His men made and sold beer and liquor.

Federal officials hired Eliot Ness, who was 26, to run the Prohibition agents in Chicago in 1929. Ness's team grew from six agents to about ten. From March 1931 they raided Capone's stills, where liquor was made, and his breweries. Gangsters offered them bribes, and the agents turned them down. A Chicago newspaper writer, Charles Schwarz, called them "untouchables."

Capone was arrested several times. Police in Philadelphia arrested him for carrying a hidden gun on May 17, 1929, and he served nine months. A federal judge sentenced him to six months for contempt of court in February 1931.

**The tax case.** Agents of the Treasury Department built the case that sent him away for years. A jury found him guilty of tax evasion, not paying taxes that are owed, on October 18, 1931. On November 24 the judge sentenced him to eleven years in federal prison and fined him $50,000. He also had to pay $215,000 in back taxes.

Ness was one of the agents who took Capone to the train for the federal prison in Atlanta on May 3, 1932. It is the only time the two men are known to have met. Capone later served part of his sentence at Alcatraz, a federal prison. He was released on November 16, 1939, with brain damage caused by syphilis, a disease passed on through sex. Ness died of a heart attack in 1957, and his book *The Untouchables* came out months after his death.

### Beaten into confessing: the third degree

The "third degree" meant police using cruelty to force a prisoner to confess. President Herbert Hoover set up a national commission to study crime and law enforcement in May 1929. The commission's 1931 report on police in 15 cities states that "physical brutality, protracted questioning, threats, prolonged illegal detention" were "widespread." Protracted questioning means questioning that goes on for hours or days, and prolonged illegal detention means holding a person for a long time when the law does not allow it.

**Brown v. Mississippi.** A man named Raymond Stewart died in Mississippi on March 30, 1934, and three Black men were later charged with his murder. That night Deputy Sheriff Dial and a group of white men seized Arthur Ellington, a Black man. They hanged him by a rope from the limb of a tree, let him down, and hanged him again. When he still said he was innocent, they tied him to the tree and whipped him. Days later the deputy arrested him again and whipped him until he agreed to confess.

On April 1 the same deputy, the jailer and other white men made Ed Brown and Henry Shields take off their clothes. They bent the two men over chairs and cut their backs open with a leather strap that had buckles on it. They kept whipping until the men confessed in the words the deputy demanded. The three men were charged with Stewart's murder on April 4, tried the next day and sentenced to death.

In court the deputy admitted the whippings. Speaking of Ellington's whipping, he said it was "Not too much for a negro." He added, "not as much as I would have done if it were left to me." Negro was a word used then for a Black person.

All the justices of the US Supreme Court agreed in 1936, in *Brown v. Mississippi*, to throw out the convictions. Chief Justice Charles Evans Hughes wrote: "The rack and torture chamber may not be substituted for the witness stand." The rack was an old device for torturing a person by stretching the body.

### The Scottsboro cases, 1931 to 1937

Nine Black teenagers and young men, aged 13 to 20, were riding a freight train in Alabama on March 25, 1931. When the train stopped near the town of Paint Rock, local police and a mob seized them. Two white women on the train, Victoria Price and Ruby Bates, accused them of rape. The nine were Olen Montgomery, Clarence Norris, Haywood Patterson, Ozie Powell, Willie Roberson, Charlie Weems, Eugene Williams, and the brothers Andy and Roy Wright.

Juries sentenced eight of them to death. At the trial of Roy Wright, who was 13, the jurors could not agree between death and life in prison, and the judge declared a mistrial, which means the trial ended with no verdict. In 1932, in *Powell v. Alabama*, the justices of the US Supreme Court ordered new trials because the young men had not had real lawyers.

Ruby Bates later said that Price had made up the story to avoid being charged with vagrancy, having no home or job. Bates then testified for the defense. Judge James Horton set aside a guilty verdict against Patterson. The justices threw out the convictions again in 1935, in *Norris v. Alabama*, because officials had kept Black people off the county's jury lists.

Seven more years of trials followed. The men were let out of prison between 1943 and 1976. Governor Robert Bentley of Alabama signed a law in 2013 that led to pardons for all nine.

**If you remember one thing:** The national government now had detectives of its own, and the justices of the Supreme Court began throwing out verdicts won by torture or by trials without real lawyers.

**One number:** The Department of Justice started with 34 agents in 1908. The Bureau had 441 by 1924, about thirteen times as many.

**Next:** After 1950 the number of people in American prisons grew more than eight times over, and the justices wrote new rules for the police station.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 23 minutes**

The number of people in American prisons grew more than eight times over in these fifty years, by the count of the Bureau of Justice Statistics, part of the US Department of Justice. In 2000, about 46 of every 100 sentenced prisoners were Black. From the 1970s on, lawmakers in Congress and the states wrote long prison terms that judges had to give, many of them for drug crimes.

**New rules.** The justices of the US Supreme Court set new rules for police and courts between 1961 and 1968. Police could not use evidence from an illegal search. State courts had to give a lawyer to a poor person charged with a serious crime. Police had to warn people of their rights before questioning them.

The justices struck down the death-penalty laws then in use in 1972 and allowed new ones in 1976. Some trials still ended with no one convicted, among them the 1955 murder trial for the killing of Emmett Till and the 1992 state trial of the officers who beat Rodney King.

### Emmett Till

> **Who:** A 14-year-old Black boy from Chicago, kidnapped and murdered by two white men whom an all-white jury then found not guilty.
>
> **When and where:** Money and Sumner, Mississippi, August and September 1955.
>
> **Movie:** *Till* (2022), a feature film about his mother, Mamie Till-Mobley, and her fight after his death.

**An all-white jury set his killers free after 67 minutes.**

Emmett Till was 14 and lived in Chicago. He was visiting relatives near Money, Mississippi, in August 1955. On August 24 he went into Bryant's Grocery and Meat Market, owned by a white couple, Roy and Carolyn Bryant. As Carolyn Bryant left, he whistled at her. Lawyers at the US Department of Justice tell these facts in their 2021 notice closing the case.

Between 2 and 3:30 in the morning of August 28, Roy Bryant and his half-brother, J. W. Milam, came to the house of Till's great-uncle, Mose Wright, who was 64. Milam carried a pistol and a flashlight. The two men took the boy away by force, with at least one other person.

Three days later his body was found in the Tallahatchie River. His killers had beaten him on his back and hips and shot him above the right ear, and one eye had been forced from its socket. The men had fastened a cotton gin fan around his neck with barbed wire to sink the body. The fan weighed 70 to 75 pounds.

He was identified by his father's silver ring. His mother, Mamie Till Bradley, later Mamie Till-Mobley, held an open-casket funeral in Chicago so that people could see what had been done to him.

**The trial.** Bryant and Milam were tried for murder in the Tallahatchie County Courthouse in Sumner in September 1955. Women and Black people were kept off the jury, and the Justice Department's 2021 notice does not name the officials who kept them off. Mose Wright stood up in court and pointed to Milam as one of the men.

The all-white, all-male jury found both men not guilty on September 23, after 67 minutes. One juror said, "If we hadn't stopped to drink pop, it wouldn't have taken that long." In November a grand jury refused to charge them with kidnapping, although they had admitted taking the boy.

Bryant and Milam told the writer William Bradford Huie, for *Look* magazine, in January 1956 that they had kidnapped and murdered Till. The magazine paid them between $3,600 and $4,000. They could not be tried again for the murder, because of the rule called double jeopardy: a person who has been found not guilty cannot be tried a second time for the same crime.

FBI agents reopened the case in 2004. A Mississippi grand jury did not charge Carolyn Bryant in February 2007. Justice Department lawyers reviewed the case again after 2017 and closed it in December 2021, stating that they could not charge anyone with a federal crime. President Joe Biden made places connected to Emmett Till and his mother a national monument on July 25, 2023.

### Clarence Earl Gideon

> **Who:** A poor man in Florida who was refused a lawyer, wrote to the US Supreme Court from prison in pencil, and won the right to a lawyer for every person charged with a serious crime.
>
> **When and where:** Panama City, Florida, 1961 to 1963.
>
> **Movie:** *Gideon's Trumpet* (1980), a television film with Henry Fonda as Gideon, based on Anthony Lewis's 1964 book.

**He asked the Supreme Court for a lawyer, in pencil, from prison.**

Someone broke into the Bay Harbor Pool Room in Panama City, Florida, on June 3, 1961. The thief took coins from the jukebox and the cigarette machine, and beer, wine and soda. A 22-year-old man named Henry Cook said he had seen Clarence Earl Gideon leave with his pockets full of coins.

Gideon, who was 50, had no money for a lawyer. Under Florida's law, only people who could be sentenced to death got free lawyers, so Judge Robert McCrary Jr. refused to give him one. Gideon defended himself in court. The jury convicted him on August 4, 1961, and the judge sentenced him to five years in prison.

From the state prison at Raiford, Gideon wrote to the US Supreme Court in pencil, asking the justices to hear his case. The justices gave him a lawyer, Abe Fortas. All nine justices agreed on March 18, 1963, in a ruling written by Justice Hugo Black, that a state must give a lawyer to a person charged with a felony, a serious crime, who cannot pay.

At Gideon's second trial, on August 5, 1963, a local lawyer, W. Fred Turner, showed that Cook had lied at the first trial about his own criminal record. The jury found Gideon not guilty after an hour. He died in 1972.

### Rules for the police station, 1961 to 1968

The justices of the Supreme Court wrote several more rules for police and courts in these years.

**Mapp.** Cleveland police forced their way into the home of Dollree Mapp on May 23, 1957. They waved a paper they called a search warrant, a judge's written order allowing a search, and no such paper was ever shown in court. They searched the house and found books they called obscene, meaning too sexual for the law to allow. She was sentenced to one to seven years.

Six of the nine justices ruled on June 19, 1961, in *Mapp v. Ohio*, that evidence police get from an illegal search cannot be used in a state trial.

**Miranda.** Phoenix police officers Carroll Cooley and Wilfred Young arrested Ernesto Miranda on March 13, 1963, and questioned him for two hours about the kidnapping and rape of an 18-year-old woman. He confessed. No one had told him he could stay silent or have a lawyer.

Five of the nine justices ruled on June 13, 1966, in *Miranda v. Arizona*, that police must tell a person they are holding about these rights before questioning. Chief Justice Earl Warren wrote the ruling. He based it on the Fifth Amendment of 1791, which forbids forcing anyone to be a witness against himself.

Afterward, officers across the country began reading people their rights aloud from "Miranda warning" cards. Arizona prosecutors, the government lawyers who bring the charges in court, tried Miranda again without the confession, and a jury convicted him again on March 1, 1967.

**Gault.** The sheriff of Gila County, Arizona, took Gerald Gault, 15, into custody in June 1964 without telling his parents. A neighbor, Ora Cook, had complained that he made an obscene phone call. Judge Robert McGhee sent him to the State Industrial School until he turned 21, about six years. An adult could have been fined for the same act. Eight of the nine justices ruled in 1967 that children in juvenile court have the right to hear the charges, to have a lawyer, to question witnesses and to stay silent.

**Terry.** Cleveland detective Martin McFadden stopped John W. Terry on October 31, 1963, patted the outside of his clothes and found a gun. Eight of the nine justices ruled on June 10, 1968, in *Terry v. Ohio*, that police may stop a person they reasonably suspect is armed and about to commit a crime. They may pat the outside of the person's clothes for weapons, even without grounds to arrest, which is called a stop and frisk.

**By 1968:** A poor person charged with a serious crime got a free lawyer, police had to warn a suspect of the right to stay silent, and evidence from an illegal search could not be used in a state trial.

### The men who killed civil rights workers, in court

Members of the Ku Klux Klan and some Southern officers killed people who worked for Black Americans' rights in the 1960s. The Ku Klux Klan is a secret white group that used terror against Black people and their supporters. In the six cases below, nobody was convicted of murder at the time.

**Jackson, Mississippi, 1963.** Byron De La Beckwith shot Medgar Evers, who led the NAACP's work in Mississippi, in the driveway of his home in Jackson in June 1963. Beckwith was tried twice in 1964, and both juries could not agree. A jury convicted him in 1994, 31 years after the killing.

**Birmingham, 1963.** A bomb exploded under the steps of the 16th Street Baptist Church in Birmingham, Alabama, on September 15, 1963. It killed four girls: Addie Mae Collins, 14, Denise McNair, 11, Carole Robertson, 14, and Cynthia Wesley, 14. Klan members had set it.

FBI agents named Robert Chambliss as the main suspect. FBI Director J. Edgar Hoover closed the case in 1968 without charging anyone and ordered the evidence sealed. Chambliss was convicted in 1977. Thomas Blanton was convicted in 2001 and Bobby Frank Cherry in 2002, with the help of secret FBI recordings made in 1964. Another suspect died before he could be tried.

**Neshoba County, 1964.** Local police in Neshoba County, Mississippi, jailed three civil rights workers for "speeding" on June 21, 1964. They were James Chaney, 21, a Black college student from Mississippi, and Andrew Goodman, 20, and Michael Schwerner, 24, white men from New York. After dark the police let them go "into the hands of the Ku Klux Klan." The three were stopped again, forced into a sheriff's car, driven to a country road and shot dead.

A federal jury convicted seven of the 18 men charged, among them a deputy sheriff and the head of a Mississippi Klan group. The verdict came on October 20, 1967, and the sentences ran from three to ten years. Edgar Ray Killen, a Klan leader and former preacher who had organized the killings, went free because one juror would not convict a preacher. A jury in Mississippi convicted Killen of manslaughter, killing a person without planning to murder, on June 21, 2005, and he died in prison in 2018.

**Marion, Alabama, 1965.** Alabama State Trooper James Bonard Fowler shot Jimmie Lee Jackson, 26, in the stomach in a cafe in Marion in February 1965, and Jackson died eight days later. Fowler pleaded guilty in 2010 to misdemeanor manslaughter, a lesser charge for killing a person. He was sentenced to six months and served five.

**Selma, 1965.** Four men in Selma attacked James Reeb, a minister from Boston, in March 1965. One of them struck him in the head with a club, and Reeb died two days later. The prosecutor let a man whose brother was a suspect sit on the jury, and the jury found all three men tried not guilty.

**Highway 80, Alabama, 1965.** Three Klan members shot and killed Viola Liuzzo, a mother of five from Detroit, on March 25, 1965, as she drove on Highway 80. A paid FBI informer rode in their car. An informer is a person who secretly passes information to the police or the FBI. State juries did not convict the three men. Federal juries convicted all three of violating her civil rights, and each got 10 years in prison.

In these six cases, every conviction came from a federal jury or came 14 to 45 years after the killing. No one was ever convicted of killing James Reeb.

### Attica, September 1971

About 1,281 of the roughly 2,200 men held at Attica, a New York state prison, took over the prison on September 9, 1971. They held 42 guards and other workers as hostages. In July the prisoners had made demands about food, mail, medical care and parole. During the takeover someone beat a guard, William Quinn, and he died. Governor Nelson Rockefeller refused to come to the prison.

**Retaking the prison.** Officers dropped tear gas into the prison yard at 9:46 in the morning on September 13. State troopers, deputies and guards fired into the smoke, some with shotguns loaded with buckshot. They killed at least 39 people: 29 prisoners and 10 of the hostages. Counting the whole four days, 43 people died.

Rockefeller and other officials first said the prisoners had cut the hostages' throats. The medical examiners, the doctors who examine bodies after a death, found that the hostages had died of gunshot wounds from the officers' guns. Afterward, prison officers tortured prisoners who had survived. Pages of an official report released in 2015 describe torture, burning and sexual abuse.

**Who was charged.** Prosecutors charged 62 prisoners with 1,289 crimes. They charged one state trooper, for reckless endangerment, putting people in danger through carelessness. A jury found the prisoner John Hill guilty of murdering William Quinn on April 5, 1975, and found another prisoner, Charley Joe Pernasilice, guilty of assault in Quinn's death.

Governor Hugh Carey pardoned the prisoners who had pleaded guilty in December 1976. Hill received clemency, a governor's mercy that cut his punishment short, about a year after his trial. New York State officials paid $8 million in settlements to prisoners and their families in 2000 and $12 million to the families of the prison workers in 2005.

### Executions stop and start again, 1972 to 1999

Five of the nine justices struck down the death-penalty laws then in use on June 29, 1972, in *Furman v. Georgia*. More than 600 people were on death row, waiting to be executed. Justice Potter Stewart wrote that the death sentences were "cruel and unusual in the same way that being struck by lightning is cruel and unusual." Being struck by lightning happens to very few people, by chance.

Lawmakers in 35 states and in Congress wrote new death-penalty laws in the next four years. The justices allowed them on July 2, 1976, in *Gregg v. Georgia*.

Gary Gilmore murdered Max Jensen, 25, a gas station worker, on July 19, 1976, and Bennie Bushnell, 26, a motel manager, the next night, in Utah. He asked to be executed. At 8:07 in the morning on January 17, 1977, a firing squad shot him at the Utah State Prison. A firing squad is a group of shooters who fire rifles at the prisoner's heart. There were five shooters, and prison officials said one of them had a blank. Gilmore was the first person executed after the 1976 ruling.

Texas officials carried out the first execution by lethal injection on December 7, 1982. Lethal injection means killing a person with drugs put into a vein through a tube in the arm. The Death Penalty Information Center, a group that collects facts about the death penalty, describes the usual three-drug method. The first drug puts the person to sleep, the second stops the muscles from moving, which stops the breathing, and the third stops the heart. Some states later used a single large dose of a drug such as pentobarbital.

New death sentences reached their highest number, 325, in 1986. Executions rose to 98 in 1999, the most in any year since 1976.

### Wounded Knee, 1973: the marshals and the trial

Members of the American Indian Movement took over the village of Wounded Knee, South Dakota, on February 27, 1973, and held it for 71 days. The movement had begun in Minneapolis in 1968, when its members patrolled the streets to watch for police abuse of Native people.

About 200 Oglala Lakota and movement members held the village. They were protesting against the head of the tribal government on the Pine Ridge Reservation and against the treaties the United States had broken. They chose Wounded Knee because soldiers of the 7th Cavalry had killed between 250 and 300 Lakota there in 1890. US marshals, FBI agents and other federal officers surrounded the village with armored vehicles and automatic weapons.

**The shootings.** Someone opened fire on a group of US marshals on the night of March 16. A bullet hit one of them, Lloyd Grimm, and left him paralyzed from the waist down. The Associated Press reported in 2000 that no suspects were ever found.

A bullet hit Frank Clearwater, an Eastern Cherokee man inside the village, in the head on April 17, and he died on April 25. The FBI released a report on deaths on the Pine Ridge Reservation, where Wounded Knee lies, in 2000. It found that Clearwater was killed by gunfire from federal officers, who were firing back after people shot at them.

A federal sniper shot and killed Lawrence "Buddy" Lamont, an Oglala man, on April 26. The FBI report gives the date as April 27 and says he died in a gunfight with federal officers at a roadblock. A US attorney, a federal prosecutor, reviewed his killing and charged no one.

Federal prosecutors charged the movement's leaders, Dennis Banks and Russell Means, for their part in the takeover. After their trial had run for eight and a half months, US District Judge Fred Nichol threw out the charges in 1974. He wrote that "the misconduct by the government in this case is so aggravated that a dismissal must be entered in the interests of justice." Aggravated here means serious.

### Drug laws and long sentences, 1973 to 1994

Lawmakers wrote the long sentences that filled the prisons. Some of those sentences were mandatory minimums. A mandatory minimum is the shortest sentence a law allows for a crime, and a judge cannot give less.

New York's lawmakers passed Governor Nelson Rockefeller's drug laws in 1973. Selling two ounces or having four ounces of heroin, cocaine or marijuana brought 15 years to life in prison.

The basketball player Len Bias died from cocaine on June 19, 1986. House Speaker Tip O'Neill had Democratic leaders write a new federal drug law, and the Republicans who then ran the Senate passed their own. President Ronald Reagan signed the law on October 27, 1986.

**Crack and powder.** Under that law, 5 grams of crack cocaine brought at least five years in federal prison, the same sentence as 500 grams of powder cocaine. Crack is a form of cocaine that is smoked. A person with crack faced the same sentence as a person with 100 times as much powder.

Staff of the US Sentencing Commission reported that in 1992, about 91 of every 100 people sentenced in federal court for crack were Black, and about 3 were white. In 2004, of the people who entered treatment for crack, 53 of every 100 were Black and 38 were white.

Members of Congress passed the largest crime law in the country's history in 1994. Representative Jack Brooks of Texas sponsored it in the House. Senator Joe Biden of Delaware wrote the Senate version, and President Bill Clinton signed it. The law provided money for 100,000 new police officers and $9.7 billion for prisons. Under it, 60 more federal crimes could be punished by death, and people in prison could no longer get federal college grants.

**By 1994:** Five grams of crack brought the same five-year federal sentence as 500 grams of powder cocaine, and members of Congress had voted money for 100,000 new police officers and $9.7 billion for prisons.

### Kemba Smith

> **Who:** A college student sentenced to 24 and a half years in federal prison for a crack cocaine ring run by a man who beat her, though she never sold or used drugs.
>
> **When and where:** Virginia, and federal prison, 1994 to 2000.
>
> **Movie:** *Kemba* (2024), a film about her life, shown on BET+.

**A first-time offender, she got 24 and a half years, no parole.**

Kemba Smith grew up near Richmond, Virginia, and went to Hampton University. There she met Peter Hall, who ran a crack cocaine ring. The NAACP Legal Defense Fund, a group of civil rights lawyers, states that she was a victim of his violence at home.

She turned herself in to federal agents on September 1, 1994. She pleaded guilty to conspiracy to sell cocaine, to lying to federal agents and to conspiracy to launder money. Conspiracy means agreeing with others to commit a crime, and to launder money means to hide where money from crime came from.

The NAACP Legal Defense Fund states that she never sold or used drugs, and that federal prosecutors still charged her with conspiracy to sell cocaine. Federal judge Richard B. Kellam sentenced her to 24 years and 6 months in federal prison, with no parole.

She was pregnant during her case. She said of her son, "I had two days with him before giving him to my parents."

President Bill Clinton cut her sentence short on December 22, 2000, after about six and a half years in prison. The Clinton Library describes her as "a first time non-violent drug offender." President Joe Biden pardoned her on January 19, 2025.

### How many people were in prison

Officials of the Bureau of Justice Statistics have counted prisoners since 1925. These are their counts of people in state and federal prisons:

- 1950: about 166,000
- 1972: about 196,000
- 1990: about 771,000
- 2000: about 1.38 million

From 1950 to 1972 the count rose by about 30,000. Then it began to climb in 1974, and by 2000 it was about seven times the count of 1972. The share of Americans in prison grew more than four times over: about 1 of every 1,000 Americans in 1950, and almost 5 of every 1,000 in 2000.

In 2000, almost 10 of every 100 Black men aged 25 to 29 were in prison, against about 1 of every 100 white men that age.

### Killed for his shoes, 1989

James David Martin, 17, killed Michael Eugene Thomas, 15, for his basketball shoes in 1989. Martin pleaded guilty to a lesser charge than murder and got seven years in prison. After his release he killed two more people.

Thomas was a ninth grader at Meade Senior High School in Anne Arundel County, Maryland. He had bought the shoes, Air Jordans, for $115.50. On May 2, 1989, Martin led him into the woods near the school and strangled him to death. Then Martin took the shoes and ran. The *New York Daily News*, the *New York Times*, the *New York Post* and *Sports Illustrated* reported that Martin raped the boy before he killed him.

**Seven years.** The school stood on federal land, so Martin was tried in federal court. He pleaded guilty to voluntary manslaughter, a charge for killing that is less serious than murder, and he was sentenced to seven years in prison. In May 1990 *Sports Illustrated* ran a cover story by Rick Telander called "Your Sneakers or Your Life."

**Two more killings.** Martin was released in 1996 and moved to New York City. In the Bronx on February 23, 1998, he beat 14-year-old Marleny Cruz and strangled her to death. In 2005 he murdered his wife, Cicela Santiago, in Allentown, Pennsylvania, and he was sentenced there to 22 to 40 years in prison.

Bronx detectives matched DNA from under Cruz's fingernails to Martin in 2011. He pleaded guilty to manslaughter in her killing in 2016 and got 20 more years. The Bronx district attorney said the plea was for "raping and strangling" her.

### Rodney King, 1991 and 1992

Los Angeles police officers Laurence Powell, Timothy Wind and Theodore Briseno and Sergeant Stacey Koon shocked Rodney King with a Taser, a weapon that fires an electric shock, early on March 3, 1991, after a car chase. They hit him with their batons while other officers watched. Police Chief Daryl Gates said the officers struck him "between fifty-three and fifty-six times." King had a broken bone in his face, a broken right ankle, and bruises and cuts. George Holliday filmed the beating from his apartment.

The trial was moved to Simi Valley, in Ventura County. The jury included ten white jurors. The jurors found all four officers not guilty of assault on April 29, 1992, and they could not agree on one charge against Powell. Rioting spread across Los Angeles from April 29 to May 3. One count gives 63 dead and another gives 55. Police or National Guard soldiers shot 10 or 11 of them. More than 12,000 people were arrested.

A federal jury convicted Koon and Powell of violating King's civil rights in 1993, and each got 30 months in prison. The jury found Wind and Briseno not guilty. King won $3.8 million from the city of Los Angeles.

### Two deaths at police hands in New York, 1983 and 1999

**Michael Stewart, 1983.** New York City Transit Police officers arrested Michael Stewart, 25, a Black graffiti artist, at the First Avenue subway station on September 15, 1983, for writing graffiti. In their custody he was beaten unconscious. He was hogtied, his ankles bound and his hands tied to his feet with an elastic strap. The account of his death does not name which officers struck him.

He reached Bellevue Hospital in a coma and died on September 28, after 13 days. The cause of death was listed as cardiac arrest, which means the heart stopped. The city's medical examiner, Elliot Gross, gave three different findings, among them an injury to the neck and blows to the body. Doctors hired by Stewart's family found that he had been strangled.

Six officers were tried for criminally negligent homicide, causing a death through carelessness, and for assault and perjury, lying under oath. An all-white jury found them not guilty on November 24, 1985. A lawsuit against eleven officers and the transit authority ended with a payment of $1.7 million.

**Amadou Diallo, 1999.** Four New York City police officers in plain clothes, Sean Carroll, Richard Murphy, Edward McMellon and Kenneth Boss, fired 41 shots at Amadou Diallo outside his building in the Bronx on February 4, 1999. Diallo, 23, was an immigrant from Guinea. Nineteen of the shots hit him and killed him. He had no gun, and he had taken out his wallet.

The officers were charged with second-degree murder, and the trial was moved to Albany. A jury found all four not guilty on February 25, 2000. City officials paid his family $3 million in 2004.

### The wrong man: DNA and the Central Park case

DNA is the chemical code inside the cells of a living body, and it differs from person to person. Cells left at a crime can be tested to show whether they came from a certain person.

**Kirk Bloodsworth.** A Maryland jury convicted Kirk Bloodsworth in 1985 of the 1984 rape and murder of Dawn Hamilton, a nine-year-old girl in Rosedale, Maryland. The jury convicted him on the word of five witnesses, and he was sentenced to death.

A DNA test in 1993 showed that the attacker's cells, saved in a paper bag in the judge's chambers, were not his. He was freed after more than nine years in prison, and Governor William Donald Schaefer pardoned him. He was the first person on death row in the United States cleared by DNA. In 2003 the cells were matched, through a DNA database, to Kimberly Shay Ruffner, who had been held in a cell one floor below Bloodsworth. Ruffner pleaded guilty in 2004.

The lawyers Barry Scheck and Peter Neufeld had founded the Innocence Project, a group that uses DNA tests to free people who were wrongly convicted, at Cardozo Law School in New York in 1992, a year before Bloodsworth was cleared.

**Central Park, 1989.** A man attacked and raped Trisha Meili on April 19, 1989, while she was running in Central Park in New York City. Police questioned five teenagers for at least seven hours before recording their statements on video. They were Antron McCray, 15, Kevin Richardson, 14, Yusef Salaam, 15, Raymond Santana, 14, and Korey Wise, 16.

Four of them confessed on video, then took it back within weeks, saying the police had lied to them and pressured them. The DNA found at the scene matched none of the five. Donald Trump paid for full-page ads in four New York newspapers on May 1, 1989, calling for the death penalty. The ads named no defendant. Juries convicted all five teenagers in 1990.

**If you remember one thing:** The justices gave accused people new protections in the 1960s, and from the 1970s lawmakers wrote the long sentences that filled the prisons.

In 1960: Police did not have to warn a suspect that he could stay silent or have a lawyer.

In 2000: Police had to give that warning before questioning, and prisons held about seven times as many people as in 1972.

**Next:** In 2002 a judge cleared the five teenagers from Central Park, and after 2009 the prison count began to fall for the first time since 1972.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 18 minutes**

American prisons held about 1.62 million people at the end of 2009, the most ever counted. Then the count fell for the first time since 1972, and by the end of 2023 it was about 1.25 million. The gap between Black and white Americans stayed wide: Black Americans were in prison at almost five times the rate of white Americans in 2023.

Judges and governors cleared thousands of people of crimes they had not committed. Police killed more than a thousand people a year in 2024 and 2025, by one group's count. Some officers were charged and convicted, and others were never charged, or juries found them not guilty. Murders jumped in 2020, then fell, and the 2025 murder rate tied the lowest the FBI has recorded.

### Fewer prisoners, a gap that shrank but stayed wide

The prison count reached 1,617,970 at the end of 2009, the highest in the Bureau of Justice Statistics count, which goes back to 1925. It fell in 2010 for the first time since 1972.

**Shorter drug sentences.** Lawmakers also cut some of the long drug sentences. New York's lawmakers ended the Rockefeller minimum sentences in April 2009. Senator Dick Durbin of Illinois wrote the Fair Sentencing Act, and President Barack Obama signed it on August 3, 2010. Under the new law, it took 28 grams of crack, not 5, to bring the five-year minimum, so the gap between crack and powder cocaine sentences went from 100 to 1 down to 18 to 1.

Under the First Step Act, which President Donald Trump signed on December 21, 2018, that change reached people already in prison. In its first year, more than 2,000 federal prisoners got shorter sentences under the crack change, and more than 3,000 were let out under changed rules for time off for good behavior.

**The gap.** About 1,254,000 people were in state and federal prisons at the end of 2023, and about 657,500 more were in local jails in the middle of 2024, by the bureau's count. For every 100,000 Black Americans, 929 were serving prison sentences in 2023. For every 100,000 white Americans, 190 were. Ten years earlier, in 2013, the two rates had been 1,348 and 237.

A conviction for a felony can also take away a person's right to vote. About 4 million Americans could not vote in 2024 because of a felony conviction, including 1 in every 22 Black adults, by the count of the Sentencing Project, a group that studies prisons and sentences.

### The Exonerated Five

> **Who:** Five New York City teenagers convicted in 1990 of a rape in Central Park, cleared in 2002 when another man confessed and his DNA matched.
>
> **When and where:** New York City, 1989 to 2014.
>
> **Movie:** *When They See Us* (2019), a Netflix drama series directed by Ava DuVernay. *The Central Park Five* (2012) is a documentary by Ken Burns, Sarah Burns and David McMahon.

**Another man confessed in 2002, and his DNA matched.**

Antron McCray, Kevin Richardson, Yusef Salaam, Raymond Santana and Korey Wise were 14 to 16 years old when juries convicted them in 1990 of the attack on Trisha Meili in Central Park. Another man had committed the rape alone.

Judge Thomas Galligan sentenced the four younger boys to 5 to 10 years in custody for young people. Wise, who was 16, was tried as an adult. His jury found him not guilty of rape and attempted murder and guilty of sexual abuse, assault and riot. He was sentenced to 5 to 15 years in an adult prison. Santana was released in 1995, McCray in 1996, and Salaam and Richardson in 1997.

A prisoner named Matias Reyes met Wise at Auburn prison in New York in 2001. Reyes was serving a life sentence for other rapes. He told officials in 2002 that he had raped Trisha Meili and that he had acted alone. A DNA test matched him. Wise was released in August 2002, after about 13 years locked up.

Prosecutors in District Attorney Robert Morgenthau's office looked into the case again and asked the court to throw out the convictions. Justice Charles Tejada vacated, or cancelled, all five convictions on December 19, 2002.

A panel chosen by Police Commissioner Raymond Kelly accepted the DNA result in January 2003 but said the five had "most likely" also taken part in the attack. Justice Tejada and the district attorney did not accept that view. Reyes was never charged for the attack on Meili, because the five-year time limit for charging the crime had passed.

New York City officials paid the five $41 million in 2014 to settle their lawsuit. Four of them got about $7.1 million each. Wise got $12.2 million, because he had served six more years than the others.

### Proving convictions wrong

An exoneration means a judge or a governor has cleared a person of a crime after a conviction, because new evidence shows the person did not do it. The National Registry of Exonerations counted 3,767 exonerations in the United States from 1989 through the end of 2025. The Innocence Project states that DNA tests helped in more than 600 of them.

Ninety-seven people were exonerated in 2025 alone. On average each of them had lost 14.2 years in prison, and 59 of the 97 were Black. In at least 70 of the cases, police, prosecutors or other officials had broken the rules, which the Registry calls official misconduct. Payments to people who were cleared have added up to more than $5.5 billion since 1989. The National Registry of Exonerations gave these figures in its 2026 report.

**George Stinney Jr.** A judge threw out the conviction of George Stinney Jr., a 14-year-old Black boy, in 2014, seventy years after South Carolina officials executed him. Two white girls, Betty June Binnicker, 11, and Mary Emma Thames, 8, were killed in Alcolu, South Carolina, on March 22, 1944. Stinney was accused. He was tried, convicted and sentenced to death in one day in April 1944, and the all-white jury took less than ten minutes.

Governor Olin Johnston refused to spare him, and South Carolina officials put him to death in the electric chair on June 16, 1944. Judge Carmen Mullen threw out his conviction on December 16, 2014. She ruled that he had not had a real defense and that his confession had probably been forced. No court has named anyone else as the killer.

### The death penalty, 2000 to 2026

Executions in the United States fell from 85 in 2000 to 11 in 2021, then rose to 47 in 2025. Officials had carried out 27 executions in 2026 by September 18. Judges and juries handed down 23 new death sentences in 2025, and 2,024 people were on death row on October 1, 2025. Twenty-three states have no death penalty. The Death Penalty Information Center gave these figures in September 2026.

Officials in the United States have carried out 1,681 executions since 1977. They killed 1,490 of those people by lethal injection. They killed the rest by electrocution, in gas chambers, sealed rooms filled with poison gas, by firing squad or by hanging.

**The victims.** Of the victims in the crimes behind these executions, 76 of every 100 were white and 14 were Black. Of all murder victims in the United States from 1985 to 2023, about 49 of every 100 were white and 47 were Black, by FBI counts. A killing was far more likely to end in an execution when the person killed was white.

The justices of the Supreme Court ruled in 2002 that states may not execute people with intellectual disabilities, a lasting limit on a person's ability to learn and reason. They ruled in 2005 that states may not execute people for crimes committed before age 18.

**Cleared from death row.** The Death Penalty Information Center counts more than 200 people sentenced to death since 1973 who were later cleared and freed.

The group's staff also list 21 people executed since 1976 who, they say, may have been innocent. Among them are Cameron Todd Willingham, executed in Texas in 2004, and Troy Davis, executed in Georgia in 2011. No court or governor has declared any of the 21 innocent. The group notes that courts do not usually hear a claim of innocence once the person is dead.

### The Danziger Bridge, New Orleans, 2005

New Orleans police officers shot six unarmed Black people on the Danziger Bridge on September 4, 2005, in the days after Hurricane Katrina. They killed James Brissette, 17, and Ronald Madison, 40, who was shot in the back. Among the officers were Kenneth Bowen, Robert Gisevius, Anthony Villavaso and Robert Faulcon. The officers then worked to cover up what they had done.

Officers were convicted in 2011. Federal Judge Kurt Engelhardt threw out those convictions in September 2013 and ordered a new trial, pointing to what he called "highly unusual, extensive and truly bizarre actions" by the prosecutors. Five former officers pleaded guilty on April 20, 2016, and they were sentenced to 3 to 12 years in prison.

In a separate case, Roland Bourgeois Jr., 55, of the Algiers Point neighborhood, was sentenced in 2019 to 10 years in prison. He had shot three Black men who were trying to flee the area.

### Police killings and what happened in court

No government agency keeps a full count of the people police kill. Campaign Zero, a group that campaigns for a cause, counted at least 1,383 people killed by police in 2024 and 1,314 in 2025. By its count, police killed Black Americans at 2.6 times the rate of white Americans in 2025. In 2020, 62 of every 100 local police departments used body cameras, cameras worn on an officer's uniform, the Bureau of Justice Statistics reported in 2023.

Officer Darren Wilson shot and killed Michael Brown, 18, in Ferguson, Missouri, on August 9, 2014. A St. Louis County grand jury did not charge Wilson. Federal prosecutors did not charge him in 2015, and in 2020 the county prosecutor, Wesley Bell, reviewed the case and did not charge him either.

**The Ferguson report.** Lawyers of the US Department of Justice reported on the Ferguson police on March 4, 2015. They found a "pattern or practice of unlawful conduct" that broke the First, Fourth and Fourteenth Amendments, which protect free speech, protect people from unfair searches and arrests, and promise equal treatment under the law. Police there had broken the law again and again, in ways that went against rights the Constitution protects.

The city's finance director had written to the police chief in 2010 that "unless ticket writing ramps up significantly," it would be hard to raise more money the next year. Of the city court's 2013 cases in which a judge issued an arrest warrant, an order to arrest someone, 92 of every 100 were against Black people.

The report describes a 32-year-old Black man who sat in his parked car in a park in the summer of 2012. An officer blocked in his car and demanded his Social Security number. The officer accused him, with no cause, of being a pedophile, a person who wants to sexually abuse children. When the man spoke of his rights, the officer arrested him at gunpoint on eight city charges.

One charge was for giving his name as "Mike" instead of "Michael." Another was for not wearing a seat belt while sitting in a parked car. The man told investigators he lost his job doing work for the federal government because of the charges.

Officer Daniel Pantaleo killed Eric Garner, 43, on Staten Island, New York, on July 17, 2014. Pantaleo held him around the neck in a chokehold, which police rules banned. Garner said "I can't breathe" 11 times. The medical examiner ruled his death a homicide, a killing by another person. A grand jury did not charge Pantaleo. In July 2019 Attorney General William Barr decided against federal charges, and in August 2019 Police Commissioner James O'Neill fired Pantaleo.

Tamir Rice, 12, was holding a toy gun at a park in Cleveland on November 22, 2014. The person who called 911 said twice that the gun was "probably fake" and the person "probably a juvenile," meaning a young person. The dispatcher, the worker who sent the call to the officers, did not pass that on. Officer Timothy Loehmann shot Tamir almost as soon as he arrived and killed him. A grand jury did not charge Loehmann. Loehmann was fired in 2017 for lying on his job application.

**Breonna Taylor.** Officers in Louisville, Kentucky, forced open Breonna Taylor's door on March 13, 2020, with a warrant to search for drugs. Her boyfriend, Kenneth Walker, fired once and hit officer Jonathan Mattingly. Officers fired 32 shots, and Myles Cosgrove fired the shot that killed Taylor, who was 26. A grand jury did not charge Mattingly or Cosgrove.

A former detective, Kelly Goodlett, pleaded guilty in 2022 to helping put false facts on the warrant. A federal jury convicted Brett Hankison in November 2024 of using excessive force, more force than the law allows. His shots hit no one. He was sentenced to 33 months in July 2025. Louisville's city officials paid $12 million.

**George Floyd.** Officer Derek Chauvin knelt on George Floyd's neck in Minneapolis for more than nine minutes on May 25, 2020, and killed him. Floyd was 46. A jury convicted Chauvin of second-degree murder, third-degree murder and second-degree manslaughter, different levels of charges for causing a death, on April 20, 2021. Judge Peter Cahill sentenced him to 22 and a half years on June 25, 2021. The state's sentencing rules set 12 and a half years, and the judge gave more after finding "particular cruelty."

Chauvin also pleaded guilty to a federal crime, and Judge Paul Magnuson sentenced him to 21 years for it in July 2022, served at the same time as the state sentence. The three other officers got federal sentences: Thomas Lane 2 and a half years, J. Alexander Kueng 3 years and Tou Thao 3 and a half years. Minneapolis city officials paid Floyd's family $27 million.

**Tyre Nichols.** Five police officers in Memphis, Tennessee, pulled Tyre Nichols, 29, from his car on January 7, 2023. They were Tadarrius Bean, Demetrius Haley, Emmitt Martin III, Desmond Mills Jr. and Justin Smith. They sprayed him with pepper spray and shocked him with a Taser. When they caught him near his mother's house, they punched him, kicked him and beat him with a baton. He died on January 10 of injuries to his head.

Mills and Martin pleaded guilty. A federal jury convicted Haley on all counts in October 2024, and Bean and Smith only of trying to influence witnesses. A state jury found Bean, Haley and Smith not guilty of all state charges, including murder, in May 2025. Judge Sheryl Lipman ordered a new federal trial for the three in August 2025, because the first judge may have been biased. No new verdict had been reported by September 2026.

### Who was charged after school shootings

After some shootings at schools, prosecutors charged officers who did not act, or a parent who supplied the gun.

**Parkland.** Nikolas Cruz, 19, a former student, shot and killed 14 students and three staff members at Marjory Stoneman Douglas High School in Parkland, Florida, on February 14, 2018, and wounded 17 others. The report of a Florida state commission states that Deputy Scot Peterson "fled to a position of personal safety while Cruz shot and killed" students and staff. A jury found Peterson not guilty of felony child neglect and other charges on June 29, 2023.

**Uvalde.** A gunman killed 19 children and two staff members at Robb Elementary School in Uvalde, Texas, on May 24, 2022. Officers killed the gunman 77 minutes after the first officers entered the school. A Department of Justice review states that the school district police chief, Pete Arredondo, told officers at several points to wait. A grand jury charged Arredondo and a former school officer, Adrian Gonzales, with child abandonment and endangerment. A jury found Gonzales not guilty of all 29 counts on January 21, 2026.

**Winder, Georgia.** A gunman killed two 14-year-old students and two teachers at Apalachee High School in Winder, Georgia, on September 4, 2024. The gunman, Colt Gray, pleaded guilty to all 55 counts, and he was sentenced to life in prison without parole on July 27, 2026. His father, Colin Gray, had given him the AR-15-style rifle as a Christmas present. A jury convicted Colin Gray of two counts of second-degree murder and other crimes on March 3, 2026, and he was sentenced to 15 years on July 30, 2026.

### Crime goes up, then down

Murders in the United States rose from 16,669 in 2019 to 21,570 in 2020, up 29 percent. The Pew Research Center, using FBI data, called it the largest one-year rise in more than a century. The murder rate in 2020 was 7.8 for every 100,000 people, still lower than the rate of 10 in 1991.

The violent crime rate dropped 9.3 percent from 2024 to 2025, from 362.9 to 327.6 for every 100,000 people. FBI officials called it the largest one-year drop since the bureau began making national estimates in 1936. Murders fell about 18 percent, robberies 18.5 percent and property crimes 12.4 percent. The 2025 murder rate, 4.1 for every 100,000 people, tied 1955 and 1956 as the lowest the FBI has recorded. FBI officials released these figures in August 2026.

### Leaders in court

A jury in Manhattan convicted former President Donald Trump of 34 felonies on May 30, 2024. The charges were for falsifying business records to hide a payment of hush money, money paid to keep someone quiet, to Stormy Daniels. He was the first US president convicted of a felony. Judge Juan Merchan sentenced him on January 10, 2025, to an unconditional discharge, which means no jail, no fine and no probation. His appeal had not been decided by September 2026.

A federal jury convicted Senator Bob Menendez of New Jersey on July 16, 2024, of taking bribes, secret payments for favors, and of acting as an agent of Egypt's government, which means working for it in secret. Agents had found $480,000 in cash and more than $100,000 in gold bars in his home. He resigned in August 2024, and on January 29, 2025, a judge sentenced him to 11 years in prison.

President Trump pardoned, on January 20, 2025, everyone convicted over the attack on the US Capitol on January 6, 2021, with one exception. The Government Accountability Office found that about 140 police officers were attacked that day. For fourteen members of two groups, the Oath Keepers and the Proud Boys, he cut their sentences to the time they had already served.

### Whose courts: McGirt, 2020

Five of the nine Supreme Court justices ruled on July 9, 2020, in *McGirt v. Oklahoma*, that the Muscogee (Creek) reservation had never been ended. Members of Congress had set that land aside for the nation in the 1800s. Justice Neil Gorsuch wrote the opinion.

US officials forced the Muscogee (Creek), the Cherokee and three other nations from their homelands in the Southeast to Indian Territory, which is now Oklahoma, in the 1830s. Those forced removals are called the Trail of Tears. Gorsuch's opinion begins: "On the far end of the Trail of Tears was a promise." Under the ruling, Oklahoma's prosecutors could not charge Native people for major crimes there, and federal and tribal courts took those cases.

Jimcy McGirt, a Seminole citizen, had been convicted in a state court of sexually abusing his wife's granddaughter. A federal jury convicted him after the ruling, in November 2020.

The judges of Oklahoma's highest criminal court then applied the same reasoning to the lands of other nations. As a result, almost all of eastern Oklahoma, including much of Tulsa, counts as Indian country, the legal name for Native land, in criminal cases. The justices ruled in 2022, in *Oklahoma v. Castro-Huerta*, that state prosecutors may also charge people who are not Native for crimes against Native victims there.

### Tulsa's survivors, 2020 to 2026

No white person was ever sent to prison for the 1921 Tulsa massacre. Survivors of the massacre sued the city, the county and state bodies in 2020. Tulsa County Judge Caroline Wall dismissed the case in July 2023, and the justices of the Oklahoma Supreme Court upheld her ruling in June 2024.

Viola Ford Fletcher was 7 in 1921. She spoke to Congress on May 19, 2021, and died on November 24, 2025, at 111. Lessie Benningfield Randle, born on November 10, 1914, was the last known living survivor in May 2026.

Tulsa's mayor, Monroe Nichols, announced the Greenwood Trust on June 1, 2025, a private fund with a goal of $105 million by June 1, 2026. The plan listed $24 million for housing, $60 million for buildings and for clearing blight, which means run-down property, and $21 million for land, scholarships and grants to small businesses. It included no direct payments to the survivors. No total raised had been published by September 2026.

**If you remember one thing:** The prison count began to fall after 2009, but Black Americans were still in prison at almost five times the rate of white Americans in 2023.

- 2009: State and federal prisons held 1,617,970 people, the most ever counted.
- 2021: A jury convicted Officer Derek Chauvin of murdering George Floyd.
- 2025: Ninety-seven people were cleared of crimes they had not committed, and the murder rate tied the lowest the FBI has recorded.

**Next:** The chapter closing answers the three questions from the opening.

**The three questions, answered**

- How did punishment move from the whipping post to the prison cell? Colonial judges had people whipped, branded and hanged in public, and had their ears cut off. Pennsylvania's lawmakers turned the Walnut Street Jail into the country's first state prison in 1790, and by 2009 American prisons held about 1.62 million people.
- Who kept order before there were police? Among the Native nations, families and clans settled killings, and in the colonies settlers took turns on a night watch while white men in the South rode on slave patrols. Full-time police began work in Boston in 1838 and in New York in 1845, and the US attorney general put 34 federal agents to work in 1908.
- What happened to the people in mobs who killed without a trial? In almost every case the chapter describes, nobody punished them. No one was charged for killing twenty Conestoga people in 1763, for burning Francis McIntosh in 1836 or for burning Henry Smith in 1893, and no white person went to prison for the attack on Greenwood, the Black district of Tulsa, in 1921.

**What changed:** The chapter begins with families settling a killing life for a life and ends with about 1.25 million people in state and federal prisons. From the first colonial courts on, whether a person got a fair trial depended on who that person was.

**Five dates to keep**

- 1631: Massachusetts judges order settlers to keep a night watch.
- 1790: The Walnut Street Jail becomes the first state prison.
- 1893: A white mob burns Henry Smith to death in Paris, Texas.
- 1963: The justices rule that a poor person charged with a serious crime must get a lawyer.
- 2009: The prison count reaches its highest point, 1,617,970.

**Not known:** Nobody knows how many people the attackers killed in Tulsa in 1921, and the estimates run from 50 to 300.

**Where to go:** Eastern State Penitentiary in Philadelphia, where Charles Williams became Prisoner Number 1 in 1829, is now a historic site.

**Next:** Chapter 22, War and the Military. It follows the wars the country fought, the draft, and the soldiers and veterans.
