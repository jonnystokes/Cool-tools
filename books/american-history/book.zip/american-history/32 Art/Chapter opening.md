**Part 9: Culture and Play**

# Chapter 32: Art

**Chapter 32 of 37 · Art · 10 eras · about 155 minutes**

**Who was allowed to make art in America, who got paid for it, and who ended up owning it has always depended on who held power.**

An enslaved potter in South Carolina named Dave cut two lines into a big clay jar in 1857. They use lucre, an old word for money: "I made this Jar = for cash / Though its called Lucre trash." Dave was not paid for that jar. It was sold for the profit of the man who held him, Lewis J. Miles. On October 29, 2025, the Museum of Fine Arts in Boston gave Dave's descendants ownership of it and of a second jar he made that year.

This chapter follows the pictures, carvings, pots, photographs and books made in this land, from Ancestral Pueblo bowls to pictures made by computer programs. Keep an eye on the names. The carvers of the Ohio pipes left none, but the men who dug up, bought and sold such work often did. Then watch the money. Enslaved painters and potters earned it for other men, the mother in the 1936 photograph *Migrant Mother* never got a penny, and artists today are suing over computer programs built from their pictures. From the 1800s on, the fights are also about who gets into art schools, museums and shows.

**Three questions this chapter answers**

- How did enslaved artists make art, and who got paid for it?
- Who decided what counted as art, and who got to see it?
- Why are museums giving back things they once took?

**Five minutes?** Read "Photographs of hunger, and photographs of the camps" in 1900 to 1950, and the Lange box after it.

**Can skip:** "Portrait painters in the colonies", "Writers", "Painters of the 1930s and 1940s", "A camera in every pocket". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 9 minutes**

Every pot, carving and copper plate made in this land before 1500 was made by Native people, and no surviving record names the people who made them. Potters in the Southwest painted bowls and jars. Carvers in the Ohio valley shaped stone pipes into birds and animals. In the towns of the Mississippi valley and the Southeast, metalworkers hammered copper into sheets and pressed pictures into it, and on the Northwest Coast people carved bone, horn and stone.

Many of the objects that survive were buried with the dead in graves and mounds. In the 1800s and 1900s, diggers took them out of the ground, and many of those diggers sold what they found.

### How did Ancestral Pueblo potters paint a pot?

Ancestral Pueblo potters painted black designs over the white of the clay, and the pottery is now called black-on-white. The Ancestral Pueblo people were the ancestors of today's Pueblo nations. A potter rolled clay into a long snake and coiled it around in a spiral to build up the pot. Then the potter scraped the coils together until the sides were smooth.

The black paint came from boiled plants, such as beeweed or tansy mustard, or from crushed rock with iron in it, such as hematite. Potters made their brushes from the fibers of the yucca plant. At Mesa Verde, people made this pottery from about the year 600 to about 1300.

**Bowls with a hole.** In the Mimbres valley of southwestern New Mexico, potters painted bowls from about 1000 to 1130 or 1150. Most of these bowls have been found in graves. Archaeologists, the scientists who dig up and study the things people left behind, think people set a bowl over the dead person's face or head. Before they did, someone punched a hole through the bottom of the bowl on purpose. Archaeologists call it a kill hole.

### Pictures on the rock

Native artists cut or pecked some pictures into rock, called petroglyphs, and painted others, called pictographs. On the volcanic cliffs west of Albuquerque, New Mexico, there are about 24,000 to 25,000 petroglyphs. They show animals, people, crosses, the brand marks that ranchers burn into cattle, and other images.

Ancestral Pueblo people chipped most of them into the rock with chisels and other stones between 1300 and the 1680s. The oldest are much older and date from about 2000 BC. For some Native nations the petroglyphs still have religious meaning today, and a place in their ceremonies.

### Pipes, copper and stone in the Ohio and Mississippi valleys

Carvers of the Hopewell culture made smoking pipes of stone in the shapes of animals. The Hopewell people lived in the Ohio valley from about 100 BC to about AD 400 or 500. Their pipes show birds of prey, the birds that hunt, and ducks and other water birds. They also show songbirds, frogs, toads, meat-eating animals and river otters.

**Stone from far away.** One Ohio mound, Tremper Mound in Scioto County, held a store of more than 500 objects, among them 136 pipes. Archaeologists thought most of the pipes were carved from Ohio pipestone. When scientists tested some of them, 16 out of every 100 turned out to be catlinite. That stone came from quarries, pits where people dug stone, in southwestern Minnesota.

**Copper plates.** Metalworkers at Etowah, near Cartersville, Georgia, hammered copper into thin sheets between about 1250 and 1325. They pushed the design up from the back of the sheet so it stood out on the front. The best-known plates show a dancing figure that archaeologists call the Birdman, or the falcon dancer.

**The Birger figurine.** Near Cahokia, in what is now Illinois, a carver made a figure of flint clay, a stone from near St. Louis, Missouri, between 1050 and 1200. It shows a kneeling woman with a pack on her back. She is using a hoe on the back of a snake that has the head of a cat. It was dug up in 1979.

At Spiro, in eastern Oklahoma, people built twelve mounds between 850 and 1450, along with grounds for ceremonies and a town. One of the mounds, Craig Mound, held objects of stone, copper, shell, basketry and cloth.

### Who dug the objects up, and where did they go?

Two men named Ephraim Squier and Edwin Davis dug into the Mound City mounds, near Chillicothe, Ohio, in 1846 and took more than 200 stone pipes. Long before they came, the pipes had been broken and laid together under the floor of a building used for ceremonies.

**Mound City to London.** Davis sold his collection in 1864 for $10,000 to William Blackmore, who ran a museum in Salisbury, England. The collection was sold again in 1931, to the British Museum in London. Fewer than two dozen of the carved animal pipes have been on public display there.

**Etowah.** John Rogan dug at Etowah for the Smithsonian, the national museum in Washington, in 1885. He took the two best-known Birdman plates from a grave lined with stone. The Smithsonian's National Museum of Natural History still holds them.

**Spiro.** Craig Mound at Spiro was a burial mound. In 1933 six men who called themselves the Pocola Mining Company paid $50 each, $300 in all, to George Evans for the right to dig into it for two years. Evans was the grandfather of the children who owned the land. He needed the money to pay off a loan on the land and to treat his grandson's tuberculosis, a disease of the lungs.

The Pocola Mining Company hired coal miners, who dug tunnels into the mound. A business that sells copies of Spiro objects shows photographs of the dig from 1935 on its website, with notes drawn from a 1952 report on the mound. The notes name two of the diggers, John Hobbs and K. A. McKenzie, who pried up thirty copper axes and carried them out of one of the tunnels. Captions on the photographs name three more: the brothers Bill and Hayden Vandagriff, and W. Guinn Cooper.

**What the diggers did.** From 1933 to 1935 the diggers took things out of the graves to sell, and they destroyed about a third of the mound. They sold thousands of objects of stone, copper, shell, basketry and cloth to collectors around the world. One pile of objects, found in April 1935, went to a secondhand furniture dealer from Indianapolis, Indiana, for $100.

People who saw the dig described it. Beads, pearls and arrowheads lay spilled across the ground. The diggers trampled feather capes and woven cloth. They hauled out decorated shells by the wheelbarrow and dumped them near the entrance, where the shells were crushed under the diggers' feet. They burned ancient cedar poles as firewood. They piled human bones at the edge of their camp, where the bones crumbled to dust.

**The blast.** Forrest Clements, an archaeologist at the University of Oklahoma, tried to stop the dig. Oklahoma lawmakers passed a law in 1935 that required a license to dig at such sites, and Clements filed a complaint with the sheriff of LeFlore County. When he left for California, the diggers came back.

The historian David La Vere calls Craig Mound by its other name, the Great Temple Mound. In his words, "In a fit of spite, just to jab their finger in Clements' eye," the diggers "packed the central chamber of the Great Temple Mound with kegs of black powder and touched off a mighty explosion." The blast caved in part of the mound and left a large crack in it.

The Encyclopedia of Oklahoma History says the Pocola Mining Company was shut down for good in November 1935. It does not say who shut it down.

Then University of Oklahoma archaeologists led workers paid by a government jobs program, the Works Progress Administration, from 1936 to 1941. The workers took the remains of more than 600 people out of Craig Mound, some whole skeletons and some only parts.

**Mimbres.** In the Mimbres valley, looters dug up graves to reach the painted bowls. In the 1960s they began using bulldozers and earth movers to get to the bowls faster, and they wiped out many village sites completely. Every Mimbres site has been looted. The records do not name the people who ran the bulldozers.

### Carving on the Northwest Coast

On the Northwest Coast, people carved bone, stone and horn at least 5,000 years ago. The oldest Coast Salish basketry comes from an old fishing camp on the Hoko River, on the Olympic Peninsula. It is about 2,500 years old.

Most carving on the coast was done in cedar wood. Wood rots, so very little of it survives from before 1500. One piece that may be that old is a hat woven from twisted strands of cedar bark, found at the mouth of Wapato Creek. It dates from between 1450 and 1620. Carvers on the coast still work in this tradition today.

### Nathan Jackson

> **Who:** A Tlingit carver of totem poles and masks, still carving in the Northwest Coast tradition in his eighties.
>
> **When and where:** Born August 29, 1938, in southeastern Alaska. He lives in Ketchikan, Alaska.

**At 86, he carved an eight-foot pole about Raven and Fog Woman.**

Nathan Jackson is Chilkoot Tlingit. Every Tlingit person belongs to one of two halves, Raven or Eagle, and each half is made up of clans, large groups of related families. Jackson's clan, the Sockeye Clan, is on the Raven side.

He carves totem poles, masks, canoes, carved doors and panels that show clan crests, the animal symbols that belong to a clan. He also works metal and dances. He learned his people's traditions from Jack David, his clan uncle and grandfather.

**Totem poles in a hospital.** Jackson served in the Army in Germany until 1959. Later he spent 54 days in a hospital with pneumonia, a serious sickness of the lungs, and while he was there he whittled small totem poles. "I told the nurses, 'Those totem poles there, they have a price on them,'" he said later.

**Not known:** whether that hospital stay came soon after his Army service or in his mid-30s, because published accounts of his life disagree.

**Learning the adze.** He joined the Chilkat Dancers of Haines, Alaska, in the early 1960s. Then he studied for about three years at the Institute of American Indian Arts in Santa Fe, New Mexico. After that the carver Duane Pasco taught him to work with an adze, a carving tool with a curved blade set across the end of its handle. Through a program of the Alaska State Council on the Arts, he taught apprentices, younger carvers who learn by working beside a master.

Officials of the National Endowment for the Arts, a US government agency, gave him an honor called a National Heritage Fellowship in 1995. He has said that "the traditional way of life is something I identify with."

He began the Raven and Fog Woman pole in 2024 at the Edwin DeWill Carving Center in Saxman, Alaska. He finished it that autumn at the Arts Council of Princeton, in New Jersey, where it stands in the lobby. In the Tlingit story the pole shows, Raven marries Fog Woman, a woman who came out of the fog, for the salmon in the basket she weaves. When he mistreats her, she leaves him, and all the salmon follow her.

## The 1500s

**Era 2 of 10 · The 1500s · about 4 minutes**

The oldest European pictures of this land and its people were made by two artists who came with colonies that did not last. Jacques Le Moyne drew the French colony in Florida in 1564. John White painted the coast of what is now North Carolina in 1585. In Europe, Theodor de Bry cut copies of both men's pictures into metal plates so that he could print them in books, and he changed them.

### How Le Moyne lost his Florida drawings

Jacques Le Moyne lost every drawing he made in Florida when Spanish soldiers took the French fort there in 1565, so the pictures that survive are ones he drew again from memory. French colonists had set up the colony, called Fort Caroline, in 1564, in a part of Florida that Spanish leaders claimed. They brought Le Moyne along as their official artist, to record it. He drew the fort, the settlers and the land, and the people who already lived there, the Timucua.

**The attack.** Pedro Menéndez de Avilés and 500 Spanish soldiers took the fort in an attack at dawn on September 20, 1565. They killed most of the French settlers they found. Menéndez spared about 50 women and children and shipped them to Havana. Le Moyne escaped.

**Sold, and changed.** Le Moyne died in France in 1588, and his widow sold his new drawings to de Bry, who printed them in 1591. De Bry changed the people and the landscapes to make his books sell better. He also made different versions of the pictures for different buyers.

One painting by Le Moyne, *Laudonnière and Athore, 1564*, shows the French commander René de Laudonnière with Athore, a Timucua leader. The year in the title is the year of the meeting the picture shows. Le Moyne made it after he got back to Europe. The New York Public Library holds it.

### John White

> **Who:** The English artist whose Roanoke watercolors are the oldest surviving pictures Europeans made on the spot in this land. Later he was governor of the 1587 colony there.
>
> **When and where:** Roanoke Island and the coast of what is now North Carolina, 1585 and 1586, and again in 1587. Probably born in Cornwall, England. His years of birth and death are not known. He was working from 1577 to 1593.

**More than seventy watercolors survive from his thirteen months at Roanoke.**

John White made the first pictures of this land by an English artist.

**The voyage.** White sailed as the artist on Sir Richard Grenville's voyage to Roanoke Island in 1585. Walter Raleigh and other men who put money into the voyage paid for it. White worked beside the mathematician Thomas Harriot. The coast they recorded was the land of nations that spoke Algonquian languages, a family of related languages. Among them were the Roanoke, the Secotan and the Croatoan. In July 1585 White visited the town of Secotan and painted it.

**What he painted.** In about thirteen months he painted Algonquian towns, people, dances, clothing and fishing, and plants, birds and fish. He drew each outline in black lead, a kind of pencil. Then he filled it in with watercolor and added touches of gold and silver paint.

De Bry printed engravings, pictures cut into metal plates so that many copies could be printed, of White's pictures of people in 1590, in a book with Harriot's report on the colony. He changed some of them. In one of White's watercolors, a Secotan girl holds a small doll dressed in English clothes. De Bry's copy also puts a model of the globe and the sky in her hands.

The British Museum in London owns White's original watercolors, and its staff keep them stored away from light. In the middle of the 1800s, water badly damaged them during a fire at the Sotheby's auction house. Over time, chemical changes have turned the silver paint black.

**The governor.** White returned to Roanoke in 1587 as the governor of a new colony. After the colonists landed, one of them, George Howe, was found dead. He had been shot with sixteen arrows and beaten. The Encyclopedia Virginia account of the colony does not name the men who killed him.

In August 1587 White led an attack on the town of Dasamonquepeuc to pay back Howe's killing. He believed its people were Roanoke, enemies of the English. They turned out to be Croatoan, who were friends of the English, and White's men killed a number of them. One account says the dead included a leader named Menatonon, and other accounts name the leader differently.

That same year the colonists talked White into sailing to England for more supplies. He could not return for three years. In 1588 Queen Elizabeth I took every English ship for her navy, to fight the Spanish Armada, a fleet of warships sent from Spain.

When White reached Roanoke again on August 18, 1590, the colonists were gone. The word "CROATOAN" was carved on a post. Chapter 31 tells what that word meant and how White tried to find the colonists.

**Not known:** what became of the colonists.

## The 1600s

**Era 3 of 10 · The 1600s · about 7 minutes**

Art in the English colonies of the 1600s was made for families with money, for the graves of the dead and for the church. Painters made portraits for rich Boston families, carvers cut pictures into gravestones, and girls stitched needlework. A printer in Massachusetts produced the first full book printed in the English colonies in 1640, and a book of poems by a woman living in Massachusetts came out in London ten years later.

In New Mexico, a Spanish friar, a member of a Catholic religious order, had Acoma people build a church on top of the steep hill where their town stands, and they had to carry every load up to the top. Other friars, and Spanish soldiers, burned the masks that Pueblo people used in their ceremonies.

### Portraits, gravestones and needlework in New England

English colonists built Boston on land of the Massachusett nation, on a peninsula the Massachusett called Mushauwomuk. Experts credit about ten portraits of people in Boston, all painted from 1670 to 1674, to one painter. No record gives the painter's name, so today the painter is called the Freake Painter, after the best-known portrait. An article in *The Magazine Antiques* calls the painter "probably Samuel Clement," but nobody has proved it.

**A baby painted in later.** That portrait shows Elizabeth Freake holding her baby daughter, Mary. The Freakes were one of the richest families in Boston. The painter first painted Elizabeth alone, in about 1671. Mary was born on May 6, 1674, and X-rays of the painting show that the baby was painted in afterward. The Worcester Art Museum, in Massachusetts, owns the painting.

**Skulls with wings.** Many settlers of New England were Puritans, English Protestants, Christians outside the Catholic Church, who wanted a plainer and stricter church. Puritans did not want religious symbols such as crosses and cherubs, carvings of baby angels, on their graves. Carvers cut other pictures into Puritan gravestones: skulls with wings, crossed bones and hourglasses. Many stones carry the Latin words "Memento Mori," which mean "remember you will die."

Joseph Lamson of Charlestown, Massachusetts, who lived from 1658 to 1722, is one carver whose name is known. He carved winged skulls with eyebrows that hook at the ends, inside borders of fruit, vines and flowers. His sons Nathaniel and Caleb and his grandson Joseph carried on the work.

Girls learned needlework from their mothers. Many stitched samplers, strips of cloth that kept a record of stitches and patterns to copy later.

### Loara Standish

> **Who:** A daughter of Myles and Barbara Standish of Plymouth Colony, thought to be the maker of the oldest known sampler made in America.
>
> **When and where:** Duxbury, in Plymouth Colony, in the 1640s or about 1653. She was born after 1627 and died before 1655.

**"Loara Standish is my name," she stitched in silk on linen.**

Loara Standish is thought to have stitched the oldest known sampler made in America, and the oldest known sampler with a verse. She made it in Duxbury, in Plymouth Colony. English settlers built Plymouth on the site of Patuxet, a Wampanoag town.

Loara was one of the seven children of Myles and Barbara Standish. According to the Pilgrim Hall Museum, she probably made the sampler in her teens. She stitched it in silk thread on linen cloth, with roses, carnations and oak leaves, and a letter S twisted around itself.

**The verse.** She stitched this into it: "Loara Standish is my name Lorde guide my hart that I may doe thy will also My hands with such Convenient skill as may Conduce to virtue void of Shame and I will give The glory to thy name." The verse asks God to guide her heart and to give her hands enough skill to do good. She promises to give God the glory.

Lucius Alden gave the sampler to the Pilgrim Hall Museum in Plymouth in 1844. It has faded from being hung up for so many years. Experts at the museum date it to about 1653. Experts at the Textile Research Centre in Leiden, in the Netherlands, date it to the 1640s.

### The first books printed and written here

The Reverend Jose Glover sailed for Massachusetts with a printing press in 1638 and died on the ship. His widow, Elizabeth Glover, set up the press in Cambridge, Massachusetts. She put it in the charge of Stephen Daye, a locksmith.

**The Bay Psalm Book.** Daye printed *The Whole Booke of Psalmes*, now called the *Bay Psalm Book*, in 1640. A group of thirty elders, men respected in the colony for their learning, had put the psalms, 150 poems in the Hebrew Bible, into English verse that could be sung. Among them were John Cotton, Richard Mather and John Eliot. Daye is thought to have printed about 1,700 copies, which sold for twenty pence, or pennies, each. Only eleven copies survive today.

### Anne Bradstreet

> **Who:** A poet in the Massachusetts Bay colony, whose book was the first book of poems by someone living in the English colonies.
>
> **When and where:** Born in England in 1612. Came to Massachusetts in 1630. Died in 1672.

**The title page called her only "a Gentlewoman of those parts."**

Anne Bradstreet wrote the first book of poems by someone living in the English colonies. It was printed in London in 1650 as *The Tenth Muse Lately Sprung Up in America*. In old Greek stories, nine goddesses called the Muses watched over poetry and the other arts, so the title describes her as a tenth one. Her full name appears inside the book.

She was the daughter of Thomas and Dorothy Dudley. She married Simon Bradstreet in about 1628, sailed to Massachusetts with him and her parents in 1630, and had eight children.

**How the poems got to London.** Her brother-in-law, the Reverend John Woodbridge, took her poems to London. In the book's opening pages, Woodbridge wrote that she had not known he was doing it. Later, in a poem called "The Author to Her Book," Bradstreet called him a "friend more loving than true" for taking them.

**What she knew.** The biographer Charlotte Gordon studied the poems and the letters between Bradstreet and Woodbridge. She found that Bradstreet knew about the plan and helped with it from the start. One poem in the book is about events of 1649. Woodbridge had sailed in 1648, so someone had to send that poem after him.

### Mission churches and burned masks in New Mexico

Acoma Pueblo is a town built on top of a mesa, a hill with steep sides and a flat top. Chapter 2 tells in full what happened there in 1598 and 1599. In the Acoma people's own account, the soldiers of the Spanish captain Juan de Zaldívar raped an Acoma woman, which means they forced her into sex. In December 1598 Acoma people killed Zaldívar and eleven to fourteen of his men.

**The attack on Acoma.** In January 1599 Spanish soldiers sent by Juan de Oñate, the leader of the Spanish colony in New Mexico, took the town and burned much of it. They killed hundreds of Acoma men, women and children, between about 300 and about 1,500 by the estimates.

Oñate sentenced the Acoma men older than twenty-five to have one foot cut off. He also sentenced them to twenty years of forced labor, work for others without pay and without the right to leave. Whether the feet were really cut off is disputed.

**The church on the mesa.** A friar named Juan Ramírez arrived at Acoma in 1629. He probably began soon after to have Acoma people build a church on the mesa, called San Esteban del Rey. The Acoma workers had to carry every load up the mesa. The loads included roof beams 40 feet long, cut in mountains 30 to 40 miles away. One account says the builders were enslaved. Another says only that they had to do the work.

**Not known:** the exact years of the building, or whether the workers were paid, which the surviving records do not say.

San Esteban del Rey is the oldest European church in New Mexico that still stands.

**Burned masks.** Pueblo people made masks for their ceremonies. Katsina masks show spirit beings, and they were kept in kivas, rooms used for religious ceremonies. Alonso de Posada, the head of the Franciscan friars in New Mexico, banned Pueblo ceremonies from 1656 to 1665. He ordered friars to go into the kivas and burn the masks. They also burned prayer sticks and carved figures, or took them away. In 1661 Spanish soldiers raided kivas and burned masks as well. No surviving record counts the masks that friars and soldiers burned.

Governor Juan Francisco Treviño had 47 Pueblo religious leaders arrested in 1675. Three of them were hanged, and one killed himself. The rest were whipped in public and jailed, until Pueblo men came to Santa Fe and forced their release. Treviño ordered the arrests. Dennis Zotigh's account of these events for the Smithsonian does not name the men who hanged and whipped the prisoners.

One of the freed men was Po'pay, of Ohkay Owingeh. He led the Pueblo Revolt on August 10, 1680, in which Pueblo people killed 21 friars and burned many of the mission churches across the province.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 7 minutes**

The first trained painters in the colonies earned their living from families with money, and some of that money came from slavery and from Native land. A few painters trained in Europe settled here between 1700 and 1750. They painted merchants, planters and officials, because only families with money could pay for a portrait.

Two portraits from these years show slavery. One shows an enslaved boy in a metal collar beside the son of a rich Maryland family. The other shows the Royall family, whose money came from trading in sugar, rum and people. One painter made portraits of two Lenape leaders two years before William Penn's sons took a large part of Lenape land. A colonial governor took Cherokee baskets to London in 1725, and they are still kept there.

### Portrait painters in the colonies

Henrietta Johnston drew portraits in Charleston, South Carolina, from 1708. John Smibert came from Scotland and painted in Boston from 1729 or 1730.

Justus Engelhardt Kühn came from Germany. He applied at Annapolis, Maryland, in 1708 to become an English subject, with the rights of a person born English. He painted the children of rich Maryland families until he died in 1717. He was the earliest artist known to work for pay in the Middle Atlantic colonies, the group of colonies that included Maryland.

Gustavus Hesselius was born in Sweden in about 1682 and studied art there. He painted portraits in Philadelphia. He also built church organs, among them one for the church of the Moravians, a Protestant group, in Bethlehem, Pennsylvania, in 1746. He died in Philadelphia on May 23, 1755. Robert Feke painted portraits in Newport, Rhode Island.

### Henrietta Johnston

> **Who:** A portrait artist who worked in pastels. She was the first woman recorded as working for pay as an artist in the English colonies.
>
> **When and where:** Born in northern France in about 1674. Worked in Charleston, South Carolina, from 1708 until she died there on March 9, 1729.

**Pastels came only from England, and pirates attacked her voyage home.**

Henrietta Johnston was the first woman recorded as working for pay as an artist in the English colonies. She was also the first artist in the colonies to use pastels, crayons made from a paste of colored powder and resin, a sticky stuff that comes from trees.

**Driven out of France.** Her family were French Protestants. Two years before they fled to London in 1687, King Louis XIV of France had taken away Protestants' right to practice their religion. He sent soldiers to live in Protestant homes, and the king's officers let the soldiers loot the homes and ruin the families.

The soldiers tortured some people who would not become Catholic, which means they hurt them on purpose to make them give in. They stayed until the families became Catholic or left France.

Henrietta married in 1694 and moved to Ireland, where she learned to draw portraits in pastel. Her first husband died in 1704 and left her with two small children.

**Charleston.** Her second husband, Gideon Johnston, was a minister of the Church of England. In 1708 he moved the family to Charleston, where he served as the representative of the bishop of London. The Stono, Kiawah and Etiwan peoples had lived along the rivers at Charleston when English colonists settled there in 1670. The Johnstons were short of money, so Henrietta drew portraits of the town's richest families for pay.

Pastels could be bought only in England. She sailed to London for supplies in 1711, and on the voyage home pirates attacked her ship. She survived. After Gideon died in 1716, she earned the family's living alone. About three dozen of her portraits survive.

### John Smibert

> **Who:** A Scottish portrait painter in Boston, whose shop and studio showed younger painters copies of European art. He also drew the plans for Faneuil Hall.
>
> **When and where:** Born in Edinburgh, Scotland, in 1688. Newport, Rhode Island, in 1729, then Boston until he died there in 1751.

**Upstairs over his paint shop hung copies of Europe's famous paintings.**

John Smibert was one of the first painters with formal art training to work in the thirteen colonies. In 1728 a church leader named George Berkeley asked him to come to America. Berkeley planned to start a college in Bermuda, where Smibert would teach art. The college was never started.

Smibert reached Newport, Rhode Island, with Berkeley's group in 1729 and painted Berkeley and his party in a picture now at Yale University. By 1729 or 1730 he had moved to Boston. There he painted merchants, such as Peter Faneuil, and Judge Samuel Sewall. He drew the plans for Faneuil Hall in Boston in 1742.

**The shop and the studio.** Portraits alone did not earn Smibert enough, so he kept a shop. In 1734 he began selling paint, other art supplies and prints. Upstairs, in his studio, he hung copies of famous European paintings that he had made in Europe. He also showed casts there, copies made by pouring material into molds.

The historian Richard Saunders calls it "America's first art gallery." Saunders writes that the collection gave Charles Willson Peale, Gilbert Stuart and John Trumbull much of their early training. A biography of Smibert on Encyclopedia.com names John Singleton Copley and Washington Allston as painters who learned from it. Stuart was born in 1755, four years after Smibert died, so he studied the copies after Smibert's death.

### Two portraits that show slavery

**The boy in the collar.** Justus Engelhardt Kühn painted Henry Darnall III, the son of a rich Maryland family, in about 1710, when the boy was about eight. Henry wears fine clothes and holds a bow. Beside him stands a Black boy with a metal collar around his neck. The Black boy was enslaved.

His name was not recorded, and neither was the name of whoever put the collar on him. The Maryland Center for History and Culture owns the painting and calls him "Unnamed attendant." One art history website calls the picture the earliest known formal painting of an enslaved African in America.

**The Royall family.** Robert Feke painted Isaac Royall Jr. in 1741, when he was 22, with his wife Elizabeth, their baby daughter Elizabeth, his sister Penelope and his wife's sister-in-law Mary Palmer. Harvard Law School owns the painting.

Isaac's father, Isaac Royall Sr., had set up a sugar plantation on the island of Antigua. The father got rich by trading in sugar, in rum and in enslaved people. In 1737 the family moved to Medford, Massachusetts, and brought at least 27 enslaved Africans with them. When the father died in 1739, the son got his very large fortune, at the age of 20.

### Two Lenape leaders painted, 1735

Gustavus Hesselius painted two Lenape leaders, Lapowinsa and Tishcohan, in 1735, for John Penn, a son of William Penn. English colonists led by William Penn had built Philadelphia on Lenape land. Lapowinsa is shown as a strong man of about 40. They are the only two Lenape chiefs whose portraits have survived. The Historical Society of Pennsylvania owns them.

**The Walking Purchase.** Two years later Lapowinsa and Tishcohan signed a land deal called the Walking Purchase with John Penn and his brother Thomas Penn. The Lenape leaders Nutimus and Menakihikon also signed it. James Logan, who worked for the Penns, showed the Lenape an unsigned copy of a deed from 1686, a paper selling land. He claimed it gave the Penns as much land as a man could walk in a day and a half.

**The walk.** The Penns' men cleared a path ahead of time. On September 19, 1737, three walkers set off at a fast pace, and in a day and a half one of them covered more than 60 miles. The Penns' surveyors, the men who measured and marked out the land, then bent the boundary line to take in even more. In all, the Penns took more than a thousand square miles of Lenape land, and they forced Nutimus and his people to leave their homes.

### Cherokee baskets taken to London, 1725

Cherokee weavers made baskets from river cane, a tall plant with hollow stems that grows along rivers. They split the cane into thin strips and dyed some of the strips with walnut and pokeberry. Some baskets were double woven, two baskets woven one inside the other from the same strips, so both the inside and the outside show a finished pattern.

Francis Nicholson, the first governor of South Carolina chosen by the British king, left Charleston for London in 1725. He took a set of Cherokee double-woven baskets with him and passed them to Sir Hans Sloane, a collector in London. A note tied to them says, "They will keep anything in them from being wetted by rain." The British Museum in London holds them today.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 10 minutes**

The men who led the Revolution had their portraits painted by Americans, several of them trained in London, and in the same cities enslaved Black artists painted and wrote poems, though only a few records name them. In Boston, Prince Demah painted portraits while he was enslaved, and later he served during the Revolution in the Massachusetts militia, a part-time army of local men.

Phillis Wheatley's *Poems*, the first book of poems by an African American, came out in London in 1773 while she was still enslaved in Boston. The painter Charles Willson Peale was paid for portraits with two enslaved people.

### Painters who went to London

John Singleton Copley, a Boston painter born on July 3, 1738, sent a painting called *A Boy with a Flying Squirrel* to be shown in London in 1766. The London painters Joshua Reynolds and Benjamin West praised it. In 1769 Copley painted Isaac Royall Jr., the rich man from Medford, and his wife. Copley left America for England in 1774. He painted *Watson and the Shark* there in 1778, and he died in London on September 9, 1815.

The Pennsylvania painter Benjamin West settled in England in 1763 and became the king's official painter of history scenes. West was known for helping young American painters who came to London to learn.

**Faces in wax.** Patience Wright, born Patience Lovell in 1725, made portraits by shaping wax. Britannica gives her birthplace as Bordentown, New Jersey. The American Battlefield Trust says she was born at Oyster Bay, on Long Island in New York, and that her family moved to Bordentown when she was four. She took her wax figures around on tour to show them. She sailed to England in February 1772, and in London she showed wax figures of actors, politicians and nobles. She died in London on March 23, 1786.

### Charles Willson Peale

> **Who:** A painter of the leaders of the Revolution, who opened a museum in Philadelphia and held a young man in slavery to work in it.
>
> **When and where:** Born in Chester, Maryland, in April 1741. Worked in Annapolis, then Philadelphia. Died in 1827.

**A planter paid him for portraits with two enslaved people.**

Charles Willson Peale painted the leaders of the Revolution, and George Washington sat for him seven times. Peale first trained to make saddles. Then he studied painting in England for three years. Back in Annapolis, Maryland, he joined the Sons of Liberty, groups of colonists who formed in 1765 to resist a British tax on printed paper, called the Stamp Act.

**Mount Vernon.** Peale came to Washington's home at Mount Vernon on May 18, 1772, and stayed two weeks. He painted small portraits of Martha Washington and her children. He also painted George Washington in oil, in the uniform of the Virginia militia.

**The museum.** Peale announced a show of 44 portraits of leaders of the Revolution in his home in Philadelphia in 1784. Visitors paid to get in, and Peale called it the Philadelphia Museum. One account dates the opening of his museum to 1786 instead.

Washington paid a yearly fee to support it and gave it two golden pheasants from China. In 1795 the museum was the site of the Columbianum, the first show in America put on by a society of artists. After Peale died, his family sold the museum's collection of things from nature in 1849 and its portraits at auction in 1854.

**Paid in people.** By 1776 a Maryland plantation owner had given Peale two enslaved people, Scarborough and Lucy, as payment for portraits. The account of this payment does not give the planter's name. Peale freed Scarborough and Lucy in 1786.

Their son, Moses Williams, was born in about 1777. Pennsylvania lawmakers passed a law in 1780 to end slavery slowly, over many years. Under that law, only children born after it was passed were to go free, and only when they turned 28. Moses had been born about three years before, so he was not one of them.

Peale kept him enslaved in his household until about 1802, when Moses was about 25 or 27. Peale trained him for work in the museum: cutting silhouettes, which are outline portraits cut from paper, preserving dead animals for display and building exhibits.

### Prince Demah

> **Who:** An enslaved portrait painter in Boston, who later lived free and served as a soldier in the Massachusetts militia.
>
> **When and where:** Baptized in Boston in May 1745. Worked in Boston and London from 1769 to 1778. Died in Boston in March 1778.

**He signed his portrait of a Boston merchant "Prince Demah Barnes."**

Prince Demah painted portraits in Boston while he was enslaved. One of his signed paintings belongs today to the Metropolitan Museum of Art in New York. He and his mother, Daphney, were baptized at Trinity Church in Boston in May 1745, when Prince was a small child.

**Bought for his talent.** Henry Barnes was a merchant in Marlborough, Massachusetts, whose family already held Daphney in slavery. In 1769 Barnes bought her son, Prince, who was then in his late twenties. Barnes's wife, Christian, wrote to a friend that they planned on "improving his genius in painting," genius meaning talent. She also wrote that the Boston painter John Singleton Copley would not be willing to teach him.

**London.** Barnes took Prince to London in October 1770, and a painter named Pine gave him lessons there. He was probably Robert Edge Pine. Barnes was afraid that Prince would "attempt his freedom," which meant try to escape. He wrote, "I do not let [Prince] converse with any of his own colour here." He meant that he kept Prince from talking with other Black people in London.

**The advertisement.** Back in Boston, an advertisement ran at least nine times in the *Boston News-Letter* in 1773. It offered the work of a "Negro Artist," using the word of that time for a Black person, who "takes Faces at the lowest Rates," which meant painted portraits cheaply. That February, Prince painted William Duguid, a Scottish cloth merchant living in Boston, and signed it "Prince Demah Barnes." He also painted, or copied from Copley, portraits of Henry and Christian Barnes.

**Free.** The Barnes family sided with the king. In late 1775 they left for England, and they left Daphney behind at their Marlborough home. The records do not say where Prince was when they sailed, or how he became free.

Prince joined a unit of cannon soldiers in the Massachusetts militia in April 1777. He signed up as Prince Demah, without the Barnes name. On March 11, 1778, he wrote his will as "Prince Demah, limner," a painter of portraits, and as a "free Negro." He left everything he had to his mother. He died one week later. The record does not give the cause.

### Phillis Wheatley

> **Who:** A poet, the first African American to publish a book of poems. She was enslaved in Boston when the book was printed.
>
> **When and where:** Kidnapped in West Africa as a child and landed in Boston in 1761, at seven or eight years old. Her book was printed in London in 1773. She died in Boston in 1784, at about 31.

**Eighteen men signed a statement at the front that she wrote it.**

Phillis Wheatley wrote the first book of poems by an African American. It came out in London in September 1773, while she was enslaved in Boston. The title page describes her as "Negro Servant to Mr. John Wheatley, of Boston." Servant there stood for enslaved.

**Named for a ship.** She was kidnapped in West Africa as a child. In 1761, when she was seven or eight, she landed in Boston on a slave ship named the *Phillis*, and her first name came from the ship. John Wheatley's letter in her book says only that she "was brought from Africa to America," and it does not name the men who kidnapped her. In Boston, John Wheatley bought her. He wrote that she learned English in sixteen months, taught at home and not in any school.

When she was about seventeen, in 1770, a Boston printer named Ezekiel Russell printed her poem on the death of George Whitefield, a preacher who had toured the colonies.

**The statement.** The publisher of her book expected readers to doubt that an enslaved African girl could write poems. So he printed a statement at the front of the book, signed by 18 men of Boston. Among them were Governor Thomas Hutchinson, John Hancock, the Reverend John Moorhead and John Wheatley, listed as "her Master."

The men wrote that the poems were "written by PHILLIS, a young Negro Girl, who was but a few Years since, brought an uncultivated Barbarian from Africa, and has ever since been, and now is, under the Disadvantage of serving as a Slave" (uncultivated meant untaught, and barbarian was an insult for a person thought to be wild and without learning). They wrote that she "has been examined by some of the best Judges, and is thought qualified to write them."

One poem in the book is called "To S. M. a young African Painter, on seeing his Works." The Wheatleys freed her by November 1773, soon after the book appeared. She married John Peters in 1778. She died poor in 1784, at about 31.

### Two more Black painters, Scipio Moorhead and Joshua Johnson

Scipio Moorhead was an enslaved Black painter in Boston. The scholars Kwame Anthony Appiah and Henry Louis Gates Jr. write that Wheatley's poem to "S. M." may describe two of his paintings. He was held in slavery by the Reverend John Moorhead of Boston, one of the 18 men who signed the statement in Wheatley's book. Sarah Moorhead probably gave Scipio lessons.

Appiah and Gates also write that the engraved portrait of Wheatley at the front of her book was based on his painting of her. No signed painting by Scipio Moorhead survives.

**Joshua Johnson.** Joshua Johnson was born enslaved in Maryland in 1763. His father was a white man named George Johnson. His mother was a woman held in slavery by William Wheeler Sr., and her name was not written down. George Johnson bought his 19-year-old son for £25 in 1782. He sent him to learn the trade of a blacksmith and signed a manumission, a legal paper that freed him.

Joshua Johnson was listed in Baltimore as a portrait painter by 1796. In a 1798 newspaper advertisement he called himself a "self-taught genius." He wrote that he had faced "many insuperable obstacles," which means problems he could not get past. Amelia Peck of the Metropolitan Museum of Art and Paula M. Bagger write that before Prince Demah's work was found, Johnson was thought to be the earliest African American painter of portraits in oil paint.

### Mercy Otis Warren's plays

Mercy Otis Warren wrote plays that made fun of the British governor of Massachusetts and attacked his policies. She was born in Barnstable, Massachusetts, on September 14, 1728. Her first play, *The Adulateur*, came out in a newspaper, the *Massachusetts Spy*, in 1772. At least four more of her plays followed by 1779.

All of them came out without her name. The National Women's History Museum says she likely did this to avoid punishment, and so that readers would take the work of a woman seriously. She died in 1814.

### Gilbert Stuart

> **Who:** A portrait painter whose unfinished picture of George Washington is the model for the face on the one-dollar bill.
>
> **When and where:** Born in Kingstown, Rhode Island, on December 3, 1755. Worked in London and Dublin, then in the United States from 1793. Died in 1828.

**He never delivered Washington's portrait, and he sold copies for $100.**

Gilbert Stuart sailed to London in 1775. There Benjamin West hired him and gave him a studio and a place to live. In 1787 Stuart left London for Dublin to get away from the people he owed money. He arrived in New York in May 1793.

**The unfinished head.** Martha Washington ordered portraits of her husband and herself from Stuart in 1796. He painted only Washington's head and neck on a brown background, left the rest of the canvas unfinished and kept it. He never gave it to her, although she asked for it again and again after her husband died in 1799.

Stuart used the unfinished head as a model and painted more than a hundred copies of it, 130 by one count. He sold them for $100 each. An engraving of the head, flipped left to right, is on the one-dollar bill.

The people in charge of the Boston Athenaeum, a library in Boston, bought the original for $1,500 in 1831, and the painting has been called the Athenaeum portrait ever since. Since 1980 the Museum of Fine Arts in Boston and the National Portrait Gallery in Washington have owned it together.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 22 minutes**

City buyers paid for paintings of the Hudson valley and the Catskills in the same years that federal officials, the officials of the national government, forced Native nations off their land. From about 1825 a group of painters known as the Hudson River School made landscapes, pictures of the land and sky, of the Hudson River valley and the Catskill Mountains. The painter George Catlin travelled west and painted the people of about fifty nations.

Enslaved artists worked too. In South Carolina an enslaved potter named Dave began cutting his own verses into his jars in 1834, the year the state's lawmakers made it a crime for enslaved people to learn to read and write, and later he signed them "Dave." News of photography reached the United States in 1839. By the early 1850s, a small photograph in New York cost as little as 25 cents.

### Black artists in Philadelphia and Baltimore

Moses Williams, the son of the two people a planter gave Charles Willson Peale as payment for portraits, was held by Peale until about 1802. Then he cut silhouettes at Peale's museum in Philadelphia, portraits that show only the outline of a face from the side. Williams used a machine called a physiognotrace, which traced the outline of a sitter's face onto paper through a set of connected rods.

Peale's own children learned painting from their father. Karl Cole's account of Williams's life for Davis Art says Williams was not given the chance to paint. The Philadelphia Museum of Art holds silhouettes he cut of the Peale family between 1803 and 1805.

Joshua Johnson, the Maryland painter whose white father bought him and freed him in 1782, was listed as a portrait painter in the Baltimore city directories, books that listed the town's people and their trades, from 1796 to 1824.

**The Academy.** Peale, the sculptor William Rush and other artists and business leaders founded the Pennsylvania Academy of the Fine Arts in Philadelphia in 1805. The academy's leaders very seldom let Black students in.

Robert Douglass Jr., a Black painter of Philadelphia who lived from 1809 to 1887, was one of the few. He trained at the academy and studied under the painter Thomas Sully. In 1834 he painted the portraits of William Lloyd Garrison and James Forten, two men who worked to end slavery. An article by the Library Company of Philadelphia describes him as Philadelphia's first African American photographer.

**Women at the Academy.** The academy's leaders let women in one step at a time. In 1844 they gave women artists the room of statues to draw in, on three mornings a week. In 1860 they let women take classes on the body's bones and muscles and draw from copies of ancient statues. They opened life classes, where students draw from a model without clothes, to women in 1868, with women as the models. Men became the models for these classes in 1874.

### Painters on the road

Many portrait painters of these years had taught themselves. They travelled from town to town and charged somewhat less than painters with training. A story told later says these painters painted bodies ahead of time and added the customer's face when they arrived. The unfinished portraits that survive show the opposite. They have the face done and the body not yet painted, so the painters began with the head.

**The "Border Limner."** Ammi Phillips travelled and painted portraits in Connecticut, Massachusetts and New York from the middle of the 1810s until the early 1860s. He was born in Colebrook, Connecticut, on April 24, 1788. For years nobody knew who had painted many of his pictures, and collectors called the unknown painter the "Border Limner," limner being an old word for a painter of portraits. The collectors Barbara and Larry Holdridge matched those paintings to Phillips.

In the mid-1830s, in Dutchess County, New York, Phillips painted *Girl in Red Dress with Cat and Dog*. It was bought for the American Folk Art Museum in 1985 for one million dollars. Phillips died on July 11, 1865.

**The Peaceable Kingdom.** Edward Hicks, born in Pennsylvania on April 4, 1780, became an apprentice, a young worker learning a trade by working for its masters, to coach makers at 13. From 1812 he was a minister of the Quakers, a Christian group.

He painted 62 versions of *The Peaceable Kingdom*, based on a passage in the book of Isaiah in the Bible. Many versions show William Penn meeting Native people, who stand for the Lenape, on whose land Penn founded his colony. In his own lifetime, Hicks was better known as a minister than as a painter. He died on August 23, 1849.

### Joseph Whiting Stock

> **Who:** A travelling portrait painter who could not walk. He kept a journal of the paintings he made and what he was paid for them.
>
> **When and where:** Born in Springfield, Massachusetts, on January 30, 1815. Painted in Massachusetts, Rhode Island and New York from 1832. Died in 1855, at the age of forty.

**An oxcart fell on him at eleven, and he painted 900 pictures.**

Joseph Whiting Stock painted more than 900 pictures, although he could not walk. When he was eleven, an oxcart turned over and fell on him. He was paralyzed from the waist down, which means he could not move or feel his legs. He could not leave his bed until he was nineteen.

**A doctor's idea.** A doctor suggested that he take up art. He began lessons at seventeen, with a painter named Franklin White, and tried a portrait of his sister Eliza. "I attempted my sister Eliza's portrait and made so good a likeness as to induce my friends to encourage me by their patronage," he wrote in his journal (patronage meant paying him for pictures).

**A wheelchair.** In 1834 a doctor named James Swan hired Stock to make drawings of the human body. Swan also built him a wheelchair. With it, Stock could paint large pictures and be lifted onto trains to travel for work.

His first painting trip was a month in Wilbraham, Massachusetts, in 1836. He later spent two years in Warren, Rhode Island, and New Bedford, Massachusetts, and several years in Orange County, New York. He lived with local families while he worked, and sometimes he paid for his room and meals with paintings.

His journal lists more than 900 paintings and what he was paid for them. About a hundred of those paintings are known today. He died of tuberculosis, a disease of the lungs, in 1855, at forty. The Springfield Museums hold his journal.

### The Hudson River School, and whose land it painted

The Hudson River School was a group of American landscape painters who worked from about 1825 to 1870. They painted American land in careful, true-to-life detail, often with quiet farms next to the last of the wild forest. Many of them believed that God could be seen in the American landscape. Thomas Cole, Thomas Doughty and Asher B. Durand were the first leaders, and many of the group painted the Catskill Mountains, west of the Hudson River.

The Hudson valley was the homeland of the Mohican people. Cole made his home in the village of Catskill, New York, in 1826. That land is the homeland of the Muh-he-conneok, the People of the Waters That Are Never Still, who today are called the Stockbridge-Munsee Band of Mohican Indians. A marker at Cole's house states that they were forced from there.

**Stockbridge.** Through the 1600s and 1700s, before Cole was born, settlers pushed the Mohican out of the Hudson valley. Most moved to Stockbridge, Massachusetts, a mission town, which means a town built around a church where ministers taught Christianity. From 1764 white settlers poured into Stockbridge and took thousands of acres of Mohican land. They squatted on it, which means they settled on it without any right, and they bought it in ways the law did not allow. They also took land to pay off Mohican debts.

The Mohican had lost all their land in the town by 1783. In 1785 a group of them founded New Stockbridge in upstate New York, on land of the Oneida nation.

**To Wisconsin.** The Mohican were made to move again in the same years Cole began to paint the Catskills. Agents from New York and commissioners from the War Department arranged treaties, written agreements between governments. Under them, the Stockbridge, as the Mohican were by then called, and the Munsee had to leave New York for Wisconsin.

The moves began after an 1822 treaty, three years before Cole put his landscapes in a New York shop window. By 1831, five years after Cole settled in Catskill, 225 Stockbridge people and 100 Munsee people had gone. From 1832 to 1834, federal officials made them move once more, to the east shore of Lake Winnebago. Their reservation, land set aside for them by treaty, is in northeastern Wisconsin today.

**Removal.** While Cole was selling paintings of the Catskills, federal officials were moving Native nations west. President Andrew Jackson signed the Indian Removal Act on May 28, 1830. Under it, the president could make treaties in which Native nations gave up their lands east of the Mississippi River for lands in the west.

Federal officials and soldiers forced more than 16,000 Cherokee people from their homeland to Indian Territory, in what is now Oklahoma, in 1838 and 1839. At least 4,000 of them died of cold, hunger and disease along the way, by the usual count, and other counts are higher.

### Thomas Cole

> **Who:** A painter of landscapes and one of the first leaders of the Hudson River School.
>
> **When and where:** Born February 1, 1801, in Bolton-le-Moors, Lancashire, England. Came to America in 1818. Lived in Catskill, New York, from 1826. Died there on February 11, 1848.

**The cleared strips on the far hill seem to spell "Noah" in Hebrew.**

Thomas Cole was one of the first leaders of the Hudson River School. He came to America from England with his family in 1818, and they lived first in Philadelphia and then in Steubenville, Ohio. A travelling portrait painter named Stein gave him lessons. Then he studied for two years at the Pennsylvania Academy of the Fine Arts.

**A shop window.** Cole put some landscapes in the window of a shop in New York City in 1825. The painters John Trumbull and Asher B. Durand saw them and bought them. The next year Cole moved to Catskill. He made pencil sketches outdoors, and in winter he painted in his studio. He also spent years painting in Europe, mostly in Italy, from 1829 to 1832 and again from 1841 to 1842.

**The Oxbow.** In 1836 he painted *The Oxbow*, a view from Mount Holyoke, near Northampton, Massachusetts. It shows the valley of the Connecticut River, not the Hudson, and Cole joined two views from the mountain into one picture. On the far hill, the bare strips where trees were cut seem to spell the Hebrew letters for "Noah." The art historian Matthew Baigell was the first to notice them.

Cole made the painting for a show in New York in April 1836. His patron, a person who pays an artist to make work, was Luman Reed, and Reed had suggested it. In March 1836 Cole wrote to Reed, "Fancy pictures seldom sell & they generally take more time than views so I have determined to paint one of the latter." By "fancy pictures" he meant pictures from his imagination, and by "views" he meant real places.

That same year he finished *The Course of Empire*, a set of five paintings. The Metropolitan Museum of Art in New York has owned *The Oxbow* since 1908.

Cole died in Catskill on February 11, 1848. Durand painted a picture called *Kindred Spirits* in his memory. Cole's house and studio in Catskill are now the Thomas Cole National Historic Site.

### Writers

Some writers of these years turned to the American land and to nature, as the painters did. Washington Irving set his 1819 story "Rip Van Winkle" in the Catskill Mountains of New York, the same mountains the Hudson River School painted a few years later. Ralph Waldo Emerson's long essay *Nature* appeared in 1836.

James Fenimore Cooper's novel *The Last of the Mohicans* came out in Philadelphia on February 4, 1826. The Mohican people named in its title were living in New York and Wisconsin that year.

**By 1840:** Painters were selling views of the Catskills in New York City, and federal officials and soldiers had forced the Mohican, the Munsee and the Cherokee out of their homelands.

### George Catlin and the people he painted

George Catlin was a lawyer who became a painter. He lived from 1796 to 1872. In 1830 he went to St. Louis to meet William Clark, the federal official in charge of Indian affairs there. From St. Louis, Catlin made five trips west between 1830 and 1836, and in 1832 he travelled more than 2,000 miles up the Missouri River.

He wrote, "If my life be spared, nothing shall stop me from visiting every nation of Indians on the Continent of North America." By one count he visited 48 nations, and by another, fifty.

**Four Bears.** At a Mandan village in what is now North Dakota, Catlin painted Four Bears, a Mandan leader, in 1832. His Mandan name was Máh-to-tóh-pa. Catlin called him "the first and most popular man in the nation." Four Bears was a painter too, and he painted his own battles on buffalo robes. Catlin got one of those robes in 1832, and it is now at the Smithsonian.

A German prince, Maximilian of Wied, travelled up the Missouri with the painter Karl Bodmer in 1833 and 1834. He took another Four Bears robe to Germany, where it is in the Linden Museum in Stuttgart.

Catlin sometimes got objects from the people he painted, as proof that his pictures were accurate. One was a Sioux cradle. In 1836 he went to the place in southwestern Minnesota where people dug red stone for pipes. Sioux elders protested strongly, and he went anyway.

**Smallpox.** Five years after Catlin painted the Mandan, smallpox killed almost all of them, Four Bears among them. Smallpox was a disease caused by a virus. It spread when people were close together, face to face. It caused a fever and a rash that turned into scabs, and about 3 of every 10 people who caught it died.

President Jackson signed the Indian Vaccination Act on May 5, 1832, a law to give Native people vaccinations. To vaccinate a person, a doctor scratched fluid from a sore of cowpox, a mild disease of cows, into the skin, and it protected the person against smallpox. Secretary of War Lewis Cass ran the program through federal Indian agents. He left the Mandan, the Hidatsa and the Arikara of the upper Missouri out of it.

The American Fur Company's steamboat *St. Peters* reached Fort Clark, next to the Mandan villages, on June 18, 1837. The fort's trader, Francis Chardon, learned from the captain, Bernard Pratte Jr., that people on board had smallpox. The crew unloaded goods and loaded furs in less than a day, and the boat went on up the river. It had brought smallpox to the Mandan villages. About 2,000 Mandan lived there that spring. By October, 138 were alive.

Four Bears caught smallpox and died on July 30, 1837. Chardon wrote down his last speech: "I have loved the Whites ... and how have they repaid it! With ingratitude!" (ingratitude means not being thankful).

**Osceola.** The Seminole leader Osceola sat for Catlin in January 1838 as a dying prisoner. General Thomas Jesup had ordered soldiers to seize Osceola near St. Augustine, Florida, on October 21, 1837, while he was under a white flag of truce, a sign that the two sides have stopped fighting to talk. Osceola was held at Fort Marion in St. Augustine and then at Fort Moultrie in South Carolina.

There he was very sick with malaria, a disease spread by mosquitoes that brings fever and chills, and with other illnesses. Three painters, Catlin, W. M. Laning and Robert John Curtis, talked him into letting them paint him anyway. Osceola died a prisoner on January 30, 1838. The army doctor, Frederick Weedon, cut off his head and then buried the body. Weedon kept the head and showed it in his drugstore.

**The Indian Gallery.** Catlin opened his paintings to the public at Clinton Hall in New York on September 23, 1837, at 50 cents a visit. He called the show his Indian Gallery. He tried to sell it to the United States government, and members of Congress did not buy it. In November 1839 he sailed for England with the gallery, a tepee of buffalo hide and two live bears. He showed the gallery in London, Brussels and Paris.

Groups of Native people who were touring Europe with promoters joined him there, 21 Ojibwe and 14 Iowa. Catlin talked them into acting out hunts, dances and even scalpings for the crowds. Scalping means cutting the skin and hair from the top of an enemy's head. In Paris in 1845, the Ojibwe group caught smallpox, and two of them died. The account that records their deaths does not name them.

**In debt.** Catlin ran out of money in 1852 and was put in a London prison for debt. Members of Congress still would not buy the gallery, even after he lowered his price from $65,000 to $25,000. Joseph Harrison, a Pennsylvania railroad owner, paid Catlin's debts and got the gallery for $20,000. He stored it in his boiler factory in Philadelphia. In 1879 Harrison's widow gave the paintings to the Smithsonian.

### Audubon's birds, and the people he sold

John James Audubon's *The Birds of America* was printed in England from 1827 to 1838. It has 435 pictures of birds, each bird shown at its real size.

**The people the Audubons sold.** The historian Gregory Nobles records that the Audubons held nine enslaved people in their household in Henderson, Kentucky, in the 1810s. By the end of that decade, short of money, they sold them. In early 1819 Audubon took two enslaved men down the Mississippi River to New Orleans on a small boat, and there he offered the boat and the two men for sale.

The family bought more enslaved people in the 1820s and sold them in 1830, when Audubon moved to England to oversee the printing of the birds.

Audubon wrote to his wife in 1834 about the freeing of the enslaved people in Britain's colonies in the West Indies, the islands of the Caribbean. He wrote that the British government had "acted imprudently and too precipitously," which means without enough care and too fast. The surviving record counts the people Audubon held and sold. It does not give their names.

### Dave (David Drake)

> **Who:** An enslaved potter and poet who cut his name and his own verses into large jars of hard-fired clay.
>
> **When and where:** Born about 1800 in South Carolina. Worked in the potteries of the Edgefield District from about 1818 to 1864. Listed in the 1870 census as "David Drake, Turner." Believed to have died in the 1870s.

**He cut verses into clay when learning to read was a crime.**

Dave was an enslaved potter who wrote his own verses on the jars he made. He is the only Black potter in Edgefield before the Civil War known to have signed his own work. He was born into slavery around 1800. In the Edgefield District of South Carolina, white factory owners made their potteries grow by using the unpaid work of enslaved men, women and children. At least 76 enslaved people worked at the district's 12 potteries.

**Mortgaged.** The first record of Dave is dated June 13, 1818. It describes "a boy about 17 years old country born," which meant born in America and not brought from Africa. His enslaver, Harvey Drake, mortgaged him to a man named Eldrid Simkins. That meant Drake used Dave to guarantee a loan: if Drake did not pay the money back, Simkins could take Dave.

**Passed from man to man.** At least five men held Dave in slavery during his life. Harvey Drake was the first, until he died in 1832. His brother Reuben Drake held Dave next, until 1835, and then the Reverend John Landrum. When Landrum died in 1846, all 18 of the people he enslaved were put up for sale. The records do not name who sold them. Franklin Landrum held Dave for a time. In 1849 Lewis Miles, who owned the Stony Bluff pottery, bought him.

**Words on a jar.** South Carolina's lawmakers made it a crime for enslaved people to learn to read and write in 1834. That same year, Dave cut words into a jar: "put every bit all between / surely this jar will hold 14." On the jar's other side he pressed fourteen dots. Arthur F. Goldberg and James Witkowski, two scholars who studied his pots, think such dots showed how many gallons a jar held, so the 14 means 14 gallons.

He wrote on another jar on July 31, 1840: "Dave belongs to Mr. Miles / wher the oven bakes and the pot biles." So by his own words, Lewis Miles held him in 1840, nine years before the 1849 sale. Accounts of his life do not agree on when Miles first held him or how.

**Not known:** how he learned to read, though he may have learned while he worked at a newspaper, the *Edgefield Hive*, printed by Harvey Drake's business partner Abner Landrum.

Dave shaped the bottom of each jar on a potter's wheel. Then he built up the top by hand with thick coils of clay. Two of his jars at the Charleston Museum each hold more than 40 gallons.

**What was taken from him.** His family was sold away from him. The records do not say who sold them or where they were taken. One of his legs was amputated, which means it was cut off.

**Not known:** how he lost the leg. One account says an enslaver beat him for writing, and another says he was hurt in a train accident. Neither has been proved.

He wrote three verses on his pots in 1857, eight in 1858 and seven in 1859. On August 16, 1857, he wrote: "I wonder where is all my relation / Friendship to all, and every nation."

His last known poem, from 1862, during the Civil War, reads: "I made this Jar all of cross, If you dont repent, you will be, lost." To repent means to be sorry for doing wrong and to change. Goldberg and Witkowski write that the poem carries political and religious meaning, because he wrote it in a time of slavery and civil war.

**Free, and counted.** In a survey of 2006, Goldberg and Witkowski counted 169 pots made by Dave or credited to him. More than a hundred, dated from 1849 to 1864, are signed "Dave." His verses and marks appear on 50 of them. Sometimes he added the names of other enslaved potters beside his own: Mark, Abram and Baddler. His last dated pot is from 1864.

Dave was free by the end of the Civil War in 1865. The Smithsonian American Art Museum credits his freedom to the Emancipation Proclamation, President Abraham Lincoln's order freeing enslaved people in the states at war with the United States. He took the last name Drake, probably from Harvey Drake, the first man who had held him.

The census of 1870, the government's count of everyone in the country, lists him as "David Drake," and his work as "turner," a person who shapes pots on a wheel. His name is not in the census of 1880. He is believed to have died in the 1870s.

### Photography arrives, 1839

The French artist Louis Daguerre worked out a way of making pictures with light, and news of his process reached the United States in late August and September 1839. In October or November 1839, Robert Cornelius of Philadelphia took a picture of himself. It is the oldest American portrait photograph that survives.

These first photographs, called daguerreotypes, were each made directly on a copper plate coated with silver. Each was a single picture, and it could not be copied.

**Studios on Broadway.** A history of New York's photographers, published by the Bard Graduate Center, says the first American studio that sold portrait photographs opened in New York in 1840. By 1850 New York had 71 daguerreotype studios, and by 1853 it had more of them than all of England. Mathew Brady opened his first studio at 205 Broadway in 1844.

Cheaper studios on Broadway and on the Bowery made portraits for working people. In the early 1850s, a very small daguerreotype, about 1 5/8 inches by 1 3/8 inches, cost 25 cents. A cheap portrait from a "picture factory," a shop that turned out many portraits fast, cost 50 cents. A medium-sized portrait at Brady's studio cost $2.

### Frederick Douglass

> **Who:** A writer and speaker who escaped slavery. He wrote the story of his own life and sat for 160 known photographs.
>
> **When and where:** Born in Talbot County, Maryland, in February 1818. Escaped slavery on September 3, 1838. Lived in Massachusetts, then Rochester, New York, then Washington. Died in 1895.
>
> **Movie:** *Becoming Frederick Douglass* (2022), a documentary by Stanley Nelson, shown on PBS. It is about his life.

**He sat for 160 photographs, more than Lincoln's 126.**

By the count of the historians John Stauffer, Zoe Trodd and Celeste-Marie Bernier, Frederick Douglass sat for more photographs than any other American of the 1800s: 160 of them, against 126 of Abraham Lincoln. He was born into slavery in Maryland. He escaped on September 3, 1838, by train through Baltimore, dressed in a sailor's clothes. Anna Murray, a free Black woman, helped him, and he married her.

**The book.** His book came out from the Anti-Slavery Office in Boston on May 1, 1845. It was called *Narrative of the Life of Frederick Douglass, an American Slave. Written by Himself*. By one count it sold 4,500 copies in four months, and by another 5,000. By 1860 almost 30,000 copies had sold.

**Pictures by white artists.** In 1849 Douglass wrote about pictures of Black people drawn by white artists. He wrote that "negroes can never have impartial portraits at the hands of white artists" (negroes was a word of that time for Black people, and impartial means fair). "It seems to us next to impossible for white men to take likenesses of black men, without most grossly exaggerating their distinctive features," he wrote.

Douglass sat for photographs again and again. He said that "the great cheapness and universality of pictures must exert a powerful, though silent, influence upon the ideas and sentiment of present and future generations." By universality he meant that pictures were everywhere.

**If you remember one thing:** Painters in these years sold city buyers pictures of the Hudson valley and of Native leaders, while federal officials forced Native nations off their land.

- May 28, 1830: President Andrew Jackson signs the Indian Removal Act.
- 1834: Dave cuts words into a jar, the year South Carolina makes it a crime for enslaved people to learn to read and write.
- October or November 1839: Robert Cornelius of Philadelphia takes the oldest surviving American portrait photograph.

**Next:** In the next fifty years, photographers carry their cameras onto Civil War battlefields and into the valleys of the far West.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 23 minutes**

Cameras and cheap printing put pictures and books in front of millions of Americans after 1850. Many Black and Native artists of the same years did their work far from home or as prisoners. Photographers showed Americans the bodies of soldiers killed in the Civil War, and the valleys and mountains of the far West. The first ten-cent novel, in 1860, sold more than 65,000 copies in a few months, and *Uncle Tom's Cabin* sold 300,000 in the United States in its first year.

The sculptor Edmonia Lewis said she was "practically driven to Rome" by prejudice against her color, and the painter Henry Ossawa Tanner made his career in Paris. At an army fort in Florida, Plains men held as prisoners without trial drew their lives in account books. In New York, the Metropolitan Museum of Art opened in 1872.

### Writers and cheap books

Harriet Beecher Stowe's *Uncle Tom's Cabin*, a novel against slavery, sold more copies than any other book of the 1800s except the Bible. It first ran in parts in a newspaper, *The National Era*, from 1851, and came out as a book in 1852. In the United States it sold 10,000 copies in its first week and 300,000 in its first year.

Herman Melville's *Moby-Dick* sold far fewer. The novel, about a whaling captain who hunts the giant white whale that bit off his leg, came out in 1851, and its first printing in New York was 2,915 copies. It was out of print when Melville died in 1891. Readers began to call it a great American novel in the 1900s.

Walt Whitman paid to print his own book of poems, *Leaves of Grass*, on July 4, 1855. The first edition held twelve poems. Whitman kept adding to it and changing it until he died in 1892.

**Dime novels.** The brothers Erastus and Irwin Beadle began selling novels of about 100 pages for ten cents each in 1860. People called them dime novels, because a dime is ten cents. The first, Ann S. Stephens's *Malaeska, the Indian Wife of the White Hunter*, sold more than 65,000 copies in its first few months. The Beadles printed 321 of these books in the series.

### Robert S. Duncanson in Cincinnati

Robert S. Duncanson was a free Black painter who had taught himself to paint. He was born in about 1821 in Fayette, New York, the son of a free Black tradesman. In 1840 he moved to Cincinnati, Ohio, where about 3,000 Black people lived.

**Belmont.** Nicholas Longworth hired Duncanson in about 1850 or 1851 to paint eight landscapes on the walls of the entrance hall of his house, Belmont. Each is about nine feet high. The house is now the Taft Museum of Art. In 1853 Duncanson painted *Uncle Tom and Little Eva*, from Stowe's novel, which is at the Detroit Institute of Arts.

During the Civil War he left the United States. He showed his work in Montreal, Canada, in 1864 and in Dublin, Ireland, in 1865. He died in Detroit on December 21, 1872.

### Photographs of the Civil War dead

Alexander Gardner, born in Paisley, Scotland, in 1821, worked for the New York photographer Mathew Brady from 1856, and in 1858 Brady put him in charge of his studio in Washington. In September 1862 Gardner and his team photographed the dead soldiers on the battlefield at Antietam, in Maryland. The American Battlefield Trust estimates that 22,717 soldiers were killed, wounded or missing in that battle.

**"The Dead of Antietam."** Brady showed the photographs at his gallery in New York in October 1862, under a sign that read "The Dead of Antietam." A writer for *The New York Times* reported on October 20 that crowds kept climbing the stairs to see them. "If he has not brought bodies and laid them in our door-yards and along the streets, he has done something very like it," the writer said (door-yards are the yards in front of houses). The article gave Brady the credit.

**Whose name went on the picture.** Brady put the words "Photographed by Brady" on pictures his employees took. In about November 1862 Gardner stopped working for Brady, probably in part because of this. In May 1863 Gardner and his brother James opened their own studio in Washington and hired many of Brady's former workers.

Gardner published a book of 100 of the war's photographs in two volumes in 1866. Under each picture he printed the name of the man who took it, among them Timothy H. O'Sullivan and James F. Gibson. The book did not sell well.

**A body moved for the camera.** After the Battle of Gettysburg, on July 6, 1863, Gardner's team photographed a dead soldier among the rocks at a place called Devil's Den. Gardner later called him a Confederate, a soldier of the Southern states that fought the United States to keep slavery. He titled the picture *Home of a Rebel Sharpshooter*, a sharpshooter being a soldier who shoots at a distance with a rifle.

The historian William A. Frassanito showed in 1975 that the same body appears in six photographs. The photographers had carried the body from the south edge of Devil's Den to a stone wall, and the rifle beside it was probably put there for the picture. In 1998 the artist James Groves argued that the body was carried the other way, out of the wall and to the first spot.

**Known:** the photographers moved the body, which both men agree on.

**Not known:** the soldier's name.

### Winslow Homer

> **Who:** A painter who drew the Civil War for a magazine and later painted the sea.
>
> **When and where:** Born in Boston on February 24, 1836. Drew the Civil War for *Harper's Weekly*. Lived in England from 1881 and in Prouts Neck, Maine, from 1883. Died there on September 29, 1910.

**He sketched the Civil War at the front for *Harper's Weekly*.**

Winslow Homer drew the Civil War at the front for *Harper's Weekly*, a magazine, and he drew everyday life in the soldiers' camps. He began as an apprentice at a lithography company, which printed pictures from drawings made on stone. Then he drew pictures for magazines, among them *Ballou's Pictorial* and *Harper's Weekly*.

**The sea.** He began painting in watercolor in 1873. In 1881 he went to live in Cullercoats, a town in England. In 1883 he moved to Prouts Neck, on the coast of Maine, and the sea became his main subject. He painted people at sea, in pictures such as *The Life Line* and *Fog Warning*. He died at Prouts Neck on September 29, 1910.

### Edmonia Lewis

> **Who:** A sculptor of Mississauga Ojibwe and African American descent, who carved in marble in Rome after she was beaten and falsely charged at college in Ohio.
>
> **When and where:** Born about July 4, 1844, in Greenbush, New York. Oberlin, Ohio, from 1859. Boston. Rome from 1865 or 1866. Died in London on September 17, 1907.

**She sold 100 plaster copies of a bust to pay her way to Rome.**

Edmonia Lewis carved statues in marble in Rome. Before that, at college in Ohio, a group of white men beat her, officials charged her with poisoning two classmates, and college officials kept her from graduating.

She was born in Greenbush, New York, in about 1844. On official papers she gave her birth year as 1842, 1844 and 1854 at different times. Her mother, Catherine Mike Lewis, was of Mississauga Ojibwe and African American descent. Edmonia's name at birth was Wildfire. By the age of nine she had lost both parents. As a girl she and her aunts sold Ojibwe baskets, moccasins and embroidered blouses to tourists at Niagara Falls. Her brother Samuel paid for her schooling with money he made in the gold rush.

**Oberlin.** From 1859 she studied at Oberlin, in Ohio. In the winter of 1862, she gave spiced wine to two white students she lived with, Maria Miles and Christina Ennes, before a sleigh ride. They fell sick. Doctors said they had been poisoned with cantharides, a poison made from blister beetles. Both young women got well.

**Beaten.** One night soon after, Lewis was walking home alone. A group of white men dragged her into an open field, beat her badly and left her for dead. No one ever identified the men who did it. A few days later, officials arrested her for poisoning the two students. She was hurt so badly she could not walk, so her trial was put off.

John Mercer Langston, the first Black lawyer in Ohio, defended her. The court dropped the charges, because no one had tested what was in the young women's stomachs, so there was no proof of poison.

About a year later she was accused of stealing art supplies. The record does not name who accused her. That case was dropped too. But Oberlin officials did not let her sign up for her last term, so she could not graduate. In 2022, more than a hundred years after her death, the leaders of Oberlin College gave her a degree.

**The bust.** She went to Boston and made a bust, a sculpture of a person's head and shoulders, of Colonel Robert Gould Shaw. Shaw had led the 54th Massachusetts, a regiment of Black soldiers, in the Civil War. Lewis sold 100 plaster copies of the bust for $15 each, and the money paid her way to Rome.

Her passport of 1865 says she was "sent by subscription to Italy having displayed great talents as a sculptor" (sent by subscription means that a group of people paid for the trip). In Rome she carved her work in marble.

She told *The New York Times* in 1878: "I was practically driven to Rome in order to obtain the opportunities for art culture, and to find a social atmosphere where I was not constantly reminded of my color. The land of liberty had no room for a colored sculptor." (Colored was a word of that time for Black people.)

**Cleopatra.** Her marble statue *The Death of Cleopatra* was shown at the Centennial Exhibition in Philadelphia in 1876. In 1878 the critic William J. Clark called the way it showed death "ghastly" and "absolutely repellant," which means disgusting. Later a gambler named "Blind John" Condon bought it from a saloon in Chicago. He used it to mark the grave of a racehorse named Cleopatra.

The Smithsonian American Art Museum's record of the statue states that it was thought lost for almost a century. It was later moved to a construction yard in Cicero, Illinois. The scholars Marilyn Richardson and Dorothy Porter Wesley told George Gurney, a curator at the Smithsonian, one of the museum workers who choose and care for its art, about it. In 1994 the Historical Society of Forest Park, Illinois, gave it to the Smithsonian American Art Museum.

**By 1866:** Americans had seen photographs of the dead at Antietam and Gettysburg, and Gardner had printed the name of each man who took them under the war's photographs.

### Pictures of the West, and whose land they showed

Carleton Watkins carried a very large camera into Yosemite Valley, in California, in July 1861. It took pictures on glass plates 18 inches by 22 inches. He came back with 30 of these large plates and 100 smaller negatives. His photographs were shown at a gallery in New York in 1862, and they helped persuade members of Congress to protect the valley. President Abraham Lincoln signed the Yosemite Grant on June 30, 1864.

**The Ahwahneechee.** Yosemite Valley was the home of the Ahwahneechee people. California's governor, John McDougal, raised a force of about 200 armed volunteers on horseback in 1851, called the Mariposa Battalion. Under Major James D. Savage, they invaded the valley in March 1851. According to the National Park Service, the battalion's men burned villages and food supplies, one after another, and forced men, women and children away from their homes.

They marched Tenaya, the leader of the Ahwahneechee, and his people to a reservation on the Fresno River. The National Park Service counts that by 1910, more than 90 out of every 100 of the Ahwahneechee who first lived there were dead or missing.

**Yellowstone.** The photographer William Henry Jackson and the painter Thomas Moran went to Yellowstone with the Hayden survey, a government expedition, in 1871. Jackson took the first known photographs of the Yellowstone falls. When President Ulysses S. Grant signed a law on March 1, 1872, Yellowstone became a national park. That year members of Congress paid Moran $10,000 for his painting *The Grand Canyon of the Yellowstone* and hung it in the Capitol. It shows four small figures in front, and one of them is a Native man.

The Tukudika, a band of Mountain Shoshone, had lived in the Yellowstone area for thousands of years. According to the National Park Service, they were forced onto reservations. The Park Service account does not say who first forced them. In the fall of 1879, the park's superintendent, Philetus W. Norris, found one of their camps. He asked the government agent at Fort Washakie for help. The agent sent a party of Shoshone men to take the Tukudika to the Wind River Reservation.

Timothy O'Sullivan, who had photographed the war, later photographed for the Wheeler survey, an army survey of the West, from 1872 to 1879. The army's orders for that survey included a duty to "discover the numbers, habits, and disposition of Indians." Disposition here meant whether they were likely to be friendly or to fight.

### Why was the Met closed on Sundays?

Many of the founders of the Metropolitan Museum of Art were Protestants, Christians outside the Catholic Church, who refused to open the museum on Sundays. Sunday was the one day off that most working New Yorkers had.

New York's lawmakers approved the founding of the museum on April 13, 1870. It opened on February 20, 1872, on Fifth Avenue, and moved to Central Park in 1880. City officials demanded Sunday opening. In 1885 officials of the city's parks department threatened to cut the museum's money if it stayed closed on Sundays. The trustees, the people in charge of the museum, agreed in the end, although they did not want to. The museum first opened on a Sunday on May 31, 1891, after nearly twenty years of argument.

### Fort Marion: drawings by Plains prisoners

Plains artists had long painted their deeds on buffalo hides. About 30 million buffalo lived on the Plains in the early 1800s, and fewer than 1,000 were left by 1900. Hunters killed them for their hides, and army officers encouraged the killing, because the herds fed the Plains nations. Disease and dry years also cut the herds, and so did the railroads built across the Plains.

With the buffalo gone, Plains artists drew on paper instead, often in ledgers, lined account books meant for keeping records of money. This is now called ledger art. Prisoners held at an army fort in Florida made many ledger drawings.

**Held without trial.** US Army soldiers fought Comanche, Kiowa, Cheyenne and other Plains people on the southern Plains in 1874 and 1875, in what is called the Red River War. After it, army officers charged 72 Cheyenne, Arapaho, Kiowa, Comanche and Caddo people with war crimes, acts in war that break the rules of war, or with being "ringleaders," the leaders of the fighting. General Philip Sheridan ordered them sent "to an eastern fort to be held without trial for an undefined time."

They were 71 men and one woman, named Mochi. A girl of about nine, Black Horse's daughter, went with them. The trip from Fort Sill, in Indian Territory, took 26 days by wagon, train, steamship and oxcart. The poet Sidney Lanier saw them arrive "in leg-irons," chains locked around their ankles.

**Fort Marion.** They were held at Fort Marion, in St. Augustine, Florida, from 1875 to April 1878. Spanish builders had begun the fort in 1672 as the Castillo de San Marcos. Lieutenant Richard Henry Pratt, who was in charge of them, took off their chains. Then he cut the prisoners' hair, put them in army uniforms, made them march in drills, taught them English and sent them out to work for others as laborers.

Army officers kept them in an old fort without proper living quarters. In the Florida summer heat, many prisoners fell sick, and many were deeply sad and homesick. The writer Judith Lee Wilmot says the sickness, the sadness, the heat and the poor quarters together raised the number of prisoners who died.

**"Only give us our women and children."** Mah-mante, a Kiowa leader, asked for that in June 1875. President Grant agreed, and then changed his mind. In 1877 Making Medicine, a Cheyenne man, wrote for the young prisoners: "We have lived in this old place two years. It is old and we are young." He went on: "We want Washington to give us our wives and children, our fathers and mothers. We are willing to learn and want to work."

**The drawings.** Pratt gave the prisoners pencils, ink, crayons, watercolor paint and paper. Twenty-six of them made drawings, all younger Cheyenne, Arapaho and Kiowa men, and Pratt sold their drawings and crafts. The artists included Making Medicine, Howling Wolf, Bear's Heart and Tichkematse, who were Cheyenne, and Zotom, Wohaw, Etahdleuh Doanmoe and Koba, who were Kiowa. White Bear was Arapaho. More than a thousand of their drawings survive in collections around the world.

**The dead.** Ten of the prisoners died in Florida. Amy Larner Giroux, of the University of Central Florida's Center for Humanities and Digital Research, spent five years searching army records for their names. A January 2023 article in UCF News states that she found all ten.

Six of the dead were Cheyenne: Grey Beard, Lean Bear, Big Moccasin, Starving Wolf, Spotted Elk and Heap of Birds. Three were Kiowa: Sun, Mah-mante and Ih-pa-yah. The tenth, Nad-a-with-t, was Comanche.

Grey Beard died on the way to the fort. He jumped out of a window of the train that was taking the prisoners to St. Augustine. The guards had orders to catch him again, but he was shot instead, and the UCF article does not say who fired. He is buried in Piney Grove Cemetery in Baldwin, Florida.

For many years two graves in the St. Augustine National Cemetery, each holding six men, had stones that read only "Six Unknown Indians." That makes twelve men, three more than the nine prisoners who died at the fort. The UCF article does not say who the twelve men are.

Officials of the National Cemetery Administration, the federal office that runs national cemeteries, said in 2023 that they would replace the two markers with headstones that give the prisoners' names.

After their release, Bear's Heart, Koba and Buffalo Meat died of tuberculosis. Making Medicine became a deacon, a church minister, in the Episcopal Church in 1881. Pratt founded the Carlisle Indian School in Pennsylvania, a boarding school for Native children, in 1879. Staff there cut the children's hair, took away their clothes, gave them English names and forbade them to speak their own languages.

### Howling Wolf

> **Who:** A Southern Cheyenne man who lived through the Sand Creek Massacre at 15 and became a ledger artist while a prisoner at Fort Marion.
>
> **When and where:** Born about 1849. The southern Plains, and St. Augustine, Florida, from 1875 to 1878. Died in 1927.

**He drew the massacre at Sand Creek, which he lived through at 15.**

Howling Wolf drew the attack he had lived through as a boy. His Cheyenne name was Ho-na-nist-to. He belonged to the band of the Cheyenne leader Black Kettle.

**Sand Creek.** Colonel John Chivington and the First Regiment of Colorado Volunteers attacked Black Kettle's camp at Sand Creek, in Colorado, on November 29, 1864. Howling Wolf was 15. He and his father, Eagle Head, were in the camp. The counts of Cheyenne and Arapaho people killed there run from about 70 to about 230. Most of the dead were women, children and old people. Among Howling Wolf's drawings is a picture of the massacre.

Army officers sent Howling Wolf to Fort Marion with the other prisoners in 1875. There he served as a sergeant in charge of a guard company made up of prisoners. He drew his people's lives and wars.

**Home.** He was released in 1878 and went home to the Cheyenne reservation in Indian Territory, now Oklahoma. His eyesight began to fail, and he sailed to Boston for an operation on his eyes.

He spoke out against the Dawes Act of 1887. Under that law, federal officials broke up land that each nation held together into small plots for single owners and sold what they called the "surplus." Native nations held about 138 million acres in 1887 and about 48 million acres by 1934, a loss of about 90 million acres.

Howling Wolf died in a car accident in 1927. He was on his way home to Oklahoma after performing in Houston, Texas, in a Wild West show, a traveling show of riding, shooting and scenes of frontier life.

### Painters after the war

Mary Cassatt showed her paintings in Paris with the Impressionists, a group of painters in France. She was born in Allegheny City, now part of Pittsburgh, Pennsylvania, on May 22, 1844. She studied at the Pennsylvania Academy of the Fine Arts from 1861 to 1865, went to Europe in 1866 and settled in Paris in 1874.

The French painter Edgar Degas admired her drawing. At his request she showed her work with the Impressionists in 1879, and again in 1880, 1881 and 1886. Britannica's writers count her as the only American who showed with them in those years. She died near Paris on June 14, 1926.

**Forced out.** Thomas Eakins, born in Philadelphia on July 25, 1844, painted *The Gross Clinic* in 1875. He taught at the Pennsylvania Academy from 1876 and became head of its school in 1882.

During a class that women students attended, he removed the cloth that covered a male model's private parts. In 1886 he had to resign, and the record does not name the people who forced him out. Some of his students then formed their own school, the Art Students' League of Philadelphia, and he taught there. One of his students at the academy was Henry Ossawa Tanner. Eakins died on June 25, 1916.

### Mark Twain

> **Who:** A writer, born Samuel Langhorne Clemens, whose books were sold door to door.
>
> **When and where:** Born November 30, 1835, in Florida, Missouri. Died in Redding, Connecticut, on April 21, 1910.
>
> **Movie:** *Mark Twain* (2001), a documentary by Ken Burns, shown on PBS. It is about his whole life.

**Salesmen going door to door sold 70,000 copies in one year.**

Mark Twain sold his books through salesmen who went from door to door. His real name was Samuel Langhorne Clemens.

**A subscription book.** His book *The Innocents Abroad* came out on July 20, 1869. Elisha Bliss's American Publishing Company sold it as a subscription book. A salesman came to people's homes and showed them the book. They ordered a copy, and it was delivered later. *The Innocents Abroad* sold more than 70,000 copies in its first year. While Twain lived, it sold better than any of his other books.

*The Adventures of Tom Sawyer* came out in 1876. *Adventures of Huckleberry Finn* came out in Britain and Canada on December 10, 1884, and in the United States on February 18, 1885.

**Kept off the shelf.** In 1885 the members of the library committee in Concord, Massachusetts, decided to keep *Huckleberry Finn* out of the town's public library. According to the *Boston Transcript*, one member of the committee called it "the veriest trash," which meant the worst kind of trash.

### Henry Ossawa Tanner

> **Who:** A Black painter who studied under Thomas Eakins and made his career in France.
>
> **When and where:** Born in Pittsburgh on June 21, 1859. Philadelphia. Paris from 1891. Died in Paris on May 25, 1937.

**Students tied him to his easel in the middle of Broad Street.**

Henry Ossawa Tanner was a Black painter who left the United States to work in France. His father, Benjamin Tucker Tanner, was a bishop, a high leader, of the African Methodist Episcopal Church.

Tanner wrote in 1909 about looking for a painting teacher when he was a boy. "The question was not, would the desired teacher have a boy who knew nothing and had little money, but would he have me, or would he keep me after he found out who I was," he wrote. He meant that a teacher might turn him away, or send him away later, because he was Black.

**The academy.** From 1879 to 1885 he studied at the Pennsylvania Academy of the Fine Arts, on and off, under Thomas Eakins. Joseph Pennell, a fellow student, later wrote about a night when other students attacked Tanner. "One night his easel was carried out into the middle of Broad Street and, though not painfully crucified, he was firmly tied to it and left there," Pennell wrote (crucified means fastened to a cross). Pennell did not name the students who did it.

**Paris.** Tanner went to Paris in 1891 to study at a school called the Académie Julian. A bishop from Atlanta, Joseph Crane Hartzell, and his wife paid for the trip by buying every painting in a show of Tanner's work. In Paris other American students mocked him. In 1893 he came home sick with typhoid fever, a disease spread by dirty water and food. In Philadelphia he painted *The Banjo Lesson*. Then he went back to Paris. Apart from short visits home, he lived there for the rest of his life.

His painting *The Resurrection of Lazarus* won a third-place medal at the Paris Salon, a large yearly art show, in 1897, and French government officials then bought it. In 1923 he was made a member of the Legion of Honor, an order of people honored by France for their work.

### The Shaw Memorial

A committee of 21 people in Boston hired the sculptor Augustus Saint-Gaudens in August 1882 to make a memorial to Colonel Robert Gould Shaw and the men of the 54th Massachusetts. The regiment had attacked Fort Wagner, in South Carolina, in July 1863. Joshua Bowen Smith, a Black man in Boston who had worked for the Shaw family, is credited with first proposing it. The writer Lydia Maria Child wrote that "the colored soldiers who fell ought to have a monument also."

**Fourteen years.** Saint-Gaudens worked on it for 14 years, longer than on anything else he made. He did not use photographs of the real soldiers or meet them. Instead he hired Black men he met on the street near his studio and made about 40 studies of their heads.

**Whose names.** Shaw's sister, Josephine Lowell, asked for the names of all the men of the 54th killed at Fort Wagner and afterward to be carved on the base. Her request failed, and the records do not say who turned it down. When the memorial went up, its base carried only the names of the white officers. The names of the Black soldiers were added in the early 1980s. The National Park Service account of the memorial does not say who added them.

The memorial was unveiled on Boston Common on May 31, 1897. Sixty-five veterans of the 54th led the parade, and Sergeant William Carney carried the flag.

### Dickinson's poems, and Riis's flash photographs

Emily Dickinson of Amherst, Massachusetts, wrote nearly 1,800 poems. Only 10 were published while she was alive. She died on May 15, 1886, and her sister Lavinia found the poems after her death. Thomas Wentworth Higginson and Mabel Loomis Todd chose and prepared the poems for the first book of them, which came out in 1890.

That same year Jacob Riis published *How the Other Half Lives*, about the tenements of New York, the crowded buildings where poor families rented rooms. To photograph the inside of the dark tenements, he used magnesium flash powder, which burns with a sudden bright light.

**If you remember one thing:** By 1900 photographs and cheap books reached millions of Americans, and the Black and Native artists of the time had worked in Rome and Paris or drawn as prisoners in Florida.

**In 1850:** a photograph was a single picture on a silvered copper plate that could not be copied, and the Metropolitan Museum of Art did not yet exist.

**In 1900:** the Met had been open on Sundays since 1891, Gardner's war photographs were in print with each photographer's name, and Jacob Riis had photographed the inside of New York's tenements by flash.

**Next:** In the next fifty years, a show of modern European paintings draws jokes in New York, and federal officials begin paying artists a weekly wage.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 25 minutes**

Americans argued over what counted as art from the first big show of modern paintings in 1913 on, and in the 1930s federal officials paid artists for the first time, though Black artists had to organize before they were given that work. About 75,000 people came to see modern European paintings at the Armory Show in New York in 1913, and its paintings drew jokes. In Harlem in the 1920s and 1930s, Black painters, sculptors, photographers and writers worked side by side.

Federal officials paid thousands of artists a weekly wage from 1935 to 1943. Government photographers recorded hungry farm families in the 1930s. In 1942 one of them photographed Japanese American families as soldiers and officials forced them into camps, and officials kept most of those pictures out of public view.

### The Armory Show, 1913, and photographs as art

The International Exhibition of Modern Art, which people call the Armory Show, ran from February 17 to March 15, 1913, in the 69th Regiment's armory on Lexington Avenue in New York, a large building where the unit's soldiers trained and kept their weapons.

A group of American painters and sculptors organized it. Its catalog listed 1,090 works by 306 artists, and several hundred more were added during the show. About 75,000 people came to see it in New York. By the end of its tour to Chicago and Boston, nearly 300,000 people had seen it.

**The jokes.** Marcel Duchamp's painting *Nude Descending a Staircase* drew jokes. The critic Julian Street called it "an explosion in a shingle factory." Theodore Roosevelt said it looked like the Navajo rug in his bathroom. The sculptor Gutzon Borglum, one of the show's early organizers, called it "a staircase descending a nude."

**A pretend trial.** In Chicago, on April 16, 1913, students of the School of the Art Institute held a pretend trial of the painter Henri Matisse. They charged him with "pictorial arson," arson being the crime of setting fire to something on purpose, and "criminal misuse of line." Then they burned copies they had painted of three of his pictures, among them *Blue Nude*. School officials had told them not to. A reporter for the *Chicago Evening Post* counted two hundred students and more than a thousand people watching.

The photographer Alfred Stieglitz argued that a photograph could be fine art, as a painting was. He published *Camera Work*, a magazine of photographs, from 1903 to 1917. He also ran a gallery at 291 Fifth Avenue in New York from 1905 to 1917, and people called the gallery 291.

### Georgia O'Keeffe

> **Who:** A painter whose drawings Alfred Stieglitz showed in New York in 1916, and who later lived and painted in New Mexico.
>
> **When and where:** Born November 15, 1887, on a dairy farm at Sun Prairie, Wisconsin. Texas, New York, and New Mexico from 1929. Died in Santa Fe on March 6, 1986.
>
> **Movie:** *Georgia O'Keeffe* (about 1977), a documentary by Perry Miller Adato, made with the New York public television station WNET. It is about her life and work.

**Stieglitz hung ten of her drawings at 291 in April 1916.**

Georgia O'Keeffe first showed her work in Alfred Stieglitz's gallery, 291, in April 1916. That fall she became head of the art department at West Texas State Normal College, in Canyon, Texas, a college that trained teachers. She married Stieglitz in 1924.

**New Mexico.** From 1929 she spent her summers painting in New Mexico. In late 1945 she bought a house at Abiquiu, New Mexico, from the Catholic Church in Santa Fe. Stieglitz died in 1946, and in 1949 she moved to New Mexico for good.

An eye disease called macular degeneration had destroyed the center of her sight by 1972, and she could see only at the sides. She had stopped painting in oils without help. She died in Santa Fe on March 6, 1986, at the age of 98.

### Native artists, the boarding schools, and the Studio

Angel De Cora was a Ho-Chunk painter from the Winnebago Agency in Nebraska, born on May 3, 1871. In her own account, a strange white man came to the reservation when she was a child and asked her, through an interpreter, if she would like to ride on a steam train. When the ride ended she was at the boarding school at Hampton, Virginia, a school where children live as well as study. "[It was] three years later when I returned to my mother," she said.

As an adult De Cora taught art at the Carlisle Indian School in Pennsylvania, the school Richard Henry Pratt had founded. She died on February 6, 1919.

Zitkala-Ša was a Yankton Dakota writer who lived from 1876 to 1938. In 1900 three of her essays ran in the *Atlantic Monthly* magazine. Two were about her childhood and her boarding school, and the third was about her work as a teacher. Her book *American Indian Stories* came out in 1921.

**The Studio.** A white teacher named Dorothy Dunn asked Chester Faris, the head of the Santa Fe Indian School, a federal boarding school in New Mexico, to let her open a painting studio there in 1932. The Studio opened on September 9, 1932, and by 1937 it had 170 students.

Dunn chose not to teach the students to draw real people and things as the eye sees them. She did not teach them to make objects look near or far, or to mix colors by rule. She taught one style: flat areas of color with heavy outlines, showing ceremonies, dances and old stories. She believed it "was the only authentic painting style for Native American artists to follow" (authentic means real and true to its roots).

**What her students said.** Her students disagreed about her. The Chiricahua Apache artist Allan Houser said, "she trained us all the same way... Her style lacked originality and creativity." Geronima Cruz Montoya, of Ohkay Owingeh Pueblo in New Mexico, said Dunn "made us realize how important our own Indian ways were, because we had been made to feel ashamed of them." She added, "She gave us something we could be proud of."

Dunn left in 1937. Montoya then ran the Studio until it closed in 1962. Other students included Pablita Velarde, the first girl in the art classes, and Harrison Begay, Quincy Tahoma, Oscar Howe, Pop Chalee and Andrew Tsinajinnie. Members of Congress created the Indian Arts and Crafts Board inside the Interior Department in 1935, while the Studio was running. They meant the board to widen the market for Native arts and crafts.

**A basket worked out from a photograph.** Lottie Queen Stamper, of the Eastern Band of Cherokee Indians in North Carolina, taught basket weaving for more than 30 years. In 1940 she found a photograph of the Cherokee double-woven baskets taken to London in 1725, two baskets woven one inside the other from the same strips.

She spent two and a half days working out the pattern from the photograph. Then she wove a copy from 500 splints, thin strips cut for weaving. "This, indeed, was the happiest day of my life," she wrote. "Now it was my duty to teach it to my brightest students."

People building along the rivers had destroyed many patches of cane by the middle of the 1900s. The weaver Eva Wolfe drove 80 miles to Hayesville, North Carolina, to gather river cane.

### Maria Martinez

> **Who:** A potter at San Ildefonso Pueblo, a Tewa town in New Mexico, known for black-on-black pottery.
>
> **When and where:** Born Maria Poveka Montoya at San Ildefonso, probably in 1887. Died there on July 20, 1980.
>
> **Movie:** *Maria Martinez: Indian Pottery of San Ildefonso* (1972), a documentary that shows her and her son Popovi Da making pottery at the pueblo.

**The black on her pots comes from smoke and dried manure.**

Maria Martinez and her husband, Julian Martinez, made black-on-black pottery at San Ildefonso Pueblo, a Tewa pueblo about 20 miles northwest of Santa Fe. Maria was born there, probably in 1887. Her aunt Nicolasa taught her to work clay.

**Fairs and copies.** In 1904 the couple showed how they made pottery at the World's Fair in St. Louis. Between 1907 and 1909, the archaeologist Edgar Lee Hewett asked Maria to make copies of ancient pots dug up at a site where he worked. Maria shaped the pots and Julian painted them. They showed their work again at fairs in San Diego in 1914 and Chicago in 1934.

**The black.** While the pots are fired, the potters smother them with dried manure, and the smoke turns the clay black. Potters at Santa Clara Pueblo had made polished black pots since the 1600s, and Maria learned the method from the Tafoya family there. In 1918 Julian finished the first pot with a dull black design on a shining black surface.

Maria signed the pots "Marie" from 1923 to 1925. From 1925 until Julian died in 1943, she signed them "Marie + Julian." Later she signed with her daughter-in-law, Santana, and then with her son, Popovi Da. Popovi Da built a shop at the pueblo and sold the family's work.

Officials of the Santa Fe Indian School asked Maria to teach there in 1932. She said no. "I come and I work and they can watch ... nobody teaches," she said. She died at San Ildefonso on July 20, 1980.

**By 1932:** Stieglitz had shown that a photograph could hang in a gallery, Maria and Julian Martinez had been making black-on-black pots since 1918, and the Studio in Santa Fe was teaching Native students a single style.

### The Harlem Renaissance

Black painters, photographers and writers worked side by side in Harlem, in New York City, in the 1920s and 1930s. This time is called the Harlem Renaissance, renaissance being a French word that means rebirth.

**Van Der Zee.** James Van Der Zee was born in Lenox, Massachusetts, in 1886. He and Gaynella Greenlee opened the Guarantee Photo Studio on West 125th Street in Harlem in 1916, where he made portraits of his customers. In 1919 he photographed the victory parade of the 369th Infantry Regiment, an army unit. He also photographed the leader Marcus Garvey. His work became widely known in 1969, when it hung in a show called *Harlem on My Mind* at the Metropolitan Museum of Art.

**Hughes.** Langston Hughes was born in Joplin, Missouri, in 1901. His poem "The Negro Speaks of Rivers" came out in 1920 (Negro was a word people then used for Black people). Readers first noticed him through *The Crisis*, a magazine. His first book of poems, *The Weary Blues*, came out in 1926.

**Douglas.** Aaron Douglas was a painter from Topeka, Kansas. He meant to stop in Harlem in 1925 on his way to Paris, and he stayed. He designed the cover of the magazine *Fire!!* in 1926 and drew pictures for Alain Locke's book *The New Negro*.

Douglas painted a set of four murals, paintings made on a wall or for a wall, for the 135th Street branch of the New York Public Library in 1934, paid through a federal program. The murals are called *Aspects of Negro Life*. They show Africa, slavery and the years after the Civil War, then lynching, the killing of a person by a mob without any trial, and segregation, keeping people apart by race, and then the move north.

Douglas started the art department at Fisk University, in Nashville, in 1944, and he taught there until 1966.

### Augusta Savage

> **Who:** A sculptor and art teacher in Harlem, who taught Jacob Lawrence and lost her largest sculpture for lack of money.
>
> **When and where:** Born Augusta Christine Fells on February 29, 1892, in Green Cove Springs, Florida. Harlem from the 1920s. A farm at Saugerties, New York, from about 1940. Died in New York City on March 27, 1962.
>
> **Movie:** *Searching for Augusta Savage* (2024), a short documentary by Charlotte Mangin and Sandy Rattley for the PBS series *American Masters*. It is about her life and her lost work.

**Her 16-foot harp was bulldozed when the World's Fair closed.**

Augusta Savage taught young artists in Harlem, among them Jacob Lawrence, and she lost her largest sculpture because she had no money to save it. Her father, Edward Fells, was a Methodist minister in Florida who said her clay figures were sinful. Her own words about him are printed by the public television station WMHT: "My father licked me four or five times a week," and he "almost whipped all the art out of me." (Licked here meant beat. Some other printings of her words say "kicked" instead.)

**Turned away.** In 1923 she was chosen for a summer art school at Fontainebleau, in France. French officials offered the school to 100 American women, and her place came with a $500 scholarship. When the American committee that chose the students learned that she was Black, its members took her place away.

Savage told the *New York World*: "My brother was good enough to be ... [in a] regiment that saw service in France during the war, but it seems his sister is not good enough to be a guest of the country for which he fought." One committee member, the sculptor Hermon MacNeil, had supported her, and he invited her to study with him.

**A teacher in Harlem.** She opened the Savage Studio of Arts and Crafts in a basement on West 143rd Street in 1934. Jacob Lawrence, Norman Lewis and Gwendolyn Knight studied with her. In 1935 she helped start the Harlem Artists Guild. In 1937 she became the first director of the Harlem Community Art Center, which opened on December 27, 1937. By one count, 70,592 children and adults took part in its first sixteen months. Another count gives 1,500 people.

**The Harp.** The organizers of the 1939 New York World's Fair hired her to make a sculpture. She was the only African American woman given such a job. She made *Lift Every Voice and Sing*, named after a song by James Weldon Johnson. It was a harp 16 feet tall. Its strings were twelve Black singers, and the arm and hand of God formed its sounding board. The fair's organizers renamed it *The Harp*.

She made it of plaster painted to look like black stone. She needed money to cast it in bronze, which means pouring melted metal into a mold of the sculpture. She sold small metal copies as souvenirs, but she never raised enough. When the fair closed in 1940, its temporary buildings and plaster art were bulldozed, and *The Harp* with them. No record names who gave the order. Some of the small copies survive.

In about 1940 she moved to a farm at Saugerties, New York, and mostly left the art world.

### Zora Neale Hurston

> **Who:** A novelist and folklorist, someone who collects the stories, songs and sayings that people pass along by word of mouth.
>
> **When and where:** Born January 7, 1891, in Notasulga, Alabama. Grew up in Eatonville, Florida. Harlem, Haiti and Jamaica. Died in Fort Pierce, Florida, on January 28, 1960.
>
> **Movie:** *Zora Neale Hurston: Jump at the Sun* (2008), a documentary by Sam Pollard for the PBS series *American Masters*. It is about her life and writing.

**She never earned more than $943.75 from any one of her books.**

Zora Neale Hurston wrote novels and collected the stories of Black Southerners, and she died poor. She grew up in Eatonville, Florida. According to the official Hurston website, Eatonville was the nation's first incorporated Black township, which means the state recognized it as a town by law, with its own government.

**Kossola.** In 1927 she interviewed Kossola, also called Cudjo Lewis. He was one of the last survivors of the *Clotilda*, the last known ship to bring captives from Africa to the United States.

Soldiers of Ghezo, the king of Dahomey in West Africa, attacked Kossola's town in April 1860 and took him captive. Captain William Foster bought him and other captives there for Timothy Meaher, a businessman in Mobile, Alabama. In July 1860 Foster smuggled about 110 Africans into Mobile on the *Clotilda*, to be enslaved. Bringing enslaved people into the country had been against federal law for 52 years. In Mobile, Meaher's brother James enslaved Kossola.

**The books.** Hurston wrote a book from what Kossola told her and called it *Barracoon*, the word for a pen where captives were held until a ship took them. It was not published until 2018, 58 years after she died. She gathered Black folktales in Florida for her book *Mules and Men* (1935), and stories in Haiti and Jamaica for *Tell My Horse* (1938). Her novel *Their Eyes Were Watching God* came out in 1937. In 1938 and 1939 she worked in Florida for the Federal Writers' Project.

Her royalties, the share of each book's price that goes to the writer, never came to more than $943.75 for any of her books. She had a stroke in early 1959. In October 1959 she had to enter the St. Lucie County Welfare Home, a home the county ran for people with no money, and she died there on January 28, 1960. Her neighbors in Fort Pierce collected money for her funeral, but not enough for a headstone.

**Saved from the fire.** After she died, a yardman cleaning out her house began burning her papers. Patrick DuVal, a law officer and her friend, put out the fire, and the papers went to the University of Florida. She lay in an unmarked grave in the Garden of Heavenly Rest, a cemetery for Black people only, until August 1973. That month the novelist Alice Walker found the spot and placed a marker there.

### Painters of the 1930s and 1940s

Grant Wood painted *American Gothic* in 1930. His models were his sister, Nan Wood Graham, and the family dentist, Byron McKeeby. They stand in front of a house in Eldon, Iowa. The painting won a bronze medal and $300 at the Art Institute of Chicago. One judge called it a "comic valentine." Some Iowans who read about it in the *Cedar Rapids Gazette* were angry. They felt it showed them as "pinched, grim-faced, puritanical Bible-thumpers."

Edward Hopper painted *Nighthawks* in 1942, and on May 13 of that year the Art Institute of Chicago bought it for $3,000.

Norman Rockwell's four paintings called the *Four Freedoms* ran in the *Saturday Evening Post* in February and March 1943, one each week. The paintings then went on a tour of 16 cities, where people bought war bonds, loans to the government to pay for World War II. About 1.2 million people saw the paintings, and the tour raised about $132 million.

### Who did the government pay to make art?

Federal officials paid thousands of artists a weekly wage through the Federal Art Project, but Black artists had to organize to be hired. The project ran from August 29, 1935, to June 30, 1943, as part of the Works Progress Administration, the federal jobs program of the Great Depression, the hard years of the 1930s when many people had no work. Holger Cahill directed it.

**The pay.** Most of its artists had to show they were poor enough to get government aid. They earned about $23.50 a week, and each had to turn in a finished work within a set number of weeks. According to Britannica, project officials employed more than 5,000 artists at its peak in 1936. Another count puts the total at about 10,000 artists and craft workers.

They made about 400,000 paintings, murals, prints and posters, and they opened more than 100 community art centers. When officials cut the budget and sent out notices that ended people's jobs, artists held sit-down strikes, refusing to leave their workplaces.

**The Harlem Artists Guild.** The project's rules said workers must be hired fairly, whatever their race, but Black artists were routinely refused work. The records do not name the people who turned them away. Augusta Savage, Charles Alston, Elba Lightfoot, Louise E. Jefferson, Arthur Schomburg and others started the Harlem Artists Guild in 1935, with Aaron Douglas as its president. Alston called it "a pressure group to get more black artists on the federal projects." According to *Black Art in America*, Alston became the first Black supervisor on the project.

**Harlem Hospital.** Alston, Vertis Hayes and Georgette Seabrooke designed murals for Harlem Hospital in 1936. According to the Harlem history project Harlem-is, it was the first mural job the WPA gave to African American artists anywhere in the country. The head of the hospital rejected the sketches because of their "Negro subject matter." Members of the Guild and the Artists Union wrote to Mayor Fiorello La Guardia and President Franklin Roosevelt, and the murals were then painted as the artists had planned.

**Post office murals.** Edward Bruce ran a second program, in the Treasury Department, from 1934 to 1943. Its artists painted about 1,400 murals for post offices in more than 1,300 towns and cities. For each new post office, about 1 percent of the building money was set aside to pay for art.

Bruce's officials pushed the artists toward American scenes and away from subjects that might start public quarrels. They also kept them away from abstract art, which shows shapes and colors instead of things. In Safford, Arizona, local people who were "still resentful about Apache raids" demanded a different subject for a mural, and the subject was changed. The account of the Safford mural does not say who changed it.

Federal officials also hired writers, for the Federal Writers' Project. From 1936 to 1938 its interviewers in 17 states recorded more than 2,300 first-person accounts by people who had been enslaved. The Library of Congress holds the accounts.

### Jacob Lawrence

> **Who:** The painter of the *Migration Series*, sixty panels about Black families moving north.
>
> **When and where:** Born September 7, 1917, in Atlantic City, New Jersey. Philadelphia, Harlem from the age of 13, and Seattle. Died in Seattle on June 9, 2000.

**He painted all 60 panels at once, one color at a time.**

Jacob Lawrence painted all 60 panels of *The Migration Series* in 1940 and 1941, when he was 22 and 23. His parents split up in 1924. From 1927 to 1930 he and his younger brother and sister lived in foster care in Philadelphia, with families paid to raise children not their own, while their mother worked in New York City.

**Harlem teachers.** At 13 he moved with his mother to Harlem. He took art classes with Charles Alston at the Harlem Art Workshop. Augusta Savage got him a scholarship to the American Artists School and a paid place on the federal art project.

**The series.** Before *The Migration Series* he painted series of pictures about the lives of Toussaint L'Ouverture in 1938, Frederick Douglass in 1939 and Harriet Tubman in 1940. Toussaint L'Ouverture was born enslaved in the French colony that is now Haiti, and he became a leader of the revolution that ended slavery there. A grant, a gift of money, from the Julius Rosenwald Fund paid for *The Migration Series*. The panels show the Great Migration, when Black families moved from the South to cities in the North.

He wrote a caption for each panel first. Then he painted all 60 at the same time, one color at a time. Each panel is 12 inches by 18 inches. In November 1941 the editors of *Fortune* magazine printed panels from the series with an essay by Alain Locke. Today the Phillips Collection in Washington holds the odd-numbered panels, and the Museum of Modern Art in New York holds the even-numbered ones.

**By 1941:** Federal officials had paid thousands of artists a wage, Black artists in Harlem had organized to get some of that work, and Jacob Lawrence had painted the Great Migration in 60 panels.

### Photographs of hunger, and photographs of the camps

Officials of the federal Resettlement Administration, later called the Farm Security Administration, paid photographers in the 1930s to record poor farm families. In March 1936 Dorothea Lange stopped at a camp of pea pickers at Nipomo, California. Freezing rain had destroyed the crop, and as many as 2,500 to 3,500 people were camped there.

**Migrant Mother.** Lange made seven pictures of a mother and her children. One of them became known as *Migrant Mother*, and it is one of the most reprinted pictures of the Great Depression. The government caption reads: "Destitute pea pickers in California. Mother of seven children. Age thirty-two" (destitute means so poor that a person has nothing to live on).

**Two accounts.** Lange later wrote, "I did not ask her name or her history." She wrote that the mother said the family had been living on frozen vegetables from the fields and on birds the children killed. The mother had just sold the tires from her car to buy food, Lange wrote. The mother's son, Troy Owens, said later, "There's no way we sold our tires, because we didn't have any to sell." He thought Lange had mixed up two stories. The two accounts do not agree.

**Florence Owens Thompson.** The mother was Florence Owens Thompson, born on September 1, 1903, in Indian Territory, now Oklahoma. The records of her family's Cherokee ancestry disagree. Cherokee Nation records list her father as Cherokee, while her mother said she had Cherokee ancestors but told a federal commission that her own parents were both white. The government had paid for the photograph, so anyone could print it for free, and neither Lange nor Thompson earned money from it.

A reporter for the *Modesto Bee*, Emmett Corrigan, found her in 1978, about 42 years after the picture was taken. She was living in a mobile home park in Modesto, California, and he printed her name. "I wish she hadn't taken my picture. I can't get a penny out of it. She didn't ask my name," she told him. "She said she wouldn't sell the pictures. She said she'd send me a copy. She never did."

Her children asked for help with her medical bills in 1983, when she was sick. More than 2,000 letters came with money. "For Mama and us, the photo had always been a bit of [a] curse," Troy Owens said. "After all those letters came in, I think it gave us a sense of pride." She died on September 16, 1983.

**The camps.** President Franklin Roosevelt signed Executive Order 9066, an order from the president that has the force of law, on February 19, 1942. Under it, Lieutenant General John L. DeWitt, who commanded the Army on the West Coast, ordered Japanese Americans out of their homes, some with only 48 hours' notice.

Soldiers and federal officials sent about 122,000 men, women and children to ten camps. They held them there behind wire fences watched by armed guards in towers. Nearly 70,000 of them were American citizens. That year officials of the War Relocation Authority, the agency that ran the camps, hired Lange to photograph the forced removal.

### Dorothea Lange

> **Who:** A photographer paid by the federal government to record poor families in the 1930s and the forced removal of Japanese Americans in 1942.
>
> **When and where:** Born Dorothea Nutzhorn on May 26, 1895, in Hoboken, New Jersey. California and the West. Died October 11, 1965.
>
> **Movie:** *Dorothea Lange: Grab a Hunk of Lightning* (2014), a documentary for the PBS series *American Masters*, directed by her granddaughter Dyanna Taylor. It is about her life and work.

**At Manzanar, officials would not let her photograph the guard towers.**

Dorothea Lange photographed Japanese American families as soldiers and officials forced them from their homes in 1942, and officials kept most of those photographs from the public. As a child she had polio, a disease that attacks the nerves, and it left her with a limp.

**What she photographed.** In 1942 she photographed families getting ready to leave their homes between Fresno and Sacramento. She photographed the Tanforan assembly center at San Bruno, a holding camp at a racetrack, where horse stalls had been turned into rooms for families. She also photographed the Manzanar camp. She made more than 800 photographs.

Officials discouraged her from talking with the prisoners. At Manzanar they did not allow her to photograph the wire fences, the watch towers, the armed guards or any sign that people were resisting. On July 30, 1942, officials of the War Relocation Authority let her go, with the note "completion of work."

**Held back.** Army officers judged her pictures critical of the camps and held them until the war ended, according to the National Coalition Against Censorship. The Densho Encyclopedia says officials of the War Relocation Authority kept most of them from public view. Neither account names the officers who gave the order.

After the war, the coalition says, the photographs were "quietly placed" in the National Archives. It does not say who placed them there. In 2006 the historians Linda Gordon and Gary Y. Okihiro published a selection of them in a book called *Impounded*.

Lange wrote to the photographer Ansel Adams on November 12, 1943: "I fear the intolerance and prejudice is constantly growing." She died on October 11, 1965.

### A book banned and burned, 1939

John Steinbeck's novel *The Grapes of Wrath* came out on April 14, 1939. It was the best-selling book of 1939, and by February 1940 publishers had printed 430,000 copies. It won the National Book Award and the Pulitzer Prize.

**The ban.** The members of the Kern County Board of Supervisors in California voted 4 to 1 in August 1939 to take the book out of the county's libraries and schools. One supervisor called it a "libel and lie," a libel being a printed lie that harms someone's good name. Bill Camp, who led the Associated Farmers, a group of large landowners, pushed for the ban. He had one of his workers, Clell Pruett, burn a copy in a trash can for a newspaper photographer. Pruett had not read the book.

**The librarian.** The county librarian, Gretchen Knief, wrote to the supervisors: "Ideas don't die because a book is forbidden reading. If Steinbeck has written the truth, that truth will survive." She did not throw the books away. She offered them to other county libraries. The book went back on the shelves in January 1941.

### Paintings sent abroad, and called back, 1946 and 1947

J. LeRoy Davidson, an art historian at the State Department, spent just under $50,000 in 1946 on 79 modern American paintings by 47 artists, among them Georgia O'Keeffe. He sent them to tour other countries in a show called *Advancing American Art*.

One congressman said, "I am just a dumb American who pays taxes for this kind of trash." President Harry Truman also mocked the paintings. He said that if that was art, then he was a member of an African people. The word he used for them was an insult that Europeans used for the Khoekhoe people of southern Africa.

**Called back.** Accounts differ on who stopped the tour, and when. The art historian Jennifer McComas writes that the tour was stopped in early April 1947. By her account, members of Congress had cancelled it by the end of that month, cut off the State Department's art program and done away with Davidson's job. The writer Matthew Algeo says instead that Secretary of State George Marshall ended the show in early May, and told a House committee that the paintings would be brought home and sold.

Officials sold the paintings, along with 38 watercolors, in June 1948 by sealed bid, in which buyers send in secret offers and the highest offer wins. Three universities in Alabama, Oklahoma and Georgia bought 81 of the 117 works.

**If you remember one thing:** For the first time, federal officials paid thousands of American artists to work, and other officials decided which pictures and books the public could see.

**One number:** About $23.50 a week was the pay of a Federal Art Project artist. In 1942 the Art Institute of Chicago paid $3,000 for one painting, Hopper's *Nighthawks*, more than two years of that wage.

**Next:** After 1950, painters in New York make pictures with no objects in them at all, and officers of the CIA secretly pay to send some of them abroad.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 21 minutes**

After 1950 the fights over who made American art, who profited from it and who paid for it came into the open. Painters in New York after 1950 made pictures that showed no objects at all, and officers of the CIA secretly paid for shows that sent some of that painting to Europe. In the 1960s other artists painted soup cans and comic strips, and the prices of paintings climbed. A painting that Robert Rauschenberg sold for $900 went for $85,000 at an auction in 1973.

Black and Chicano artists painted murals on neighborhood walls and bridge pillars, and women and Black artists protested at museums that left them out. In 1987 volunteers laid 1,920 quilt panels on the National Mall for people who had died of AIDS, a disease that destroys the body's defenses against other illnesses.

Members of Congress fought in 1989 and 1990 over whether public money should pay for art that some of them called offensive. In 1990 they also passed laws to protect Native artists' work and to return Native remains and sacred objects to the nations.

### Painting with no objects in it

Jackson Pollock laid his canvas on the floor from 1947 to 1950 and dripped and poured paint onto it. Other people called his way of working drip painting or action painting. His pictures showed no things that a viewer could name. This kind of painting, abstract because it shows no real objects, is called Abstract Expressionism. The historian Frances Stonor Saunders writes that the center of the art world had been moving from Paris to New York since the 1930s.

### Jackson Pollock

> **Who:** A painter who dripped and poured paint onto canvas laid on the floor.
>
> **When and where:** Born January 28, 1912, in Cody, Wyoming. New York City, then Springs, on Long Island, New York. Died there on August 11, 1956.
>
> **Movie:** *Pollock* (2000), a feature film directed by Ed Harris, who also plays Pollock. It is about his life.

**"On the floor I am more at ease," he wrote in 1947.**

Jackson Pollock explained his method in 1947, in a magazine called *Possibilities*: "I prefer to tack the unstretched canvas to the hard wall or the floor. I need the resistance of a hard surface. On the floor I am more at ease. I feel nearer, more a part of the painting, since this way I can walk around it, work from the four sides and literally be in the painting." He wrote that this was like the method of the Native sand painters of the West.

Pollock had married the painter Lee Krasner in 1945. On August 8, 1949, the editors of *Life* magazine put this question in a headline over a story about him: "Jackson Pollock: Is he the greatest living painter in the United States?"

**The crash.** On the night of August 11, 1956, in Springs, New York, Pollock drove his car while drunk. He crashed less than a mile from his home and was killed, and so was his passenger Edith Metzger. A second passenger, Ruth Kligman, survived.

### The CIA and the painters

The historian Frances Stonor Saunders reported in *The Independent*, a British newspaper, in 1995 that officers of the CIA had helped promote Abstract Expressionism in other countries. The CIA, the Central Intelligence Agency, is the government's spy agency.

In those years the United States and the Soviet Union were rivals in the Cold War, a long contest for power and friends around the world that never became open war between the two. The Soviet government's official style of art was called Socialist Realism. Its paintings looked like real life, only better, and they showed simple stories in support of the government's ideas, such as workers winning their freedom.

**What a CIA man said.** Donald Jameson, a former CIA officer, told Saunders that CIA officers saw a chance in this new painting. He said "Abstract Expressionism was the kind of art that made Socialist Realism look even more stylised and more rigid." The support came "at two or three removes," he said, which means through other groups. The painters did not know.

Tom Braden, who led a CIA division from 1950, had worked at the Museum of Modern Art in New York in 1949. "We wanted to unite all the people who were writers, who were musicians, who were artists," Braden said, "to demonstrate that the West and the United States was devoted to freedom of expression."

**The money's route.** The money went through the Congress for Cultural Freedom, a group set up with CIA money in 1950 and run by a CIA agent. It had offices in 35 countries and paid for touring shows of American art. One, "The New American Painting," visited every large city in Europe in 1958 and 1959. Staff of the Museum of Modern Art organized most of these shows.

Accounts differ about how much this mattered to the painters or to their fame. The art historian Jennifer McComas writes that the claims hold "some truth." She also writes that some of the writers who made them got facts wrong and chose only the shows that fit their argument.

**Not known:** the amount of money spent on the painting shows.

### Photographs and books

The photographer Robert Frank won a Guggenheim Fellowship, a grant of money for artists and writers, in 1955. He used it to pay for trips across the United States. In the South, a sheriff told him he had "an hour to leave town." His book of photographs, *The Americans*, came out in Paris in 1958 and in New York in 1959. A writer in *Popular Photography* called the pictures "meaningless blur, grain, muddy exposures, drunken horizons and general sloppiness."

Black writers won national prizes and reached Broadway in the 1950s. Ralph Ellison's novel *Invisible Man*, about the problems Black Americans faced in the early 1900s, came out in 1952. It won the National Book Award in 1953, and Ellison was the first African American writer to win it.

Lorraine Hansberry's play *A Raisin in the Sun* opened on Broadway on March 11, 1959. It follows a Black family in Chicago that buys a house in a white neighborhood, where a man from the neighborhood offers to buy them out. Its director, Lloyd Richards, was the first Black director of a Broadway play, and the New York Drama Critics' Circle named it the best play of the year.

### Gordon Parks

> **Who:** A photographer, the first African American staff photographer at *Life* magazine.
>
> **When and where:** Born November 30, 1912, in Fort Scott, Kansas. Washington, D.C., from 1942. New York. Died in New York on March 7, 2006.
>
> **Movie:** *Half Past Autumn: The Life and Works of Gordon Parks* (2000), a documentary about his life.

**He photographed a cleaning woman with her mop before the flag.**

Gordon Parks was the first African American photographer on the staff of *Life* magazine. He grew up in Fort Scott, Kansas, the youngest of 15 children, and went to a segregated elementary school, a school for Black children only. He bought his first camera at a pawnshop, a store that lends money and sells things people leave there and do not come back for.

**Washington, 1942.** Parks won a Julius Rosenwald Fellowship in 1942 and went to Washington, D.C., to work for the Farm Security Administration. Workers in restaurants and shops in the segregated capital refused to serve him.

After that he photographed Ella Watson, a Black woman on the cleaning crew of the agency's building. She stands with a broom and a mop in front of an American flag. He titled the picture *American Gothic, Washington, D.C.*, after Grant Wood's 1930 painting *American Gothic*, which shows a farmer holding a pitchfork beside a woman in front of their house. His boss, Roy Stryker, said the picture was an attack on America and could get all his photographers fired.

Parks published a photo essay, a set of photographs that tell a story, about a young gang leader in Harlem in 1948. It won him a staff job at *Life*, and he stayed at the magazine until 1972.

### Pop Art, and the price of a painting

Pop Art painters of the early 1960s made pictures of comic strips, soup cans and famous faces. Roy Lichtenstein painted scenes from comic strips in oil paint. His 1961 painting *Look Mickey* is now in the National Gallery of Art in Washington.

**Thirty-two soup cans.** Andy Warhol showed 32 paintings of Campbell's soup cans at the Ferus Gallery in Los Angeles in July 1962. Each canvas is 20 inches by 16 inches. The art dealer Irving Blum, who bought and sold art for a living, bought all 32 for $1,000, paid in ten monthly payments of $100.

The Museum of Modern Art got them from Blum in 1996. In 1970 one of Warhol's soup-can paintings sold at auction for $60,000. At that time it was the highest auction price for a living American artist.

**$900, then $85,000.** Robert Scull, who owned a fleet of taxis, sold 50 works from his art collection at an auction in New York on October 18, 1973, for about $2.2 million. Years earlier, Robert Rauschenberg had sold Scull his painting *Thaw* for $900. That night it sold for $85,000. Artists received nothing when their work was sold again. Rauschenberg shoved Scull and told him he had been working hard for Scull to make that profit.

### Andy Warhol

> **Who:** A painter who made pictures of soup cans, dollar bills and famous faces. His studio was called the Factory.
>
> **When and where:** Born Andrew Warhola Jr. on August 6, 1928, in Pittsburgh. New York. Died in New York on February 22, 1987.
>
> **Movie:** *Andy Warhol: A Documentary Film* (2006), a four-hour documentary by Ric Burns, shown on PBS. It is about his life.

**Told to paint what he liked most, he answered, "money."**

Andy Warhol started out drawing pictures for magazines before he made his paintings of soup cans. His parents were working-class immigrants, Rusyns from the village of Miková, in what is now northeastern Slovakia. His father worked in a coal mine.

**Drawings for magazines.** Warhol moved to New York in 1949. There Tina Fredericks, an editor at *Glamour* magazine, bought a drawing of an orchestra from him for $10. Through the early 1950s his drawings appeared regularly in fashion magazines and in *The New York Times*.

**Silkscreens.** In 1961 a printer, Floriano Vecchi, taught him silkscreen printing, in which the artist puts a design on a fine screen and pushes ink through it with a rubber blade, so the same picture can be printed again and again. His first silkscreens, made in early 1962, showed one-dollar and two-dollar bills.

Muriel Latow, who knew him from the art world, had told him to paint what he liked most, and he answered, "money." One of his best-known early silkscreen paintings is *Marilyn Diptych*, from 1962, a picture in two parts of the actress Marilyn Monroe.

His studio was called the Factory. On June 3, 1968, the writer Valerie Solanas shot Warhol and the critic Mario Amaya at the Factory. Warhol was in the hospital for nearly two months. He died in New York on February 22, 1987, after an operation on his gallbladder.

**By 1973:** Paintings by New York artists had toured Europe in shows paid for in secret with CIA money, and a Rauschenberg painting bought for $900 had resold for $85,000.

### Walls, bridges and museums: art made as protest

**A walk to school.** Ruby Bridges, who was six, walked into William Frantz Elementary School in New Orleans on November 14, 1960, between four federal officers called deputy US marshals. She and three other six-year-old girls at another school that day were the first Black children in white public schools in Louisiana. A crowd outside screamed at her.

Norman Rockwell painted her walk in 1963, the year he left the *Saturday Evening Post*, whose editors limited what political subjects he could paint. On the wall behind her he painted a racial slur, the letters "KKK" and a smashed tomato. KKK stands for the Ku Klux Klan, a white group that has threatened, beaten and killed Black people. The editors of *Look* magazine printed the painting, *The Problem We All Live With*, on January 14, 1964.

**The Wall of Respect.** Fourteen artists of the Organization of Black American Culture, among them William Walker, painted the *Wall of Respect* in 1967 on the side of a closed bar at 43rd Street and Langley Avenue in Chicago. It showed Nat Turner, Harriet Tubman, W. E. B. Du Bois, Marcus Garvey, Malcolm X, Gwendolyn Brooks, Muhammad Ali, Aretha Franklin and others. In the eight years after it, artists painted more than 1,500 murals across the country.

A fire damaged the building in 1971. The building was then torn down, and the mural with it. The records do not say who ordered the building torn down.

**Chicano Park.** Barrio Logan is a Mexican American neighborhood of San Diego, and many Mexican Americans call themselves Chicano. Highway builders cut the neighborhood in two with Interstate 5 in 1963, and in 1969 they cut it again with the ramps of the bridge to Coronado. City officials approved a park under the bridge that June and then did nothing.

A student named Mario Solis saw bulldozers there on April 22, 1970, getting the land ready for a parking lot for a California Highway Patrol station. Residents took over the land.

City officials set aside $21,814.96 for a park of 1.8 acres, called Chicano Park, on July 1, 1970. The artist Salvador Torres had proposed painting the bridge pillars. The artist Victor Ochoa brought 300 brushes on March 23, 1973, and nearly 300 people painted all weekend. The artists raised the money for the paint themselves.

**At the museums.** Faith Ringgold and other artists protested at the Whitney Museum of American Art in New York in 1970, because its show of American art had no Black artists in it. They also demanded that half the artists it showed be women.

Judy Chicago finished *The Dinner Party* in 1979. It is a table with three sides, set with 39 places for 39 women from history and legend, among them Sacajawea, Sojourner Truth, Susan B. Anthony, Virginia Woolf and Georgia O'Keeffe. Each place has a hand-painted plate. Most of the plates show a butterfly or flower shape that stands for a vulva, the outer part of a woman's sex organs.

The critic Hilton Kramer called it "very bad art ... failed art." Representative Robert K. Dornan called it "ceramic 3-D pornography" (pornography means pictures or objects made to show sex). The writer Alice Walker objected that Sojourner Truth, the one Black woman at the table, was shown in a different way from the white women. Truth's plate shows three faces instead.

The board of the University of the District of Columbia voted in 1990 to accept it as a gift. After the *Washington Times* printed stories against it, the plan was dropped. The records do not say who dropped it. *The Dinner Party* is now at the Brooklyn Museum.

**Mining the Museum.** The artist Fred Wilson rearranged the collection of the Maryland Historical Society in Baltimore in 1992 for a show called *Mining the Museum*. In a case of fine silver, he placed shackles that had been used to chain enslaved people. He also hung Justus Engelhardt Kühn's portrait of Henry Darnall III, the Maryland boy painted in about 1710 with an enslaved Black boy beside him. Wilson lit the face of the enslaved boy and played a recorded voice asking, "Am I your brother?"

In another room he set old chairs facing a whipping post. Several writers said that the post had been used on enslaved people, but it came from the Baltimore City jail, where officials had used it to whip men convicted of beating their wives.

**On the subway walls.** Jean-Michel Basquiat and Al Diaz wrote graffiti, writing or drawing on walls without permission, signed "SAMO" on walls in Manhattan in the late 1970s. Basquiat later became a painter. He died of a heroin overdose on August 12, 1988, at 27.

**Michael Stewart.** New York City Transit Police officers arrested Michael Stewart, a 25-year-old Black artist, at the First Avenue subway station on September 15, 1983, for writing graffiti. While the officers held him, he went into a coma, a state like deep sleep that a person cannot wake from. He died on September 28. The city's medical examiner, the doctor who studies a body to find the cause of death, said his heart had stopped. Others disputed that finding.

Six officers were tried for causing his death by carelessness, for assault and for lying under oath. On November 24, 1985, an all-white jury found them not guilty. A lawsuit over his death was later settled for $1.7 million. Basquiat painted *Defacement (The Death of Michael Stewart)* about him.

Keith Haring drew in the early 1980s in white chalk on the black paper that covered empty advertising frames in New York subway stations. He learned he had AIDS in 1988, and in 1989 he started the Keith Haring Foundation. He died on February 16, 1990.

### Faith Ringgold

> **Who:** A painter and quilt maker who also wrote and illustrated children's books.
>
> **When and where:** Born Faith Willi Jones on October 8, 1930, in Harlem. New York City. Died in Englewood, New Jersey, on April 13, 2024.

**Her quilt *Tar Beach 2* shows a girl flying over Harlem.**

Faith Ringgold painted stories on quilts, and police arrested her during the protest at the Whitney. For years she taught art in New York City public schools. In 1967 she painted *The Flag Is Bleeding* and *Die* for a series called *The American People*.

**Arrested.** With the critic Lucy Lippard and the artist Poppy Johnson, she started the Ad Hoc Women's Art Committee, which joined the protest at the Whitney. The museum owned work by Jacob Lawrence but left him out of its show. Police arrested Ringgold on November 13, 1970. That year she and her daughter, Michele Wallace, also started a group called Women Students and Artists for Black Art Liberation.

**Quilts.** From the 1980s she painted stories on quilts. *Tar Beach 2* (1990) shows Cassie Louise Lightfoot, an eight-year-old girl who dreams of flying over Harlem. She wrote and illustrated more than a dozen children's books.

### Native artists and Native objects

Oscar Howe was a Yanktonai Dakota painter, born on the Crow Creek Sioux Reservation in South Dakota in 1915, who had studied at Dorothy Dunn's Studio in Santa Fe. In 1958 the judges of the Indian art show at the Philbrook Museum in Tulsa, Oklahoma, turned down his painting as "a fine painting, but not Indian."

**Howe's answer.** "Who ever said, that my paintings are not in the traditional Indian style, has poor knowledge of Indian art indeed," Howe wrote back. "There is much more to Indian Art, than pretty, stylized pictures." He added: "Are we to be herded like a bunch of sheep, with no right for individualism, dictated as the Indian has always been."

**Scholder and Cannon.** When the Studio closed in 1962, the Institute of American Indian Arts opened in Santa Fe. Fritz Scholder, a registered member of the La Jolla Band of Luiseño Indians, taught there from 1964. From 1967 he painted Native people with American flags, beer cans and cats. The paintings started an argument, among Native artists too, that still goes on.

The Cherokee painter Roy Boney Jr. said of *Indian with Beer Can* (1969): "While some might find the image offensive or even ugly," it "definitely was not a maiden on the river or a warrior on horseback, and I liked that."

T. C. Cannon, a Kiowa and Caddo painter, studied at the Institute. He served in Vietnam in 1967 and 1968 as a paratrooper, a soldier who jumps from planes, and he won two Bronze Stars, medals for brave or useful service in war. He died in 1978 at the age of 31.

Cannon was one of the Americans who served in that war. In 1981 a student, Maya Lin, 21, won the contest to design the memorial to them in Washington, the Vietnam Veterans Memorial. The judges knew the 1,421 entries only by number, not by name. Chapter 12 tells her story in full.

**Two laws of 1990.** Members of Congress passed the Indian Arts and Crafts Act in 1990. Under it, selling work as made by a Native artist when it was not is a crime. A person who does it for the first time can be fined up to $250,000 or sent to prison for five years, or both. A business can be fined up to $1,000,000.

President George H. W. Bush signed the Native American Graves Protection and Repatriation Act, called NAGPRA, on November 16, 1990. Representative Mo Udall had introduced it. Repatriation means sending something back home. Under the law, museums and agencies that take federal money must return Native human remains, objects buried with the dead, sacred objects and objects that belong to a whole nation, to descendants and to the Native nations.

Some of those remains and objects had been dug out of graves and mounds, among them the remains of more than 600 people that workers took out of Craig Mound at Spiro after the Pocola Mining Company's dig, which the first era of this chapter tells.

### The AIDS Memorial Quilt, 1987

Cleve Jones, an activist in San Francisco, learned in November 1985 that more than 1,000 people in his city had died of AIDS. He made the first quilt panel, for his friend Marvin Feldman. In June 1987 he, Mike Smith, Gert McMullin and others started the NAMES Project Foundation.

Each panel is three feet by six feet, about the size of a grave, and each one is made in memory of people who died of AIDS. Many people who died of AIDS had no funeral. Some of their families were ashamed, and workers at many funeral homes and cemeteries refused to handle their bodies.

**On the Mall.** Volunteers laid 1,920 panels on the National Mall in Washington on October 11, 1987, over an area larger than a football field. They read all 1,920 names aloud. About half a million people came that weekend. By October 1989 the quilt had more than 12,000 panels. In October 1996 the whole quilt covered the Mall for the last time, and about 1.2 million people came to see it.

### Fights over public money for art, 1989 and 1990

The National Endowment for the Arts, or NEA, is a federal agency that gives money to artists and museums. In 1987 the photographer Andres Serrano made a picture of a small plastic crucifix, a model of Jesus on the cross, in a glass of his own urine. It won an award of $15,000, paid for in part with NEA money.

Senators Al D'Amato and Jesse Helms attacked the award in 1989. Some members of Congress called art like this obscene, so shocking or indecent that some people want it banned, or blasphemous, insulting to God or religion. Serrano received death threats and hate mail, and he lost grants.

**Mapplethorpe.** Robert Mapplethorpe was a photographer who died of AIDS on March 9, 1989. A show of more than 150 of his photographs was then touring the country. It held portraits, nudes and pictures of flowers. It also held photographs that showed sex between men openly, some of it sex that involves pain, and two photographs of young children without clothes. At each museum, staff hung the sex pictures in a separate area that children could not enter.

Christina Orr-Cahall, director of the Corcoran Gallery of Art in Washington, cancelled the show in June 1989, because she feared for the NEA's money. Senator Helms then proposed that no NEA money could pay for "obscene" art. For a time, artists who took NEA grants had to sign a promise not to promote obscenity.

**A museum on trial.** The Mapplethorpe show opened at the Contemporary Arts Center in Cincinnati in 1990. After a campaign by a group called Citizens for Community Values, law officers ordered 400 visitors out of the museum and videotaped the photographs. Government lawyers charged the museum and its director, Dennis Barrie, with obscenity. It was the first time a museum in the United States was put on trial for art it showed. On October 5, 1990, a jury found them not guilty. More than 80,000 people saw the show in Cincinnati.

The NEA chairman, John Frohnmayer, turned down grants to four performance artists, who put on live shows, in June 1990 because of what their work was about. They were Karen Finley, Tim Miller, John Fleck and Holly Hughes. Panels of experts had already approved the grants. The four artists won in court in 1993. In 1998 the justices of the Supreme Court ruled in favor of the way the NEA chose its grants. After that, NEA officials stopped giving most grants to single artists.

### Toni Morrison

> **Who:** A novelist and book editor who won the Nobel Prize in Literature.
>
> **When and where:** Born Chloe Ardelia Wofford on February 18, 1931, in Lorain, Ohio. Syracuse, then New York City. Died in the Bronx on August 5, 2019.
>
> **Movie:** *Toni Morrison: The Pieces I Am* (2019), a documentary by Timothy Greenfield-Sanders about her life and work.

**She found Margaret Garner's story while making *The Black Book*.**

Toni Morrison published other Black writers as an editor before she became a famous novelist herself. In about 1965 she began work as an editor for a textbook company owned by Random House, in Syracuse, New York. About two years later she moved to Random House in New York City. There she was the first Black woman senior editor in the fiction department.

**The editor.** As an editor she published the novelist Gayl Jones, whose writing she had discovered, and the writer Toni Cade Bambara. She also published books by the activist Angela Davis and the boxer Muhammad Ali. She published the poet Henry Dumas, whom a transit officer had shot dead in a New York subway station in 1968. The records do not name the officer.

She and the collector Middleton A. Harris put together *The Black Book*, a collection of old papers, photographs, advertisements and pictures about Black life in America, in 1974.

**Beloved.** Her first novel, *The Bluest Eye*, came out in 1970. While working on *The Black Book*, she found the story of Margaret Garner. On January 28, 1856, Garner and her family escaped from slavery to a place near Cincinnati, Ohio. When slave catchers came for them, Garner killed her two-year-old daughter, Mary, with a knife rather than see the child returned to slavery. That story became the base for Morrison's novel *Beloved* (1987), which won the Pulitzer Prize in 1988. In 1993 she won the Nobel Prize in Literature.

**If you remember one thing:** Between 1950 and 2000 the fights over art moved into the open, in museums, in courts and in Congress, and in 1990 members of Congress ordered museums that take federal money to return Native remains and sacred objects.

**Left open:** how much the museums would really give back under the 1990 law, and how fast.

**Next:** After 2000 a new federal rule makes museums cover or close their Native displays, and computer programs begin making pictures in the style of living artists.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 24 minutes**

Almost every adult now carries a camera in a phone, and the old arguments about art have come back over new things: computer programs that copy artists' styles, Native remains in museums, and what national museums may show. After 2022, computer programs could make pictures in the style of living artists, and some of those artists sued the companies that made the programs.

Under a rule that took effect in January 2024, museums must get a Native nation's consent before they show its ancestors' remains or sacred objects.

Two Black artists painted the official portraits of a president and a first lady in 2018. In 2025 one of them cancelled her show at a national museum after officials there questioned one of her paintings. That year officials of President Donald Trump's administration ended many federal arts grants and asked for a review of eight Smithsonian museums.

### A camera in every pocket

A smartphone has a camera built in, so anyone who owns one can take a picture at any moment. In a survey taken from February to June 2025, researchers at the Pew Research Center found that 91 out of every 100 adults in the United States owned a smartphone. In Pew's first survey about smartphones, in 2011, only 35 out of every 100 did.

### Who is in the picture

Officials of the National Portrait Gallery in Washington unveiled the official portraits of former President Barack Obama and former First Lady Michelle Obama on February 12, 2018. Kehinde Wiley painted the former president, and Amy Sherald painted the former first lady. According to the gallery's staff, Wiley and Sherald were the first African American artists chosen to paint the gallery's official portraits of a president or a first lady.

Wiley painted Obama sitting in front of a wall of leaves and flowers. The chrysanthemums stand for Chicago, the jasmine for Hawaii and the African blue lilies for Kenya, his father's country. Sherald titled her painting *Michelle LaVaughn Robinson Obama*.

The two portraits then toured museums, first the Art Institute of Chicago, and in 2022 Atlanta, Houston, San Francisco and Boston. The Los Angeles County Museum of Art was another stop. At the Art Institute of Chicago, the crowds broke the museum's records for daily attendance again and again, according to the Portrait Gallery.

**Kara Walker.** Kara Walker was born in Stockton, California, on November 26, 1969. She cuts figures out of black paper and sets them up in scenes, as big as a room, about slavery in the South. In 1997, when she was 28, she won a MacArthur Fellowship, a large prize of money given to people for creative work. That same year the artist Betye Saar sent letters to about 200 artists and politicians. Saar objected that Walker's work used racist pictures of Black people.

In a 1999 PBS documentary, Saar called the work "revolting and negative" and said it pandered to "the white art establishment," which means it gave those people what they wanted, to win their favor. Other writers call Walker one of the most prominent and praised Black American artists working today.

**A sugar sphinx.** Inside the old Domino Sugar Refinery in Brooklyn, from May to July 2014, before the building was torn down, Walker showed a huge white figure coated in sugar. It was a sphinx, a creature with a lion's body and a human head, and its face had the features of a Black woman. Fifteen smaller figures stood around it.

She called it *A Subtlety, or the Marvelous Sugar Baby*. Its full title calls it a tribute to "the unpaid and overworked Artisans who have refined our Sweet tastes from the cane fields to the Kitchens of the New World." The unpaid workers in the cane fields were enslaved people.

### Amy Sherald

> **Who:** The painter of Michelle Obama's official portrait and of Breonna Taylor, who cancelled her own show at the National Portrait Gallery in 2025.
>
> **When and where:** Born August 30, 1973, in Columbus, Georgia. Baltimore, then New Jersey from 2018.

**She cancelled her own show at the National Portrait Gallery.**

Amy Sherald waited tables until she was 38 while she kept painting, and then she painted Michelle Obama's official portrait. She studied painting at Clark Atlanta University, where she finished in 1997, and at the Maryland Institute College of Art in Baltimore, where she finished in 2004. She taught art at the Baltimore City Detention Center.

**A new heart.** When she was 30, doctors found that she had congestive heart failure, which means her heart could not pump blood well enough. On December 18, 2012, when she was 39, she had a heart transplant, an operation that gave her the heart of a person who had died.

**The portrait contest.** In 2016 she won the National Portrait Gallery's portrait contest with a painting called *Miss Everything (Unsuppressed Deliverance)*. She was the first woman and the first African American to win it. Two years later, gallery officials unveiled her portrait of Michelle Obama. In 2018 she moved from Baltimore to New Jersey.

**Breonna Taylor.** Police officers in Louisville, Kentucky, forced their way into Breonna Taylor's apartment on March 13, 2020, with a warrant to search for drugs. Taylor was a Black woman. Her boyfriend fired one shot, the officers fired 32, and a shot by officer Myles Cosgrove killed her. No officer was charged with killing her. One officer, Brett Hankison, whose shots hit no one, was later convicted in federal court of using too much force.

For the September 2020 cover of *Vanity Fair*, Sherald painted Taylor's portrait. The Smithsonian's National Museum of African American History and Culture and the Speed Art Museum in Louisville bought the painting together.

**The cancelled show.** A large show of Sherald's work, *American Sublime*, hung at the San Francisco Museum of Modern Art and at the Whitney Museum of American Art in New York in 2024 and 2025. It was due at the National Portrait Gallery in September 2025.

Officials at the gallery, whom the reports do not name, raised "concerns" about one painting, *Trans Forming Liberty*. It shows a transgender woman, someone whose sense of being a woman is different from the sex written down at birth, in the pose of the Statue of Liberty. The officials talked about taking the painting out of the show.

Sherald cancelled the show on July 24, 2025. "I cannot in good conscience comply with a culture of censorship, especially when it targets vulnerable communities," she said. In a statement, Smithsonian officials said they had proposed adding a video to explain the painting. The Baltimore Museum of Art showed *American Sublime* instead, from November 2, 2025, to April 5, 2026.

### Answering the Confederate statues

Delegates from seven Southern states that had left the United States met in Montgomery, Alabama, in February 1861 and set up the Confederate States of America, called the Confederacy. Its leaders then fought the United States in the Civil War to keep slavery.

**Rumors of War.** A show of the painter Kehinde Wiley's work opened at the Virginia Museum of Fine Arts in 2016. While he was there, he saw the Confederate statues on Monument Avenue in Richmond, Virginia. He then made *Rumors of War*, a bronze statue of a young Black man in jeans and sneakers riding a horse. The pose copies the statue of the Confederate general J. E. B. Stuart on Monument Avenue. It stands more than 27 feet tall.

It was first shown in Times Square in New York in September 2019. On December 10, 2019, it was unveiled outside the Virginia Museum of Fine Arts in Richmond, where it stays. Museum staff estimated the crowd at more than 5,000 people. Work by Wiley is also in the Freedom Monument Sculpture Park in Montgomery, Alabama, which opened on March 27, 2024.

**Charlottesville.** A bronze statue of the Confederate general Stonewall Jackson, made by Charles Keck in 1921, stood in Charlottesville, Virginia, for 100 years. At a rally in Charlottesville called Unite the Right, on August 12, 2017, James Alex Fields Jr. drove his car into people protesting against the rally. He killed Heather Heyer, who was 32. City workers took the Jackson statue down on July 10, 2021, along with a statue of Robert E. Lee.

The members of the City Council voted, all in favor, to give the Jackson statue to The Brick, an art gallery in Los Angeles. Kara Walker cut the bronze apart and joined the pieces into a new shape, which she finished in 2023. She called it *Unmanned Drone*. The Museum of Contemporary Art in Los Angeles bought it in February 2026. In October 2023 members of the Jefferson School African American Heritage Center melted down the Lee statue, in a project called Swords into Plowshares.

**MONUMENTS.** The Museum of Contemporary Art and The Brick showed ten statues that had been taken down from public places, most of them Confederate, in a show called *MONUMENTS*, from October 23, 2025, to May 3, 2026. New works by living artists stood beside them, and Kara Walker helped choose the works.

The oldest statue in the show was an 1887 figure of Roger B. Taney. As chief justice, the head judge of the Supreme Court, he wrote the Dred Scott decision of 1857, which held that Black Americans were not and could never be citizens. Hamza Walker, the director of The Brick, said the works "address the questions of who we want to be as a nation, and who and what is worth remembering, let alone celebrating."

### Street murals after 2020

A Minneapolis police officer, Derek Chauvin, murdered George Floyd on May 25, 2020, by kneeling on his neck for more than nine minutes. In the weeks after the murder, people painted words and portraits on walls, on streets and on the plywood boards nailed over shop windows. In 2021 a jury convicted Chauvin of murder.

A team at the University of St. Thomas in St. Paul, Minnesota, led by the professors Heather Shirey, Todd Lawrence and Paul Lorah, began recording this art in early June 2020, from small stickers to large murals. Some of the painted boards were taken down, stored and later shown in exhibits.

**Black Lives Matter Plaza.** Washington's mayor, Muriel Bowser, had the words "Black Lives Matter" painted across two blocks of 16th Street in early June 2020, days after federal officers used tear gas on protesters in Lafayette Square near the White House. The yellow letters were 48 feet wide. She renamed the spot Black Lives Matter Plaza. Keyonna Jones, one of the artists who painted it, said, "We are saying it loud. We are here." According to NPR, the whole project cost more than $4 million.

Representative Andrew Clyde of Georgia introduced a bill in early March 2025 to cut federal money to the city unless it removed the words and renamed the spot Liberty Plaza. Bowser had earlier called the mural permanent. Now she announced it would go: "now we can't afford to be distracted by meaningless congressional interference." Workers of the District Department of Transportation began tearing it out on March 10, 2025.

**By 2025:** Kehinde Wiley's *Rumors of War* stood in Richmond, Kara Walker had cut a Confederate general's statue apart, and workers were tearing out the painted words on 16th Street in Washington.

### What museums hold, and what goes back

Officials of the Interior Department announced new rules for NAGPRA, the 1990 law on returning Native remains and sacred objects, on December 6, 2023. The rules took effect on January 12, 2024. A museum must now get the consent of the Native nation, or of the dead person's descendants, before it shows Native human remains or sacred objects. The same consent is needed before staff study them or let others get at them.

These remains and objects had been taken from Native graves and lands in earlier years, by men such as the diggers at Mound City in 1846 and at Spiro in the 1930s.

**Halls closed.** Museum leaders closed or covered Native displays in January 2024. Sean Decatur, president of the American Museum of Natural History in New York, closed its Eastern Woodlands and Great Plains halls on January 27, 2024, and covered seven more cases. He wrote to his staff that the halls came from "an era when museums such as ours did not respect the values, perspectives, and indeed shared humanity of Indigenous peoples."

About 500,000 children visit that museum each year on school or camp trips. In October 2023 museum officials had said that about 26 out of every 100 of the 12,000 human remains the museum held were Native American.

Staff at the Field Museum in Chicago, the Cleveland Museum of Art and the Metropolitan Museum of Art covered cases or took objects down. Harvard's Peabody Museum closed most of its floors on January 16, 2024, while its staff asked Native leaders which objects to remove, and they took down nearly 40. No one has published a count of every museum that did the same.

**Fines.** According to *The Art Newspaper*, from 1990 to early 2024 museums paid less than $60,000 in all in fines for breaking NAGPRA, and those fines came from 20 museums. Kelly Applegate, of the Mille Lacs Band of Ojibwe, wrote to the Interior Department that museums had used the law's wording "to not give complete information about the entirety of their collections."

**The count.** The latest federal count comes from the National Park Service, in a report published on May 29, 2026. Since 1990, museums and federal agencies have reported holding the remains of 222,824 Native people. For 142,389 of them, officials have published a notice naming the nation or the family with the right to them. That notice is a legal step, and it does not mean the person's body has gone home.

As of September 30, 2025, the remains of 80,435 people had not yet gone through those legal steps. They were held by 381 museums and 104 federal offices. The report states that each year museums find and report remains they had never listed before. As of September 2026, the 2024 rule was still in force.

**Dave's jars.** Some returns fall outside NAGPRA. The Museum of Fine Arts in Boston gave the descendants of David Drake, the enslaved potter and poet, ownership of two jars he made in 1857, on October 29, 2025. The museum's officials said Drake "was not permitted to possess the jars and did not receive remuneration for them," which means he was not paid. The jars had been sold for the profit of his enslaver, Lewis J. Miles.

The family kept one jar and lent it back to the museum, and museum officials bought the other one from them. On that second jar, called the Poem Jar, Drake wrote: "I made this Jar = for cash / Though its called Lucre trash" (lucre is an old word for money).

### Jeffrey Gibson

> **Who:** A painter and sculptor, a member of the Mississippi Band of Choctaw Indians and of Cherokee descent, the first Native artist to represent the United States alone at the Venice Biennale.
>
> **When and where:** Born March 31, 1972, in Colorado Springs, Colorado. Grew up in North Carolina, New Jersey, West Germany and South Korea. Lives near Hudson, New York.

**In 2024 his work alone filled the United States pavilion in Venice.**

Jeffrey Gibson was the only artist shown in the United States Pavilion at the Venice Biennale in 2024. The Biennale is an international art show held in Venice, Italy, where each country shows its artists in its own building, called a pavilion. According to SITE Santa Fe, one of the show's sponsors, he was the first Native artist to represent the United States there alone.

**His parents' schools.** Both of Gibson's parents had attended boarding schools as children. At the federal boarding schools for Native children, staff had for many years cut the children's hair, taken away their clothes and forbidden them to speak their own languages.

**London.** He studied painting at the School of the Art Institute of Chicago and at the Royal College of Art in London. The Mississippi Band of Choctaw Indians paid for his study in London. "My chief felt that me going there, being a strong artist, made him stronger," he said.

His paintings and sculptures use bright color, detailed patterns and written words. According to the Portland Art Museum, he mixes American, Native and queer history with music and popular culture, queer being a word many gay and lesbian people use for themselves. He won a MacArthur Fellowship in 2019.

**Venice and after.** His Venice show ran from April 20 to November 24, 2024. He named it *the space in which to place me*, after a poem by the Oglala Lakota poet Layli Long Soldier. The same sponsor says it was also the first United States pavilion organized by a Native curator, a museum worker who chooses the art for a show and plans it. She was Kathleen Ash-Milby of the Portland Art Museum.

Four large sculptures by Gibson, of a deer, a coyote, a squirrel and a hawk, stood on the front of the Metropolitan Museum of Art in New York from September 12, 2025, to June 9, 2026. On April 9, 2026, the Obama Foundation said it had asked him to make a wall of 17 round prints for the Obama Presidential Center.

### Prices, and a picture that is only a file

The highest prices paid for paintings by American artists have reached hundreds of millions of dollars. A buyer paid $195 million at Christie's auction house in New York on May 9, 2022, for Andy Warhol's 1964 portrait of Marilyn Monroe, *Shot Sage Blue Marilyn*. The money went to a charity for children in Zurich, Switzerland.

The Associated Press reported that no work by an American artist had ever sold for more at auction, and as of September 2026 none had. Sixty years before that sale, an art dealer had bought all 32 of Warhol's soup-can paintings for $1,000.

Paintings by Basquiat and Pollock have also sold for more than $100 million. The Warhol beat the $110.5 million paid in 2017 for a 1982 painting of a skull by Jean-Michel Basquiat, the painter who had once written graffiti on Manhattan walls. In May 2026 a painting by Jackson Pollock, *Number 7A, 1948*, sold for $181.2 million, according to the *Robb Report*.

Paintings by women have sold for much less. Georgia O'Keeffe's *Jimson Weed/White Flower No. 1* sold for $44.4 million in 2014. According to the Associated Press, that was the most ever paid at auction for a work by a woman until November 20, 2025, when a painting by the Mexican painter Frida Kahlo sold for $54.7 million.

**A picture that is only a file.** A digital picture by Mike Winkelmann, who calls himself Beeple, sold at Christie's on March 11, 2021, for more than $69.3 million, according to Al Jazeera. It is a collage of 5,000 pictures he made, one each day, starting on May 1, 2007. The buyer, Vignesh Sundaresan, a programmer based in Singapore, paid in Ether, a kind of digital money.

What Sundaresan bought was a digital token, a record kept on a network of computers that names one person as the owner of a file. With it he got the right to show the picture. He did not get the copyright, the legal right to copy the work and sell copies.

Sundaresan and Beeple also both owned part of a different set of tokens, tied to other Beeple works. The price of those tokens rose to its highest during the sale and then fell sharply, and some people called the sale a publicity stunt.

### Pictures made by computer programs

Anyone could type a few words into a website and get a picture back by the summer of 2022, as NPR reported.

**The lawsuit.** Kelly McKernan, Sarah Andersen, Karla Ortiz and other artists sued Stability AI, the company behind the program Stable Diffusion, along with Midjourney and the art website DeviantArt, in January 2023. Accounts give the date as January 12 or January 13.

In their lawsuit, the artists say the companies built these programs by feeding them huge collections of pictures gathered from the internet. They say the collection behind Stable Diffusion held more than five billion pictures, copied without asking the people who made them. These are the artists' claims, and no court has yet ruled on whether they are true.

Judge William Orrick in San Francisco let the artists' copyright claims go forward on August 12, 2024. As of September 2026, the case was still before him, and no trial had been held, according to the court's record of the case.

**No human author.** The computer scientist Stephen Thaler asked the US Copyright Office on November 3, 2018, to register a picture made by his computer program, with the program named as the only author. On August 12, 2019, officials refused, because the picture had no human author.

The officials relied in part on an 1884 Supreme Court case. In it the justices decided that a photograph of the writer Oscar Wilde counted as a work of art, because it came from the photographer's own ideas, his "intellectual invention." A picture with no person's ideas behind it, the officials reasoned, had no author who could own it.

Judges on a federal appeals court agreed with the refusal in 2025. On March 2, 2026, the justices of the Supreme Court declined to hear Thaler's appeal. As the law stood in 2026, according to the National Constitution Center, no one could hold the copyright to a picture made by a program with no human author.

### Kelly McKernan

> **Who:** An illustrator and painter, one of three artists who sued the makers of picture-making programs in January 2023.
>
> **When and where:** Born 1986. Nashville, Tennessee.

**People typed "in the style of Kelly McKernan" more than 12,000 times.**

Kelly McKernan was one of three artists who sued the companies behind picture-making programs in January 2023. McKernan uses the words they and them. They live in Nashville, Tennessee, where they teach at the Nossi College of Art and Design. McKernan is a single parent.

**Twenty years online.** McKernan joined DeviantArt, a website where artists share their work, as a high school student in 2002. For about 20 years they posted paintings there, "not for money," and built a following. In January 2023 McKernan told NPR: "I almost barely make rent most months. I will spend, you know, 30 hours on a painting, and I won't see any money from that until it sells."

**Their name on someone else's picture.** People using picture programs had typed the words "in the style of Kelly McKernan" more than 12,000 times. Some people sold the results on websites such as Redbubble, with McKernan's name attached. "There's more and more images with my name attached to it that I can see my hand in, but it's not my work," McKernan said.

**In court.** Judge William Orrick dismissed most of the claims in the artists' case on October 30, 2023, and allowed them to rewrite them. Cleary Gottlieb, a law firm that represents Midjourney, wrote a report on the ruling. According to that report, he dismissed McKernan's copyright claims because McKernan had not registered those paintings with the Copyright Office. In 2023 *Time* magazine named McKernan to its list of the 100 most influential people in artificial intelligence. By September 2026 McKernan's name was no longer on the list of artists suing.

### Books

More writers now publish their own books, without a publishing company. Every book for sale carries an identifying number called an ISBN, and in the United States a company called Bowker hands these numbers out. By Bowker's count, reported by the publishing writer Jane Friedman, writers who published their own books took out numbers for about one and a half times as many new books in 2021 as in 2018.

Spending on audiobooks grew too. Americans spent $2.43 billion on them in 2025, 9 percent more than in 2024, according to a survey for the Audio Publishers Association.

**Books taken off the shelves.** School and library officials removed or restricted thousands of books in the mid-2020s. Two groups count this, and their numbers differ because they count different things. PEN America, a group of writers that defends free expression, counts each time school officials remove or restrict a book. It counted 10,046 in the 2023-24 school year and 6,870 in 2024-25.

The American Library Association counts attempts it hears about to remove books from school, public and college libraries, listed by title. It counted 4,235 different titles in 2025, and it found that 92 out of every 100 of those attempts were started by "pressure groups, government officials and decision makers."

**Which books, and why.** The books PEN America found removed most often included *A Clockwork Orange*, a 1962 novel by Anthony Burgess, and *Sold*, a 2006 novel by Patricia McCormick about a girl sold into sexual slavery in India. PEN America says that books showing gay, lesbian or transgender people were often called "sexually explicit," among them *And Tango Makes Three*, a picture book about two male penguins at New York's Central Park Zoo who raise a chick together.

In July 2025 federal officials removed nearly 600 titles from the schools the Defense Department runs on military bases. According to PEN America, those books did not fit President Trump's orders on diversity, race and "gender ideology extremism."

**Wilder's name.** Laura Ingalls Wilder's Little House books, about her family's life as settlers on the frontier, came out from 1932 to 1943. The board of the Association for Library Service to Children took her name off its award for children's books on June 23, 2018. The award had carried her name since 1954.

The board members wrote that her books include "expressions of stereotypical attitudes inconsistent with ALSC's core values," a stereotype being an unfair, fixed idea about a whole group of people. They acted after critics pointed to how her books show Native and Black people, and after a group that included the American Indian Library Association reviewed the award.

Wilder described one place in her 1935 book *Little House on the Prairie* as somewhere "there were no people. Only Indians lived there." In that line, the Native people who lived there do not count as people. Later printings changed the line. Several characters in the Little House books say that "the only good Indian is a dead Indian." The prize is now called the Children's Literature Legacy Award.

**Audubon's name.** The members of the board of the National Audubon Society voted in March 2023 to keep the name of John James Audubon, who painted *The Birds of America* and who had enslaved people. "The name has come to represent not one person, but a broader love of birds and nature," said the board chair, Susan Bell. Three board members resigned. The leaders of the local Audubon groups in Chicago, Seattle, Portland and Washington, D.C., had already decided to drop the name.

### Public money and national museums, 2025 and 2026

White House officials sent Congress a budget for 2026 on May 2, 2025, that would have shut down the National Endowment for the Arts. The same day, NEA staff emailed arts groups across the country that their grants were withdrawn or ended because the projects fell outside the President's priorities. On May 5 about a dozen senior NEA staff members resigned.

Members of Congress did not close the agency. They gave it $207 million for 2026, the same amount as in 2024 and 2025, according to the Congressional Research Service. On April 3, 2026, White House officials proposed shutting the NEA down again, for 2027. As of September 2026, members of Congress had not decided.

**The Smithsonian.** President Donald Trump signed an order titled "Restoring Truth and Sanity to American History" on March 27, 2025. It stated that the Smithsonian Institution had "come under the influence of a divisive, race-centered ideology."

Trump announced on May 30 that he had fired Kim Sajet, who had directed the National Portrait Gallery for 12 years. He called her a "highly partisan person." He named no law under which he could fire her, and she kept coming to work. The members of the Smithsonian's Board of Regents, the group that governs it, then said that all decisions about staff belonged to the Smithsonian's head, Lonnie Bunch. Sajet resigned on June 13, 2025. She told her staff that her presence had become a distraction from the Smithsonian's mission.

Three White House officials, Lindsey Halligan, Vince Haley and Russell Vought, wrote to Bunch on August 12, 2025. They asked for a review of eight Smithsonian museums, among them the American Art Museum and the Portrait Gallery. They told the museums' leaders to begin changing their exhibits within 120 days. On July 24, 2026, Trump signed another order about the Smithsonian, aimed at the National Museum of American History.

**If you remember one thing:** Since 2000 artists have sued over programs built from their pictures, museums have needed Native consent to show remains, and officials have pushed national museums to change what they show.

- January 12, 2024: a federal rule takes effect that requires a Native nation's consent before museums show its ancestors' remains or sacred objects.
- July 24, 2025: Amy Sherald cancels her show at the National Portrait Gallery.
- October 29, 2025: the Museum of Fine Arts in Boston gives Dave's descendants ownership of two of his jars.

**The three questions, answered**

- How did enslaved artists make art, and who got paid for it? They painted, cut silhouettes, turned pots and wrote poems while other people held them as property, and the people who held them got the money. Dave's jars were sold for the profit of Lewis J. Miles, and Moses Williams learned to cut silhouettes and build exhibits in Peale's museum while Peale held him enslaved. Henry Barnes took Prince Demah to London for painting lessons, and Dave cut verses into his jars in years when it was a crime for him to learn to read.
- Who decided what counted as art, and who got to see it? Mostly people with money or power: the Met's trustees, who kept it shut on Sundays until 1891, a teacher in Santa Fe who taught one "authentic" Native style, and a congressman who called a touring show of modern paintings trash. Artists pushed back, from Oscar Howe's letter in 1958 to Amy Sherald cancelling her show in 2025.
- Why are museums giving back things they once took? Diggers took objects and human remains out of Native graves, at Mound City in 1846 and at Spiro in the 1930s, and sold many of the objects. Under a 1990 law, NAGPRA, museums that take federal money must return Native remains and sacred objects, and since 2024 they need a nation's consent even to show them.

**What changed:** The chapter begins with potters and carvers whose names no record keeps and ends with artists suing over computer programs that copy their styles and attach their names.

**Five dates to keep**

- 1585: John White paints the town of Secotan, on the coast of what is now North Carolina.
- 1773: Phillis Wheatley's *Poems* comes out in London while she is enslaved in Boston.
- 1857: Dave cuts "I made this Jar = for cash" into the jar now called the Poem Jar.
- 1936: Dorothea Lange photographs Florence Owens Thompson at a pea pickers' camp in Nipomo, California.
- November 16, 1990: President George H. W. Bush signs NAGPRA.

**Not known:** No surviving record names the people who made the painted bowls, stone pipes and copper plates of this land before 1500.

**Where to go:** The Museum of Fine Arts in Boston holds the two jars Dave made in 1857, one bought from his descendants and one lent by them.

**Next:** Chapter 33, Music. It asks the same questions about songs: who made them, where they came from, and who got paid.
