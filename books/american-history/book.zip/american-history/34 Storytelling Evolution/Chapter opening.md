# Chapter 34: Storytelling Evolution

**Chapter 34 of 37 · Storytelling Evolution · 10 eras · about 125 minutes**

**People here have acted out stories for centuries, and in every era someone fought over who was allowed to act, whom an actor could play, and who owned the performance.**

The court of Accomack County, Virginia, kept a record of three men who acted a play called *Ye Bare and Ye Cubb* on August 27, 1665. A man named Edward Martin reported them. On November 16 the judges ordered the three to come back to court "in those habilemts that they then acted in," which meant in their costumes, and to bring the script. In January 1666 the judges found them not guilty and made Martin pay all the costs. Those court orders are the only record of the play.

This chapter follows acting in this land from masked dancers before 1500 to computer copies of actors after 2000. Each new way of telling a story borrowed from the stage. The first films recorded stage acts, and the first television dramas were plays performed live.

Watch who is allowed to act. Priests burned Pueblo masks, lawmakers banned plays, and police arrested Black actors in the middle of a show. Watch, too, who plays whom. For more than a hundred years white actors blacked their faces to play Black people as fools, and film studios cast white actors as Asian and Native characters. After 2000 the fight moved to who owns an actor's face and voice.

**Three questions this chapter answers**

- Who tried to stop Americans from acting, and why?
- Why did white actors play Black, Asian and Native people for so long?
- Who controls a computer copy of an actor's face and voice?

**Five minutes?** Read "The African Theatre, New York, 1821 to 1823" in 1800 to 1850, and the two stories after it.

**Can skip:** "Places built to hold a crowd", "Shakespeare on the rivers", "Big openings and home video", "YouTube and TikTok". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 5 minutes**

In the Native nations here before 1500, acting was part of religion. A dancer in a mask took on the part of a spirit or an animal, in ceremonies and to ask the animals to give themselves to hunters. Among the Pueblo peoples, men carved dolls of these spirits so that girls would learn who each one was.

Some of what is known about these traditions comes from the nations themselves. Leaders of the Haudenosaunee, six nations whose lands stretch across what is now New York State and into Canada, published a policy on their masks in 1995. An Ojibwe teacher explained his people's storytelling rules in 2024. Older evidence survives in the ground. People built wide open squares called plazas and large round rooms for ceremonies, and they painted masked figures on walls and pots.

### Who is inside the mask?

Pueblo men wear katsina masks and special clothing in dances, and the people believe that the spirit shown on the mask is present with or inside the dancer while the dance goes on. The Pueblo peoples, among them the Hopi, are Native nations of the Southwest. In their religion, katsinam are spirit beings, more than 500 of them. Men also carve katsina dolls and give them to girls, so the girls learn who each spirit is.

The katsina religion reached Homol'ovi around 1350. Homol'ovi is a group of towns near Winslow, in what is now Arizona, built by ancestors of today's Hopi.

**Yup'ik masks.** In what is now Alaska, the Yup'ik people held a winter ceremony in which dancers wore masks and took on the spirits of the animals the masks showed. Ann Fienup-Riordan, quoted in *Archaeology* magazine in 2015, said that the dancers asked the animals to give themselves to hunters in the coming year. After a dance, people usually burned the masks, broke them or left them out on the tundra, the flat treeless land of the far north.

People lived at Nunalleq, a village near Quinhagak, from 1300 to the 1650s. Archaeologists, scientists who dig up and study what people left behind long ago, found masks there that are the oldest complete Yup'ik masks anywhere. The masks were made before 1650, while people lived in the village.

**Haudenosaunee masks.** Among the Haudenosaunee, groups called medicine societies use masks of wood and of cornhusk. The Haudenosaunee have not published a date for when the societies began.

The Grand Council of the Haudenosaunee published its policy on these masks in 1995. The policy says only that a medicine society is made up of Haudenosaunee who have taken part in the medicine, and it does not explain the phrase further. It states that all the masks are sacred, whatever their size or age, and that only members of a medicine society should make masks. The masks must not be shown in public, and photographs and drawings of them should not be used in public displays.

### Rules about who tells what, and when

Some nations set rules about which stories may be told, by whom, and at what time of year. An Ojibwe teacher described his people's rules in 2024. A Tlingit heritage group describes the Tlingit rules.

Ojibwe people tell their sacred stories, called aadizookaanag, only in winter. James Vukelich Kaagegaabaw, who is of Turtle Mountain Ojibwe descent, said in 2024 that tellers wait until the lakes freeze over and snow covers the ground. By then the frogs, snakes and other amphibians and reptiles are asleep for the winter, and so are the bears.

He said the spirits in the stories are thought to be asleep too, and "you wouldn't want to be thought of as gossiping about them." If someone tells the stories out of season, he said, "a frog or a toad may jump into your bed."

**Tlingit crests.** The Tlingit live in Southeast Alaska. They belong to clans, large family groups that trace back to the same ancestors. Each clan owns its crests, the animal and spirit figures that stand for the clan, and the stories, songs and names that go with each crest. The Tlingit word for this sacred clan property is at.óow.

The Sealaska Heritage Institute, led by Rosita Worl, published the first list of Tlingit clan crests in 2023. Its writers say that a clan got the right to a crest when an ancestor met a spirit being or what they call an "animal person." A clan "often acquired" the right "as payment for the life of an ancestor," they add, and the article does not say more about that payment. Clan members hold the crest and its stories through the generations.

### Places built to hold a crowd

At Cahokia, in what is now Illinois across the Mississippi River from St. Louis, people built a Grand Plaza of about 47 acres. It was the largest of the city's five plazas. The builders cut down a ridge of sand and moved the sand to fill low places and make a level surface. Archaeologists see the plazas as the places where people from all around gathered for their most important ceremonies, meetings and social events.

**Casa Rinconada.** At Chaco Canyon, in what is now northwestern New Mexico, the people of Chaco built a great kiva called Casa Rinconada. A kiva is a round room, partly underground, used for ceremonies. Casa Rinconada is about 63 feet across inside, with a bench around the wall and 34 small openings, called niches, set into the wall.

A tunnel 39 feet long ran under the floor. Through it, a person, perhaps a leader of the ceremonies, could enter the kiva unseen and then come up suddenly in front of the people there. Building probably began in about the middle of the 1000s, and people stopped using the kiva in the early 1100s.

### What the record does not have

No person from before 1500 in this land who acted, danced or told stories is named in any surviving record.

## The 1500s

**Era 2 of 10 · The 1500s · about 6 minutes**

The first European play on record in what is now the United States was acted on the day a Spanish leader claimed the land for his king, and his men made Native people act in it. Spanish soldiers and priests put it on beside the Rio Grande on April 30, 1598. They made Manso people, who lived near their camp, take part.

The Spanish belonged to an expedition, a large group of soldiers, priests and settlers, led by Juan de Oñate. They had come north from Mexico to take New Mexico for the king of Spain. Later that year Oñate's soldiers acted a second play at a pueblo, a Native town, farther north. No other European play acted in this land in the 1500s is on record.

### The play at the river, 1598

Oñate's expedition reached the Rio Grande near present-day San Elizario, Texas, on April 20, 1598. Ten days later the colonists held a Mass of thanksgiving, a Catholic church service, in a chapel that Oñate had ordered set up in a grove of cottonwood trees.

**"The taking."** That day Oñate also read out a statement called "La Toma," which means "the taking." In it he claimed for King Philip II of Spain all the land that the river drained. Accounts differ on whether he read it before or after the play. Manso people lived near the camp.

After the Mass the expedition put on a play nearby. Captain Marcos Farfán de los Godos, one of Oñate's officers, wrote it. The stage was bare ground, and a canvas curtain hung between two tree trunks behind it. Soldiers and friars, Catholic priests who belong to a religious order, played the main parts.

**The Manso actors.** Members of the expedition made Manso people found near the camp take part in the play, the historian Marc Simmons writes. Simmons does not say who gave the order. In the play the Manso acted the parts of the Pueblo people who lived farther north.

An officer who watched described the story. Friars arrive in New Mexico, and the Native people there kneel and ask to be baptized, made members of the Catholic church in a ceremony with water. At the end, the people watching cheered and fired their guns into the air. No copy of the script survives, and its title is not known.

### Marcos Farfán de los Godos

> **Who:** A captain in Juan de Oñate's expedition who wrote the first European play on record in what is now the United States.
>
> **When and where:** The Rio Grande near present-day San Elizario, Texas, April 30, 1598.

**The author opened his play by calling it a poor one.**

Marcos Farfán de los Godos wrote the play that Oñate's expedition acted on April 30, 1598, and he spoke first. In his opening speech he said he was unworthy to have written such a poor play. He offered it for the fun of his fellow soldiers and of Oñate.

Farfán came from the city of Seville, in Spain. When the expedition's officers checked each man and wrote down what he brought, Farfán had two servants, 16 horses, a tent, weapons and armor.

In November 1598 Farfán led a party west from the Hopi villages to look for mines. They reached the Verde Valley, in what is now Arizona. Near present-day Jerome they marked out 14 or 15 mining claims, pieces of ground where they said they had the right to dig for ore, rock that holds metal. What happened to Farfán after 1599, and when he died, is not known.

### The same expedition at Acoma

About eight months after the play, men of the same expedition attacked Acoma Pueblo. The play had shown Pueblo characters kneeling and asking the friars to baptize them. At Acoma the expedition's soldiers killed real Pueblo people, and Oñate sentenced most of the people they captured to slavery. Acoma is a town built on top of a mesa, a steep hill with a flat top.

**The demand for food.** Oñate's nephew Juan de Zaldívar and his soldiers climbed the mesa in early December 1598 and demanded food. The All Pueblo Council of Governors is a council of the leaders of the Pueblo nations. In 2023 its leaders said that the soldiers had demanded food and supplies, and had forced the Acoma to promise loyalty to the king of Spain.

In the Acoma people's own account, as the Rio Grande Sun newspaper reported it in 2019, the soldiers also raped an Acoma woman, forcing her into sex. Acoma people killed Zaldívar and between 11 and 14 of his men. Accounts differ on the number.

**War "by fire and blood."** Oñate sent Zaldívar's brother, Vicente de Zaldívar, with about 70 soldiers in January 1599, and he declared a war "by fire and blood." The soldiers fought their way up the mesa. Over two or three days of fighting, they killed Acoma men, women and children and burned much of the pueblo. The soldiers took about 500 people prisoner.

No one counted the Acoma dead. Published estimates run from about 300 to about 1,500. The figure given most often is about 800 men, women and children, and it is the figure the Pueblos themselves use.

**The sentences.** Oñate put the prisoners on trial in February 1599 and sentenced them. Every Acoma man over 25 was to have one foot cut off and to be forced to work for Spanish masters for twenty years, as their slaves. Males from 12 to 25, and females over 12, got the same twenty years of forced work. Oñate also sentenced two Hopi men captured in the fighting to have their right hands cut off.

Oñate ordered the old people handed over as slaves to the Plains Apache, and children under 12 taken from their families and given to the friars. Under that order, Acoma girls were taken south to Mexico and placed in convents, houses where nuns live. The National Park Service's account gives about 70 girls, and the All Pueblo Council of Governors gives 60 children. The records do not name the men who took them. None is known to have come home.

**The 24.** Oñate's sentence is in the written record. Acoma people have passed down their own account since 1599: Oñate had the right feet of 24 captive men cut off. The Associated Press, NPR and the New York Times have reported that number. No one has traced it to a written record from the time. The historians Marc Simmons and John Kessell doubt that the cutting was carried out.

**Oñate's own trial, years later.** Spanish officials charged Oñate with 30 crimes in 1612 or 1613. In 1614 judges in Mexico found him guilty of 12 of them, including using too much force at Acoma. The judges ordered him out of New Mexico for life and barred him from Mexico City for four years. One account says five years. They also fined him 6,000 ducats, which were Spanish gold coins.

### Los Moros y Cristianos

Oñate's soldiers had acted a second play months before the attack on Acoma. They put it on in the middle of 1598 to celebrate the expedition's safe arrival at a town of the Tewa, one of the Pueblo peoples, farther north. The Spanish renamed the town San Juan and made it their first capital. Today that pueblo is called Ohkay Owingeh.

The play was *Los Moros y Cristianos*, which means *The Moors and the Christians*. It shows the battles between the Moors, who were Muslims, and the Christians in Spain from the 700s to the 1400s. The leaders of each side make long speeches, and the battle scenes are full of clashing weapons.

New Mexicans have acted the play now and then in recent times, most of all a group of actors from Chimayó. Actors performed it at the University of New Mexico in 1998, for the 400th anniversary of Oñate's colony.

## The 1600s

**Era 3 of 10 · The 1600s · about 6 minutes**

People with power on both sides of the ocean tried to stop acting in the 1600s. Members of England's Parliament ordered stage plays stopped in 1642. In Virginia a man named Edward Martin reported three actors to a county court in 1665, and the court tried them. The first play in English on record in what is now the United States is known only from that court's orders.

In New Mexico, Spanish priests went into Pueblo ceremonial rooms and burned the masks used in the dances. In 1680 the Pueblos drove the Spanish out and brought back their own ceremonies.

### Plays stopped in England, and a play at Harvard

England's lawmakers meet in Parliament, which has two parts, the House of Lords and the House of Commons. Members of both houses ordered on September 2, 1642, that "Public Stage Plays shall cease." Plays were to stop while "these sad causes and set Times of Humiliation do continue," meaning while the country was in trouble and kept times of sad, serious worship.

The order called plays "Spectacles of Pleasure, too commonly expressing lascivious Mirth and Levity." That meant shows put on for pleasure that too often made rude jokes about sex and joked about serious things.

**Harvard.** Students at Harvard College, in Cambridge, Massachusetts, acted *Gustavus Vasa* in 1690. It was a tragedy, a serious play with a sad ending, by Benjamin Colman. Local officials disapproved of the play. Arthur Hornblow, who wrote a history of the American theatre in 1919, called it the first play written by an American to be acted in America.

### A play, a complaint and a court, 1665

Three men named Cornelius Watkinson, Philip Howard and William Darby acted a play called *Ye Bare and Ye Cubb* in Accomack County, Virginia, on August 27, 1665. The court record does not say where. A local history site, Secrets of the Eastern Shore, says they acted it at Fowkes Tavern near Pungoteague.

A man named Edward Martin reported the play to the court. The king's attorney for the county, the lawyer who brought cases to court in the king's name, took up the case. The record gives the charge only as "acting a play." It does not say what Martin objected to, or what law the attorney said the men had broken.

**"In those habilemts."** The king's attorney accused the three men in the county court on November 16, 1665. The judges ordered the men to come to the next court "in those habilemts that they then acted in." Habilemts was the court clerk's short spelling of habiliments, an old word for clothes, so the men had to come in their costumes. They also had to bring a written copy of the verses and speeches.

The judges ordered the sheriff to hold Watkinson and Howard until they gave security, a promise backed by money or property that they would come back. They ordered him to arrest Darby.

**The verdict.** The judges found the three men "not guilty of fault" at a court in January 1666. They ordered Edward Martin, who had reported the men, to pay all the costs of the case. The record does not say whether the men acted the play in front of the judges. The court orders are the only record of the play from its own time.

### William Darby

> **Who:** One of the three men who acted *Ye Bare and Ye Cubb* in Virginia in 1665, and the one the sheriff was ordered to arrest.
>
> **When and where:** Accomack County, Virginia, August 27, 1665, and the county court, November 1665 to January 1666.

**Later writers name him as the author of the lost play.**

William Darby is one of the first people on record to act a play in English in what is now the United States. The Accomack County court record names him as an "actour," an old spelling of actor, in *Ye Bare and Ye Cubb*. He was the one actor of the three whom the judges ordered arrested, "to answere at his ma'ties suit." That meant he had to answer a case brought in the name of His Majesty, the king.

Later writers say he wrote the play or helped write it. The reference book *American Eras* lists it as "*Ye Bare and Ye Cubb*, by William Darby." Writers at the Oscar G. Brockett Center for Theatre History call him "one of the piece's authors."

**Not known:** The court record is the only account of Darby from his own time, and it does not say what work he did, when he was born or when he died.

### Pueblo ceremonies attacked, and brought back

In New Mexico, Spanish officials and priests tried to end the Pueblo ceremonies that the masked dancers performed. Franciscan friars, one group of Catholic friars, had set up churches in several Pueblo towns.

The Franciscan leader Alonso de Posada forbade the Pueblo people to hold their ceremonies from 1656 to 1665. He ordered the missionaries, priests sent to win people over to Christianity, to go into the kivas, burn the masks there, and take or destroy the sacred objects. Armed Spanish soldiers protected the missionaries while they did it.

**The arrests.** Governor Juan Francisco Treviño ordered the arrest of 47 Pueblo religious leaders for sorcery, using magic to do harm, in 1675. Spanish officials sentenced four of the men to death by hanging. They hanged three of them, and the fourth killed himself. They shamed the others, whipped them in public and put them in prison. Pueblo men then came to Santa Fe and demanded that the prisoners be freed, and the Spanish let them go. One of the men freed was Po'pay of Ohkay Owingeh, the pueblo the Spanish called San Juan.

**The knotted ropes.** Po'pay planned a revolt of all the Pueblo towns at once. He sent runners carrying knotted ropes to the towns, and the people in each town untied one knot a day. When the last knot was gone, the revolt would begin. On August 9, 1680, the Spanish caught two of the runners, Pedro Omtua and Nicolas Catua of Tesuque Pueblo, and tortured them. The Smithsonian's account does not say how.

When Po'pay learned the two had been caught, he started the revolt a day early, on August 10. Pueblo fighters killed about 400 people, including 21 of the 33 Spanish priests in New Mexico. About 2,000 settlers who survived fled south to El Paso. After the Spanish left, the Pueblo people destroyed the churches and went back to their own religious ceremonies. The Spanish stayed away for 12 years.

### What the record does not show

English colonists in the 1600s enslaved Africans, owning them as property and forcing them to work without pay. Religion, storytelling, music and dancing were important parts of enslaved people's lives, and helped them pass African ways from parents to children. No record from the 1600s describes a performance by an enslaved person in the English colonies. The earliest known picture of a stick dance, a dance of enslaved people, is a watercolor called *The Old Plantation*, painted in the late 1700s.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 7 minutes**

Two of the first actors in the English colonies were not free. They were servants, bound by contract to the man who built the first playhouse, in Williamsburg, Virginia, between 1716 and 1718. Builders in Charleston, South Carolina, put up a theatre made for plays in 1735 and 1736.

Some colonists wanted no plays at all. In Boston, a judge of the colony's high court wrote against acting one. The preacher George Whitefield, who had prepared to act plays as a schoolboy, preached in the fields. According to newspaper reports that Benjamin Franklin read, one crowd numbered 25,000. In New York, enslaved Black people gathered with music and dancing for a holiday called Pinkster.

### The first actors and the first playhouses

The British actor Anthony Aston reached Charleston, South Carolina, in about 1702 and wrote a play about the colony there. Accounts give his arrival as 1701, 1702 or 1703. No copy of his play survives.

**Williamsburg.** A merchant named William Levingston signed a contract in 1716 with Charles Stagg and his wife, Mary Stagg. The Staggs were his indentured servants, people bound by a contract to work for a master for a set number of years. Under the contract, Levingston agreed to build a playhouse in Williamsburg, and the Staggs agreed to act and dance in it.

The first play on record there was acted in 1718. Lieutenant Governor Alexander Spotswood, the colony's leader at the time, sponsored it. No list of the plays acted in Levingston's playhouse survives.

**Whose land.** Williamsburg stands on land that the Paspahegh and Chiskiack peoples used before the English came. Both belonged to Tsenacomoco, a group of nations that Powhatan led until 1618. Its people spoke Algonquian languages, one family of related Native languages.

**Charleston.** A company of actors put on Thomas Otway's tragedy *The Orphan* in Charleston on January 24, 1735. They acted it in the "Court-room" of a tavern on Broad Street, a room that colony officials rented for trials. The company gave six shows through March.

A ticket cost forty shillings in South Carolina money, which was worth less than English money, so the ticket was worth a little less than six English shillings. Most of the actors' names are not recorded. A dancer named Henry Holt probably led them.

Builders then put up a theatre on Dock Street, made for plays. It opened on February 12, 1736, with George Farquhar's comedy *The Recruiting Officer*.

**The Etiwan.** The Etiwan people lived on the Charleston peninsula until 1672. That year the colony's Grand Council, the group of men who governed it, decided to build the town there. Colonists paid the Etiwan in trade goods to move away. Maurice Mathews, one of the colonists who probably arranged it, wrote in 1680 that the settlers paid the Etiwan "to remove them from their old habitations," meaning their old homes.

**Philadelphia.** A company led by Walter Murray and Thomas Kean gave its first show in Philadelphia on August 22, 1749. It acted Joseph Addison's tragedy *Cato* that month.

### Anthony Aston

> **Who:** A British lawyer who became an actor and wrote a play about South Carolina while he was there.
>
> **When and where:** Charleston, the Albemarle region of North Carolina, New York and Virginia, about 1701 to 1703.

**He reached Charleston "full of lice, shame, poverty, nakedness and hunger."**

Anthony Aston told his own story in the preface, the short opening piece, of his play *The Fool's Opera*, printed in 1730 or 1731. He listed himself as "a gentleman, lawyer, poet, actor, soldier, sailer, exciseman, publican," the last two meaning a collector of taxes on goods and a tavern keeper.

In Charleston, he wrote, he "turned player," or actor, "and poet and wrote one play on the subject of the country." That Charleston play was a different play from *The Fool's Opera*, and no copy of it survives.

He then spent about a month in the Albemarle region of North Carolina, where two settlers, Allen and Abraham Waights, supported him. On the way to New York, a storm blew his ship off course to the coast of Virginia. In New York he spent a winter "acting, writing, courting, fighting." Then he sailed to Virginia, and later he went back to England.

### William Levingston

> **Who:** A merchant and dancing teacher who built the first playhouse in the English colonies, with two indentured servants as his actors.
>
> **When and where:** New Kent County and Williamsburg, Virginia, 1716 to 1723.

**He built a theatre beside his bowling alley and stable.**

William Levingston built the first theatre in the English colonies, in Williamsburg, Virginia. Before that, he ran a dancing school that traveled around New Kent County, with Charles and Mary Stagg as its star dancers.

Their contract, dated July 11, 1716, and recorded at Yorktown, set out how the theatre would work. Charles Stagg was an actor, a violin player and a dancer. Mary Stagg was an actor. The three agreed to share the costs of costumes, music and everything else needed to put on plays.

**The theatre lot.** Levingston bought land in Williamsburg on November 21, 1716. On it he built a house, a kitchen, a stable, a bowling alley and the theatre. He borrowed money from Dr. Archibald Blair with the property as security. In 1723 Blair foreclosed, which means he took the property because the debt was not paid.

Charles Stagg died in Williamsburg in 1735 or early 1736. After his death, Mary Stagg earned her living by holding dancing parties. College of William and Mary students acted plays in the theatre in 1735 and 1736. In 1745 a group of Virginia men bought the building and gave it to Williamsburg to use as a town hall.

### Boston against plays

Samuel Sewall, a judge of the Massachusetts high court who later became its chief justice, wrote a letter on March 2, 1714, against a plan to act a play in the Council Chamber in Boston. The Council Chamber was the room where the colony's council met.

Sewall wrote that even the Romans had not been so set on plays as to "turn their Senate House into a Play-House." He went on: "Let not Christian Boston goe beyond Heathen Rome in the practice of Shamefull vanities." No record shows that the play was ever acted.

### How far could one preacher's voice carry?

Benjamin Franklin worked out that the English preacher George Whitefield could be heard by more than 30,000 people at once. Franklin heard Whitefield preach from the courthouse steps on Market Street in Philadelphia, and he walked backward down the street until he could no longer hear clearly. Then he worked out how many people could stand in a half circle that size, giving each person two square feet. He "computed that he might well be heard by more than thirty thousand."

Whitefield first came to the colonies in 1738 and made a preaching tour from 1739 to 1741. According to newspaper reports that Franklin read, Whitefield once preached outdoors to 25,000 people. As a schoolboy of about twelve in Gloucester, England, he wrote later, he "was very fond of reading plays." He stayed away from school "for days together to prepare myself for acting them."

**Practice on tour.** Franklin noticed that Whitefield spoke each sermon better every time he repeated it on tour. By then "every accent, every emphasis, every modulation (rise and fall) of voice, was so perfectly well turn'd and well plac'd." Franklin wrote that a preacher who traveled could improve a sermon "by so many rehearsals," or practice runs.

### Pinkster and Black election days

In New York, enslaved Black people gathered for a holiday called Pinkster, with music and dancing. In Connecticut, Black communities chose their own governor.

Dutch settlers brought Pinkster to New Netherland, later New York, in the 1620s. The oldest written account of Pinkster appeared in the *New-York Weekly Journal* in March 1737. It describes a gathering in fields outside New York City, with African-style musical instruments.

Enslavers gave the people they held time off for the holiday. For many enslaved Africans it was a chance to see loved ones and family members who lived some distance away. Africans and Europeans alike drank, played games, made music and danced at these gatherings, with dances called the jig, the breakdown and the double shuffle.

**A Black governor.** Black communities in Connecticut held their own elections for a governor by 1749, when a man named Hercules served as governor at New London. The voting took place the day after the white colonists' elections, and the celebration went on for a full week. Some of the clothes people wore were borrowed from the men and women who enslaved them. By custom, the enslaver of the man elected was expected to help pay for food, decorations and liquor.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 9 minutes**

Lawmakers kept passing laws against plays even as paid actors arrived and found audiences. A family company of actors from London landed in Virginia in 1752 and toured the colonies. One reference work describes their *Merchant of Venice* in Williamsburg that year as the beginning of truly professional theatre in America.

Lawmakers in Massachusetts, Pennsylvania and Rhode Island passed laws against plays between 1750 and 1761. Even so, professional actors staged the first play by an American writer in 1767. In 1774, as the fight with Britain grew, the delegates to the First Continental Congress promised to discourage plays, and shortly before the war the leading company of actors left for the West Indies.

During the war, British soldiers acted a play in Boston, and American officers acted one at Valley Forge. After the war the actors came back. In 1787 an American comedy brought a new character to the stage, the plain-spoken Yankee.

### Why lawmakers banned plays

Lawmakers in Massachusetts said that plays made people less moral and less religious. Members of the Massachusetts General Court, the colony's lawmakers, passed "An Act for preventing Stage-Plays, and other Theatrical Entertainments" in 1750. It stated that plays "tend to increase immorality, impiety, and a contempt of religion," impiety meaning a lack of respect for God. The act set fines for anyone who put on a play or took part in one.

**Three more colonies.** Members of the Pennsylvania House of Representatives voted through a law against acting plays on May 31, 1759, with a fine of five hundred pounds. Two years later the lawmakers of Rhode Island passed "an act to Prevent Stage Plays and other Theatrical Entertainments."

Members of the New Hampshire House of Representatives refused in 1762 to let a company of actors into the town of Portsmouth. They said that plays had a "peculiar influence on the minds of young people and greatly endanger their morals," peculiar meaning special, and morals meaning a person's ideas of right and wrong.

**The crowd in Chapel Street.** New Yorkers learned on May 5, 1766, that members of the British Parliament had voted to end the Stamp Act, a British tax that many colonists had protested. A crowd tore down the theatre in Chapel Street, where a comedy called *The Twin Rivals* was advertised for that night.

David Malinsky, writing in the *Journal of the American Revolution* in 2013, says that the New York Sons of Liberty did it. They were secret groups of colonists, sometimes violent, who fought the Stamp Act. Malinsky writes that the crowd severely beat an actor who was dressed as a woman and killed a small child. The older accounts record only that the theatre was destroyed. No record names the child, the actor, or who led the crowd.

### The first touring company, 1752

The London actor Lewis Hallam led a company of actors to Virginia in 1752. It included members of his family, among them his son Lewis, about twelve years old. It opened in Williamsburg with Shakespeare's *The Merchant of Venice* on September 15, 1752. William Dunlap, an early historian of the American stage, gave the date as September 5.

The company acted tragedies by Shakespeare and Joseph Addison, and comedies by William Congreve and Richard Steele. *Hamlet*, *Othello* and *Richard III* were among its plays. It played Williamsburg, Annapolis, Philadelphia and New York. Hallam had trouble getting permission to act in New York and Philadelphia, and he did not even try in Boston. In New York, Hallam built a theatre on Nassau Street in 1754.

**The American Company.** Lewis Hallam then died in Jamaica, where the company had gone to perform. His widow, Sarah Hallam, married the actor and manager David Douglass. In 1758 they formed the American Company. Douglass built a theatre in Philadelphia in 1759. In Annapolis he opened a brick theatre on March 3, 1760, that held five to six hundred people.

Charles Daly, writing in 1896, says Douglass also built a theatre in Chapel Street, New York, in 1761. Gabriel Furman's notes name another man, Phil Miller, as its builder.

### Lewis Hallam the Younger

> **Who:** A boy in the first touring company of actors in the colonies, who grew up to be the leading actor and manager of the American Company.
>
> **When and where:** Born about 1740 in England. Came to Virginia in 1752. Died in Philadelphia on November 1, 1808.

**He landed in Virginia at about twelve and acted for fifty years.**

Lewis Hallam the Younger spent about fifty years on the stage in America. He was about twelve years old when his father's company landed in Virginia in 1752. The historian William Dunlap got that story from Hallam himself.

At eighteen, in 1758, Hallam became the leading man of the American Company, which his mother and stepfather ran. He acted in *The Prince of Parthia* in 1767, the first play by an American writer that professional actors staged. He also acted in *The Contrast* in 1787.

His mother died in 1774, and his stepfather retired to Jamaica. Hallam then took over the family company. Shortly before the Revolution, he moved it to the West Indies. He brought the company back in 1784 or 1785, depending on the account, and managed it until 1796. He kept acting until shortly before he died. *Encyclopaedia Britannica* describes him as "known as a quarrelsome and financially inept manager," which means he argued with people and handled money badly.

### Nancy Hallam

> **Who:** An actress and singer in the American Company, and the subject of an early painting of an actress in a role in America.
>
> **When and where:** Annapolis, Maryland, 1770 and 1771.

**A newspaper letter praised "the Musick of her Tongue."**

Nancy Hallam was an actress whom the painter Charles Willson Peale painted in the costume of one of her roles. She was the niece of Sarah Hallam Douglass. She trained as a singer in England from 1760 to 1765, and she was acting with the American Company by 1766. In 1769 she moved from the parts of young women to leading roles.

In Annapolis in 1770 she played Imogen in Shakespeare's *Cymbeline*, a princess who disguises herself as a young man named Fidele. On September 6, 1770, the *Maryland Gazette* printed a letter signed only with the initials "Y.Z." It praised her "Delicacy of Manner" and "the Musick of her Tongue."

Peale painted her dressed as Fidele, and the painting was on view by September 1771. Colonial Williamsburg owns it today. Nancy Hallam went back to Britain in 1773. What happened to her after that, and when she died, is not known.

### The first American plays

Thomas Godfrey wrote a tragedy called *The Prince of Parthia*. The American Company acted it at the Southwark Theatre in Philadelphia on April 24, 1767. It was the first play by an American writer that professional actors performed. Godfrey had died of a disease called yellow fever in 1763, so he never saw it on the stage.

Mercy Otis Warren of Massachusetts wrote plays in which she attacked the policies of the colony's British governor. At the time, Massachusetts law banned acting plays.

**The Yankee.** Royall Tyler wrote a comedy called *The Contrast*. It opened at the John Street Theatre in New York in 1787, the first comedy by an American that professional actors performed. Tyler wrote it after he met Thomas Wignell, the American Company's leading comic actor.

Its leading character, Jonathan, has rough, plain-spoken manners. He is a Yankee, a word that can mean a person from New England. Playwrights after Tyler kept writing Yankee characters like him.

### Mercy Otis Warren

> **Who:** A Massachusetts writer who used plays to attack the royal government at a time when Massachusetts law banned acting them.
>
> **When and where:** Born in Barnstable, Massachusetts, on September 14, 1728. Wrote plays from 1772 to 1779. Died in 1814.

**She wrote five plays against the royal governor and signed none.**

Mercy Otis Warren's first play, *The Adulateur*, came out in 1772 in a newspaper, the *Massachusetts Spy*. *The Defeat* followed in 1773, *The Group* in 1775, *The Blockheads* in 1776 and *The Motley Assembly* in 1779.

The National Women's History Museum's biography of her states that she likely left her name off the plays to avoid being punished, and also so that readers would take her work seriously even though a woman wrote it. In 1805 she published a history of the American Revolution in three volumes.

### Congress against plays, and armies acting them

The First Continental Congress was a meeting of delegates, men chosen by each colony to speak for it. On October 20, 1774, they signed an agreement called the Continental Association. In its eighth article they promised to "discourage every species of extravagance and dissipation," meaning spending too much and wasting time and money on pleasure. The list that followed named horse racing, cockfighting, "shews, plays, and other expensive diversions and entertainments." Shortly before the war, the American Company left for the West Indies.

**A play in Boston.** British soldiers acted a play in Boston while American troops surrounded the city. On December 2, 1775, they staged *Zara*, a tragedy by the British writer Aaron Hill, in Faneuil Hall. The poster states that it was put on "by a Society of Ladies and Gentlemen." General John Burgoyne wrote a prologue for it, a speech given before the play begins. By one account, Francis Rawdon-Hastings, a British officer, read it. The money from tickets went to the widows and children of soldiers.

**A play at Valley Forge.** American officers at Valley Forge acted Joseph Addison's *Cato* in the spring of 1778. Lieutenant Colonel William Bradford Jr. wrote in a letter that "Cato was performed before a very numerous & splendid audience." He wrote that "His Excellency and Lady" were there, and that the performance was "admirable." His letter uses only that title and gives no names.

The historian Nancy K. Loane writes that General George Washington and his wife, Martha, attended the play. Accounts date the performance May 4 or May 11, 1778. The audience was officers and their guests. Shawn David McGhee, writing in the *Journal of the American Revolution* in 2024, argues that it may have been a reading of the play rather than a full staging.

**Congress again.** The delegates to Congress asked the states to stop "theatrical entertainments" in October 1778. On October 16 the delegates voted that any official who would "act, promote, encourage or attend such plays, shall be deemed unworthy to hold such office."

### After the war

Lewis Hallam the Younger brought the American Company back from the West Indies in 1784 or 1785 and started it up again.

The Massachusetts law of 1750 still banned plays. In 1791 a group of men who wanted a theatre in Boston tried and failed to get it repealed, which means ended by a vote. In 1792 they opened the "New Exhibition Room" on Board Alley anyway. They sometimes advertised its plays as "moral lectures," talks meant to teach right from wrong. Governor John Hancock forced it to close in June 1793.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 14 minutes**

White audiences paid to watch white actors play Black people as fools, while Black actors who played Shakespeare were attacked and arrested. The first known Black theatre company in the United States opened in New York in 1821, and police arrested its actors in the middle of a play. In 1824 a young actor from the company, Ira Aldridge, left for England. In the United States he faced discrimination, which means he was treated worse because he was Black.

**Blackface.** A white actor named Thomas Dartmouth Rice blacked his face with burnt cork in 1828 and played a Black man as a fool. White audiences paid to laugh at the act, and by 1843 four white men in the same makeup were performing together as a group.

Actors also played Shakespeare in city theatres and on boats on the rivers. In 1849 the fans of two rival actors fought outside a New York theatre. City officials gave soldiers the order to fire into the crowd, and the soldiers killed at least 22 people.

### The African Theatre, New York, 1821 to 1823

The first known Black theatre company in the United States opened in New York in 1821. Its founder, William Brown, was a free Black man from the West Indies who had worked as a steward, a servant on a ship. He ran a tea garden behind his house at 38 Thomas Street, an outdoor place for refreshments and shows, with music on Sunday afternoons.

Brown opened a theatre in 1821 with about 300 seats on the second floor of a building at Mercer and Bleecker Streets. Its actors were Black. It opened with Shakespeare's *Richard III*. Accounts give the first night as September 17, 21 or 24, 1821. A ticket cost 25 cents, or 50 cents for a better seat.

**A curtain for a robe.** On the first night, an enslaved man played the king in a robe made from a window curtain. After that, an actor named James Hewlett took over the part. The company also played Shakespeare's *Othello* and other plays such as *The Poor Soldier*. White New Yorkers came too, and some of them made trouble.

A group of people that included a man named George Bellmont broke into the theatre. They attacked the actors and wrecked the costumes and scenery. Police arrested Bellmont and several of the others.

**The arrests.** Brown then moved his company next door to the Park Theatre, run by a white manager named Stephen Price. Brown's company played *Richard III* on the same nights as Price's company. White members of the audience shouted at Brown's actors and broke up the show. According to the Shakespeare Theatre Company, which has published Hewlett's history, Price started a riot because he hoped to destroy Brown's company.

During one performance, police arrested the actors and put them in jail. The police let them go only after they promised to stop acting Shakespeare. The surviving records do not give the date or name the officers.

**The end.** Mordecai Noah, the editor of a newspaper called the *National Advocate*, mocked the company in print. He warned that free Black New Yorkers might one day "outvote the whites." In October 1822 Noah's newspaper included a notice that the theatre was closing because of an outbreak of a disease called yellow fever. The last known playbill of the company, a printed poster for a show, is from June 1823.

In London, the English comedian Charles Mathews mocked the company in his show *A Trip to America*, although he had never been to its theatre. In May 1824 James Hewlett answered him in a letter in the *National Advocate*: "Was this well for a brother actor?"

### William Alexander Brown

> **Who:** A Black ship's steward from the West Indies who started the first known Black theatre company in the United States, and wrote the first known play by a Black writer to be acted there.
>
> **When and where:** New York City, 1816 to 1823.

**His own play told of a 1796 war on St. Vincent.**

William Brown wrote *The Drama of King Shotaway*, the first known play by a Black writer to be staged in the United States. Accounts give his full name two ways, as William Alexander Brown and as William Henry Brown.

Brown bought his house on Thomas Street in 1816. Neighbors and police complained about the shows in its tea garden again and again until the garden closed. After the attacks and arrests at his theatre, he moved his company several times.

Brown staged *King Shotaway* in 1823. It told the story of the war that the Black Caribs of the Caribbean island of St. Vincent fought against English and French settlers in 1796. The Black Caribs, now called the Garifuna, were a people whose ancestors were both free Africans and Native people of the Caribbean. No copy of the play survives. What happened to Brown after his company's last known playbill, in June 1823, is not known.

### Ira Aldridge

> **Who:** A Black actor from New York who left the United States in 1824 and spent more than forty years acting Shakespeare in Britain and Europe.
>
> **When and where:** Born in New York about July 24, 1807. Went to England in 1824. Died on tour in Łódź, Poland, on August 7, 1867.

**A London critic said his skin was not dark enough for Othello.**

Ira Aldridge became a successful Shakespearean actor in Britain and across Europe. He is not known to have acted on a stage in the United States after he left. He went to the African Free School in New York, and as a teenager he acted with William Brown's company. Because he was Black, he faced discrimination in the United States, and in 1824 he sailed to England.

In October 1825 he played Oroonoko in a play called *The Revolt of Surinam, or A Slave's Revenge*, at a London theatre. A writer in *The Times* of London made fun of the shape of his lips. The same writer said his skin was not dark enough for him to play Othello.

Aldridge played Othello anyway, and King Lear and Macbeth. In 1828 he became the manager of the theatre in Coventry, England. In 1833 he took over the part of Othello at the Theatre Royal, Covent Garden, in London. *Encyclopaedia Britannica* describes that first appearance there as "highly successful."

He also played white characters, such as Shylock and Richard III, wearing greasepaint, a thick stage makeup, and a wig. On the last night of a run, he spoke to the audience against slavery. Rulers in Prussia, Austria and Russia gave him honors, and in 1863 he became a British citizen.

After the Civil War, Aldridge planned a tour of the United States and agreed to act in New York in September 1867. He died in Poland that August, before he could make the trip.

### Blackface minstrelsy: the act and the makeup

In blackface minstrelsy, white actors darkened their faces with burnt cork and acted Black people as fools. They built caricatures of Black people, acts that made fun of them by blowing up some of their features, and played them as singing, dancing, grinning fools. White audiences paid to watch.

Writers at the Jim Crow Museum at Ferris State University state that Rice and the actors who copied him helped to spread the belief that Black people were lazy, stupid and less than human. They write that the shows also helped white people argue for keeping Black people apart from them.

**"Jim Crow."** Thomas Dartmouth Rice was a white actor who did short comic acts between the scenes of plays. In 1828 he first went on stage as "Jim Crow," a Black character acted as a fool, with his skin blacked with burnt cork. Rice said he copied a Black man he had seen. Some accounts say the man was old, enslaved and walked with difficulty. Others say he was a ragged stable boy. No record names him.

Rice took the act from Louisville to Cincinnati, Pittsburgh and Philadelphia, and he reached New York in 1832. The act made him rich and famous. He died poor in New York on September 19, 1860.

People were using "Jim Crow" as an insult for Black people by 1838. By the end of the 1800s, "Jim Crow" was the name for the segregation laws and customs, which kept Black Americans apart from white Americans by race. Those laws came after 1877 and lasted until the mid-1960s.

**The first group.** Four white men in New York performed together in blackface as the Virginia Minstrels on January 31, 1843, the first group act of its kind. Years later, Black performers took up minstrelsy too, and they also blacked their faces with burnt cork. They acted the same caricatures that white actors had invented. In the 1840s one young Black dancer was already working in blackface.

### William Henry Lane (Master Juba)

> **Who:** A young Black dancer, known on stage as Master Juba, who danced in blackface and who toured with a white minstrel company.
>
> **When and where:** New York and London, 1840s. Born about 1825, died about 1854.

**"A black man imitating a white man imitating a black man."**

William Henry Lane was a Black dancer, known on stage as Master Juba. He learned to dance in the Five Points, a neighborhood in New York. By the early 1840s he was dancing for food and for coins people tossed him. Charles Dickens described a young Black dancer in the Five Points in a book in 1842, and later writers decided the dancer was Lane.

The reference book *Notable Black American Men* states that he was the only Black dancer of his time to get top billing, which means his name came first on the posters, in a minstrel company whose other members were all white. He toured with that company in the United States and in Britain.

**The fake contests.** A letter printed in a newspaper called the *Sunday Flash*, in 1841 or 1842, made a charge against the showman P. T. Barnum. The letter said that Barnum had made the Black boy up in blackface and advertised him as John Diamond, an Irish-American dancer who performed in blackface. It also said that Barnum staged fake dance contests with him: "Not one dollar is ever bet or staked."

The historian Eric Lott called the act "a black man imitating a white man imitating a black man." Lane later danced against the real John Diamond in public dance contests.

Lane went to London in 1848 with the Ethiopian Serenaders, a white minstrel company. A writer for *The Times* of London said that Lane "was compelled to repeat his efforts three times," which means the crowd made him dance again and again. He died in about 1854, when he was about 29.

**Not known:** No record states the cause of his death. Historians think that overwork and too little food killed him.

### Shakespeare on the rivers

Actors carried plays to river towns by boat. The actor Noah Ludlow bought a flatboat, a wide boat with a flat bottom, 25 feet long, at Olean, New York, in 1816. He named it Ludlow's Noah's Ark. He and eleven others floated down the Allegheny, Ohio and Mississippi rivers and stopped to perform wherever they could.

**The Floating Theatre.** William Chapman, a British-born actor, built a boat called the Floating Theatre at Pittsburgh in 1831. It was 14 feet wide and 100 feet long, the first boat built to be a theatre. Chapman and his family acted plays such as Shakespeare's *The Taming of the Shrew* at each landing, with songs and dances added.

When they reached New Orleans, they broke up the boat and went back to Pittsburgh on a steamboat to build another. From 1836 Chapman used a small steamboat to tow the theatre back up the river.

A night on the Floating Theatre began with a play. Then came a speech and a set of short scenes and songs. A ticket cost fifty cents, and people who had no cash could pay with fruit, potatoes or bacon. Minstrel shows in the same years acted comic versions of Shakespeare, with titles such as "Julius Sneezer."

### The Astor Place riot, May 10, 1849

Soldiers in New York fired into a crowd outside the Astor Opera House, on Astor Place, on May 10, 1849, and at least 22 people died. City officials and the soldiers' own general had given the order. The crowd had come to stop the English actor William Charles Macready from playing Shakespeare's *Macbeth*.

The quarrel began between two actors. Edwin Forrest, the American star, was jealous of Macready. In 1846, in a theatre in Edinburgh, Scotland, Forrest hissed at Macready from a private box.

**The first night.** Forrest's supporters stopped Macready's *Macbeth* inside the opera house on May 7 by throwing rotten eggs, potatoes, shoes and pieces of ripped-up seats. Forty-seven New Yorkers, including the writers Herman Melville and Washington Irving, signed a letter asking Macready to play again.

Captain Isaiah Rynders and the writer Ned Buntline put up posters that spoke to working men. Rynders belonged to Tammany Hall, a political group in New York. The posters read "WORKINGMEN! SHALL AMERICANS OR ENGLISH RULE IN THIS CITY?" The two men also handed out free tickets.

**The order to fire.** A crowd of about 10,000 gathered outside the opera house on May 10. Mayor Caleb Woodhull had called out the militia, an army of part-time soldiers who have other jobs. General Charles Sandford brought about 350 soldiers of the Seventh Regiment, one unit of that army. People in the crowd threw stones at the building and at the soldiers.

Frederick Talmadge was the city's recorder, an elected city officer who also served as a judge. He told General William Hall, who commanded the soldiers on the spot, "You must order your men to fire." Sandford, the general who had brought the soldiers, said his men would not "stand and be pounded to death with stones." Then the sheriff, whose name no record gives, said, "you have permission to fire." Sandford gave the order. The soldiers fired first over the crowd's heads. Then they lowered their guns and fired into the crowd.

**The dead.** The counts differ. Betsy Golden Kellem, writing in *Smithsonian* magazine in 2017, counts 18 dead that night and five more who died of their wounds in the next few days, 23 in all. Miguel Hernandez, writing in the *New York Almanack*, counts 25. The historian Nigel Cliff counts between 22 and 31.

Kellem writes that many of those shot were bystanders, people who were only watching. Seven of the dead were Irish immigrants. The dead included carpenters, clerks, printers and laborers, both men and women. About 48 people in the crowd were hurt, along with 50 to 70 police officers and 141 soldiers. The next night, in more fighting near Astor Place, a young boy was killed.

A jury later found that the events "justified the authorities in giving the order to fire." In September 1849 Buntline and nine others were found guilty of starting the riot, fined and jailed. Kellem does not name the judge. Kellem calls the shooting "the most significant loss of civilian life in New York since the Revolution."

### Edwin Forrest

> **Who:** An American-born star actor whose fans rioted against his English rival, William Charles Macready, at Astor Place in 1849.
>
> **When and where:** Born in Philadelphia on March 9, 1806. Acted from about 1817 to 1872. Died December 12, 1872.

**He paid prizes for new plays with a big part for himself.**

Edwin Forrest was an American star actor. In 2006 the Theatre Alliance of Greater Philadelphia, a group of the city's theaters, called him "America's first superstar of the stage and the highest paid actor in the world in the mid-nineteenth century." He first acted at eleven, at the South Street Theatre in Philadelphia. He became a star playing Othello at New York's Bowery Theatre in 1826.

**Metamora.** From 1828 Forrest paid prizes for new American plays that had a leading part written for him. The first winner was *Metamora*, by John Augustus Stone. Its hero, Metamora, stands for Metacom, a leader of the Wampanoag nation whom the English called King Philip. Forrest, a white actor, played Metamora from December 15, 1829. At the end of the play, Metamora kills his wife to save her from the settlers, and then he dies. The theatres made record profits from the play, and Stone got very little of the money.

An English visitor, Thomas Hamilton, called Forrest "a coarse and vulgar actor." Hamilton also wrote that his audience "were enraptured," meaning they loved him. No record shows that Forrest led the crowd at Astor Place in 1849, or that he was there that night.

Forrest beat the writer Nathaniel Parker Willis with a whip in Washington Square, in New York, in 1850. Willis took him to court and won $2,500. Forrest's wife, Catherine, won their divorce case on January 24, 1852, after a six-week trial in New York. Forrest had to pay her money every year, and he kept acting almost until he died, partly to pay it.

**If you remember one thing:** White actors in burnt-cork makeup made a paying business of mocking Black people, while the Black actors who played Shakespeare in New York were arrested and made to promise to stop.

- 1821: William Brown opened the African Theatre in New York.
- 1828: Thomas Dartmouth Rice first went on stage as "Jim Crow."
- May 10, 1849: soldiers fired into the crowd at Astor Place, and at least 22 people died.

**Next:** Harriet Beecher Stowe refused in 1852 to let her novel against slavery become a play, and theatre managers staged it anyway.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 15 minutes**

The biggest touring shows after 1850 told the stories of Black and Native people, and white showmen decided how. From 1852 until well after 1900, white actors in blackface toured the country playing the enslaved people in stage versions of *Uncle Tom's Cabin*, a novel written against slavery. Buffalo Bill's Wild West opened in 1883, and Native performers in it acted out attacks on settlers. Black minstrels such as Billy Kersands worked in the same burnt-cork makeup that white minstrels wore.

**Other stages.** John Wilkes Booth, a working actor, shot President Abraham Lincoln in 1865 in a theatre where he often performed. From 1881 theatre managers in New York and Boston built a new kind of show called vaudeville. In 1894 the first paying customers in New York watched films, and most of those films showed stage performers doing their acts.

### A novel against slavery, acted in blackface

Harriet Beecher Stowe published *Uncle Tom's Cabin*, a novel against slavery, in 1852. That year she refused to let it be made into a play, writing that "it would not be advisable." She never earned a cent from any stage version of it.

Theatre managers staged it anyway. The version that lasted opened in Troy, New York, on September 27, 1852. The manager, G. C. Howard, paid his 22-year-old cousin, George L. Aiken, $40 and a gold watch to write it in a week. When Aiken's play reached New York in July 1853, it ran for about 300 performances.

**Blackface again.** White actors in blackface played the enslaved characters. In Troy, the company's leading man, Green Germon, did not want to play a blacked-up character. He feared audiences would then expect minstrel dances and "Jim Crow" songs from him. The manager's wife, Mrs. Howard, played the enslaved girl Topsy and danced a minstrel dance called a breakdown. In January 1854 Thomas Dartmouth Rice, the actor who had created "Jim Crow," played Uncle Tom at New York's Bowery Theatre.

P. T. Barnum put on a version by Henry J. Conway at his American Museum in New York. His advertisement stated that this version "does not foolishly and unjustly elevate the Negro above the white man in intellect or morals," using a word of that time for a Black person. The advertisement promised white audiences that the play would not show Black people as being as smart or as good as white people.

**Tom shows.** People called these stage versions Tom shows. In the 1890s between 400 and 500 touring companies were playing the story. An agent's price list from 1893 offered actors to play Uncle Tom by the week, with "prime" ones at $60, "fair" ones at $50 and "culls," the leftovers, at $40.

One report counted a quarter of a million performances by 1902. A dozen companies were still touring the story in 1927.

### Charlotte Cushman

> **Who:** A Boston-born actress who played men's parts, including Romeo and Hamlet, as well as women's parts.
>
> **When and where:** Born in Boston on July 23, 1816. Acted in the United States and Britain from 1835 to 1875. Lived in Rome from 1852. Died in Boston on February 18, 1876.

**She played Romeo while her sister Susan played Juliet.**

*Encyclopaedia Britannica* describes Charlotte Cushman as "the first native-born star on the American stage." A Philadelphia theater group has called Edwin Forrest, who was born in Philadelphia ten years before her, "America's first superstar of the stage," so the two descriptions do not agree on who came first. Cushman first trained to sing opera. Her voice failed after she sang parts that were too high for it, and she turned to acting. In 1836 she played Lady Macbeth.

Cushman played men's parts as well as women's. In London in 1845, and again in 1854 and 1855, she played Romeo while her sister Susan played Juliet. She also played Hamlet.

Cushman lived with the writer Matilda Hays from 1848, and people in Europe knew the two women as a couple. In 1852 Cushman settled in Rome, among a group of American women who were artists. She later lived with the sculptor Emma Stebbins. Cushman helped the career of the sculptor Edmonia Lewis, whose mother was of Ojibwe and African American descent.

During the Civil War, Cushman acted to raise money for the care of Union soldiers. In 1869 doctors began treating her for breast cancer. She kept acting and reading on stage. She announced her farewell at least seven times before her last performance in Boston on May 15, 1875.

### The actor who shot Lincoln

The man who killed President Abraham Lincoln was an actor. John Wilkes Booth came from a family of actors, and he often performed at Ford's Theatre in Washington. On April 14, 1865, he learned that Lincoln would come that night to see a comedy called *Our American Cousin*.

That night Booth found the president's box almost unguarded. He went in, barred its outer door from the inside, and waited for a line that he knew would bring a big laugh. Then he burst into the box and shot Lincoln once in the back of the head with a small pistol called a derringer. Booth also slashed Major Henry Rathbone, one of Lincoln's guests, in the shoulder with a knife. The play stopped at the line "you sockdologizing old man-trap," a joking insult made of slang of the time.

Booth jumped from the box to the stage below. He broke his left leg in the fall, though some people believe the leg broke later. Accounts differ on what he shouted: "Sic semper tyrannis," Latin for "Thus always to tyrants," or "The South is avenged!", or both. Lincoln died the next morning.

**The theatre after.** The federal government bought the theatre in 1866. Edwin Stanton, the Secretary of War, ordered it turned into offices. Workers were digging in the basement on June 9, 1893, to put in an electric light plant, when a brick pillar that held up the floors gave way. Part of the inside of the building fell in. Twenty-two clerks who worked there were killed, and at least 68 were hurt.

An inquest jury, a jury that looks into a death, met to find out why. It found three men guilty of criminal negligence, which means carelessness so serious it is a crime. The three were Colonel Fred C. Ainsworth, the head of the office whose clerks worked there, the engineer, and George Dant, the contractor in charge of the building. The jury blamed Dant most, because he had not propped up the brick pillars before the digging began. The charges against all of them were later dropped.

The restored theatre held its first public performance since Lincoln's death in 1968.

### Edwin Booth

> **Who:** An American actor of Shakespeare who played Hamlet a record hundred nights in a row, and the older brother of John Wilkes Booth.
>
> **When and where:** Born in Bel Air, Maryland, on November 13, 1833. Acted mostly in New York and on tour. Died in New York on June 7, 1893.
>
> **Movie:** *Prince of Players* (1955), a feature film about his life.

**He pulled the president's son out from beside a moving train.**

Edwin Booth once saved the life of Robert Lincoln, the president's son. Late in 1863 or early in 1864, on a train platform in Jersey City, New Jersey, Robert slipped into the gap between the platform and a moving train. Booth grabbed his coat collar and pulled him out. Robert Lincoln described the rescue in a letter in 1909.

Booth played Hamlet about a hundred nights in a row in New York in 1864 and 1865. That was a record, and no actor broke it until 1922. He was the son of the actor Junius Brutus Booth. Edwin supported the Union in the Civil War. His brother John Wilkes supported the Confederacy, the group of Southern states whose leaders broke away from the United States to keep slavery.

**After the shooting.** After his brother killed President Lincoln, Edwin Booth stayed off the stage for about nine months. He came back as Hamlet in January 1866. He opened his own theatre in New York in 1869. It never made a profit, and in 1874 it went bankrupt, which means Booth could not pay its debts.

A salesman named Mark Gray fired two shots at him on a stage in Chicago in 1879 and missed. In 1888 Booth bought a house in New York and founded The Players, a private club, in it. He kept an upper floor as his home, and he died there.

### How vaudeville began

Vaudeville was a show made of many short, separate acts, one after another. Tony Pastor, a theatre manager, took over a theatre on 14th Street in New York in 1881. He sold no alcohol and kept the acts clean, so that women and families would come. *Encyclopaedia Britannica* credits Pastor with the first show of the kind later called vaudeville.

**Boston.** Benjamin Franklin Keith opened a museum of oddities on Washington Street in Boston in 1883. Its first exhibit was a very small baby, three months old, shown to paying customers as "Baby Alice." Keith added a theatre with 123 seats. He ran a "continuous" show there from 10 in the morning to 11 at night, so customers could walk in at any time.

From 1885 Keith and Edward F. Albee ran the Bijou Theatre in Boston together, and the two men went on to build a chain of vaudeville theatres.

### Billy Kersands

> **Who:** A Black minstrel comedian, the most popular Black comedian of his day, who performed in burnt-cork blackface.
>
> **When and where:** Born about 1842 in Baton Rouge, Louisiana. Toured the United States and Europe. Died on June 30, 1915, in Artesia, New Mexico.

**He filled his mouth with billiard balls to get laughs.**

Billy Kersands was a Black comedian who blacked his face with burnt cork and played the character that white minstrels had invented. He worked in Black minstrel companies such as Sam Hague's Georgia Minstrels. On stage he played a slow, foolish Black man. He filled his wide mouth with billiard balls, or with a cup and saucer. Tom Fletcher, a Black performer who knew him, wrote that Kersands once told Queen Victoria that if his mouth were any bigger, his ears would have to be moved.

A tavern owner named Charles Callender bought the Black minstrel company that Kersands worked in. That was in 1872. When Kersands and other stars asked for more pay and better treatment, Callender fired them. Most of them later came back to him.

**The pay.** Kersands earned about $15 a week in 1879, and by 1882 he was reportedly earning $80 a week, only a little less than a white minstrel star. On tours of Europe he earned up to $250 a week. White and Black audiences in the South came to see him. Because he drew such crowds, some theatre owners relaxed their rules limiting Black customers to separate sections of the theatre.

People asked Kersands why he never moved to vaudeville. Fletcher recorded his answer: "All of my money came from the people of the South, the white and the colored (Black), while playing down there." Kersands died shortly after a show, at about 73.

### The Wild West: Lakota performers

William F. Cody, called Buffalo Bill, started a show called Buffalo Bill's Wild West near North Platte, Nebraska, in 1883. In its arena, Native performers acted out attacks on stagecoaches, wagon trains and a settler's cabin. Then cowboys and soldiers drove them off, and in the last scene Cody rode to the rescue.

**Sitting Bull's contract.** The Hunkpapa Lakota leader Sitting Bull signed a contract on June 6, 1885, to tour with the show for four months. It paid him $50 a week and let him sell his own photographs and autographs. He signed at the Standing Rock Agency, the office of the Indian agent at Standing Rock. An Indian agent was the federal official who ran a reservation, land that US officials had set aside for a Native nation. James McLaughlin, the agent at Standing Rock, signed as a witness.

**Deaths on tour.** Several performers died on the show's tours of Europe. Surrounded by the Enemy, an Oglala Lakota man, died of a lung infection in London in 1887 and was buried there. Four months before him, a one-year-old boy named Red Penny, the son of Little Chief and Good Robe, died and was buried in the same London cemetery.

Chief Hawick died of typhoid fever on January 1, 1890, and Featherman died of smallpox, two diseases that often killed people then. Both men had been left in a hospital in Marseilles, France. Wounds One Another died after he fell from a train in Germany, with $108 in wages still owed to him. No full count of the deaths survives.

**The pay.** Most Lakota men in the show earned far less than Sitting Bull's $50 a week. The Lakota performer No Neck came home from Europe in July 1890 and told reporters that the men had been paid $25 a month. He said that no more Lakota would go for less than $50 a month. He also said that Cody had given him "a suit of clothes, paid my wages, and gave me $100 besides," and had told him to give "a good report of the treatment of the Indians."

**The permits.** To hire Lakota people from their reservations, Cody needed permits, written permission from federal officials. John Noble, the Secretary of the Interior, ordered an investigation because of the deaths on the 1889 to 1890 tour and the poor condition of the performers coming home. He also stopped giving new permits for Native performers.

**Wounded Knee.** Soldiers of the 7th Cavalry, a regiment of soldiers on horseback, were taking the guns of Spotted Elk's band of Lakota at Wounded Knee Creek, in South Dakota, on December 29, 1890. The soldiers opened fire with carbines, which are short rifles, and Hotchkiss guns, which are small cannon. They killed between 250 and 300 Lakota people, most of them women and children.

After the killings, army officers held Lakota Ghost Dancers, people who took part in a religious ceremony called the Ghost Dance, as prisoners at Fort Sheridan, Illinois.

In early 1891 Cody and Nate Salsbury, who had started the show with him, wrote to the Commissioner of Indian Affairs, the federal official over all the agents. They asked for 60 men and 15 women and children. They said the men would be paid $25 a month, that men they called "chiefs" would get $30 to $60 and that women would get $10. The officials in charge of Indian affairs agreed. In March 1891 federal officials released 23 of the Fort Sheridan prisoners to Cody, on the condition that they tour Europe with his show. General Nelson Miles, Cody's close friend, commanded the army in the region.

The prisoners included Short Bull and Kicking Bear. Short Bull said of Wounded Knee, "twenty-three of my own relations were killed in this fight, men, women and children, this is like butchery." In Cody's arena, the prisoners played "hostiles," the Indians who attacked.

The historian Sam Maddra studied these tours and concludes that the Lakota who joined the show got wages, travel and standing among their people. She adds that, perhaps more important, they got away from the control of government officials. They also earned far more than farming on the reservation paid.

**Dances made crimes.** United States officials and missionaries worked in the same years to stop Native ceremonies and dances. In 1883 Hiram Price, the Commissioner of Indian Affairs, issued rules that made the Sun Dance and other dances "Indian offenses," or crimes, for the Courts of Indian Offenses on the reservations.

For a first offense, the rules specify stopping the person's rations, the food handed out to them on the reservation, for up to ten days. For a later offense, the rations could be stopped for 15 to 30 days, or the person could be locked in the agency jail for up to 30 days.

Missionaries from the Moravian Church arrived at Quinhagak, Alaska, in 1885. They called the masked dances of the Yup'ik people "heathen rites," meaning the religion of people who were not Christian. No traditional dancing took place in Quinhagak for more than a century, until 2013. *Archaeology* magazine's 2015 account of the village does not name the missionaries or say how the dancing was stopped.

### What did the first films show?

Many of the first films were recordings of performers doing their stage acts. In December 1892 Thomas Edison's staff began building a film studio at West Orange, New Jersey. They called it the Black Maria. It was a studio lined with tar paper, with a roof on hinges that flipped open, and the whole building could turn on a track.

**The first paying customers.** The Holland brothers opened a Kinetoscope parlor at 1155 Broadway in New York on April 14, 1894. A Kinetoscope was a machine that showed one short film to one person looking into it. The parlor had ten machines and ten films, each 15 to 20 seconds long, all shot in the Black Maria.

They showed Sandow, a strongman, and Bertoldi, a contortionist who bent the body into unusual shapes. The other films showed wrestlers, a trapeze act, a Highland dancer, blacksmiths and a barber shop.

**A stage kiss.** A film projector called the Vitascope showed films on a screen to a seated audience in a theatre for the first time on April 23, 1896, at Koster and Bial's Music Hall, a vaudeville theatre in New York.

That same month, the actors May Irwin and John Rice made a film of a stage kiss. They had kissed at the end of a Broadway musical, *The Widow Jones*, in 1895. They acted the same kiss again in front of Edison's camera. The film, *The Kiss*, runs about 18 seconds.

**If you remember one thing:** Black and Native performers found paying work on the touring stage in these fifty years, mostly in parts that white managers had written to mock them or to act out their defeat.

**In 1850:** Theatres played Shakespeare and minstrel shows, and Cody's Wild West, vaudeville and films did not yet exist.

**In 1900:** Hundreds of companies had been touring *Uncle Tom's Cabin* in blackface, Keith and Albee ran a chain of vaudeville theatres, and New Yorkers had been paying to watch films for six years.

**Next:** The first film companies kept their actors' names secret, so fans called one star only "the Biograph Girl."

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 23 minutes**

Acting moved onto film and into radio in these fifty years, and the people in charge kept the parts of the old minstrel stage, where white men had blacked their faces to mock Black people. Americans in 1903 saw films mostly in vaudeville theatres, which put on shows made of many short live acts. From 1905 small theatres charged five cents to see short films, and by 1908 there were about 8,000 of them.

The first film studio in Hollywood opened in 1911. In 1927 *The Jazz Singer* put recorded songs and speech into a full-length film, and by the 1930s eight companies made most American films.

**Who played whom.** White actors in blackface, dark makeup that made a white face look Black, played Black characters, and white actors made up to look Chinese played Chinese characters.

On the radio, two white men used put-on voices to play Black characters in one of the most popular shows of the time. Because of state laws against marriage between races, producers would not let the Chinese American star Anna May Wong kiss a white actor on screen. The studio heads' own rules banned showing romance between white and Black characters.

Radio plays and, from 1928, the first television plays brought actors into people's homes.

### Story films, nickelodeons and actors with no names

Edwin S. Porter made *The Great Train Robbery* for Thomas Edison's company in November 1903. The film runs about 12 minutes. Porter cut between places to show things happening at the same time. He took the title from a stage play of 1896. Later legends called it the first film with a story. That claim is wrong: films with plots came before it.

**The nickel theatres.** Harry Davis and John P. Harris opened a small theatre in a Pittsburgh storefront on June 19, 1905, and charged a nickel to see films. They named it the Nickelodeon, and small theatres like it were called nickelodeons. By 1908 there were about 8,000 nickelodeons in the United States. Most of them seated fewer than 200 people. William Fox, Carl Laemmle and Louis B. Mayer, who later ran big film studios, all started out as nickelodeon owners.

**Hollywood.** The Nestor company opened the first permanent film studio in Hollywood on October 27, 1911, at Sunset Boulevard and Gower Street. Hollywood lies in the Los Angeles Basin, the homeland of the Tongva people, whom the Spanish called the Gabrielino. In 1994 California officials named the Gabrielino the first people of the Los Angeles Basin. Federal officials do not list any Tongva group as a tribe.

**Actors with no names.** The first film companies did not publish their actors' names. The owners of the Biograph company refused to name Florence Lawrence, one of their leading actors, so fans called her "the Biograph Girl." Her biographer writes that the owners feared famous actors would ask for more pay.

The producer Carl Laemmle hired her in 1910. He spread a false story that she had been killed by a streetcar. Then he named her in newspaper ads headed "We nail a lie." Lawrence is often called the first film star, and her headstone says "The First Movie Star." Evidence published in 2019 points to the French actor Max Linder as the first film actor named in public.

**Films and free speech.** All nine justices of the Supreme Court ruled in 1915 that showing films was "a business, pure and simple." That meant films had no protection as free speech. State and city censors, officials who decided which films could be shown, could cut any film or ban it. In 1952 the justices reversed that ruling.

### The Birth of a Nation, 1915

D. W. Griffith's *The Birth of a Nation* showed members of the Ku Klux Klan hunting down and lynching a Black man, killing him with no lawful trial, and stopping Black men from voting. Many of its Black characters were played by white actors in blackface.

The Ku Klux Klan was a secret group that Confederate veterans founded in December 1865. Klansmen, armed and in disguise, whipped freed Black people and the white people who worked with them, burned their homes and murdered them.

The film opened in Los Angeles on February 8, 1915. It ran about three hours, longer than any film released before it. Griffith based it on a novel by Thomas Dixon called *The Clansman*.

**What the film shows.** The film shows its Black characters as unintelligent and as sexually aggressive toward white women, which means wanting to force sex on them. In one scene, Gus, a freed man played by a white actor in blackface, follows a white girl named Flora Cameron into the woods and says he wants to marry her. She runs from him to the edge of a cliff and jumps to her death.

Klansmen in the film hunt Gus down, hold their own trial, lynch him and leave his body at the house of a character named Silas Lynch.

At the end of the film, armed Klansmen on horseback stop Black men from voting. Griffith said that he had decided to have "no black blood among the principals," the main actors. Black extras, actors hired to fill out crowd scenes, appear in many shots. The filmmakers housed them apart from the white cast.

**At the White House.** President Woodrow Wilson watched the film in the East Room of the White House on February 18, 1915, with his family and members of his Cabinet, the officials who head the government's departments. Dixon and Wilson had been graduate students together. Wilson's secretary later wrote that Wilson had not known what the film contained.

In 1937, 22 years later, a magazine reported that Wilson had said of the film, "It is like writing history with lightning. And my only regret is that it is all so terribly true." No record from 1915 contains those words, and whether he said them is disputed. In May 1915 Dixon wrote to Wilson's secretary that "the real purpose of my film was to revolutionize Northern sentiments," meaning to change completely what Northerners thought.

**The protests.** Protests began at the Los Angeles opening in February 1915 and went on when the film opened in New York the next month. In Boston in April 1915, the managers of the Tremont Theatre refused to sell tickets to William Monroe Trotter, the editor of a newspaper called the *Guardian*, and to others with him. Police arrested Trotter and ten others.

Trotter and the Boston branch of the NAACP, the National Association for the Advancement of Colored People, then led rallies of thousands of people against the film.

**The bans.** Twelve mayors banned the film in 1915, and the mayor of Cedar Rapids, Iowa, was the first. In Chicago, Black voters pressed the mayor to act, and he banned showings on May 17, 1915. Officials in Denver, Pittsburgh, St. Louis and Minneapolis kept the film out too, and officials in the state of Ohio banned it on March 4, 1916. Most cities and states let it play.

**The money.** No one knows how much people paid to see the film. The company that made it reported $4.8 million by the end of 1917. The historian Richard Schickel estimates more than $60 million from its first run. No American film earned more until *Gone with the Wind* in 1939.

**The Klan again.** After the film opened in Atlanta, a preacher named William J. Simmons started the Klan again. He led a cross burning, setting a large cross on fire, on Stone Mountain, Georgia, in November or December 1915. *Encyclopaedia Britannica* states that Simmons was "directly inspired" by the film. In the 1970s David Duke, a Klan leader, showed the film to bring in new members.

### Lilian St. Cyr (Red Wing)

> **Who:** A Ho-Chunk actress who played the leading woman in the first Western made in Hollywood.
>
> **When and where:** Born on the Winnebago Reservation in Nebraska in February 1884. Acted in films from 1908 to 1925. Died in March 1974.

**"He's working with a one hundred percent American."**

Lilian St. Cyr played a leading part in the first Western made in what is now Hollywood, and she was paid far less than the man who starred with her, Dustin Farnum. She was Ho-Chunk, born on the Winnebago Reservation in Nebraska. By 1888 both of her parents had died.

**The schools.** She spent ten years in Indian boarding schools and graduated from the Carlisle Indian School in Pennsylvania in 1902. At these schools, run or paid for by the federal government, staff cut Native children's hair, gave them English names and forbade them to speak their own languages. Staff punished children with beatings, locked rooms and withheld food. A federal report in 2024 counted at least 973 children who died at the schools and said the true number is higher.

She married James Young Deer in 1906. The couple performed in Wild West shows, and from 1908 they acted in short Western films. She used the name Red Wing. In 1909 the director D. W. Griffith hired the couple as technical consultants, people who advise filmmakers on how to get details right.

**The film.** A film by Cecil B. DeMille opened on February 23, 1914, in which St. Cyr played a Ute woman who marries an Englishman and then kills herself. The film's title used an insult for Native women. St. Cyr made her own costumes. The male lead, Dustin Farnum, earned $1,000 a week. Someone told her she should be proud to act with such a star. She answered, "What about him? He's working with a one hundred percent American."

She acted until 1925. Then she made costumes in New York and worked for a national day to honor Native Americans. Accounts differ on her birth date, February 14 or February 23, 1884, and on the day she died, March 12 or March 13, 1974.

### Wounded Knee acted again, 1913

Buffalo Bill Cody made a film in the fall of 1913 that acted out Wounded Knee. There, on December 29, 1890, soldiers of the 7th Cavalry had killed between 250 and 300 Lakota people, most of them women and children, with rifles and small cannon.

Cody filmed in the Badlands and the Black Hills of South Dakota. He got $50,000 for it from the Essanay film company and from the owners of two newspapers. Lindley Garrison, the Secretary of War, supplied soldiers of the 12th Cavalry to play the troops. Franklin K. Lane, the Secretary of the Interior, allowed more than 1,000 Lakota people to take part. General Nelson Miles advised on the film, although he had written that such a show was not "for the welfare of the Indians."

**Short Bull.** Short Bull acted in it. Twenty-three of his relatives had been killed at Wounded Knee. In 1891 federal officials had released him from prison at Fort Sheridan, an army post in Illinois, to tour Europe with Cody.

The film was called *The Indian Wars*. Only a few minutes of it survive. Ben Black Elk later said that "the government put a ban on it" and destroyed it. No surviving record names the official who did so.

**By 1915:** Hollywood had its first film studio, the Supreme Court had ruled that films had no protection as free speech, and the longest film yet made showed Klansmen lynching a Black man.

### Bert Williams

> **Who:** A Black comedian who wore blackface on stage and starred in an otherwise all-white Broadway show.
>
> **When and where:** Born in Nassau, in the Bahamas, on November 12, 1874. Performed in the United States and Britain from 1895. Died in New York City on March 4, 1922.

**"I don't belong to either side. Nobody wants me."**

Bert Williams was a Black comedian who blacked his face to work, even as a star on Broadway. He moved to the United States at ten. From 1895 he worked with another Black comedian, George Walker. The two men wore burnt-cork blackface, as white minstrels did.

Their stage name paired the word "Real" with an insult for Black people. It told audiences that these two were real Black men, unlike the many white performers in blackface. On stage Williams played the slow-witted, shuffling Black man that was then a standard part on the minstrel and vaudeville stage.

In August 1900, during a riot in New York, a white mob pulled Walker off a streetcar and beat him. In 1903 the two men starred in *In Dahomey*, a musical with an all-Black cast. It played on Broadway and then at Buckingham Palace in London.

**One Black act.** In 1909 a group of white vaudeville performers called the White Rats, who opposed Black performers and women gaining ground in vaudeville, made theatre managers cut Williams's billing, the size and place of his name on the posters. Managers of the big chains of vaudeville theatres allowed only one Black act on each program. Williams had to travel, eat and sleep apart from the white performers.

**The Follies.** Florenz Ziegfeld hired Williams for his Broadway revue, the *Follies*, a show of songs and comic scenes, in 1910. Several white cast members demanded that Ziegfeld fire him. Ziegfeld answered, "I can replace every one of you," except Williams. Williams starred in the *Follies* until 1919. On one three-year contract he was paid $62,400 a year.

In August 1919 the rest of the cast went on strike, and no one told him. He said, "I don't belong to either side. Nobody wants me." He collapsed on stage in Detroit in February 1922 and died in New York at 47. More than 5,000 people filed past his coffin.

### Charlie Chaplin

> **Who:** A London comedian who became a film star around the world by acting without speaking.
>
> **When and where:** Born in London on April 16, 1889. Made films in Los Angeles from 1914 to 1952. Died in Switzerland on December 25, 1977.
>
> **Movie:** *Chaplin* (1992), a feature film about his life, directed by Richard Attenborough.

**When he came back, the audience stood and applauded for 12 minutes.**

Charlie Chaplin became famous around the world for acting with his face and body, with no spoken words. He grew up poor in London. Before he was nine, he was sent twice to a workhouse, a place where poor people lived and worked in return for food and a bed.

Chaplin came to the United States with a touring comedy company. In September 1913 he signed with the Keystone studio for $150 a week. His character the Tramp first appeared on screen on February 7, 1914. In 1916 the Mutual company paid him $670,000 for one year of work.

**His own company.** Chaplin formed a company called United Artists on February 5, 1919, with the actors Mary Pickford and Douglas Fairbanks and the director D. W. Griffith. The four could then pay for their own films and control them. Chaplin kept making films with no spoken words after sound arrived, including *City Lights* (1931) and *Modern Times* (1936). In his first talking film, *The Great Dictator* (1940), Chaplin attacked Adolf Hitler and Benito Mussolini, the dictators, or rulers with total power, of Germany and Italy.

**Shut out.** FBI agents under J. Edgar Hoover investigated Chaplin. On September 18, 1952, he sailed for London. The next day Attorney General James McGranery canceled his permit to come back into the United States. Chaplin settled in Switzerland. He came back once, in April 1972, to accept an honorary Academy Award, and the audience stood and applauded for 12 minutes.

### Sound, and the Production Code

*The Jazz Singer* opened in New York on October 6, 1927. It was the first full-length film with songs and speech recorded to match the actors' lips, in a few scenes. Its star, Al Jolson, was a Jewish performer born in Lithuania who worked in blackface. At the end of the film he sings in blackface.

**The Code.** The heads of the big studios agreed in 1930 to follow a set of rules called the Production Code. Martin Quigley, a Catholic publisher, and Daniel Lord, a Catholic priest, wrote it. The studio heads adopted the Code through their own trade group, led by Will H. Hays. From July 1, 1934, no film from those studios could open without a seal of approval from an office run by Joseph Breen.

One rule in the Code read: "Miscegenation (sex relationships between the white and black races) is forbidden," using an old word for marriage or romance between people of different races. The studio heads rewrote that rule in 1956. On November 1, 1968, they replaced the whole Code with movie ratings.

**By 1934:** Films talked, eight companies made most of them, and no film from the big studios could open without the approval of Joseph Breen's office.

### How a seven-year contract ran longer

Actors signed contracts with a studio for up to seven years, and studio heads did not count any time when an actor was not working. So a contract could run much longer than seven years. The actress Olivia de Havilland sued Warner Bros. over this in 1943. On December 8, 1944, California judges ruled that seven years meant seven years on the calendar.

**Eight companies.** Eight companies made most American films by the 1930s. Five of them, MGM, Paramount, Warner Bros., 20th Century-Fox and RKO, also owned chains of theatres. By 1939 there were 15,000 movie theatres in the country.

The justices of the Supreme Court ruled against the five studios that owned theatres on May 4, 1948, in a case called the Paramount case. The justices also outlawed block booking, the studios' practice of selling films to theatres only in large bundles. By 1954 the studios had sold their theatres.

### Oscar Micheaux

> **Who:** A Black homesteader and novelist who made more than 40 films for Black audiences outside the Hollywood studios.
>
> **When and where:** Born in Metropolis, Illinois, on January 2, 1884. Made films from 1919 to 1948. Died in Charlotte, North Carolina, on March 25, 1951.
>
> **Movie:** *Midnight Ramble: Oscar Micheaux and the Story of Race Movies* (1994), a PBS documentary about him and about films made for Black audiences.

**The only known copy of his second film turned up in Spain.**

Oscar Micheaux made more than 40 films for Black audiences outside the Hollywood studios. He worked as a Pullman porter, an attendant on railroad sleeping cars. Then he farmed a homestead in Gregory County, South Dakota, a farm on land that the federal government gave to settlers who lived on it and worked it. In 1906 he bought the claim from a settler who had given it up, and he lost the farm in 1911. He wrote novels about that life and sold them door to door.

George Johnson, the manager of the Lincoln Motion Picture Company, a Black-owned film company, offered in 1918 to film his novel *The Homesteader*. Micheaux wanted to make the film himself. He started his own company and sold shares in it for $75 to $100 each. The film came out in 1919.

**Within Our Gates.** His next film, *Within Our Gates* (1920), shows a white mob lynching a Black couple and burning their bodies. Micheaux gave it to Chicago's censor board in December 1919, and the board's members first rejected it. Five months earlier, gangs of white youths in Chicago had attacked Black residents during a riot in which 38 people were killed, 23 of them Black. Critics feared the film would set off more violence. Officials in Omaha and New Orleans also blocked it or demanded cuts.

Micheaux's films played in about 700 theatres. He paid for each new film by touring with the last one and raising money from investors along the way, often carrying the copies of the film by hand. The only known copy of *Within Our Gates* was found in Spain in 1979.

### Plays on the radio

Radio drama was acting for listeners who could not see the actors. Two white men, Freeman Gosden and Charles Correll, started *Amos 'n' Andy* on a Chicago radio station on March 19, 1928. They knew the traditions of the minstrel show. They voiced Amos, Andy and many other characters, more than 170 in the first ten years. One storyline in 1930 and 1931 drew about 40 million listeners. In 1930 Gosden and Correll played the parts in blackface in a film.

**The petitions.** Robert L. Vann, the publisher of the *Pittsburgh Courier*, a Black newspaper, collected petitions, written requests signed by many people, against the show from more than 700,000 Black Americans in 1931. Vann sent them to the Federal Radio Commission, the government office in charge of radio. Writers at the *Chicago Defender*, another Black newspaper, praised the show that same year.

**The War of the Worlds.** Orson Welles, who was 23, and his Mercury Theatre on the Air performed H. G. Wells's novel *The War of the Worlds* on the CBS radio network on October 30, 1938. They acted it as a string of fake news bulletins about Martians landing in New Jersey. The announcement that it was a play came almost 40 minutes in.

The next morning, newspaper stories across the country described a national panic. The *New York Times* ran an opinion piece headed "Terror by Radio." Later researchers found that the panic was far smaller than those stories said. Jefferson Pooley and Michael J. Socolow, writing in *Slate* in 2013, called it a myth, and they wrote that newspapers, which had been losing advertising money to radio, blew the story up.

That night workers for C. E. Hooper, a company that counted radio listeners, had telephoned 5,000 homes. Only 2 percent said they were listening to the Welles program, and none said they were hearing a news broadcast. Some listeners were frightened and called police stations and newspapers. Six weeks later, Princeton researchers checked six New York City hospitals and found no one brought in because of the broadcast. No death has ever been traced to it.

### The Federal Theatre Project, 1935 to 1939

Federal officials set up the Federal Theatre Project on August 27, 1935, to pay theatre workers to put on plays. It was part of the Works Progress Administration, a federal program that gave people jobs. Harry Hopkins, the head of that program, chose Hallie Flanagan, a theatre professor at Vassar College, to lead the project.

Within a year it employed 15,000 people at $23.86 a week, when the actors' union said an actor should get at least $40. About 30 million people saw its roughly 1,200 productions, and most of the shows were free.

**Macbeth in Harlem.** Federal Theatre officials set up 17 Negro Theatre Units, companies of Black actors, in cities from Seattle to Birmingham. On April 14, 1936, the New York unit opened *Macbeth* at the Lafayette Theatre in Harlem. It had an all-Black cast of about 150 and was set on an island like Haiti in the 1800s. Orson Welles, then 20, directed it. A free show on April 20 drew 3,000 more people than the theatre could seat.

**The end.** In 1938 Martin Dies Jr. and the other members of a House of Representatives committee he led held hearings and charged that the project spread communism, a system in which one party runs the government and the government owns the farms and factories. The committee's members argued that "racial equality forms a vital part of the Communist dictatorship." On December 6, 1938, Flanagan testified before the committee. Members of Congress then cut off the project's money in June 1939, and 8,000 people lost their jobs.

### Anna May Wong

> **Who:** A film actress often called the first Chinese American film star, who spoke out against the parts that film studios gave her.
>
> **When and where:** Born Wong Liu Tsong in Los Angeles on January 3, 1905. Acted in the United States and Europe from 1919. Died in Santa Monica, California, on February 3, 1961.

**"Why is it that the screen Chinese is always the villain?"**

Anna May Wong became a film star while producers kept her out of leading parts written for Chinese women. Her parents were Chinese Americans. She got her first film job as an extra in 1919. She starred in *The Toll of the Sea* (1922), one of the first films made in color.

Studio producers would not let her kiss a white actor on screen, because state laws banned marriage between races. That held even when the white actor was playing an Asian man. Producers cast her as villains, as the sly and dishonest "Dragon Lady," or as the gentle "Butterfly" who gives up everything. In 1933 she wrote in a magazine article called "I Protest," "Why is it that the screen Chinese is always the villain?"

**The Good Earth.** The producers at MGM refused to consider her for O-Lan, the Chinese heroine of *The Good Earth* (1937). They gave the part to Luise Rainer, a white actress made up to play a Chinese woman. Rainer won the Academy Award for Best Actress. MGM's producers tested Wong for Lotus, a dishonest singer. She turned the part down. She told the producer Irving Thalberg that he was asking her, "with Chinese blood," to play "the only unsympathetic role" in a film where white actors played the Chinese characters.

She starred in *The Gallery of Madame Liu-Tsong* in 1951, the first American television series with an Asian American star. In 2022 her picture went on the quarter, which made her the first Asian American shown on United States coins.

### Hattie McDaniel

> **Who:** The first Black person to win an Academy Award.
>
> **When and where:** Born in Wichita, Kansas, on June 10, 1893. Acted in Los Angeles from the 1930s. Won the award on February 29, 1940. Died on October 26, 1952.

**She won the Academy Award and sat at a separate table.**

Hattie McDaniel won the Academy Award in 1940 and had to sit apart from the white stars of her film to receive it. She was the youngest of 13 children, and her parents had been enslaved.

In *Gone with the Wind* she played Mammy, an enslaved house servant, for $450 a week. The film opened in Atlanta on December 15, 1939, at the Loew's Grand Theatre. The producer, David O. Selznick, asked that she attend. Officials at MGM advised against it because of Georgia's segregation laws, under which Black and white people had to stay apart. She did not go. Clark Gable, the film's star, threatened to stay away too, and she talked him into going.

**The award.** She won the Academy Award for Best Supporting Actress on February 29, 1940. The ceremony took place at the Cocoanut Grove in the Ambassador Hotel in Los Angeles. The hotel had a strict rule against Black guests, and Selznick had to ask a special favor to get her into the building. She sat at a small table with her escort and her white agent, away from the film's white stars. In her speech she said she hoped to "always be a credit to my race."

Accounts differ on where the table stood. *The Hollywood Reporter* places it against a far wall. A 2008 book places it at the back of the room. A 2019 article places it in a separate back room used to store the trophies.

At least 74 of her film parts were maids and other servants. Walter White of the NAACP and others criticized her for taking those parts. She often answered, "I'd rather play a maid than be a maid."

**Her house and her grave.** In 1945 white neighbors in West Adams Heights, her Los Angeles neighborhood, sued her and 30 other Black homeowners. They wanted to force them out under a rule that only white people could live there. Judge Thurmond Clarke threw the case out. McDaniel died of breast cancer in 1952. She had asked to be buried in Hollywood Cemetery, but the people who ran it refused, because the cemetery took only white people. She was buried at Rosedale Cemetery.

### The first television plays

The radio station WGY in Schenectady, New York, broadcast a short spy play called *The Queen's Messenger* by television on September 11, 1928. It was the first television drama. Two actors, Izetta Jewell and Maurice Randall, performed it. Viewers watched on screens three inches wide.

Twenty years later, on June 8, 1948, the NBC network began broadcasting a comedy show called *Texaco Star Theater*. The comedian Milton Berle became its host that fall, and people called him "Mr. Television."

**If you remember one thing:** Films and radio carried the old minstrel parts to millions of people, and studio rules and state laws kept actors of color out of love scenes with white actors.

**One number:** about 40 million. That many people listened to one storyline of *Amos 'n' Andy*, in which two white men played Black characters, in 1930 and 1931. In 1931 more than 700,000 Black Americans signed petitions against the show.

**Next:** Ten Hollywood writers and directors refused in 1947 to tell a House committee whether they belonged to the Communist Party.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 15 minutes**

The fight over who could act turned political after 1947. Members of a House committee questioned film workers about communism, a system in which one party runs the government and the government owns the farms and factories. Studio executives announced that they would not knowingly hire any Communist. Hundreds of writers, directors and actors lost work, some for more than ten years.

**Live and on film.** Actors in the early 1950s performed plays live on television, with no second takes. By 1961 about 80 percent of evening programs were filmed ahead of time.

**The parts on offer.** White actors still played Asian and Native characters. Actors of color such as Rita Moreno and Sidney Poitier won Academy Awards, and they were still offered a narrow set of parts.

Studio executives began opening big films in hundreds of theatres on the same day in 1975. Families could record shows at home from 1975, and in 1984 the Supreme Court justices ruled that taping a broadcast to watch later was legal. A physicist built one of the first video games in 1958, and by the 1990s game makers were hiring actors.

### Who lost work in the blacklist?

Hundreds of people in film, radio and television lost their jobs in the late 1940s and 1950s because of their politics, or because they would not answer questions about it. Studio executives put them on a blacklist, a list of people they would not hire. The list was rarely written down. It grew out of many separate decisions by studio executives.

**The hearings.** Members of the House Un-American Activities Committee, a group of members of the House of Representatives, ordered 42 people from the film industry in late September 1947 to answer questions about communism. The hearings began in October. Walt Disney, the studio head Jack Warner, and the actors Gary Cooper and Ronald Reagan answered the committee's questions. Disney named former employees of his who, he said, were probably Communists.

**The Hollywood Ten.** Ten writers and directors refused to say whether they belonged to the Communist Party. They became known as the Hollywood Ten. On November 24, 1947, members of the House voted 346 to 17 to charge them with contempt of Congress, the crime of refusing to cooperate with Congress.

The next day, nearly 50 film executives met at the Waldorf-Astoria hotel in New York. Eric Johnston, who led the group that spoke for the film producers, then announced that the ten would be fired or suspended without pay. He said the studios would not "knowingly" hire any Communist. The promise is called the Waldorf Statement.

The ten were found guilty in 1948. They appealed, and the justices of the Supreme Court refused to hear their case again. They went to prison in 1950, for up to a year each. Others lost their jobs after witnesses named them, or after they refused to answer the committee's questions. The list grew to hundreds of names, and no one kept a complete count.

**False names.** Some writers kept working under false names. In 1957 the Academy Award for the story of *The Brave One* went to "Robert Rich." That was a false name for the blacklisted writer Dalton Trumbo. The real Robert Rich was the nephew of the film's producer. In 1975 Academy officials reissued the award in Trumbo's name.

Some people named others to the committee, among them the director Elia Kazan and the writer Budd Schulberg. The actor Sterling Hayden said in 1963, "I was a rat, a stoolie, and the names I named of those close friends were blacklisted and deprived of their livelihood," using "stoolie" for a person who informs on others.

The blacklist began to break in 1960. The director Otto Preminger announced on January 20 that Trumbo had written *Exodus*, and the actor Kirk Douglas gave Trumbo credit on screen for *Spartacus*.

**Paul Robeson.** Paul Robeson was a Black actor who also gave concerts. In 1943 he became the first Black actor to play Othello on Broadway. In 1949 he gave a speech in Paris that was misquoted, and his concerts were canceled. Britannica's account does not name who misquoted him or who canceled the concerts.

That year near Peekskill, New York, people against communism started a riot and burned a straw figure of him. In 1950 officials of the State Department took away his passport, so he could not travel outside the country. His yearly income fell from $100,000 to $6,000 between 1947 and 1952.

He told the House committee in 1956, "I am not being tried for whether I am a communist." He said he was being tried "for fighting for the rights of my people, who are still second-class citizens in these United States of America."

### Lee Grant

> **Who:** An actress who was blacklisted for twelve years at the start of her film career, and who later won an Academy Award for acting. A documentary she directed won another Academy Award.
>
> **When and where:** Born Lyova Haskell Rosenthal in New York City on October 31. The year is disputed, and every year from 1925 to 1931 has been given. Acted in New York and Los Angeles from 1948.

**"Twelve working, acting years from my life."**

Lee Grant lost twelve years of work in film and television to the blacklist. In 1949 she played a shoplifter in the play *Detective Story* on Broadway, and she played the part again in the 1951 film. It earned her an Academy Award nomination and the Best Actress prize at the Cannes Film Festival in France.

**Two reasons.** The actor J. Edward Bromberg died in 1951 soon after members of the House committee questioned him. At his memorial service, Grant gave a speech that suggested the committee's pressure had caused his death. In April 1951 the director Edward Dmytryk had named the writer Arnold Manoff to the House committee as a Communist. Grant married Manoff in 1952.

Accounts give two reasons why film and television employers put her on the blacklist, and they do not name those employers. One is her speech for Bromberg. The other, as the actor Kirk Douglas remembered it, is that she refused to testify about her husband.

For twelve years she could get little work in film or television. She taught acting and took small parts under other names. In her 2014 book about her own life she wrote of "my rage at those who had taken twelve working, acting years from my life."

She came back in the television series *Peyton Place* and won an Emmy award in 1966. She won the Academy Award for Best Supporting Actress for *Shampoo* (1975). Her documentary *Down and Out in America* (1986) won the Academy Award for Documentary Feature.

### The Actors Studio, and plays on live television

Elia Kazan, Cheryl Crawford and Robert Lewis, all from a theatre company called the Group Theatre, opened the Actors Studio in New York in 1947, a place where working actors trained. About 700 actors tried out in the first year, and 50 were chosen, including Marlon Brando. Teachers at the studio taught "method acting," a way of acting built on the teaching of Konstantin Stanislavsky, a Russian director at the Moscow Art Theatre. Lee Strasberg ran the Actors Studio from 1952 until he died in 1982.

Brando played Stanley Kowalski in Tennessee Williams's play *A Streetcar Named Desire* on Broadway on December 3, 1947. Kazan directed it, and he directed the film version in 1951.

**One chance.** The television networks broadcast plays performed live from 1947, such as *Kraft Television Theatre*, from May 7, 1947, and *Studio One*, from November 7, 1948. The actors had one chance, with no second takes. The first practical videotape came in 1957. By 1961 about 80 percent of evening programs were filmed ahead of time.

### I Love Lucy: a stage comedy on film

*I Love Lucy* was filmed like a stage play, in front of a live audience. It ran on CBS from October 15, 1951, to May 6, 1957. Lucille Ball and Desi Arnaz acted each episode in order, like a play, before an audience of about 300 people. Three film cameras recorded it at the same time.

Jerry Fairbanks had used the three-camera method on other shows before. Karl Freund, the man in charge of the cameras, filmed *I Love Lucy* with three 35 mm film cameras. It was the first scripted television show filmed on 35 mm film in front of a studio audience.

**The deal.** Executives at Philip Morris, the company that paid for the show, wanted it performed live in New York. Ball and Arnaz wanted to stay in Los Angeles, because Ball was pregnant, and to make the show on film. They offered to take a pay cut of $1,000 a week, and executives at CBS and Philip Morris agreed. In return Ball and Arnaz got 80 percent ownership of the films. Because they owned the films, they could sell the episodes again as reruns.

### Lucille Ball

> **Who:** A film actress who starred in the television comedy *I Love Lucy* and then became the first woman to run a major television studio.
>
> **When and where:** Born in Jamestown, New York, on August 6, 1911. Worked in Los Angeles from the 1930s. Died on April 26, 1989.
>
> **Movie:** *Being the Ricardos* (2021), a feature film about Ball and Arnaz, written and directed by Aaron Sorkin.

**About 44 million people watched Lucy have a baby.**

Lucille Ball became the first woman to run a major television studio in 1962. Through the 1930s she acted in films under contract to the RKO studio. People called her "Queen of the B's," after the low-budget films called B movies.

She starred in a radio comedy, *My Favorite Husband*, on CBS in 1948. Her real husband was Desi Arnaz, a Cuban American bandleader and actor. When CBS made *I Love Lucy*, the network's executives at first did not want Arnaz, a Cuban, cast as Ball's husband.

The episode of *I Love Lucy* in which Lucy has a baby aired on January 19, 1953, and about 44 million people watched it. In 1957 Desilu, the company Ball and Arnaz owned, bought the old RKO studios for more than $6 million. Ball had once worked there as a contract actress.

**Running the studio.** Ball and Arnaz divorced in 1960. In November 1962 she bought his share of Desilu and became its president. Desilu's staff developed the television series *Star Trek* and *Mission: Impossible*. She agreed in 1967 to sell Desilu for $17 million, and the sale closed in 1968.

### Lorraine Hansberry

> **Who:** The first Black woman to have a drama produced on Broadway.
>
> **When and where:** Born in Chicago on May 19, 1930. *A Raisin in the Sun* opened in New York on March 11, 1959. Died in New York City on January 12, 1965, at 34.
>
> **Movie:** *Lorraine Hansberry: Sighted Eyes/Feeling Heart* (2017), a documentary about her life and work.

**Her family's fight over a house reached the US Supreme Court.**

Lorraine Hansberry wrote *A Raisin in the Sun*, the first drama by a Black woman to be produced on Broadway. Her father, Carl Hansberry, bought and sold houses for other people in Chicago. When she was about seven, the family bought a house in Woodlawn, a white neighborhood. Owners there had signed a restrictive covenant, an agreement not to sell to Black people.

Anna M. Lee, a homeowner in the neighborhood, sued to cancel the sale. A violent mob harassed the family. The judges of the Illinois Supreme Court ruled against the Hansberrys, and the family had to leave. In 1940, in the case *Hansberry v. Lee*, the justices of the US Supreme Court reversed that ruling. Only 54 percent of the owners had signed the agreement, and it needed 95 percent.

**The play.** *A Raisin in the Sun* tells of the Younger family, a Black family in Chicago who buy a house in a white neighborhood. Karl Lindner, a white man sent by that neighborhood, offers to buy them out so they will stay away. The producer, Philip Rose, spent 18 months raising money for a play in which all but one character is Black.

Lloyd Richards directed it, the first Black director of a Broadway play. Sidney Poitier and Ruby Dee starred. The play ran for 530 performances. Richards said it was the first play on Broadway that large numbers of Black people came to see. Hansberry died of pancreatic cancer in 1965.

### Who was allowed to play whom

White actors kept playing Asian characters. In *Breakfast at Tiffany's* (1961), Mickey Rooney, a white actor, played a Japanese landlord named I. Y. Yunioshi. In 2008 an Asian American group in Sacramento, California, told the city council that the part spread "hateful racial stereotypes," unfair ideas that every member of a group is the same, and the film was pulled from a free film series there. Rooney said that if he had known people would be so offended, "I wouldn't have done it."

**Iron Eyes Cody.** Espera de Corti was born in Kaplan, Louisiana, in 1904. Under the name Iron Eyes Cody, he played Native Americans in more than 200 films, and he said his parents were Cherokee and Cree. In 1971 he appeared in a television advertisement against litter, with a tear rolling down his face. In 1996 a New Orleans newspaper reported what his half-sister and his baptism record showed: his parents were Sicilian and Italian, and he was Italian American. He denied it.

### Rita Moreno

> **Who:** A Puerto Rican actress, dancer and singer who became the first Hispanic woman to win an Academy Award.
>
> **When and where:** Born Rosa Dolores Alverío Marcano in Humacao, Puerto Rico, on December 11, 1931. Moved to New York in 1936. Acted in Hollywood from 1950. Won the award on April 9, 1962.
>
> **Movie:** *Rita Moreno: Just a Girl Who Decided to Go for It* (2021), a documentary about her.

**"I was always barefoot. It was humiliating, embarrassing stuff."**

Rita Moreno became the first Hispanic woman to win an Academy Award on April 9, 1962, and film producers went on offering her the same narrow parts. Her mother brought her from Puerto Rico to New York City in 1936. Moreno was acting on Broadway at 13, and as a teenager she signed a contract with MGM.

Studio producers cast her again and again in the same kind of part. She later said, "I was always offered the stereotypical Latina roles. The Conchitas and Lolitas in westerns. I was always barefoot. It was humiliating, embarrassing stuff. But I did it because there was nothing else."

**Anita.** In the film *West Side Story* (1961) she played Anita, a Puerto Rican woman in New York. The part won her the Academy Award for Best Supporting Actress. She said the offers that followed were "pretty much the same thing. A lot of gang stories." She did not make another film for seven years. She went on to win a Grammy award for recorded music in 1972, a Tony award for theatre in 1975, and Emmy awards for television in 1977 and 1978.

### Sidney Poitier

> **Who:** The first Black man to win the Academy Award for Best Actor.
>
> **When and where:** Born in Miami on February 20, 1927. Raised in the Bahamas. Acted in New York and Los Angeles from the 1940s. Won the award on April 13, 1964. Died on January 6, 2022.
>
> **Movie:** *Sidney* (2022), a documentary about him, directed by Reginald Hudlin.

**An older waiter helped him read the newspaper every night.**

Sidney Poitier became the first Black man to win the Academy Award for Best Actor on April 13, 1964. His parents were tomato farmers on Cat Island in the Bahamas. He was born two months early in Miami, while they were there on business, so he was a US citizen. He grew up on Cat Island and in Nassau. He went to Miami at 15 and moved to New York at 16, where he worked washing dishes.

**The audition.** Poitier failed his first audition at the American Negro Theatre, a Black theatre company in New York, because he could not read the script well. An older waiter sat with him every night for several months and helped him read the newspaper. In November 1943, at 16, he joined the Army. Later he tried out again and won a part.

He became the first Black actor nominated for Best Actor in 1958, for *The Defiant Ones*. In 1959 he starred on Broadway in *A Raisin in the Sun*. He won Best Actor for *Lilies of the Field* in 1964. In 1967 more people bought tickets to his films than to any other star's. Critics complained that his characters were too perfect. At the time, he was the only major Black actor being cast in leading parts.

### Why Brando refused his Oscar, 1973

Marlon Brando won the Academy Award for Best Actor for *The Godfather* on March 27, 1973, and he refused it in protest. He stayed away from the ceremony and sent Sacheen Littlefeather, who said her father was White Mountain Apache and Yaqui, to refuse the award for him.

She spoke for about 60 seconds. She said Brando was protesting "the treatment of American Indians today by the film industry," and the armed standoff then going on at Wounded Knee, South Dakota. Some people in the audience booed, and some applauded. In 2022 she said that some people mocked her with the "tomahawk chop," a chopping arm motion that makes fun of Native people, as she was led off the stage.

**Wounded Knee, 1973.** About 200 Oglala Lakota people and members of the American Indian Movement held the village of Wounded Knee for 71 days, from February 27 to May 8, 1973. They were protesting broken treaties and the chairman of the Pine Ridge tribal government. Federal marshals, officers who work for the courts, and FBI agents surrounded them.

Two of the people holding the village were shot and killed. Frank Clearwater was shot in the head during a gun battle with federal forces, and a federal agent's sniper shot Lawrence "Buddy" Lamont through the heart. A US marshal, Lloyd Grimm, was shot and paralyzed from the waist down.

**Afterward.** Academy officials sent Littlefeather a letter of apology in June 2022. Littlefeather died on October 2, 2022. After her death, her two sisters told the Navajo writer Jacqueline Keeler that the family was not Native American. They said their father was of Spanish and Mexican descent.

### Big openings and home video

*Jaws* opened on 409 screens in the United States at once on June 20, 1975, with advertisements on national television. Columbia Pictures executives had done something like it a month earlier with a film called *Breakout*. *Jaws* earned more than any film before it. *Star Wars* opened on May 25, 1977, in only a small number of theatres, because few theatre owners wanted it. It quickly became a surprise success and passed *Jaws* in earnings.

**Taping at home.** Sony's Betamax video recorder went on sale in the United States in November 1975. The first VHS recorder in the United States, made by RCA, followed on August 23, 1977. In 1976 Universal and Walt Disney Productions sued Sony to stop people from taping at home. On January 17, 1984, the justices of the Supreme Court ruled 5 to 4, in *Sony v. Universal*, that recording a broadcast at home to watch later was legal.

### Games, and the first actors in them

The physicist William Higinbotham built *Tennis for Two* in 1958 for a public exhibition at Brookhaven National Laboratory in New York. Visitors lined up to play it on an oscilloscope, a screen that draws lines of light. In 1972 the Atari company sold *Pong* to arcades. It was the first video game to sell well.

**Filmed actors.** The early games had no actors. From 1983 some arcade games played filmed scenes stored on laser discs, shiny discs read by a beam of light. In the early 1990s, games on compact discs used filmed actors, often from low-budget films and television. *Night Trap* (1992) and *The 7th Guest* (1993) were two of them. In 1994 the makers of *Wing Commander III*, published by Electronic Arts, cast Hollywood actors in it, including Mark Hamill.

**If you remember one thing:** Actors lost work for their politics after 1947, and actors of color won the top awards while studios went on offering them narrow parts.

**The question this era leaves open:** Game makers had begun to hire actors. Would the people who acted in games be paid like film and television actors?

**Next:** The English actor Andy Serkis played the creature Gollum in a marker suit, and people argued over whether that was acting.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 23 minutes**

The newest fight over acting is over computer copies of actors' faces, bodies and voices. Since 2000, actors have performed in suits covered with markers while computer artists turned their movements into creatures and game characters, and game makers now hire actors to perform whole stories. In 2023 film and television actors and writers went on strike together for the first time since 1960.

Video game performers struck from July 2024 to July 2025. Both strikes were partly about who controls a computer copy of a performer's face, body and voice.

**Screens and seats.** People could watch films and series streamed into their homes over the internet from 2007. Moviegoers in the United States and Canada spent 22 percent less on tickets in 2025 than in 2019.

**Who is on screen.** Michelle Yeoh and Ke Huy Quan won Academy Awards for acting in 2023, and in 2024 Lily Gladstone became the first Native American nominated for Best Actress.

### Acting in a marker suit

In motion capture, cameras record the movements of an actor's body, and a computer uses those movements to move a character that artists have drawn. When the cameras also record the actor's face, the method is often called performance capture.

**Gollum.** In the *Lord of the Rings* films (2001 to 2003), the English actor Andy Serkis played the creature Gollum on set, beside the other actors. Artists at a company called Weta Digital used the recorded movements of his body and face. They painted Serkis out of each shot, one frame, or single picture, of the film at a time, and put the computer-made Gollum in his place.

For *The Two Towers*, the second film, the crew fed Serkis's movements into the Gollum model while he performed. It was the first feature film to use capture as the actor acted.

Other actors followed. Tom Hanks played several characters this way in *The Polar Express* (2004). The actors who played the Na'vi people in *Avatar* (2009) did too, and so did Mark Ruffalo as the Hulk in *The Avengers* (2012).

### Andy Serkis

> **Who:** An English actor whose performance-capture work started an argument. People asked whether a performance turned into a computer-made body still counts as acting.
>
> **When and where:** Born April 20, 1964. Played Gollum in films released from 2001 to 2003. Played the ape Caesar in the *Planet of the Apes* films from 2011 to 2017.

**He called the animators' work "painting digital makeup."**

After Andy Serkis played Gollum, people argued in public over whether an actor whose body is replaced on screen by a computer image is still acting. Serkis also gave Gollum his voice, and for the second and third films the artists redesigned Gollum's face to look more like his.

**The Oscar campaign.** The films' producer, Barrie M. Osborne, argued that Serkis should be nominated for an Academy Award as an actor, because his voice, his body movements and his facial expressions were on screen. In 2011 staff at the studio 20th Century Fox campaigned for a nomination for his work as the ape Caesar in *Rise of the Planet of the Apes*.

The actor James Franco called Serkis "the undisputed master of the newest kind of acting called 'motion capture.'" Serkis said the apes were "infused with the heart and soul of an actor." He has never been nominated for an acting Oscar. *War for the Planet of the Apes* (2017) was nominated for its visual effects instead.

Serkis described the animators' work in 2014 as "painting digital makeup" onto an actor's performance. Animators objected that the phrase made their work sound small. The director Matt Reeves said the phrase had come from Weta's own artists. In 2011 Serkis opened a capture studio in London, called the Imaginarium.

### Games as acted stories

The game company Naughty Dog released *The Last of Us* on June 14, 2013. Troy Baker played Joel, and Ashley Johnson played Ellie, with their voices and their bodies. About 85 percent of the movement in the game was recorded on a motion-capture stage. Some lines were recorded later in a sound studio. The two actors changed their characters as they worked.

The HBO television version began on January 15, 2023, with Pedro Pascal as Joel and Bella Ramsey as Ellie. Ramsey was told not to play the game, so as not to copy Johnson's performance.

**The first game strike.** Game actors went on strike for the first time from October 2016 to September 2017, for 340 days. They asked for residuals, payments that grow when a game sells well, and they did not get them. In 2016 the voice actor Jennifer Hale told NPR that game actors were paid $825 for a four-hour session, with nothing more however many copies sold.

### Ashley Johnson

> **Who:** A child television actor who later played Ellie in the video game *The Last of Us* with her voice and her body, and won the British Academy's game award for performance twice.
>
> **When and where:** Born in Camarillo, California, on August 9, 1983. Acting in Los Angeles from 1990.

**She talked the director into making Ellie tougher.**

Ashley Johnson played Ellie in *The Last of Us*, and her acting changed who Ellie is. She began acting at six, as Chrissy Seaver on the comedy *Growing Pains*, from 1990 to 1992. By the time she was 12 she had been in the casts of eight television series.

She persuaded the game's director, Neil Druckmann, to rewrite Ellie as tougher and more independent. She said, "There were some days when we would shoot things that even at my age made me feel a little uncomfortable."

**Her face.** Her own face shaped the character. The actor Elliot Page complained that the first design of Ellie looked like Page. The studio's artists then redrew Ellie to look younger and more like Johnson.

Johnson won the British Academy Games Award for Performer for the 2013 game. She won it again on March 12, 2015, for the added chapter *Left Behind*. She is the only person to have won it twice. She played Ellie again in *The Last of Us Part II* (2020). In the 2023 television series, she played Ellie's mother, Anna.

### Streaming, and fewer people in movie theatres

Since 2007 people have watched films and series streamed into their homes, and moviegoers now spend less at theatres than they did before 2020. Streaming means watching a film or show sent over the internet while it plays, instead of on a disc or at a set broadcast time. Netflix, a company that then mailed DVDs to renters, began its streaming service in January 2007, with 1,000 titles.

Every episode of *Lilyhammer*, a Norwegian series Netflix had bought, came out on the same day in February 2012. *House of Cards*, the first series Netflix had ordered made for itself, came out in February 2013. By 2026 Netflix had 325 million paid memberships in more than 190 countries.

**The empty theatres.** Theatres in North America had their lowest ticket sales since 1998 over one weekend in March 2020, as the COVID-19 disease spread. Days later, Universal executives announced that three new films would be sold for home viewing within the week. Disney put *Mulan* on its own streaming service instead of in American theatres.

In July 2020 executives at the AMC theatre chain and at Universal agreed that Universal could sell a film for home viewing after at least 17 days in AMC theatres.

**Fewer tickets.** Moviegoers in the United States and Canada bought about 780 million tickets in 2025, about 5 percent fewer than the more than 820 million of 2024, according to the research company Comscore. Because the average ticket cost more, they still spent 1.5 percent more than in 2024, a total of $8.87 billion. That was 22 percent less than the $11.4 billion they spent in 2019, before the theatres closed.

### Broadway dark for eighteen months

New York Governor Andrew Cuomo ordered on March 12, 2020, that gatherings of 500 people or more be canceled. Under his order, the Broadway theatres had to close at 5 p.m. that day, a day earlier than other large events. According to the theatre magazine *Playbill*, all 41 Broadway theatres stayed dark, which means closed, for 18 months.

**Pass Over.** The first play back on Broadway was *Pass Over*, by the playwright Antoinette Nwandu. It began previews, the shows before the official opening, at the August Wilson Theatre on August 4, 2021, and it opened on August 22. Full productions of other shows returned that fall.

Nwandu had started writing it in 2012, after Trayvon Martin, an unarmed Black 17-year-old, was shot and killed in Sanford, Florida. George Zimmerman, a man who volunteered to watch his neighborhood for crime, shot him. In 2013 a jury found Zimmerman not guilty.

The Broadway League reported in May 2026 that in the season ending May 24, 2026, audiences bought 14,577,322 tickets and paid $1.91 billion. That was the most money in any Broadway season on record.

### YouTube and TikTok

Chad Hurley, Jawed Karim and Steve Chen, three former workers at the payment company PayPal, started YouTube in February 2005. The first video went up on April 23, 2005.

From May 2007, makers of videos in YouTube's Partner Program got a share of the advertising money, usually 55 percent, and YouTube kept 45 percent. From 2018 a channel needed at least 10,000 lifetime views to join the program. Since November 2020, YouTube's staff can put advertisements on any video in the United States. When the maker is not in the program, Google, which owns YouTube, keeps all of that money.

An app called Musical.ly was merged into TikTok, an app owned by the company ByteDance, on August 2, 2018. That October, TikTok was the most downloaded app in the United States.

**By May 2026:** Actors in marker suits played creatures and game characters, Netflix had 325 million paid memberships, and Broadway had just finished the season that took in the most money on record.

### Who is on screen, and who votes on the awards

All 20 actors nominated for Academy Awards on January 15, 2015, were white. That day April Reign started the Twitter hashtag #OscarsSoWhite, a tag that people added to their posts to join the protest. On January 14, 2016, all 20 were white again. The director Spike Lee and the actress Jada Pinkett Smith said they would stay away from the ceremony.

**The voters.** Members of the Academy of Motion Picture Arts and Sciences vote on the Oscars, and in 2015 most of them were white men. That year 92 percent of the members were white, and three of every four were men. In 2016 the Academy's president, Cheryl Boone Isaacs, promised to double the number of women and people of color among its members by 2020. The Academy then had about 6,000 members.

By 2019 women were 32 percent of the members, up from 25 percent, and people of color were 16 percent, twice the 8 percent of 2015. The Associated Press reported in June 2026 that if everyone invited that year joined, the Academy would have 11,319 members. Of them, 75 percent would be white, down from 92 percent in 2015, and 64 percent would be men.

**The count.** Hispanic and Native characters were rare in the most popular films of 2024. Researchers at the USC Annenberg Inclusion Initiative count the speaking characters in each year's 100 most popular films. In the films of 2024, they reported in August 2025, 63.6 percent of speaking characters were white, 13.2 percent Black and 13.5 percent Asian. Only 3.1 percent were Hispanic or Latino, and fewer than 1 percent were American Indian or Alaska Native. Ninety-eight of the 100 films had no Native American girls or women.

Asian people are about 6.3 percent of the US population, so Asian characters had about twice that share overall. They were bunched into some of the films, though: 29 of the 100 films had no Asian speaking characters at all.

**Reservation Dogs.** *Reservation Dogs* ran on the Hulu streaming service from August 9, 2021, to September 27, 2023. Sterlin Harjo, a filmmaker from Oklahoma, created it with Taika Waititi. It is about four Native teenagers in a small town in the Muscogee Nation. It was the first American series with all Native writers and directors and an almost all Native cast.

**Killers of the Flower Moon.** *Killers of the Flower Moon* opened on October 20, 2023. It is about the murders of Osage people for their oil money in Oklahoma in the 1920s. Each Osage person held a share of the tribe's oil money, called a headright. When a holder died, the headright passed to the heirs, who could be people who were not Osage.

Under a 1921 law, local judges put many Osage adults' money under white "guardians," men who controlled it for them. Guardians and some of the men who married Osage women stole that money. Between about 1920 and 1925, more than 60 Osage headright holders died in murders and suspicious deaths, by the Osage Nation's count. The FBI counts at least two dozen.

The cattleman William Hale ordered the murders of the family of Mollie Kyle, an Osage woman, so that their headrights would pass to Hale's nephew, Ernest Burkhart, Mollie's husband. Mollie's sister Anna Brown was shot on May 22, 1921. The sisters' mother, Lizzie Q. Kyle, died in July 1921, and poison was suspected. Their cousin Henry Roan was shot in January 1923.

On March 10, 1923, the house of Mollie's sister Rita and Rita's husband, Bill Smith, was blown up, killing them and their servant, Nettie Brookshire. Ernest Burkhart pleaded guilty in 1926, and Hale was found guilty in 1929. Both were sentenced to life in prison.

**Osage actors.** The director, Martin Scorsese, met with the chief of the Osage Nation, Geoffrey Standing Bear. The film's makers held a meeting with about 200 Osage people. They cast Osage actors in at least 40 parts and hired Christopher Côté to teach the actors the Osage language.

At the premiere, Côté spoke about the film's telling of Mollie's marriage to Burkhart, the man who pleaded guilty in the murders of her family: "when somebody conspires to murder your entire family, that's not love. That's not love, that's just beyond abuse." In 2024 he said, "I still stand by what I said."

Lily Gladstone, who grew up on the Blackfeet Reservation in Montana, played Mollie Kyle, the Osage wife. In January 2024 she became the first Native American to win a Golden Globe for acting, and the first Native American nominated for the Academy Award for Best Actress.

*Everything Everywhere All at Once* is about a Chinese immigrant woman who runs a laundromat. On March 12, 2023, it won seven Academy Awards. Michelle Yeoh won Best Actress, and Ke Huy Quan won Best Supporting Actor.

### Ke Huy Quan

> **Who:** A child actor from a refugee family who quit acting when he could not get parts as an adult Asian American actor, and came back decades later to win an Academy Award.
>
> **When and where:** Born in Saigon, South Vietnam, in 1970. Came to the United States in 1979. Acted in Los Angeles from 1984. Won the award on March 12, 2023.

**"My journey started on a boat."**

Ke Huy Quan gave up acting because he could not get parts, and he did not act on screen again for 19 years, from 2002 to 2021. Then he came back to win an Academy Award.

His family's ancestors were Chinese, and the family lived in Vietnam. They left Vietnam three years after the war there ended in 1975. Quan, his father and five of his brothers and sisters went to a camp in Hong Kong for refugees, people who flee their country to be safe. His mother and three of the other children went to Malaysia. In 1979 the whole family came to the United States as refugees and settled in Los Angeles.

At 13 Quan played Short Round, Harrison Ford's young sidekick, in *Indiana Jones and the Temple of Doom* (1984). In 1985 he played Data in *The Goonies*. As he grew up, he said, "the opportunities got fewer, and the wait time longer. I was still working, but once a year, or once every two years. And the roles got smaller."

**The wait.** In 1993 he tried out for a part and never heard back. "I remember sitting at the edge of my bed, completely frozen," he said in 2023. He blamed himself: "I thought I wasn't tall enough, I wasn't good-looking enough, I was not a good enough actor." In time he quit acting and studied film at the University of Southern California. He arranged fights for the film *X-Men* (2000) and worked as an assistant director.

He watched the film *Crazy Rich Asians* in 2018. "I was sitting in the theatre, fantasising, wishing I was up there with them," he said. He went back to acting and played Waymond Wang in *Everything Everywhere All at Once*. On March 12, 2023, he won the Academy Award for Best Supporting Actor, and he began his speech, "My journey started on a boat." He was the first actor born in Vietnam to win an Oscar.

### #MeToo in Hollywood: Harvey Weinstein

Actresses were among the women who accused the film producer Harvey Weinstein of sexual attacks, and juries in New York and Los Angeles later found him guilty of rape and other sex crimes. Reporters at *The New York Times* and *The New Yorker* published the first accounts, from more than a dozen women, in October 2017. The women said Weinstein had sexually harassed them, meaning unwanted sexual remarks, demands or touching. Some said he had sexually assaulted them, meaning attacked them sexually, or raped them, meaning forced them into sex.

By the end of that month, more than 80 women had made such accusations. Leaders of his own company fired him, and the leaders of the Academy expelled him. Weinstein said he had never had sex with anyone against her will.

**The spies.** A month later a reporter for *The New Yorker* reported that Weinstein had hired a private spy company called Black Cube. Its investigators used false names to follow reporters and actresses. The people they followed included the actress Rose McGowan, who had said Weinstein raped her.

**The first trials.** A New York jury found Weinstein guilty in 2020 on two of the five charges against him: rape, and forcing oral sex on a woman. The jury found him not guilty on the other three, including the charge called predatory sexual assault. A judge sentenced him to 23 years in prison.

A Los Angeles jury found him guilty in 2022 on three of seven charges, for attacks in 2013: rape, forcing oral sex on a woman, and a third charge listed as sexual misconduct. The jury did not convict him on the other four. A judge sentenced him to 16 years.

**The new trial.** In 2024 the judges of New York's highest court threw out the two New York guilty decisions. They found that the trial judge had made "egregious errors," meaning very serious mistakes, and they ordered a new trial. Weinstein stayed in prison because of the California guilty decision.

At the new trial in 2025, a jury found him guilty of forcing oral sex on Miriam Haley, a former production assistant, a helper on a film crew, in his Manhattan apartment in 2006. The jury found him not guilty on the charge that involved the model Kaja Sokola. Two juries in a row could not agree on the charge that he raped the actress Jessica Mann, and in 2026 Manhattan's chief prosecutor announced that there would be no further trial on it.

**The sentence.** In September 2026 a judge, Curtis Farber, sentenced Weinstein to 15 years in prison for the attack on Haley. He told Weinstein, "You took what you wanted by force, and you have never accepted responsibility." Haley told the court that what he did to her was "a life sentence for me."

California judges had upheld his Los Angeles guilty decision earlier in 2026 but ordered a new sentence, and the California Supreme Court's justices declined to review the case. As of late September 2026, no date had been set for the new sentence.

**By September 2026:** Michelle Yeoh and Ke Huy Quan had won Academy Awards for acting, Lily Gladstone had become the first Native American nominated for Best Actress, and Harvey Weinstein was in prison.

### The 2023 strikes, and scanning

The Writers Guild of America is the union of 11,500 screenwriters. Its members struck against the studios from May 2 to September 27, 2023, for 148 days. Their new contract forbids the studios to use writers' work to train AI, or artificial intelligence: computer programs that can make new text, images and voices by copying patterns from the work of real people. It also forbids the studios to use AI to cut writers or writers' pay.

Members of SAG-AFTRA, the actors' union, with about 160,000 members, struck from July 14 to November 9, 2023. It was the longest actors' strike against the film and television studios, and the first time since 1960 that actors and writers had struck at the same time.

**The scans.** The union's chief negotiator, Duncan Crabtree-Ireland, said on July 13, 2023, that the studios' negotiators had proposed scanning background actors, extras with no lines, for one day's pay, with the studio owning the scans. The studios' negotiators answered that a scan would be used only in the film the actor was hired for.

In August 2023 NPR interviewed five background actors who had been scanned. Most had signed agreements not to talk about their work. They said they feared that if they refused a scan, they would be called difficult and not hired again. No public count exists of how many background actors were scanned.

**The contract.** The union's members approved the contract that ended the strike on December 5, 2023. It requires a studio to get clear consent, meaning permission, from an actor before it makes or uses a digital replica, a computer copy of the actor's face, body or voice. A studio that wants to use a replica in a different production must ask again and bargain over pay. The consent lasts after the actor dies unless the contract says otherwise. Studios may not use replicas to avoid hiring background actors.

The writers approved a new four-year contract in April 2026. SAG-AFTRA's members approved theirs on June 4, 2026. Of the members who voted, 91 percent said yes, but only about 19 percent of members voted. According to *Los Angeles Magazine*, it lets producers use a performer made entirely by computer only when that performer adds "significant additional value" over a live actor.

### Alexandria Rubalcaba

> **Who:** A background actor whom a television crew scanned into a digital copy of her face and body, with no word to her on how anyone would use it.
>
> **When and where:** On the Disney+ series *WandaVision* during the COVID-19 pandemic. She told her story to NPR in 2023.

**"Let us see your scared face. Let us see your surprised face."**

Crew members on a television set scanned Alexandria Rubalcaba into a digital copy, and no one told her how or whether the copy would be used. She worked for four weeks as a background actor on the series *WandaVision*. Then the crew sent her to a truck trailer.

Inside, dozens of background actors stood one at a time in front of cameras mounted on metal frames. She remembered the instructions: "Have your hands out. Have your hands in. Look this way. Look that way. Let us see your scared face. Let us see your surprised face."

Each scan took about 15 minutes, and a digital copy of each actor was made from it. Rubalcaba earned the union rate for background actors, $187 a day. She would not be paid for any use of the scan, and she did not give permission for her copy to appear in any scene. "What if I don't want to be on MarioVision, or SarahVision?" she asked. "I fear that AI is eventually going to weed out background actors. They won't have any use for us anymore."

Disney did not answer NPR's questions, and no record shows whether her scan was ever used. Her account came out in August 2023, during the actors' strike that won the rules on consent for replicas.

### The video game strike, 2024 to 2025

About 2,600 game performers who work in voice and motion capture struck from July 26, 2024, to July 9, 2025. They struck against companies including Activision, Electronic Arts, Epic Games, Take-Two and Warner Bros. Games. Their old contract had run out in November 2022. The one issue left unsettled was consent and pay for AI copies of the performers' voices and bodies.

**Darth Vader's voice.** Staff at Epic Games added Darth Vader to the game *Fortnite* on May 16, 2025. The character talked with players in a computer-made copy of the voice of James Earl Jones, who had died on September 9, 2024. In 2022 Jones had signed a deal that allowed his recorded voice to be used this way, and his family worked with Epic and Disney on it.

Union officials filed a charge with the National Labor Relations Board, the federal agency that hears complaints about unfair treatment of workers, on May 19, 2025. The charge was against Llama Productions, a company owned by Epic Games. It said the company's staff had replaced actors' work with AI without telling the union.

**The contract.** The strike ended when 95 percent of the members who voted approved a new contract on July 9, 2025. Before a company makes a digital replica of a performer, it must now get written consent that names what the replica will be used for. It must pay for the replica's use and tell the performer how it is used. During a future strike, performers can stop companies from using their replicas to make new material.

### Faces and voices nobody performed

In *Rogue One* (December 16, 2016), the actor Guy Henry played the character Grand Moff Tarkin. Effects artists then placed a digital copy of the face of Peter Cushing, an actor who had died in 1994, over Henry's face. Lucasfilm staff got permission from Cushing's estate, the people in charge of his property after his death.

**New laws.** Tennessee Governor Bill Lee signed the ELVIS Act on March 21, 2024. Under it, copying a person's voice with AI without permission is against the law in Tennessee.

California Governor Gavin Newsom signed two laws at the actors' union headquarters on September 17, 2024. The first, AB 2602, requires a contract to describe how a digital replica of a living performer will be used. The second, AB 1836, forbids using a digital replica of a dead performer in films, games and recordings without the estate's consent. As of September 2026, members of Congress had not passed a national law, the NO FAKES Act.

**Tilly Norwood.** Eline Van der Velden, whose company made a computer-generated "actress" called Tilly Norwood, said in September 2025 that studios were interested in it and that a talent agency, a company that finds work for actors, would represent it. The leaders of SAG-AFTRA answered in a statement that Tilly Norwood "is not an actor." They said it was made by a computer program "trained on the work of countless professional performers," without their permission or pay.

**Sora 2.** The company OpenAI released its Sora 2 video app on September 30, 2025. Users soon made clips with the face and voice of the actor Bryan Cranston, without his consent. Cranston and the union complained.

OpenAI, the union, Cranston and several talent agencies put out a joint statement on October 20, 2025. It said OpenAI would require a person's permission before the app copies that person. Sam Altman, the head of OpenAI, said the company was "deeply committed to protecting performers from misappropriation," meaning having their faces and voices taken. Cranston said he was "deeply concerned not just for myself, but for all performers whose work and identity can be misused in this way."

**If you remember one thing:** Since 2000 actors' unions have won written rules that a studio or game company must get a performer's consent before it makes or uses a computer copy of that performer.

- June 14, 2013: *The Last of Us* came out, with Troy Baker and Ashley Johnson acting Joel and Ellie on a motion-capture stage.
- December 5, 2023: SAG-AFTRA's members approved the contract that ended their strike, with its rules on digital replicas.
- July 9, 2025: game performers approved a contract that requires written consent and pay for any replica.

**Next:** The chapter closing is below. Chapter 35, Styles, follows it.

**The three questions, answered**

- Who tried to stop Americans from acting, and why? Early on, church leaders and lawmakers tried to stop it, for reasons of religion and morals. Spanish priests burned Pueblo masks to end the ceremonies, and Massachusetts lawmakers banned plays, saying they made people less moral and less religious. Later, police arrested Black actors after a rival white manager, by one account, started a riot to destroy their company, and studio heads blacklisted hundreds of film workers over communism.
- Why did white actors play Black, Asian and Native people for so long? White audiences paid to laugh at blackface from 1828 on, and producers carried the old minstrel parts into film and radio. Because of the studio heads' own Code and state laws against marriage between races, producers kept actors of color out of leading parts.
- Who controls a computer copy of an actor's face and voice? Since the strikes of 2023 and 2024 to 2025, union contracts require a studio or game company to get the performer's consent before it makes or uses one, and the game contract also requires pay. Lawmakers in Tennessee and California passed laws of their own in 2024, and as of September 2026 Congress had passed no national law.

**What changed:** Acting moved from masked dancers in Native ceremonies to stages, screens and games, and the fight moved with it, from who was allowed to act at all to who owns a copy of an actor.

**Five dates to keep**

- April 30, 1598: Spanish soldiers and priests acted the first European play on record here, beside the Rio Grande.
- 1821: William Brown opened the African Theatre in New York, the first known Black theatre company in the United States.
- 1828: Thomas Dartmouth Rice first went on stage as "Jim Crow," in blackface.
- February 8, 1915: *The Birth of a Nation* opened in Los Angeles.
- July 14, 2023: film and television actors began the longest actors' strike against the studios.

**Not known:** The title of that first European play of 1598 is not known, and no copy of its script survives.

**Where to go:** Ford's Theatre in Washington, D.C., where John Wilkes Booth shot President Lincoln in 1865, held its first public performance since that night in 1968.

**Next:** Chapter 35, Styles. It asks who made the rules about Americans' clothes and hair, and who made the cloth they wore.
