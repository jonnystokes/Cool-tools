# Chapter 19: Big Business and Its Power

**Chapter 19 of 37 · Big Business and Its Power · 10 eras · about 95 minutes**

**From the Virginia Company of 1606 to the trillion-dollar companies of 2026, the biggest businesses here kept getting bigger, and at every step people fought over how much power their owners should have.**

Members of a protest group called the Sons of Liberty smashed open 340 chests of tea with axes on December 16, 1773, and dumped the tea into Boston Harbor. The tea belonged to a company, the East India Company of London. British lawmakers had just let the company's agents sell its tea straight to the colonies, more cheaply than colonial merchants could. In February 1774 the company's directors sent a bill for the tea to the British minister in charge of the colonies. It came to 9,659 pounds, 6 shillings and 4 pence.

This chapter describes the biggest companies of each era, from the London investors behind Jamestown to the technology companies in court in 2026. It follows where each company's power came from. At first it came from a government's written permission. Later it came from secret deals with railroads and from buying up rivals until a few owners ran whole industries. People pushed back. Kings and lawmakers took that permission away, workers went on strike, the reporter Ida Tarbell dug through the records, and presidents and judges split companies apart. The owners of some companies made money from shipping enslaved people. Others kept selling leaded gasoline after workers who made its additive died, and cigarettes after studies linked smoking to lung cancer.

**Three questions this chapter answers**

- How did a few companies come to control whole industries?
- What did owners do when their workers went on strike?
- Did breaking up a giant company ever work?

**Five minutes?** Read "Homestead, 1892" in 1850 to 1900.

**Can skip:** "The Hudson's Bay Company, 1670 to 1825", "Who ran the corporations? 1932", "What was a conglomerate?". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 1 minute**

No company existed in this land before 1500, no business owned by a group of people who put money into it and shared what it earned. Starting a corporation, a company that goes on after its first owners are gone, took a written grant from a government.

Native nations traded goods over hundreds of miles, and Chapter 18, Marketplace and Consumer Life, tells that trade. The traders belonged to many different nations, and none of them ran the trade as a company whose owners each held a part of it.

## The 1500s

**Era 2 of 10 · The 1500s · about 1 minute**

Merchants in London started forming joint-stock companies in the 1500s, and later companies of that kind paid for England's first lasting colonies on this coast. Kings and queens paid for the European voyages that reached this coast during that century. No company with a charter, the written grant from a government that creates a company and lists its rights, traded here in those years.

### What was a joint-stock company?

A joint-stock company had many owners at once. Each investor bought shares, parts of the ownership, and got a part of the profit that matched the number of shares he owned. The money the investors paid in was called stock.

The explorer Sebastian Cabot and a group of London merchants formed the Muscovy Company in 1555. It held a monopoly on English trade with Russia, the right to be the only English company trading there. Before it, investors had taken their money back after each voyage. The Muscovy Company was the first English joint-stock company that kept its investors' money in the business from one voyage to the next.

Sir Edward Osborne founded the Levant Company on September 11, 1592, by joining two older companies, the Venice Company and the Turkey Company. Its merchants traded in the eastern Mediterranean Sea, not in North America.

**A charter from the queen.** A nobleman and 218 other men asked Queen Elizabeth I for a charter for a new company. She gave one to the East India Company of London on December 31, 1600.

## The 1600s

**Era 3 of 10 · The 1600s · about 9 minutes**

The first lasting English colonies here were started by companies, and the investors who owned them hoped the colonies would earn them a profit. A king signed each company's charter, investors bought its shares, and the company's officers sent the settlers. The kings who signed the charters gave the companies land where Native nations already lived. Two of those companies lost their charters before the century ended. King James I took the Virginia Company's in 1624, and English judges cancelled the Massachusetts Bay Company's in 1684.

**Companies that traded people.** The owners of other companies made money from enslaved people. The Dutch West India Company owned the enslaved men who dug the trench for a wall at New Amsterdam. The ships of the Royal African Company, chartered in 1672, carried more enslaved Africans to the Americas than those of any other company or group in the history of the slave trade, the historian William Pettigrew found.

### The Virginia Company, a colony run as a business

King James I of England gave the Virginia Company of London a charter in 1606 to start a colony in North America. The company's settlers founded Jamestown on May 13, 1607. They built it inside Tsenacomoco, the land of the Powhatan chiefdom, a group of towns under one leading chief.

**The shares.** A share in the company cost 12 pounds and 10 shillings, at 20 shillings to the pound, and it lasted seven years. By one estimate, the first sale of shares raised as much as 10,000 pounds. In 1616 the company paid its shareholders in land alone.

**Who ran it.** Under a second charter, dated May 23, 1609, the king gave up some of his power over the company, and from then on the investors elected a treasurer to run it. A third charter, dated March 12, 1612, added the island of Bermuda to the company's lands and allowed the company to run lotteries.

The lotteries raised 7,000 pounds of the company's 9,831 pounds in cash in the year before May 1620. Members of the House of Commons, one of the two groups of lawmakers in England's Parliament, attacked the lotteries in a debate in February 1621. King James I banned them soon after.

**The first Africans in Virginia.** The first Africans known to reach English Virginia came in 1619, while the company ran the colony. Earlier that summer the crews of two privateers, ships whose captains had a government's permission to attack and rob enemy ships, had attacked a Portuguese slave ship, the *São João Bautista*, off the coast of Campeche, in what is now Mexico. They seized 50 to 60 Africans from it.

One of the two, the *White Lion*, had sailed from the Netherlands, and its captain, John Colyn Jope, carried Dutch papers giving him that permission. The *White Lion* landed "20. and odd" Africans at Point Comfort in Virginia in late August 1619, in the words of the colonist John Rolfe. Governor George Yeardley and the merchant Abraham Peirsey bought them and paid for them with food.

The other ship, the English *Treasurer*, arrived three or four days later with more of the stolen people. Its owners were Robert Rich, Lord Warwick, a nobleman, and Samuel Argall, Virginia's deputy governor.

**The deaths.** Of the 4,270 people counted in Virginia from 1619 to 1622, only 1,240 were alive at the end. About 700 settlers lived in the colony in 1619. Over the next three years the company's officers shipped 3,570 more men, women and children there.

English settlers had been taking Powhatan land to grow tobacco. An alliance of Virginia Indians led by Opechancanough, the leading chief of the Powhatan, attacked the English settlements on March 22, 1622, and killed as many as 347 colonists. Besides those 347, 2,683 people were gone. One investor asked what had happened to them. Most of them had died of disease, Encyclopedia Virginia's history of the company states.

**The end of the company.** King James I's advisers on the Privy Council, his inner council, named a group of officials in May 1623 to look into the company's business. On May 24, 1624, the king took away the company's charter. From then on Virginia was a royal colony, run by officials the king chose.

### Sir Edwin Sandys

> **Who:** The man who ran the Virginia Company while its officers shipped thousands of settlers to a colony where most of them died.
>
> **When and where:** London, 1619 to 1624.

**Every person shipped to Virginia earned someone 50 acres.**

The investors of the Virginia Company elected Sir Edwin Sandys their treasurer, the man who ran the company, on April 28, 1619. In the next three years most of the people counted in the company's colony died or were killed.

To draw settlers, Sandys and the company's officers used a plan called the headright. They promised 50 acres of land for each person whose trip to Virginia someone paid for. The payer got the land, whether he paid for his own trip or for another person's. The settler then paid the company a quitrent, a small yearly rent on the land, of one shilling a year. The land handed out this way was Powhatan land.

**Who could have stopped it.** The historian Edmund S. Morgan studied these years in a book published in 1975. He and later scholars have shown that a responsible king would have stopped the company from recklessly shipping his people to their deaths, Encyclopedia Virginia's history of the company states. King James I did not stop the shipments while they went on, from 1619 to 1622. He took the company's charter away in 1624.

### The Dutch West India Company

Members of the States General, the lawmaking assembly of the Netherlands, gave the Dutch West India Company a charter on June 3, 1621. For 24 years no one else from the Netherlands could sail to or trade with the Americas. The same rule held for the coast of Africa from the Tropic of Cancer, a line on maps north of the equator, to the Cape of Good Hope, near Africa's southern tip.

**Fort Orange and Manhattan.** Men working for the company built a trading post called Fort Orange in 1624, where Albany, New York, stands today. It was the first lasting Dutch settlement in New Netherland, the colony along the Hudson River. The upper Hudson was the country of the Mohican people.

The company's settlers then moved onto Manhattan Island, the home of the Lenape people. Company officials said they bought Manhattan in 1626 for trade goods worth 60 guilders in Dutch coins. A guide to Lenape history from the Pratt Institute Libraries says the Dutch likely misunderstood what the Lenape meant by that exchange.

**People the company owned.** The company owned people as well as ships and forts. Enslaved men owned by the company dug the trench for a wall at New Amsterdam, the town on Manhattan, in 1653. Three of them are known by name: Paulo d'Angola, Simon Congo and Anthony Portuguese.

The company's director and council had given these three men, eight other men and their wives what the officials called "half-freedom" in 1644, after 18 or 19 years of forced work. The men could own land, but their children stayed the company's property. The men still owed the company a yearly payment of grain or beans and a hog, and they had to work for the company whenever its officials called them.

### The Massachusetts Bay Company

Investors in the Massachusetts Bay Company started the colony of Massachusetts, and the company's leaders governed it under the company's charter. King Charles I signed that charter in March 1629. In late August 1629 twelve men, among them John Winthrop, signed a paper called the Cambridge Agreement. They promised to sail to New England if the company's charter and its government moved there with them.

**Boston.** Winthrop arrived at the Shawmut Peninsula in 1630 with about 1,000 Puritan settlers, English Protestants who wanted to "purify" the king's official church, the Church of England. Winthrop renamed the peninsula Boston.

The land around the peninsula belonged to the Massachusett people, whose leading chief was Chickataubut. About 100,000 people had lived in the region, according to the West End Museum in Boston, and an epidemic, a disease that spread quickly through many people, had killed about 75,000 of them from 1616 to 1618. In 1633 Chickataubut agreed to a treaty with Winthrop, a written agreement that gave up his rights to the peninsula. He died of smallpox that same year.

**The charter cancelled.** English judges cancelled the company's charter on October 23, 1684, for three reasons. Colonists had traded with other countries against English trade laws. The colony's leaders had made their own coins, without the king's picture on them. And the colony's lawmakers had passed laws against members of the Church of England and against Quakers, a Christian group, also called the Society of Friends, that began in England in the 1600s.

### The Hudson's Bay Company, 1670 to 1825

King Charles II gave a charter to the Hudson's Bay Company on May 2, 1670. Prince Rupert, the king's cousin, had persuaded the king and a group of merchants and noblemen to back the company. Under the charter, the company alone could trade in all the lands whose rivers flow into Hudson Bay, in what is now Canada. In the charter those lands are called Rupert's Land.

The Hudson's Bay Company was an English company. Much later, in 1821, it took over the trading posts of its rival, the North West Company, in the Pacific Northwest. The company's governor, George Simpson, and the trader Dr. John McLoughlin opened Fort Vancouver on the Columbia River, in what is now Washington state, on March 19, 1825. Chinookan people had lived along that river for thousands of years. They called the place where the fort stood Skatcutxat, which means "Mud Turtles."

### The Royal African Company

The Royal African Company's investors made money from shipping enslaved Africans to the Americas. King Charles II gave the company a charter in 1672, and his brother James, who held the title Duke of York, led it. James later became King James II. The company held the only English right to trade with West Africa, a trade in gold, silver and enslaved people.

Ships that the company put money into carried 186,748 enslaved people on 652 voyages to English colonies in the Americas between 1672 and 1731. Of those people, 16,077 died on the way. The count comes from the Trans-Atlantic Slave Trade Database, a record of known slave voyages. From 1680 to 1686 the company's ships carried about 5,000 people a year, most of them to English colonies in the Caribbean and to Virginia.

**The brands.** Thousands of the people on the company's ships arrived with the company's initials branded on their chests. To brand a person means to press a red-hot metal stamp against the skin. The heat burns the letters into the flesh and leaves a raised scar for life. Many of the brands read DoY, for Duke of York, the company's leader. Others read RAC, for Royal African Company. The accounts of the branding name the company but not the men who pressed the hot stamps into people's skin.

The historian William Pettigrew wrote in his 2013 book *Freedom's Debt* that the company "shipped more enslaved African women, men and children to the Americas than any other single institution (company or other group) during the entire period of the transatlantic (across the Atlantic) slave trade." He also wrote that its investors knew what the company did and meant to make money from it.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 4 minutes**

The historian Robert E. Wright counts only 8 business corporations chartered in the colonies before independence, so almost no business in the colonies from 1700 to 1750 was a corporation. He writes that before the Revolution, American business corporations were "few, small, and largely inconsequential," which means mostly unimportant. Under British rules, Wright writes, getting a charter cost a lot, and its owners got little in return. So most colonists in business found other ways to organize.

### Partners, and the trade in people

Many colonial businesses were partnerships, in which two or more men put their money together and shared the profits. Under the law of the time, each partner was liable for all of the firm's debts, which meant he could be made to pay them. If the firm failed, the people it owed could make any one partner pay all of it from his own property.

**The trade opened.** The Royal African Company's monopoly ended in practice in 1689, after King James II lost his throne, and the company's own leaders admitted it that year. Under a law that members of the English Parliament passed in 1698, any English merchant could carry enslaved people from Africa. He had to pay the company a fee of 10 percent on the goods he shipped out of Africa. The Royal African Company itself stopped trading in enslaved people in 1731.

**Boston's trade in people.** Boston merchants bought and sold people. The *Boston Gazette*, a newspaper, ran about 2,300 advertisements for about 2,000 enslaved people from 1719 to 1781. Charles Apthorp, a Boston merchant born in Britain, ran a firm that brought in enslaved people and sold them along with other goods. By 1746 he was one of the richest men in Boston.

Apthorp placed advertisements in the *Boston Gazette* in the 1730s and 1740s for "a parcel of likely negros just imported," a group of newly arrived Black people he called healthy, good-looking and fit for work. In 1742 he offered a reward of five pounds for the return of "a negro man named Jack about 35 years old," who had escaped from his enslaver, Stephen Eastwick. Apthorp's business partner was Thomas Hancock, one of the richest merchants in New England.

### Thomas Hancock

> **Who:** The Boston merchant whose firm rented out the ships that carried the Acadians away from their homeland in 1755.
>
> **When and where:** Boston, from about 1724 until his death in 1764.

**His firm's ships, rebuilt like slave ships, carried away Acadian families.**

Thomas Hancock built one of the largest fortunes in New England, and part of his firm's business was carrying people whom British officials had forced from their homes. He started out at 13 or 14 as a bookseller's apprentice in Boston, learning the trade.

**What he traded.** Hancock's ships took codfish, whale oil, logwood (a wood that gives a dye) and potash (a salt made from wood ashes) to other countries. With different partners he made paper. He sold rum and molasses to the crews of the fishing fleet off Newfoundland, and he controlled a group of fishing boats of his own.

**Smuggling.** Under English trade laws, colonial merchants could buy and sell only where the laws allowed. Hancock's ships carried tea and paper from Amsterdam to the West Indies anyway, and when his ships brought French molasses into Boston, he hid it.

**The Acadians.** Hancock's partner Charles Apthorp was a paymaster and agent for the British army and navy, the man who paid out their money, and he supplied goods and money to British forces in Nova Scotia and Boston. In the autumn of 1755 British officials forced the Acadians, French-speaking Catholic farm families, out of Nova Scotia and took their houses and farms. The officials who gave the orders were Governor Charles Lawrence of Nova Scotia and Governor William Shirley of Massachusetts.

Lawrence and Shirley hired about 24 sailing ships from the firm of Apthorp and Hancock to carry the Acadians away. The partners charged 40 to 48 pounds a month for each ship, and the governors also paid a fixed fee for each person carried. In Boston the ships were rebuilt inside to hold two people for every ton of cargo the ship could carry, and some held 300 to 500 people. The historian Mark Peterson writes that they were "fitted out in the manner of slave ships."

The ships carried the Acadians to British colonies along the Atlantic coast, among them Maryland and South Carolina. The ships were in poor condition. On board, Acadians went without enough food, caught diseases and died. The ships carried no passenger lists, so no record shows which Acadians died at sea or how many.

Hancock made his nephew, John Hancock, his equal partner in 1763. Thomas Hancock died of a stroke on August 1, 1764, as he entered the council chamber in Boston. He left property and money worth about 70,000 pounds.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 6 minutes**

Colonists in Boston destroyed tea in 1773 that belonged to the East India Company of London. British lawmakers had just given that company the right to sell its tea straight to the colonies. After independence, American lawmakers began chartering companies of their own.

**Charters at home.** Most of the new charters went to banks and to insurance companies, which took a regular fee from people and paid them back after a loss such as a fire. Others went to companies that piped water to towns or built canals, bridges and toll roads, roads that people paid a fee to use.

Robert E. Wright counts 319 business corporations chartered in the United States before 1801. Only 8 of them came from the colonial years and 21 from 1776 to 1789. The other 290 were chartered from 1790 to 1800.

### Whose tea went into Boston Harbor?

The tea belonged to the East India Company of London, the company chartered in 1600. The company held about 17 million pounds of tea, by weight, that it could not sell. Members of the British Parliament passed the Tea Act on May 10, 1773. Under it, the company could ship tea straight to the American colonies, and its own agents could sell the tea there at a lower price.

The Act contained no new tax. The tax on tea that members of Parliament had set in 1767 still had to be paid on the company's tea. But the company's agents could sell tea more cheaply than colonial merchants could, so the merchants who sold tea in the colonies lost business.

**The three ships.** Ships carrying the company's tea reached Boston in late 1773. Thomas Hutchinson, the royal governor of Massachusetts, refused to let the three ships, the *Beaver*, the *Dartmouth* and the *Eleanor*, leave the harbor until they had unloaded.

On December 16, 1773, members of the Sons of Liberty, a protest group, boarded the ships. Some of them were dressed as Mohawk men. They dumped all of the tea into the harbor, more than 92,000 pounds of it, about 46 tons. The company's directors later asked the British government to pay them back for it.

### Americans start chartering companies

Robert Morris planned the first commercial bank in the United States, the Bank of North America, a bank that kept people's money safe and lent money to merchants and businesses. Members of the Continental Congress, the leaders from the 13 states who ran the country during the Revolution, approved his plan on May 26, 1781. They granted the bank its charter on December 31, 1781, and it opened on Chestnut Street in Philadelphia on January 7, 1782.

Morris started the bank with a shipment of French silver worth $450,000 that had been sent to Congress, and the bank's officers then lent the money back to Congress. Ninety-nine Philadelphians and members of Congress bought shares.

**A fight over the charter.** Pennsylvania's lawmakers gave the bank a second charter of their own in 1782. In March 1785 they received petitions, written requests signed by many people, asking them to cancel it. The bank's critics said its officers favored their friends, charged too much interest on loans and had too much power over trade and politics. They pointed to the 14 percent dividends, shares of the profits, that the bank paid its shareholders.

The lawmaker William Findley called the bank "a monopoly." That September the lawmakers voted to cancel the charter. In 1787 they gave the bank a narrower charter that lasted 14 years. Under it the bank's capital, the money its owners put in, could be no more than $2 million, and the bank could own no property beyond what its business needed.

**Toll bridges.** Only 7 of the 319 corporations that Wright counts before 1801 were for making goods. Lawmakers in the Northeast chartered 59 private companies to build toll bridges from 1786 to 1798. The first was the Charles River Bridge in Boston, and in its first six years its investors earned an average of 10.5 percent a year on their money.

**What a charter cost.** Getting a charter cost money. Wright found that people who wanted one paid for signatures and for help getting a bill passed by the lawmakers. Some paid lobbyists, people hired to persuade lawmakers, and some paid bribes.

**How much an owner could lose.** In a corporation, each owner risks the money he paid for his shares. Under a rule called limited liability, owners cannot also be made to pay the company's debts from their own property. The historians Oscar and Mary Handlin found only 16 early charters that spelled out that promise. Wright argues that owners' risk was limited anyway, because a company could not charge its shareholders more than the price of their shares.

### Robert Morris

> **Who:** The merchant who ran the country's finances near the end of the Revolution, then went to a debtors' prison owing nearly $3 million.
>
> **When and where:** Philadelphia, 1781 to 1801. Born 1734, died 1806.

**When he left prison, he owed $2,948,711.11.**

As Superintendent of Finance, the official in charge of the Continental Congress's money, Robert Morris wrote the charter of the Bank of North America. He used the bank to keep the value of the country's money steady and to keep the national government from running out of money.

After the war, Morris bought land with borrowed money. Starting in 1793, he and his partners, among them John Nicholson, bought thousands of building lots in the new District of Columbia. They also bought millions of acres in Pennsylvania, New York, Kentucky, Virginia, Georgia and the Carolinas.

**Seneca land.** Morris's land in western New York was Seneca land. His son Thomas Morris and his agent Charles Williamson met Seneca leaders at Geneseo, New York, from August 20 to September 16, 1797. Nearly 3,000 people came from the Seneca and the other nations of the Haudenosaunee, the union of six Native nations to which the Seneca belong.

The Seneca leaders at Geneseo included Cornplanter, Red Jacket and Handsome Lake, along with the clan mothers, the women leaders who choose their clan's chiefs and can remove a chief who acts badly. At this meeting the Seneca leaders signed the Treaty of Big Tree. They gave up almost all of their remaining land in New York, nearly 3.5 million acres, and kept 12 small pieces.

Morris paid $100,000. Federal officials held the money and put it into shares of the Bank of the United States, which paid the Seneca up to $6,000 a year. Morris asked that the $100,000 go back to his own heirs, the family members who would inherit from him, if the Seneca nation should "become extinct," meaning if every Seneca died. The heads of the federal Treasury and State departments refused. Most of the land went on to the Holland Land Company.

**Prison.** Morris and Nicholson together owed their creditors, the people they had borrowed from, about $12 million by 1797. Officers arrested Morris at his home in February 1798 and took him to the Prune Street debtors' apartment, next to the Walnut Street Prison in Philadelphia. He was held there about three and a half years because he could not pay his debts.

Members of Congress passed a bankruptcy law in 1800. Under it, a court could divide what a person owned among the people he owed and free him from the rest of the debt. Accounts differ about whether Morris's time in prison helped get that law passed. He was released under it in 1801. The three officials who handled his case found that he himself owed $2,948,711.11.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 9 minutes**

State lawmakers chartered thousands of corporations, companies the law treats as one body, in the first half of the 1800s, and the fights over them reached the Supreme Court and the president. At the start of the century the lawmakers had to pass a special law for each charter. The justices of the Supreme Court ruled in 1819 that a state's lawmakers could not change a charter they had already granted. By 1837 a Connecticut law let people start a corporation for any lawful business by following set steps.

**The mills and the bank.** Merchants in Boston used corporations to build cotton mills, and by 1850 their group controlled a fifth of the country's cotton cloth making. In the 1830s President Andrew Jackson fought the Second Bank of the United States, one of the largest companies in the country, and its federal charter ran out in 1836.

### From special charter to general law

A group that wanted a corporation before 1811 had to ask lawmakers to pass a special law just for them. New York's lawmakers changed that on March 22, 1811, when they passed the country's first general incorporation law, a law that let any group form a corporation by following set steps, without a special vote.

Under the New York law, only makers of goods could form such a company: makers of goods of wool, cotton or linen, and of iron, steel, copper, lead and similar metals. Any five or more people could form one. Its charter lasted 20 years, and it could raise no more than $100,000.

**An emergency law.** The historian Seavoy called the law "essentially an emergency measure" in a 1972 article in the *Business History Review*. Under two federal laws that banned trade, the Embargo of 1807 and the Non-Intercourse Act of 1809, cloth from Europe had stopped coming in. New York's lawmakers wanted thread made at home so that families could weave their own cloth.

Connecticut's lawmakers went further in 1837. Their new law let people incorporate, or form a corporation, for "any other lawful business." It was the first such law that did not list which trades were allowed or set a time limit on the corporation's life. Banks still needed a special act.

**Who was shut out.** Lawmakers in some Southern states shut particular groups out of their general incorporation laws, most often people who were not white. In those states, the economic historian Eric Hilt found, a Black American could not form a corporation under the general law.

**How many.** State lawmakers created 22,419 business corporations by special laws, one charter at a time, from 1790 to 1860, by the count of the economic historians Richard Sylla and Robert E. Wright. That is about 70 times the 319 corporations chartered before 1801. Together their charters allowed their owners to raise at least $4.5 billion. Several thousand more corporations formed under general laws.

### Could lawmakers take back a charter? The Dartmouth case, 1819

The justices of the Supreme Court ruled in 1819 that a charter is a contract, and that a state's lawmakers cannot change it at will. The case was about a college's charter, but business corporations could rely on the same rule to protect their own.

**The case.** King George III had granted Dartmouth College its charter in 1769. The college's trustees, the board that ran it, removed its president, John Wheelock, in 1815. Wheelock then persuaded the governor of New Hampshire to change the charter, and in 1816 the state's lawmakers rewrote it. Under the new charter the governor chose trustees and a state board could overrule them. The lawmakers also renamed the college Dartmouth University.

The old trustees sued William Woodward, who served as secretary under the new plan. Daniel Webster argued the trustees' case before the Supreme Court. "It is, sir, as I have said, a small college, and yet there are those who love it!" he said. Chief Justice John Marshall wrote the Court's decision and ruled that the 1769 charter was a contract. The Constitution states that no state may pass a law "impairing," or weakening, "the obligation of contracts," and New Hampshire's lawmakers had broken that rule.

**The way around it.** After the ruling, state lawmakers could not take back a charter that earlier lawmakers had granted. Justice Joseph Story, in his own written opinion in the case, pointed to a way around this. Lawmakers could write into a charter, at the start, a power "to alter, modify, or repeal" it, which means to change it or cancel it. State lawmakers began writing such lines into new charters.

Dartmouth College's own history of the case describes it as a basis for the Constitution's protection of corporations. Supreme Court justices still cite it, as they did in *Citizens United v. FEC*, a 2010 case about money spent on elections, and in *Burwell v. Hobby Lobby*.

### The Boston Associates and the mills

A group of Boston merchants, known today as the Boston Associates, built cotton mills with far more money behind them than their rivals had. By 1850, the National Park Service counts, they controlled a fifth of the country's cotton cloth making.

Francis Cabot Lowell, Patrick Tracy Jackson and Nathan Appleton organized the Boston Manufacturing Company in 1813. It started with $400,000 in capital, the money its owners put in, more than ten times the money behind the average cotton mill in Rhode Island. By 1820 the owners had put in $200,000 more.

**Waltham.** They built a mill at Waltham, on the Charles River, in 1814. It was the first mill in the world to spin cotton into thread and weave it into cloth under one roof, so every step from raw cotton to finished cloth happened in one building.

Within six years the mill ran 5,376 spindles, the rods that twist cotton fibers into thread, and 175 power looms, weaving machines driven by water power. A typical Rhode Island mill ran fewer than 1,000 spindles. The Waltham mill used 450,000 pounds of cotton a year, and by 1820 it used all the power the Charles River could give.

**Lowell.** The same investors then built mills at Pawtucket Falls, on the Merrimack River. The falls were a fishing place of the Pennacook people, and in the 1600s two Pennacook towns stood there, under the leaders Passaconaway and his son Wannalancet.

**What happened to the Pennacook.** Native nations fought the English colonies of New England in 1675 and 1676, and Wannalancet kept peace with the English. In 1676 he led about 400 people from the nations allied with him to make peace with an English captain, Richard Waldron. Waldron took them all prisoner.

Officials in Boston hanged seven or eight of the prisoners, and about 200 were enslaved for life and shipped to Barbados. Wannalancet, whom Waldron let go, moved north to Canada with his people. Chapter 14, Work and Workers, tells this in full.

The mill village became a town named Lowell on March 1, 1826. It had 2,500 people that year and 6,477 in 1830.

**Whose cotton.** Enslaved people in the South grew the cotton the mills spun. The mills also made a cheap cloth, which people at the time called "negro cloth," that planters bought to clothe the people they enslaved. Senator Charles Sumner of Massachusetts called the tie between the mill owners and the slaveholders an "unholy union" between the lords of the loom and the lords of the lash, or whip.

### Nicholas Biddle

> **Who:** The head of the Second Bank of the United States, one of the largest companies in the country, who cut off its loans in his fight with President Andrew Jackson.
>
> **When and where:** Philadelphia, from 1822 or 1823 to 1839.

**He cut off loans, hoping people would blame Jackson.**

Nicholas Biddle became president of the Second Bank of the United States in 1822 or 1823. The Federal Reserve's own history of the bank describes it as "one of the largest U.S. corporations." Its charter, which President James Madison signed into law on April 10, 1816, ran for 20 years, and the bank opened in Philadelphia in January 1817.

The bank had $35 million in capital, three and a half times the $10 million of the first national bank. The federal government owned a fifth of its stock, and the president chose 5 of its 25 directors, the board that ran it. By the end of the 1820s the bank had at least 25 branches and did about $70 million of business a year.

The Federal Reserve's history states that Biddle "was not above allowing the Bank to make loans to his friends while denying loans to those less friendly."

**The fight with Jackson.** Andrew Jackson, president from 1829, called the bank unconstitutional, or against the Constitution, and corrupt. Both houses of Congress voted to renew its charter early, in 1832, 28 to 20 in the Senate and 107 to 85 in the House, and Jackson vetoed the bill, refusing to sign it. Chapter 17 tells that fight in full.

After Jackson won a second term, he ordered the government's money moved out of the bank and into banks chartered by the states, and by late 1833 most of it was gone.

**Biddle's answer.** Biddle cut the bank's lending and called in loans, telling borrowers to pay back what they owed. He believed that a shortage of credit, money to borrow, might turn people against Jackson. In April 1834 a majority of the House of Representatives voted against renewing the charter.

The federal charter ran out in 1836, and Pennsylvania's lawmakers chartered the bank again as a state bank. In 1839 the bank's officers suspended payment: they stopped handing out coins to people who brought in its paper notes. Biddle resigned that year.

**What the stockholders found.** The bank's stockholders, the people who owned its shares, chose a committee in 1841 to look into its books. The committee members reported that Biddle had used the bank's money to buy cotton, tobacco and other crops and ship them to Europe. The bank closed for good on April 4, 1841.

**Charged with a crime.** A grand jury, a group of citizens who decide whether there is enough proof for a trial, charged Biddle and two other bank officers with a crime on December 10, 1841. The charge stated that the three men had cheated the stockholders out of $400,000 in 1836 and had tried to cover it up with false records in 1841. Biddle was arrested. Judges later dropped the charges.

Biddle paid the bank's creditors, the people it owed money, with what was left of his own fortune. He faced lawsuits until he died in 1844. In one of them he was sued for nearly $25 million.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 17 minutes**

A few companies came to control whole industries between 1850 and 1900. One railroad, the Pennsylvania, had more capital in 1880 than the federal government took in that whole year. John D. Rockefeller's Standard Oil refined 90 to 95 percent of the country's oil by 1880, and by 1895 one company controlled about 98 percent of the country's sugar refining.

**Rules and soldiers.** Members of Congress wrote the first federal rules for big business in these years, and federal lawyers used one of them against striking railroad workers. When workers struck, owners and officials answered with armed guards, court orders and soldiers.

### How big was the biggest railroad?

The largest corporation in the country in 1880 was a railroad, the Pennsylvania. That year it had 30,000 workers and $400 million in capital, and it carried 10 percent of all the freight in the United States and 20 percent of the passengers. Federal officials collected about $334 million in all in the year that ended on June 30, 1880, less than the railroad's capital. By 1882 the Pennsylvania was the largest corporation in the world.

**Free land.** Federal and state officials also gave the railroads land grants, gifts of land from a government. Federal officials granted about 130 million acres to railroad companies from 1850 to 1871, and state lawmakers granted about 51 million acres more. The Illinois Central got the first federal grant in 1851, under a law passed the year before: nearly 2.6 million of the law's 3.75 million acres.

**Whose land.** The granted land came from land that federal officials had taken, or were taking, from Native nations. The Pacific Railroad Act of July 1, 1862, states: "The United States shall extinguish as rapidly as may be the Indian titles to all lands falling under the operation of this act." In that law, members of Congress told federal officials to end the Native nations' rights to the land along the railroad as fast as they could.

### John D. Rockefeller

> **Who:** The Cleveland businessman who built Standard Oil and set up the first large trust.
>
> **When and where:** Cleveland and New York, 1870 to 1911.
>
> **Movie:** *The Men Who Built America* (2012), a History Channel series about Rockefeller, Carnegie, J. P. Morgan and others. It is a docudrama: actors play the real people in scripted scenes.

**"Take Standard Oil Stock, and your family will never know want."**

John D. Rockefeller used secret deals with the railroads to take over nearly all of the country's oil refining, the work of cleaning crude oil from the ground and separating it into products that people can use.

Rockefeller formed the Standard Oil Company in Ohio on January 10, 1870, with his brother William Rockefeller, Henry M. Flagler and two other partners. The company had $1,000,000 in capital. Its refineries in Cleveland could handle about 1,500 barrels of crude oil a day, out of about 10,000 to 12,000 barrels a day for all the refineries in Cleveland together.

**The secret deal.** Thomas A. Scott of the Pennsylvania Railroad set up the South Improvement Company late in 1871, a secret deal between a few refiners and the railroads. Rockefeller and his partners controlled 900 of its 2,000 shares. Under the deal, the railroads would charge $2.56 a barrel to carry crude oil to New York, and members would get back $1.06 on every barrel they shipped. That payment was called a rebate.

Members would also get $1.06 in cash on every barrel that their rivals shipped, a payment called a drawback. A rival refiner would pay the full price, and part of what he paid would go to his own competitors.

Oil producers in western Pennsylvania learned of the plan and fought it. They organized, raided the shipments of the scheme's members and asked Pennsylvania's lawmakers and Congress for help. Pennsylvania officials suspended the South Improvement Company's charter on April 2, 1872, and the company never shipped any oil.

**The Cleveland buyout.** While the scheme stood, in early 1872, Rockefeller bought out at least 21 of the 26 refiners in Cleveland within three months. One refiner later testified that "our establishment was worth $150,000, and we sold it for about $65,000," about forty or forty-five cents for each dollar his business was worth. Rockefeller told the sellers, "Take Standard Oil Stock, and your family will never know want," meaning they would never be poor.

In those months Standard Oil went from refining about 1,500 barrels a day to 10,000. Ida Tarbell, a reporter who later wrote a history of Standard Oil, found that it then held more than a fifth of the country's refining capacity. Rockefeller kept buying out rivals and making deals with railroads for lower rates. By 1880 Standard Oil refined 90 to 95 percent of all the oil produced in the United States.

### What a trust was

A trust was a way to run many companies as one business, with one small group in charge, and the Standard Oil Trust was the first large one. More than 40 people who owned shares in Standard Oil signed the Standard Oil Trust Agreement on January 2, 1882.

They handed over their shares in about 40 companies to nine trustees, people who hold and manage property for others. Rockefeller was one of the nine, and the nine trustees themselves owned most of the stock. The trust was valued at about $70 million. In time the trustees ran some 40 corporations, 14 of them fully owned.

Owners in other industries copied the plan, and laws against such combinations of companies are still called antitrust laws.

**The Ohio ruling.** The justices of the Ohio Supreme Court ruled in 1892 that the Standard Oil Trust was a monopoly, a business with no real rivals, and that it broke Ohio law. Rockefeller moved the property to companies in other states. Ida Tarbell later wrote of the trust, "You could argue its existence from its effects, but you could not prove it." She meant that people could see what the trust did, but they could not prove it existed.

**Tobacco and sugar.** James B. Duke had gone into the cigarette business in 1881. He leased new machines that rolled cigarettes, advertised heavily and bought up smaller rivals. On January 31, 1890, Duke and the owners of four other firms joined their businesses into one, the American Tobacco Company, the largest tobacco business in the world. Duke's own firm was W. Duke, Sons and Company of Durham, North Carolina. In sugar, the American Sugar Refining Company controlled about 98 percent of the country's sugar refining by 1895.

### Franklin Tarbell

> **Who:** An oil producer who fought Standard Oil from 1872 into the 1890s, and the father of the reporter Ida Tarbell.
>
> **When and where:** Oil Creek and Titusville, Pennsylvania, from 1859 until his death in 1905.

**He and scores of other producers pledged not to sell to Standard Oil.**

Franklin Tarbell fought Standard Oil for twenty years, and in 1893 he had to mortgage his family's home to pay a ruined partner's debts. His daughter, the reporter Ida Tarbell, told his story in her memoir, published in 1939.

**Tanks.** Tarbell was on his way home to Iowa in 1859 when he heard about the oil well at Titusville, Pennsylvania. He guessed that oil men would need tanks to hold their oil, and he believed he could build a wooden one that held 500 barrels or more. He was told, "Show me a model that won't leak, and I'll give you an order." He made the model, got the order and built the first large round wooden tank on Oil Creek. For ten years he built tanks.

He began to produce oil himself in 1867, on farms near Rouseville, and in 1870 he moved his family into a new house he had built in Titusville. Ida was thirteen.

**The pledge.** The oil producers learned of the South Improvement scheme in 1872. Ida remembered her father coming home one night with a grim look on his face. He told the family that he and scores of other producers had signed a pledge not to sell oil to Standard Oil, the one company that had gained from the scheme. Ida, fifteen that year, later wrote that in 1872 "there was born in me a hatred of privilege, privilege of any sort."

**Twenty years.** The fight between the independent producers and Standard Oil went on for twenty years. The producers waited for slow decisions from the Interstate Commerce Commission, the federal board set up in 1887 to watch over the railroads, and some of their businesses failed while they waited.

One of Franklin Tarbell's business partners lost everything in this fight and shot himself between 1891 and 1893, while Ida was living in Paris. Ida's memoir does not state the man's name. The partner left Franklin Tarbell owing money on notes, written promises to repay loans. To pay them, during the money panic of 1893, he mortgaged the family's home: he borrowed money and pledged the house, which the lender could take if the loan was not repaid.

**His warning.** Ida Tarbell later spent most of five years investigating Standard Oil. Her father warned her that Rockefeller and Standard Oil could crush her, just as, in his view, they had crushed her home town of Titusville, a 2012 account in *Smithsonian* magazine says. Franklin Tarbell died in Titusville on March 1, 1905.

### Andrew Carnegie

> **Who:** The Pittsburgh steelmaker whose company owned every step of making steel, and whose manager broke the union at Homestead.
>
> **When and where:** Pittsburgh, until he sold his company in 1901.
>
> **Movie:** *Andrew Carnegie: The Richest Man in the World*, an American Experience documentary shown on PBS on January 20, 1997.

**One company owned the coke, the ore, the ships and the railroad.**

Andrew Carnegie cut his costs and raised his profits by owning every step of making steel. That way of running a business is called vertical integration: one company owns each stage of making a product, from the raw material to the finished goods.

**Coke and ore.** Carnegie already owned 73.5 percent of Henry Clay Frick's coke company by 1888. The company made coke, a fuel baked from coal that steel makers burn to melt iron ore. Carnegie leased newly found iron ore deposits in the Mesabi Range of Minnesota in the 1890s. The name Mesabi comes from the Ojibwe name for the range, Misaabe Wajiw, which means Big Man Mountain.

**Ojibwe land.** The Mesabi Range was Ojibwe country. Ojibwe bands gave up northeastern Minnesota to the United States in a treaty of 1854. Federal officials wanted a vein of copper there, on the north shore of Lake Superior. In a treaty of 1855 Ojibwe bands gave up most of north-central Minnesota, where federal officials wanted land for logging and mining.

**Ships and a railroad.** Carnegie bought ships on the Great Lakes to carry his ore, and he bought a railroad and extended it to link his steel works to Lake Erie. He no longer had to buy coke, ore or shipping from other companies, and that cut his costs. Carnegie Steel was the largest steel maker in the world by the end of the 1890s, and it made a quarter of all the steel produced in the United States. In 1900 it earned $40 million in profits.

**Homestead.** Carnegie was in Scotland in the summer of 1892. In the words of the encyclopedia Britannica, he gave his general manager, Henry Clay Frick, "carte blanche," or full freedom, "to break the union" at the Homestead works.

**By 1892:** Standard Oil had refined 90 to 95 percent of the country's oil as early as 1880. The American Tobacco Company was the largest tobacco business in the world, and Andrew Carnegie owned most of Henry Clay Frick's coke company.

### Homestead, 1892

Henry Clay Frick broke the steelworkers' union at the Homestead works near Pittsburgh in 1892 with a fence, a lockout and about 300 armed Pinkerton men. Frick was the general manager of Carnegie Steel. That year he became its chairman, and he owned 11 percent of it. The union was the Amalgamated Association of Iron and Steel Workers, and its contract ran out on July 1, 1892.

**The lockout.** Frick cut wages and had a fence built around the plant, topped with barbed wire, which the workers called "Fort Frick." In late June he locked the workers out, closing the plant to them. On July 2 he fired all 3,800 workers.

**The Pinkertons.** Frick signed a contract with William and Robert Pinkerton, who ran the Pinkerton National Detective Agency, for 300 armed men at five dollars a day for each man. Agency officials gathered 316 men in New York and Chicago. Some were Pinkerton regulars. Others had no jobs, some were criminals on the run, and a few were college students earning money for the summer. Their crates held 250 Winchester rifles and 300 pistols.

Early on July 6, 1892, tugboats towed two barges carrying the men up the Monongahela River to the plant. Dawn was breaking when the barges reached the riverbank, where about 10,000 people were waiting, by the count of the historian Leon Wolff. When the Pinkerton men tried to come ashore, shooting broke out on both sides. No one knows who fired the first shot.

**The surrender.** The gun battle went on all day. Strikers threw dynamite at the barges and sent a burning raft toward them. By late afternoon the Pinkerton men had agreed to surrender, and the crowd beat them as they walked up to the town.

**The dead.** Counts of the dead differ. The encyclopedia Britannica lists at least 7 workers and 3 Pinkerton men killed in the battle and the days after it. Wolff counts about 9 strikers and 7 Pinkerton men dead from bullets, beatings, drowning and suicide.

Wolff writes that about 40 strikers and 20 Pinkerton men were shot, and he names some of the dead. A Pinkerton guard named Klein died on the gangplank, shot through the head. Joseph Sotak went to help a wounded worker, Martin Murray, and was shot in the mouth and killed. A worker named Streigle was shot through the throat and died at once. Neither Wolff nor Britannica names the men who fired the shots that killed them.

**The soldiers.** After the battle, Frick asked Governor Robert Pattison of Pennsylvania for help. Pattison sent about 8,500 soldiers of the state National Guard, and they took over the plant on July 12. By July 15 Carnegie Steel's managers had the plant running again with replacement workers.

Many of the replacement workers were Black men from the South, and the union did not let Black workers join it. In November 1892 about 2,000 white workers attacked Black workers and their families, and gunfire badly wounded several people. The accounts do not say who fired. The union gave up on November 21. By then, Wolff counts, 35 men had died from the battle and the violence that followed.

**After the strike.** Officials charged scores of union leaders and workers with crimes, and almost all of them were found not guilty. Carnegie Steel's managers cut wages in all of Carnegie's mills by about half. A heater's helper, one of the workers who heated the steel, was paid by the ton of steel: he earned 4.85 cents a ton in February 1892 and 2.22 cents a ton in February 1894. The managers enforced the twelve-hour workday.

Employers blacklisted the members of the union's advisory committee for life, putting them on a list of workers the employers agreed never to hire. Members of Congress investigated the use of private armed guards at Homestead, and Frick testified before them.

### John W. Holway

> **Who:** A 23-year-old medical student hired as a Pinkerton guard for the Homestead job.
>
> **When and where:** Chicago to Homestead, Pennsylvania, July 1892.
>
> **Movie:** *The River Ran Red* (1993), a documentary about the Homestead lockout, directed by Steffi Domike and Nicole Fauteux. It tells the story from the workers' side.

**The agency promised "the element of danger" would be "entirely lacking."**

John W. Holway was hired to guard the Homestead works, and a crowd there kicked him and beat him with stones. He was studying to be a doctor and was one of the college students who signed up with the Pinkerton agency for summer work at five dollars a day.

**The train.** The man in charge of the agency's Chicago office would not tell the men where they were going. "The element of danger which is usually found in such expeditions will be here entirely lacking," he told them.

After dark, agency men put Holway and the other Chicago men on a train at the Lake Shore depot. Pinkerton detectives stood guard to stop anyone from getting off, even at the stops in Toledo and Cleveland. The thought struck Holway, Wolff writes, that he was "a sort of prisoner," and he had a feeling that there would be shooting.

**The barges.** Holway was on the barges at Homestead on July 6. According to Wolff, he does not seem to have fired a shot all day. On the walk up to the town after the surrender, three strikers knocked Holway down, and one of them said, "You have killed two men this morning. I saw you!" As they pushed him up the hill, a stone hit him in the head.

Holway told the congressional committee under oath what happened next. He ran about half a mile, but he was weak and had had nothing to eat or drink, and his legs gave out. A man grabbed him by the back of his coat. Then, in Holway's words, "about 20 or 30 men came up and kicked me and pounded me with stones."

"I thought I was about going," he said, meaning about to die, "and commenced to scream." Two or three strikers with rifles then ran up and kept the crowd off him.

### The first federal rules, and how they were used

Members of Congress passed the first federal laws to control big business in 1887 and 1890. In the 1890s the justices of the Supreme Court let the sugar trust stand, and federal officials used the second law to break a railroad strike.

**The railroads.** The Interstate Commerce Act, which set rules for interstate commerce, or trade between the states, became law on February 4, 1887. Under the Act, the five members of a new board, the Interstate Commerce Commission, watched over the railroads. The railroads became the first industry under federal regulation, rules made and enforced by the national government, and the commission was the first federal board of its kind.

**The Sherman Act.** The Sherman Antitrust Act, named for Senator John Sherman of Ohio, became law on July 2, 1890. Under it, every contract or combination "in restraint of trade" became illegal, meaning any deal that blocks free buying and selling between the states. Trying to monopolize, or to become the only seller of something, also became a crime.

A person found guilty could be fined $5,000 and sent to jail for a year, and people harmed could sue for three times their losses. The law did not define the words "trust," "combination," "conspiracy" or "monopoly."

**The sugar case.** The justices of the Supreme Court ruled on the sugar trust in 1895, in *United States v. E. C. Knight Co.* The American Sugar Refining Company controlled about 98 percent of all sugar refining in the United States, and the justices ruled that it had not broken the law. They reasoned that making sugar was manufacturing, and that manufacturing was not trade.

**Pullman.** The Pullman Palace Car Company ran sleeping cars, railroad cars with beds, on trains across the country. Its managers laid off more than 2,000 workers and cut wages by 25 percent in 1893, during a depression, a long time when many businesses fail and many people lose their jobs. The company owned the town where its workers lived, and its managers did not lower the rents. Company president George M. Pullman refused to meet the workers' representatives.

Railroad workers in 27 states, between 125,000 and 250,000 of them, joined a boycott of Pullman cars in 1894, refusing to handle trains that carried them. That year federal officials used the Sherman Act against the workers. A special lawyer working for the US attorney general claimed in court that the strike broke the Sherman Act.

**The court order.** On July 2, 1894, two federal judges granted the government's lawyer an injunction, a court order that tells people to stop doing something and lets judges jail anyone who breaks it. President Grover Cleveland used the injunction as his reason to send federal troops. The soldiers arrested boycotters and rioters and sometimes shot them, according to the Federal Judicial Center's history of the case.

About 30 people were killed across the country during the strike, and the histories of it do not say who killed each of them.

**If you remember one thing:** Between 1850 and 1900 a few owners took control of whole industries, and when workers struck, a governor and a president sent soldiers against them.

- 1882: Standard Oil's owners sign the first large trust agreement.
- 1890: Under the new Sherman Antitrust Act, deals "in restraint of trade" become illegal.
- 1892: Frick's Pinkerton men and the Homestead steelworkers fight a gun battle.

**Next:** After 1900 bankers joined hundreds of firms into giant corporations, and two presidents had their lawyers sue to break up the biggest.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 15 minutes**

The biggest companies the country had yet seen took shape in these years, and presidents and judges began to break some of them apart. Between 1895 and 1904 owners and bankers joined more than 1,800 manufacturing firms into 157 large corporations. The largest, US Steel, issued more than a billion dollars in stock, shares sold to investors, in 1901.

**Breakups and new rules.** Presidents Theodore Roosevelt and William Howard Taft had their lawyers sue the biggest combinations. In 1911 the justices of the Supreme Court ruled that Standard Oil and the American Tobacco Company had broken the law, and under court orders both were split apart. Members of Congress passed two more antitrust laws in 1914. In 1934, after the stock market crash of 1929, they passed a law that required companies selling stock to report their finances to the public.

Soldiers of the Colorado National Guard, whose costs the mine owners paid, burned a strikers' tent camp at Ludlow in 1914, and Chicago police killed 10 people during a steel strike in 1937. During the Second World War, federal officials gave about two-thirds of the value of their main war contracts to 100 companies.

### The great merger movement and US Steel

The 157 large combinations of 1895 to 1904 were mergers, in which two or more companies join into one, and more than 60 of them formed in 1899 alone.

Naomi Lamoreaux names the causes in her book *The Great Merger Movement in American Business*. Factories cost a great deal to build, and industries grew fast after 1887. After the depression of 1893 began, rival owners cut their prices against each other in price wars. The owners had made agreements, called pools, to hold prices up, but the price wars went on anyway.

Lamoreaux writes that "there was nothing natural or inevitable," nothing certain to happen, about these combinations. Most of them used more money and work to make the same goods than the new rivals that soon appeared, and in her words they "quickly lost their positions of market dominance," their lead in their markets. The firms that built barriers against rivals, such as US Steel through its control of iron ore, kept their lead longer.

**US Steel.** The banker J. P. Morgan put US Steel together as a corporation in New Jersey in February 1901. He bought Carnegie Steel for Andrew Carnegie's asking price of $480 million. Other companies went in with it, among them makers of steel, pipe and bridges and the Lake Superior Consolidated Iron Mines, whose ore came from Ojibwe land in Minnesota. Charles M. Schwab was president from 1901 to 1903, and Elbert H. Gary was chairman from 1901 to 1927.

**A billion dollars in stock.** US Steel was the first company in the world with more than a billion dollars in stock. It issued stock with a stated value of about $1.4 billion.

Government investigators at the federal Bureau of Corporations put the real value of what the company owned at about $682 million, about half the stock issued. So about half of the stock was watered stock, stock issued for more than the property behind it.

**Two-thirds of the steel.** US Steel made about two-thirds of all the steel in the United States at the start. In 1902 the company employed 168,000 people. By 1911 its share had fallen to less than half.

### J.P. Morgan

> **Who:** The Wall Street banker who joined rival companies into giant ones, among them US Steel in 1901.
>
> **When and where:** New York, 1901 to 1904.

**Carnegie named $480 million. Morgan said yes at once.**

J. P. Morgan, a banker on Wall Street in New York City, led a wave of mergers around 1900, joining rival companies into single giant ones.

**The steel deal.** Charles M. Schwab, then president of Carnegie Steel, gave a speech at the University Club in December 1900, and the speech led Morgan to the steel deal. Carnegie named a price of $480 million for his company, and Morgan accepted it at once. Morgan then formed US Steel in 1901 and sat on its finance committee.

**Northern Securities.** Morgan and the railroad owner James J. Hill also formed the Northern Securities Company in 1901. It was a holding company, a company that owns controlling shares in other companies and does little else. Through it they controlled three railroads: the Great Northern, the Northern Pacific, and the Chicago, Burlington and Quincy. President Theodore Roosevelt's Justice Department lawyers sued to break it up in 1902.

### Ida Tarbell

> **Who:** The reporter whose history of Standard Oil, pieced together from court records and sworn testimony, showed how Rockefeller took over the oil business.
>
> **When and where:** New York and the Pennsylvania oil region, 1900 to 1904.

**Rockefeller called her "That poisonous woman."**

Ida Tarbell spent most of five years, by her own count, tracing from public records how John D. Rockefeller built Standard Oil. She began in 1900. Her father was Franklin Tarbell, one of the oil producers who had signed the 1872 pledge not to sell oil to Standard Oil.

**The records.** Tarbell read hundreds of thousands of documents from across the country, among them court records and depositions, sworn testimony taken outside a courtroom and written down. She interviewed employees and lawyers. The writer Mark Twain arranged for her to meet Henry H. Rogers, an officer of Standard Oil, and she interviewed him too.

Her *History of the Standard Oil Company* came out in 19 parts in *McClure's* magazine from November 1902 to October 1904, and as a book in two volumes in 1904.

**The widow's plant.** In one part, Tarbell told the story of a Cleveland widow, Mrs. Backus, who sold her late husband's plant for making oil for machines to Rockefeller in 1878. Tarbell wrote that he paid her next to nothing. Rockefeller's biographer Ron Chernow tells it differently: the plant was out of date, the widow asked for as much as $200,000, and Rockefeller paid $79,000, including $10,000 added on top. The two accounts of that sale do not agree.

Chernow does call Rockefeller's buyouts of his Cleveland rivals in 1872 "one of the most shameful episodes in his career." Rockefeller called Tarbell "That poisonous woman." He told his advisers, "Not a word about that misguided woman."

**What came of it.** Her series made many Americans furious with Standard Oil. Smithsonian magazine writes that this public fury is credited with the company's breakup. The breakup came after the justices of the Supreme Court ruled against Standard Oil in 1911.

### Theodore Roosevelt

> **Who:** The president known as the trust-buster, whose lawyers won the Northern Securities case.
>
> **When and where:** Washington, 1901 to 1909.
>
> **Movie:** *TR: The Story of Theodore Roosevelt*, an American Experience documentary first shown on PBS in October 1996.

**His lawyers brought 44 antitrust suits. Taft's brought more.**

Theodore Roosevelt is known as the trust-buster, but the president after him had his lawyers bring more antitrust suits. Roosevelt's Justice Department lawyers sued the Northern Securities Company, J. P. Morgan and James J. Hill's railroad holding company, in 1902 under the Sherman Act, the federal law of 1890 against deals that block trade.

**The ruling.** The justices of the Supreme Court ruled 5 to 4 for the government on March 14, 1904, and upheld the order to break the company up. Justice John M. Harlan wrote for the majority. Justice Oliver Wendell Holmes disagreed, writing, "Great cases like hard cases make bad law." He meant that a case the whole country is excited about stirs up feelings that can bend the judges' thinking.

**Who brought more.** Roosevelt's lawyers brought 44 antitrust suits in seven and a half years. William Howard Taft, the next president, had his lawyers bring more in four years, at least 75. Taft's lawyers sued US Steel in 1911, and Roosevelt then accused Taft of being unable to tell the good trusts from the bad ones.

### Standard Oil and American Tobacco are broken up, 1911

The justices of the Supreme Court ruled against Standard Oil and the American Tobacco Company in May 1911, and both companies were split apart. On May 15 they ruled that Standard Oil of New Jersey had broken the Sherman Act. Chief Justice Edward D. White wrote the court's decision. He wrote that the Sherman Act banned only "unreasonable" limits on trade, a test called the rule of reason. The justices gave the company's owners six months to break it up, and Standard Oil was split into 34 separate companies.

**Richer after the breakup.** Rockefeller was worth about $300 million in May 1911 and more than $900 million by the end of 1913, three times as much. According to Chernow, Roosevelt said that Wall Street's prayer was now "Oh Merciful Providence, give us another dissolution," asking God for another breakup. In 1916 newspaper headlines called Rockefeller the world's first billionaire. Companies that grew out of Standard Oil later became Exxon, Mobil and Chevron.

**Tobacco.** The justices ruled against the American Tobacco Company on May 29, 1911. They found that James B. Duke, Benjamin N. Duke, George W. Watts, R. J. Reynolds and others had broken the Sherman Act "by seeking to monopolize practically all sectors of the tobacco industry." Federal judges in New York divided the company's property in November 1911 among a new American Tobacco Company, Liggett and Myers, P. Lorillard, R. J. Reynolds and others. James B. Duke's tie to American Tobacco ended that year.

### Two new laws, 1914

Members of Congress passed two laws in 1914 that added to the Sherman Act. President Woodrow Wilson signed the first, the Federal Trade Commission Act, on September 26, 1914. Under it, "unfair methods of competition" became illegal, and the members of a new Federal Trade Commission had the power to make companies obey that rule. The commission opened on March 16, 1915.

**The Clayton Act.** The second law named business practices the Sherman Act had left vague. Wilson signed it, the Clayton Antitrust Act, on October 15, 1914. It banned price discrimination, charging different buyers different prices for the same goods. It also banned deals that tied a buyer to one seller, mergers that cut down competition, and the same people sitting on the boards of competing companies.

The Clayton Act also stated "that the labor of a human being is not a commodity or article of commerce," not a thing to be bought and sold. Under that section, federal lawyers and judges could no longer treat unions as illegal combinations, as they had used the Sherman Act against the railroad workers of the Pullman boycott in 1894.

### Ludlow, 1914

Soldiers of the Colorado National Guard, the state's part-time army, burned the tent camp of striking coal miners at Ludlow, Colorado, on April 20, 1914. The mine owners were paying the Guard's costs. At least 19 people were killed, 13 of them women and children. Most of the strikers worked for the Colorado Fuel and Iron Company, whose main stockholder, the person who owned the most shares, was John D. Rockefeller Jr.

**The strike.** The miners struck in September 1913. In October men in a company armored car known as the "Death Special" fired on their tent camp at Forbes and killed one person. Governor Elias M. Ammons sent the Colorado National Guard.

**The fire.** Fighting broke out at the tent camp at Ludlow on April 20, 1914. Nobody knows who fired the first shot. Guardsmen set the tents on fire. Thirteen women and children had hidden in a pit dug under a tent, and they suffocated there, dying for lack of air. One guardsman and five miners were also killed in the fighting. Guardsmen shot the strike leader Louis Tikas three times in the back.

President Wilson sent the US Army on April 28. The strike ended in December 1914, and the union won none of its goals.

### Leaded gasoline, 1924 to 1926

The leaders of three of the largest companies in the country kept selling a lead fuel additive in the 1920s after workers who made it died. The additive was tetraethyl lead, a liquid made with lead. Researchers at General Motors added it to gasoline to stop engine knock, a pinging sound in the engine. General Motors and Standard Oil of New Jersey formed the Ethyl Gasoline Corporation in August 1924 to sell it, and DuPont made it. Chapter 13 tells the whole story of the additive.

**The dead.** Workers died at plants and a laboratory of all three companies. Seven men died and 33 went to the hospital after working at Standard Oil's Bayway refinery in Elizabeth, New Jersey, in October 1924, by the count of Bill Kovarik, who wrote a history of leaded gasoline in 2005. Other accounts count five dead. Kovarik counts ten more dead at a DuPont plant and at least two dead at General Motors' laboratory in Dayton, Ohio.

Poisoned workers at Bayway were "black and blue from uncontrolled muscle spasms." Some had to be tied into straitjackets, coats that hold a person's arms tight against the body.

**"A gift from heaven."** The Surgeon General, the head of the federal public health service, called a meeting about the additive on May 20, 1925. Frank Howard of Standard Oil said there that the industry could not give up "what has come to the industry like a gift from heaven." The companies kept selling it. Robert Kehoe, a scientist paid by the Ethyl company, then set out a theory of a "safe level" of lead that the companies' leaders relied on for decades.

### Who ran the corporations? 1932

Hired managers, not owners, ran the 200 largest corporations outside banking, two writers showed in 1932, and those 200 held about half of the country's corporate wealth. Adolf Berle and Gardiner Means counted them in their book *The Modern Corporation and Private Property*. By 1930 the 200 held 49.2 percent of the country's corporate wealth. The scholar Gerald F. Davis later worked out that at the same pace they would have held all of it by 1959.

Berle and Means also found that the ownership of these companies was split among many scattered shareholders, so the managers made the decisions.

### The Securities and Exchange Commission, 1934

After the stock market crash of 1929, members of Congress passed a law that required companies selling stock to report their finances to the public. President Franklin D. Roosevelt signed it, the Securities Exchange Act, on June 6, 1934. Under it, the members of a new Securities and Exchange Commission, or SEC, watched over the stock markets. The yearly and quarterly reports that such companies still file with the SEC began with this law.

**The fox and the hen house.** Roosevelt made Joseph P. Kennedy the first chairman of the SEC in the summer of 1934. Kennedy had made money in the stock market using the same practices the new law banned, and he had given, lent and raised money for Roosevelt's 1932 campaign.

Newspaper writers said the choice was "like putting the fox in the hen house." In private, Roosevelt answered, "set a thief to catch a thief." Both sayings meant the same thing: Roosevelt had put a man who had used those practices in charge of stopping them. Kennedy resigned in September 1935.

### Spies, guns and company police, 1936 to 1940

Senators on a committee led by Senator Robert M. La Follette Jr. of Wisconsin held hearings from 1936 to 1940 on how employers fought unions. Witnesses told the senators that company managers had planted spies inside unions and hired their own police forces. The managers had also stored up weapons, among them submachine guns, rifles and tear gas.

**Memorial Day, 1937.** Several hundred men, women and children marched toward the Republic Steel plant in Chicago on Memorial Day, May 30, 1937, to support striking steelworkers. Republic Steel's chairman was Tom M. Girdler.

At the plant, 264 Chicago police threw tear gas at the marchers, fired their guns and beat them with clubs. The police killed 10 people and shot 40, and more than 90 people were hurt in all. The senators on the La Follette committee found that the police had used "excessive force," far more force than was needed.

### Hawaii's Big Five

Five companies in Hawaii, known as the Big Five, controlled about 94 percent of the islands' sugar crop by 1920, by the count of the historian Carol MacLennan. Two of them were Castle and Cooke and Alexander and Baldwin.

The same people sat on the boards of several of the firms, and together they controlled shipping, banking and stores in the islands. Four of the firms together owned nearly three-quarters of the Matson shipping line, which carried 80 percent of the cargo between the mainland and Hawaii.

**The overthrow.** Hawaii was a kingdom with its own rulers until 1893. On January 17 of that year, a group of mostly American businessmen calling themselves the Committee of Safety moved against Queen Liliʻuokalani. John L. Stevens, the United States minister to Hawaii, was the American government's representative there. He had 162 US sailors and Marines brought ashore from a warship.

The queen's soldiers and police did not fight. She gave up her power under protest, to the United States rather than to the committee. Chapter 23, America and the World, tells the overthrow in full.

Some children of Big Five partners were members of the Committee of Safety, which then pressed for the United States to annex the islands, or take them over. The Big Five's plantations stood on the land of Native Hawaiians, the Kanaka Maoli. From 1893 into the 1950s, the owners of the Big Five dominated Hawaii's economy and government.

### War contracts, 1940 to 1944

A small number of large companies received most of the government's war business during the Second World War. Robert Higgs, writing for the Independent Institute in 1995, gives the figures for prime contracts, contracts made directly between the government and a company, from 1940 to 1944. The 100 companies with the most contract money received about two-thirds of the value of those contracts, the top 10 received about 30 percent, and General Motors alone received nearly 8 percent.

Federal officials also paid for new factories and rented them to private companies. Just 26 companies had the use of half the value of all those government-paid factories as of June 30, 1944.

**If you remember one thing:** Judges split up Standard Oil and American Tobacco in 1911, but the biggest corporations kept growing through the next forty years.

**One number:** 49.2 percent. By 1930 the 200 largest corporations outside banking held that share of the country's corporate wealth, and at the same pace, Gerald F. Davis worked out, they would have held all of it by 1959.

**Next:** After 1950 the largest companies had hundreds of thousands of workers each, and their leaders organized to win influence in Washington.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 15 minutes**

Companies grew so large in these years that General Motors had 618,365 workers in the United States in 1979, and the Bell telephone system had more than a million that year. From the 1970s, business leaders organized to win influence in Washington. By 1982 more than 2,400 firms paid lobbyists registered there to persuade lawmakers.

**Products and disease.** The leaders of some companies kept selling products that studies linked to disease and death. Tobacco companies paid for advertisements in 1954 in which their leaders disputed studies linking smoking to lung cancer, and in 1994 heads of tobacco companies told a House hearing that they did not believe nicotine is addictive.

**Breakups.** AT&T's leaders agreed with federal lawyers to split up the Bell System, and the split took effect in 1984. Federal lawyers won a ruling in 1999 that Microsoft held a monopoly, and in 2001 an appeals court agreed that Microsoft had broken the law to keep it.

### General Motors

General Motors was the country's largest car maker in the 1950s, and in 1953 it sold more to the armed forces than any other company. In 1954 it sold about half of all new cars in the country, 54 percent by the Associated Press's count.

**A billion dollars.** In 1955 GM became the first company to earn more than a billion dollars in profit in one year. In the first three quarters of that year alone it made $912,887,537 in profit. *TIME* magazine wrote, "Never before in history has one corporation made so much in so short a time."

**"Good for General Motors."** President Dwight D. Eisenhower chose GM's president, Charles E. Wilson, as Secretary of Defense in January 1953. Wilson gave up a salary of $600,000 a year for one of $22,000. He owned 40,000 shares of GM stock, and GM sold more to the armed forces than any other company. As Secretary of Defense he could make decisions that helped or hurt GM, so at his hearing senators pressed him on that conflict.

Senator Robert C. Hendrickson asked whether Wilson could make a decision that went strongly against GM's interest. Wilson answered, "Yes, sir, I could." But he said he could not imagine one, "because, for years, I thought what was good for our country was good for General Motors, and vice versa," meaning the other way around. People soon repeated his words as "What is good for General Motors is good for the country."

**Ralph Nader.** Ralph Nader criticized the safety of GM's Corvair car in a 1965 book called *Unsafe at Any Speed*. GM managers hired private detectives to look into Nader's private life, and in 1966 GM's president, James M. Roche, apologized to a Senate committee. That same year members of Congress passed the National Traffic and Motor Vehicle Safety Act, the first federal rules for how cars must be built.

Nader sued GM for invading his privacy and settled for $425,000, which he used to start groups that work for consumers. GM stopped making the Corvair in 1969.

**Workers in 1979.** GM's workforce in the United States peaked at 618,365 in 1979. AT&T's Bell telephone system had more workers than GM that year. By AT&T's own count, it employed 1,029,905 people at the end of 1979.

### Eisenhower's warning, 1961

President Dwight D. Eisenhower warned the country about the power of the arms makers and the armed forces together in his farewell speech, on January 17, 1961. "In the councils of government," he said, "we must guard against the acquisition of unwarranted influence, whether sought or unsought, by the military-industrial complex."

By the military-industrial complex he meant the ties between the armed forces and the companies that made their weapons. He meant that the people making the government's decisions had to keep the arms makers and the armed forces from gaining power they had no good reason to have, whether they went looking for it or not. The weapons makers were the same kinds of large companies that had received most of the war contracts of 1940 to 1944.

### What was a conglomerate?

A conglomerate was one company that owned many businesses that had nothing to do with each other. Harold Geneen ran the company ITT from 1959 to 1977, and in those years ITT bought more than 250 companies in more than 80 countries. They included the Sheraton hotel chain, Avis car rental, the Hartford insurance company and Continental Baking, the maker of Wonder Bread.

ITT's yearly sales grew from about $700 million to $17 billion, and it became the eleventh-largest corporation in the country. Geneen believed that good managers could make a success of any business.

**ABC and Chile.** ITT's leaders tried to buy the ABC television network for $700 million in 1966, and federal antitrust officials stopped the deal. In Chile, officials under President Salvador Allende took over ITT's company there. ITT's leaders later admitted that the company had given the CIA, the American spy agency, $350,000 for "political" purposes in Chile.

### Business organizes in Washington

Heads of large companies built up their own political power in Washington in the 1970s.

**The Powell memo.** The lawyer Lewis F. Powell Jr. sent a private memo to Eugene B. Sydnor Jr. of the US Chamber of Commerce, a national group of businesses, on August 23, 1971. Its title was "Attack On American Free Enterprise System." Powell wrote that critics of business now came from "the college campus, the pulpit (preachers in churches), the media" and from politicians. He urged business leaders to keep "constant surveillance," or a close watch, on textbooks and television programs.

President Richard Nixon nominated Powell to the Supreme Court on October 21, 1971, less than two months later. The newspaper columnist Jack Anderson made the memo public in September 1972. That year the Chamber's leaders set up a 40-person working group on the memo, and in late 1973 they approved plans for business to act in education, in communications, in politics and in the courts.

**The Business Roundtable.** Three groups of company heads joined to form the Business Roundtable on October 13, 1972. Its founders included John D. Harper of Alcoa and Roger Blough, the retired head of US Steel. They set out to fight the growing power of unions, especially construction unions.

**Offices and lobbyists.** Company heads opened offices in Washington, and by 1978 more than 500 corporations had one. They also hired lobbyists to persuade lawmakers. Firms with registered lobbyists went from 175 in 1971 to 2,445 in 1982, about 14 times as many.

**Money for candidates.** Companies also set up political action committees, or PACs, groups that collect money and give it to candidates. Officials of the Federal Election Commission counted 89 company PACs at the end of 1974 and 1,206 at the end of 1980, more than 13 times as many.

**Rules removed.** In the same years, members of Congress voted to take federal rules off three industries, and President Jimmy Carter signed each law. The airline law of 1978 began ending federal officials' control over which routes airlines flew and what they charged, and the federal board that had set them closed in 1984.

The banking law of 1980 ended, over six years, the limits on the interest banks could pay savers. The trucking law of 1980 let trucking companies set many of their own prices and made it easier for new companies to start. Each law took power over prices from federal officials and gave it to the companies.

### What did the companies say when their products hurt people?

Heads of tobacco companies publicly disputed the evidence that smoking causes disease and that nicotine is addictive for forty years, from 1954 to 1994. The major American tobacco companies ran an advertisement called "A Frank Statement to Cigarette Smokers" in more than 400 newspapers on January 4, 1954, and it reached about 43 million people.

In it, the companies' leaders disputed new scientific studies that linked smoking cigarettes to lung cancer. The public relations firm Hill and Knowlton, a company paid to shape what the public thinks of its clients, designed it.

**The 1963 memo.** Addison Yeaman, the chief lawyer of the Brown and Williamson tobacco company, wrote a memo on July 17, 1963. To protect its earnings, he wrote, the industry must "either a) disprove the theory of causal relationship or b) discover the carcinogen or carcinogens...and demonstrate our ability to remove or neutralize them." He meant that the companies had to either show that smoking does not cause cancer, or find the substances in smoke that do cause it and show they could take them out or make them harmless.

**The 1994 hearing.** Representative Ron Wyden asked seven tobacco company heads whether nicotine is addictive at a hearing in the House of Representatives on April 14, 1994. William Campbell of Philip Morris answered, "I believe nicotine is not addictive, yes." James Johnston of R. J. Reynolds said cigarettes "clearly do not meet the classic definition of addiction." Joseph Taddeo of US Tobacco said, "I don't believe that nicotine or our products are addictive."

**The settlement.** Four cigarette makers, Philip Morris, R. J. Reynolds, Brown and Williamson and Lorillard, signed an agreement on November 23, 1998, with the attorneys general, the chief lawyers, of 46 states. The attorneys general had sued to get back what their states spent treating sick smokers. The companies' leaders agreed to pay at least $206 billion over the first 25 years and to limit their advertising.

**Asbestos.** Asbestos is a mineral that separates into thin, strong fibers, and builders used it to fireproof and insulate buildings. When people breathe asbestos fibers in, the fibers can stay in the lungs for years. They scar the lungs and can cause asbestosis, a lung disease that brings shortness of breath, coughing and lasting lung damage. They can also cause mesothelioma, a cancer of the thin linings of the chest and belly. The illness can take 10 to 40 years or more to show.

Johns-Manville was once the largest maker of asbestos products in the country. Andrew Hansen began working at a shipyard in 1940, tearing old insulation out of ships and putting new insulation in. Most of it was made by Johns-Manville and contained asbestos. In 1978, at 65, he was found to have asbestosis and mesothelioma, and he died 13 months later. His widow sued the company.

**What the company knew.** Dr. Kenneth Smith, Johns-Manville's medical director until 1966, gave sworn testimony in the case. He said that in the 1940s he had told the company's leaders about the danger asbestos posed to insulation workers and had urged warnings on its insulation products, and that they did not act on his advice.

Johns-Manville's lawyers answered that the company began putting warnings on its products in 1964, as soon as science proved a link between its products and asbestosis. The jury found for Hansen's widow, and in 1984 a federal appeals court upheld that finding against the company.

By 1981, while her case was still in the courts, Johns-Manville faced 9,300 lawsuits brought by 12,800 people who sued over illness from asbestos. Its leaders filed for bankruptcy, a court process for a company that cannot pay its debts, in August 1982. Under the filing, all the injury lawsuits against the company were put on hold. By the end of 1988, more than 12,600 claims, almost $500 million in all, had been paid from a fund set up in the bankruptcy to pay for injuries.

**Bhopal.** More than 40 tons of a poison gas called methyl isocyanate leaked from a pesticide plant in Bhopal, India, a factory that made poisons to kill insects, on December 3, 1984. Union Carbide India Limited, part of the American company Union Carbide, ran the plant.

**How it happened.** Union Carbide's leaders had planned to close the plant, which was losing money. Instead they cut many jobs to run it for less, among them maintenance engineers. In June 1984 the unit that kept the gas cold was shut down, to cut the plant's use of electricity by 18 percent. Weeks before the leak, the machine meant to clean escaping gas was turned off too: on October 23 by the date in a report by France's environment ministry, or three weeks before by a 2005 medical review.

On December 2, 1984, the plant's senior managers ordered some pipes cleaned with water. A broken valve let about a ton of that water into a tank holding 40 tons of the gas, and on December 3 the gas escaped into the air. Neither report names the people who turned off the gas-cleaning machine or shut down the cooling unit.

**What the gas did.** The gas damaged people's eyes, causing redness and sores, and it filled their lungs with fluid. It killed about 2,000 people in the first hours, according to Britain's Health and Safety Executive, a government safety agency. The 2005 medical review, by Edward Broughton, gives about 3,800 dead at once, and 15,000 to 20,000 early deaths reported over the next twenty years.

At first Union Carbide's leaders tried to keep the company free of legal blame. Later they said the company accepted "moral responsibility," and the company paid $470 million to the government of India.

### The Bell System is split, 1984

AT&T's Bell System held about $150 billion in property and employed about a million people in the early 1980s. Justice Department lawyers had sued AT&T in 1974. In January 1982 AT&T's leaders and the Justice Department's lawyers agreed that AT&T would give up its local telephone companies.

In return, a 1956 court order that had kept AT&T out of the computer business was lifted, and most newspapers reported the deal as a win for AT&T. Judge Harold H. Greene approved the deal with changes, and the case was closed on August 24, 1982.

**The Baby Bells.** The local companies became seven regional companies, called the Baby Bells, on January 1, 1984. AT&T kept its long-distance service, its research center, Bell Labs, and its equipment maker, Western Electric. It kept $34 billion of the $149.5 billion in property it had held the day before, less than a quarter, and it had 636,000 fewer workers.

### Bill Gates

> **Who:** The head of Microsoft when federal and state lawyers sued it for keeping an illegal monopoly on the software that runs personal computers.
>
> **When and where:** Redmond, Washington, and Washington, D.C., 1998 to 2001.
>
> **Movie:** *Inside Bill's Brain: Decoding Bill Gates* (2019), a Netflix series directed by Davis Guggenheim.

**A judge ordered his company split in two.**

Bill Gates founded Microsoft and ran it as its chief executive until January 2000, so he was in charge when a federal judge found that it held an illegal monopoly. Microsoft made Windows, the operating system, or main program, that ran most personal computers and the other programs on them.

**The case.** Lawyers for the Justice Department, the attorneys general of twenty states and the District of Columbia sued Microsoft on May 18, 1998. The main question was whether Microsoft could bundle its web browser, Internet Explorer, the program people use to look at websites, with Windows. To bundle it meant to build it into Windows, which made it harder for rival browsers such as Netscape Navigator to win users.

**On tape.** Gates answered the government lawyers' questions in a deposition that was filmed on videotape. A person who was there called him "evasive and nonresponsive," dodging the questions. According to *Businessweek* magazine, the government lawyers used snippets of emails to show that many of his denials were false.

**The rulings.** Judge Thomas Penfield Jackson found on November 5, 1999, that Microsoft held a monopoly. On June 7, 2000, he ordered the company split into two, one for Windows and one for its other software. On June 28, 2001, seven judges of the federal appeals court agreed that Microsoft had illegally kept its monopoly, but they threw out the breakup order, partly because Jackson had talked about the case to reporters while it was still going on.

**No breakup.** Attorney General John Ashcroft announced on September 6, 2001, that Justice Department lawyers would no longer seek a breakup. The government's lawyers settled with Microsoft on November 1, 2001. Microsoft's leaders agreed to share some of the company's technical information with other companies and accepted a panel of three investigators with full access to its systems.

### Steve Young

> **Who:** A Vlasic pickle executive who described what it was like to sell to Walmart.
>
> **When and where:** The late 1990s to January 2001. His account was published in December 2003.
>
> **Movie:** *Is Wal-Mart Good for America?* (FRONTLINE, PBS, 2004), a documentary about Walmart.

**Walmart sold a gallon of Vlasic pickles for $2.97.**

Steve Young watched Walmart's buyers push his company's pickles to a price that left almost no profit. He was vice president of grocery marketing for pickles at Vlasic. The reporter Charles Fishman told his story in *Fast Company* magazine in December 2003.

**The jar.** A Walmart buyer saw Vlasic's gallon jar of pickles in the late 1990s and began talking about it with Pat Hunn, the head of Vlasic's Walmart sales team. The jar went into every Walmart, about 3,000 stores, at $2.97. At that price Vlasic and Walmart each made a penny or two a jar, if that. Young said each store sold about 80 jars a week, which came to 240,000 gallons of pickles a week.

Walmart was 30 percent of Vlasic's business. Young says shoppers who used to buy Vlasic's pickle spears and chips at supermarkets bought the cheap gallon jar instead, and Vlasic's profits from pickles fell by 25 percent or more.

**The threat.** Young says Vlasic's managers asked to raise the price. He remembers the Walmart buyers' answer: "If you do that, all the other products of yours we buy, we'll stop buying." He called it "a clear threat." Hunn remembers the buyers saying, "We want the $2.97 gallon of pickles. If you don't do it, we'll see if someone else might."

Later, Walmart's buyers let Vlasic shrink the jar to just over half a gallon, at $2.79. Vlasic filed for bankruptcy in January 2001, though everyone involved agrees that the gallon jar was not a main cause.

**Why this story is here:** A buyer as large as Walmart could name its price, even a price that left the seller almost nothing.

**If you remember one thing:** Between 1950 and 2000 the biggest companies had hundreds of thousands of workers, and from the 1970s their leaders built up their own power in Washington.

**One question this era leaves open:** The Bell System was split up in 1984 under a deal a judge approved, but in 2001 appeals judges threw out the order to split Microsoft in two. Would judges order a giant company split up again? The next era answers it.

**Next:** After 2000 three American companies came to be worth more than $4 trillion each, and government lawyers took four of the largest technology companies to court.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 12 minutes**

Three American companies, Nvidia, Apple and Alphabet, the company that owns Google, were each worth more than $4 trillion in September 2026. In the same years government lawyers took four of the largest technology companies to court over monopoly power. Walmart employed about 1.6 million people in the United States in 2026, by its own count, about 2.6 times General Motors' American workforce at its peak in 1979.

**Fraud and a rescue.** A federal jury convicted Enron's former chief executives of fraud in 2006. Purdue Pharma, the maker of the pain pill OxyContin, pleaded guilty to federal crimes in 2007 and again in 2020. Lehman Brothers failed in 2008, and members of Congress set aside $700 billion that year to rescue banks and other companies.

**The four cases.** The four technology companies taken to court were Google, Meta, Amazon and Apple. By September 2026 judges had ruled twice that Google broke the law and once for Meta, and the Amazon and Apple cases had not come to trial.

### How big are the biggest companies?

Nvidia became the first company worth $5 trillion on October 29, 2025, according to the business news network CNBC. A company's worth, its market value, is the price of one share times the number of shares, and it changes every day the stock market is open. The investment website The Motley Fool listed the three most valuable companies in the world on September 7, 2026: Nvidia at about $5.6 trillion, Apple at about $4.7 trillion and Alphabet at about $4.1 trillion.

**Workers.** Walmart reported $713.2 billion in revenue, the money it took in, for the year that ended on January 31, 2026. Its 2026 annual report records about 2.1 million workers around the world, about 1.6 million of them in the United States, and about 92 percent of its American workers were paid by the hour. At that time it had more than 10,900 stores in 19 countries.

Amazon's yearly report to the government for 2025 states that it employed about 1,576,000 people at the end of that year. It also used independent contractors, workers paid for each job who are not employees, and temporary workers, and neither group is counted in that number.

### Fraud and harm at the top

Judges and juries found that leaders of several large companies of these years had deceived the public, and Purdue Pharma's leaders admitted it in guilty pleas.

**Enron.** Enron, an energy company in Houston, Texas, filed for bankruptcy on December 2, 2001. Its workers had much of their retirement savings in Enron stock. At the end of 2000, 62 percent of the money in the company's retirement plan was in its own shares, according to the Congressional Research Service, which does research for Congress.

The shares fell from more than $80 each in January 2001 to less than 70 cents in January 2002, less than a hundredth of their old price. A lawsuit claimed that Enron had blocked its workers from moving their retirement money out of Enron stock while the price fell.

A federal jury in Houston convicted Enron's former chief executives, Kenneth L. Lay and Jeffrey K. Skilling, on May 25, 2006. The jury found them guilty of conspiracy, planning a crime together with others, and of fraud, lying or cheating to get money. According to the Justice Department, the two men had lied to investors and others to make Enron look healthy, as if it were growing steadily and had no large debts or losses. Their lies pushed up the price of Enron's stock.

**Tobacco in court.** Federal Judge Gladys Kessler ruled on August 17, 2006, that the major tobacco companies had broken the federal racketeering law, the law against running a business through a pattern of fraud. She found that the companies had "defrauded the American people by lying for decades about the health risks of smoking and their marketing to children."

She wrote that they had "marketed and sold their lethal products with zeal, with deception," meaning with great eagerness and with lies, and that they had cared only about their profits, "without regard for the human tragedy or social costs that success exacted," the price other people paid for it. She ordered them to publish statements about the harm of smoking and about how addictive nicotine is.

**Purdue Pharma.** Purdue Pharma made OxyContin, a pain pill and an opioid, a drug from the same family of chemicals as heroin. The first wave of opioid overdose deaths, from 1999, came from prescription opioids, after doctors wrote more opioid prescriptions in the 1990s, according to the federal Centers for Disease Control and Prevention. CDC researchers count about 806,000 Americans who died of opioid overdoses from 1999 to 2023, from all kinds of opioids.

**Guilty pleas.** Purdue pleaded guilty in May 2007 to misleading the public about the risk of becoming addicted to OxyContin, and it agreed to pay $600 million. Its president, Michael Friedman, its top lawyer, Howard R. Udell, and its former chief medical officer, Paul D. Goldenheim, also pleaded guilty. They admitted to misbranding, selling a drug with false or misleading claims about it, and together they paid $34.5 million.

Purdue pleaded guilty again on November 24, 2020, to three federal felonies, which are serious crimes. No member of the Sackler family, which owned Purdue, was charged with a crime.

Attorneys general of 55 states and territories joined a $7.4 billion settlement with Purdue and the Sacklers on June 16, 2025, according to the New York attorney general's office. Federal Judge Madeline Cox Arleo sentenced Purdue to pay $5.5 billion on April 28, 2026, as CNBC and Reuters reported. She said she could not send Purdue's executives or owners to prison, because Justice Department lawyers had charged only the company.

More than 40 people spoke at the sentencing. Judge Arleo said, "Your government failed you." New York's attorney general announced on May 1, 2026, that Purdue had shut down. A new company, Knoa Pharma, took over, with no role for the Sacklers.

### The 2008 rescue

The investment bank Lehman Brothers failed in 2008, and members of Congress voted public money to rescue banks and other companies.

**Lehman Brothers.** Lehman Brothers filed the largest bankruptcy in the country's history on September 15, 2008. It had about $639 billion in property and $619 billion in debts, according to the reference publisher EBSCO. Its chief executive was Richard S. Fuld Jr.

Investigators later looked into whether Lehman's executives, Fuld among them, had moved money and raised their own pay just before the bankruptcy. EBSCO's entry states that Fuld "walked away with $480 million" but does not say over what years he received it.

**Repo 105.** Anton R. Valukas, an investigator named by the bankruptcy court, reported in March 2010 on deals that Lehman's managers called Repo 105. They had used the deals to make the firm's books look stronger at the end of each quarter, the three-month periods for which companies report their results. Officials of the Securities and Exchange Commission reported in 2011 that it would be hard to prove that Lehman had broken the law. No Lehman executive was charged with a crime.

**The rescue.** Members of Congress passed the Emergency Economic Stabilization Act on October 3, 2008. It allowed up to $700 billion to rescue banks and other companies. Federal officials paid out $443.5 billion in all, and most of it was paid back. Auditors at the Government Accountability Office, which checks federal spending for Congress, put the final cost at $31.1 billion in December 2023.

Some parts of the rescue made money, and others lost it. The money put into banks under the Capital Purchase Program earned a profit of $16.3 billion. The rescue of the insurance company AIG, the loans to car makers and the housing programs all cost money, and the housing programs cost the most. The car loans began with $13.4 billion that President George W. Bush announced in December 2008.

### Antitrust returns

Government lawyers brought monopoly cases against four of the largest technology companies in the 2020s. By September 2026 they had won two cases against Google and lost one against Meta, and two more were waiting for trial. Neither judge in the Google cases ordered Google to sell off part of its business.

**Google search.** Federal Judge Amit P. Mehta ruled on August 5, 2024, that Google had illegally kept monopolies in general internet search and in search advertising. On September 2, 2025, he refused to make Google sell its Chrome browser or its Android phone software. Then, on December 5, 2025, he ordered Google to share its search index, the huge list of web pages a search engine keeps, and some user data with rival companies. A committee of five technical experts was to oversee it.

Google's lawyers appealed. In late July 2026 Justice Department lawyers filed a brief, a written argument, with the appeals court, according to the news service Courthouse News. They asked the court to keep the ruling and to ban Google's large payments to companies such as Apple. Under those deals, Google is the search engine that the companies' products use unless the user changes it.

**Google advertising.** In a second case, federal Judge Leonie Brinkema ruled in April 2025 that Google had illegally monopolized the tools that websites use to sell advertising space. Her opinion on what Google must do was made public on September 16, 2026. She refused to make Google sell its advertising exchange, the online market where websites sell ad space to advertisers, and ordered new rules for how the tools work.

The National Law Review reported the opinion in an article by a writer for Chamber of Progress, a group funded by the technology industry.

**Meta.** The Federal Trade Commission's case against Meta was about its purchases of Instagram in 2012 and WhatsApp in 2014. The trial began on April 14, 2025, and Judge James Boasberg ruled for Meta on November 18, 2025. He found that Meta did not hold a monopoly, because TikTok and YouTube competed with it. FTC lawyers appealed on January 20, 2026, and in August 2026 the appeals judges had not yet set a date to hear the case.

**Amazon and Apple.** FTC lawyers and 17 state attorneys general sued Amazon on September 26, 2023, for keeping an illegal monopoly. Judge John H. Chun set the trial for March 29, 2027, and he will decide the case himself, without a jury. Justice Department lawyers and 16 state attorneys general sued Apple on March 21, 2024, for monopolizing the market for smartphones. On June 30, 2025, Judge Julien Neals refused Apple's request to throw the case out.

### Lina Khan

> **Who:** A law student whose 2017 article argued that the people who enforce antitrust law were missing Amazon's kind of power, and who later led the Federal Trade Commission.
>
> **When and where:** New Haven, Connecticut, and Washington, D.C., 2017 to 2025.

**At 32 she became the youngest head of the FTC.**

Lina Khan argued that the judges and officials who enforce antitrust law had stopped looking at the kind of power Amazon held, and she later ran the agency that sued Amazon. She published her argument in the *Yale Law Journal* in 2017, while she was a student at Yale Law School, under the title "Amazon's Antitrust Paradox," a paradox being something that seems to contradict itself.

**Her argument.** She wrote that those judges and officials had come to judge competition mainly by whether prices went up. In her view, that test missed the power Amazon's leaders built by accepting losses while the company spread into selling, delivery, publishing and cloud computing, renting out computer storage and computing power over the internet. They could use the company's place in one business to gain in another.

**The diapers.** Her article gave an example. In 2009 Amazon's leaders wanted to buy Quidsi, the company that ran the website Diapers.com, and Quidsi's owners said no. Amazon then cut its prices for diapers and other baby goods by up to 30 percent. Quidsi's executives worked out that Amazon was on track to lose $100 million in three months on diapers alone. Amazon bought Quidsi the next year, and by February 2012 it had cut the discounts it gave parents from 30 percent to 20 percent, she wrote.

**At the FTC.** Members of the Senate confirmed her to the Federal Trade Commission by a vote of 69 to 28 on June 15, 2021. President Joe Biden chose her as the commission's chair, and she was sworn in the same day. At 32 she was the youngest chair in the agency's history, according to CNBC. Under her, FTC lawyers sued Amazon in 2023 and carried on the case against Meta.

**Her critics.** Robert D. Atkinson and Michael R. Ward of the Information Technology and Innovation Foundation, a research group funded partly by technology companies, argued in a 2023 report that her 2017 article misread how online markets work. Khan served as chair until January 20, 2025.

### Corporate money in politics

Corporations and unions have been able to spend without limit on elections since 2010, as long as they do not work directly with a candidate. The justices of the Supreme Court ruled 5 to 4 on January 21, 2010, in *Citizens United v. Federal Election Commission*, that "the Government may not suppress political speech based on the speaker's corporate identity." That meant the government could not silence speech about politics just because a corporation was doing the speaking.

**The case.** The case began with a film that a non-profit corporation had made to attack Hillary Clinton. Federal law had barred the group from advertising it close to the election.

**Super PACs.** After the ruling, committees called super PACs could raise and spend unlimited sums. Researchers at the Brennan Center for Justice, a law and policy institute, count about $6.4 billion that super PACs spent on federal elections from 2010 to 2022. In the 2024 election they spent at least $2.7 billion. That year, spending by groups that do not have to name their donors passed $1 billion, spending people call dark money.

**Lobbying.** Companies and other groups also pay lobbyists. Organizations spent $5.08 billion on lobbying the federal government in 2025, the first year above $5 billion, according to OpenSecrets, a group that tracks money in politics. That year 15,768 organizations reported lobbying, and the US Chamber of Commerce spent the most, $72.1 million.

### Working for a company without being employed by it

Some companies now pay people for work without hiring them as employees. Ride and delivery companies call their drivers independent contractors. The federal law on the minimum wage and overtime pay is the Fair Labor Standards Act, and its rules apply to employees but not to independent contractors, according to the Department of Labor.

**How many.** The count of Americans who do this kind of work depends on the question asked. Researchers at the Bureau of Labor Statistics, the federal agency that counts jobs, found 1.6 million people in May 2017 who found work through an app or a website, 1.0 percent of all workers. Researchers at the Pew Research Center found in 2021 that 16 percent of American adults had ever earned money through an online job app, and 9 percent had done so in the past year.

**The three questions, answered**

- How did a few companies come to control whole industries? Their owners made secret deals with railroads, bought out rivals and joined companies into trusts and mergers. By 1880 Standard Oil refined 90 to 95 percent of the country's oil.
- What did owners do when their workers went on strike? They locked workers out and hired armed guards, and officials sent soldiers and court orders. At Homestead in 1892 Frick's Pinkerton men fought the steelworkers, and at Ludlow in 1914 soldiers paid by the mine owners burned the strikers' tent camp.
- Did breaking up a giant company ever work? Not clearly. Judges split Standard Oil into 34 companies in 1911, yet Rockefeller was three times as rich by 1913. AT&T gave up its local telephone companies in 1984 in a deal most newspapers called a win for AT&T, the order to split Microsoft was thrown out in 2001, and judges in 2025 and 2026 would not make Google sell off parts of its business.

**What changed:** In 1500 no company existed in this land, and by 2026 three American companies were each worth more than $4 trillion.

**Five dates to keep**

- May 13, 1607: The Virginia Company's settlers found Jamestown.
- December 16, 1773: Colonists dump the East India Company's tea into Boston Harbor.
- July 2, 1890: The Sherman Antitrust Act becomes law.
- May 15, 1911: The justices of the Supreme Court rule against Standard Oil.
- January 21, 2010: The justices decide *Citizens United*, on corporate spending in elections.

**Not known:** No record shows which Acadians died at sea on the ships Thomas Hancock's firm rented out in 1755, or how many.

**Where to go:** Lowell National Historical Park stands in Lowell, Massachusetts, the mill town the Boston Associates built.

**Next:** Chapter 20, Government, Law, and Politics. It asks who wrote the rules of American government, and who got to vote.
