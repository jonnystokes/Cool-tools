# Chapter 12: Landmarks

**Chapter 12 of 37 · Landmarks · 10 eras · about 75 minutes**

**Many of the people who built America's landmarks were enslaved, forced to work or killed on the job. Americans still argue about whose land the landmarks stand on and which people they honor.**

In Emancipation Hall, in the Capitol Visitor Center in Washington, there is a block of sandstone from Aquia Creek, Virginia. It was part of the Capitol's East Front, built from 1824 to 1826. Members of Congress unveiled it as a marker on February 28, 2012. Its plaque states that the stone "was quarried," or cut from the ground, "by laborers, including enslaved African Americans." In the 1790s the officials in charge of building the Capitol rented enslaved men from their owners by the year, and the owners collected the pay.

This chapter describes landmarks from earthworks more than 3,000 years old to memorials opened in 2024. Watch for two things as you read. One is who did the building: Native men drafted to cut stone for a Spanish fort, enslaved men rented out by their owners, immigrants killed on the Brooklyn Bridge. The other is what people argued about afterward. A golf club used an ancient earthwork in Ohio as a golf course from 1910 to 2024. Workers carved Mount Rushmore on land that members of Congress had taken from the Sioux. Since 2015, officials and work crews have taken down, moved or renamed hundreds of Confederate memorials, and in 2025 federal officials began putting some back.

**Three questions this chapter answers**

- Who built the White House and the Capitol, and who was paid for their work?
- How many workers died building Hoover Dam?
- What has happened to the Confederate monuments since 2015?

**Five minutes?** Read "Enslaved men who built the capital" in 1750 to 1800.

**Can skip:** "The Woolworth Building", "The largest private house", "The Space Needle". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 6 minutes**

Native people built the oldest landmarks in the United States, hundreds and even thousands of years before any European arrived. They piled up mounds of earth, and one of them covers more ground than the Great Pyramid in Egypt. In the Southwest they built stone houses with hundreds of rooms and set whole villages under cliffs.

No one wrote down the names of the people who built these places. In the Southwest, the builders' descendants, among them the Pueblo peoples, still live in the same region.

### Monks Mound and the mound builders

Monks Mound, at Cahokia in what is now Illinois, is the largest structure made of earth in North and South America. People piled up its earth in stages, mostly between about the years 1050 and 1200. It stands about 100 feet tall. Its base covers about 14 acres, and the base of the Great Pyramid of Giza, in Egypt, covers about 13. The pyramid is far taller, so the mound is bigger only in the ground it covers.

Poverty Point, in Louisiana, is much older. People built it between about 1700 BC and 1100 BC, which is about 3,700 to 3,100 years ago. The builders lived by hunting, fishing and gathering wild food. They heaped up earth into five mounds and six curved ridges, set one inside another around a wide open space in the middle. It is the largest earthwork of its age north of Mexico.

**A world list.** Poverty Point is on the World Heritage List, which includes places chosen because they matter to all people. The World Heritage Committee of UNESCO, a part of the United Nations, keeps the list. Its members added Poverty Point on June 22, 2014, at a meeting in Doha, Qatar, as the 1,001st place on the list and the 22nd in the United States.

Serpent Mound, in Ohio, is a snake shaped out of earth, about a quarter of a mile long. It is the largest snake-shaped mound in the world. Nothing found inside it shows who built it.

**Two dates.** Archaeologists, scientists who study the past from the things people left behind, have tested the mound with radiocarbon dating, a way to measure the age of anything that was once alive. Tests done in 1991 gave about the year 1070, the time of a people archaeologists call the Fort Ancient culture. Tests done in 2014 gave about 300 BC, the time of a people they call the Adena culture. Later work has found evidence for both dates.

**Not known:** which people built Serpent Mound. Archaeologists now think it possible that people built it in one period and rebuilt it in another.

### Stone buildings of the Southwest

In Chaco Canyon, in what is now New Mexico, people built large stone buildings called great houses between about 850 and 1150. The largest, Pueblo Bonito, rose four stories high. It held about 600 to 650 rooms, or more. The counts differ because some of them include a guess at how many rooms the upper floors held, and some do not.

At Mesa Verde, in what is now Colorado, people built Cliff Palace between about 1190 and 1280. They set it under an overhang, a place where the rock of the cliff sticks out above like a roof. Cliff Palace has about 150 rooms and 23 kivas, rooms used for religious ceremonies. It is the largest cliff dwelling in North America.

The National Park Service lists 26 tribes with a special tie to Mesa Verde. Twenty-one of them are Pueblo nations, among them the Hopi Tribe and the Pueblos of Zuni, Taos and Acoma in New Mexico. The other five, the Navajo Nation, three Ute tribes and the Jicarilla Apache Nation, also have a tie to the place.

### Earthworks under a golf course

Native people in southern Ohio built long walls of earth in the shapes of circles and eight-sided figures about 2,000 years ago. Archaeologists call these people the Hopewell culture. Hopewell is a name archaeologists gave them, not the name of any nation.

Accounts differ on how long the building went on, from about 400 years to about 700, in the centuries between about 200 BC and the year 500.

The Octagon Earthworks, in Newark, Ohio, is a large circle of earth joined to an eight-sided wall. Together the two walls surround nearly 70 acres. The walls line up with the points where the moon rises, in a pattern that repeats every 18.6 years.

**The golf course.** The Moundbuilders Country Club began leasing, or renting, the Octagon in 1910 and used it as a golf course. Since 1933 the land has belonged to the Ohio Historical Society, now called the Ohio History Connection, a group set up under state law and not run to make money. For decades its leaders kept leasing the site to the club.

Members of UNESCO's World Heritage Committee voted on September 19, 2023, to add eight Hopewell earthwork sites to the World Heritage List. The Octagon was one of them.

### Glenna Wallace

> **Who:** The first woman to lead the Eastern Shawnee Tribe of Oklahoma, chief from 2006 to 2026, who fought for years to get a golf course off the Octagon Earthworks.
>
> **When and where:** The Octagon Earthworks, Newark, Ohio, from the late 2000s to 2025.

**A golfer shouted at her, "Out of the way! You don't belong here!"**

**The golfer.** Wallace first visited the Octagon Earthworks in the late 2000s, in 2007 by the account in the Smithsonian's *American Indian* magazine and in 2009 by other accounts. That was the visit when the golfer shouted at her. She decided to get the golf course off the earthworks and to win World Heritage status for them.

**Forced out of Ohio.** Wallace's own people had once lived in western Ohio, near Lewistown. Their band of Shawnee and Seneca, joined as one, gave up that land in a treaty, a written agreement between nations, signed on July 20, 1831. James B. Gardiner, a special official, signed it for the United States.

Under the treaty, US officials forced the people out of Ohio in 1832. They walked about 800 miles to a reservation, land set aside for a Native nation, in what is now Ottawa County, Oklahoma. More than 15 percent of them died on the way, according to the Ohio History Connection. No record of the march names the officials who led it. Wallace was born in that county in about 1939.

**Her own words.** At Ohio Statehood Day in 2019, Wallace asked, "Why had I never read anything about Newark Earthwork Mounds?" Then she answered her own question: "Because you here in Ohio didn't even realize the treasures that you had."

**The court case.** Leaders of the Ohio History Connection went to court to end the club's lease. They used eminent domain, a legal power to take property for public use as long as the owner is paid. On December 7, 2022, the judges of the Ohio Supreme Court ruled 5 to 1 that they could do it.

Wallace gave the main speech at the 2023 meeting in Riyadh, Saudi Arabia, where members of UNESCO's World Heritage Committee voted to list the earthworks. In August 2024 leaders of the club and of the Ohio History Connection agreed to end the court case, and they did not make the terms public. "At last," Wallace said. "So many people have worked so long for this to become reality."

The club ran the golf course until the end of 2024. The Octagon opened to the public on January 1, 2025.

## The 1500s

**Era 2 of 10 · The 1500s · about 1 minute**

Nothing that Europeans built here in the 1500s still stands. The Spanish built their first forts in Florida of wood and earth. Those forts burned many times, and the Spanish rebuilt them again and again.

Spanish priests ran missions, settlements where Native people lived and were taught the Catholic religion. The mission buildings of this century, in Florida and in the Southwest, survive only as remains in the ground that archaeologists dig up. Native mounds and stone buildings of earlier centuries, such as Monks Mound and Cliff Palace, were standing then, and they still stand today.

### Where did St. Augustine begin?

St. Augustine, Florida, began in a Native town. Pedro Menéndez de Avilés landed at Seloy, a town of the Timucua people, on September 8, 1565. The Spanish made their first settlement in Seloy's village. People have lived in St. Augustine without a break ever since. Of all the cities that Europeans founded on the mainland of the United States, it is the oldest that people never left.

Francis Drake and his men burned the town in 1586. The only landmark left from this century is the place where the Spanish settled. Nothing they built there in the 1500s survives above ground. The stone fort that still stands in St. Augustine, about a mile south of Seloy, was begun in 1672.

## The 1600s

**Era 3 of 10 · The 1600s · about 9 minutes**

Spanish officials forced Native men from their towns to cut the stone for a fort at St. Augustine, in Florida. The fort still stands, and it is among the oldest buildings that Europeans put up in the United States. So are two churches of this century: a chapel in Santa Fe, New Mexico, made of adobe, bricks of mud and straw dried in the sun, and a wooden church building in Massachusetts called a meetinghouse.

### A fort built of shell stone

Spanish officials ordered a stone fort, the Castillo de San Marcos, built at St. Augustine after pirates attacked the town. About a hundred English pirates came ashore at midnight on May 28, 1668, and looted St. Augustine. They killed more than 50 Spaniards, and they said they would come back and take the town's fort.

**The order.** Queen Mariana of Spain then named Manuel de Cendoya governor of Florida. She sent him to the viceroy of New Spain, the king's highest official in Mexico, to collect 12,000 pesos, which were Spanish coins, to begin a fort of stone.

Workers broke ground on October 2, 1672, and Cendoya laid the first foundation stone that November. The last stones were set in 1695 or 1696, by different accounts. By 1696 the fort had cost close to 100,000 pesos. It is the oldest masonry fort, a fort built of stone or brick, in the continental United States.

**Stone made of shells.** The fort is made of coquina, a soft stone made of packed seashells. Workers cut the coquina from quarries, pits where stone is cut out of the ground, on Anastasia Island, across the bay from the town. They cut grooves in the rock with picks and axes, then broke the blocks loose with bars and wedges.

The largest blocks were 2 feet thick and 4 feet long. Albert Manucy, who wrote a history of the fort for the National Park Service in 1942, says six strong men "could hardly lift" one of them. Oxen dragged the blocks to a dock, and rafts carried them across the bay.

The stones are held together with mortar, a paste that hardens. Workers made lime, a white powder, for the mortar by burning oyster shells in kilns, or very hot ovens. By the spring of 1672 they had stored about 7,000 bushels of lime, measures of about 8 gallons each. The walls they built are 14 feet thick at the base and about 9 feet thick at the top.

**Two sieges.** English soldiers attacked the fort twice and failed both times. Governor James Moore of Carolina came with an army in November 1702, with Colonel Robert Daniel at his side. Almost 1,500 people crowded into the fort for safety. The siege, an attack in which an army surrounds a place and tries to force the people inside to give up, lasted about two months.

The English cannonballs did not shatter the walls. The shell stone crushed inward where each ball hit, so the balls sank into the wall or bounced off. When a Spanish force arrived to help, the English set fire to their own ships and retreated. As they left, Daniel's troops and their Native allies burned the rest of St. Augustine to the ground.

The fort and the people inside it survived. General James Oglethorpe of Georgia besieged the fort for 27 days in 1740, and he failed too. The fort is now the Castillo de San Marcos National Monument.

### Who cut the stone?

Spanish officials forced Native men to work on the Castillo and in the king's corn fields near the town. At times up to 300 Native people were working for the Spanish king in St. Augustine, counting the men in the fields as well as the men on the fort. The men came from three nations: the Guale of what is now Georgia, the Timucua of eastern Florida and the Apalache of western Florida.

Officials drafted the men in their home towns, which means they ordered them to come and work. Some of the men had to walk about 200 miles to reach St. Augustine. Manucy wrote that "many of them served unwillingly." A drafted man had two choices. He could bring his family with him, or he could leave his wife and children in the village to feed themselves.

**Past their terms.** Each group of drafted men was supposed to work for a set time and then go home, but officials often held the men long past it. They drafted even some chiefs, and one chief was forced to work on the fort for more than three years without once going home. Some governors used Native men as their own servants. Years before the work on the Castillo began, Spanish officials had sentenced the Apalache to forced labor on the forts as a punishment for rebelling.

**The pay.** The Native laborers were paid 1 real, a Spanish silver coin, a day, plus a daily share of corn. Manucy counted the real as worth 12 and a half cents, and a park handbook written in 1993 puts it at about 20 cents. Spanish master masons on the same job earned 20 reales a day.

The fort alone needed about 150 laborers: 50 to quarry and haul the stone, 50 to gather oyster shells and help at the lime kilns, and 50 to dig trenches, carry sand and mix mortar. Officials found it hard to get even 100. In the first winter a sickness the Spanish called El Contagio, "the contagion," spread among the Native laborers, and the crew shrank to almost no one. Manucy's history does not count how many men died.

**No names.** The payrolls, the lists of workers and their pay, counted the Guale, Timucua and Apalache men who cut the stone. Manucy's history and the 1993 park handbook were both written from those payrolls. They give the men's nations and numbers, but not their names.

**Convicts and enslaved men.** Spanish officials also put convicts on the fort, men sentenced to forced labor there for a set number of years. One Spaniard caught smuggling English goods got 6 years of labor on the fort, and his term would double if he ran away. Enslaved Black people owned by the Spanish king worked there too, and in 1687 officials added eighteen of them to the crew.

That same year, eleven people escaped slavery in Carolina and reached St. Augustine. They were eight men, two women and a nursing baby. Governor Diego de Quiroga y Losada gave them shelter and had them baptized in the Catholic Church, a ceremony with water that makes a person a member of the church.

The governor hired the men as paid workers, and six of them worked on the Castillo. In 1693 King Charles II of Spain ordered that enslaved people who escaped from the English colonies and became Catholic would be free.

### John Collins

> **Who:** An English mason the Spanish held prisoner, who made the lime and ran the quarry for the Castillo de San Marcos.
>
> **When and where:** St. Augustine, Florida, from 1670 for 19 years or more.

**He made more lime in a week than Spanish workmen in two.**

John Collins was an English mason, a builder in stone. In 1670 a ship sailing for the new English colony at Charleston, in Carolina, landed by accident at the Spanish mission of Santa Catalina, near the Savannah River. The Spanish there captured two Englishmen from the ship.

A small boat came from Charleston to get them back, and Collins and another man carried a message ashore. The Spanish held them too and sent all four men to St. Augustine as prisoners.

**Juan Calens.** Governor Manuel de Cendoya put the prisoners to work on the fort, and the Spanish payroll lists Collins as Juan Calens. According to Manucy's history, Collins could burn more oyster shells into lime in a week than Spanish workmen could in two. The lime went into the mortar that held the coquina blocks together. As a prisoner he was paid 8 reales a day, when a master workman was owed 20.

Collins rose from master of the lime kilns to master of the quarry. Later he ran the dugout boats, the food stores and the convict workers. At last he held the job of pilot, guiding ships between St. Augustine and Charleston. Officials of the Spanish king recognized his work after he had spent 19 years or more in the town.

**Not known:** Manucy's history and the 1993 park handbook do not say when he was born or died, or whether he ever went home.

### The oldest churches

San Miguel Chapel in Santa Fe, New Mexico, is often called the oldest church in the country. Its site and its foundations are that old, but most of the adobe walls standing today date from a rebuilding in 1710. The chapel was built around 1620 as a church for the soldiers, servants and laborers of the town's Spanish officials, and it was in use before 1626.

**The Pueblo Revolt.** The Pueblo people of northern New Mexico rose up against Spanish rule in 1680. Spanish officials had been collecting tribute, payments of goods, from the Pueblos, and they had used their power to keep the Pueblo people from practicing their own religion. A religious leader named Popé planned the uprising from Taos. The Pueblo people drove the Spanish out of the region, and the Spanish stayed out until 1692, when Diego de Vargas led them back.

The chapel was partly destroyed in the revolt. The histories of the chapel written for the National Park Service and the Historic Santa Fe Foundation do not say who damaged it. In 1710 Governor José Chacón had it rebuilt on the old foundations.

The Old Ship Meetinghouse in Hingham, Massachusetts, was built in 1681. The Puritans, a group of English Protestants who settled in New England, met in buildings like this one for church. It is the only Puritan meetinghouse from the 1600s still standing in the country, and the oldest church building in the United States that has been in use without a break.

**The name.** Its roof rests on a frame of heavy timbers, left open to view from inside. To the people who worshiped there, the frame looked like the hull, or body, of a ship turned upside down. That is how the building got its name.

**The two claims.** San Miguel's foundations are about 60 years older than the Old Ship Meetinghouse, but San Miguel's standing walls are about 30 years younger.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 4 minutes**

Colonists in Boston and Philadelphia put up public buildings that are still landmarks today. The first lighthouse in what became the United States was lit at the mouth of Boston Harbor in 1716, and Boston's Old North Church went up in 1723. In Philadelphia, builders began a statehouse for Pennsylvania's lawmakers in 1732. It is now called Independence Hall.

In Texas, Spanish priests ran a mission at the place later known as the Alamo. The first stone of its stone church was laid in 1744.

### The first lighthouse

Boston Light stands on Little Brewster Island, at the entrance to Boston Harbor. It was first lit on September 16, 1716, the first lighthouse in what became the United States. British forces blew up the tower in 1776. It was rebuilt in 1783, and the 1783 tower is the one that stands today.

### George Worthylake

> **Who:** The first keeper of Boston Light, who drowned with his family two years into the job.
>
> **When and where:** Little Brewster Island, Boston Harbor, 1716 to 1718.

**The keeper, his wife and their daughter drowned coming home from church.**

George Worthylake became the first keeper of Boston Light in 1716. He was paid £50 a year, 50 British pounds, to keep the light burning from sundown to sunrise. Worthylake lived on the island with his wife Ann and his daughter Ruth. He earned extra money guiding ships in and out of the harbor, and he kept a flock of sheep on Great Brewster Island, next door.

**The canoe.** The family had gone into Boston for a church sermon on November 3, 1718. Just after noon, on the way back to the island, their canoe tipped over. Worthylake, Ann and Ruth all drowned. Shadwell, a man Worthylake enslaved, drowned with them, and so did George Cutler, a servant, and John Edge, a friend of the family. Within weeks, in a second accident, two of the men hired to keep the light until a new keeper was chosen drowned near the island too.

**Franklin's song.** Benjamin Franklin was 12 years old and working for his older brother, a printer in Boston. His brother had him write a ballad about the drowning, a song that tells the story, called "The Lighthouse Tragedy." Once it was printed, Franklin's brother sent him around the town to sell copies. Franklin later called his own verses "wretched stuff," and no copy survives.

### A steeple and a statehouse

Old North Church in Boston, also called Christ Church, was built in 1723. It is the oldest church building still standing in Boston. Its steeple, the tall pointed tower on top, was finished in 1740 and is 191 feet high.

**Two lanterns.** On April 18, 1775, the church's sexton, or caretaker, Robert Newman, and Captain John Pulling Jr. hung two lanterns in the steeple. The lanterns were a signal, worked out by Paul Revere, that British troops were moving by water.

Work on the Pennsylvania State House in Philadelphia began in 1732 and ended in 1753, 21 years later. Andrew Hamilton designed it with Edmund Woolley, a master carpenter. Workers added its tower from 1750 to 1753, and in 1753 they raised a bell into it. Words on the bell read "Proclaim liberty throughout all the land." The bell later became known as the Liberty Bell.

The State House is now called Independence Hall. Leaders of the colonies debated and signed the Declaration of Independence inside it in 1776.

### The mission church later called the Alamo

A Spanish priest, Father Antonio de San Buenaventura y Olivares, founded Mission San Antonio de Valero in San Antonio, Texas, on May 1, 1718. Soldiers sent by Governor Martín de Alarcón came with him.

The people who lived at the mission came from more than a hundred Native groups, among them the Payaya, the Pamaya, the Xarame, the Apache and the Karankawa. Diseases brought by Europeans had already killed many Native people in the region. Many came to the San Antonio missions for protection from their enemies and for a steadier supply of food.

**Kept by force.** As a rule, the Spanish forced no one to come in. Once people had joined a Texas mission, though, priests and soldiers used force to keep them. Soldiers went out to bring back people, and whole groups, who left. Smallpox and measles spread through the mission in 1739. In 1745, 311 people lived there.

The cornerstone of a stone church, the first stone set at a corner of the new building, was laid on May 8, 1744. That church fell down in the 1750s. Work on the church that stands today began in 1758. The missionaries never finished it, and the bell towers and the dome they planned were never built. The records do not say who laid the church's stones.

Spanish officials closed the mission in 1793 and divided its lands among the Native people and others who still lived there.

**The Alamo Company.** From 1803 a company of Spanish soldiers lived in the old mission. They had been stationed before at Alamo de Parras, a town in what is now Mexico, so people called them the Alamo Company, and the mission took its name from them.

Texans were fighting to break away from Mexico in 1836, in a war called the Texas Revolution. That year Mexican soldiers attacked the old mission and killed the Texan soldiers defending it, 187 men by the National Park Service's count.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 6 minutes**

Enslaved people worked at every stage of putting up the first buildings of the new national capital. Leaders of the United States began building the capital beside the Potomac River in the 1790s, and its two main buildings were the President's House and the Capitol. The officials in charge rented enslaved men from their owners, and the owners collected the pay. Enslaved workers also built two houses of the time that are landmarks today, Mount Vernon and Monticello.

### Raising the capital's buildings

The land chosen for the capital had been home to the Nacotchtank people. The English captain John Smith traveled up the Potomac River in 1608 and found their villages there. European settlers brought diseases that killed many of the Nacotchtank. In colonial times most of their groups joined other Native peoples, and some moved away.

James Hoban, an architect born in Ireland, designed the President's House, later called the White House. Its cornerstone was laid on October 13, 1792. George Washington laid the cornerstone of the Capitol, the building where Congress meets, on September 18, 1793. Neither building was done by 1800. When John Adams moved into the President's House in November 1800, it was still unfinished, and the Capitol had only one wing.

### Enslaved men who built the capital

Enslaved men quarried sandstone for the President's House and the Capitol. They also cut timber, made bricks, sawed boards, did carpentry and hauled loads. The three commissioners, the officials in charge of the new District of Columbia, bought a sandstone quarry on Government Island, in Aquia Creek, in Stafford County, Virginia, for $6,000 on December 2, 1791. In the fall of 1792 they allowed the man running the quarry to rent forty enslaved men to work there, beside a number of free workers.

**Rented by the year.** William C. Allen, a historian in the office of the Architect of the Capitol, studied the Capitol's payrolls for Congress in 2005. His report states that the commissioners rented enslaved men from their owners by the year. They called this "Negro hire," using a word of that time for Black people. The Capitol's accounts list 385 payments for it between February 11, 1795, and May 17, 1801.

**Who got the money.** The money went to the owners. At first an owner got $60 a year for each man, when a white laborer with no special skills earned $70 a year. The commissioners raised the owners' rate to $70 in 1797. When a man missed work, the commissioners cut his owner's pay.

Two of the commissioners, Gustavus Scott and William Thornton, rented out men they held in slavery to the project, and Thornton also designed the Capitol. James Hoban was paid for enslaved men too. So were the commissioners' treasurer, the man who oversaw the Capitol's laborers and a land developer. Many Maryland slaveholders rented out men as well, and several of them were women, such as Ann Digges and five women of the Brent family.

The commissioners told the overseers to keep the rented men at work "from sunrise to sunset," six days a week. They housed the men in huts and gave them rations, a set share of food and drink, of salt meat and whiskey. Allen found that the overseers probably kept the enslaved sawyers, men who sawed logs into boards, at work seven days a week. For work at night, on Sundays and on holidays, the men themselves got small extra wages.

**First names only.** Only a few of the men's names were written down, and only their first names. The payment records list Dick and Tom, rented from Ann Digges in 1795, and Nace, Gerrard, David, Charles, Harry, Gabe and Sil, rented from the Brent women in April 1795. Allen wrote that "virtually nothing is known of their lives." A man named Jacob ran away from the work in 1793, and his owner offered a $6 reward for him.

**Known:** The historian Bob Arnebeck counts at least 200 known enslaved laborers on the Capitol and the President's House together.

**Not known:** the full number. Richard Baker, the Senate Historian, and Kenneth Kato of the House history office, who introduced Allen's report, wrote that no one will ever know how many enslaved people helped to build the Capitol.

### Tom, Peter, Ben, Harry, and Daniel

> **Who:** Five enslaved carpenters who helped build the White House, known only by the first names on one month's payroll.
>
> **When and where:** The President's House building site, Washington, May 1795.

**Peter and Ben each worked 28 days and got none of the pay.**

Tom, Peter, Ben, Harry and Daniel were enslaved carpenters who worked on the President's House in May 1795. The carpenters' payroll for that month lists them by their first names only. James Hoban, the architect of the building, held four of them in slavery, and his assistant, Pierce Purcell, held the fifth.

The payroll records how many days the men worked that month. Peter and Ben each worked 28 days, Daniel worked 25 and Harry worked 9. Hoban signed for their wages. The pay went to the men's owners and not to the men.

**Not known:** which of the five men Purcell held. The White House Historical Association's own accounts differ.

### Who built Mount Vernon and Monticello?

Enslaved workers built and enlarged Mount Vernon, George Washington's home in Virginia, and Monticello, Thomas Jefferson's home in Virginia.

Washington had the roof of his one-story house at Mount Vernon raised in the late 1750s to make a full second floor. The people he enslaved did most of the work, while he was away at war. He began enlarging the house again in 1774, and its last new room was finished in about 1787.

Jefferson began building Monticello in 1769 and left it unfinished in 1784. From 1796 to about 1809 he redesigned it and had it rebuilt, and enslaved workers did much of the building and made much of its fine woodwork. One of them was John Hemmings, a joiner, or maker of fine woodwork.

### Thomas Jefferson

> **Who:** The owner of Monticello, who designed his own house and worked on a design for Virginia's capitol that copied a Roman temple.
>
> **When and where:** Monticello, Virginia, 1769 to about 1809. The design for the Virginia State Capitol in Richmond, 1785.

**Virginia's capitol was modeled on an ancient Roman temple in France.**

Thomas Jefferson designed his own house at Monticello, and with a French draftsman, a man who drew building plans, he made the design for the Virginia State Capitol.

**The temple.** Virginia's Directors of Public Buildings asked Jefferson for a design for a new state capitol in Richmond in 1785. He was then the United States minister to France, the man who represented the country to the French government. The French draftsman, Charles-Louis Clérisseau, persuaded him to model the outside of the building on the Maison Carrée, an ancient Roman temple in the city of Nîmes, in France.

Clérisseau drew the final plans. A plaster model reached Richmond late in 1786 to guide the workmen, and Samuel Dobie built the capitol. A history of the building by the Virginia General Assembly, the state's lawmakers, states that the capitol "introduced the Classical Revival temple style to the modern world," a style that copies the temples of ancient Greece and Rome. The same history states that the capitol "has inspired countless public buildings for over 200 years."

**Not known:** who Dobie's workmen were, or whether any of them were enslaved. The General Assembly's history names only Dobie.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 3 minutes**

Work on two tall stone monuments, one to the Battle of Bunker Hill and one to George Washington, stopped when the people raising them ran out of money. They were among the first monuments Americans built to the Revolution and to Washington. Workers finished the Bunker Hill Monument near Boston in 1842. The Washington Monument in the capital stood at about 150 feet when work stopped in 1854, and the stump stayed unfinished for 25 years.

Enslaved craftsmen at Monticello, in Virginia, went on rebuilding Thomas Jefferson's house until about 1809. One of them, the joiner John Hemmings, made much of its fine woodwork.

### Two obelisks that ran out of money

Both monuments are obelisks, tall stone pillars with four sides that narrow toward a pointed top. The Bunker Hill Monument marks the Battle of Bunker Hill, fought on June 17, 1775, and it stands on Breed's Hill in Charlestown, Massachusetts. A group of leading citizens of the Boston area formed the Bunker Hill Monument Association in 1823 to build it.

**The cornerstone.** Daniel Webster and the Marquis de Lafayette, a French general, led the ceremony that laid its cornerstone on June 17, 1825, 50 years to the day after the battle. About 40 men who had fought in the battle came, along with about 190 other men who had fought in the Revolutionary War.

The association bought a granite quarry in Quincy, Massachusetts. Horses pulled the granite blocks three miles to the Neponset River on a railway. A National Park Service article describes it as the first horse-drawn railway built to carry goods as a business. Ships then carried the blocks to Charlestown.

**Out of money.** The association's money ran out in December 1828, after 19 months of work, and the work stopped. To pay off its debts, its leaders sold 10 acres of the old battlefield in 1839. Sarah Josepha Hale organized a Ladies' Fair at Quincy Market in Boston in 1840, and the money taken in at the fair came to more than $30,000, about a quarter of the monument's cost.

Workers finished the 221-foot granite obelisk in July 1842. It was dedicated, or opened with a public ceremony, on June 17, 1843, with President John Tyler there.

**The Washington Monument.** Work on a monument to Washington began in the capital on July 4, 1848. About 20,000 people watched members of the Washington National Monument Society lay the cornerstone. By 1854 the society's money was gone, and work stopped at about 150 feet.

**The Pope's stone.** In March 1854, members of the Know-Nothing movement, a political movement against Catholics, stole a block of marble meant for the monument. Pope Pius IX, the head of the Catholic Church, had given it. By the usual account, the thieves threw the stone into the Potomac River, and it was never found. Know-Nothings took control of the monument society from 1855 to 1858. The stump of the monument stood unfinished until 1879.

### The Smithsonian Castle

James Smithson, an English chemist who never set foot in the United States, left his fortune to the country in his will, to found the Smithsonian Institution. Workers put up the Smithsonian Institution Building, of red sandstone, from 1847 to 1855, and the money for the work came from the interest that Smithson's gift had earned. The architect James Renwick Jr. designed it, and its cornerstone was laid on May 1, 1847. People call it the Castle.

### John Hemmings

> **Who:** An enslaved joiner who made the fine woodwork of Monticello's rebuilt rooms, and one of only five people Jefferson freed in his will.
>
> **When and where:** Monticello and Poplar Forest, Virginia. Born 1776, died 1833.

**Of more than 600 people Jefferson enslaved, his will freed five.**

Thomas Jefferson held John Hemmings in slavery at Monticello. From the age of 17, Hemmings learned the joiner's trade from white joiners whom Jefferson hired.

When Jefferson rebuilt Monticello, Hemmings made the fine woodwork of the remodeled rooms and much of the furniture. He also led the woodwork at Poplar Forest, Jefferson's other house in Virginia.

**Freed by the will.** Jefferson enslaved more than 600 people during his life, and in his will he freed five of them. Hemmings was one of the five, and he became free in 1826. Jefferson also left him the tools of the joiner's shop.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 10 minutes**

The Washington Monument, finished in 1884, was the tallest structure in the world at 555 feet. In New York, workers hung the Brooklyn Bridge from cables, and at least 21 of them died. Other workers raised a bronze statue onto the new dome of the Capitol and set up the Statue of Liberty in New York Harbor. As St. Louis grew, between 1850 and 1904, people dug away almost all of the Native mounds that had stood there for centuries.

### The Statue of Freedom

Workers set the last section of a bronze statue called Freedom on top of the new dome of the Capitol on December 2, 1863. Clark Mills, a sculptor who had taught himself, cast the statue from 1860 to 1862 in his foundry, a workshop where metal is melted and poured into molds. One of the men who cast it was Philip Reid, whom Mills held in slavery.

### Philip Reid

> **Who:** An enslaved foundry worker who helped cast the Statue of Freedom for the dome of the Capitol, and who was free by the day it was raised.
>
> **When and where:** Clark Mills' foundry, Washington, 1860 to 1863.

**Reid kept Sunday's pay, and his owner took the other six days.**

Philip Reid worked out how to take apart the plaster model of the Statue of Freedom so it could be cast in bronze. He was born in slavery in Charleston, South Carolina, in about 1820, and Clark Mills bought him there. Mills said he paid $1,200 for Reid "because of his evident talent for the business."

**The puzzle.** An Italian sculptor on the job refused to show how to take the model apart unless he got a raise in pay. Reid worked out how to separate the sections himself, using a pulley and tackle, a set of ropes and wheels for lifting heavy loads.

**The pay.** Reid earned $1.25 a day, but he kept only Sunday's pay. Mills collected the pay for the other six days of each week.

**Free.** President Abraham Lincoln signed the District of Columbia Compensated Emancipation Act on April 16, 1862. It was a law for setting free, or emancipating, the enslaved people of the capital, and Reid became free that day.

Under the law, owners who had stayed loyal to the Union, the side of the United States government in the Civil War, could be paid, or compensated, up to $300 for each person. The government of the District of Columbia counts 3,100 people freed under it, and the US Senate's history office counts 2,989.

When the last section of Freedom was set on the dome in December 1863, Reid had been free for more than a year and a half. He later signed his name Philip Reed.

### The Brooklyn Bridge and the bends

The Brooklyn Bridge, in New York, opened on May 24, 1883. It is a suspension bridge, which means its roadway hangs from cables strung between tall towers. At least 21 workers died building it, and most of the dead were immigrants.

**How many died.** The counts differ. The historian David McCullough counted 21 deaths. C. C. Martin, an assistant engineer on the bridge, told the *Brooklyn Eagle* newspaper that 27 men died in accidents. E. F. Farrington, the head mechanic on the job, said the number could be as high as 40.

The towers stand on caissons, huge boxes, open underneath, that were sunk to the bottom of the river. Men worked inside them, digging out the riverbed in air pumped in under pressure to keep the water out.

**The bends.** When men came up out of that air too quickly, bubbles of gas formed in their blood. The bubbles caused great pain in the joints, and they could leave a man paralyzed, unable to move parts of his body, or kill him. This illness is called caisson disease, or the bends.

Dr. Andrew Smith, the bridge company's doctor, gave it the name caisson disease. Between January 25 and May 31, 1872, he treated 110 cases among the roughly 600 men who worked in the air under pressure. Three of them died of it.

Caisson disease killed John Myers on April 22, 1872, Patrick McKay eight days later, and Daniel Reardon within the month. After those deaths, Washington Roebling, the chief engineer, stopped digging the New York caisson any deeper.

Other workers died too. John French and Thomas Douglas died before the caisson deaths, and Neil Mullen died in 1877. In 1878 a strand of cable snapped at the Manhattan end and threw Thomas Blake and Harry Supple, two men from Newfoundland, to their deaths. Caisson disease also crippled many workers who lived.

### John, Washington, and Emily Roebling

> **Who:** The man who designed the Brooklyn Bridge, the son who took charge of building it, and the son's wife, who carried his instructions to the engineers for 11 years.
>
> **When and where:** New York, 1869 to 1883.
>
> **Movie:** *Brooklyn Bridge* (1981), Ken Burns' first documentary, narrated by David McCullough. It was nominated for the Academy Award for Best Documentary Feature. It is about the bridge and the Roeblings.

**Emily Roebling rode across first, holding a live rooster.**

John A. Roebling designed the Brooklyn Bridge, but he died before building began. In June 1869 he was measuring the site for a tower when a ferry crushed his foot against the posts that held up the dock.

Doctors told him the foot should be cut off. He refused and allowed only a water treatment, with cold water dripped steadily onto the wound. His crushed toes were cut off, and tetanus, an infection from a wound that makes the muscles tighten and lock, set in. He died on July 22, 1869.

**The son.** His son, Washington Roebling, took over as chief engineer. He went down into the caissons with the workers and got caisson disease. He collapsed in 1872 and was left partly paralyzed. For the next 11 years, until the bridge opened in 1883, he directed the work from a room in Brooklyn Heights, watching the bridge through a telescope.

**The son's wife.** Emily Warren Roebling carried her husband's instructions to the engineers for 11 years. She studied cable construction, the forces on a bridge and the mathematics of bridge building, so she could pass on his orders correctly and answer the engineers' questions. When the bridge's trustees, the people chosen to look after the project, tried to remove her husband, she defended him before them.

Some writers today call her the bridge's "effective chief engineer," meaning she did much of that job in practice. Washington kept the title and made the engineering decisions from his sickroom. Emily was the person the engineers dealt with every day.

When the bridge opened in 1883, Emily Roebling was the first person to cross it by carriage. She carried a live rooster as a sign of victory.

### The Washington Monument, finished

Members of Congress voted in 1876 to have the federal government take over the unfinished Washington Monument. Army engineers led by Lieutenant Colonel Thomas Lincoln Casey started work again in 1879, and the workers finished the monument on December 6, 1884.

**An aluminum tip.** On its point the workers placed a cast aluminum tip that weighed 100 ounces. Aluminum then cost about a dollar an ounce, roughly a day's wage for a laborer, and the whole tip cost $225.

The monument was dedicated on February 21, 1885. At 555 feet, it was the tallest structure in the world until the Eiffel Tower was built in Paris in 1889.

**A line in the stone.** About 150 feet up, the color of the marble changes. The stone laid after 1879 came from different beds of rock in the quarries than the stone laid from 1848 to 1854. The line shows where the work stopped for 25 years.

### Coins for Liberty's pedestal

People in France gave the money for the Statue of Liberty, and Americans had to raise the money for its pedestal, the tall stone base it stands on. Édouard de Laboulaye proposed the statue in 1865. The sculptor Frédéric Auguste Bartholdi designed it.

The statue's finished arm and torch were shown at the Centennial Exhibition, a big fair in Philadelphia in 1876 that marked 100 years since 1776. From 1877 to 1882 the arm stood in Madison Square Park in New York to draw gifts of money for the pedestal.

**Two pennies thick.** The engineer Gustave Eiffel joined the work in 1879 and designed the iron frame inside the statue. The statue's copper skin hangs on that frame, and it is 3/32 of an inch thick. In the words of the National Park Service, that is "about the thickness of two pennies placed together."

**The newspaper campaign.** The architect Richard Morris Hunt designed the pedestal, which was built from 1884 to 1886. Money for it came in slowly until 1885. That year Joseph Pulitzer, who published the *New York World* newspaper, ran a campaign in its pages. More than $100,000 came from about 120,000 donors. Most gave less than a dollar, and many of the gifts were coins from schoolchildren. Every donor's name was printed in the paper.

President Grover Cleveland led the dedication ceremony on October 28, 1886. The statue is 151 feet tall, and with its pedestal it stands about 305 feet high.

### Frédéric Auguste Bartholdi

> **Who:** The French sculptor who designed the Statue of Liberty and spent more than 15 years on it.
>
> **When and where:** Paris, 1870 to 1885. New York Harbor, dedicated October 28, 1886.

**The statue crossed the ocean in 350 pieces, packed in 214 crates.**

Frédéric Auguste Bartholdi worked on the Statue of Liberty from 1870 to 1886. He traveled to the United States in 1871, and in a little under three months he chose Bedloe's Island in New York Harbor as the site and met many of the leading people in America. He and Laboulaye set up committees in both countries to raise money.

**Hammered copper.** The statue's skin was made of thin copper sheets shaped by hammering, a method called repoussé. The arm and torch were finished in 1876, and the head and shoulders in 1878. That year the head and shoulders were shown at the Paris Universal Exposition, a world's fair. The whole statue was put together in Paris between 1881 and 1884.

Then it was taken apart again. The French ship Isère carried it across the Atlantic Ocean in 350 pieces packed in 214 crates, and it arrived on June 17, 1885. Bartholdi came back to New York with a group sent from France for the dedication in 1886.

### Mounds dug away for fill

St. Louis, Missouri, was once called the Mound City. It was built among about 40 mounds, hills of earth that Native people built between about the years 600 and 1300. As the city grew, people dug away most of them. One group of 25 mounds stood along the north riverfront, and by the 1850s all of them were gone except part of the largest, Big Mound.

**Sold for fill.** Big Mound stood about 30 to 34 feet high. Workers dug it away completely in 1869, and its earth was sold to the North Missouri Railroad to build up the beds for its tracks. The workers who removed it found 32 burials, the graves of people, in two chambers inside it.

No surviving record says what became of the bones, and no archaeologist is known to have recorded the digging. The history of the mounds written for the Landmarks Association of St. Louis does not name the men who dug the mound out or the person who sold its earth.

Before the World's Fair of 1904 in Forest Park, two more groups of mounds along the River des Peres were destroyed, 16 mounds in all. That same history does not name who destroyed them.

One mound is left in St. Louis, Sugarloaf Mound, on the south side of the city. In 1928 someone built a house on top of it. The story of how the Osage Nation got it back is in 2000 to Today.

### The largest private house

George W. Vanderbilt had Biltmore House built in Asheville, North Carolina, between 1889 and 1895. It has 250 rooms and covers about 179,000 square feet, and it is still the largest privately owned house in the United States. Vanderbilt opened it to his family on Christmas Eve, 1895.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 13 minutes**

Workers died building three of the giant landmarks that went up between 1913 and 1941. Five died on the Empire State Building and 11 on the Golden Gate Bridge. At Hoover Dam the official count is 96, and it leaves out 42 more deaths that were listed as pneumonia.

The Lincoln Memorial and Mount Rushmore went up in the same years. Mount Rushmore was carved into a mountain in the Black Hills of South Dakota, on land that members of Congress took from the Sioux in 1877, breaking a treaty, a written agreement between nations.

### The Woolworth Building

Frank W. Woolworth paid the whole $13.5 million cost of the Woolworth Building in New York himself, in cash. Workers finished it in 1913. At 792 feet, it was then the tallest building in the world. Woolworth had made his fortune from stores that sold goods for five and ten cents.

### A roped-off section at the Lincoln Memorial

At the opening of the Lincoln Memorial in Washington in 1922, a white Marine ordered Black guests into a roped-off section, apart from white guests. William Howard Taft, who led the group in charge of the memorial, told the only Black speaker to cut his speech.

**The building.** Work on the memorial to Abraham Lincoln began on February 12, 1914, Lincoln's 105th birthday. Joseph Blackburn, a member of the Lincoln Memorial Commission, the group in charge of the building, broke the ground. He had been an officer in the Confederate army, the army of the Southern states that fought to keep slavery in the Civil War. The architect Henry Bacon designed the building, and the sculptor Daniel Chester French made the seated statue of Lincoln inside.

About 50,000 people came to the dedication on May 30, 1922. The crowd was segregated, which means Black people and white people were kept apart. According to an account in Smithsonian magazine, the Marine was rough and rude as he sent the Black guests to their section. Twenty-one of them left in protest.

**The telegram.** Robert Russa Moton was the only Black speaker. A week before, on May 23, Taft sent him a telegram, a message sent by wire. Taft was the Chief Justice, the head of the US Supreme Court, and also the president of the Lincoln Memorial Commission. He wrote, "Shall have to ask you to cut five hundred words."

Taft added, "I am sure you wish to avoid any insinuation (hint) of attempt to make the occasion one for propaganda (messages meant to push people to one side)." Moton made the cuts. One passage he removed said that the work Lincoln died for was "still unfinished."

**A concert on the steps.** Marian Anderson, a famous African American singer, sang from the memorial's steps in 1939, after the Daughters of the American Revolution refused to let her sing in Constitution Hall. The group owned the hall, in Washington, and its rule allowed only white performers there. Eleanor Roosevelt, the president's wife, quit the group in protest.

Harold Ickes, the Secretary of the Interior, got President Franklin D. Roosevelt's approval for a concert at the memorial. On Easter Sunday, April 9, 1939, Anderson sang from its steps to about 75,000 people of all races.

### Whose land is Mount Rushmore on?

Mount Rushmore is carved on land that US officials promised to the Sioux in a treaty and that members of Congress later took. The Lakota, one of the Sioux peoples, call the mountain Tunkasila Sakpe, the Six Grandfathers. It stands in the Black Hills of South Dakota.

**The treaty.** In the Fort Laramie Treaty of 1868, US officials set aside a large reservation for the Sioux, and the Black Hills were part of it. The treaty states that the land was "for the absolute and undisturbed use and occupation" of the Sioux, theirs alone to live on and use. It also states that no part of it could be given up unless three-fourths of the adult Sioux men signed.

Lieutenant Colonel George Armstrong Custer led close to 1,000 soldiers and teamsters, men who drove wagons, into the Black Hills on July 2, 1874. Lieutenant General Philip Sheridan had sent them, and by the middle of August they had found gold.

**The gold rush.** Hundreds of miners rushed into the hills once the news spread. At first soldiers tried to keep them out of the land the treaty had set apart for the Sioux. In late 1875 President Ulysses S. Grant ordered the Army to leave the miners alone.

**The food law.** Members of Congress then set out to get the hills for the United States. In August 1876 they passed a law saying no more money would be spent on food for the Sioux until they gave up the Black Hills. Under it, officials would give the Sioux no more food rations, and the Sioux then depended on those rations to eat.

A group of officials led by George Manypenny brought the Sioux a paper in September 1876. It was already written, and it stated that the Sioux gave up the Black Hills. Only about one in ten of the adult Sioux men signed it, far fewer than the three-fourths the treaty required. Members of Congress made that paper a law anyway on February 28, 1877, and with it they took the Black Hills.

The judges of the US Supreme Court, who are called justices, decided the case *United States v. Sioux Nation* in 1980. Justice Harry Blackmun wrote for the court that the taking had broken the treaty. The justices agreed with an earlier award of $17.1 million for the land, plus interest, extra money of 5 percent for every year since 1877. The total came to about $106 million.

The Sioux nations have never taken the money. They say the Black Hills were never for sale. The money sits in a federal account held by the US Interior Department, and officials keep its balance secret. South Dakota Public Broadcasting put it at about $2 billion in 2022. Frank Star Comes Out, president of the Oglala Sioux Tribe, has said, "We will never sell out our holy lands, the Black Hills, to the United States for monetary compensation (payment in money)."

**The carving.** Workers carved the mountain from October 4, 1927, to October 31, 1941. According to the National Park Service, nearly 400 men and women worked there, among them drillers and blacksmiths. They did about 90 percent of the carving with dynamite and removed about 450,000 tons of rock in all.

Then drillers made rows of holes close together, a method called honeycombing, and smoothed the faces with hand tools. Workers were lowered down the 500-foot face on steel cables, sitting in bosun chairs, seats hung from a cable. No worker died in the 14 years of carving. Today the memorial's staff consult with 21 Native nations connected to the site.

### Gutzon Borglum

> **Who:** The sculptor who designed Mount Rushmore, after starting a Confederate carving in Georgia that the Ku Klux Klan helped pay for.
>
> **When and where:** Stone Mountain, Georgia, from 1923. The Black Hills of South Dakota, 1927 to 1941.

**Klan money helped pay for Borglum's carving at Stone Mountain.**

Before he carved Mount Rushmore, Gutzon Borglum went to meetings of the Ku Klux Klan and took a deep part in Klan politics, according to reports in the Washington Post and Smithsonian magazine. No record proves he was a member.

**The Klan.** Confederate veterans had started the first Klan in Pulaski, Tennessee, in December 1865. Its members whipped, burned the homes of and murdered freed Black people and the people who helped them. Federal officials put that Klan down in the early 1870s.

William J. Simmons and 16 other men climbed Stone Mountain in Georgia on Thanksgiving night in 1915. They burned a cross there and announced that the Klan was born again. Members of the new Klan preached white supremacy, the belief that white people should rule over everyone else. They were also against Catholics and Jews, and they wanted fewer immigrants let into the country.

At Stone Mountain, Borglum designed a carving of three Confederate leaders on horseback, Robert E. Lee, Stonewall Jackson and Jefferson Davis. Klan money helped pay for it. Work began in 1923, and Borglum unveiled the head of Lee in 1924.

Borglum quarreled with the businessmen who ran the Stone Mountain project, and they fired him. He then destroyed his models to protect his design, which made the directors angry. A warrant, a court paper ordering his arrest, was issued, and he fled Georgia.

Borglum began Mount Rushmore in 1927 and directed the carving until he died on March 6, 1941. His son, Lincoln Borglum, finished the work that year.

### Nick Clifford

> **Who:** The youngest worker on Mount Rushmore, and the last of its carvers to die.
>
> **When and where:** Mount Rushmore, South Dakota, 1938 to 1940. Died in 2019, at 98.

**The Borglums hired the 17-year-old partly to pitch for their baseball team.**

Donald "Nick" Clifford was 17 when he was hired at Mount Rushmore in 1938, the youngest worker on the job. The Borglums wanted him for the crew's baseball team, where he pitched.

Clifford earned 55 cents an hour. He ran the winch, a machine that winds a cable, and the cable carried men up the face of the mountain. He also drilled holes for the dynamite. He worked there until 1940.

When Clifford died on November 23, 2019, at the age of 98, he was the last of the carvers.

### The Empire State Building and the Mohawk ironworkers

Five workers died building the Empire State Building in New York, by the official count. A story that hundreds died is false.

Builders took about 410 days to put up the building, from the first steel to the opening on May 1, 1931. Up to 3,400 workers were on the job each day, and during the fastest stretch the steel frame rose about four and a half floors a week. The photographer Lewis Hine took pictures of the men working on the steel for his book *Men at Work*.

The building has 102 stories and stands 1,250 feet tall, or 1,454 feet to the tip of today's antenna. It was the tallest building in the world until 1970, when the steel frame of the World Trade Center's North Tower rose higher.

**High steel.** Some of the riveting crews were ironworkers from Kahnawake, a community of the Mohawk Nation in Canada. Ironworkers put up the steel frames of buildings and bridges, and riveters joined the steel beams with rivets, hot metal pins that lock the beams together. Kahnawake men had done this work since the 1880s.

**The Quebec Bridge.** Kahnawake ironworkers had died on an earlier job. On August 29, 1907, the south half of the Quebec Bridge fell while it was being built across the St. Lawrence River in Canada. James H. Marsh, writing in the Canadian Encyclopedia, gives 75 workers killed, and Eve Cable, writing in *The Eastern Door*, the Kahnawake newspaper, gives 76. Thirty-three of the dead were Kahnawake men.

A Royal Commission, a group set up to find the cause, blamed two engineers. Theodore Cooper, an expert brought in to oversee the design, had made mistakes in it and had lengthened the bridge to save money. John Deans, the chief engineer, kept the crews working after Cooper warned of danger.

**The women's rule.** The women of Kahnawake made sure after 1907 that the men of one family did not all work on the same job at the same time. *The Eastern Door* gives the rule this way: "If a lady had seven sons, they're not all going to the same job." Crosses made from the bridge's steel stand in the village cemetery. In 2007 a monument went up with a picture of each man who was killed and a 40-foot steel model of the bridge.

### The Golden Gate Bridge

Eleven workers died building the Golden Gate Bridge in San Francisco. One died in October 1936, and ten died on February 17, 1937, when a falling work platform tore through the safety net under the bridge. The bridge opened in May 1937, and on May 27, the first day, about 200,000 people walked across it.

**Who designed it.** Joseph Strauss was the chief engineer. Charles Ellis, the engineer who worked out how the bridge's structure would hold its weight, did the detailed design and thousands of calculations from 1929 to 1931. Strauss fired Ellis before building began, and Ellis got no public credit for decades. In a 2007 report, officials of the Golden Gate Bridge District gave Ellis the main credit for the design.

### Joseph Strauss

> **Who:** The chief engineer of the Golden Gate Bridge, who hung a safety net under the bridge while it was built.
>
> **When and where:** The Golden Gate Bridge, which opened in May 1937.

**A $130,000 net under the bridge caught 19 falling men.**

Joseph Strauss required hard hats on the Golden Gate Bridge job. He also spent about $130,000 on a safety net that hung under the bridge while it was built. It was the first large safety net used on an American bridge job.

The net caught 19 men who fell. They called themselves the Halfway to Hell Club.

### Al Zampa

> **Who:** An ironworker who fell from the Golden Gate Bridge and lived, and who later had a bridge named for him.
>
> **When and where:** The Golden Gate Bridge, October 19, 1936. From Crockett, California.

**Zampa fell into the net where it sagged down onto the rocks.**

Alfred Zampa was an ironworker from Crockett, California. On October 19, 1936, he slipped on wet steel and fell into the safety net. He was near the shore, where the net sagged down onto the rocks, and he broke four bones in his back.

Zampa spent twelve weeks in the hospital and two years in a back brace. Then he went back to ironwork. He was one of the first members of the Halfway to Hell Club and later its unofficial spokesman, the man who spoke for the club without holding any title.

California lawmakers named the new bridge over the Carquinez Strait the Alfred Zampa Memorial Bridge in 2003.

### How many men died building Hoover Dam?

By the official count, 96 men died building Hoover Dam. The count comes from the Bureau of Reclamation, the federal office that runs the dam. It includes deaths from falls, rock slides, machinery and drowning, and it leaves out deaths from heat, heart trouble and pneumonia, a sickness of the lungs. The exact number of deaths is not known.

**The 42.** The main builder was a company called Six Companies Inc. The records list 42 more workers who died of pneumonia. Workers said these men really died of carbon monoxide poisoning. They said officials of Six Companies listed the deaths as pneumonia so the company would not have to pay compensation claims, the payments owed when a worker is hurt or killed on the job.

Carbon monoxide is a gas with no color or smell that comes from burning fuel. When a person breathes it in, it stops the blood from carrying oxygen. The workers blamed the gasoline-powered vehicles running inside the diversion tunnels, which were dug to carry the river around the building site. The tunnels often reached 140 degrees Fahrenheit and filled with thick exhaust. In nearby Boulder City, no one who did not work on the dam was recorded as dying of pneumonia in those years.

**Father and son.** The first deaths on the official list came in 1922, during the surveys for the dam. J. G. Tierney drowned on December 20 of that year, and Harold Connelly also died that year. The last death on the list came 13 years to the day after Tierney's. On December 20, 1935, his son, Patrick Tierney, an electrician's helper, fell from one of the dam's intake towers, the towers that take in water.

People tell a story that men are buried inside the dam's concrete. It is false. Workers poured the dam as many separate blocks, in shallow layers, with crews standing over each pour, so a body could not have been left inside. President Franklin D. Roosevelt dedicated the dam on September 30, 1935, and its generators began making electricity in 1936.

**If you remember one thing:** Workers died building three of the giant landmarks of these years, and Mount Rushmore was carved on land that members of Congress took from the Sioux.

**96 and 42:** Hoover Dam's official count of the dead is 96. The records list 42 more workers as dying of pneumonia, deaths that workers blamed on carbon monoxide in the tunnels.

**Next:** After 1950, two men climbed the unfinished Gateway Arch in St. Louis to protest who was kept off the job.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 7 minutes**

Americans in these years fought over who was allowed to build a landmark and over what a memorial to the dead should look like. In St. Louis, Justice Department lawyers later charged in court that leaders and members of the building trades unions kept Black workers out of the unions, and so off the job building the Gateway Arch. Two men climbed the unfinished arch in protest.

In Washington, critics attacked the design of the Vietnam Veterans Memorial, a black stone wall set into the ground. The names of more than 58,000 Americans who died in the Vietnam War are cut into it, and it was dedicated in 1982. Builders also put up two towers in New York, one of them for a few years the tallest building in the world, and workers restored older landmarks, including the Statue of Liberty and Ellis Island.

### The Space Needle

Builders put up the Space Needle in Seattle in about 400 days for a world's fair called the Century 21 Exposition. It opened on April 21, 1962, the first day of the fair. The tower is 605 feet tall, with a restaurant on top that turns around.

### The Gateway Arch and the men kept off the job

The Gateway Arch in St. Louis is 630 feet tall and 630 feet wide, and its outside is stainless steel. The architect Eero Saarinen won the contest to design it, and the winner was announced in February 1948. Saarinen died in 1961, before building began. Workers built the arch from February 12, 1963, to October 28, 1965. Insurers had predicted 13 deaths, and no worker died.

Black workers were kept out of the building jobs on the arch, a federal monument. In St. Louis, the building trades unions, groups that carpenters, plumbers, ironworkers and other builders join to bargain together for jobs and pay, had almost all white members. Justice Department lawyers later charged in court that the leaders and members of these unions kept Black men out of the unions and so out of the jobs.

**The climb.** Percy Green and Richard Daly climbed a 125-foot construction ladder on the unfinished north leg of the arch on July 14, 1964. The two men were activists, people who campaign for a cause, and they climbed to protest. An article by the Gateway Arch Park Foundation states that they stayed up for 6 hours, and a St. Louis Public Radio report states that Green was up there for more than four hours. Police arrested both men.

Green later helped start ACTION, a St. Louis group that worked for fair hiring. ACTION stood for the Action Committee to Improve Opportunities for Negroes, a word of that time for Black people.

Two Black plumbers, Elijah Smith and Oliver Parker, were hired to work on bathrooms in the arch's visitor center. White union workers walked off the job on January 7, 1966, to protest the hiring of the two men.

**The lawsuit.** Lawyers in the US Justice Department sued the St. Louis Building and Construction Trades Council and five of its unions about a month later, on February 4, 1966. They charged the unions under the Civil Rights Act of 1964, which made it against the law for unions and employers to treat workers unfairly because of their race.

Officials of several of the unions settled the case. They signed an agreement to end "all practices that were discriminatory," meaning every rule and habit that kept Black workers out, and to judge everyone who applied by the same written standards. Two unions, the sheet metal workers and the electricians, fought the case in court. A judge ruled for them in 1968. In 1969 appeals judges overturned that ruling, found that the two unions' rules still kept Black workers out, and ordered the rules changed.

### Harold McComber

> **Who:** A Mohawk ironworker from Kahnawake, in Canada, who left home to work on the steel frames of Manhattan skyscrapers.
>
> **When and where:** Manhattan and Kahnawake, filmed in 1965.
>
> **Movie:** *High Steel* (1965), a documentary by the National Film Board of Canada, directed by Don Owen. It is about McComber's working life.

**McComber's sons grew up without him while he built New York skyscrapers.**

Harold McComber was a Mohawk ironworker from Kahnawake, in Quebec. Like many Kahnawake men, he left home to work on the steel frames of skyscrapers in Manhattan.

The director Don Owen built his 13-minute documentary *High Steel* around McComber's working life, and the National Film Board of Canada produced it in 1965. The film shows McComber and the men he worked with on the steel high above New York City. It also shows the quieter life of their community at home. To film the men at work, the camera crew reached the site by crossing on a ladder from the building next door.

In the film, McComber is sorry that his sons have had to grow up without their father. The film also tells how Kahnawake men first earned their name for steelwork, on a railway bridge built in the late 1800s.

### The World Trade Center

The architect Minoru Yamasaki designed the two towers of the World Trade Center in New York, each 110 stories tall. The ribbon-cutting was on April 4, 1973. The North Tower stood 1,368 feet. Its steel frame had passed the height of the Empire State Building in 1970, which made it the tallest building in the world. It kept that title until May 1973, about a month after the ribbon-cutting, when the steel frame of the Sears Tower in Chicago rose higher.

### Philippe Petit

> **Who:** A French high-wire walker who walked on a cable between the two towers of the World Trade Center.
>
> **When and where:** New York, August 7, 1974.
>
> **Movie:** *Man on Wire* (2008), directed by James Marsh. It won the Academy Award for Best Documentary Feature and is about the walk.

**Petit crossed between the towers eight times in 45 minutes.**

Philippe Petit walked on a wire strung between the tops of the Twin Towers, about 1,350 feet above the ground, on August 7, 1974. He and his friends had smuggled a cable up to the roofs and strung it from one tower to the other. Petit crossed eight times in 45 minutes.

Afterward police arrested him. The charges against him were dropped. In return, he put on a show for children in Central Park.

### The Vietnam Veterans Memorial and its critics

Two long walls of polished black granite, set into the ground of the National Mall in Washington, form the Vietnam Veterans Memorial. The names of more than 58,000 Americans who died in the Vietnam War are cut into the stone, in the order they died. It was dedicated on November 13, 1982, and it became the most visited memorial in Washington.

**The attacks.** Critics attacked the design before it was built. One veteran called it "a black gash (a deep cut) of shame." Another critic said that burying the dead "in a black stone sarcophagus," a stone coffin, "is like spitting on their graves." Opponents of the design included the radio host Patrick Buchanan and Congressman Henry Hyde. They campaigned to make the wall white and to add an eight-foot statue of soldiers.

The members of the US Commission of Fine Arts, a federal board that reviews designs in Washington, kept the wall. They also added a statue of three soldiers by Frederick Hart nearby, in 1984. Hart's design had won third place in the contest for the memorial.

### Maya Lin

> **Who:** The 21-year-old college student whose design won the contest for the Vietnam Veterans Memorial.
>
> **When and where:** Yale University and Washington, 1981 to 1982.
>
> **Movie:** *Maya Lin: A Strong Clear Vision* (1994). It won the Academy Award for Best Documentary Feature and is about Lin.

**Entry number 1026 beat 1,420 others.**

Maya Lin was a 21-year-old architecture student at Yale University when she won the contest to design the Vietnam Veterans Memorial. She had first drawn the design for a class. She was born in Ohio, where her parents were professors. They had escaped from mainland China as young adults.

**The contest.** It was the biggest design competition held in the United States up to then. The judges looked at the entries without knowing who had made them, and they chose entry number 1026 over 1,420 others. In May 1981 officials came to Lin's college room to tell her she had won the $20,000 first prize.

**The critics.** Lin argued against the campaign to make her wall white and add a statue, and she said Congressman Henry Hyde was "drawing mustaches on other people's portraits." Some of the wall's critics also used her age and her Chinese family background as reasons to change the design or drop it. The speakers at the dedication in 1982 did not mention her.

### Restoring the old landmarks

Workers restored the Statue of Liberty for its 100th birthday from 1984 to 1986. They took down its original 1886 torch in 1984, and it is now in the statue's museum. In its place they put a copy made of copper and covered in gold leaf, thin sheets of gold. The statue was dedicated again on July 4, 1986.

Ellis Island, in New York Harbor, was where federal officials checked arriving immigrants. On May 11, 1965, President Lyndon B. Johnson signed Proclamation 3656, a formal order from the president, under which Ellis Island became part of the Statue of Liberty National Monument. Ellis Island's main building had opened in 1900. Workers restored it, and in 1990 it opened as a museum of immigration.

On the West Coast, from 1910, US officials held immigrants in barracks on Angel Island, in San Francisco Bay. Chinese immigrants held there had carved more than 200 poems into the barracks walls, and in 1970 the poems were found again. After that, people campaigned to save the barracks. In 1997 Angel Island Immigration Station became a National Historic Landmark.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 12 minutes**

Memorials to people who were killed or enslaved went up after 2000: to the victims of the September 11 attacks, to the Black Americans murdered by mobs without a trial, and to the people held in slavery. In the same years, officials and work crews took down, moved or renamed hundreds of memorials to the Confederacy, the Southern states that fought to keep slavery in the Civil War.

These memorials include statues and place names. Researchers at the Southern Poverty Law Center, a group that campaigns for civil rights, counted 415 of them removed, moved or renamed between 2015 and April 2025, and 2,086 still standing. In 2025 federal officials began putting some of the removed monuments back.

### Ground Zero rebuilt

The National September 11 Memorial in New York stands where the Twin Towers stood. On September 11, 2001, hijackers took over four airliners. They crashed two of them into the North Tower and the South Tower, and fires from the crashes made both towers collapse. They crashed a third into the Pentagon, the headquarters of the US military, near Washington, and the fourth, Flight 93, also crashed.

**The dead.** The hijackers killed 2,977 people, not counting the 19 hijackers themselves, according to the 9/11 Memorial and Museum. Of those, 2,753 were killed in New York, 184 at the Pentagon and 40 on Flight 93.

The memorial opened on September 11, 2011, ten years after the attacks. It has two pools set into the footprints of the two towers. Each pool covers nearly an acre. Water falls 30 feet into each pool and then drops another 20 feet. Around the edges, bronze panels carry the names of 2,983 people. They are the people killed on September 11, 2001, and the six people killed in an earlier bombing of the towers in 1993.

The design, called *Reflecting Absence*, won a contest in 2004 that drew 5,201 entries from 63 countries. The museum under the memorial opened on May 21, 2014. On November 3, 2014, One World Trade Center opened nearby. It stands 1,776 feet to the tip of its spire. The height was chosen to match 1776, the year of the Declaration of Independence.

### Michael Arad

> **Who:** The architect, then 34 and working for New York City, whose design for the National September 11 Memorial was chosen from 5,201 entries.
>
> **When and where:** New York. He won the design contest in 2004, and the memorial opened in 2011.

**His first sketches showed two empty spaces in the Hudson River.**

Michael Arad was 34 years old and working as an architect for a New York City government office when he entered the contest for the memorial. In his first sketches, he pictured two empty spaces cut into the surface of the Hudson River. His finished design put two pools where the towers had stood.

Arad worked with the landscape architect Peter Walker, who plans outdoor spaces such as parks. The contest judges chose their entry from 5,201 in 2004.

### New memorials in Washington

New memorials to Black Americans went up in Washington after 2000. The Martin Luther King, Jr. Memorial was dedicated on October 16, 2011, the first memorial to an African American in the area of the National Mall. At its center is a 30-foot carving called the Stone of Hope.

**The Capitol's builders.** Members of Congress unveiled a marker to the enslaved workers who helped build the Capitol on February 28, 2012, in Emancipation Hall, the great hall of the Capitol Visitor Center. The marker is a block of Aquia Creek sandstone taken from the Capitol's East Front, which was built from 1824 to 1826. Its plaque states that the stone "was quarried by laborers, including enslaved African Americans, and commemorates (honors) their important role in building the Capitol."

The National Museum of African American History and Culture opened on September 24, 2016, beside the Washington Monument. It is part of the Smithsonian. The architect David Adjaye led its design. He based the building's outside, a bronze-colored shape in three levels called the corona, on the art of the Yoruba, an African people. The pattern of its metal screen is copied from ironwork made by enslaved and free Black craftsmen in the South.

### Memorials to lynching and slavery

The National Memorial for Peace and Justice, in Montgomery, Alabama, is a memorial to Black people who were lynched, killed by a mob without a trial. The lawyer Bryan Stevenson founded the Equal Justice Initiative (EJI), a legal group that does not make a profit. EJI built the memorial and opened it on April 26, 2018, with a museum called the Legacy Museum.

**805 blocks.** The memorial holds 805 steel blocks, each six feet tall, hanging from above. Each one stands for a county in the United States where EJI researchers found a record of a lynching. In their study *Lynching in America*, EJI researchers counted almost 4,400 lynchings of Black people from 1877 to 1950.

A copy of each county's block stands at the site, and EJI offers each copy to groups in that county to set up at home. A team called MASS Design Group designed the memorial, and it cost about $20 million, paid by private foundations.

**122,000 names.** EJI opened the Freedom Monument Sculpture Park nearby in March 2024, on 17 acres with nearly 50 sculptures. Its National Monument to Freedom lists more than 122,000 last names taken from the 1870 census, the government's count of everyone in the country that year. That census was the first time people who had been enslaved could claim a last name that the government would recognize. In it, nearly five million Black people took these names as their own.

The monument stands 43 feet tall and 155 feet long, and EJI dedicated it on Juneteenth, June 19, 2024. Juneteenth marks June 19, 1865, the day Major General Gordon Granger of the US Army reached Galveston, Texas, with the news that enslaved African Americans were free.

### Confederate monuments coming down and going back up

**Who put them up.** Members of the United Daughters of the Confederacy had put up hundreds of Confederate statues at courthouses and other public places since the Civil War, researchers at the Southern Poverty Law Center (SPLC) reported in 2018. The researchers found two main periods of building.

The first began around 1900, while lawmakers in Southern states were passing Jim Crow laws, which they wrote to force Black and white people apart and to take away Black people's rights. The second ran from the early 1950s through the 1960s, when segregationists, people who wanted to keep the races apart, fought the civil rights movement.

Hundreds of these memorials came down or were renamed after people were killed in three places: Charleston, Charlottesville and Minneapolis.

**Charleston.** A 21-year-old white man named Dylann Roof sat in on a Bible study at the Emanuel African Methodist Episcopal Church in Charleston, South Carolina, on June 17, 2015. After about an hour he opened fire and killed nine Black worshippers. Roof had posted pictures of himself with Confederate flags on his website, and he had written racist views there. A federal jury found Roof guilty of all 33 federal charges against him on December 15, 2016, and the federal court sentenced him to death on January 10, 2017.

The Confederate battle flag had flown at the South Carolina State House, in Columbia, since 1961. After the murders, state lawmakers voted to take it down, and Governor Nikki Haley signed the law on July 9, 2015. The next day an honor guard of the state Highway Patrol lowered the flag, and it went to the Confederate Relic Room at the state museum.

**Charlottesville.** Paul Goodloe McIntire paid for a statue of the Confederate general Robert E. Lee in Charlottesville, Virginia, and it was dedicated in 1924. The members of the city council voted 3 to 2 on February 6, 2017, to remove it. City workers took the statue down on July 10, 2021, and city officials gave it to the Jefferson School African American Heritage Center. In October 2023 the staff of the center's Swords into Plowshares project had the statue melted down at a foundry.

**The rally.** White supremacists organized a rally called Unite the Right around the statue for August 2017, six months after the council's vote. On August 12 James Alex Fields Jr. drove his car into a crowd of people protesting against the rally. He killed Heather Heyer, a 32-year-old paralegal, a worker who helps lawyers, and injured many others. Counts of the injured run from 19 to 29.

A Virginia jury found Fields guilty in December 2018 of first-degree murder, the most serious kind of murder, done on purpose. In 2019 he pleaded guilty to 29 federal hate crimes, crimes against people chosen because of their race, religion or a similar trait, and a federal judge sentenced him to life in prison.

**Minneapolis.** Minneapolis police officer Derek Chauvin murdered George Floyd on May 25, 2020, by kneeling on his neck, back and shoulder for about ten minutes. A jury convicted Chauvin of murder in 2021. Protests followed Floyd's murder, and SPLC researchers counted at least 168 Confederate symbols removed in 2020 alone.

Virginia Governor Ralph Northam ordered the removal of Richmond's Lee statue, a 12-ton monument put up in 1890, in June 2020. The judges of the Supreme Court of Virginia then refused to block the removal in two lawsuits. A crew led by Devon Henry, who owned the construction company doing the work, took the statue down on September 8, 2021, ABC News reporters wrote.

SPLC researchers counted 2,086 Confederate memorials still standing in public places in April 2025. In their count, memorials include place names and other symbols as well as monuments such as statues, and 685 of the 2,086 were monuments. Rivka Maizlish of the SPLC called the memorials "the results of a mass propaganda campaign," meaning a huge effort to push one side of the story.

**Going back up.** Federal officials began putting some monuments back in 2025. Protesters had pulled down a statue of the Confederate general Albert Pike in Washington in June 2020 and set it on fire. National Park Service workers put it back up in October 2025. They cited a historic preservation law and an executive order, a written command from the president, that President Donald Trump had signed on restoring removed monuments.

Members of the United Daughters of the Confederacy put up the Confederate Memorial at Arlington National Cemetery in 1914. The sculptor, Moses Ezekiel, had fought for the Confederacy. The memorial shows "an enslaved man following his owner to war." It also shows an enslaved woman as a "mammy," holding a white officer's child.

The "mammy" was a made-up picture of an enslaved Black woman who cared for a white family's children and seemed happy in slavery. The picture hid the truth that enslavers separated these women from their own children. A commission set up by Congress found that the memorial showed "highly sanitized depictions of slavery," pictures of slavery with the cruelty cleaned out.

On that commission's advice, the memorial was taken down in December 2023. *Stars and Stripes*, the newspaper that reported it, does not say who did the work. In August 2025 Defense Secretary Pete Hegseth announced that it would return in 2027, and *Stars and Stripes* reported that the repairs would cost about $10 million.

### Who took down the slavery exhibit in Philadelphia?

National Park Service workers took down an exhibit about slavery in Philadelphia in 2026. A federal judge ordered it put back, but appeals judges later let officials of the Trump administration replace it with panels of their own. The President's House site marks where George Washington lived while he was president. Its exhibit panels described the lives of nine people Washington held in slavery there.

**The court case.** The workers removed the panels in January 2026, following President Trump's executive order called "Restoring Truth and Sanity to American History." Lawyers for the City of Philadelphia sued. On February 16, 2026, US District Judge Cynthia Rufe ordered the panels restored while the case went on, and workers began putting them back three days later.

Lawyers for the federal government appealed, which means they asked a higher court to change the ruling. On June 18, 2026, judges of the Third Circuit Court of Appeals ruled that the city had no right to decide what the exhibit showed. On July 15 officials of the Trump administration replaced the old panels with their own.

The new panels still describe the nine enslaved people, but they leave out some of the old panels' detail, such as a map of the routes of the slave trade and a timeline of slavery. As of September 2026, the administration's panels were in place, and the city's case was still going on in the lower court.

### Old landmarks, new names and owners

Sugarloaf Mound, on the south side of St. Louis, is the only one left of the roughly 40 mounds that Native people built in the city. People dug away all the others as the city grew, Big Mound and its 32 burials among them, as 1850 to 1900 describes. Someone built a house on top of Sugarloaf Mound in 1928.

**Back to the Osage.** The Osage Nation bought that house and about a third of the mound in 2009, and had the house torn down in 2017. In 2025, working with an arts group called Counterpublic, the Osage Nation got the last two pieces of the property transferred to it. The Osage Nation's announcement describes Sugarloaf Mound as a sacred Osage site.

Afterward Andrea Hunter, the Osage Nation's Historic Preservation Officer, said, "It has been a long 17-year journey, and I am thrilled to finally see the entire mound come under Osage Nation control." She said her office must now "remove all the structures from the properties and stabilize (make firm) the mound." Osage leaders plan to build a center there to teach visitors about the mound.

**New names.** Workers finished restoring the barracks of the Angel Island Immigration Station in California in 2009. On February 22, 2018, President Donald Trump signed a law under which the Jefferson National Expansion Memorial in St. Louis, the grounds of the Gateway Arch, became Gateway Arch National Park. It is the smallest national park in the country.

**The three questions, answered**

- Who built the White House and the Capitol, and who was paid for their work? Enslaved men did much of the work, from quarrying the stone to sawing boards and hauling loads. The officials in charge rented them from their owners by the year, and the owners collected the pay.
- How many workers died building Hoover Dam? By the official count, 96. The records list 42 more as dying of pneumonia, deaths that workers blamed on carbon monoxide in the tunnels, so the exact number is not known.
- What has happened to the Confederate monuments since 2015? By April 2025 officials and work crews had taken down, moved or renamed 415 Confederate memorials, from statues to place names. Hundreds of them came down or were renamed after Dylann Roof killed nine Black worshippers in Charleston in 2015, James Alex Fields Jr. killed Heather Heyer in Charlottesville in 2017 and the police officer Derek Chauvin murdered George Floyd in Minneapolis in 2020. In 2025 federal officials began putting some back.

**What changed:** No one wrote down who built the oldest landmarks here, and since 2000 Americans have built memorials to the enslaved and the murdered and fought over monuments to the Confederacy.

**Five dates to keep**

- October 2, 1672: Workers break ground for the Castillo de San Marcos.
- September 18, 1793: George Washington lays the cornerstone of the Capitol.
- February 28, 1877: Members of Congress take the Black Hills from the Sioux.
- May 24, 1883: The Brooklyn Bridge opens, after at least 21 workers died building it.
- June 17, 2015: Dylann Roof kills nine Black worshippers in Charleston.

**Not known:** Nobody knows how many enslaved people helped to build the Capitol, and two congressional historians wrote that no one ever will.

**Where to go:** The Octagon Earthworks in Newark, Ohio, a golf course from 1910 to 2024, opened to the public on January 1, 2025.

**Next:** Chapter 13, The Elements. It describes the copper, iron, gold and other elements that people here dug up, used and discovered.
