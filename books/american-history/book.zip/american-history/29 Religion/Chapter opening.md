**Part 8: Faith, Learning, and News**

# Chapter 29: Religion

**Chapter 29 of 37 · Religion · 10 eras · about 200 minutes**

**Freedom of worship in the United States grew one fight at a time, and most of those fights were started by people who were being punished for their faith.**

A statue of a Pueblo man named Po'pay stands in the US Capitol in Washington. New Mexico gave it to the National Statuary Hall Collection in 2005. The sculptor, Cliff Fragua of Jemez Pueblo, carved scars on its back. In 1675 Spanish officials had Po'pay whipped in public for taking part in Pueblo ceremonies. Five years later he led the rising that drove the Spanish out of New Mexico for twelve years.

This chapter follows faith in America from the sun posts at Cahokia to the shootings of worshippers at prayer in this century. First, watch who was punished for the way they worshipped, and who did the punishing: Quakers hanged in Boston, Catholic churches burned in Philadelphia, Native dancers whose food was cut off, Black churches bombed. Then watch the people who pushed back, from Baptists who organized against the church tax to families who took their cases to the Supreme Court. Revivals, meetings meant to stir people to a stronger faith, run through the chapter too. By the early 1800s the Presbyterians, Baptists and Methodists who backed them were the largest Protestant churches in the country.

**Three questions this chapter answers**

- Why did colonists who crossed the ocean to worship freely punish other people for their faith?
- How did Americans stop paying taxes to support churches?
- How long did US officials treat Native ceremonies as crimes?

**Five minutes?** Read the Mary Dyer story in The 1600s, "How Virginia ended its church tax" in 1750 to 1800, and "Hiram Price's rules against ceremonies, 1883" in 1850 to 1900.

**Can skip:** "Three more colleges with church backing", "Laws against teaching evolution, 1921 to 1929", "Worship on a screen", "Teaching religion at home". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 4 minutes**

Hundreds of Native nations lived on this land before 1500, and each one had its own religious life. So there were hundreds of Native religions, and many are still practiced today. The nations shared no holy book and no single founder. Each held its ceremonies in a set place, at a set season, with its own community.

No written account of these religions survives from before the 1500s, because the written record of this land begins with the Europeans who came then. What is known comes from two places. One is what people built and buried. The other is the traditions that the nations kept and still keep.

### What the ground can show, and what it cannot

Archaeologists, scientists who dig up and study old buildings, graves and objects, can measure which way a doorway faces. They can check whether the sun rises in line with it on a certain day. A wall lined up with the midwinter sunrise shows that the builders lined it up on purpose. It does not show what the builders believed.

The nations themselves hold spoken histories that go back before 1500, and the people of each nation decide how much of that to make public. Written descriptions of Native religions begin after 1500. Europeans wrote them from the outside, and most of those writers were hostile to the religions they described. Many were missionaries, people sent to turn others to their own religion.

### Chaco Canyon

Chaco Canyon, in what is now northwestern New Mexico, holds large stone buildings of many stories. People there began building them in the middle and late 800s, and today they are called great houses. Three of the first were Pueblo Bonito, Una Vida and Peñasco Blanco. Building went on in the canyon for more than 300 years.

The builders lined many great houses up with the sun, the moon, and north, south, east and west. They also built roads out from the canyon. The roads joined it to more than 150 other great houses across the region.

Pueblo people are the descendants of the people of Chaco. They say Chaco was a gathering place where many peoples and clans, groups of families who count themselves as related, came together to share their ceremonies and knowledge. Many Native people of the Southwest also say that Chaco is an important stop on their clans' sacred migration paths. Those are the routes their peoples traveled as they moved from one home to another.

### Cahokia and its circle of posts

Cahokia stood in what is now Illinois, a few miles east of the Mississippi River and of present-day St. Louis, Missouri. People lived there mainly between about 800 and 1400. It was the largest town in North America north of Mexico before Europeans came. National Park Service figures put the number of people living in Cahokia itself at 10,000 to 20,000.

The people of Cahokia built about 120 mounds of earth. Some held public buildings on top, and others held graves. The biggest is now called Monks Mound, and no earth structure that Native people built north of Mexico is larger. It went up in fourteen stages. It rises in four steps, called terraces, to about 100 feet.

**Woodhenge.** Near Monks Mound stood a circle of upright wooden posts, called Woodhenge today. Posts in the circle marked where the sun came up on the longest day of the year and on the shortest. Others marked the two equinoxes, the days in spring and fall when day and night are the same length. The post for the equinox sunrise lines up with the front of Monks Mound.

Bill Iseminger, an archaeologist at the Cahokia site, gives these figures for the circle. The people rebuilt it about five times. It measured from about 240 to 480 feet across. The first circle had 24 posts, and each new circle had twelve more than the one before.

**Not known:** what the people said or believed as they watched the sun rise over the posts. No record of it survives.

### The earthworks of Ohio

People in the woodlands of eastern North America built long walls of earth between about the years 1 and 400. They laid the walls out in geometric shapes and built mounds of many shapes beside them. Many of these earthworks are in Ohio. In 2023 they were added to UNESCO's list of World Heritage Sites as the Hopewell Ceremonial Earthworks, ceremonial meaning built for religious gatherings and ceremonies. UNESCO is the part of the United Nations that keeps that list of important places.

Objects found at the earthworks came from far away. There is mica, a shiny rock that splits into thin sheets. There are shark's teeth, sea shells, copper, and obsidian, a black glass made by volcanoes. The builders had contacts with peoples from the Atlantic coast to the Rocky Mountains, and these things reached Ohio through them.

**Whose name?** Archaeologists call the builders the Hopewell culture, but that is not the name of any Native nation. Mordecai C. Hopewell owned a farm near Chillicothe, Ohio, where some of the mounds stood. Warren K. Moorehead dug into twenty-eight mounds on that farm, and the objects he took out went on show at the world's fair in Chicago in 1893. After that, archaeologists used the farmer's name for the builders. The National Park Service's account of the earthworks states that different Native groups built them.

## The 1500s

**Era 2 of 10 · The 1500s · about 8 minutes**

Spanish priests, with Spanish soldiers at their side, set out in the 1500s to turn the peoples of this land into Catholics, Christians who follow the pope in Rome. The priests belonged to orders, groups of Catholic men who promised to live by one set of rules. The Jesuits were one order. The Franciscans were another, and their priests and brothers are called friars.

Franciscan friars built missions, churches they ran inside Native towns, among the Timucua and Guale peoples of what is now Florida and Georgia. From 1598 they built missions among the Pueblo nations of what is now New Mexico as well. In each mission town the friars baptized the people, washing them with water in the Christian ceremony that makes a person a member of the church. They also taught them Catholic beliefs.

**Missions and government.** Spanish officials used the missions to bring the Native towns under the Spanish government. The officials demanded that the people promise loyalty to that government, and they ordered each mission town to send men to work for the Spanish. Nearly all of the written record of the missions in this century comes from the missionaries themselves, so it records their view.

### The missions in Florida and Georgia

Luis Cáncer de Barbastro, a Dominican friar from Spain, argued that friars should bring Native people to Christianity without soldiers. He had come to the Caribbean in 1518. King Charles V of Spain gave him a written order to try it in Florida, and he sailed from Havana, Cuba, in early June 1549. On June 26 he went ashore near Tampa Bay to greet a group of Tocobaga people, and they killed him. The Tocobaga left no account of why.

The Jesuits tried missionary work in Florida from 1568 to 1571 and left without success. Franciscan friars came next. After a new group of them arrived from Spain in 1587, they began building missions up the coast into what is now Georgia.

San Pedro de Mocama, on the coast of what is now Georgia, was the first successful mission there. By the end of 1595 the friars had missions in at least five main towns of the Guale people, who spoke a Muskogee language.

A mission town with a friar living in it was called a *doctrina*. There the friar baptized people and led Mass, the main Catholic church service. Friars also taught the catechism, a set of questions and answers about Christian beliefs that people learn by heart. The friar Francisco Pareja had a catechism in Spanish and in the Timucua language printed in Mexico City in 1612.

**Workers for St. Augustine.** Spanish officials used the mission towns to get workers as well. Under a system called the *repartimiento*, each mission town had to send a set number of unmarried men to St. Augustine every year to work for the Spanish.

### Killed for refusing to change faith, 1565

Spanish soldiers killed French Protestants, Christians whose churches had broken away from the pope, in Florida in 1565 because of their religion. It was the first killing over religion between Europeans in what became the United States.

**The first group.** A hurricane wrecked the French ships that year, and about 127 French Protestants came ashore with no food and no weapons. They surrendered to Pedro Menéndez de Avilés, the Spanish commander. Menéndez told them to give up their Protestant faith, and they refused. His soldiers killed 111 of them. Menéndez spared 16 men: a few who said they were Catholic, some sailors forced onto the ships, and four craftsmen St. Augustine needed.

Of the others, Menéndez wrote to the king of Spain on October 15, 1565: "I had their hands tied behind them and put them to the knife." That meant his men killed them with knives.

**The second group.** About two weeks after the first killing, a second group of Frenchmen under Jean Ribault surrendered. They refused the same demand, and Menéndez's soldiers killed 134 of them. The two killings are dated September 29 and October 11 or 12, 1565.

### Guale, 1597

Guale people killed five Franciscan friars and destroyed their missions in the autumn of 1597. One of the five was Blas Rodríguez, the friar at the town of Tupiqui. A sixth friar was held captive and freed in 1598.

**Not known:** which Guale people killed the friars, and why.

The historians J. Michael Francis and Kathleen Kole translated the earliest Spanish records of the uprising and published them in 2011. They wrote that those two questions cannot "be answered with any certainty." Older retellings name a young leader and give a reason. In the earliest records, only two of the seven witnesses named that young man at all, and neither said he alone ordered the killings.

**The governor's revenge.** Gonzalo Méndez de Canzo, the Spanish governor of Florida, led soldiers into Guale country himself. On October 27 people at the town of Ospo shot arrows at his men. Over the next ten days the governor and his officer Alonso Díaz burned Ospo and four more Guale towns, with their houses and storehouses, some of them full of corn. The governor could not capture anyone, so he ordered his men to destroy the corn fields and other crops as well. The records describe the burning and give no count of Guale people killed.

**Lucas.** The governor took seven young Guale captives in July 1598. Francis and Kole describe them as boys. One was Lucas, the son of don Felipe, the chief of Tupiqui. Spanish officials questioned Lucas a second time on July 27, now under the threat of torture, and he confessed that he had been there when Blas Rodríguez was killed. They sentenced him to death on July 28. He was hanged at St. Augustine on July 29, 1598, and the records do not name the man who hanged him.

Lucas was the only Guale person the Spanish officially charged and punished for the uprising. Spanish officials divided the other six boys among themselves as personal servants. The boys were captives and had to do forced labor for the men who held them. The Spanish left the northern missions empty until 1604.

### New Mexico, 1598

Juan de Oñate claimed for Spain the land the Spanish called New Mexico in early May 1598, at a crossing of the Rio Grande near what is now El Paso. It was the homeland of the Pueblo nations, and Franciscan friars traveled with him.

That autumn Oñate went to every pueblo, as the Spanish called each Pueblo town. Through translators he demanded that the people of each town promise loyalty to the Spanish government. At those meetings he gave each town a missionary, and the Franciscan missions in New Mexico began that way.

**Acoma.** The friars also gave their approval for a war on Acoma Pueblo. In December 1598 Oñate's nephew, Juan de Zaldívar, went up to Acoma Pueblo with soldiers to demand food. In the Acoma people's own account, the soldiers raped an Acoma woman, forcing her into sex. The Acoma killed Zaldívar and eleven to fourteen of his men.

**What the friars said.** Oñate then asked the Franciscan friars whether a war against Acoma would be just. The friars answered that he "possessed both the authority and sufficient cause." That meant the friars said he had the right to make war and a good enough reason.

**The killing.** Oñate's soldiers attacked in January 1599. They killed Acoma men, women and children and burned much of the town. No one counted the dead, and estimates run from about 300 to about 1,500.

**The sentences.** Oñate sentenced the men over twenty-five to have one foot cut off. He sentenced them and every other captive over twelve to twenty years of forced labor, and he handed the old people to the Plains Apache as slaves. Whether the feet were really cut off is disputed.

**The children.** On Oñate's orders, Acoma children under twelve were taken from their parents and given to the friars. About seventy of the girls were sent south to convents in Mexico, houses of nuns, women who have promised their lives to the Catholic church. The records do not name the men who took them. Almost certainly none of the girls ever came home.

### Doña María Meléndez

> **Who:** The Timucua chief of Nombre de Dios, the town beside St. Augustine, and a Catholic.
>
> **When and where:** Spanish Florida, the late 1500s and early 1600s.

**The friars' success in her town was "largely owing to" her.**

Doña María Meléndez ruled Nombre de Dios, a Timucua town just outside St. Augustine. The Spanish called her the *cacica*, their word for a woman chief. Her mother ruled the town before her and was one of the first Timucua people to become Christian. Doña María was a Christian too. She married a Spanish soldier named Clemente de Vernal, who lived with her and their children at Nombre de Dios.

The Franciscans set up their first *doctrina* at Nombre de Dios after 1587. Staff at the Florida Museum of Natural History write that the Franciscans' success there "was largely owing to" her. By 1606 she ruled the Timucua towns along the coast from St. Augustine north to about Cumberland Island, in what is now Georgia.

**Not known:** how she gained that wider rule. The National Park Service's account says she may have had Spanish help, and the records do not settle it. Spaniards wrote down everything known about her, nothing survives in her own words, and no record says why she became a Christian.

## The 1600s

**Era 3 of 10 · The 1600s · about 25 minutes**

English Protestants founded several colonies in the 1600s so that they could worship in their own way, and in some of those colonies the leaders punished people who worshipped differently. The Puritans ran Massachusetts. They were English Protestants who wanted to clear the Church of England of what they saw as Catholic leftovers. Among the people they punished were Quakers, members of a Protestant group begun in England in 1652. Puritan leaders had the ears of some Quakers cut off, and they hanged four Quakers in Boston.

Other colonies set other rules. Maryland's lawmakers protected worship for Christians in a law of 1649, and the same law ordered death for anyone who denied the Trinity, the Christian belief that God is three persons in one. Roger Williams in Rhode Island let people of every faith live as neighbors with equal rights. William Penn wrote freedom of worship into Pennsylvania's Frame of Government, his plan for running the colony.

**New Mexico.** Spanish friars and governors punished Pueblo people for holding their own ceremonies. They whipped religious leaders and hanged some of them. In 1680 the Pueblo nations rose up and drove the Spanish out.

### Why the Puritans left England

In England in the 1620s, the men who ran the church and the government ordered the Puritans to follow church practices they hated. Those leaders put Puritan ministers out of their jobs and threatened them with "extirpation from the earth," which means being wiped out.

Bishops, the high officials who ran the Church of England, had their critics punished hard. English judges had Protestants who wrote against the bishops whipped, cut and branded.

**Alexander Leighton.** The judges of a London court called the Star Chamber sentenced a Scottish minister named Alexander Leighton in June 1630, for writing a book against the bishops. They fined him 10,000 pounds and ordered him whipped. He was to stand in the pillory, a wooden frame that locked a person's head and hands in a public place. The judges ordered one of his ears cut off and one side of his nose slit open.

They also ordered his face branded with the letters S.S. Branding means pressing red-hot metal onto the skin to burn in a mark that never goes away. The letters stood for "sower of sedition," a person who stirs people up against the government.

Leighton escaped the night before the punishment, but he was caught again in Bedfordshire. The first part of the sentence was carried out on him on November 26, 1630.

**Not known:** which punishments that first part included, and who carried them out. The account of his life in the Dictionary of National Biography, a British book of life stories printed between 1885 and 1900, does not say.

He was held in the Fleet, a London prison, until 1640. That year the members of Parliament, England's lawmakers, set him free, canceled his fine and voted to pay him 6,000 pounds.

**Crossing the ocean.** As many as 20,000 Puritans left England for America from 1630 on, looking for the freedom to worship as they believed they should. John Winthrop's company of about 1,000 arrived in 1630 and settled on the Shawmut Peninsula, where Boston stands now.

It was the land of the Massachusett people, who called it Mushauwomuk, "the boat landing place." Between 1616 and 1618 an epidemic, a disease that spread fast from person to person, had killed all but about 25,000 of the roughly 100,000 people of that region. That is three people in every four. In 1633 the Massachusett leader Chickataubut signed a treaty with Winthrop that gave up his rights to the peninsula.

The Pilgrims who landed at Plymouth in 1620 were a different group. They had left the Church of England completely and formed churches of their own. The Puritans believed the Church of England was a true church that needed to be fixed.

**Joining a church.** In Massachusetts a person could not simply join a church. At first, only men and women who had gone through a conversion experience, a moment when a person feels that God has changed him or her, could become members. Each new member also had to convince the other members that it was real.

**The Bay Psalm Book.** Richard Mather and two other ministers turned the Psalms of the Bible into verses that church members could sing. Stephen Daye printed their book at Cambridge, Massachusetts, in 1640, and it was the first book printed in the English colonies of North America. Eleven copies still exist.

### Reading for God

New England children were taught to read for a religious reason. In 1642 the men of the Massachusetts General Court, the colony's lawmakers, ordered parents and masters to teach their children and apprentices, young people learning a trade from a master, to read. The law required them to learn enough "to read the English tongue" and to know the colony's "Capital Lawes," the laws that set death as the punishment for a crime. The colonists pointed to the Bible as the authority for many of their criminal laws.

**The Old Deluder Satan Act.** A second law, in 1647, ordered towns of 50 households to hire someone to teach reading and writing. Towns of 100 families had to set up a grammar school, a school that prepared young people for "the university," which meant Harvard College. The law's opening words state that it is "one of the chief projects of that old deluder Satan to keep men from the knowledge of the Scriptures."

A deluder is someone who tricks people, and the law has been called the Old Deluder Satan Act ever since. The colonists wanted every child to be able to read the Bible without a minister in between.

Harvard College was founded in 1636 to train ministers. A pamphlet by its founders, *New Englands First Fruits*, printed in England in 1643, states the college's purpose. The founders were "dreading to leave an illiterate Ministery to the Churches, when our present Ministers shall lie in the Dust." They feared that when their ministers died, no trained ministers would be left to replace them.

New England children learned to read from *The New England Primer*, made by the printer Benjamin Harris. Staff at the American Antiquarian Society, a research library, date its first printing between 1687 and 1690, because the only evidence left is booksellers' advertisements. Harris placed his first advertisement for it in 1690. No copy printed before 1727 survives.

**The picture of the fire.** One page of the Primer showed John Rogers being burned alive at Smithfield, in England, on February 4, 1555. He was the first Protestant put to death under Mary, the Catholic queen of England. The picture showed his wife and ten children beside the fire. A long poem next to it, written as his last advice to his children, told them to "Abhor the arrant Whore of Rome," which meant to hate the Catholic Church.

Library of Congress staff write that generations of New England children read these pages. In their words, the pages "doubtless helped to fuel" New Englanders' prejudice against Catholics, a dislike of a whole group of people without knowing them. That prejudice stayed strong there well into the 1800s.

**By 1650:** Puritan leaders ran Massachusetts by their reading of the Bible, only people who had felt God change them could join its churches, and every town of 50 households had to hire someone to teach reading.

### Praying towns and Deer Island

New England ministers also tried to bring the Native nations around them to Christianity. John Eliot, the minister at Roxbury, translated the whole Bible into the Algonquian language of the Massachusett people. It was printed at Cambridge in 1663, the first Bible printed in any language in North America. At one time Eliot ministered to about 1,100 Christian Native people, whom the English called Praying Indians. They lived in fourteen towns laid out in the English style.

**Deer Island.** The English were fighting what they called King Philip's War in 1675. That year the members of the Massachusetts General Court ordered the Christian Native people of Natick taken from their homes and put on Deer Island in Boston Harbor. Daniel Gookin, the Massachusetts official in charge of dealings with the Praying Indians, wrote that the order came from "false informations" given to the court to stir its members up against the people of Natick.

Samuel Shrimpton of Boston held the island, and he agreed to the plan as long as they did not cut down any trees. Captain Thomas Prentiss and a party of horsemen brought the Natick people to the Charles River.

About 200 people from Natick were put on three boats about midnight on October 30, 1675, under the court's order, and carried to Deer Island. Gookin does not name the men who took them. John Eliot met them at the landing and prayed with them. They were afraid they would never come home and would be shipped out of the country.

**The winter.** Massachusetts officials then sent the Punkapog people to the island too, "upon as little cause as the Naticks were," Gookin wrote. By late December about 500 people were held there. Gookin wrote that they lived mostly on clams and shellfish dug out of the sand at low tide. The island was cold, their wigwams, or houses, were poor, and they had few clothes, and thin ones.

Gookin wrote that the island kept them safe "from the fury of the people." His account of that winter gives no count of the dead. In 2025 the Episcopal bishops of Massachusetts and Western Massachusetts wrote that hundreds of Native people from the praying towns died on Deer Island from the cold and from starvation in the winter of 1675 to 1676.

### Quakers punished in Massachusetts

The Quakers formed around a preacher named George Fox in England in 1652, and they call themselves the Religious Society of Friends. They taught that the Spirit, or "Light of Christ," lives inside every person. Quaker women spoke and preached at Quaker meetings for worship, and other colonists found this offensive. Many people at the time called Quaker teaching heresy, a belief that goes against the teaching of the church.

English officials had put 10,000 Quakers in prison by 1680. According to the Library of Congress, 243 of them died in the king's jails "of torture and mistreatment."

The Puritan lawmakers of Massachusetts passed law after law against Quakers, starting on October 14, 1656. They called Quakers "the cursed sect of heretics." They fined ship captains who brought Quakers into the colony and people who owned Quaker books.

**Ears and tongues.** A law of 1657 set the punishment for a Quaker who came back after being thrown out of the colony. A man would have one ear cut off the first time, and the other ear the second time. A woman would be whipped. A third return was to be punished by boring a hole through the person's tongue with a hot iron.

Christopher Holder, John Copeland and John Rous were Quakers who came back. The judges sentenced each of them to have his right ear cut off by the hangman. On September 16, 1658, the deputy of the colony's marshal, a law officer, came to the prison with a group of men and shut the door. Then he had the right ear of each of the three men cut off. Afterward the three men said: "They that do it Ignorantly, We desire the Lord from our hearts to forgive them."

**Two children for sale.** Massachusetts officials also punished the children of Quakers. Daniel and Provided Southwick were the son and daughter of Lawrence and Cassandra Southwick, Quakers of Salem. Judges at Salem and Ipswich fined them ten pounds for not going to the town's church meetings, and they had no property to pay it with. The members of the General Court then gave the county treasurers the power to sell the two children to any English buyer, in Virginia or Barbados, to pay the fine.

The county treasurer, Edmond Batter, looked for a ship's captain to carry them to Barbados. The captain he found refused. He asked, "will ye offer to make Slaves of so harmless Creatures?" Batter sent the children home, and the order to sell them was never carried out.

**Death for coming back.** The lawmakers set the punishment of death on October 19, 1658, for any Quaker who came back after being banished, which means ordered out of a place and forbidden to return. Between 1659 and 1661 the colony's officials hanged four Quakers in Boston under that law: William Robinson and Marmaduke Stephenson in 1659, Mary Dyer in 1660 and William Leddra in 1661. The governor, John Endecott, sentenced three of them. The story of Mary Dyer, after this section, describes the first three hangings.

King Charles II ordered the Massachusetts lawmakers to stop punishing Quakers on September 9, 1661, after Quakers in England pressed him. By 1677 Quakers could hold their meetings openly in Massachusetts.

Virginia's lawmakers passed their own laws against Quakers from 1659, including death for Quakers who would not obey them. No one was put to death under them. Thomas Jefferson later wrote that the reason was not that the church held back or that the lawmakers went easy. In his words, it "was not owing to the moderation of the church, or the spirit of the legislature."

**By 1677:** Quakers met openly in Massachusetts, and no Quaker had been hanged there since 1661.

### Mary Dyer

> **Who:** A Quaker woman hanged on Boston Common for returning to Massachusetts after she had been banished.
>
> **When and where:** Massachusetts and Rhode Island. Hanged in Boston on June 1, 1660.

**She stood on the ladder with the rope around her neck.**

Her first trouble with the Massachusetts leaders came when she supported Anne Hutchinson, a Boston woman who was banished for her religious teaching. In 1638 the Massachusetts leaders forced Dyer and her family out, and they moved to Rhode Island. In the 1650s, in England, she became a Quaker.

She came back to New England to spread Quaker beliefs. The Massachusetts officials arrested her and banished her three times. In the spring of 1657 her husband, William Dyer, got her out of the Boston jail by confronting Governor John Endecott. Endecott let her go on the condition that she never return.

**The first sentence.** She returned anyway, and in October 1659 Endecott sentenced her to death along with two Quaker men, William Robinson, a merchant from London, and Marmaduke Stephenson, a farm worker from Yorkshire. He told them they would "be hanged until you are dead." On October 27, 1659, the officials led all three to the gallows and made Dyer watch the two men hanged. She stood on the ladder with the rope around her neck.

Then the officials announced a reprieve, which called off her hanging. Endecott had agreed to it the day before. The officials sent her out of the colony.

She came back once more in May 1660, and Endecott sentenced her to death a second time. Massachusetts officials hanged her on Boston Common on June 1, 1660.

### Maryland, 1649: freedom for Christians, death for others

Most people in England hated the Catholic Church all through the 1600s, and they made life hard for Catholics and punished them. In 1632 George Calvert got a charter, a written grant of land and of the right to govern it, from King Charles I for the land that became Maryland. According to the Library of Congress, Calvert wanted a safe place for his fellow Catholics.

Two ships, the *Ark* and the *Dove*, carried about 200 settlers there. Two Catholic priests had to sneak on board to get away from England's laws against Catholics.

Maryland's colonists first landed on March 25, 1634. They later bought land from the Yaocomaco people and built St. Mary's City there. The records do not say what the Yaocomaco were paid or how they understood the sale. By 1649 the colony belonged to Cecil Calvert, the second Lord Baltimore.

**The Toleration Act.** Cecil Calvert sent the Maryland assembly, the colony's lawmakers, a set of proposals about religion in 1649. The members met at St. Mary's City from April 2. They rewrote part of what he sent, and on April 21 they voted it into law as An Act Concerning Religion. It has been called the Toleration Act ever since, toleration meaning letting people hold beliefs that others do not share.

The act protected only Christians. It stated that no person "professing to believe in Jesus Christ" should be "in any ways troubled, molested, or discountenanced" for his or her religion. Molested here meant bothered or attacked, and discountenanced meant treated with disapproval.

**Death for other beliefs.** The same act ordered death for anyone who cursed God, or denied that Jesus was the Son of God, or denied the Trinity of the Father, the Son and the Holy Ghost. Such a person "shall be punished with death," and the person's land and goods would be taken and given to Lord Baltimore. Under this law a Jew, or a Christian who did not believe in the Trinity, could be put to death.

The act also punished insults about religion. Calling someone a heretic, a Puritan, a Presbyterian, a "Popish Priest" or a similar name as an insult cost a fine of ten shillings (a shilling was an English coin). Half of the fine went to the person insulted. A person who could not pay was "publickly whipt" and kept in jail until he or she asked forgiveness in public.

Puritans took control of Maryland in 1654 and threw out the act. They took legal rights away from Catholics, Jews, Quakers and others. Maryland's colonists canceled the Puritan laws in 1661, and the act was in force again. After 1689 the Church of England became Maryland's official church by law, and officials there enforced English laws that kept Catholics from voting, holding office or worshipping in public.

### Two colonies that left worship alone

Roger Williams founded Providence in 1636, on land of the Narragansett people. He wanted it to be "a shelter for persons distressed for conscience." In Rhode Island, Anglicans (members of the Church of England), Puritans, Quakers, Catholics, Jews and people with no religion lived as neighbors with equal rights.

William Penn was a Quaker. In 1681 King Charles II owed a debt to Penn's father, and Penn turned it into a charter for Pennsylvania. The Lenape people, also called the Delaware, lived on both sides of the Delaware River. Beginning in 1682, the Lenape gave up land on the west bank of the river to Penn in exchange for cloth, guns, gunpowder, alcohol and other goods. By 1685 as many as 8,000 Quakers had moved to Pennsylvania.

**Penn's plan.** In 1682 Penn wrote a Frame of Government for the colony. It stated that everyone who believed in "One Almighty and eternal God" would "in no wayes be molested," meaning bothered, for their religion. It also stated that no one would "be compelled at any time to frequent or maintain any Religious Worship, Place or Ministry whatever." That meant no one in Pennsylvania had to attend a church, and no one had to pay for one.

The first group of Germans reached Philadelphia in 1683, from the town of Krefeld. They were Mennonites and possibly some Dutch Quakers. Mennonites, Dunkers, Schwenkfelders, Moravians and German Baptists followed. These were small Protestant groups from Germany and nearby lands, and their members had been punished for their religion in Europe. People described Pennsylvania as "an asylum for banished sects," a safe place for religious groups that had been driven out.

Twenty-three Jewish refugees from Dutch Brazil arrived in New Amsterdam, the Dutch town that became New York, in 1654. Within a year they were holding religious services there. By 1658 Jews had also settled at Newport, Rhode Island, where they could worship freely.

### Roger Williams

> **Who:** A minister thrown out of Massachusetts who founded Rhode Island, where the government stayed out of religion.
>
> **When and where:** Born in London about 1603. Massachusetts from 1631. Founded Providence in 1636. Died in Providence in 1683.

**"Forced worship stinks in God's nostrils," he wrote in 1644.**

Roger Williams taught that a government has no right to force religion on anyone. He called the freedom to follow one's own conscience "soul liberty," and he built a colony on that idea.

He had studied at Cambridge University and become a minister in the Church of England, and he disliked the church's ranks of officials, its wealth, its power in government and its decorations. He reached Massachusetts Bay in 1631, one year after the Puritans settled it. There, Puritan religious rules covered every part of daily life, and colony officials enforced them. Williams preached that the government should not enforce anyone's religion, and that a person's spiritual life should be kept separate from public life.

**Thrown out.** The judges of the colony's General Court ordered him out of Massachusetts for preaching these ideas. He fled in the winter, because he might have been put to death if he had been sent back to England. Wampanoag people took him in and kept him alive through that winter. He had traded with them and learned their language.

**Providence.** With help from Wampanoag and Narragansett people, he traveled by canoe to a freshwater spring at a place called Moshassuck. He settled there in 1636 with the permission of the Narragansett and named the place Providence. In 1638 the Narragansett leaders Canonicus and Miantonomi signed a deed with Williams for the settlement, a deed being a paper that hands over land. Under it, the Narragansett kept the right to trade inside the settlement.

In Rhode Island, people of every faith lived as neighbors with the same rights. Williams thought many of them were wrong about religion. He believed that correcting them was not the government's job.

**His books.** In 1643 he published *A Key into the Language of America*, a book about the Native languages of New England, mostly Narragansett, and about Narragansett daily life. In 1644 he published *The Bloudy Tenent of Persecution*, an argument against forced worship. In it he wrote: "God requireth not an uniformity of Religion to be inacted and inforced in any civill state." He meant that God does not require everyone to be made to follow the same religion.

Members of England's Parliament granted Rhode Island a patent, a paper that recognized the colony, in 1644. King Charles II granted it a new charter in 1663, at the request of John Clarke, a Rhode Island colonist who had stayed on in England to act for the colony. The charter stated that no one in the colony would be punished "for any differences in opinion in matters of religion."

Williams died in Providence in 1683. In 1965 members of Congress voted to set up the Roger Williams National Memorial in Providence.

### Anne Hutchinson

> **Who:** A Boston woman who held religious meetings in her home, taught her own reading of the Bible, and was banished and put out of her church for it.
>
> **When and where:** Born in Alford, England, about 1591. Boston from 1634. Banished in November 1637. Killed in 1643.

**Her church said she had "rather been a Husband than a Wife."**

The leaders of Massachusetts put Anne Hutchinson out of the colony for what she taught about God, and then the members of her church put her out of the church. She had sailed to Boston in the autumn of 1634 with her husband, William, and their children, following their minister, John Cotton.

**The meetings.** From 1636 she held a meeting in her home once a week to talk over the Sunday sermon. At first only women came. Then men came too, including important men of the colony. In Massachusetts the minister's sermon in the meeting house was the official teaching, and a second meeting in a private house, led by a woman, was a rival to it.

**What she taught.** She taught that God's grace, God's free gift of love and forgiveness, alone decides who is saved, meaning who goes to heaven. She said good behavior played no part.

She also said she could tell which ministers and which neighbors had received God's grace and which had not. That second claim put her in judgment over the colony's ministers. Her opponents called her teaching antinomian, a word that means "against the law." They meant that her teaching let a saved person ignore the rules.

At her trial she said that God had spoken to her directly, by "an immediate revelation," and that God would curse the Puritans if they harmed her. The judges called that blasphemy, speaking against God.

**Two trials.** She faced two trials, five months apart. In November 1637 the members of the General Court tried her at Newtown, now Cambridge, and banished her. In March 1638 the members of the church at Boston tried her separately and excommunicated her, which means they put her out of the church.

The church's charges said she had "rather been a Husband than a Wife and a preacher than a Hearer." The same charge went on: "and a Magistrate than a Subject," an official who governs or judges rather than a person who is governed.

**Her death.** In the spring of 1638 she moved to Aquidneck Island in what became Rhode Island and founded the town of Portsmouth. After her husband died, she moved in 1642 to land on Long Island Sound that the Dutch claimed for their colony.

A war broke out there the next year. In February 1643 soldiers of the Dutch governor, Willem Kieft, killed at least eighty, and perhaps as many as 120, Munsee people in one night, and that killing began the war. In August or September 1643, during that war, Siwanoy people attacked her home. They killed her and several of her children. One daughter survived.

### Baptism and slavery in Virginia, 1667

Some colonists argued that a Christian could not be held as a slave. In September 1667 the members of Virginia's lawmaking assembly settled the question in favor of slavery. Their law said that being baptized "doth not alter the condition of the person as to his bondage or ffreedome," bondage meaning slavery. The law's own words state the lawmakers' reason. Once enslavers were sure that baptism would not free the people they held, they would be more willing to let them be baptized.

### New Mexico: punished for their ceremonies

The Pueblo nations of New Mexico hold their religious ceremonies in kivas, rooms set aside for worship. Some of their ceremonies are masked dances. For about eighty years the Franciscan friars demanded that the kivas be destroyed and the masked dances ended. The friars called the dances idolatry, which means worshipping false gods.

Alonso de Posada, the head of the Franciscan missionaries from 1656 to 1665, forbade Pueblo ceremonies. He ordered the missionaries to go into the kivas, burn the masks, and take or destroy the sacred objects. In 1661 Spanish soldiers as well as friars raided kivas and burned sacred masks.

**Whippings and hangings.** Will Hansen and Analú María López, who work at the Newberry Library, a research library in Chicago, write that missionaries almost certainly whipped Native people who did not take part in Christian services. Spanish investigations in New Mexico between 1620 and 1680 recorded many cases of missionaries punishing Native people severely. According to the Architect of the Capitol's account of Po'pay, Pueblo people "found practicing their religion were tortured and sometimes executed."

Juan Francisco Treviño, the Spanish governor, ordered the arrest of 47 Pueblo medicine men in 1675. The charge was sorcery, using magic to cause harm, which is what Spanish officials called the medicine men's ceremonies. Spanish officials sentenced four of them to be hanged. Three were hanged, and the fourth killed himself. Spanish officials whipped the others in public and put them in prison. The records do not name the men who did the hanging and the whipping.

**Po'pay.** One of the men whipped was Po'pay, of Ohkay Owingeh, also called San Juan Pueblo. He was born about 1630, and his name means "ripe squash" in the Tewa language. He was a farmer and a member of a medicine society, and his work was healing and the spiritual life of his people. Spanish officials had him flogged in public. Flogging is beating a person on the back with a whip. The whip leaves wounds that heal into scars.

When Pueblo leaders heard about the arrests, they sent armed men to Santa Fe, where the prisoners were held. Many Spanish soldiers were away at the time, so Treviño gave in and released the prisoners. Po'pay was one of them.

**The rising.** Po'pay led a rising of the Pueblo nations against the Spanish in 1680, and he planned it from Taos Pueblo. The leaders set it for August 13 and sent runners to the pueblos with knotted cords. Chapter 2, Native Nations, describes the rising in full, including what the knots meant.

On August 9 the Spanish captured two of the runners, Pedro Omtua and Nicolás Catua of Tesuque Pueblo. Spanish officials tortured them to make them explain the cords, and later hanged them. The records do not name the men who did it. With two of their runners in Spanish hands, the Pueblo leaders began the rising three days early, on August 10, 1680.

The Pueblo fighters killed about 400 people, including 21 of the 33 Spanish priests in New Mexico, and burned mission churches across the province. The Pueblo nations kept the Spanish out of New Mexico for twelve years.

The Pueblo nations run their own museum, the Indian Pueblo Cultural Center. Its account of those eighty years of Spanish rule states that "the Pueblo people suffered violence, cruelty, and hunger." It lists "exploitation of labor and resources," and "harassment and persecution for practicing long-held religious traditions that are interwoven in daily life." That means the Spanish forced Pueblo people to work for them, took what they had, and troubled and punished them again and again for keeping their own religion.

**The statue.** In 2005 a statue of Po'pay, given by the state of New Mexico, was placed in the National Statuary Hall Collection in the United States Capitol. Of all the people in that collection who were born on land that later became the United States, Po'pay was born the earliest.

No picture or written description of Po'pay survives, so the face is the sculptor's own work. The sculptor, Cliff Fragua of Jemez Pueblo, wrote: "On his back are the scars that remain from the whipping he received for his participation and faith in the Pueblo ceremonies and religion."

**If you remember one thing:** English colonists crossed the ocean to worship in their own way, and the leaders of Massachusetts, like the friars of New Mexico, punished people who worshipped any other way.

- 1636: Roger Williams founds Providence, where people of every faith live as neighbors.
- 1660: Massachusetts officials hang Mary Dyer on Boston Common.
- 1680: Po'pay leads the Pueblo rising that drives the Spanish out of New Mexico.

**Next:** In the 1700s traveling preachers held revivals across the colonies, and church members split over them.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 14 minutes**

Traveling preachers held revivals, series of meetings meant to stir people to a stronger faith, across the colonies in the 1730s and 1740s. People in many colonies took part in the same religious movement at the same time, and it is called the Great Awakening.

Most colonists already went to church. By one estimate, 75 to 80 percent of colonists attended church between 1700 and 1740, and colonists were building new churches fast. The revival preachers wanted each person to go through the new birth, a conversion that a person could feel happening inside. Church members split into two sides over whether the new birth was real. Critics said many of the conversions were false, and even the work of the devil.

Killings over religion came in these years too. English colonists from Carolina and Creek fighters under James Moore destroyed the Spanish missions among the Apalachee of Florida in 1704. In 1741 New York officials hanged a man they called a Catholic priest.

### The Apalachee missions destroyed, 1704

English colonists from Carolina and their Creek allies destroyed the Spanish missions among the Apalachee people in 1704. The Apalachee lived around what is now Tallahassee, Florida. Many of them were baptized Catholics who lived in fourteen Franciscan mission towns.

The members of the Carolina assembly approved the attack in September 1703 and asked James Moore, a former governor of Carolina, to lead it. Moore promised that the attack would cost the colony nothing, because he would pay for it "by the taking of loot and slaves." That meant stealing goods and capturing people to sell as slaves. He led fifty Englishmen and about one thousand Creek men, also called Muscogee.

**Ayubale.** Moore's men destroyed nearly all of the fourteen mission towns. At the church of Ayubale, on January 25, 1704, a friar named Angel de Miranda and 26 men held off the attackers for about nine hours. They surrendered when they ran out of arrows.

A magazine account based on the work of the historian John Hann describes what the attackers did there. They burned one friar alive and cut off his head, and the account does not give his name. They also tortured two Native people and burned them at the stake.

**Patale.** In a later raid that year, on June 23, 1704, attackers killed the friar Manuel de Mendoza at the Patale mission and burned the church. At Patale they tied prisoners to the Stations of the Cross, a set of markers used in Catholic prayer, and cut them with knives. Then they pushed burning sticks into the wounds and burned the prisoners to death. The records name James Moore as the commander of the January raid. They do not name the men who tortured and burned the prisoners.

**How many were taken.** The counts vary widely. Moore reported that his army killed more than 1,100 men, women and children and captured more than 4,300 people as slaves, most of them women and children. Moore had promised to pay for the raid with captives.

Other counts of the people captured run from hundreds to about 1,400. The historian John Hann counts about 2,000 Apalachee who went into exile after the raids, forced to live far from their homeland, and he writes that an unknown number were enslaved. In 1680 the fourteen mission towns had held about 8,000 people.

Many Apalachee were unhappy with the forced labor the Spanish demanded, which included carrying goods about 100 miles to St. Augustine. The Spanish had also forbidden mission Apalachee to own guns. Many Apalachee left with Moore. In his report, Moore said that most of the people of seven villages chose to join him.

### New Lights and Old Lights

Church members argued over the revival, and many churches divided into two sides. People who supported the revival were called New Lights, and people who opposed it were called Old Lights. Those were the names among the Congregationalists, the members of the churches the Puritans had founded in New England. Among the Presbyterians, another family of Protestant churches, the two sides were called the New Side and the Old Side.

The revival had ended in New England by the middle of the 1740s. Preachers carried it south, where it started revivals that went on into the 1800s. The Presbyterians, Baptists and Methodists had backed the revival, and by the early 1800s they were the largest Protestant churches in the country. According to the Library of Congress, the Anglicans, the Quakers and the Congregationalists "were left behind."

A small number of colonists, among them Thomas Jefferson and John Adams, went a different way. They were deists, who stressed living a good life and rejected the Christian teaching that Jesus was God.

Drawings of New York City from 1690, 1730 and 1771 show the churches multiplying. The 1690 view shows an empty skyline. The 1771 view shows eighteen steeples, the tall towers on top of churches.

### A college founded by revival supporters

Only graduates of Harvard or Yale could become Presbyterian ministers in the colonies in these years. Under that rule, the young men taught by William Tennent could not become Presbyterian ministers, so revival supporters set out to found new colleges.

Tennent was a Presbyterian minister, born in Ireland and educated in Edinburgh, Scotland. From 1726 until he died in 1745 he ran a school at Neshaminy, in Bucks County, Pennsylvania. People called it the Log College, because it was a log house about twenty feet long and almost as wide. He taught his students ancient languages and the Bible. Several of them became revival preachers anyway, among them his four sons.

**Princeton.** A group of New Lights planned a college in New Jersey in early 1746 to train young men for the ministry. On October 22, 1746, John Hamilton, the acting governor of New Jersey, granted a charter for the College of New Jersey. It is now Princeton University, and Princeton's own historians call its founding "a direct outgrowth" of the Great Awakening. Six months after the charter, three Log College graduates became trustees, the men in charge of running the college. They were Samuel Blair and two of Tennent's sons, Gilbert Tennent and William Tennent Jr.

### Should enslaved people be taught Christianity?

Revival preachers pressed enslavers to let enslaved people be taught Christianity, and enslavers resisted. In 1740 George Whitefield printed an open letter in the *Pennsylvania Gazette* to the enslavers of Maryland, Virginia and the Carolinas. He wrote down their reason for keeping enslaved people from Christianity: that "teaching them Christianity would make them proud, and consequently unwilling to submit to Slavery."

Whitefield called that "a dreadful Reflection" on their own religion. He did not say in the letter that slavery was wrong, and he later held enslaved people himself.

Leah, who was enslaved in the household of the minister Jonathan Edwards, became a full member of the church at Northampton, Massachusetts, during the revival. Kenneth Minkema of the Jonathan Edwards Center at Yale records her membership.

### George Whitefield

> **Who:** An English preacher whose tours of the colonies were the high point of the Great Awakening, and who worked to make slavery legal in Georgia.
>
> **When and where:** Born in Gloucester, England, December 16, 1714. Seven visits to America from 1738. Died in Newburyport, Massachusetts, September 30, 1770.

**People in the crowd threw rotten eggs and pieces of dead cat.**

George Whitefield drew crowds of up to 30,000 people in the Great Awakening, and he also pushed to make slavery legal in Georgia. He was a minister in the Church of England and was often in conflict with its leaders.

**The tour.** His preaching tour of the colonies from 1739 to 1741 was the high point of the Great Awakening in America. A sermon he gave in Boston drew as many as 30,000 people.

Many churches would not let him preach inside, so he preached outdoors from a folding pulpit that he carried with him. The first recorded use of it was at Moorfields, in England, on April 9, 1742, in front of a crowd estimated at twenty or thirty thousand. People in the crowd threw stones, rotten eggs and pieces of dead cat at him. He preached about two thousand sermons from that pulpit, by one estimate.

**Why crowds came.** He preached the new birth. In a printed sermon of 1739 he admitted that "how this glorious Change is wrought in the Soul cannot easily be explained." The Library of Congress lists the reasons crowds came to hear him: a strong voice, a way of speaking like an actor on a stage, the strong feelings he stirred up, simple messages, and clever use of the new ways of advertising.

Someone in London made an engraving, a printed picture, in 1763 that mocked his eye disease by calling him "Dr. Squintum." The picture's maker also accused him of sexual wrongdoing and of getting rich from his preaching.

**Bethesda.** In 1740 he founded an orphanage called Bethesda near Savannah. Slavery was against the law in Georgia at that time. In 1741 he wrote that farming more land than his hired servants and older boys could manage was "impracticable without a few negroes." ("Negroes" was a word of his time for Black people.)

He wrote to a donor in 1747 that friends in South Carolina were giving money toward buying "a plantation and slaves" to support Bethesda. He added: "One negroe has been given me." He wrote that he planned to buy more that week.

**Slavery in Georgia.** From 1747 he pressed the trustees who ran Georgia to lift the ban on slavery. He wrote that "Georgia never can be a flourishing province, unless negroes are employed." He told them that unless the ban ended, he could not "cultivate the plantation in any manner." The trustees gave way.

Slavery became legal in Georgia in the early 1750s. The Penn and Slavery Project at the University of Pennsylvania dates it to 1752, when Georgia became a royal colony, run directly by the king's officials instead of the trustees. Other accounts give 1751.

Whitefield died at Newburyport, Massachusetts, on September 30, 1770. In his will he left 4,000 acres of land in Georgia and fifty enslaved people to the Countess of Huntingdon. Phillis Wheatley, a girl of about seventeen who was enslaved in Boston, wrote a poem about his death that was printed that year.

### Jonathan Edwards

> **Who:** The minister of the Northampton revival, whom the historian Perry Miller called "the first and greatest homegrown American philosopher." He bought and held enslaved people from 1731 until at least 1756.
>
> **When and where:** Born in East Windsor, Connecticut, October 5, 1703. Northampton, Massachusetts, from 1726. Died in Princeton, New Jersey, March 22, 1758.

**He compared his listeners to a spider held over a fire.**

Jonathan Edwards led a revival in his own church at Northampton, Massachusetts, and wrote the books that other revival preachers learned from. He was the fifth of eleven children of a minister, and he finished first in Yale's class of 1720.

He joined his grandfather, Solomon Stoddard, as a minister of the church at Northampton in 1726. It was the largest church in Massachusetts outside Boston. He later took his grandfather's place. In 1727 he married Sarah Pierpont, and they had ten children.

A revival took place in his congregation, the people of his church, in 1734 and 1735. Edwards wrote a book about it, *A Faithful Narrative of the Surprising Work of God*. Revival preachers in America and Britain used it as a model, and it made him famous.

**The sermon.** On July 8, 1741, he preached a sermon at Enfield, Connecticut, called "Sinners in the Hands of an Angry God." He told the people that their own care and goodness had "no more influence to uphold you and keep you out of hell than a spider's web would have to stop a falling rock."

He also told them that God hated them: "The God that holds you over the pit of hell, much as one holds a spider or some loathsome insect over the fire, abhors you, and is dreadfully provoked."

He preached that God controls everything, that people are sinful by nature, that hell is real, and that a person has to be born again. Critics said many of the revival's conversions were false, or even the work of the devil. Edwards answered them in four books between 1741 and 1749, among them *A Treatise Concerning Religious Affections* in 1746. In them he tried to set out how a person could tell a real change of heart from a false one.

**The people he enslaved.** Edwards bought and held enslaved people from 1731 until at least 1756. Kenneth Minkema, of the Jonathan Edwards Center at Yale, lays out the record. The first was a teenage girl named Venus, whom Edwards bought at Newport in 1731. The last was a child named Titus, in 1756. Others whose names are known were Leah, Rose, and a married couple, Joseph and Sue.

His wife, Sarah, actively tried to get enslaved people from family members and from her husband's fellow ministers. Edwards defended slavery as allowed by the Bible. He argued that it was a way to bring enslaved people to Christianity. Late in his life he came to oppose the slave trade, writing that it was unjust to take away the freedom of people born free. After his death his son, Jonathan Edwards Jr., and his student Samuel Hopkins called for ending slavery completely.

**Stockbridge.** The members of his congregation dismissed him in 1750, after he tried to make the rules stricter for who could take communion, the Christian ceremony of sharing bread and wine in memory of Jesus. From 1751 to 1757 he worked at Stockbridge, a Mohican town on the western edge of Massachusetts. He preached to a small English congregation and was a missionary to about 150 Mohican and Mohawk families.

Stockbridge had 218 Mohican people living there in 1749. By 1774 the Mohicans had lost all but 1,200 of their 23,000 acres there, and in 1783 the Mohicans were forced to leave the rest. Their own history does not name the people who took the land or forced them out. The Jonathan Edwards Center at Yale states that Edwards was "an agent in depriving Native Americans of their lands and culture."

**His death.** In late 1757 Edwards agreed to become president of the College of New Jersey. A few months after he arrived, he was inoculated against smallpox, given a small dose of live smallpox on purpose so that he would have a mild case and be safe afterward. A few of the people inoculated died from it, and Edwards was one of them. He died on March 22, 1758.

### A man hanged as a Catholic priest, New York, 1741

Under a law the members of the New York assembly passed in 1700, any Catholic priest who came to New York faced prison for life.

**The fires of 1741.** After a string of fires in 1741, New York City officials claimed that enslaved people and poor white people had plotted to burn the city. By the end of August the judges had sentenced 30 people to death, by the count of the Historical Society of the New York Courts. They also sentenced 70 people to be sold as slaves in the Caribbean.

The historian Jill Lepore counts 34 people put to death. By her count, officials burned 13 Black men at the stake and hanged 17 Black men, two white men and two white women.

**The hunt for priests.** While those trials were going on, James Oglethorpe, the governor of Georgia, wrote to New York's lieutenant governor, the deputy governor. He warned that the Spanish had sent agents to burn English towns in North America, and that "many priests were employed" in disguise, pretending to be doctors or dancing masters. New York officials began hunting for hidden priests. They arrested John Ury, a schoolteacher who knew Latin. Ury said he was a minister of the Church of England.

Mary Burton, a servant, had been a witness in the earlier trials. A judge, Daniel Horsmanden, had promised her money and an end to her years of service. She had never mentioned Ury before. Now she said he was the leader of the plot and had performed Catholic ceremonies for the plotters. Two more witnesses backed her. One was William Kane, a soldier Burton had accused, who went along to save himself. The other was Sarah Hughson, who was brought from the cell where she waited to be executed.

**The trial.** New York's attorney general, the colony's top lawyer, was a man named Bradley. At the trial he attacked the Catholic religion as "murderous" and read Oglethorpe's letter to the jury. Ury had no lawyer. His own witnesses said he was not a Catholic priest and that he had been elsewhere on the nights in question.

The jury took less than fifteen minutes to find him guilty. New York officials hanged John Ury on August 29, 1741. Before he died he said he was innocent and forgave the men who had prosecuted him. He was the last person executed for the supposed plot.

**If you remember one thing:** Traveling preachers set off the Great Awakening, and the argument over their new birth split churches into New Lights and Old Lights.

- In 1739: George Whitefield begins the preaching tour of the colonies that was the high point of the Great Awakening.
- In 1746: New Lights who backed the revival get a charter for a college of their own, now Princeton.

**Next:** After 1750 Americans argued over whether anyone should be taxed to pay for a church, and Black Americans born into slavery founded churches of their own.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 21 minutes**

Americans spent these years arguing over whether the government should make people pay taxes to support a church. Before 1776, several colonies had an established church, one that the government supported with tax money. In Massachusetts it was the Congregational church. In Virginia it was the Church of England, also called the Anglican church, and people there had to attend its services as well as pay for its ministers.

Baptists and other people outside the tax-supported churches still had to pay those churches' ministers, and they organized against the church taxes. After the Revolution the lawmakers of each state decided for themselves whether to keep a church tax. The Baptists won in Virginia in 1786 and lost in Massachusetts, where the tax lasted until 1833. The First Amendment, the first of the changes added to the national Constitution in 1791, barred Congress, the national lawmakers, from setting up a national church.

**New churches and new missions.** Black Americans who had been born into slavery founded churches of their own in these years. On the Pacific coast, Spanish Franciscans built missions from 1769 on the lands of many Native nations. To keep people in the missions, missionaries and soldiers whipped them, locked them in the stocks, wooden frames that hold the feet or hands, and hunted down those who ran away.

### Three more colleges with church backing

Three more colleges were founded with church backing in these years. Rhode Island College was founded in 1764 with the support of the Philadelphia Baptist Association, a group of Baptist churches, and it was renamed Brown University in 1804. Queen's College, tied to the Dutch Reformed Church, received its charter on November 10, 1766. It is now Rutgers University. Dartmouth College received its charter on December 13, 1769. Its founder was Eleazar Wheelock, a Congregational minister.

### How Virginia ended its church tax

A parish was the area served by one church. In Virginia the men who ran each parish also cared for poor people and orphans, so they did the work of a local government as well as running a church.

The members of the Virginia assembly stopped the tax that paid Church of England ministers in 1779. Patrick Henry put forward a bill, a proposed law, for a new religious tax on December 24, 1784. Under his plan, each taxpayer could send his share to the church of his choice.

Some leading Virginians backed a religious tax. Richard Henry Lee wrote that "the experience of all times shows religion to be the guardian of morals." John Marshall, who later became Chief Justice of the United States, voted to move Henry's bill forward rather than put it off. George Washington wrote to George Mason that he did not object to "making people pay towards the support of that which they profess." He thought the bill would stir up trouble, though.

**Madison's protest.** James Madison led the other side. He got the vote put off until the autumn of 1785. On June 20, 1785, he published a long argument against religious taxes, without his name on it, called the *Memorial and Remonstrance*, a remonstrance being a formal protest.

Baptists and most Presbyterians were on his side. They argued that tax money spoils a church, and that a government has no right to control a person's religion. By the autumn of 1785 Madison had the votes, and the members of the assembly voted Henry's bill down.

**Jefferson's law.** In its place Madison brought back a bill that Thomas Jefferson had written in 1777. The members of the assembly passed it on January 16, 1786, and it became law three days later. It is called the Statute for Establishing Religious Freedom, a statute being a law. It states: "no man shall be compelled to frequent or support any religious worship, place, or ministry whatsoever."

Jefferson wrote that it was meant to protect "the Jew and the Gentile" (a person who is not Jewish), the "Mahometan" (an old word for a Muslim), the "Hindoo" (an old spelling of Hindu), and the "Infidel of every denomination," meaning people who believe in no religion at all.

Lawmakers in most states did not follow Virginia in these years. Those of Massachusetts, Connecticut and New Hampshire set up religious taxes that people had to pay. Maryland's and Georgia's lawmakers passed religious taxes but never collected them.

### No religious test, and the First Amendment

The Constitution written in Philadelphia in 1787 says almost nothing about religion. Its one rule about religion is in Article VI. It states that "no religious Test shall ever be required" for a job in the national government. That meant no one could be made to swear an oath about religious beliefs before taking office. Charles Pinckney of South Carolina proposed the rule on August 20, 1787. The delegates at the convention, the meeting in Philadelphia that wrote the Constitution, adopted it on August 30.

**Franklin's motion.** Benjamin Franklin, who was eighty-one, asked the convention on June 28, 1787, to open each day with prayers. He told the delegates: "the longer I live, the more convincing proofs I see of this Truth." He went on: "that God governs in the Affairs of Men." The delegates did not approve his motion. According to reports of the time, the convention had no money to pay local ministers to lead the prayers.

Some people complained that the Constitution contained "no recognition of his mercies to us . . . or even of his existence," meaning God's. Many of the voters in Madison's part of Virginia were Baptists, and they wanted freedom of religion protected in writing. On June 8, 1789, Madison introduced a set of amendments, or changes, to the Constitution. In his notes for that speech he wrote against a "national" religion.

The members of both houses of Congress voted on September 28, 1789, to send twelve amendments to the states. By December 1791 the lawmakers of three fourths of the states, the number needed, had approved ten of them. The first of the ten begins: "Congress shall make no law respecting an establishment of religion, or prohibiting the free exercise thereof." Those words mean that Congress may not set up an official church, and may not stop people from practicing their religion.

### The last church tax

Massachusetts lawmakers kept their state's church tax for forty-two years after the First Amendment was approved. Article III of the state's 1780 constitution required every town and parish to pay for "public Protestant teachers of piety, religion and morality." It also allowed the lawmakers to order people to go and listen to those teachers.

If a man asked, his church tax went to the minister of his own church, as long as he went to hear that minister preach. If he had no such minister, his tax could go to the minister of the parish where the tax was collected.

**The argument.** Article III was the part of that constitution people argued about most. Phillips Payson, a Congregational minister at Chelsea, argued for it in a sermon on May 27, 1778. He warned that if "the restraints of religion" were "once broken down," nothing could "support and preserve order and government in the state." He meant that without religion, no one could keep order.

Isaac Backus, the leader of the Baptists of New England, answered him that year in a pamphlet. He argued that government money spoils churches, and that the best thing a government can do for religion is to leave it alone.

The Baptists lost. There was strong doubt that Article III had won the two thirds of the vote that it needed, and in 1780 the state's officials declared it adopted anyway.

Article III stood for fifty-three years. In 1833 a new amendment to the state constitution replaced it. Churches could still choose their ministers and agree to pay them, but they had to raise the money themselves. Any member could leave a church by handing its clerk a written notice. Massachusetts was the last state to end its church tax.

**By 1791:** Virginia had ended its church tax and the First Amendment kept Congress from setting up a national church, but Massachusetts towns still had to pay Protestant ministers.

### Black Baptists in Savannah

George Liele was born into slavery in Virginia in 1750. In 1775 he was ordained a Baptist minister, which means church leaders officially made him a minister, and he preached at plantations along the Savannah River. In 1778 he gathered a congregation of Black Baptists in Savannah, Georgia.

During the Revolution Liele told his followers to side with the British, who promised to treat African Americans as free people. When the British left their headquarters on Tybee Island, near Savannah, in 1782, many of Liele's followers went with them. They founded settlements and churches in Jamaica, Nova Scotia and Sierra Leone. Liele went to Jamaica.

Andrew Bryan kept the Savannah congregation going. He was born at Goose Creek, South Carolina, and was enslaved by a man named Jonathan Bryan. On January 20, 1788, in a barn at Brampton plantation, a white minister named Abraham Marshall and a Black minister named Jesse Peter baptized more than forty of Bryan's followers. They made the group a church and ordained Bryan as its minister. The church was named the Ethiopian Church of Jesus Christ.

**Whipped for worshipping.** Many white people in Savannah feared that any gathering of enslaved people could be the start of a revolt. A letter written from Savannah in 1790 by Jonathan Clarke describes what they did. White people of Savannah broke up the worship and took many of the worshippers before magistrates, local judges. The worshippers were jailed twice. About fifty were severely whipped. Andrew Bryan was cut and "bled abundantly," which means he bled heavily. The letter does not say who used the whip or who gave the order.

Clarke wrote that Bryan said he "rejoiced not only to be whipped, but would freely suffer death for the cause of Jesus Christ." The chief justice, Henry Osborne, questioned the worshippers along with James Habersham and David Montague, and they released them. Another man, George Walton, said the treatment of the worshippers "would be condemned even among barbarians." Osborne then allowed them to worship between sunrise and sunset.

Bryan counted about 575 followers in 1790. Of those, 225 were full members. About 350 others were converts, and many of them did not have their enslavers' permission to be baptized. Bryan later bought freedom for himself and his family, and he bought land for the church. He died in 1812.

### Richard Allen

> **Who:** A preacher born into slavery who bought his freedom, walked out of a white-run church in Philadelphia, and founded the African Methodist Episcopal Church.
>
> **When and where:** Born into slavery on February 14, 1760, held by a Philadelphia lawyer. Delaware, then Philadelphia. Died in Philadelphia, March 26, 1831.

**A trustee pulled a praying man up off his knees.**

Richard Allen founded Bethel Church in Philadelphia after a white trustee, one of the men who ran the church, pulled a Black member up off his knees during prayer. Allen was born enslaved by Benjamin Chew, a Philadelphia lawyer, who sold Allen and his family to Stokely Sturgis, a farmer near Dover, Delaware. Allen began preaching as a teenager, while he was still enslaved.

**Buying freedom.** In 1780 he bought his freedom for $2,000. He earned the money by working in his own time for about five years. The dollars were Continental money, paper money printed during the Revolution, which by 1780 had lost most of its value.

**Philadelphia.** He came to Philadelphia in February 1786. He wrote: "I frequently preached twice a day, at 5 o'clock in the morning and in the evening, and it was not uncommon for me to preach from four to five times a day." That year he gathered a group of forty-two members.

Absalom Jones, William White and Dorus Ginnings joined him in wanting a church for Black Philadelphians. The elder, the church leader in charge at St. George's Methodist Church, where they worshipped, forbade their prayer meetings. Allen wrote that the Black members "were considered as a nuisance."

**The gallery.** At St. George's, Allen wrote, the Black members were moved out of their usual seats and placed along the wall. He does not say who moved them. Then one Sunday the sexton, the church's caretaker, sent them up to the gallery, a balcony above the main floor. As they knelt there to pray, a trustee took hold of Absalom Jones and pulled him up off his knees.

Allen wrote down the words. The trustee said, "You must get up," and then, "you must not kneel here." Jones answered, "Wait until prayer is over, and I will get up and trouble you no more." The trustee said, "No, you must get up now, or I will call for aid and force you away." A second trustee went to pull up William White.

Allen wrote: "By this time, prayer was over, and we all went out of the church in a body, and they were no more plagued with us in the church." He added that the Black members had helped pay for the church, "in building the gallery and laying new floors."

**When it happened.** The date of the walkout is disputed, and Allen's own account gives none. The traditional date is 1787. The historian Richard S. Newman argues for 1792 or 1793, which would make it a planned protest rather than a sudden one. The Encyclopedia of Greater Philadelphia places it "in the early 1790s."

The group rented a storeroom for worship. Allen wrote that they were threatened with being "read publicly out of meeting," which meant expelled in front of the whole church, if they kept worshipping there. Benjamin Rush and Robert Ralston gave money for a new church. On their first day collecting money, Allen and Jones raised $360. Allen called it "the greatest day's collection that we met with."

**Bethel.** Allen bought a lot at Sixth and Lombard Streets in 1791. The first building was an old blacksmith's shop, and he opened Bethel Church there in July 1794. In 1799 he became the first Black man ordained a Methodist minister.

In Philadelphia in 1816 he brought together African Methodist churches from Pennsylvania, New Jersey, Delaware and Maryland. They formed a new church body, the African Methodist Episcopal Church, and elected Allen its first bishop, a leader over many churches. He died at his home on March 26, 1831, and was buried in the basement of Mother Bethel, as his church came to be called.

### Absalom Jones

> **Who:** A man born into slavery who taught himself to read and became the first priest of African descent in the Episcopal Church in the United States.
>
> **When and where:** Born in Delaware, November 6, 1746. Philadelphia from 1762. Died 1818.

**When he was sixteen, his mother, sister and five brothers were sold.**

Absalom Jones was the first priest of African descent in the United States. He was born into slavery in Delaware and taught himself to read, and the New Testament was one of the books he learned from. When he was sixteen, his mother, his sister and his five brothers were sold. The records do not name who sold them. The man who enslaved Jones took him to Philadelphia in 1762, and there he went to a Quaker night school for Black people.

He bought his freedom in 1784. In 1787 he and Richard Allen started the Free African Society, which worked to end slavery and helped widows, orphans and poor people. In 1792, with help from local Quakers and Episcopalians, Jones and Allen set up the First African Church in Philadelphia.

**St. Thomas.** After the walkout from St. George's, Jones and Allen went separate ways. Jones led the congregation into the Episcopal Church, while Allen stayed a Methodist and opened Bethel Church in 1794. On October 17, 1794, Jones's congregation was formally received into the Episcopal Diocese of Pennsylvania, the group of churches under that state's bishop, as the African Episcopal Church of St. Thomas. Jones was ordained a deacon, a minister one rank below a priest, in 1795.

Bishop William White, a different man from the William White who walked out of St. George's, ordained Jones, then fifty-six, a priest. The Episcopal Church's own archives give the year as 1802, and Delaware's state historical marker gives 1804.

Jones also started a day school, a Female Benevolent Society and an African Friendly Society. In 1800 he sent a petition, a written request, to Congress about slavery. He died in 1818.

### Christian Lenape killed at Gnadenhutten, 1782

American militiamen, part-time soldiers from the local area, killed about 96 Christian Lenape and Mohican people at Gnadenhutten, in the Tuscarawas Valley of Ohio, on March 8, 1782. Chapter 22, War, tells the killing in full. The people killed were converts of the Moravian church and lived in Moravian mission villages. They had refused to fight for either side in the Revolution. Colonel David Williamson led between 100 and 200 militiamen.

The militiamen falsely accused the Christian converts of taking their goods in raids. They held them in houses and voted to kill them. Williamson asked the militiamen who wanted to spare the prisoners to stand apart, and only sixteen or eighteen did. The prisoners, knowing what was coming, prayed and sang hymns.

The militiamen tied them up and killed them by smashing their heads with a mallet, one after another, taking turns as each man got tired. Then they cut off their scalps, the skin and hair of the top of the head. They killed 62 adults and 34 children. Two boys escaped. One of them, named Thomas, lived after he was scalped.

### The California missions

Spanish soldiers and Franciscan friars began building missions in Alta California, which is now the state of California, in 1769. Spain's officials wanted to hold the Pacific coast against Russia and England, and they had little money. They sent missionaries to live on Native homelands because it was a cheap way to claim the land. Soldiers and missionaries came together. The missionaries' job was to make Native people Catholics and to change their whole way of life.

Father Junípero Serra led the Franciscans. He was born in 1713 at Petra, on the island of Mallorca, and he had worked as a missionary in Mexico for seventeen years. He founded Mission San Carlos Borromeo at Monterey in 1770 and lived there until he died in 1784. By the end of 1800 the Franciscans had founded eighteen missions. By 1823 there were twenty-one.

**Whose land.** About 310,000 Native people lived in California in 1769. Each mission was built in the homeland of a people with its own government and language. By 1800 the missions stood on the lands of more than a dozen peoples, among them the Kumeyaay at San Diego, the Tongva at San Gabriel, the Chumash at Santa Bárbara and La Purísima, and different Ohlone peoples around Monterey Bay and San Francisco Bay.

**Baptism and force.** Serra's writings describe a plan to baptize young children first. He expected the children to learn Spanish and translate for their parents. Edward Ketchum, a tribal historian, has said that once a child was baptized, the child was the "property" of the church.

Researchers wrote a report on the missions for the state of California in 2023, with advisers from 19 California tribes. Drawing on the scholars Cook and Madley, it describes persuasion in the early years and more force after about 1790 to 1800. Native accounts make clear that force was used in many baptisms. When Native people kept resisting, the missionaries called in soldiers, who captured runaways and people who had not been baptized.

Missionaries punished baptized Native people to keep them from leaving the missions or to force them to come back. They punished people for running away, stealing, fighting and drinking, and for other acts they called disobedience. The missionaries sometimes gave the punishments themselves. They also had soldiers or Native officials deliver them. Soldiers patrolled the countryside around the missions and punished people there too.

**Whipping.** The 2023 report describes flogging, beating a person with a whip that cuts and bruises the skin, as "probably the most common" form of violence at the missions. It was done in the open, in front of others. Some Franciscans, Serra among them, whipped themselves as a religious practice, so whipping seemed to them a fair punishment for others.

Serra wrote to the military commander Fernando de Rivera y Moncada on July 31, 1775, about four men who had run from Mission Carmel. He asked to have them whipped "two or three" times. He offered to send shackles, iron rings locked around the legs or wrists. The journalist Elias Castillo, who has written against the missions, quotes the letter from Serra's collected writings.

Missionaries and soldiers used other punishments too. People were locked in the stocks, sometimes for days. People were hobbled, which means their legs were tied so they could only shuffle, and they were made to keep working. Others were beaten with a cudgel, a heavy club, or jailed and put to hard labor. For plotting, murder or armed rebellion, some people were executed. Soldiers raped Native women at missions including Soledad, San Luis Obispo, San Diego and San Gabriel.

**Baptisms and deaths.** The missionaries recorded 85,840 baptisms of Native people at the 21 missions from 1769 to 1834, and in the same years they recorded 59,538 Native deaths. That is about seven deaths for every ten baptisms. The death records for two missions are missing, so the real number of deaths is higher. These counts come from the Early California Population Project at the Huntington Library, and they run past 1800.

Other record collections cover different years and people, so their totals differ. One gives about 101,000 baptisms and 71,000 deaths. Another gives 95,493 baptisms and 56,776 deaths. The 2023 report lists the causes of death. They include forced moves, hard labor, the banning of Native ways of life, poor living conditions, violence, and new diseases brought in from outside.

### The Kumeyaay attack on Mission San Diego, 1775

Kumeyaay fighters burned Mission San Diego on the night of November 4 to 5, 1775. They came from fifteen of the twenty-five villages nearest the mission. Spanish soldiers estimated that 600 to 1,000 people took part.

**Why they attacked.** The attackers left no account of their own, but the Spanish records list what the Kumeyaay had been complaining about. From 1769 to the end of 1774 the friars had baptized only 100 people, and then they pushed much harder. On October 3, 1775, the friars baptized sixty people in a single day.

Spanish soldiers had raped Kumeyaay women, and at least one of those women was also murdered. Father Luis Jayme, a friar at the mission, had reported the rapes. Spanish cattle had destroyed village land. Writers at the Smithsonian's National Museum of the American Indian list the Spanish destruction of Native food sources and the Spanish taking of Native land among the causes. Disease was also spreading.

The attackers burned the mission and took goods from the church. They killed three people: Father Jayme, and a carpenter and a blacksmith from Mexico. They shot Jayme with an arrow and then beat him to death.

After the attack, Spanish soldiers took violent revenge. They went through the villages in force and singled out the people they believed had led it. The records give no number of the people they punished or killed, and the 2023 report does not say what the soldiers did to the people they singled out. The mission was rebuilt.

### Toypurina

> **Who:** A Tongva woman, often called a religious leader, who helped plan an attack on Mission San Gabriel.
>
> **When and where:** Japchivit and Mission San Gabriel, near what is now Los Angeles, 1785.

**The soldiers were warned and arrested twenty-one rebels before the attack.**

Toypurina was a Tongva woman from the village of Japchivit who had never been baptized. She had influence and standing in her community, and writers often call her a shaman, a religious or spiritual leader. In October 1785 she helped plan an attack on Mission San Gabriel. Soldiers at the mission were warned, and they arrested twenty-one of the rebels before the attack began.

**The plan.** The plan started with Nicolás José, a baptized Tongva man. He had lost a son and two wives. He asked Toypurina to call together the leaders of the other villages. One of those village leaders carried her message into the mission. People from the mission and from up to eight Tongva villages joined the plan.

When they were questioned, Nicolás José and Toypurina gave their reasons. Nicolás José said that the ban on dancing kept him from holding the ceremonies of mourning for the dead. Toypurina said she was angry with the Spanish settlers. She was also angry with the Native people who had moved to the mission, which stood on her land.

All of the leaders were held in jail for two and a half years. Then Spanish officials freed two of the village leaders with a warning. They exiled Nicolás José and Toypurina, sending them away from their homes.

**Not known:** the year of her birth and the rest of her life. The records of the plot do not give them.

**If you remember one thing:** Americans argued over whether anyone should be taxed to support a church, and in Virginia the side against church taxes won.

**One number:** 59,538 Native deaths recorded at the California missions from 1769 to 1834, against 85,840 baptisms. That is about seven deaths for every ten baptisms, and the real count of deaths is higher.

**Next:** After 1800 revivals spread across the whole country, and Protestant mobs turned on Catholics and Latter-day Saints.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 27 minutes**

Protestant revivals were held in almost every corner of the country between 1800 and 1850, so many that one religious magazine stopped reporting them in 1827. Its editors wrote that revivals "are becoming too numerous in our country to admit of being generally mentioned in our Record." In 1833 Massachusetts lawmakers stopped using tax money to pay for churches, and no other state still did.

The kind of Protestant faith that spread in these years is called evangelicalism. Evangelical preachers called on each listener to be converted, to turn to God and become a true believer, and they called this change the "new birth." Converted people started societies to hand out Bibles and religious papers, teach children, and send out missionaries. Some of the societies worked to get people to stop drinking, because their members believed a sober person was readier to be converted.

A Library of Congress exhibit lists the six largest of these societies in 1826 and 1827, among them the American Sunday School Union and the American Tract Society.

**Mobs and splits.** In the same fifty years, Protestant mobs burned a school run by Catholic nuns near Boston and Catholic churches in Philadelphia, and a Missouri governor ordered the members of a new church driven from his state. Methodists and Baptists in the South broke away from their national churches over slavery and formed churches of their own. In California the whippings at the missions went on, and the Mexican officials who took the missions away from the friars often whipped people too.

### Camp meetings

Big revivals began at both ends of the country in 1800, in New England and in Kentucky. A Library of Congress exhibit calls the New England revival "decorous," which means calm and proper, and the Kentucky revival "exuberant," which means full of wild feeling. In Kentucky, Presbyterian ministers started a new kind of gathering, the camp meeting.

The ministers copied the long outdoor "communion seasons" of the Church of Scotland, gatherings for communion, the church service in which believers share bread and wine in memory of Jesus. Families loaded wagons, drove to the meeting, pitched tents, and stayed for several days of preaching.

**Cane Ridge.** One camp meeting was held at Cane Ridge, near Lexington, Kentucky, in the summer of 1801. A Presbyterian minister named Barton Stone organized it. In 1832 Stone and Alexander Campbell left the Presbyterians and formed a new church, the Disciples of Christ.

Lorenzo Dow was a traveling Methodist preacher. While he preached, people in his crowds often jerked their bodies about, which was called the jerking exercise. The Presbyterians and Baptists who had started camp meetings soon turned against them because of the strong feelings they stirred in people. The Methodists kept them and carried them east, and for decades camp meetings were a Methodist practice.

**A drawing from 1809.** Benjamin Henry Latrobe drew a plan of a Methodist camp meeting in Fairfax County, Virginia, on August 8, 1809. His drawing shows the men's seats apart from the women's and the tents of Black worshippers apart from the tents of white worshippers. At one side of the camp, the organizers had built a pen of boards filled with straw. Latrobe wrote that "the converted were thrown" into it "that they might kick about without injuring themselves."

A Library of Congress exhibit calls this drawing an example of separation by race. That separation led Black Methodists, a few years later, to leave and form a Methodist church of their own.

Mother Ann Lee, who founded the Shakers, came to America from England in 1774. The Shakers' full name was the United Society of Believers in Christ's Second Coming. They danced in worship, often in circles inside circles, and got their nickname from shaking and whirling during services. In the early 1800s Shakers from New York went to Kentucky to see the revivals, and they gained a small number of converts there.

### Sunday schools taught reading

The first Sunday schools taught poor children to read. Sunday schools began in England in the 1780s. In 1791 a group of pastors and merchants in Philadelphia started the First Day Society. Its members paid schoolmasters to teach boys and girls, and grown men and women who could not read, to read and write. The Bible was the textbook. Sunday was the day poor working children were not at work, and there were no free public schools yet.

A group of Philadelphia businessmen started the Sunday and Adult School Union in 1817, with volunteer teachers instead of paid ones. Within a year they had opened forty-three Sunday schools in the city, with 5,970 pupils. The group grew into the American Sunday School Union. Its leaders hired missionaries who started Sunday schools in cities, in the countryside and on Native reservations, and it became a large publisher of children's books.

**Tracts.** The American Tract Society began in 1825 to print tracts, short papers about religion. A Library of Congress exhibit gives an estimate that its members handed out 35 million books and tracts in its first ten years. Its leaders printed papers that urged readers to be converted and to give up drinking and gambling, which the leaders believed kept people from being converted.

Rebecca Gratz started the first Hebrew Sunday School, a Sunday school for Jewish children, in Philadelphia in 1838.

### The African Methodist Episcopal Church grows

The African Methodist Episcopal Church, which Richard Allen and other Black Methodists formed in 1816, grew fast. It began with 8 ministers and 5 churches. By 1846 it had 176 ministers, 296 churches and 17,375 members.

Women preached in the church from its early years. Many people objected to women preaching, in the A.M.E. Church as in the white churches. An engraving made in Philadelphia in 1844 by P. S. Duval, from a painting by Alfred Hoffy, shows one of these women: Juliann Jane Tillman, a preacher of the A.M.E. Church.

### The convent burned at Charlestown, 1834

Some Protestants in these years turned to violence against Catholics. In Charlestown, Massachusetts, near Boston, Ursuline nuns, Catholic women who make religious promises and live together in a convent, ran a convent school from 1819. The Ursulines are an order of nuns who teach, and their students were girls.

**The stories.** Stories about the convent spread in Boston. Rebecca Reed, a Protestant woman, had entered the convent in 1832 and left after less than six months. Her stories about life inside went around before her book, *Six Months in a Convent*, came out in 1835.

A nun named Sister Mary John, whose name before she joined the order was Elizabeth Harrison, left the convent on July 28, 1834. Bishop Fenwick, the church leader in charge of all the Catholic churches of the area, talked her into going back. Rumors spread that she was being held against her will.

The Protestant minister Lyman Beecher preached against Catholic schools in three Boston churches on Sunday, August 10. The next day a group of Charlestown officials toured the convent, and Sister Mary John guided them. Historians disagree about whether Beecher's sermons led to what happened that night. Ira Leonard argues that they did. Ray Billington points out that the workmen had met before the sermons. Beecher himself said that probably no rioter had heard him.

**The fire.** A mob of mostly Protestant workmen from Charlestown burned the convent school on the night of August 11 to 12, 1834. The nuns and 47 girl students were inside when the mob came, and only six of the girls were Catholic. The mob also broke open the convent's tomb, where several dead nuns were buried. Firemen stood by and watched. No deaths are recorded.

Police arrested 13 men. Juries found 12 of them not guilty, including John R. Buzzell, who admitted he had led the mob. The one man found guilty was 16 years old, and Governor John Davis pardoned him, which means he freed him from his punishment.

### Whose Bible? Philadelphia, 1842 to 1844

Pennsylvania's lawmakers passed a law in 1838 that made the King James Bible, the Bible that Protestants used, a required textbook in the public schools. In Philadelphia, Protestant teachers also led their pupils in Protestant hymns, or church songs.

**The bishop's letter.** Bishop Francis Patrick Kenrick, the Catholic bishop of Philadelphia, wrote to the board that ran the city's public schools in 1842. He objected to the hymns and to the Bible readings. He asked that Catholic children be allowed to read the Douay Bible, the translation Catholics use, and that they not be made to join in Protestant worship.

Early in 1843 the board members agreed that children could be excused from the King James Bible and could use any Bible "without note or comment." The Douay Bible has notes and comments. Under the board's rule, the one Bible the Catholic bishop had asked for was still not allowed.

**The rumor.** Hugh Clark, a Catholic school director in the Kensington neighborhood, suggested in February 1844 stopping Bible reading until the board could write a rule both sides accepted. A rumor spread that Clark had ordered a teacher, Miss Bedford, to stop reading the Protestant Bible. Witnesses later showed that the rumor was false.

Nativists, people who opposed Catholic immigration and saw Catholics as a danger to the Protestant faith, spread it anyway. A newspaper editor named Lewis Levin had founded their group in Philadelphia, the American Republican Association, in December 1843.

**The May riots.** The nativists held a rally on May 3, 1844, and marched into Kensington, where Irish Catholic families lived. On May 6 a nativist named George Shiffler was shot dead. By the end of that day a second man, who seems to have been a bystander, had been shot dead. Two more nativists were shot that day and later died of their wounds. The Encyclopedia of Greater Philadelphia does not name who shot any of them.

Nativist crowds burned St. Michael's Church, St. Augustine's Church and Irish Catholic homes, including Hugh Clark's house, on May 8. They also burned a Catholic seminary, a school for training priests.

**The July riots.** Fighting started again in July, at the Church of St. Philip de Neri in the Southwark neighborhood. State militia, part-time soldiers called up by the state, fought the crowd with cannon under General George Cadwalader. By the morning of July 7, four militiamen and probably about a dozen rioters were dead, and many more were wounded.

Counts of the dead in the two riots differ. Counts for May run from at least 14 dead to 20, and one count gives at least 100 wounded. Counts for July run from at least 14 dead to about 16.

**Who was blamed.** A grand jury, a group of citizens who decide whether there is enough proof for a trial, charged 19 rioters with crimes, and only a few were found guilty. The grand jury blamed the May riots on "the efforts of a portion of the community to exclude the Bible from the public schools." The jurors meant the Catholics who had been attacked.

Catholics answered that the grand jury had called no Catholics to testify. After the riots, Catholics decided to build a school system of their own.

**By 1844:** Protestant mobs had burned a convent school near Boston and two Catholic churches in Philadelphia, and Catholics had decided to build schools of their own.

### The Latter-day Saints driven out of Missouri

Joseph Smith founded the Church of Jesus Christ of Latter-day Saints on April 6, 1830, at a farmhouse near Fayette, in western New York. Its members were often called Mormons. In 1831 Smith said that God had chosen western Missouri as the place where his people would gather. Church members moved there, and their Missouri neighbors drove them out twice.

**Jackson County, 1833.** The first time was in Jackson County in 1833. The older settlers feared that the newcomers would control the county's politics and trade, and they objected to the newcomers' religious beliefs. An article in the church newspaper about free Black converts coming to Missouri, a state that allowed slavery, also angered them.

A mob attacked the church's printing office on July 20, 1833, threw the press out of the window, and scattered the type in the street. They tarred and feathered Edward Partridge, the church's bishop in Missouri, and Charles Allen in the public square. In tarring and feathering, men tore off a person's clothes and smeared hot pine tar on the bare skin, which burned it. Then they covered the person with feathers, which stuck to the tar. The church's account does not describe the injuries the two men suffered.

Mobs drove the church members out of the county in November 1833. Three people were killed on November 4, one of them a church member, and the church's account does not say who killed them.

**Caldwell County, 1836 to 1838.** The Missouri lawmakers created Caldwell County in 1836 as a place for church members to live. More converts kept arriving and settled beyond its borders. In 1838 both sides used violence. The Missouri State Archives states that "Old Settler mobs and Mormon paramilitary units roamed the countryside," paramilitary units being armed groups organized like an army.

Some Latter-day Saint men formed the Danites, a group of vigilantes, people who act as their own police and punish others outside the law. In the middle of October, Mormon forces raided the towns of Gallatin and Millport and burned property there. Shortly before the end of October, at Crooked River, church members attacked a unit of the state militia that they took for a mob. One Missourian and two church members were killed. One of the dead was David W. Patten, an apostle, one of the church's highest leaders.

**The governor's order.** Governor Lilburn Boggs issued an order on October 27, 1838. It said the Latter-day Saints must be driven from the state or "exterminated," killed every one, if necessary.

**Haun's Mill.** Three days later, on October 30, between about 200 and 240 armed men attacked the small church settlement at Haun's Mill at about 4 in the afternoon. Colonel Thomas Jennings of Livingston County commanded them, and Captain Nehemiah Comstock led one of the companies.

Boggs had not ordered this attack. The Missouri State Archives says it happened "even without official sanction," which means without the governor's approval. The historian Alma Blair writes that the governor's order "was now widely known."

Many of the Mormon men took cover in the blacksmith shop, and the attackers shot them through the cracks in its walls. The attackers then hacked some of the wounded men to death with corn knives, long blades used for cutting cornstalks. One of them shot Thomas McBride with McBride's own rifle as he surrendered, and then the attackers hacked him.

They killed seventeen or eighteen men and boys. The Missouri State Archives gives eighteen, and Blair and the church's history give seventeen. Among the dead was Sardius Smith, age 10. Charles Merrick, age 9, died of his wounds five weeks later. One woman was wounded. No record shows that anyone was ever tried for the killings at Haun's Mill.

General Samuel D. Lucas arrested Joseph Smith and other church leaders on October 31. Over the next year about 8,000 church members, driven out under the governor's order, went from Missouri to Illinois. The Missouri State Archives describes them as "often ragged and deprived of their property." Governor Boggs's order stayed in force until June 25, 1976, when Governor Bond canceled it.

### Joseph Smith

> **Who:** The founder of the Church of Jesus Christ of Latter-day Saints, whose followers were driven from state to state. A mob killed him in 1844.
>
> **When and where:** Lived 1805 to 1844. Western New York, Ohio, Missouri, and Nauvoo, Illinois. Killed at Carthage, Illinois, on June 27, 1844.

**About 100 men broke into the jail at Carthage, Illinois.**

Joseph Smith founded a new American church in 1830, and a mob killed him fourteen years later. He grew up in a part of western New York that people called the Burned Over District, because so many revivals had passed through it. A Library of Congress exhibit states that his church did not split off from an older church, and it describes the church as the only one of its kind.

**The Book of Mormon.** E. B. Grandin of Palmyra, New York, published the Book of Mormon for Smith in 1830. Smith said the book came to him through revelations, messages he said came from God, on a set of gold plates written in a language he called reformed Egyptian. He said he had translated it. Eleven men signed statements saying that they had seen and handled the plates.

The book tells of Israelites, the people of ancient Israel in the Bible, who were led out of Jerusalem to the Americas about 600 years before the birth of Jesus. It also tells of Jesus appearing to their descendants in America. Smith's followers believed his church brought back the earliest form of Christianity. Church members accept the Book of Mormon as scripture, a holy book, alongside the Bible.

**Nauvoo.** The church moved from New York to Ohio, from Ohio to Missouri, and from Missouri to Illinois. In 1839 church leaders bought land on the Mississippi River in Illinois, at a nearly empty town called Commerce, and they renamed it Nauvoo in 1840. A large Meskwaki village had stood there, and accounts of how its people lost it differ.

The Illinois Department of Natural Resources runs the state park at Nauvoo. Its page about the park states that the site was signed away in a treaty in 1824, but it does not name who signed it. Another account states that a man named James White bought it from the Sauk leader Quashquame for liquor and corn, and that Quashquame's people moved across the river.

In Illinois, trouble grew again. Neighbors resented the church members' business dealings and the way they all voted together. Some accused them of theft. They were angry about Smith's plans in politics. News spread that some church leaders had more than one wife, and church members also argued among themselves about it.

**Carthage.** Men who opposed Smith started a newspaper in Nauvoo, and Smith ordered its printing press destroyed. He was jailed at Carthage, Illinois, for it. On June 27, 1844, about 100 men broke into the jail and killed Smith and his brother Hyrum. The men came from three units of the Illinois militia: the 59th Regiment, the Warsaw Independent Battalion and the Warsaw Rifle Company.

The militiamen guarding the jail barely resisted. Accounts of the killing differ. A Library of Congress exhibit states that Smith was "apparently" shot, and that one man in the mob came at him meaning to cut off his head and was stopped.

**The trial.** Nine men were charged with the murders in October 1844. Four ran away and were never arrested. Five were tried in May 1845: Thomas C. Sharp, the publisher of an anti-Mormon newspaper, and four militia officers, Levi Williams, Mark Aldrich, William N. Grover and Jacob C. Davis, who was also a state senator. The jury found all five not guilty.

The prosecutor, Josiah Lamborn, said of Davis: "I have no doubt in my own mind, not a particle, that Davis cooperated in the murder, but there is no legal evidence to convict him."

After Smith's death, men attacked Mormon farms around Nauvoo. Brigham Young, who led the church after Smith, planned to move about 15,000 people west. On February 4, 1846, the first wagons crossed the Mississippi into Iowa.

### The religion enslavers taught

In the South, enslavers did not let enslaved people attend the regular preaching with them on working days. Charles Colcock Jones was a Presbyterian minister in Liberty County, Georgia. In 1842 he wrote that enslaved people "were not permitted, on working days, to attend the public administration of the word in company with their masters." By "the public administration of the word" he meant the regular preaching. Where they did attend, part of the white church was set apart for them.

Jones wrote a book to urge planters and ministers to have Christianity taught to the people they held in slavery. In *The Religious Instruction of the Negroes in the United States*, finished on July 4, 1842, Jones told ministers which parts of the Bible to use. ("Negro" was the common word for a Black person in his time, and it is no longer used.)

He chose verses about obedience. One verse says "servants" should "count their masters worthy of all honor," and Jones used it to teach enslaved people to obey. He wrote that a minister should teach them "the duties of their station," meaning their duty to obey.

**Frederick Douglass.** Frederick Douglass, who had been enslaved in Maryland, wrote down what this religion looked like to the people it was used on. Thomas Auld, the man who held Douglass, was converted at a Methodist camp meeting in Talbot County, Maryland, in August 1832. Douglass hoped Auld would free him, or at least treat him better. "I was disappointed in both these respects," he wrote. "I believe him to have been a much worse man after his conversion than before."

Douglass wrote that after his conversion, Auld "found religious sanction and support for his slaveholding cruelty," sanction meaning approval. Auld became a leader in his church, and visiting preachers stayed at his house. Douglass wrote: "while he starved us, he stuffed them."

At St. Michael's, Maryland, a young white man named Wilson started a Sunday school to teach enslaved people to read the New Testament. They met three times. Then Garrison West and Wright Fairbanks, two class leaders, each in charge of a small group of church members, came with many other men carrying sticks and other things to throw. The men drove the students away and forbade them to meet again.

**Henny.** Douglass saw Auld whip Henny, a young woman whose hands had been burned so badly in a fire when she was a child that she could not use them. Auld tied her up and whipped her bare shoulders with a heavy cowskin, a whip made of cowhide, "causing the warm red blood to drip." To justify it, he quoted the Bible: "He that knoweth his master's will, and doeth it not, shall be beaten with many stripes."

He left her tied up for four or five hours at a time. He whipped her before breakfast, went to his store, and came back and whipped her again at dinner "in the places already made raw." At last, in Auld's own words, he "set her adrift to take care of herself."

Douglass also named one minister, George Cookman, whom the enslaved people loved and believed was working to free them.

**What Douglass was against.** In 1845 Douglass added a note to the end of his book to explain that he was not against religion. He was against what he called "the slaveholding religion of this land." He wrote: "The man who wields the blood-clotted cowskin during the week fills the pulpit on Sunday." He wrote that the man who called it a religious duty to read the Bible denied him "the right of learning to read the name of the God who made me."

### The churches split over slavery

Members of two of the largest Protestant churches in the country divided them over slavery more than fifteen years before the Southern states left the Union.

**The Methodists.** Bishop James Osgood Andrew of Georgia held enslaved people, whom he had gained through his marriage. Methodist leaders met for their national meeting in 1844. The delegates, the men chosen to speak and vote for their churches, voted to stop Andrew from working as a bishop for as long as he held enslaved people.

A few days later the delegates adopted a Plan of Separation. Under the plan, the Methodist conferences in the slave states, the regional groups of churches there, could form a church of their own. Delegates from those conferences met at Louisville, Kentucky, in 1845 and created the Methodist Episcopal Church, South.

**The Baptists.** The Baptists split the same year. Georgia Baptists put forward an enslaver, James E. Reeve, to be a missionary, and Northern Baptists refused to appoint him. From May 8 to 12, 1845, Baptists from the South met at Augusta, Georgia, and formed the Southern Baptist Convention. William Bullein Johnson was its first president.

**By 1845:** Missouri's governor had ordered the Latter-day Saints driven out, a militia mob had killed their founder in Illinois, and Southern Methodists and Baptists had formed churches of their own over slavery.

### Charles Grandison Finney

> **Who:** A young lawyer who gave up the law after his conversion and became a revival preacher. His book on revivals became a handbook for other revival preachers.
>
> **When and where:** Born in Warren, Connecticut, August 29, 1792. Upstate New York, then Oberlin, Ohio. Died 1875.

**He told a client he now worked for "the Lord Jesus Christ."**

Charles Grandison Finney taught that a person could choose to be converted, and he built new methods of preaching on that idea. He grew up in Oneida County, New York, which was then, in his words, "to a great extent, a wilderness." His parents did not belong to a church. He wrote that there were few religious books where he grew up and that he "seldom heard a sermon."

**The retainer.** He was training to be a lawyer at Adams, New York, when he was converted in 1821. The next morning a client came to ask whether he was ready to argue the client's case in court. The client was a deacon, an officer of his church. Finney answered with a lawyer's word, retainer, the money paid to a lawyer to take a case: "Deacon B, I have a retainer from the Lord Jesus Christ to plead His cause, and I cannot plead yours."

**The anxious seat.** He preached across upstate New York. From September 1830 he spent six months in Rochester. He preached every day of the week and three times on Sunday, and he spent most of each day praying with people one at a time. In Rochester he began using what was called the anxious seat, a set of seats at the front of the church where people who felt worried about their souls came and sat, in front of everyone.

Finney explained that people of the "higher classes" were "too proud to take any position that would reveal them to others as anxious for their souls." He wanted "something that would commit them publicly to the service of Christ."

His methods were called the New Measures. Finney taught that a person could decide to be converted, and his meetings stirred strong feelings in the people who came. Both things angered other ministers. Asahel Nettleton, a New England revival preacher, objected that Finney had changed the older Presbyterian teaching on how God saves people. Lyman Beecher feared that Finney's meetings let feelings run wild.

As early as July 1827, before Rochester, ministers had met at New Lebanon, New York, to look closely at the New Measures. Finney's *Lectures on Revivals*, published in 1835, became a handbook for revival preachers across the country.

**Oberlin.** Oberlin College in Ohio was close to shutting down in 1835. Arthur Tappan, a businessman in New York who worked to end slavery, agreed to rescue it on two conditions. Finney had to be made its teacher of theology, the study of religious belief. And the college had to admit Black students on the same terms as white students.

Finney took the job and also became minister of the Oberlin church. He was president of the college from 1851 to 1866 and stayed on as minister until 1872. He taught that the sign of God's grace in a person "was a person's benevolence toward others," meaning kindness and help given to other people. He died in 1875.

### The California missions, 1800 to 1848

The California missions, run by Franciscan friars, went on through these years, and so did the whippings. Missionaries had Native people whipped for running away, stealing, fighting and drinking, for living with a partner without a church marriage, and for other acts that mission officials counted as disobedience. They often had soldiers or Native officials give the whippings, and some of them whipped people themselves. Father de la Peña did at Mission Santa Clara.

**Santa Cruz, 1812.** A 2023 report on the missions for the state of California says that at Mission Santa Cruz, Father Andrés Quintana used a whip tipped with metal for floggings, beatings on the bare back that cut and bruise the skin. In 1812 he had just beaten two men nearly to death with it when a group of Awaswas Ohlone people from the mission killed him. The records name five of them: Lacah, Yaquenonsat, Yachacxi, Ules and Lino.

For two years his death was taken to be a natural one. Then a guard overheard an argument, and the plan came out. Spanish officials tried sixteen men and found nine guilty. Seven of the men died while held at the presidio, the Spanish fort, four of them before they were sentenced. The story of the plan comes from Lorenzo Asisara, an Ohlone man whose father took part in it.

**Punished for having no children.** Diseases brought by the Spanish made Native women less able to have children, or made them lose their babies before birth. Some missionaries believed that women did this on purpose. Lorenzo Asisara told what Father Olbes did at Santa Cruz to a married couple who had no children. Olbes demanded to inspect the couple's genitals, the parts of the body used to make babies.

When the woman resisted, he had her flogged and made her stand in front of the church for nine days holding a wooden doll. Olbes also had her husband put in shackles, iron rings locked around the legs or wrists, and made him stand in front of the church wearing horns. At Mission San Gabriel, Father Zalvidea punished women whose babies were born dead. He had their heads shaved, made them carry a wooden doll, had them flogged, and kept them in iron ankle cuffs for three months.

**The Chumash rising, 1824.** Native people fought back. In February 1824 Chumash people rose against three missions, Santa Inés, La Purísima and Santa Bárbara, in the largest planned revolt in California in the mission years. It began at Santa Inés on February 21, a day earlier than planned, after soldiers whipped a Native man from La Purísima who had come to visit a relative in jail. The Chumash attacked the soldiers and burned mission buildings.

The next day troops from the Santa Bárbara fort burned the adobe houses, made of sun-dried mud bricks, where the rebels were camped. Up to nineteen Chumash people and one Mexican soldier were killed at Santa Inés. At Santa Bárbara the Chumash leader Andrés Sagimomatsee called people to fight. At least two Chumash were killed there, and more than 1,000 people fled the mission for the inland country of the Yokuts people.

At La Purísima, led by Pacomio, the rebels held the mission for almost a month. One Chumash man and four settlers were killed when the rebels took it. In March troops took it back and killed 16 Chumash people. Mexican officials then had seven Chumash men executed for killing the four settlers. They sentenced four leaders to ten years in prison followed by exile from their homeland, and eight more men to eight years.

**Estanislao and Yozcolo.** Hundreds of Yokuts people left Missions San José and Santa Clara in 1828 and 1829 under two mission leaders, Estanislao and Cipriano. They built a fort in the marshes of the San Joaquin River. Mexican officials sent soldiers, Native fighters and armed settlers against them, and these forces defeated them in a battle. The records give no count of the dead and do not name the commander. Estanislao later bargained for a pardon.

A man named Yozcolo freed the young women who were locked in the women's building at Mission Santa Clara in 1839, and fled to the hills. Soldiers defeated him. The records do not say who cut off his head. The Mexican officials there set it outside the mission church for people to see.

**The end of the missions.** Mexicans won their independence from Spain in 1821. Mexican officials then began to take the missions away from the Franciscans and turn them into ordinary parish churches, the local churches of a town. This was called secularization, and Governor José Figueroa put it in place in 1833 and 1834.

The officials who took over the missions often used punishments like the friars' punishments, including whipping. At most missions, colonists got most of the land and supplies. Under Figueroa's rules, Native people had no right to their own homelands. In 1845 officials passed the final law ending the missions.

The historian Cook estimated that about 310,000 Native people lived in California before 1769, give or take about a tenth. By 1845, by his estimate, their number had dropped by about half, to no more than 150,000. That count includes all Native Californians, not only the people held at the missions.

**If you remember one thing:** Mobs burned Catholic churches and drove out the Latter-day Saints, and almost none of the attackers were ever found guilty.

**A question for the next era:** would any tax money help pay for the schools Catholics planned to build?

**Next:** Between 1850 and 1900 the numbers of Catholics and Jews grew fast, slavery ended, and federal officials made Native ceremonies a crime.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 18 minutes**

Some Protestants met the fast growth of Catholics and Jews after 1850 with mobs, school laws and state constitutions. Catholics were about one person in twenty in the United States in 1850. By 1906 there were 14 million of them, about one person in six. Catholics answered by building their own schools. Jews started schools to train rabbis, the teachers and leaders of Jewish congregations.

**The end of slavery.** Census takers counted 3,953,760 enslaved people in the United States in 1860. Many were freed as the Union army advanced during the Civil War. In December 1865 enough state lawmakers had approved the Thirteenth Amendment, a change to the Constitution, to make it law. It bans slavery everywhere except as a punishment for a crime. Black members already ran some large churches of their own, and in 1865 their ministers spoke for the freed people of Savannah.

**On the reservations.** United States officials made Native religious ceremonies a crime in 1883, and that ban could be enforced until 1978. Churches also ran many of the government's boarding schools for Native children, with government money.

### Bloody Monday in Louisville, 1855

A political party called the Know-Nothings, or the American Party, grew large in the 1850s. Its members opposed Catholic immigration, and they feared that Catholics were a danger to Protestant faith and to democracy.

On election day, Monday, August 6, 1855, in Louisville, Kentucky, mobs led by Know-Nothing members attacked the German immigrant neighborhoods east of downtown and the Irish neighborhoods to the west. The mobs set fires and robbed homes and businesses.

An armed crowd set out to attack St. Martin of Tours, a German Catholic church, and the mayor, John Barbee, who was himself a Know-Nothing, turned it back. The Kentucky Historical Society's marker counts at least 22 dead and does not say who they were. Five people were later charged with crimes, and none was found guilty.

### Mountain Meadows, 1857

Members of the Church of Jesus Christ of Latter-day Saints killed about 120 people at Mountain Meadows, in Utah Territory, about 35 miles southwest of Cedar City, in September 1857. The victims belonged to the Baker-Fancher wagon train, a company of families mostly from Arkansas on their way to California. Only 17 children, all six years old or younger, were spared.

The killers were local militiamen, part-time soldiers of the territory, who were also church members, and Paiutes joined them. A statement from the church identifies five of the leaders: Isaac Haight, John D. Lee, William Dame, John Higbee and Philip Klingensmith. They held both church posts and militia or town posts. Haight was the regional church leader at Cedar City and second in command of the county militia. Dame was the colonel in command of the southern Utah militia. Higbee was the major in command at the meadows.

**The white flag.** The attack began on September 7, by Paiutes and by Mormon men dressed to look like Native Americans. On September 11, John D. Lee and William Bateman came to the wagon train under a white flag, the sign of a truce. They promised the travelers safe passage if they gave up their guns.

The militiamen walked the men of the wagon train out in a single line, each man beside an armed militiaman. Higbee called out, "Halt! Do your duty!" and each guard shot the man beside him. On the other side of the field, Nephi Johnson ordered the killing of the women and the older children.

**Why.** Douglas Linder of the University of Missouri-Kansas City gives three things behind the killings. Federal troops were marching on Utah that year, in what is called the Utah War. That spring, on May 13, 1857, Hector McLean had shot and stabbed Parley Pratt, a church leader, in Arkansas. Eleanor McLean had left her husband and become Pratt's twelfth plural wife, one of several wives he had at the same time. And in 1856 church leaders had held a preaching campaign called the Reformation.

**Disputed:** whether Brigham Young, the church's president, ordered the killings. In 2007 a church leader, Henry B. Eyring, said that Young's message telling local leaders not to interfere with the travelers arrived too late. Linder writes that Young reportedly said afterward, "It is all right. The only fear I have is from traitors."

**The trials.** Nine men were charged with crimes, and only John D. Lee was found guilty. A jury of church members found him guilty of murder on September 20, 1876. He was executed at Mountain Meadows on March 23, 1877, by a firing squad, a group of men who shoot a condemned person at the same time.

Speaking for the church on September 11, 2007, Eyring expressed "profound regret." He called the killings "a terrible and inexcusable departure from Christian teaching and conduct."

### Synagogues, schools for rabbis, and an order to expel Jews

About 2,500 Jews lived in the United States in 1800. By 1860 there were between 125,000 and 200,000, and by 1880 between 230,000 and 300,000, about a hundred times as many as in 1800.

Czar Alexander II, the ruler of Russia, was murdered in 1881, and pogroms followed in Russia. A Library of Congress timeline defines a pogrom as a "massacre often with government collusion," which means a mass killing of Jews, often with the help of government officials. After that, Jews from Eastern Europe came to America in great numbers.

**Schools for rabbis.** American Jews divided in these years into a traditional wing and a Reform wing, which was less traditional, and both wings built schools to train rabbis. Isaac Leeser, a leader of the traditional wing, founded Maimonides College in Philadelphia in 1867, the first school in America to train rabbis.

In 1873 thirty-four congregations, groups of Jews who worship together, formed the Union of American Hebrew Congregations. Its founders hoped it would take in every synagogue, or Jewish house of worship, in the country, and it became the union of Reform congregations instead. Two years later Isaac Mayer Wise, a leader of the Reform wing, founded Hebrew Union College in Cincinnati, which became the Reform wing's school for rabbis.

**The dinner.** The food served in 1883 at a dinner for the first class of rabbis from Hebrew Union College was not kosher, which means it broke Jewish food laws. Traditional guests walked out. The argument that followed led to calls for a more traditional seminary, and in 1887 the Jewish Theological Seminary opened in New York.

**General Orders No. 11.** During the Civil War, on December 17, 1862, General Ulysses S. Grant issued General Orders No. 11. It said that "The Jews, as a class," were "hereby expelled from the department within twenty-four hours," and it accused them of "violating every regulation of trade." The order applied to Jewish civilians in Kentucky, Tennessee and Mississippi, the area under his command.

Eleven days later, Cesar Kaskel and all the other Jews known in Paducah, Kentucky, got papers from the army ordering them to leave within twenty-four hours. Kaskel sent a telegram to President Lincoln and went to Washington. He met Lincoln on January 3, 1863, and Lincoln had General Henry Halleck cancel the order. The historian Jonathan Sarna's account of the order gives no count of the people expelled.

That same year, 1862, Jacob Frankel became the first Jewish chaplain in the United States Army, a religious leader who serves soldiers.

**Turned away at Saratoga.** Henry Hilton, the manager of the Grand Union Hotel in Saratoga, New York, turned away Joseph Seligman, a New York banker, and his family in 1877 because they were Jewish. Hilton blamed a drop in the hotel's business on guests who did not want to stay where Jews were let in.

A Library of Congress timeline describes it as a sign of "the growth of social anti-Semitism in America," anti-Semitism being hatred of Jews. That same year New Hampshire's lawmakers gave Jews the same political rights as other citizens.

### The ministers who spoke for the freedpeople

Secretary of War Edwin Stanton and General William Sherman met twenty Black men in Charles Green's house in Savannah, Georgia, on January 12, 1865, and asked them what freedom should look like. Thirteen of the twenty were ministers, ordained or licensed, which means their churches had made them ministers or given them permission to preach. The others included deacons, class leaders and other church officers.

The notes of the meeting record how large their churches already were. William J. Campbell, who had been freed by a will, was pastor of the First Baptist Church, with about 1,800 members. John Cox, who had bought his own freedom, led the Second African Baptist Church, with 1,222 members.

Another of the twenty, Jacob Godfrey, had been a class leader and a steward, a man who helped look after the church's business, in the Methodist church since 1836. Until the Union army came, he had been held as property by James E. Godfrey, a Methodist preacher who was serving in the Confederate army.

### Garrison Frazier

> **Who:** A Baptist minister who had bought his own freedom, chosen by the other Black church leaders at a meeting to tell the Secretary of War what freedom meant.
>
> **When and where:** Born in Granville County, North Carolina, about 1798. Savannah, Georgia, January 12, 1865.

**He said his people needed "land, and turn it and till it."**

The twenty church leaders at the Savannah meeting chose Garrison Frazier to answer for all of them, and his answers were written down.

He was 67 years old. Eight years before the meeting he had bought his own freedom and his wife's for $1,000 in gold and silver. He had been an ordained Baptist minister for thirty-five years, but by 1865 his health was so poor that he no longer led a congregation of his own.

**Slavery and freedom.** Asked what slavery was, he said it was "receiving by irresistible power the work of another man, and not by his consent." Asked what freedom was, he said it was "taking us from under the yoke of bondage, and placing us where we could reap the fruit of our own labor."

Asked how his people could best take care of themselves, he answered: "land, and turn it and till it by our own labor." He added: "that is, by the labor of the women and children and old men."

Asked whether Black people would rather live among white people or by themselves, he said: "I would prefer to live by ourselves, for there is a prejudice against us in the South that will take years to get over." Each of the other men was then asked the same question, one at a time, and all of them agreed with him. At one point Sherman left the room, and the men were then asked what they thought of him.

**Forty acres.** Four days after the meeting, Sherman issued Special Field Orders No. 15. In it he set aside about 400,000 acres of land along the coast, from Charleston to northern Florida, for freed families in plots of forty acres, and about 40,000 people settled there. In the fall of 1865 President Andrew Johnson reversed the order and gave the land back to its former owners.

### A Chinese temple in Weaverville, 1874

In Weaverville, in Trinity County, California, a temple of Taoism, a Chinese religion and way of life, burned down, and Chinese men there built a new one to replace it. Work began in February 1874, and the temple was dedicated that April. They named it the Temple of the Forest Beneath the Clouds.

It is the oldest Chinese temple in California that has been used without a break, and people still worship there. In 1956 Moon Lim Lee, a descendant of the men who built it, and his wife, Dorothy, gave it to California State Parks.

### A second school system

In Philadelphia, Bishop Kenrick had asked the public school board to let Catholic children read their own Bible, and under the board's rule the Douay Bible was still not allowed. So Catholics built parish schools, schools run by a local Catholic church. In 1834 there had been fewer than a dozen parish schools in the whole country, for about half a million Catholics. In the 1850s Bishop John Neumann began building parish schools in Philadelphia.

**Baltimore, 1884.** The Catholic bishops of the United States met at the Third Plenary Council of Baltimore from November 9 to December 7, 1884. They declared that every parish that could afford a school should run one. Their letter to Catholics said that parish schools should be as good as "the best schools of the country." It also said: "A Catholic congregation without a Catholic school is like a family without a mother."

**The Blaine amendment.** Congressman James G. Blaine of Maine, at President Grant's suggestion, proposed an amendment to the Constitution in 1875. Its words said that no money raised by taxes for public schools "shall ever be under the control of any religious sect," a sect being a religious group. Members of the House voted for it. In the Senate it fell four votes short. Lawmakers in thirty-seven states later put their own versions into their state constitutions.

Justice Clarence Thomas of the Supreme Court wrote about the amendment in 2000, in the case *Mitchell v. Helms*, for himself and three other justices. He said it came at "a time of pervasive hostility to the Catholic Church," a time when dislike of Catholics was everywhere. He wrote that "it was an open secret that 'sectarian' was code for 'Catholic,'" an open secret being something many people know but few say out loud.

Blaine ran for president in 1884. A pastor who supported him called the Democrats the party of "rum, Romanism and rebellion," Romanism being an insulting word for the Catholic Church. Blaine did not reject the remark. Lyle Denniston, writing for the National Constitution Center, says the remark and Blaine's amendment cost him many Irish Catholic votes. Blaine lost the election.

### Belief and practice: the Reynolds case

George Reynolds, a Latter-day Saint in Utah Territory, married a second wife while his first wife was still living, which was the crime of bigamy. A court found him guilty and sentenced him to two years in prison at hard labor, forced heavy work, and a $500 fine. He argued that his religion required him to have more than one wife. In a case decided in the Supreme Court's 1878 term, *Reynolds v. United States*, the justices ruled against him.

Chief Justice Waite wrote that laws "cannot interfere with mere religious belief and opinions," but "they may with practices." He wrote that excusing a crime because of religious belief would "permit every citizen to become a law unto himself."

### Hiram Price's rules against ceremonies, 1883

Hiram Price, the Commissioner of Indian Affairs, issued a set of rules on March 30, 1883, for the Court of Indian Offenses, which tried Native people for breaking them. He wrote them after the Secretary of the Interior, Henry M. Teller, sent him a letter on December 2, 1882. In it Teller objected to the work of medicine men, Native healers and religious leaders. He called Native dances "heathenish," his insult for the ways of people who were not Christian.

Price's rules named ceremonies as crimes: "The 'sun-dance,' the 'scalp-dance,' the 'war-dance,' and all other so-called feasts assimilating thereto, shall be considered 'Indian offenses.'" The words "assimilating thereto" mean "like those dances." For a first offense, officials took away the person's rations for up to ten days. For a second, they took away rations for fifteen to thirty days, or jailed the person for up to thirty days.

**Food as punishment.** Rations were the food that United States officials had agreed by treaty to give to Native nations whose hunting lands United States officials had taken. So the punishment for dancing was that a family went without food for as long as a month.

Another rule said that "the usual practices of so-called 'medicine-men' shall be considered 'Indian offenses.'" A medicine man could be jailed for at least ten days, and kept there until he showed that he had given up his practices. These rules could be enforced for ninety-five years, until 1978, when members of Congress passed the American Indian Religious Freedom Act.

**Alaska.** Missionaries worked against Native ceremonies in Alaska too. In 1885 missionaries of the Moravian Church, a Protestant church, arrived at Quinhagak, a Yup'ik village. They called Yup'ik masked dancing "heathen rites" and "idol worship," and they recruited Yup'ik helpers as missionaries. After the missionaries came, no traditional dancing took place in Quinhagak for more than a hundred years, until 2013. The 2015 *Archaeology* magazine report on the village does not say who stopped the dancing or how.

### The churches and the boarding schools

Federal officials handed many of the Indian boarding schools, schools where children live as well as study, to churches to run, and they paid the churches to do it. Federal officials used these schools to assimilate Native children, which means to make them give up their own nations' ways of life. In a report published in 2024, investigators at the Department of the Interior counted 417 federal Indian boarding schools. A religious group ran 210 of them, about half.

At least 59 different religious groups received federal money to run or support the schools. That count leaves out the schools that churches ran without any federal money.

**What staff did to the children.** The same federal investigation recorded what staff at the schools did to the children. Staff cut the children's hair, took away their clothes for uniforms, gave them English names and forbade their own languages. Punishments included beatings, solitary confinement, which means being locked up alone, withheld food, and mouths washed out with soap.

At least 973 children died at the schools, and investigators found at least 74 marked and unmarked burial sites at 65 schools. The report states that the true number of deaths is higher.

**Which churches.** The investigators counted 132 schools tied to Protestant churches, 77 to the Catholic Church, and 5 to other groups. Some schools were tied to more than one. The Presbyterians had the most, with 31 schools. The Quakers, the American Board of Commissioners for Foreign Missions, the Methodists and the Episcopalians each had 12 or more.

On the Catholic side, the Jesuits, an order of priests, had 10. Many orders of Catholic nuns are on the list, among them the Sisters of Mercy, the Sisters of St. Joseph, the Ursulines and the Grey Nuns.

**The money.** The payments began long before. In the Civilization Fund Act of March 3, 1819, members of Congress set aside $10,000 a year to teach Native nations "the habits and arts of civilization." Officials often gave that money to religious groups, until members of Congress stopped the yearly payment in 1873. From 1871 to 1969, by the investigators' estimate, members of Congress set aside more than $23.3 billion, in 2023 dollars, for the boarding schools and related programs.

Government records show how much power officials handed to the churches. Each reservation was run from an office called an agency, by a government agent. In 1872 the Commissioner of Indian Affairs wrote that the agencies had been divided among the churches. Each church could put forward the person to be the agent in charge and could "assume charge of the intellectual and moral education of the Indians."

A Senate report of 1969 describes this as "an unprecedented delegation of power by the U.S. Government to church bodies," a handing over of power never done before. The report states that the "military was frequently called in to reinforce the missionaries' orders," which means soldiers were often brought in to back up what the missionaries ordered.

### The Ghost Dance, 1889 and 1890

**Wovoka's vision.** A Northern Paiute man named Wovoka, whose English name was Jack Wilson, had a vision on January 1, 1889, during an eclipse of the sun. By one account, he saw a world made new, with the dead alive again, the buffalo back, the land restored, the settlers gone and everyone living in peace.

A young Arapaho man, Casper Edson, wrote down Wovoka's message for a group of visitors. In it Wovoka said: "You must not hurt anybody or do harm to anyone. You must not fight. Do right always." He said that "the dead are all alive again" and told people to dance every six weeks.

He also warned: "Do not refuse to work for the whites and do not make any trouble with them until you leave them." The dance and its teaching spread across the reservations of the Plains, and the religion became known as the Ghost Dance.

The teaching changed as it spread. At the end of October 1890, the Lakota leader Short Bull told a gathering near Pine Ridge that "the whites were interfering so much in the religious affairs of the Indians" that he would make the great change, the new world of Wovoka's vision, come sooner. In that change, he said, "the white race itself would soon be annihilated," wiped out completely. He told the dancers to keep dancing even if soldiers surrounded them, because "the guns of the soldiers would be rendered harmless."

**The agent's fear.** Daniel F. Royer became the government agent at Pine Ridge in October 1890. On October 12 he reported that more than half of the 6,000 Lakota people at his agency were dancing, and he suggested calling in the army. General Miles told him the excitement would die down. On October 30 Royer wrote that 600 or 700 soldiers were needed.

Royer sent a telegram on November 15 saying "that the Indians were wild and crazy and that at least a thousand soldiers were needed." The Lakota called Royer "Young-man-afraid-of-Indians." Officials in the Indian Office passed his request to the War Department. In the middle of November 1890, President Benjamin Harrison ordered troops onto the reservations.

**Wounded Knee.** Soldiers killed between 250 and 300 Lakota people at Wounded Knee on December 29, 1890, most of them women and children. Chapter 2, Native Nations, tells what happened there.

**If you remember one thing:** As Catholics and Jews grew in number, some Protestants answered with mobs and with laws that kept tax money from Catholic schools.

- In 1850: about one American in twenty was Catholic.
- In 1906: about one in six was, 14 million people.

**Next:** After 1900 a new kind of worship began in Los Angeles, and a new Ku Klux Klan made opposing Catholics and Jews one of its central beliefs.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 23 minutes**

New kinds of worship spread across the United States between 1900 and 1950. In the same years some Americans attacked other Americans because of their religion. A Black preacher, William J. Seymour, led a revival in Los Angeles in 1906, and Pentecostal worship began there. Pentecostals believe that God's Spirit fills a person, who then speaks in sounds he or she never learned. Aimee Semple McPherson preached from her Los Angeles church to listeners at home by radio.

**Attacks.** A new Ku Klux Klan, open only to white Protestant men born in America, made opposing Catholics and Jews one of its central beliefs. In 1915 a group of men in Georgia hanged a Jewish factory superintendent named Leo Frank. In 1940 mobs attacked Jehovah's Witnesses for refusing to salute the flag. Christians also argued with other Christians about how to read the Bible, and in 1925 both sides made their case at a trial in Tennessee.

**On the reservations.** Federal officials went on punishing Native people for holding their ceremonies. In the 1930s John Collier, the new Commissioner of Indian Affairs, the head of the federal office in charge of Native affairs, ordered the punishments stopped, but the rules of 1883 that made the ceremonies crimes stayed in the law.

### Native ceremonies still punished, 1902 to 1940

Era 7 tells how Hiram Price's rules of 1883 made Native dances and the work of medicine men, Native healers and religious leaders, into crimes punished by the loss of food rations or by jail. Federal officials kept enforcing those rules after 1900. Commissioners of Indian Affairs kept issuing new orders against Native dances into the 1920s.

**Hair and dances, 1902.** Commissioner William A. Jones wrote to the superintendents, the officials in charge of each reservation, on January 11, 1902. He told them that "Indian dances and so-called Indian feasts should be prohibited," which means banned. He also wanted Native men to cut their long hair, and he suggested that superintendents hold back the men's rations and jobs until they did.

Charles Burton was the superintendent for the Hopi and the Navajo. The historian Tisa Wenger writes that he reportedly used "whips, guns, and sheep shears" to force men to obey the order. The surviving accounts do not say how many men were forced to cut their hair. People objected in print, including in the magazine *Harper's Weekly*, and officials then sent new directions advising "persuasion and example, rather than force."

**The Kiowa Agency.** At the Kiowa Agency, the federal office that ran the Kiowa reservation in Oklahoma, Superintendent C. V. Stinchecum held back people's own money to stop them from dancing. Kiowa families had trust money, money that belonged to them and that the government held for them. Stinchecum ruled that a man would not "receive his money until he has given his word of honor to the Superintendent that he will not again indulge in either a ghost dance or a give-away dance."

The Ghost Dance was the religion that spread across the Plains reservations in 1889 and 1890, and a give-away dance is a gathering at which people give gifts, such as horses, to others. By early December 1916 Stinchecum had held back the money of about ninety people.

Stinchecum sent the Indian Office, the federal office in charge of Native affairs, a list of 109 names in January 1917. Among them were Humming Bird, George Mopope and Silver Horn. To get their money, they had to sign a sworn paper promising not to dance.

Eleven horses were given away at a Fourth of July dance near Anadarko in 1921. Stinchecum accused nine Kiowa men of "the reckless giving away of property" and held their money until they signed a promise never to do it again. By early November only three of the nine had signed.

**Orders from Washington.** Charles Burke, the Commissioner of Indian Affairs, sent out Circular 1665, an order sent to every office at once, on April 26, 1921. It was titled "Indian Dancing." It allowed any superintendent to stop a dance he judged immoral or against the community's interest. Burke added a supplement on February 14, 1923, and a message "To All Indians" ten days later.

**Collier's order.** John Collier became Commissioner of Indian Affairs in April 1933. In 1934, with the approval of Harold Ickes, the Secretary of the Interior, Collier sent every agency a circular titled "Indian Religious Freedom and Indian Culture." It stated that "no interference with Indian religious life or ceremonial expression will hereafter be tolerated." The scholar Lee Irwin calls it the federal government's first policy statement protecting Native religious rights. At the Kiowa Agency, the punishments for dancing stopped soon after Collier took office.

Federal officials could still punish people under the 1883 rules until 1978. In 1940 federal rules under the Bald Eagle Protection Act also made it a federal crime to have eagle feathers. Under those rules, federal prosecutors took traditional practitioners, people who kept the old ceremonies, to court for holding eagle feathers.

### Nicholas Black Elk

> **Who:** An Oglala Lakota holy man who was also a Catholic catechist for decades.
>
> **When and where:** Born December 1863 on the Little Powder River. Pine Ridge, South Dakota. Died August 1950.

**"The only thing I really believe is the pipe religion," he said.**

Nicholas Black Elk kept his standing as a Lakota holy man while he worked for decades as a Catholic catechist, teaching the faith and preparing people for baptism, the Christian ceremony with water in which a person joins the church.

**The vision.** He was born on the Little Powder River, in land that later became Wyoming, and in his ninth year he had a vision. In it, in the words of the National Park Service, he "met with a council of the Six Grandfathers representing the four cardinal directions as well as the earth and sky," the four directions being north, south, east and west. The vision gave him the power to heal and a pipe made of pipestone.

He was at the Battle of the Little Bighorn on June 25, 1876, when he was twelve. There he took his first scalp, cutting the skin and hair from a person's head. He also collected guns, ammunition and clothing from dead and dying soldiers.

**Abroad.** In 1886 he joined Buffalo Bill's Wild West, a traveling show, and performed at Madison Square Garden in New York. The next year the show sailed to England for Queen Victoria's Golden Jubilee, the celebration of her fifty years as queen. He was separated from the show, traveled around Europe on his own, found Buffalo Bill again and came home.

**Wounded Knee.** He was back at Pine Ridge in 1889 and took part in the Ghost Dance ceremonies. On December 29, 1890, soldiers of the 7th Cavalry, a regiment of soldiers on horseback, opened fire on a band of Lakota people at Wounded Knee Creek. They killed between 250 and 300 of them, most of them women and children. Black Elk heard the cannon and gunfire. He came to Wounded Knee, helped the survivors and wept for the dead.

He married Katie War Bonnet in 1892, and their children were baptized. Katie died in 1903. In 1904 he was baptized a Catholic and took the name Nicholas. In 1930 the poet John G. Neihardt interviewed him, and the book *Black Elk Speaks* came out in 1932.

He died in August 1950. Near the end of his life he told his daughter Lucy, "The only thing I really believe is the pipe religion." In 2017 Catholic leaders of the Diocese of Rapid City, the church's area centered on that city, opened his cause for sainthood, the first step toward the church naming him a saint.

### Azusa Street, 1906

A new kind of Christian worship began in Los Angeles in April 1906, at meetings led by a Black preacher named William J. Seymour. It is called Pentecostal. The name comes from the Day of Pentecost, when, the Bible says, the first Christians were filled with the Holy Spirit, the Spirit of God. Pentecostals held that this still happens, and that speaking in tongues, speaking sounds that the speaker has not learned and does not understand, is the proof.

The first speaking in tongues came on April 9, 1906, at a house at 214 North Bonnie Brae Street, after a month of prayer and fasting.

**312 Azusa Street.** In mid-April the meetings moved to 312 Azusa Street, into a room about 40 feet by 60 feet. The building had been put up as a church of the African Methodist Episcopal Church, the church that Black Methodists formed in 1816. Biddy Mason, a woman who had been enslaved and won her freedom in a California court, had founded that church. By 1906 the building had been used as a tenement, a crowded apartment house, and as a livery stable, where horses were kept for hire.

The first people at the meetings were Black washerwomen, maids and laborers. Later most of the members and visitors were white. The University of Washington's architecture records call it "one of the first religious congregations in the U.S. that consisted of black and white parishioners together under a African-American pastor." That means Black and white worshippers met together under a Black pastor. The mission met there from 1906 to 1931.

### William J. Seymour

> **Who:** The Black preacher who led the Azusa Street revival in Los Angeles, where Pentecostal worship began.
>
> **When and where:** Born May 2, 1870, at Centerville, Louisiana. Los Angeles from early 1906. Died September 28, 1922.

**He learned the teaching sitting in a hallway outside the classroom.**

William J. Seymour's parents, Simon and Phyllis Seymour, had both been enslaved.

**Houston, 1905.** In Houston in 1905 he asked to study at a Bible school run by a preacher named Charles Fox Parham. Under Texas law, Black and white students could not sit in the same classroom, so Parham had Seymour sit in the hallway and listen to the lectures through the doorway. There Seymour learned the teaching that speaking in tongues is the proof that the Holy Spirit has filled a person.

**Locked out.** Early in 1906 he came to Los Angeles. Julia Hutchins had invited him to help lead a Holiness church there, a church of one of the Protestant groups of the time. He preached what he had learned in Houston, and the congregation locked him out of the building. He kept preaching at a house on Bonnie Brae Street, where the speaking in tongues began on April 9, 1906. Within days the meetings moved to Azusa Street.

The people of Seymour's mission began printing their own newspaper, *The Apostolic Faith*, in September 1906. It was sent out free, and at its height it went to about 50,000 subscribers around the world.

Seymour ran the Apostolic Faith Mission at Azusa Street. He died on September 28, 1922, and the mission kept meeting there until 1931. The building is gone. A plaque on the spot reads "Site of the Azusa St. Revival from 1906 to 1931. Cradle of the Worldwide Pentecostal Movement."

### Leo Frank, 1913 to 1915

A group of men in Georgia kidnapped and hanged Leo Frank, a Jewish factory superintendent, in 1915, after the governor spared his life. Frank ran the National Pencil Company in Atlanta. In 1913 a jury convicted him of murdering Mary Phagan, a thirteen-year-old girl who worked at the factory. The Georgia Historical Society's marker at the site describes it as "a highly controversial trial fueled by societal tensions and anti-Semitism," anti-Semitism being hatred of Jews.

Crowds outside the courthouse cheered the prosecutor. Much of the newspaper coverage was anti-Semitic in tone, according to The Temple, the Atlanta Jewish congregation that Frank belonged to. It is a Reform congregation, part of the less traditional branch of Judaism. Tom Watson, the publisher of a paper called *The Jeffersonian*, campaigned against Frank and against Jews in general, and more people bought his paper.

**The lynching.** Governor John M. Slaton commuted Frank's sentence from death to life in prison, changing it to a lighter one. On August 17, 1915, a group of men took Frank from the state prison at Milledgeville. They took him to Marietta, Mary Phagan's hometown, and hanged him before a local crowd. This was a lynching, a killing by a mob that had no legal right to kill.

The men called themselves the Knights of Mary Phagan. The New Georgia Encyclopedia describes them as twenty-five prominent citizens of Marietta. No one was ever tried for killing Frank.

**The pardon.** Georgia officials granted Frank a pardon, an official act that forgives a crime or cancels its punishment, in 1986, after his death. This pardon was given "without addressing guilt or innocence," so it did not say whether he had killed Mary Phagan. The marker says the pardon recognized the state's failure "to either protect Frank or bring his killers to justice." Georgia's officials had not protected him, and they had never put his killers on trial.

The Temple's own history says that no Jew ran for office for more than twenty years after the lynching. The New Georgia Encyclopedia says that after the case, Jewish southerners were afraid and watched their own behavior closely for the next fifty years. Some of the Knights of Mary Phagan later took part in the ceremony that started a new Ku Klux Klan.

**By 1915:** Pentecostal worship had spread out from Azusa Street, federal officials were still punishing Native dances, and a Georgia mob had lynched Leo Frank.

### A Klan that called itself Protestant

William J. Simmons and sixteen other men climbed Stone Mountain in Georgia on Thanksgiving evening in 1915. They set a cross on fire and announced the rebirth of the Knights of the Ku Klux Klan. Only white, American-born Protestant men could join. Opposing Catholics and Jews was one of its central beliefs, according to the New Georgia Encyclopedia. By 1924 it had an estimated five million members.

**Robes and altars.** Klan members borrowed the forms of Protestant worship. The historian Kelly J. Baker describes their white robes and masks, their "elaborate initiation ceremonies," which means ceremonies with many detailed steps for new members, their burning crosses, and their altars draped with the American flag.

In the middle of revival services, robed Klansmen gave money to the preachers. The traveling preacher Billy Sunday received $50 and a letter from Klansmen in Indiana. In Spokane, Washington, two robed Klansmen gave $50 to the traveling preacher George Wood, the *Idaho Daily Statesman* reported in March 1922. Other Protestants spoke against the Klan. In October 1922 the *Savannah Tribune* reported that the Federal Council of Churches, a group of Protestant churches, had condemned it.

### The year Oregon voted to close the Catholic schools

Oregon's voters passed a law in 1922 that would have closed the state's Catholic schools, along with its other private schools, for children aged eight to sixteen. The law was an initiative, a law that citizens propose and then vote on themselves. It was proposed on June 26, 1922. Klan members put it on the ballot through the Scottish Rite Masons, a men's club.

The voters passed it on November 7, 1922, 115,506 to 103,685. It required children aged eight to sixteen to attend a public school, starting September 1, 1926. There were a few exceptions, such as a child who had finished the eighth grade, a child who lived far from a public school, or a child who was physically unable to attend school.

**Fines and jail for parents.** The penalties in the law were for parents, not for schools. A parent who kept a child out of public school could be fined $5 to $100, or jailed in the county jail for two to thirty days, or both. Each day a child stayed away counted as a separate crime. A child could be taught at home only with written permission from the county superintendent, renewed every year.

The Society of Sisters of the Holy Names of Jesus and Mary had run schools in Oregon since 1880. Their schools taught the Catholic religion along with the ordinary subjects. The Sisters sued. So did Hill Military Academy, a boys' school that was not religious at all. The National Catholic Welfare Conference, a Catholic organization, paid for the case to be carried to the Supreme Court.

**The ruling.** The justices of the Supreme Court struck the law down on June 1, 1925, in *Pierce v. Society of Sisters*, before it could take effect. They held that it "unreasonably interferes with the liberty of parents and guardians to direct the upbringing and education of children under their control."

### Christians arguing with Christians at Dayton, 1925

The 1925 trial at Dayton, Tennessee, was an argument between two groups of Christians about how to read Genesis, the first book of the Bible. Governor Austin Peay of Tennessee signed a law, the Butler Act, on March 21, 1925. It made it a crime to teach "any theory that denies the story of Divine Creation of man as taught in the Bible," and to teach instead that people came "from a lower order of animals."

That was a ban on teaching evolution, the scientific theory that living things, people included, developed over very long ages from earlier forms of life. Tennessee prosecutors put John T. Scopes, a science teacher and football coach at Dayton's high school, on trial under the law. The trial opened on July 10, 1925.

Both sides of the argument were Christians, and both put their beliefs on the record. On one side were Christians often called fundamentalists, who read the Bible word for word. One of them was William Jennings Bryan, one of the lawyers against Scopes. On the other side, two scientists for the defense, both of them Christians, wrote that God works through evolution and that the Bible and evolution do not conflict.

**Bryan on the stand.** The prosecutor William Jennings Bryan took the witness stand himself on July 20, the seventh day of the trial. The defense lawyer Clarence Darrow questioned him about the Bible. Bryan said, "I accept the Bible absolutely." He said Darrow's purpose was "to cast ridicule on everybody who believes in the Bible."

Darrow answered that his purpose was "preventing bigots and ignoramuses from controlling the education of the United States." By bigots he meant people who hate or look down on those who believe differently, and by ignoramuses people who know very little.

Bryan had written a closing speech, but both sides gave up their closing speeches, so he never gave it. It was printed afterward with the trial record. In it he asked, "Can the fathers and mothers of Tennessee be blamed for trying to protect their children from such a tragedy?" The tragedy he meant was a child losing "faith in God, trust in the Bible, and belief in the supernatural character of Christ."

**The scientists' statements.** The defense could not put its expert witnesses in front of the jury, so the defense lawyer Arthur Garfield Hays read their written statements into the record. Kirtley F. Mather led the geology department at Harvard and had graduated from Denison University, a Baptist college. He wrote: "Evolution is not a power, nor a force. It is a process, a method. God is a power, a force."

The zoologist Maynard M. Metcalf, a scientist who studied animals, wrote: "There is no conflict, no least degree of conflict, between the Bible and the fact of evolution." In the same sentence he went on to call the word-for-word reading of the Bible childish and "insulting, both to God and to human intelligence."

**The verdict.** The jury found Scopes guilty, and he was fined $100. In 1927 the judges who heard his appeal threw out the verdict on a technicality, a small point about how the case was handled. Chapter 20, Government, Law, and Politics, describes the case in full.

### Laws against teaching evolution, 1921 to 1929

Lawmakers in twenty states introduced bills against teaching evolution between 1921 and 1929. Tennessee's passed in 1925. Oklahoma's lawmakers passed one and canceled it in 1926. Mississippi's law was still in force in 1968. Lawmakers in Florida and Texas passed resolutions against teaching evolution, which are statements of opinion rather than laws.

In Arkansas the voters passed the law themselves in 1928. It made it a crime "to teach the theory or doctrine that mankind ascended or descended from a lower order of animals," or to use a textbook that taught it. A teacher found guilty could be fined up to $500 and had to leave the job. In the forty years it stood, there is no record that anyone was prosecuted under it. Tennessee's lawmakers canceled the Butler Act in 1967.

**By 1929:** Oregon's voters had passed a Klan-backed law to close the state's Catholic and other private schools, the Supreme Court had struck it down, and lawmakers in twenty states had tried to ban the teaching of evolution.

### Aimee Semple McPherson

> **Who:** A Pentecostal preacher who built the Angelus Temple in Los Angeles and preached from it by radio.
>
> **When and where:** Born 1890 near Ingersoll, Canada. Los Angeles from 1918. Died 1944.

**She rode a motorcycle onto the stage dressed as a policewoman.**

Aimee Semple McPherson built a church in Los Angeles with seats for 5,300 people and preached from it by radio. She grew up in the country near Ingersoll, Canada. Her mother was a member of the Salvation Army, a Christian group, and her father led a Methodist choir. As a child she sang, prayed and recited Bible passages at Salvation Army services. She was the only child in her public school who belonged to the Salvation Army, and the other children taunted her for it.

In high school she was taught evolution and began to doubt her faith. After that she started going to a Pentecostal church. She married Robert Semple, a Pentecostal minister, and went with him to China as a missionary. He died there, and her first child was born a month after his death. Later she married Harold McPherson and lived in Providence, Rhode Island. In 1916 she left him and went preaching across the country.

**The Angelus Temple.** She settled in Los Angeles in 1918. The Angelus Temple on Glendale Boulevard opened in 1923, built and paid for with money from her preaching tours. The National Park Service writes that she "fell squarely into the fundamentalist camp." She called on believers to leave the old churches that she believed had been "tainted with Darwinian modernism," meaning they had accepted evolution. A newspaper in 1926 reported radio towers on top of the Temple carrying her words to listeners.

The National Park Service writes that she brought the entertainment of Hollywood films and vaudeville, stage shows of songs, comedy and acts, into her preaching. Once she dressed as a policewoman and rode a motorcycle onto the stage, and she preached on the subject "Stop! You are breaking God's law!" In 1926 she opened a Bible college. By 1944 more than 3,000 of its graduates, men and women, had become ministers or missionaries.

Each week, members brought an item to stock the Temple's shelves, and the staff gave the goods to anyone in need. During the Great Depression the Temple's workers gave out more than 1,500,000 meals.

In Florida she held special meetings for Black people because, in her words, "the dear colored people did not feel free to attend the white meetings." ("Colored" was a common word for Black people at the time, and it is no longer used.) In Oakland, California, she preached to the Ku Klux Klan.

**Five weeks missing.** She went into the ocean at Ocean Park, on the Santa Monica coast, on May 18, 1926, and did not come back. Police, lifeguards, lifeboats, motorboats and an airplane searched for her. Two days later her friends had given up hope that she was alive.

She walked out of the desert near Douglas, Arizona, on June 23 and was taken to a hospital. She said that two men and a woman had kidnapped her at the beach and held her in Mexico for half a million dollars in ransom. Armed search parties, including Mexican soldiers, searched the flats of Sonora for the shack she described.

California prosecutors brought a case against her afterward. On January 10, 1927, a judge dismissed the case at the request of District Attorney Asa Keyes, the county's chief prosecutor, who pointed to "the constantly conflicting stories" of a witness. No court ever decided what happened in those five weeks. She died in 1944.

### Jehovah's Witnesses and the flag, 1940 to 1943

Jehovah's Witnesses, a Christian group, would not salute the American flag, and in 1940 people in towns across the country attacked them for it. They believed that saluting a flag was the same as bowing down to a graven image, an idol, which the Bible forbids.

The justices of the Supreme Court ruled 8 to 1 in 1940, in *Minersville School District v. Gobitis*, that school officials in Minersville, Pennsylvania, could expel two Witness children, Lillian and William Gobitas, for refusing to salute. A court clerk misspelled the family's name as Gobitis.

**The attacks.** After the ruling the attacks grew. The First Amendment Encyclopedia at Middle Tennessee State University lists beatings, the destruction of Kingdom Halls (the Witnesses' places of worship) and at least one castration. Castration means cutting off a man's testicles, the glands that make sperm. A man who loses both can never father a child. The encyclopedia does not name the man or say where or how it was done.

The encyclopedia states that the American Legion, a club of military veterans, was linked to more than 100 attacks by vigilantes, people who punish others with no legal right to do so.

**Richwood, West Virginia.** One attack was recorded in detail, at Richwood, West Virginia, on June 29, 1940. Deputy Sheriff Martin Catlette and Police Chief Bert Stewart held seven Witnesses whose loyalty local Legion members had questioned. According to West Virginia Public Broadcasting, members of the American Legion forced four of the seven to drink doses of castor oil.

Castor oil is a laxative, a medicine that makes the muscles of the bowels push out their contents. It can cause diarrhea, which is watery emptying of the bowels, along with stomach pain, sickness to the stomach and vomiting. The accounts do not give the size of the doses. Then the Legion members marched all seven through a jeering crowd to the post office, where the Witnesses refused to salute the flag.

Catlette and Stewart were found guilty in federal court at Charleston in 1942 of violating the Witnesses' civil rights, the rights the Constitution promises every citizen. Appeals judges upheld Catlette's conviction. West Virginia Public Broadcasting calls it the only federal conviction for any of the hundreds of attacks on Witnesses in 1940.

**Reversed in 1943.** Three Witness families in Kanawha County, West Virginia, whose children had been expelled from school, took their case to the Supreme Court. In 1943, in *West Virginia State Board of Education v. Barnette*, the justices reversed their ruling of 1940 by a vote of 6 to 3.

Justice Robert Jackson wrote that "no official, high or petty, can prescribe what shall be orthodox in politics, nationalism, religion, or other matters of opinion." That means no official can order which beliefs are the correct ones. He called that rule the "fixed star in our constitutional constellation."

**If you remember one thing:** People who were attacked or punished for their faith began to win their cases in the Supreme Court.

- 1906: speaking in tongues begins at a house on Bonnie Brae Street in Los Angeles.
- 1925: the justices strike down Oregon's law to close its Catholic and other private schools.
- 1943: the justices rule that schools cannot force Witness children to salute the flag.

**Next:** After 1950 Black churches held the meetings of the civil rights movement, and men bombed them for it.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 30 minutes**

Families took their fights over religion in the public schools to court between 1950 and 2000, and the justices of the Supreme Court drew the lines. Church membership held steady. About seven American adults in ten told the Gallup polling company that they belonged to a church, a synagogue or a mosque, the Jewish and Muslim houses of worship. Members of Congress added "under God" to the Pledge of Allegiance in 1954 and made "In God we trust" the national motto in 1956.

**Churches and courts.** In the South, Black churches held the meetings of the civil rights movement, and men bombed their buildings and killed their members. Families of several faiths, and some with none, brought the cases over prayer, Bible reading and the teaching of evolution. The justices of the Supreme Court ended official prayer and Bible reading in public schools. They also ruled for Amish fathers who kept their children out of high school for religious reasons.

**Native religion allowed.** Members of Congress declared in 1978 that Native Americans had a right to practice their own religions. Federal officials had been able to punish Native ceremonies under the 1883 rules for ninety-five years before that.

**Deaths in two religious communities.** Jim Jones, the leader of Peoples Temple, ordered the members at Jonestown, in Guyana, to take poison in 1978. Parents and nurses squirted it into the mouths of more than 200 children, and the adults drank it while armed guards surrounded them. In all, 909 people died there.

More than 70 Branch Davidians, 22 of them children, died in a fire near Waco, Texas, in 1993. A Special Counsel later found that some of the Davidians had set the fire, and that some had shot their own people.

### God in the country's official words, 1954 and 1956

Members of Congress changed the Pledge of Allegiance, the promise of loyalty to the flag, by law on June 14, 1954. They added the words "under God." The pledge now reads: "I pledge allegiance to the flag of the United States of America and to the Republic for which it stands, one Nation under God, indivisible, with liberty and justice for all."

They passed a joint resolution, a kind of resolution that becomes a law, on July 30, 1956. It is one sentence long: "That the national motto of the United States is hereby declared to be 'In God we trust.'" A motto is a short saying chosen to stand for a group or a country.

Gallup is a private polling company, and its pollsters record what people say about themselves. Since 1937 they have asked Americans whether they belong to a church, synagogue or mosque. In 1937, 73 percent said they did. The figure stayed near 70 percent through the 1990s and was 70 percent in 1999.

### A church that was bombed three times

Bethel Baptist Church in Birmingham, Alabama, served as the headquarters of a civil rights movement from 1956 to 1961, and it was bombed three times. The church stood in Collegeville, a Black working-class neighborhood six miles north of the center of the city. Fred L. Shuttlesworth had been its pastor since March 1953.

**A movement in the churches.** An Alabama judge banned the NAACP, a national civil rights organization, from working anywhere in the state on June 1, 1956. Four days later, on June 5, about a thousand people met at Sardis Baptist Church and started the Alabama Christian Movement for Human Rights. Shuttlesworth said that officials could outlaw an organization but not a movement.

He said the word "Christian" set the group apart from groups being called Communist, Communists being people who wanted the government to own the land and the businesses. He also said the word gave the group "a foundation and Christian orientation." Members met every Monday night in churches around the city. The National Park Service describes the meetings as "emotional testimony, soul-lifting music, impassioned preaching, and fundraising." By 1958 weekly meetings were being held in 55 other working-class churches in Birmingham.

**Christmas night, 1956.** Someone set off twelve sticks of dynamite on Christmas night, December 25, 1956, in the space between the church and the parsonage, the pastor's house. The blast destroyed the parsonage. Shuttlesworth was inside talking with a deacon, a member who helps run the church, and his family was watching television. He had a minor head injury.

The bomb went off the night before the movement's members had said they would ride Birmingham's segregated buses, where Black riders had to sit apart from white riders. The next day 250 people rode the buses, and police arrested 22 of them.

A second bomb came on June 29, 1958, and a third in 1962, which broke the church's windows. The 1958 bombing was not solved until 1980, when J. B. Stoner was convicted of it. No one is recorded as convicted of the 1956 bomb or the 1962 bomb.

**Other churches.** Other Black churches were bombed and burned in these years. On September 15, 1963, a bomb at the 16th Street Baptist Church in Birmingham killed four girls: Addie Mae Collins, 14, Denise McNair, 11, Carole Robertson, 14, and Cynthia Wesley, 14. Robert Chambliss was convicted of the bombing in 1977, Thomas Blanton in 2001 and Bobby Frank Cherry in 2002.

Jason Wollschleger, a sociologist at Whitworth University who studies how groups of people live together, and his research team have mapped about 145 attacks on Black churches across the South from about 1954 to 1970. It is one team's count, not an official one.

In Albany, Georgia, in 1961 and 1962, four Black churches connected with the Student Nonviolent Coordinating Committee, a civil rights group of young people, were burned to the ground. Among them were Shady Grove Baptist and High Hope Baptist. Wollschleger's account does not name who set the fires.

### The Revis family of Bethel Baptist Church

> **Who:** A church deacon and his two daughters, whose front porch became the guard post for a church that kept being bombed.
>
> **When and where:** Collegeville, Birmingham, Alabama, 1956 to the early 1960s.

**Laverne Revis saw a bomb smoking beside the church.**

The Revis family turned their own front porch into a guardhouse so that armed volunteers could watch Bethel Baptist Church day and night. James Revis was a deacon of the church and sat on the executive committee of the Alabama Christian Movement for Human Rights. His house stood across the street from the church.

**The porch.** After the bomb of Christmas night 1956 destroyed the pastor's house, members of the church and the movement volunteered to guard the church and the new parsonage. In 1957 the Revis family closed in their porch to make a room for the guards.

His daughter Robbie Revis Smith described it years later: "with our house sitting on the corner, it gave a very good view several ways that they could see because they had the glass out there and they put a little gas heater out there so they wouldn't be too cold sitting up. They did this year round."

Her sister Laverne Revis Martin said their parents made the room "just so the guards would be able to watch."

**The guards.** The volunteers were called the Civil Rights Guards. They worked in two shifts, from six in the evening to midnight and from midnight to six in the morning. They carried rifles, which they called their "nonviolent Winchesters." Women of the movement took a weekly shift, among them Desta Brooks, a florist, and Minnie Eaton, a schoolteacher.

**The night of the bomb.** At about half past one in the morning on Sunday, June 29, 1958, Laverne was coming home from work when she saw a bomb smoking beside the church. She told the guards. They carried it into the street, where it went off. It blew a hole in the road and broke church windows, and the building stood. Afterward Birmingham police came to the Revis house and took four rifles from the guards on the porch.

Robbie Revis Smith said of coming home in those years: "So it was kind of a good feeling coming home because you never came home without a person out there watching you, so you didn't have to worry about that."

### Billy Graham

> **Who:** A Southern Baptist preacher who held large public revival meetings, which he called crusades, from 1949 to 2005.
>
> **When and where:** Born in Charlotte, North Carolina, November 7, 1918. Died at Montreat, North Carolina, February 21, 2018.

**Martin Luther King Jr. gave the opening prayer at his 1957 crusade.**

Billy Graham held revival meetings from 1949 to 2005, and in 1957 Martin Luther King Jr. gave the opening prayer at one of them. Graham grew up on a dairy farm near Charlotte, North Carolina. In 1934, after hearing a traveling preacher in Charlotte, he decided to give his life to God. In 1943 he married Ruth Bell.

**Crusades.** From 1944 to 1948 he traveled the country speaking at rallies for a group called Youth for Christ. In 1949 he held a campaign in Los Angeles that was planned for three weeks and ran for seven. He then started the Billy Graham Evangelistic Association and a weekly radio program, *Hour of Decision*. He preached for twelve weeks in London in 1954, and every night for sixteen weeks at Madison Square Garden in New York in 1957.

**King's prayer.** On July 18, 1957, at the New York crusade, Martin Luther King Jr. gave the opening prayer. Graham and King had spoken by telephone, and on July 5 the evangelist Leighton Ford, a traveling preacher, had sent King a telegram asking him to come. King asked for help "for a warless world and for a brotherhood that transcends race or color." Then he led the crowd in the Lord's Prayer.

King wrote to Graham on August 31, 1957: "You have courageously brought the Christian gospel to bear on the question of race." He wrote again on July 23, 1958, this time to object. Graham had shared a platform with Governor Price Daniel of Texas, and King called that an "endorsement of racial segregation and discrimination." At Easter in 1964, Graham held crusades in Birmingham, Alabama, that Black and white people attended together.

**Honors.** Members of Congress voted Billy and Ruth Graham a gold medal in 1996, and it was presented to them in the Capitol Rotunda on May 2. In the law, members of Congress wrote that his crusades had reached 100 million people in person and more than 2 billion on television. He stepped down from his association in 2000 and held a last crusade in Queens, New York, in 2005.

He died on February 21, 2018, aged 99. On February 28 his body lay in honor in the Rotunda, the round hall under the dome of the Capitol, where people could come to pay their respects. According to the House of Representatives, he was the fourth private citizen to be given that honor.

### Dynamite at an Atlanta synagogue, 1958

Fifty sticks of dynamite exploded in the entrance of the Hebrew Benevolent Congregation in Atlanta, called The Temple, in the early hours of October 12, 1958. It was the congregation Leo Frank had belonged to. No one was hurt. Its rabbi, the congregation's religious leader, was Jacob Rothschild. He had preached against segregation in his sermons since 1947.

Within days police arrested five men, all members of anti-Semitic groups, groups that spread hatred of Jews. Only one of them, George Bright, was tried. His first trial ended in a mistrial, a trial stopped without a verdict, because the jury split 9 to 3. At his second trial the jury found him not guilty. The charges against the other four men were dropped. No one was ever convicted of the bombing.

**By 1958:** Bombs had gone off at Bethel Baptist in Birmingham twice and at The Temple in Atlanta once, and no one had yet been convicted of any of them.

### Prayer and the Bible in public schools, 1962 and 1963

The justices of the Supreme Court ended official prayer and Bible reading in public schools in 1962 and 1963. The families who brought the cases came from several faiths, and some had none.

**Two rulings.** On June 25, 1962, in *Engel v. Vitale*, the justices ruled that New York's public schools could not have pupils say a prayer written by the New York State Board of Regents, the state officials in charge of its schools. On June 17, 1963, in *School District of Abington Township v. Schempp*, they ruled that public schools could not open the day with Bible reading as a religious exercise.

The parents of ten pupils brought the New York case. They said the official prayer went against their own beliefs and their children's. Judges in a New York court had already found that the prayer did not fit the teachings of Jewish, Unitarian or Ethical Culture groups.

Unitarians belong to a church that does not teach the Trinity, the belief that God is three persons in one, and the Ethical Culture society is a group that meets to teach right conduct. One parent was an agnostic, a person who holds that no one can know whether God exists.

**The Schempps.** The Schempps, who brought the 1963 case, went to church. Edward and Sidney Schempp and their children Roger and Donna were members of the Unitarian church in Germantown, Philadelphia, and so was their son Ellory, who had started the case. Under Pennsylvania law, public schools had to read ten verses from the Bible each morning. A child could be excused if a parent asked, and Edward Schempp decided not to ask.

He testified that teachers and classmates would label his children "odd balls" every school day. He said classmates would lump every religious difference together as "atheism," the belief that there is no God, and in 1962 atheism was tied to communism and called un-American. He also said that an excused child had to stand in the hall outside the homeroom, which looked like a punishment for bad behavior.

**Two scholars.** Two scholars testified about the Bible itself. Solomon Grayzel, for the families, said the Jewish scriptures have no New Testament. He said that from the standpoint of Jewish faith, calling Jesus the Son of God is "practically blasphemous," which means close to an insult against God. Read to children without explanation, he said, parts of the New Testament had been "psychologically harmful to the child."

Luther A. Weigle, for the school district, said the Bible was "non-sectarian," meaning it belonged to no single religious group. He later said he meant non-sectarian among Christian churches.

A second case was decided with the Schempps'. In Baltimore, schools opened each day with a chapter from the Bible or the Lord's Prayer. Madalyn Murray and her son William J. Murray III were atheists. They argued that the rule threatened their religious liberty "by placing a premium on belief as against non-belief," which means it rewarded believers over people who do not believe.

### The day after, and the years after

**Calls to undo it.** The day after the 1962 ruling, a member of Congress introduced an amendment, a change to the Constitution, to undo it, and others were drafting more. The *Evening Star* newspaper of Washington, D.C., reported on June 26, 1962, that Representative Taylor of North Carolina was first. The paper noted that Billy Graham was one of his constituents, the people he represented.

Senator Beall of Maryland had one ready for the Senate. Representative Chelf of Kentucky said that if he could not get a law passed, he would try to limit Supreme Court justices to a set number of years instead of life.

In Washington, D.C., the school board's rules required a Bible reading and the Lord's Prayer to open the school day. Superintendent Carl F. Hansen said that "on the surface it appears that it does invalidate the board's rule," meaning that the ruling seemed to cancel it. None of the proposed amendments became part of the Constitution.

**Earlier limits.** The justices had set some limits before 1962. In 1948, in a case brought by a mother named Vashti McCollum, the justices ruled against a program in Champaign, Illinois. There, Catholic, Protestant and Jewish teachers came into the public school buildings once a week to teach religion for thirty to forty-five minutes. Children whose parents asked had to attend.

The justices allowed a program in New York City in 1952 in which children left the school buildings to go to a church or synagogue for the lesson. So the justices ruled out religion lessons inside the school building, and they allowed lessons that children left the building to attend.

Justice Clark also wrote, in the 1963 ruling, that teaching *about* religion was allowed. He wrote that "it might well be said that one's education is not complete without a study of comparative religion or the history of religion and its relationship to the advancement of civilization." He wrote that the Bible "is worthy of study for its literary and historic qualities."

**A moment of silence.** After 1963 Alabama's lawmakers tried a moment of silence. They passed a law in 1978 for one minute of silence "for meditation." In 1981 they changed it to "for meditation or voluntary prayer," and in 1982 they let teachers lead "willing students" in a prayer to "Almighty God." In 1985, in *Wallace v. Jaffree*, the justices struck down the 1981 law because its purpose was to support religion. They left the 1978 law for plain silence in place.

The justices struck down a Kentucky law in 1980, in *Stone v. Graham*, that required the Ten Commandments to be posted in every public classroom.

**A graduation prayer.** The justices ruled in 1992 that a principal could not invite a member of the clergy, such as a minister or a rabbi, to pray at a school graduation. Principal Robert E. Lee of Nathan Bishop Middle School in Providence, Rhode Island, had invited Rabbi Leslie Gutterman of Temple Beth El to pray at Deborah Weisman's graduation. The principal gave the rabbi a pamphlet of guidelines and told him to keep the prayers non-sectarian. The rabbi began, "God of the Free, Hope of the Brave."

Deborah's father, Daniel Weisman, sued. In *Lee v. Weisman*, the justices held that by handing over the pamphlet and the instruction, the principal "directed and controlled the content of the prayers."

### Evolution in court again, 1968 and 1987

Two state laws about teaching evolution reached the Supreme Court, in 1968 and 1987. The justices struck down both, and both times they named the religious belief behind the law.

**Susan Epperson.** Susan Epperson had gone to school in Arkansas and earned a master's degree in zoology. Little Rock school officials hired her in the autumn of 1964 to teach tenth-grade biology at Central High School. For the 1965 to 1966 school year, school officials adopted a new biology textbook with a chapter on evolution. Teaching that chapter was a crime under the Arkansas law of 1928. She sued, and H. H. Blanchard, a parent of children in the public schools, joined her case.

The justices struck the law down on November 12, 1968, in *Epperson v. Arkansas*. They wrote that "fundamentalist sectarian conviction was and is the law's reason for existence," meaning that the law existed because of one group's religious belief. They also wrote that the First Amendment requires the government to be neutral "between religion and religion, and between religion and nonreligion."

No justice voted to keep the law. They did not all agree on the reasons, and Justice Black wrote separately that he doubted the Court's reading of why Arkansas had passed it.

**Creation science.** Louisiana's lawmakers passed a different kind of law. It stated that a public school that taught evolution also had to teach "creation science," and a school that taught creation science also had to teach evolution. Creation science was the teaching that a supernatural being created humankind. The people who sued to stop the law included Louisiana parents, Louisiana teachers and religious leaders.

Religious groups stood on both sides. Groups may send the Court a friend-of-the-court brief, a written argument from people who are not in the case. Three groups, among them the Catholic League for Religious and Civil Rights and the Christian Legal Society, sent briefs asking the justices to keep the law. The New York Committee for Public Education and Religious Liberty sent one asking them to strike it down.

The justices struck the law down by 7 votes to 2 on June 19, 1987, in *Edwards v. Aguillard*. They held that "the preeminent purpose of the Louisiana Legislature was clearly to advance the religious viewpoint that a supernatural being created humankind." The justices meant that Louisiana's lawmakers passed the law mainly to promote one religious belief.

**By 1987:** The justices had ended official prayer and Bible reading in public schools and struck down two state laws about teaching evolution, each time naming the religious belief behind it.

### Jonas and Frieda Yoder

> **Who:** An Old Order Amish father who would not send his daughter to high school, and the daughter, who told the court that the decision was her own religion too.
>
> **When and where:** Green County, Wisconsin, 1968 to 1972.

**Frieda Yoder, fifteen, was the only child who testified.**

Frieda Yoder was the only child who testified in her family's case, which went to the Supreme Court and asked whether Amish parents could keep their children out of high school. Her father, Jonas Yoder, belonged to the Old Order Amish, a Christian church whose members keep apart from the outside world. They lived in Green County, Wisconsin.

Wisconsin law required children to stay in school until they turned sixteen. Frieda was fifteen and had finished the eighth grade at the public school. Her father did not send her on to high school.

**One line from the Bible.** His reason was one line from the Bible. In his letter to the Romans, Paul, an early leader of the Christian church, wrote, "be not conformed to this world." The Amish take that line as a rule for daily life. They did not object to the first eight grades, because a child needs to read the Bible, farm and deal with people outside the community. They saw the high school as the world they were told not to join.

**The case.** Jonas Yoder was charged, tried and convicted in the Green County Court along with two other fathers, Wallace Miller and Adin Yutzy. Miller was also Old Order Amish, and Yutzy belonged to the Conservative Amish Mennonite Church. On May 15, 1972, in *Wisconsin v. Yoder*, the justices of the Supreme Court decided for the three fathers.

Frieda testified that her own religious beliefs were the reason she had stopped going to school after the eighth grade. Neither side called the other children. Justice Douglas agreed with the ruling for her father. He disagreed with it for the other two fathers, because no one had asked their children, Barbara Miller and Vernon Yutzy, what they believed. He said the Court had never answered whose religion counts when a family's religion decides a child's schooling, the parents' or the child's.

### Ministers on both sides of a textbook fight, 1974

Ministers spoke up on both sides of a fight over schoolbooks in Kanawha County, West Virginia, in 1974. During the protests people fired guns, and attackers firebombed and dynamited schools. The county had 46,000 pupils in 124 public schools. In April 1974 the five members of the county school board voted to adopt 325 language-arts textbooks and other books.

The next month a board member, Alice Moore, objected to what some of the books said and taught. She was the wife of a minister, and she had been elected in 1970 after campaigning against sex education. She and several ministers campaigned against the books. Twenty-seven ministers condemned them as immoral and indecent, and petitions carried 12,000 signatures. Another minister, Jim Lewis of Charleston, spoke out most strongly for the books. In June the board voted 3 to 2 to accept most of them.

**The boycott.** When school opened on September 3, 1974, a fifth of the pupils stayed home in a boycott, a refusal to take part. Picket lines, groups of protesters standing outside with signs, spread from the schools to businesses and coal mines, and 3,500 miners walked off the job in support.

The West Virginia Encyclopedia lists gunfire, firebombs and dynamite attacks on schools, and it does not name who carried them out. Police made 11 arrests. The schools were closed for four days starting September 12. The records of the protest give no count of the injured.

The protests went on into 1977, and outside groups joined them, among them the Ku Klux Klan and the John Birch Society, a political group. The Reverend Marvin Horan was tried for plotting to bomb schools, and the violence ended with his trial. Board members set up committees that gave parents a part in choosing textbooks.

### The law that said Native religion was allowed, 1978 to 1997

Members of Congress passed the American Indian Religious Freedom Act on August 11, 1978. In it they declared that it was the policy of the United States to protect the right of Native people "to believe, express, and exercise the traditional religions of the American Indian, Eskimo, Aleut, and Native Hawaiians." That included the right to visit sacred sites, to have sacred objects, and to worship "through ceremonials and traditional rites."

The act came ninety-five years after the 1883 rules that made the Sun Dance, a sacred ceremony of the Plains nations, a crime.

**What Congress admitted.** The members of Congress wrote down what had been happening. Federal laws and policies "often deny American Indians access to sacred sites required in their religions, including cemeteries." They wrote that "traditional American Indian ceremonies have been intruded upon, interfered with, and in a few instances banned." Federal officials had done this, as Price's rules of 1883, Jones's order of 1902 and Burke's circular of 1921 show.

For example, a Native person had needed a federal permit since 1962 to hold an eagle feather for worship. Without one, the penalty was up to $500 or six months in prison.

**Chimney Rock.** The 1978 Act stated a policy. In 1988 the justices of the Supreme Court ruled that it created no right a court could enforce, in the case *Lyng v. Northwest Indian Cemetery Protective Association*.

Officials of the U.S. Forest Service planned to build a six-mile paved road through the Chimney Rock area of Six Rivers National Forest in California, and to allow logging there. The Yurok, Karuk and Tolowa had long used this high country for worship. Justice Brennan, who disagreed with the ruling, wrote that they had held it sacred "for at least 200 years and probably much longer." It is land of the Yurok, Karuk and Tolowa that the Forest Service holds as federal land.

The authors of a study that the Forest Service itself paid for found that the road "would cause serious and irreparable damage to the sacred areas" and advised against building it. In 1982 Forest Service officials chose a route through Chimney Rock anyway.

The justices ruled 5 to 3 that the Constitution did not stop the road. Justice O'Connor wrote that even if the road would "virtually destroy the Indians' ability to practice their religion, the Constitution simply does not provide a principle" for stopping it. The justices' opinion also records that the Native people of the area did not all oppose the road.

**Peyote.** Alfred Smith and Galen Black were members of the Native American Church. Their employer, a private drug treatment program, fired them because they ate peyote at a church ceremony. Peyote is a small cactus that causes hallucinations, which means it makes a person see or feel things that are not there. Members of the church take it as a sacrament, a sacred act of worship.

Oregon officials refused to pay the men unemployment money. The justices ruled 6 to 3 in 1990, in *Employment Division v. Smith*, that Oregon could ban peyote even for worship and deny the payments. Justice Scalia wrote that leaving such questions to lawmakers "will place at a relative disadvantage those religious practices that are not widely engaged in."

**Congress answers.** Members of Congress answered twice. In 1993 they passed the Religious Freedom Restoration Act. It stated that government officials could not put a heavy burden on a person's religion unless they had a reason of the highest importance, and that they had to choose the way that restricted religion least.

Members of Congress also amended the 1978 Act on October 6, 1994. They wrote that 28 states protected the peyote ceremony and 22 did not, and they made it lawful everywhere in the country for a Native person to use peyote in traditional religious ceremonies. In 1997, in a case brought by Archbishop Patrick Flores of San Antonio, the justices ruled that the 1993 act went beyond Congress's power over the states. That ruling did not touch the 1994 peyote law.

### Jonestown, 1978

Jim Jones, the leader of an American congregation called Peoples Temple, ordered its members at its settlement in Guyana, in South America, to take poison on November 18, 1978. More than 900 people died. Jones had founded Peoples Temple in Indianapolis in the 1950s and moved it to San Francisco in 1971. Members then moved to a settlement they called Jonestown.

That day Temple members shot and killed Congressman Leo Ryan of California and four other people at the Port Kaituma airstrip, among them an NBC cameraman and a newspaper photographer.

**How the children died.** At Jonestown, at Jones's order, parents and nurses used syringes to squirt a mix of cyanide, sedatives and powdered fruit drink into the children's mouths. Cyanide is a poison that stops the cells of the body from using oxygen, so the cells cannot make the energy they need to live. Sedatives are drugs that make a person calm and sleepy.

More than 200 children were killed this way, according to the Association for Diplomatic Studies and Training, an organization of former American diplomats. The children could not choose, and the association calls them murdered. Then the adults drank the mix while armed guards surrounded the pavilion, the large roofed meeting place where they had gathered. In all, 909 members died at Jonestown, all but two of them from what appeared to be cyanide poisoning. One or two people there, among them Jim Jones, had bullet wounds instead.

### Houses of worship attacked, 1991 to 2000

Gunmen shot nine people dead at Wat Promkunaram, a Thai Buddhist temple near Phoenix, Arizona, on August 10, 1991, during a robbery of the monks. Johnathan Doody and Alessandro Garcia were later convicted of the killings. The dead were six monks, a nun, a novice, who is a person training to become a monk, and a boy who helped at the temple. Each was shot in the head.

Doody was 17 at the time. His first conviction was thrown out because federal appeals judges found that his confession had been coerced, which means forced out of him. At his third trial he was convicted of nine counts of first-degree murder, a killing planned ahead of time, one for each person killed. He was sentenced to 249 years in prison on March 14, 2014. Alessandro Garcia pleaded guilty and was sentenced to life, NBC News reported.

**Church fires.** People set fire to churches across the country in the middle of the 1990s. Members of Congress passed the Church Arson Prevention Act on July 3, 1996, arson being the crime of setting a fire on purpose. They wrote that fires set at places of worship had increased, "especially in the context of places of religious worship that serve predominantly African-American congregations," which means mostly Black congregations.

Agents of a federal task force from the Justice and Treasury departments counted 297 arsons, bombings or attempted bombings at houses of worship in 1996. The count fell every year after that, to 140 in 1999. Between January 1995 and August 2000 the agents arrested 431 suspects, and courts found 305 people guilty.

Jay Scott Ballinger pleaded guilty on July 11, 2000, to setting fire to 26 churches in eight states between 1994 and 1999.

### Mount Carmel, near Waco, 1993

A standoff between federal agents and a religious community near Waco, Texas, ended in 1993 when some of the Davidians set fire to their own building. More than 70 people died in it, 22 of them children, according to a report by members of Congress. A Special Counsel, an outside lawyer appointed to investigate, later found that some of the Davidians had spread fuel through their building and set it on fire.

The Branch Davidians lived at a property called Mount Carmel, outside Waco, and their leader was Vernon Howell, who called himself David Koresh.

**The raid.** Agents of the federal Bureau of Alcohol, Tobacco and Firearms, the ATF, stormed the building on February 28, 1993. There were 76 of them, and they had warrants, papers from a judge that allowed them to arrest people and search the building. The Davidians had learned of the raid in advance. The gun battle lasted almost 90 minutes.

The Special Counsel found that Davidians shot and killed four ATF agents, Conway C. LeBleu, Todd W. McKeehan, Robert J. Williams and Steven D. Willis, and wounded 20 others. Six Davidians were killed that day, by the Special Counsel's count. The House report says that ATF agents killed at least two of them.

**Disputed:** who fired first. In their 1996 report, members of two House subcommittees, small groups of members of the House of Representatives, found that the question could not be settled for certain, but that "It appears more likely, however, that the Davidians fired first." ATF agents testified that the Davidians did. The Davidians' lawyers said they believed an ATF gun went off by accident.

**Fifty-one days.** Agents of the FBI then took over and talked with the Davidians for 51 days. By March 23, 35 people had come out. The House majority report records 21 of them as children, and the minority report records 14. After March 23 no one else left.

A six-year-old girl, Melissa Morrison, told an FBI negotiator that she could not leave because "David won't let me." She died in the fire.

**April 19.** FBI agents in armored vehicles began punching holes in the walls and spraying tear gas inside at about 6 in the morning on April 19, 1993, and Davidians fired on the vehicles. At about 12:07 in the afternoon a fire broke out in the building. Two more began within two minutes, and within eight minutes the whole building was burning.

**What the Special Counsel found.** Former Senator John C. Danforth was the Special Counsel. The Attorney General, the head of the Justice Department, appointed him, and he studied the case for ten months. In 2000 he reported that government agents did not start or spread the fire and did not shoot at the Davidians.

He found that some of the Davidians spread fuel through the building and set it on fire in at least three places. Danforth placed the responsibility for the deaths on "certain of the Branch Davidians and their leader, David Koresh." He counted at least 80 dead in all, including the six Davidians killed on February 28.

Danforth found that some Davidians shot and killed their own people, among them at least five children. At least twenty Davidians were shot dead on April 19, many of them in the head or mouth at close range. A three-year-old, Dayland Gent, was stabbed in the chest and died. Danforth's report does not name who stabbed him.

Danforth also reported that an FBI agent had fired three tear-gas rounds of a kind that can start fires at 8:08 that morning, toward a pit about 75 feet from the living quarters. Government officials did not reveal this until August 1999. Danforth found that those rounds did not start the fire four hours later. A Texas jury later found eight Davidians guilty of gun crimes.

**If you remember one thing:** Families of many faiths, and some of none, won Supreme Court cases that ended official prayer and Bible reading in public schools.

**One number:** about 145, the attacks on Black churches across the South from about 1954 to 1970 that one research team has mapped.

**Next:** After 2000 a smaller share of Americans belonged to a congregation, and gunmen killed worshippers in a Sikh gurdwara, in churches and in a synagogue.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 28 minutes**

Fewer Americans have belonged to a congregation since 2000. In a survey taken in 2023 and 2024, 29 percent of American adults said they had no religion, up from 16 percent in 2007. People attacked worshippers inside gurdwaras, the houses of worship of the Sikh religion, and inside churches and synagogues, and killed them where they prayed.

**Abuse and courts.** Records made public in these years showed that more than 10,000 people had told Catholic officials that priests sexually abused them as children. A grand jury in Pennsylvania, a group of citizens who hear evidence gathered by prosecutors, found that church leaders in six dioceses, the regions led by bishops, had hidden the abuse there.

A report on the Southern Baptist Convention found that its leaders had pushed back against people who reported abuse, and sometimes met them with outright hostility. Families and teachers kept going to court over what a public school may teach about religion and whether public money may pay for religious schools.

### How many people say they have no religion

Twenty-nine percent of American adults, more than one in four, said they had no religion when researchers at the Pew Research Center, a private polling organization, asked 36,908 of them in 2023 and 2024. In Pew's study of 2007 the share was 16 percent. This group, often called the "nones," includes atheists, agnostics and people who answer "nothing in particular."

Sixty-two percent said they were Christian, down from 78 percent in 2007. Fewer than two adults in a hundred said they were Jewish, and about one in a hundred each said they were Muslim, Buddhist or Hindu. Pew's own report states that the fall in the Christian share had slowed and may have stopped, because it had stayed about the same for four or five years.

**Gallup's question.** Gallup's pollsters ask a different question: whether people belong to a church, synagogue or mosque. In 2020, for the first time since Gallup began asking in 1937, fewer than half said yes. The share was 47 percent, down from 70 percent in 1999.

Older Americans belonged far more often than younger ones. In the years 2018 to 2020, about two in three Americans born before 1946 belonged to a congregation, against a little more than one in three of those born between 1981 and 1996.

### Killed where they were worshipping, 2001 to 2025

FBI officials count the crimes that police report as motivated by hatred of a group. Their report for 2001, the year of the September 11 attacks, records 481 incidents aimed at Muslims, with 554 victims. That was more than 1,600 percent higher than in 2000, or about seventeen times as many. Crimes aimed at Jews were still the largest group, at more than half of all religious hate crimes that year.

**Oak Creek, 2012.** A white supremacist, a person who believes white people are better than others and should rule over them, walked into the gurdwara at Oak Creek, Wisconsin, on Sunday morning, August 5, 2012. He carried a loaded gun, and he killed six people. Paramjit Kaur was sitting for morning prayers when he shot her. The others killed were Sita Singh, Ranjit Singh, Prakash Singh, Suvegh Singh Khattra and Satwant Singh Kaleka, the gurdwara's president, who was killed fighting the gunman.

Santokh Singh and Punjab Singh were shot and lived through the attack, but Punjab Singh later died of his wounds. In 2022 Senator Tammy Baldwin of Wisconsin introduced a resolution in the United States Senate that counts him as the seventh person killed. The resolution also names Lieutenant Brian Murphy, a police officer who was shot 15 times at close range.

### Harpreet Singh Saini

> **Who:** A young man whose mother was shot dead at morning prayers, and who asked the United States Senate to start counting crimes against Sikhs.
>
> **When and where:** Oak Creek, Wisconsin, and Washington, D.C., August and September 2012.

**He asked for his mother "the dignity of being a statistic."**

Harpreet Singh Saini asked the United States Senate to count crimes against Sikhs, forty-five days after a gunman killed his mother at prayer. His parents brought him and his brother, Kamaljit, from India to the United States in 2004, when he was ten. "Like many other immigrants," he said, "they wanted us to have a better life, a better education."

His mother was Paramjit Kaur, the woman shot at morning prayers in the Oak Creek gurdwara. The five men killed with her all wore turbans, as Harpreet does.

**The last rotis.** Two days after the shooting, Harpreet and his brother ate the last rotis, a kind of flatbread, that their mother had made from scratch the night before she died. He said that with the last bite he understood it was the last food made by her hands that they would ever eat. He had just started college, and she was not there to send him off.

**Before the Senate.** On September 19, 2012, he testified before a subcommittee of the United States Senate. He said: "I want to tell the gunman who took her from me: You may have been full of hate, but my mother was full of love."

He told the senators what his mother's faith taught her. "My mother was a devout Sikh. Like all Sikhs, she was bound to live in Chardi Kala," which he described as "a state of high spirits and optimism." He said, "She was also taught as a Sikh to neither have fear of anyone nor strike fear in anyone."

Then he asked for one thing. "I came here today to ask the government to give my mother the dignity of being a statistic. The FBI does not track hate crimes against Sikhs. My mother and those shot that day will not even count on a federal form. We cannot solve a problem we refuse to recognize."

The FBI's report for 2015 was the first to list crimes against Sikhs. It counted 6 offenses against Sikhs that year.

### Charleston, Sutherland Springs and Pittsburgh, 2015 to 2018

**Charleston, 2015.** A 21-year-old man named Dylann Roof killed nine members of Mother Emanuel church in Charleston, South Carolina, at their weekly Bible study on Wednesday evening, June 17, 2015. Mother Emanuel is an African Methodist Episcopal church, part of the denomination, a group of churches sharing one set of teachings, that Richard Allen and other Black Methodists formed in 1816. Twelve members were meeting in the fellowship hall, and Roof came in at about 8:16.

Judges of a federal appeals court later wrote that "the parishioners welcomed Roof, handing him a Bible and a study sheet," and that for 45 minutes he "worshipped with the parishioners." Then: "They stood and shut their eyes for closing prayer. Roof then took out his gun and started shooting." He fired about seventy-four shots.

The nine killed were the Reverend Sharonda Coleman-Singleton, Cynthia Hurd, Susie Jackson, Ethel Lee Lance, the Reverend DePayne Middleton-Doctor, the Reverend Clementa Pinckney, Tywanza Sanders, the Reverend Daniel Simmons Sr. and the Reverend Myra Thompson. Roof told the FBI that he had looked up African American churches in Charleston, visited this one beforehand, and learned from a member that the Bible study met on Wednesday nights.

A federal jury convicted him on 33 counts, among them nine counts of obstructing religion resulting in death. That federal crime means using force to stop people from practicing their religion, in a way that kills someone. He was sentenced to death, and appeals judges upheld the sentence on August 25, 2021.

**Sutherland Springs, 2017.** Devin Patrick Kelley walked into the First Baptist Church of Sutherland Springs, Texas, on Sunday, November 5, 2017, and opened fire. He killed twenty-six people and wounded twenty-two more, then died of his own gunshot after fleeing. Among the dead were Emily Hill, 11, and Megan Hill, 9. Kelley had been convicted of a crime of domestic violence while he was in the U.S. Air Force. In 2012 a military court found him guilty of attacking his wife at the time, Tessa Brennaman, and his stepson.

**The missing record.** Air Force agents and jail staff never sent his fingerprints or his conviction to the FBI. A gun store must run a background check, a search of national criminal records, before it sells a gun, and a reported conviction like his would have stopped the sale. Without the record, Kelley passed the check each time he bought a gun from a store.

Judge Xavier Rodriguez, a federal judge, found in 2021 that federal officials had failed "to exercise reasonable care" in sending his criminal record to the FBI. He held the United States government 60 percent responsible for the harm. He wrote that if the government had reported the record, it was "more likely than not" that Kelley would have been deterred, or put off, from the shooting.

**Pittsburgh, 2018.** Three Jewish congregations, Tree of Life, Dor Hadash and New Light, were at prayer in one building in Pittsburgh, Pennsylvania, on Saturday morning, October 27, 2018. Twelve Tree of Life members were in the chapel, partway through the opening prayers. Audrey Glickman had begun the service. David Rosenthal, who could not read but had memorized every prayer and song, was helping to lead it, and his brother Cecil was one of the greeters.

In Dor Hadash's room, three men were setting out prayer books and copies of the Torah, the Jewish scriptures: Jerry Rabinowitz, a doctor, Daniel Leger, a hospital chaplain, a minister who serves patients, and Martin Gaynor. Downstairs, Richard Gottfried and Daniel Stein of New Light were in the kitchen making a meal for a breakfast the next day.

Robert Bowers came in with three handguns and a rifle and killed eleven people: Jerry Rabinowitz, David Rosenthal, Cecil Rosenthal, Rose Mallinger, Bernice Simon, Sylvan Simon, Joyce Fienberg, Irving Younger, Richard Gottfried, Daniel Stein and Melvin Wax. The youngest was 54, and Rose Mallinger was 97.

Two more worshippers were badly wounded, and five police officers were injured going in after him. Federal prosecutors charged him with eleven counts of obstructing the free exercise of religious beliefs resulting in death, among other crimes. He was sentenced to death on August 3, 2023.

**By 2018:** Gunmen had killed worshippers at morning prayers in a gurdwara in Oak Creek, at a Bible study in Charleston, at a Sunday service in Sutherland Springs and at Saturday prayers in Pittsburgh.

### Two attacks on churches in 2025

**Minneapolis.** Children at the Church of the Annunciation in Minneapolis were at an all-school Mass, the Catholic worship service, on Wednesday, August 27, 2025, in the first week of school. A shooter fired through the church windows at them in the pews. Two children were killed. Twenty-six children and three adults were wounded by gunfire, and one more person was hurt in another way, according to the City of Minneapolis.

NPR reported that the shooter was Robin Westman, 23, who then fatally shot themself at the scene, according to police. NPR reported that FBI officials called it an act of domestic terrorism, an attack meant to frighten people inside the country. They said it was driven by a "hate-filled ideology," a set of hateful ideas.

**Grand Blanc Township.** Members of the Church of Jesus Christ of Latter-day Saints were at services in their meetinghouse in Grand Blanc Township, Michigan, on Sunday, September 28, 2025. Thomas Jacob Sanford, 40, of Burton, Michigan, drove his pickup truck through the front doors. He opened fire and set the building on fire. He killed four people: Craig Hayden, Pat Howard, John Bond and Thelma Armstrong.

Nine others, aged 6 to 78, were wounded. Police shot him dead within 3 minutes and 43 seconds of the first 911 call, the television station WNEM reported. The reports of the attack give no settled reason for it.

**The count for 2025.** FBI officials released their count of hate crimes for 2025 in August 2026. By the reading of the Anti-Defamation League, a group that speaks out against anti-Semitism, police reported 2,408 hate-crime incidents based on religion, and 1,528 of them, or 63 percent, were aimed at Jews. Staff of the Sikh Coalition, a group that speaks up for Sikhs, counted 177 incidents aimed at Sikhs in the FBI's figures for 2025, up from 142 in 2024.

### What priests did to children, and what bishops did about it

More than 4,000 Catholic priests in the United States were accused of sexually abusing children between 1950 and 2002. Sexual abuse of a child means an adult using a child's body for sex. Church officials reported few of these priests to the police, and in Pennsylvania a grand jury found that church leaders in six dioceses had hidden the abuse.

**The John Jay report.** In 2002 the Catholic bishops of the United States asked John Jay College of Criminal Justice, in New York, to study how many of their priests had done it. Researchers at the college published their report in February 2004. It was based on surveys covering 98 percent of the country's diocesan priests, the priests who serve in a bishop's region.

The report records accusations against 4,392 priests for the years 1950 to 2002, about 4 percent of all the priests who served in those years, or one in twenty-five. These were accusations that had not been withdrawn and were not known to be false. In all, 10,667 people said they had been abused. Half of them were between 11 and 14 years old when it happened. Sixteen percent were between 8 and 10, and nearly 6 percent were younger than 7. Eighty-one percent were boys.

**What was done to them.** The acts reported most often were touching the child over or under the clothes. Next came the priest putting his mouth on the child's sex organs, the child being undressed, and rape, which means forcing sex on a person, or attempted rape. Rape or attempted rape was reported in 22.4 percent of the cases.

Most of the accused priests were said to have done more than one of these things to the same child. It happened most often in the priest's own home or the parish house, the house beside the church where priests live, and next most often inside the church.

**Who was told.** Only 384 of the 4,392 priests were ever charged with a crime. Victims reported fifteen percent of the priests to the police. The report says that dioceses and religious orders, the groups of priests, brothers or sisters who live under shared religious promises, reported "a much smaller number." Before 1993, church officials knew of only a third of the cases at all.

The dioceses and religious orders reported that they had already paid $472 million for victims, for treating priests and for lawyers, and 14 percent of them gave no figure.

**Accusations after 2004.** People kept coming forward after the report, and most of them told of abuse from decades before. Researchers at the Center for Applied Research in the Apostolate at Georgetown University sort the accusations made since 2004 by the years in which the abuse is said to have happened. They count 4,216 for the ten years of the 1960s, 2,813 for just the five years from 1970 to 1974, and 36 for the three years from 2020 to 2022.

These are accusations made years afterward. They are not a count of everything that happened in each period, and one priest can be accused by more than one person.

**Pennsylvania, 2018.** A grand jury in Pennsylvania released a report on six of the state's Catholic dioceses in August 2018. The jurors read half a million pages of the dioceses' own internal records. They found believable accusations against more than three hundred priests. They identified more than one thousand children from the church's own records, and they wrote that they believed the real number was in the thousands.

The jurors wrote that most of the victims were boys and some were girls, some were teenagers, and many were young children whose bodies had not yet begun to grow into adult bodies. Some were raped. "But all of them were brushed aside, in every part of the state, by church leaders who preferred to protect the abusers and their institution above all."

**The playbook.** The grand jury set out what it called a playbook for hiding the truth. Its first item was to use mild words instead of real ones in church documents: never to write "rape," but "inappropriate contact" or "boundary issues" instead. In the grand jury's account, church officials let fellow priests ask the questions rather than trained investigators. When they removed a priest, they told his parish he was on "sick leave," or said nothing.

They kept paying for his housing and living costs. If people found out, they moved him to a new place "where no one will know he is a child abuser." The last item was "Finally and above all, don't tell the police." Because of this hiding, the jurors wrote, "almost every instance of abuse we found is too old to be prosecuted."

The bishops released their own yearly audit, a check of their records, for July 2024 to June 2025 in May 2026. It records 1,070 new accusations made by 973 people, OSV News, a Catholic news service, reported. Only 24 of them came from people who were still children. Most of the rest concerned abuse that had happened decades earlier. Diocesan officials reported $389.9 million in costs connected with abuse that year.

**The Southern Baptists.** Members of the Executive Committee of the Southern Baptist Convention, a large group of Baptist churches, hired an outside firm, Guidepost Solutions, to look at how they had handled abuse. The firm published its report in May 2022. It states that people who reported abuse "were met, time and time again, with resistance, stonewalling, and even outright hostility," stonewalling meaning refusing to answer or act.

The firm's investigators found that two former leaders, D. August Boto and Roger Oldham, had kept a private list of ministers accused of abuse. On May 26, 2022, the committee released the list, 205 pages long, NBC News reported.

### A sacred place traded to a mining company, 2014 to 2026

Members of Congress ordered in 2014 that Oak Flat, a place where Apache people pray, be traded to a mining company, and in March 2026 the trade was completed. Oak Flat, called Chí'chil Biłdagoteel in Western Apache, is a place in the Tonto National Forest in Arizona where Apache people hold ceremonies, among them the Sunrise Ceremony. It was listed on the National Register of Historic Places in 2016.

The company is Resolution Copper, owned by the mining companies Rio Tinto and BHP. Members of Congress put the order into the yearly bill that pays for the armed forces. With the exchange of about 2,400 acres in March 2026, the land became private property. Company officials expect the mine to leave a crater about two miles wide within about forty years, the radio station KJZZ reported.

### A church divides, 2019 to 2024

More than a quarter of the United Methodist Church's American congregations left it between 2019 and the end of 2023. Its members had argued over gay members and gay ministers, gay meaning attracted to people of the same sex, since at least 1984. That year a ban on making gay people ministers went into the church's rule book.

**The way out.** At a special General Conference in 2019, the gathering where delegates write the church's rules, delegates added a rule. Under it, a congregation could leave the denomination, the whole group of United Methodist churches, and keep its buildings for "reasons of conscience" over the church's decisions about homosexuality, another word for being gay. The rule ran out on December 31, 2023. By then more than 7,600 congregations in the United States had left under it, about 26 percent of the church's American congregations.

**The ban lifted.** Delegates at the General Conference in Charlotte, North Carolina, voted 692 to 51 on May 1, 2024, to remove the ban that had been in the church's rule book since 1984. It had banned making gay people ministers, in the rule's words "self-avowed practicing homosexuals," meaning gay people who said so openly and lived as gay people. Delegates at the same conference also removed the ban on ministers and churches holding weddings for same-sex couples.

**By 2024:** Researchers working for the Catholic bishops had counted 10,667 people who said priests abused them as children, Southern Baptist leaders had released a private list of accused ministers, and about a quarter of United Methodist congregations had left their church.

### A prisoner's dreadlocks, 2020 to 2026

Damon Landor was a prisoner at the Raymond Laborde Correctional Center in Louisiana. In 2020, on the warden's order, guards there handcuffed Landor to a chair and shaved off his dreadlocks. Landor had grown them for decades under a Rastafarian vow, a religious promise not to cut his hair. He showed the guards a court decision, and they threw it away. He had three weeks left to serve.

Landor sued under the Religious Land Use and Institutionalized Persons Act, a federal law that protects the religious practice of people held in prisons. The justices of the Supreme Court ruled 6 to 3 on June 23, 2026, that he could not sue the individual officers for money under that law. Justice Neil Gorsuch wrote for the majority. Justice Ketanji Brown Jackson disagreed, joined by Justices Sotomayor and Kagan. Published accounts of the case do not name the guards.

### Worship on a screen

Twenty-seven percent of American adults were watching religious services on a screen by November 2022. Researchers at the Pew Research Center asked 11,377 adults how they took part in worship between November 16 and 27, 2022, and Pew published the answers in June 2023.

Sixteen percent were regularly going to services in person only, 10 percent were regularly watching only on a screen, and 17 percent were doing both. In all, 43 percent were attending or watching at least once a month, and 57 percent were doing neither. Among those who did both, 76 percent said they would rather be in the room. The reason people gave most often for watching on a screen was that it was convenient.

### The churches answer for the boarding schools, 2022 to 2024

Catholic leaders apologized between 2022 and 2024 for the church's part in the boarding schools for Native children. Religious groups ran 210 of the 417 federal Indian boarding schools in the United States. At the 417 schools, staff cut children's hair, forbade their languages and beat them, and at least 973 children died, by the count of investigators at the Department of the Interior.

**The pope.** In Canada on July 25, 2022, Pope Francis asked forgiveness for the ways that church members "cooperated, not least through their indifference, in projects of cultural destruction and forced assimilation," forced assimilation meaning making people give up their own ways of life. He was speaking of Canada's schools.

**The Doctrine of Discovery.** Officials at the Vatican, the headquarters of the Catholic Church in Rome, rejected the Doctrine of Discovery on March 30, 2023. Catholic News Service described it as a set of old writings by popes that "appeared to bless the efforts of explorers to colonize and claim the lands of any people who were not Christian." The Vatican officials said it "is not part of the teaching of the Catholic Church."

**The bishops' apology.** The bishops of the United States Conference of Catholic Bishops voted 181 to 2 on June 14, 2024, to adopt a document called "Keeping Christ's Sacred Promise." It is a formal apology for the Catholic Church's part in the schools in the United States. The Interior Department's 2024 report on the schools states that its authors know of no support from the bishops' conference for a Pope's apology for the schools in the United States.

### Prayer at a football game, 2000

Families went to court again and again from 2000 on over religion in public schools and public money for religious schools. One case, decided on June 19, 2000, was about football.

At Santa Fe High School in Texas, before 1995, a student elected as chaplain of the student council said a prayer over the loudspeakers before every home game of the school's top football team. District officials then set up two student elections. One decided whether to have prayers at the games, and the other chose who would give them. Two families sued, one Mormon and one Catholic. In *Santa Fe Independent School District v. Doe*, the justices of the Supreme Court struck down the policy.

### Public money and religious schools, 2022

The justices of the Supreme Court ruled in 2022 that Maine's officials could not refuse to pay for a child's schooling because the school taught religion. Under Maine law, the state pays the fees for children who live in towns with no high school of their own. Since 1981 it had paid only for schools that were nonsectarian, meaning not tied to any religious group.

David and Amy Carson of Glenburn, Maine, sent their daughter to Bangor Christian Schools, which Bangor Baptist Church had founded in 1970. They paid her fees themselves. Troy and Angela Nelson of Palermo, Maine, sent their son to Temple Academy, a school connected with Centerpoint Community Church. They could not afford its fees for their daughter too, so she went to a private school that was not religious. On June 21, 2022, in *Carson v. Makin*, the justices ruled 6 to 3 for the families.

**What the schools taught.** Justice Breyer, who disagreed, quoted the two schools' own descriptions of their teaching. One of Bangor Christian's goals is "lead[ing] each unsaved student to trust Christ as his/her personal savior," an unsaved student being one who did not yet believe in Christ. School officials said there was no way to separate its religious teaching from its other teaching.

Temple Academy said the Bible is used in every subject it teaches. In mathematics that meant teaching that a creator made the universe so that "one plus one is always going to be two."

### Joseph Kennedy

> **Who:** A high school football coach who was put on paid leave over his prayers on the field after games, and who won his case in the Supreme Court.
>
> **When and where:** Bremerton, Washington, 2008 to 2022.

**He knelt at the 50-yard line after every game.**

Joseph Kennedy was put on paid leave from coaching over prayers he said on the football field. In 2022 the justices of the Supreme Court ruled 6 to 3 that the school district's officials could not punish him for those prayers. He spent nearly twenty years in the Marine Corps. In 2008 he began coaching football at Bremerton High School in Washington State. After each game, once the players and coaches had shaken hands, he knelt at the 50-yard line and prayed for about thirty seconds.

At first he prayed alone. Then players asked whether they could join him, and he told them, "This is a free country. You can do what you want." After some games most of the team knelt with him. Sometimes players from the other team were invited to join. He began adding short speeches to encourage the players when others were there. No one complained for more than seven years.

**The letters.** In September 2015 an employee of another school praised the practice to Bremerton's principal, and the district's superintendent found out. District officials wrote to Kennedy on September 17, 2015. On October 16 they wrote again, forbidding "any overt actions" while he was on duty that could look like the school supporting prayer.

He prayed after the games of October 16, 23 and 26. On October 16 most of his players were singing the school fight song, and players from the other team and people from the crowd joined him before he finished. On October 23 no one joined him. On October 26 other adults gathered around him while he knelt. After that game, district officials put him on paid leave and barred him from the football program.

**Two readings of one record.** On June 27, 2022, in *Kennedy v. Bremerton School District*, the justices ruled for him, 6 to 3. Justice Gorsuch wrote for the majority that the First Amendment protects "an individual engaging in a personal religious observance from government reprisal," which means punishment by government officials.

Justice Sotomayor, who disagreed, described what happened differently. She wrote: "To the degree the Court portrays petitioner Joseph Kennedy's prayers as private and quiet, it misconstrues the facts," the petitioner being the person who brings a case to the Court. She wrote that the record showed that he "consistently invited others to join his prayers and for years led student athletes in prayer at the same time and location." The nine justices read the same record and described the events in two different ways.

### The Ten Commandments in the classroom, 2024 to 2026

Louisiana's lawmakers passed a law requiring every public school classroom to display the Ten Commandments, and Governor Jeff Landry signed it on June 19, 2024. Families of several faiths sued to stop it. The justices of the Supreme Court had struck down a Kentucky law that required the same thing in 1980, in *Stone v. Graham*.

Louisiana's law requires a poster or framed copy at least 11 inches by 14 inches, with the Commandments as its "central focus" in large print. The law sets out the exact wording, which begins "I AM the LORD thy God."

**The parents.** The parents who sued include ministers and Jewish parents, and the case is named for one of them, the Reverend Darcy Roake. A Jewish parent swore that the law "misappropriates a Jewish text, ripping it from its Jewish context," which means it takes and misuses something that belongs to Jews.

The parent said it then requires the changed text to be shown to non-Jews, "in violation of core Jewish tenets that oppose proselytizing." Tenets are the main rules of a faith, and proselytizing means trying to convert people to a religion.

Another Jewish parent objected that Louisiana's version leaves out the freeing of the Jews from slavery in Egypt, "a key piece of the Ten Commandments and of the Jewish story." A Presbyterian minister who is also a parent objected to the state putting its "stamp of approval" on one version.

**In the courts.** A federal judge blocked the law, and on June 20, 2025, three judges of the Fifth Circuit Court of Appeals, the federal appeals court for Louisiana, Texas and Mississippi, agreed. Then all the judges of the Fifth Circuit reheard the case, and on February 20, 2026, they lifted the order blocking the law.

The law is called House Bill 71, or H.B. 71. The judges wrote that the question before them was "not whether H.B. 71 is constitutional, but whether that issue is fit for judicial resolution at this time." They held that it was too early to decide. Three judges disagreed in writing. As of September 2026, no court had decided whether Louisiana's law breaks the Constitution.

**Texas.** Texas's lawmakers passed a similar law. Rabbi Mara Nathan is one of the parents suing over it. She objects that the required text "erases this foundational Jewish tenet and historical context."

The full Fifth Circuit's judges ruled 9 to 8 on April 21, 2026, that the Texas law does not violate the First Amendment's religion clauses, the two parts of the amendment about religion. On August 17, 2026, the Texas families asked the Supreme Court to hear their case. As of late September 2026 the Court had not said whether it would.

### Storybooks and parents' faith, 2025

Members of the school board of Montgomery County, Maryland, added five storybooks with LGBTQ+ characters, a short name for lesbian, gay, bisexual, transgender and queer people and others, for children from kindergarten to fifth grade in the 2022 to 2023 school year. At first board members let parents take their children out of those lessons. Then they ended that choice.

**The parents.** Parents of several faiths sued. Tamer Mahmoud and Enas Barakat are Muslims. Jeff Roman is Catholic and Svitlana Roman is Ukrainian Orthodox. Chris and Melissa Persak are Catholics.

The justices of the Supreme Court ruled 6 to 3 on June 27, 2025, in *Mahmoud v. Taylor*, that the parents were entitled to have their children excused while the case went on. Justice Alito wrote for the majority. He relied on the 1972 Amish case, *Wisconsin v. Yoder*, and its holding that parents have a right "to direct the religious upbringing of their children."

Justice Sotomayor wrote for the three who disagreed. She wrote that public schools "offer to children of all faiths and backgrounds an education and an opportunity to practice living in our multicultural society." She warned that this "will become a mere memory if children must be insulated from exposure to ideas and concepts that may conflict with their parents' religious beliefs."

### Fewer sisters to teach in the Catholic schools

Members of religious orders built and staffed the Catholic school system of the 1800s. By 2025 there was about one Catholic sister, or nun, in the United States for every five there had been in 1965. The Center for Applied Research in the Apostolate at Georgetown University takes its figures from the Catholic Church's own yearly directory. Its researchers counted 178,740 religious sisters in the United States in 1965, 79,814 in 2000, and 33,135 on January 1, 2025.

**Schools, priests and Mass.** Over the same sixty years, Catholic elementary schools fell from 9,366 to 4,606, and Catholic high schools from 1,986 to 1,178. Priests fell from 59,426 to 33,462. In 1965, 530 parishes had no priest living there as pastor. In 2025, 3,674 did not. The same center estimates from surveys that 54.9 percent of Catholics went to Mass every week in 1970, and 17.6 percent in 2025.

### Teaching religion at home

Some parents teach their children at home so that they can teach them religion. The National Center for Education Statistics, part of the U.S. Department of Education, surveyed parents of homeschooled children aged 5 to 17 about the 2022 to 2023 school year and published the answers in September 2024.

Fifty-three percent said that wanting to give religious instruction was an important reason for homeschooling, and 11 percent said it was the most important reason. More parents named a concern about the environment of other schools. That was important to 83 percent and the most important reason for 28 percent.

**The three questions, answered**

- Why did colonists who crossed the ocean to worship freely punish other people for their faith? The Puritans wanted freedom for their own way of worship, and they ran Massachusetts by it. Their leaders banished Roger Williams and Anne Hutchinson and hanged four Quakers in Boston.
- How did Americans stop paying taxes to support churches? Baptists and James Madison defeated a new church tax in Virginia, where Jefferson's religious freedom law passed in 1786. Massachusetts ended the last state church tax in 1833.
- How long did US officials treat Native ceremonies as crimes? For ninety-five years, from Hiram Price's rules of 1883 until members of Congress passed the American Indian Religious Freedom Act in 1978.

**What changed:** In the 1600s officials in New Mexico and Massachusetts punished people for how they worshipped, and later Americans fought for freedom of worship in court, sometimes winning and sometimes losing.

**Five dates to keep**

- August 10, 1680: Po'pay leads the Pueblo rising in New Mexico.
- January 16, 1786: Virginia's lawmakers pass Jefferson's religious freedom law.
- December 1791: the First Amendment becomes part of the Constitution.
- April 1906: Pentecostal worship begins at Azusa Street in Los Angeles.
- August 11, 1978: the American Indian Religious Freedom Act passes.

**Not known:** Nobody knows what the people of Cahokia believed as they watched the sun rise over Woodhenge.

**Where to go:** The statue of Po'pay, whipping scars carved on its back, stands in the US Capitol in Washington, D.C.

**Next:** Chapter 30, School and Education. It asks who got to go to school in America, and what they learned there.
