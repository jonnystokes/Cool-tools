# Chapter 33: Music

**Chapter 33 of 37 · Music · 10 eras · about 135 minutes**

**For most of American history, the people who made the music were often not the people who got paid for it.**

Willie Mae "Big Mama" Thornton, a blues singer from Alabama, recorded "Hound Dog" on August 13, 1952, and her record went to No. 1 on the rhythm and blues chart. Don Robey, who owned her record company, put his own name on the copyright form as one of the song's writers. Each writer named on that form has a right to part of the money the song earns.

Four years later Elvis Presley recorded the same song and sold about 10 million copies. "I got one check for $500 and never saw another," Thornton said. She died poor in a Los Angeles boarding house in 1984.

This chapter follows American music from wooden flutes made in the 600s to songs streamed over the internet. In every era, look first at who made the music: Native singers, enslaved fiddlers, New England singing teachers, blues singers in Mississippi, a teenage DJ in the Bronx. From the 1770s on, the records show who was paid, so look at that too.

Again and again the money and the credit went to someone else: a white stage performer who copied a Black man's song, a publisher who put his own name on a song, a company that paid a set fee and kept the rest. Watch, too, for the people who tried to stop music, from lawmakers who banned drums to officials who banned Native dances.

**Three questions this chapter answers**

- Where did the banjo and the blues come from?
- Why did so many musicians make hit songs and still die poor?
- Who tried to stop people from playing their own music, and why?

**Five minutes?** Read "Drums at Stono, and the 1740 law against drums and horns" in 1700 to 1750, then "Records for Black buyers, and who was paid, 1920 to 1938" in 1900 to 1950.

**Can skip:** "Jenny Lind's tour, 1850 to 1852", "Concerts for a ticket, and a fiddle for a prize", "The Kennedy Center, 2025 and 2026". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 4 minutes**

Native nations in this land made music for nearly every part of life, and they passed their songs on by teaching them. Their songs were for ceremonies, healing, work, games, courting a sweetheart, storytelling, hunting, farming, war and social dances. None of the nations north of Mexico had a way of writing tunes down, so no singer's name and no song's name from these centuries survives in writing.

Some of the instruments survive. Archaeologists, scientists who dig up and study what people left behind, have found wooden flutes and metal-covered panpipes more than a thousand years old. Onondaga and Tlingit singers today still follow rules about where a song may be sung and who owns it.

### How old are the oldest flutes?

The oldest known wooden flutes in North America were made between the years 620 and 670. Ancestral Pueblo people, the ancestors of today's Pueblo peoples, made them. The archaeologist Earl H. Morris found them in 1931, when he explored 15 caves in the Prayer Rock district of northeastern Arizona, in what is now the Navajo Nation. In the largest cave he found four wooden flutes. That cave is now called Broken Flute Cave.

**The flutes.** Each one is a tube of box elder wood between about 68 and 74 centimeters long, a little over two feet. The finger holes are almost the same on each flute, so the maker planned which notes the flute would play. Red, blue and black feathers were tied to one end. Two of the flutes lay broken in trash above a grave. The other two lay whole under a dirt floor, tied together. The Arizona State Museum in Tucson holds them today.

**The panpipes.** Farther east, people of the Hopewell culture lived in the woodlands of eastern North America between the years 1 and 400. "Hopewell" is a name archaeologists gave them, not the name of a nation. In southern Ohio they built earthworks, mounds and long banks of piled earth. A Hopewell panpipe is a row of three or four tubes of cane, reed or bone, held together by a metal jacket. A player blows across the tubes, and each tube makes a different note.

Almost every Hopewell panpipe that archaeologists have found was buried with the dead. They have found 105, from Wisconsin and Ontario down to the Gulf Coast, and very few came from places where people lived. Most of the metal jackets are copper. The rest are silver, copper covered with silver, or iron.

**Not known:** Nobody knows what tunes anyone played on these flutes and panpipes.

### Drums, rattles, and songs that belong to someone

Onondaga singers today play a water drum and a horn rattle. The Onondaga Nation, in what is now central New York, is one of the Haudenosaunee nations. The water drum is usually made of cedar, with deer hide stretched over the top. The horn rattle is a dried, hollowed animal horn with seeds inside. A rattle made of turtle shell is used only in a few ceremonies.

The Onondaga keep two kinds of songs. Social songs can be sung anywhere. Songs for ceremonies are sung only in the longhouse, the building where ceremonies are held, and the public may not watch them.

**Songs a clan owns.** Among the Tlingit of what is now southeast Alaska, a song can belong to a clan, a large family group that traces itself back to shared ancestors. A clan owns its songs, its stories, its crests and the clothing its members wear in ceremonies. The Tlingit word for these owned things is *at.óow*, "something owned or purchased."

Some songs and stories tell of a clan's losses in a certain place. In the Tlingit view, those songs are the clan's deed to that place, the proof that the place is theirs.

**Known:** These rules come from the nations' own accounts today.

**Not known:** No written record from before 1500 describes them.

### R. Carlos Nakai

> **Who:** A flute player from a Navajo (Diné) and Ute family, whose records were the first of the traditional Native flute to sell 500,000 copies.
>
> **When and where:** Born April 16, 1946, in Flagstaff, Arizona. Still performing in 2026.

**A car crash ruined his trumpet playing, and someone gave him a flute.**

R. Carlos Nakai first studied the trumpet. A car accident ruined the way he shaped his lips against the trumpet's mouthpiece. Someone gave him a cedar flute as a gift and challenged him to master it. His family is Navajo and Ute, and his father, Raymond Nakai, was chairman of the Navajo Nation from 1963 to 1970.

**The records.** Nakai has recorded more than forty albums with Canyon Records in Phoenix, Arizona, starting with *Changes* in 1983. His albums *Canyon Trilogy* and *Earth Spirit* each sold 500,000 copies, and each earned a gold album award from the RIAA, the music business group that gives sales awards. They were the first recordings of the traditional Native flute to sell that many. *Canyon Trilogy* kept selling. In 2014 the RIAA named it a platinum album, its award for one million copies.

He was nominated for ten Grammy awards between 1994 and 2013. Nakai calls himself "an iconoclastic traditionalist," someone who breaks with old ways and keeps them at the same time. His concert calendar for 2026 lists shows in Utah and Colorado in September and more in October and November.

**Why this story is here:** Flutes survive from before 1500, but no flute player's name does, so this era's story belongs to a living player of the traditional cedar flute.

## The 1500s

**Era 2 of 10 · The 1500s · about 4 minutes**

The first European music on record in what is now the United States is church singing and soldiers' trumpets, and Native people watched and listened. It comes from three places: the coast of Florida, the coast of California, and New Mexico from 1598. Spanish priests sang Latin hymns, songs that praise God, when they came ashore and when they held services. French and English Protestants, Christians who had broken away from the Catholic Church, sang psalms, songs from the Bible.

Europeans wrote down a few of the Native listeners' reactions. No record from the 1500s names a mission choir or a Native singer trained in church music. The first ones on record come after 1598.

### Hymns sung at the landings, Florida, 1564 and 1565

French Protestants called Huguenots built Fort Caroline in 1564, near the mouth of the St. Johns River and today's Jacksonville, Florida. They built it on the land of the Timucua people. Their leader, René de Laudonnière, wrote that on June 30 he ordered his men to sing aloud on the beach to thank God for their safe arrival. The historian Francis Parkman wrote in 1865 that on the morning they began the fort, the men sang a psalm before they started work.

**St. Augustine.** The Spanish commander Pedro Menéndez de Avilés landed at Seloy, a Timucua town, on September 8, 1565, and founded St. Augustine. His chaplain, the priest who served his soldiers, was Francisco López de Mendoza Grajales, and the chaplain wrote an account of that day. He wrote that Menéndez came ashore "to the sound of trumpets and salutes of artillery," meaning cannons fired as a greeting.

The chaplain walked to meet Menéndez carrying a cross and singing the *Te Deum*, a Latin hymn of praise to God. "A large number of Indians watched these proceedings and imitated all they saw done," the chaplain wrote.

**The killings.** Menéndez's soldiers captured Fort Caroline on September 20, 1565, and killed most of the Frenchmen there. In a letter of October 15, Menéndez wrote that 132 of them had "their throats cut." He gave his reason in the same letter: "they spread the Lutheran sect," meaning the Protestant faith. When Menéndez came back to St. Augustine, the chaplain and his companions walked ahead of him in a line, "singing the Te Deum laudamus."

In the weeks after, shipwrecked Frenchmen surrendered to Menéndez at a place called Matanzas. His soldiers killed 111 of them. On October 12 they killed 134 more who had surrendered with their leader, Jean Ribault.

### Psalms at Drake's landing, California, 1579

The English captain Francis Drake stopped on the California coast in June 1579 to repair his ship, probably at the place now called Drake's Bay. Coast Miwok people lived along that shore. Drake's men stayed for about five weeks. They held prayers, sang psalms and read from the Bible, and Miwok people came to watch.

**"Gnaah."** A book about the voyage, *The World Encompassed by Sir Francis Drake*, states that the Miwok "tooke such pleasure in our singing of Psalmes" that each time they came, "their first request was Gnaah." That word meant they wanted the Englishmen to sing. The anthropologist Robert Heizer, a scientist who studied people and the ways they live, wrote in 1947 that *gnaah* seems to be a Coast Miwok word.

**Who wrote the book.** It came out in London in 1628. Drake's nephew, also named Francis Drake, put it together. Its title page states that it was collected "out of the Notes of Master Francis Fletcher," the preacher on the voyage, and checked against other notes made on the same voyage. Heizer wrote that who wrote it is uncertain.

### New Mexico, 1598

Juan de Oñate led Spanish colonists north into New Mexico in 1598 to start a colony on the lands of the Pueblo peoples. Pueblo people then began to hear Spanish military music and to sing Catholic church songs, some of them in parts, with different voices singing different notes at the same time. The music historian John Koegel dates this to "the Oñate expedition and its aftermath," meaning the journey and the years after it.

The earliest music teachers there that Koegel names are two friars, Catholic men who lived by the rules of a religious order and put the title Fray in front of their names. Fray Bernardo de Marta came in about 1605. Fray Cristóbal de Quiñones died in 1609.

## The 1600s

**Era 3 of 10 · The 1600s · about 5 minutes**

Colonists in the 1600s brought their church singing with them, and in New Mexico Spanish friars and officials punished Pueblo people for keeping their own ceremonies. In New England, congregations, the people who worship together at a church, sang psalms from a book printed in Massachusetts in 1640. For most of the century each printing of that book held only the words, with no musical notes.

In New Mexico, the friar Cristóbal de Quiñones put an organ in the church at San Felipe Pueblo and trained Pueblo singers. Later friars banned Pueblo religious ceremonies, and a Spanish governor had 47 Pueblo religious leaders arrested in 1675. Three were hanged. In Virginia, the crew of an English ship landed about twenty captured Africans in 1619. Enslaved Africans made music there through the century, but nobody who wrote in those years left a description of it that survives.

### Singing without notes: the Bay Psalm Book and lining out

Stephen Daye printed *The Whole Booke of Psalmes Faithfully Translated into English Metre* at Cambridge, Massachusetts, in 1640. People today call it the *Bay Psalm Book*, and it was the first book printed in British North America. Richard Mather and other New England ministers turned the Psalms of the Bible into English verse with a steady beat, so that a congregation could sing them. Eleven copies of that first printing survive.

**No notes.** The 1640 book had no printed music. It lists tunes by name, tunes already printed in English psalm books. The ninth edition, printed in 1698, was the first to include music: 13 tunes taken from a music book by an Englishman, John Playford.

**Lining out.** A gathering of ministers at Westminster, in London, wrote a guide for church services in 1644. Where many people in a congregation could not read, the guide says, the minister or a person he chose should "read the psalm, line by line, before the singing thereof."

This way of singing is called lining out. A leader read or sang one line, and the congregation sang it back. Colonists from England and Scotland brought lining out to America, and members of Old Regular Baptist churches in the United States still sing this way today.

### Fray Cristóbal de Quiñones

> **Who:** A Franciscan friar who built the church at San Felipe Pueblo, put an organ in it, and trained Pueblo singers.
>
> **When and where:** San Felipe Pueblo, a Keres-speaking town in New Mexico. Died in 1609.

**He put an organ in a Pueblo church and trained its singers.**

Fray Cristóbal de Quiñones belonged to the Franciscans, a Catholic religious order. He was the leader of the Franciscan friars in New Mexico. San Felipe is a Pueblo town whose people speak the Keres language. Quiñones learned Keres and baptized many Native people in the New Mexico missions, making them members of the Christian church in a ceremony with water. At San Felipe he built the church, a house for the friars, a pharmacy and a place to care for the sick.

**What one writer recorded.** Agustín de Vetancurt, a Franciscan writer in Mexico, described his work in a book of the lives of Franciscan friars, printed in the 1690s. Vetancurt wrote that Quiñones "installed an organ to enrich the Divine Service," meaning the church service, "and encouraged music-making by the skilled singers" he had trained.

Quiñones died in 1609. The music historian John Koegel calls him "perhaps the first trained teacher of European music" to live in what is now the US Southwest. Koegel gives neither his birthplace nor the year he came to New Mexico.

**Not known:** Vetancurt tells only the friar's side, and his account does not record what the singers of San Felipe thought of the music they were taught.

### Church music and banned ceremonies in New Mexico

Other friars taught music in more Pueblo towns. Fray Bernardo de Marta came to New Mexico in about 1605, taught Pueblo people in many towns to sing and to play European instruments, and died in 1635. By 1634 Fray Roque de Figueredo was teaching Zuni boys to sing in parts.

**The ban.** A Spanish church leader and a Spanish governor punished Pueblo people for keeping their own religion. The Franciscan leader Alonso de Posada forbade Pueblo ceremonies from 1656 to 1665. He ordered friars to invade the sacred kivas, the rooms where Pueblo people held their ceremonies. There the friars burned the masks and took or destroyed sacred objects.

**The arrests.** The governor, Juan Francisco Treviño, had 47 Pueblo religious leaders arrested in 1675 and charged with sorcery, using magic to do harm. Four were sentenced to be hanged. Three were hanged, and one killed himself. The rest were shamed and whipped in public, then put in prison. The records do not name the men who passed the sentences or carried out the hangings and the whippings. Pueblo people went to Santa Fe and demanded that the prisoners be freed, and Spanish officials let them go.

**Po'pay.** One of the whipped men was Po'pay, a leader from Ohkay Owingeh. On August 10, 1680, Po'pay led the Pueblo nations as they rose up together against the Spanish. The Pueblo fighters killed about 400 Spanish settlers, 21 of them Franciscan friars, and drove the Spanish out of New Mexico for 12 years.

### What arrived with enslaved Africans

The crew of an English ship called the *White Lion* landed "20. and odd Negroes" at Point Comfort, Virginia, in late August 1619. Those are the words of the colonist John Rolfe, and "Negroes" was a word of that time for Black people. The crew had taken these Africans from a Portuguese slave ship. They came from the Ndongo and Kongo region of West Central Africa.

Enslaved Africans made music in the English colonies through the 1600s, but no one who wrote in those years left a description of it that survives. The first clear description of an early banjo comes from the island of Jamaica. An English doctor there, Hans Sloane, wrote in 1687 about an instrument he called a "strum strump."

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 8 minutes**

Two fights over music ran through these fifty years. In New England, church members argued about singing from written notes, and in South Carolina, lawmakers took drums away from enslaved people. New England ministers began teaching their congregations to read notes around 1720. They started singing schools and printed the first books of music lessons in the colonies.

Boston had a concert for a paying audience by 1731, and a ticket cost five shillings. In Virginia, enslaved Black musicians played the fiddle. Three of them appear in notices their enslavers printed when the men ran away in 1745 and 1746. Enslaved men rose up near the Stono River in South Carolina in 1739, with drums beating. The next year South Carolina's lawmakers banned enslaved people from using drums and horns, and fined any master who let them.

### Singing by note and the first singing schools

New England churches still sang by lining out at the start of the 1700s. "By the end of the seventeenth century singing had sunk to a low level in all the colonies," the historian Henry Wilder Foote wrote. In the first 25 years of the 1700s, ministers in New England turned against lining out. They called for "regular singing" instead, which meant singing from written notes.

The Reverend Thomas Symmes of Bradford, Massachusetts, made the case in a booklet of 1720, *The Reasonableness of Regular Singing, or Singing by Note*. He wrote that church singing had got worse because "Singing schools and singing books being laid aside, there was no way to learn." New England had had singing schools in its early days, Symmes wrote, but people had stopped holding them.

**The first music books.** The Reverend John Tufts of Newbury, Massachusetts, published *An Introduction to the Singing of Psalm Tunes*, the first book of music lessons printed in the English colonies.

No copy of the first printing is known, so its exact title and year are uncertain. The dates given for it run from about 1712 to 1721. Tufts traveled to give talks about singing and to set up singing schools, where a teacher taught a class to read and sing music.

Thomas Walter, a 25-year-old nephew of the Boston minister Cotton Mather, published *The Grounds and Rules of Musick Explained* in 1721, with 24 psalm tunes. James Franklin printed it in Boston. It was the first music in the colonies printed with bar lines, the lines that divide music into equal parts of time. It stayed a favorite for more than forty years and went through six editions.

New singing schools spread in the 1720s. The records that survive do not say where the first one met or what a pupil paid.

**The young singers.** Young people took up the new singing first. The Boston judge Samuel Sewall wrote in his diary on March 20, 1721, that "Dr. Mather" had preached that night "in the school house to the young musicians." The house was full, Sewall wrote, "and the singing extraordinarily excellent, such as hardly been heard before in Boston."

**The fight.** Other church members fought the change. In Symmes's town, he reported, "a great part of the town has for near half a year, been in a mere flame about it." He meant that people had been angry and arguing about it for almost six months.

The Reverend Nathaniel Chauncey of Connecticut wrote answers in 1728 to the objections people raised. One objection was that singing by note "leads to the Church of England and will bring in organs quickly." The Church of England was the official church back in England.

The churches in this fight had been started by Puritans, English Protestants who wanted to clear the Church of England of what they saw as leftovers of the Catholic Church. Puritan congregations sang with no instruments at all, because instruments looked to them like Catholic worship. Another objection was only about who liked the change: the new way must be wrong "because the young people fall in with it."

### Concerts for a ticket, and a fiddle for a prize

A "Concert of Music" on several instruments was held in Mr. Pelham's great room in Boston on December 30, 1731. An advertisement in the *Boston News-Letter* that month listed it, and a ticket cost five shillings, a quarter of a British pound. It is the earliest advertised concert in Boston that the music historian Oscar Sonneck found. After a concert at Faneuil Hall in 1744, the town's selectmen, the men elected to run the town, received 205 pounds for the poor of Boston.

**A fiddle for a prize.** A notice in the *Virginia Gazette* of November 26, 1736, listed prizes for a holiday gathering at Page's Warehouse in Hanover County, Virginia, on November 30. One prize was "A fine Cremona Fiddle to be plaid for, by any number of Country Fiddlers." A Cremona fiddle was a violin made in the town of Cremona, in Italy. The races at John Pinkerton's Old Field in Virginia in November 1737 included a fiddling contest.

### Fiddles, banjos, and the enslaved musicians who played them

The banjo has West African roots. A 2014 article on the Oxford University Press blog counts more than 60 plucked instruments in West Africa that are likely forerunners of it. The first known mention of a banjo in the mainland colonies is in John Peter Zenger's newspaper, the *New-York Weekly Journal*, in 1736.

**Runaway notices.** Virginia enslavers put notices in the *Virginia Gazette* when an enslaved person ran away. Each notice described the person's body, clothes and skills, so that strangers could recognize and catch the person. Playing the fiddle was one of the skills these notices listed. The University of Virginia's collection of Virginia runaway notices holds three from before 1751 that name a musician: two men named Tom, and a fiddler named Harry.

Robert Whitfield of Isle of Wight County offered four pistoles, Spanish gold coins used in the colonies, for a young man named Tom, who "plays very well on the Violin." His notice ran in the issue of November 28 to December 5, 1745. In April 1746 John Thornton of Fredericksburg advertised for another man named Tom, about 46 years old, who "plays on the Violin, and is a Sawyer," a man who saws logs into boards.

### Harry, a fiddler who ran away, perhaps to his wife, 1746

> **Who:** An enslaved man who played the fiddle. The man who held him put a notice in the newspaper for his capture.
>
> **When and where:** Near Jamestown, Virginia, March 1746.

**He wore a blue greatcoat. His enslaver wanted him whipped.**

Harry was an enslaved fiddler who ran away in early March 1746 from the man who held him, near Jamestown, Virginia. Everything known about him comes from one notice in the *Virginia Gazette*, printed between March 20 and 27, 1746. The notice gives him no last name.

Harry was about 35 years old and about 5 feet 7 inches tall, with small eyes and "a very large Beard," and he "plays upon the Fiddle." He left wearing a double-breasted dark cloth coat, two dark cotton jackets, a blue greatcoat and buckskin breeches, which are pants that end at the knee. He had once belonged to Colonel Grymes of Richmond County, Virginia.

**The notice.** William Newgent signed it, though a later reprint spells his first name James. Newgent guessed that Harry had gone to Richmond County, "where he has a Wife." He offered one pistole for Harry's return. At the end he added: "As he ran away without any Cause, I desire he may be punish'd by Whipping, as the Law directs." Newgent was asking whoever caught Harry to have him beaten with a whip.

**Not known:** The record does not say whether Harry was caught.

### Drums at Stono, and the 1740 law against drums and horns

About 20 enslaved men seized weapons near the Stono River, south of Charleston, South Carolina, on September 9, 1739. A report written that year called them "Angola Negroes" and named their leader as a man called Jemmy. They marched south toward Spanish Florida.

More men joined them, "calling out Liberty," the report says, and they "marched on with Colours displayed," meaning flags, "and two Drums beating." When there were sixty to a hundred of them, they stopped in a field and "set to dancing, Singing and beating Drums, to draw more Negroes to them."

**The killings.** The same report says the rebels killed white men, women and children as they marched. Lieutenant Governor William Bull raised the militia, a force of armed planters, and the militiamen attacked the rebels in the field the same day. The report says the men captured in the field were questioned and then "shot on the Spot," and men who had run back to their plantations were caught there and shot. It does not name who fired.

The report counts about 40 Black people and 20 white people killed. Later counts give about 25 white colonists and 35 to 50 rebels killed. Colonists cut off the heads of rebels and set them on stakes along the main roads as a warning. They put most of the captured rebels to death and sold the survivors to the West Indies.

**The law.** The men of the South Carolina assembly passed the Negro Act on May 10, 1740. In section 36 they wrote that it was "absolutely necessary to the safety of this Province," meaning the colony, to stop enslaved people from "using or keeping of drums, horns, or other loud instruments."

They gave the reason in the same sentence: such instruments "may call together or give sign or notice to one another of their wicked designs and purposes." They meant that drums and horns could be used to call enslaved people together to rise up.

**What the law allowed.** A master or an overseer, the man who ran the work on a plantation, paid a fine of ten pounds each time he let enslaved people beat drums, blow horns or gather in public. The lawmakers wrote that enslaved people had to be kept from wandering and meeting at all times, and most of all on Saturday nights, Sundays and holidays. Any master, overseer or other person could seize an enslaved person found off the plantation without a written pass and with no white person along.

If an enslaved man found off the plantation carried a weapon, any master, overseer or other person could take the weapon away, seize him and whip him, even if he carried a pass.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 10 minutes**

Americans began writing and printing their own music in these years. The names of the Black musicians who played beside them survive mainly in the notices enslavers printed when those musicians ran away. A Boston tanner named William Billings published a book of church songs he had written himself in 1770. By 1800 Americans had published about forty books of church music. During the Revolution, officers used drum beats to tell soldiers when to wake, march and fight, and American writers put new words to old tunes.

Black musicians played fiddles, horns, drums and banjos in Virginia, in Charleston and in New England. Slave traders took one of them, Newport Gardner, from Africa as a boy. He became a music teacher in Newport, Rhode Island, and bought his freedom in 1791. That same year, on the Pacific coast, a man sailing with a Spanish expedition wrote down Tlingit songs in musical notes.

### William Billings and the New England singing masters

William Billings, a Boston tanner who turned animal skins into leather for a living, published *The New-England Psalm-Singer* in 1770. A Library of Congress research guide calls it "the first publication consisting of sacred music," meaning music for worship, "composed entirely by a native-born American." Paul Revere is credited with engraving the picture at the front of the book, cutting it into a metal plate so it could be printed.

Billings also taught singing schools. He opened one in Boston with John Barry in 1769, and he taught another in Stoughton, Massachusetts, in 1774. The historian Henry Wilder Foote counted about forty American books of church music published before 1800, most of them printed in Boston.

### William Billings

> **Who:** A tanner and singing teacher who wrote about 340 songs for choirs.
>
> **When and where:** Boston. Born October 7, 1746. Died September 26, 1800.

**A tanner with one blind eye wrote 340 songs and died poor.**

William Billings wrote about 340 songs for choirs and published them in six books. He did it while working as a tanner and a singing teacher. His father died when Billings was 14, and he went to work learning to tan leather. He was mostly self-taught in music, though he may have had some lessons from John Barry of Boston's New South Church. A writer named Nathaniel Gould described him in 1853 as having "one eye blind, one leg shorter than the other, one arm somewhat withered."

**"Chester."** His 1770 book included his song "Chester." It opens with the words "Let tyrants shake their iron rod." The singers say that they do not fear tyrants or the chains of slavery, because they trust in God. Billings printed a new version with five verses in *The Singing Master's Assistant* in 1778. Soldiers "learned the words by heart," according to the writer David Stowe, and carried Billings's songs wherever the army sent them.

**No copyright.** Other printers copied Billings's tunes without paying him. Before the Revolution, the men who made Massachusetts's laws voted for a bill, a proposed law, to give Billings copyright over his first book: the legal right to decide who may copy and sell it. The governor, a Tory loyal to the British king, refused to sign it. Stowe writes that the governor may have refused because Billings had ties to patriots such as Samuel Adams.

**Poor at the end.** His friends paid to print his book *The Continental Harmony* in 1794. His wife, Lucy, died on March 26, 1795, and left him with six children under 18. In the 1790s he worked as a street cleaner. Billings died poor in Boston on September 26, 1800, and was buried in an unmarked grave on Boston Common.

### Songs and signals of the Revolution

British officers first sang "Yankee Doodle" to make fun of the colonists. The man most often named as the writer of the words is Richard Shuckburgh, a British army surgeon, in about 1755 or 1758, during the French and Indian War. The date is disputed.

British soldiers arrived to occupy Boston in 1768, and their musicians played the song in the streets to mock the colonists. Early in the war, British troops and Loyalists, colonists who stayed on the British side, played it to make fun of the Continental soldiers. The Americans then made up their own verses, and by 1781 "Yankee Doodle" was a favorite American song.

**"The Liberty Song."** John Dickinson of Pennsylvania wrote its words to the tune of "Heart of Oak," the anthem, or official song, of the British Royal Navy. The *Boston Gazette* printed it in July 1768. Dickinson sent it to his Massachusetts friend James Otis with a note that "indifferent songs are very powerful on certain occasions." By indifferent he meant songs that were not very good.

**Orders by drum.** In the Continental Army, officers gave orders by drum beat. Under the army rules of Baron von Steuben, each beat had its own name and meaning. "The Reveille" woke the soldiers in the morning. "The General" meant take down the tents and get ready to march, "The Assembly" meant line up at the flags, and "To Arms" meant pick up weapons and get ready to fight.

Drummers beat "The Tattoo" at 9 or 10 at night, and at that signal tavern keepers stopped serving the soldiers drinks. Boys under 14 were recommended as drummers, according to the American Battlefield Trust, and some boys who played the fife, a small, high-pitched flute, were 9 or 10 years old.

### Black musicians, enslaved and free

Virginia enslavers kept naming enslaved musicians in their runaway notices. William Gregory advertised on May 4, 1769, for Peter, about 44, who had taken with him "a fiddle, which he is much delighted in when he gets any strong drink." David Walker of Dinwiddie County advertised on September 8, 1775, for Jemmy. He wrote that Jemmy "is very fond of singing hymns and preaching," and that he was living near Williamsburg under the name James Williams.

**Mark.** William Allason offered forty pounds in August 1780 for four men who had run away together from near Fauquier Court House, Virginia. One of them was Mark, about 25, born on the island of St. Jago, in the Cape Verde Islands off West Africa. He spoke Portuguese. The notice says Mark "blows the French horn, can play on the fiddle, whistles many tunes well," and that he loved marches and Catholic church music. Allason guessed that the four men planned to get aboard a ship.

**At Nomini Hall.** Philip Vickers Fithian was a tutor, a live-in teacher, to the children of Robert Carter III at Nomini Hall, a Virginia plantation, in 1774. His journal records that on a January evening, enslaved people gathered in the schoolroom "& began to play the Fiddle, & dance." Two of Carter's sons, Ben and Harry, joined them, and Fithian sent everyone away. A few days later, he wrote, "several Negroes & Ben, & Harry are playing on a Banjo & dancing."

**In Charleston.** A gentleman lost his pocketbook on the evening of December 2, 1766, as he passed "a croud of negroes assembled at the lower end of Elliott-street, with a banjer playing." A notice in the *South Carolina Gazette and General Advertiser* of December 12 reported the loss. A Charleston town rule of 1750 banned beating drums in town without an officer's permission.

**The earliest banjo painting.** A painting on paper called *The Old Plantation*, made between about 1785 and 1795, shows enslaved Black men and women dancing. One man plays an early banjo made from a gourd, a large fruit with a hard shell that can be dried and hollowed out. Another man plays a drum, and two women hold rattles. It is the earliest known painting of a banjo.

The librarian Susan Shames identified the painter in 2010 as John Rose, a South Carolina planter who held people in slavery. The Abby Aldrich Rockefeller Folk Art Museum in Williamsburg, Virginia, owns it.

**Jefferson.** Thomas Jefferson held people in slavery at Monticello, his plantation in Virginia. In the 1787 edition of his book *Notes on the State of Virginia*, he wrote about Black musicians: "In music they are more generally gifted than the whites." Then he doubted that they could write longer, more complicated music: that, he wrote, "is yet to be proved."

In a note he called the "Banjar" the instrument "which they brought hither," meaning here, "from Africa." In the same passage he wrote that Black people had "no poetry," and he dismissed the published poems of Phillis Wheatley, a Black woman.

**Election days.** Black communities in New England held their own election days from about 1750. In New Hampshire and Massachusetts they elected a "king," and in Rhode Island and Connecticut a "governor." The enslavers granted the day off and paid for the feast. The parades had "tambourines, banjos, fiddles and drums," and the feast had rum, gingerbread and "thick, fruit-studded election cakes."

### Newport Gardner

> **Who:** Born Occramer Marycoo in West Africa, enslaved in Newport, Rhode Island, where he became a music teacher and composer.
>
> **When and where:** Born about 1746. Newport, from about 1760. Died in Liberia in 1826.

**He won a lottery in 1791 and bought his family's freedom.**

Newport Gardner was about 14 when slave traders took him from West Africa to Newport, Rhode Island. His name at birth was Occramer Marycoo. Caleb Gardner, a merchant and ship captain, bought him and renamed him Newport Gardner. The music writer Sophie Lowe writes that Caleb Gardner "helped enslave some 3,912 human beings" through the slave trade.

**His teachers.** The enslaved boy learned English and music in Newport. The best-known account names Andrew Law as his teacher, Lowe writes. But Law is first known to have been in Rhode Island in 1783, when Gardner was already in his late thirties. Lowe concludes that he "probably had a variety of musical teachers."

**Freedom.** Gardner and some friends won a lottery in late December 1791. With his share he bought freedom for himself and his family, then opened a school in Newport where he taught music. At Newport's First Congregational Church he was a deacon, a church member who helps lead it. In the 1820s he helped found a Black church, according to the historian Edward Andrews, and the historian John Millar writes that Gardner joined the new Colored Union Church in 1824.

**His music.** The writer Eileen Southern credited to him a tune called "Crooked Shanks," printed in 1803. Lowe reports newer research that found the same tune in print in London in 1768, so the credit is uncertain. The words of his anthem, a church song, survive. They begin "Hear the words of the LORD, O ye African race."

**Liberia.** He led a group of Black New Englanders to Liberia, in West Africa. Millar counts about 30 of them, and Andrews counts about three dozen. Accounts also differ on when they sailed: late December 1825, or January 4, 1826. Gardner died of disease in Liberia within months, in 1826.

### Tlingit songs written down, 1791

Two Spanish ships led by Malaspina and Bustamante anchored in Yakutat Bay, in what is now Alaska, in 1791. The bay was Tlingit land. Several times, Tlingit people sang "to and with" the Spanish sailors.

Tadeo Haenke was a botanist on the ships, a scientist who studies plants, and he had trained in music. He wrote the songs down in musical notes on four sheets of paper. The sheets stayed in the Museo de América, a museum in Madrid, Spain, for more than 200 years.

**Hearing them again.** The scholar Steve Langdon got pictures of the sheets and sent them to Maria Shaa Tláa Williams, a Tlingit ethnomusicologist, a scholar who studies the music of a people and its place in their lives. Williams found that the singers used harmony, two or more notes sung together, in part of their singing. She found one song, "Canta de la Paz," that was used to settle a quarrel over a stolen piece of clothing.

She then programmed a synthesizer, a machine that makes musical sounds electronically, to play the notes, so people could hear how the songs sounded. Judy Daxootsu Ramos, a Tlingit from Yakutat, said of the old songs, "we're still practicing that today."

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 15 minutes**

Enslaved Black people in the South made songs that carried their own meanings, while white men in blackface copied Black music on stage and kept the money. The enslaved made their songs at work, at worship and on the days off their enslavers allowed, such as Christmas. Frederick Douglass later wrote down what the songs meant, and Harriet Tubman told a writer, Sarah Bradford, how she used hers.

**The minstrel show.** White performers darkened their faces with burnt cork and sang and danced as Black characters who were lazy, stupid, grinning fools. This blackface minstrel show became one of the most popular kinds of entertainment in the country. The money went to white performers and publishers. Stephen Foster, a white songwriter from Pittsburgh, wrote many of its best-known songs.

In Philadelphia a free Black bandleader, Francis Johnson, published more than 200 pieces of music. In the South, singers learned church music from books printed in shape notes, where the shape of each note shows the singer which sound to sing.

### What the singers said the songs meant

Frederick Douglass was enslaved in Maryland, on Colonel Edward Lloyd's plantation in Talbot County and later on William Freeland's farm. He escaped in 1838 and published the story of his life in 1845. In it he wrote that enslaved people sang as they walked to the main farm to collect their monthly food, making up the words as they went.

Some people in the North took such singing as a sign that enslaved people were happy. Douglass wrote that this was a mistake: "Slaves sing most when they are most unhappy." He added, "I have often sung to drown my sorrow, but seldom to express my happiness."

**"Make a noise."** Enslavers wanted to hear singing, Douglass wrote in a second book, in 1855. "A silent slave is not liked by masters or overseers," he wrote. When the workers went quiet, the words they heard were "Make a noise." Teamsters, the men who drove the wagons, sang so that the overseer, the man who drove enslaved people at their work, would know where they were and that the work was going on.

**A second meaning.** Douglass and five other enslaved men planned to escape together in 1836. As they planned, they kept singing a hymn about being "bound for the land of Canaan." In the Bible, Canaan is the land God promised to the people of Israel after they escaped from slavery in Egypt.

Douglass wrote, "the north was our Canaan." Someone betrayed the plan, and it failed. Douglass never found out who. In his book he named the five men: Henry Harris, John Harris, Sandy Jenkins, Charles Roberts and Henry Bailey.

**Juba.** At Christmas, enslaved people on the Maryland farms played fiddles and beat out rhythms on their own bodies with their hands, which was called "juba" beating. The singers made up the words of the juba songs as they went. Douglass wrote down one verse that begins "We raise de wheat, Dey gib us de corn." It goes on to list the work the enslaved people did and the scraps they were given for it.

**Tubman's signals.** Harriet Tubman escaped from slavery in Maryland in September 1849 and later went back to lead others north. She told the writer Sarah Bradford how she used hymns as signals. People hiding in the woods came out only after she walked past singing a certain hymn twice. If she sang "Moses go down in Egypt" instead, they stayed hidden, "for dere's danger in de way." Bradford printed Tubman's account in 1869.

**The "Drinking Gourd."** Douglass and Tubman describe songs with hidden meanings and songs used as signals. A different claim is that the song "Follow the Drinking Gourd" was a map that led people from Alabama north to the Ohio River. That claim comes from a single article printed in 1928 by H. B. Parks, a Texas scientist who studied insects and collected songs.

A folk singer, Lee Hays, wrote the best-known words of the song in 1947. The researcher Joel Bresler found that no one ever collected the song in Alabama. He also found no older use of "drinking gourd" to mean the Big Dipper, the group of stars that points to the North Star. Bresler and the scholar James Kelley doubt that the song was ever a map.

### Congo Square, New Orleans

Under a city law the mayor of New Orleans issued in 1817, enslaved people could gather in only one place: across Rampart Street at the back of town, on Sunday afternoons. The space was later called Congo Square. There enslaved people sold goods, sang, danced and played music. The architect Benjamin Latrobe wrote in his journal in 1819 of 500 to 600 enslaved people gathered there for dancing. He called the dancing "savage."

City officials stopped the Sunday music and dancing in 1835. It started again, and officials stopped it again in 1851. The records that survive do not give the names of the mayor who limited the gatherings or of the officials who stopped them.

### What was blackface minstrelsy?

Blackface minstrelsy was a stage show in which white men darkened their faces with burnt cork and acted as Black people. White audiences liked seeing Black people shown as "singing, dancing, grinning fools," David Pilgrim of the Jim Crow Museum at Ferris State University writes. He writes that these shows helped spread the belief that Black people were lazy, stupid and "inherently less human," meaning less human by birth.

**Jim Crow.** Thomas Dartmouth Rice was a white actor, born in New York in 1808. He sang and danced a song called "Jump Jim Crow" in blackface. Pilgrim dates his first performance as Jim Crow to 1828. Other accounts say only that it had become his main act by 1832, when a Philadelphia newspaper notice announced that "Mr. Rice will appear and sing Jim Crow."

**The man he copied.** Rice said he copied a disabled Black man who cared for horses and sang as he worked, and that he bought the man's clothes to wear on stage. People still argue about when and where this happened, and whether it happened at all. No record names that man. No record shows that he or any other Black musician was paid for what the minstrels copied.

Rice played to sold-out theaters from about 1832 to 1844, and he took the act to London in 1836. By 1838 people were using "Jim Crow" as an insult for Black people. By the end of the 1800s, "Jim Crow" was the name for the laws and customs that officials and lawmakers used against Black people. Under them, Black people were kept out of white schools, railroad cars and waiting rooms.

**The Virginia Minstrels.** Four white men performed in New York for a paying audience as the Virginia Minstrels on what was probably January 31, 1843. They were Dan Emmett, Billy Whitlock, Dick Pelham and Frank Brower. Earlier blackface acts had one singer or dancer. The Virginia Minstrels performed as a group, with fiddles, banjos, tambourines and the bones, a rhythm instrument.

A group led by Edwin P. Christy, the Christy Minstrels, started many of the features of the minstrel show from 1845. The players sat in a half circle. Two comic players called Mr. Tambo and Mr. Bones sat at the ends, and a leader called Mr. Interlocutor sat in the middle. The money went to the white performers and to the music publishers who printed their songs. Rice became rich, and he died poor in 1860.

### The banjo goes on stage

Enslaved Black people played the banjo, which came from West African instruments, in America from at least 1736. That was about a hundred years before any white man played it on a stage.

Joel Walker Sweeney, a white man born in 1810 in Appomattox County, Virginia, learned to play it from enslaved people there. He played the banjo on a stage in New York in April 1839, and he is the earliest known person to have done so. Four years later, two of the Virginia Minstrels played banjos in their show.

One story says that Sweeney added the banjo's short fifth string. No proof of that exists. Older banjos, and pictures made before his time, already show the short fifth string.

### Stephen Foster

> **Who:** A white songwriter who wrote songs for blackface minstrel shows and for singing at home, and one of the first Americans to earn a living only by writing songs.
>
> **When and where:** Born July 4, 1826, in Lawrenceville, Pennsylvania, now part of Pittsburgh. Worked in Pittsburgh, Cincinnati and New York. Died January 13, 1864, in New York.

**When he died, his wallet held 37 cents and three pennies.**

Stephen Foster wrote many of the best-known songs of the minstrel shows.

**Kitty.** Foster's family held a Black girl named Kitty as a bound servant, someone who had to work for a family without pay until a set number of years ran out. The writers of the University of Pittsburgh library's biography of Foster call this arrangement "enslavement in all but name."

Foster's father wrote in 1834 that a woman named Mrs. Collins had given the family the girl as "a present." The girl had more than three years left to serve. He wrote that it saved them the cost of hiring a girl.

**Learning the style.** At nine, Foster sang blackface songs such as "Jim Crow" in a boys' theater set up in a carriage house, and he was paid a small sum each week. He learned the style mostly from songs that white performers wrote to mock Black people. In 1846 and 1847 he kept the money records for his brother's shipping company in Cincinnati. The company made money from cotton picked by enslaved people in the South.

**"Oh! Susanna."** The song was first advertised in Pittsburgh in September 1847. Within a year the publisher William C. Peters printed it as one of the songs of the Sable Harmonists, a blackface group. At the time, no American song had sold more than 5,000 copies of its sheet music, the printed music people bought to play at home. "Oh! Susanna" sold more than 100,000. Its original second verse used a racist word for Black people and told, as comedy, of an explosion that killed 500 of them.

**Christy's name on the song.** The minstrel leader Edwin P. Christy paid Foster $10 a song from 1850 for the right to sing each new song first. For "Old Folks at Home" in 1851, Christy paid $15, and the sheet music named Christy as the writer. Foster asked in 1852 to have his own name put back. Christy refused.

That year Foster wrote to Christy about the words of his songs. He said he had made them suitable for "refined people," instead of the "trashy and really offensive words" of other minstrel songs. The University of Pittsburgh writers say he most likely did this to sell more sheet music.

**Politics.** His only openly political songs before the Civil War supported the Democrats who opposed ending slavery. One of them, "The Abolition Show" of 1856, attacked the people working to end slavery. Frederick Douglass, however, said in 1855 that songs such as "Old Kentucky Home" and "Uncle Ned" could make listeners feel for enslaved people.

**Selling the future.** In about 1857 Foster sold his rights to future payments on his songs, in return for money right away. He moved to New York in 1860 and kept writing, including more minstrel songs.

**His death.** In January 1864, while he was ill, Foster was badly cut on his neck and face in his hotel room. His writing partner, George Cooper, found him lying in a pool of blood, with what Cooper called "a cut in his throat." Foster died at Bellevue Hospital three days later, at 37. His wallet held 37 cents in paper money and three pennies.

**Disputed:** Biographers disagree about how he was cut. His brother Morrison wrote in 1896 that Stephen fainted and fell across the wash basin, which broke and cut him. Ken Emerson, writing in 1997, tells it as a fall onto a wash basin or a chamber pot, a bowl kept in the room for use as a toilet. JoAnne O'Connell argued in 2016, from Cooper's description of the wound, that Foster cut his own throat on purpose.

**The words today.** Other people later changed the words that are sung today. Two Kentucky lawmakers, Representative Carl Hines and Senator Georgia Davis Powers, won votes in 1986 to sing "people" in place of a racist word in "My Old Kentucky Home," the state song since 1928.

### Church songs: Richard Allen's hymn book and shape notes

Richard Allen, a Philadelphia minister who had been born enslaved, put together two hymn books in 1801, one of 54 hymns and one of 64. The books contain the words and no music. Allen formally organized the African Methodist Episcopal Church, a church run by Black Methodists, in 1816.

**Shape notes.** William Little and William Smith printed a music book called *The Easy Instructor* in Philadelphia in 1801, the same year as Allen's hymn books. Its music is written in shape notes: each note has one of four shapes, and each shape stands for one sound to sing. The book was made for singing schools.

**The Sacred Harp.** Two Georgia men, Benjamin Franklin White and Elisha J. King, published *The Sacred Harp* in 1844, a shape-note book of more than 250 songs. Some of its oldest songs are by William Billings, the Boston singing teacher of the late 1700s. By 1800 his tunes had mostly dropped out of use in Boston, but singers in the rural South kept them.

Sacred Harp singers sit in a square, facing inward, with an empty space in the middle, and they sing in four parts with no instruments. People still sing from the book, and a new edition was printed in 2025.

### Francis Johnson

> **Who:** A free Black bandleader, bugle player and composer in Philadelphia who published more than 200 pieces of music.
>
> **When and where:** Born June 16, 1792, in Philadelphia. Died there April 6, 1844.

**A congressman called him the "leader of the band at all balls."**

Francis Johnson led the band at Philadelphia's dances and balls, and he published more than 200 pieces of music. He was a free Black man. A church record in Philadelphia gives his birth date as June 16, 1792. Some books say he was born on the island of Martinique, but they give no evidence.

He grew up in a free Black neighborhood of Philadelphia. By 15 he could play the flute, the violin, the bugle and the piano. He played in taverns, then as the fiddler at the Exchange Coffee House.

**First in print.** A Philadelphia publisher, George Willig, printed his dance music. The writer Richard Grant, in *Smithsonian* magazine, dates the first piece to 1810 and calls it the first music published by a Black American. Other accounts date his first wide notice to a collection Willig printed in 1818. That year Robert Waln, a former congressman, wrote a book about Philadelphia that called Johnson the "leader of the band at all balls." Johnson played the keyed bugle, a brass horn with keys, and wrote dances, marches and songs.

**To England.** Johnson took his four-man band to England in November 1837. No Black American musician had taken a band to Europe before, Grant writes. Some accounts say Johnson played for Queen Victoria, and others say that has not been proven.

**Arrested in St. Louis.** Johnson and nine Black musicians toured eight states in 1842 and 1843. In St. Louis in December 1842, the band members were served with warrants, papers from a court that order an arrest. The charge was being "Free Negros within the State of Missouri without a license." Missouri law required free Black people to hold a license to be in the state.

The records do not name the officials who served the warrants. A firemen's club that had hired the band paid a lawyer. The judge closed the case without a ruling, and the band left.

**The mob.** In Allegheny City, Pennsylvania, a mob gathered outside the hall where the band played. The mob attacked the musicians in the street, threw stones, bricks and rotten eggs, and shouted racist insults. Several musicians were badly hurt. The band played the next night anyway. No record names anyone in the mob.

Johnson died on April 6, 1844, when a blood vessel near his heart burst. At his funeral his band played a funeral march he had written. One of the largest funeral crowds in Philadelphia's history came to it.

### The Hutchinson Family sing against slavery

The Hutchinson Family Singers were brothers from Milford, New Hampshire: John, Asa, Jesse and Judson Hutchinson. They gave their first concert in Milford on November 6, 1840. Their sister Abby joined them when she was about 12. In 1842 they earned up to $130 a concert.

**Songs against slavery.** From 1843 the Hutchinsons sang against slavery. In 1844 they set "Get Off the Track!" to the tune of a minstrel song, "Old Dan Tucker." A year later they toured Britain with Frederick Douglass.

**Philadelphia, 1847.** The Hutchinsons sang in Philadelphia in the spring of 1847 to audiences of Black and white people together. The city's mayor, John Swift, said more concerts would cause a riot. He ruled that no antislavery speech could be given at the hall and that no Black person could sit in the audience. The Hutchinsons refused to sing for a white audience only.

**If you remember one thing:** In these fifty years enslaved people's songs held meanings of their own, and the white men who copied Black music on the minstrel stage kept the money.

- 1817: The mayor of New Orleans limits enslaved people's Sunday gatherings to the place later called Congo Square.
- 1843: Four white men perform in New York as the Virginia Minstrels, the first blackface act built as a group.
- 1845: Frederick Douglass writes, "Slaves sing most when they are most unhappy."

**Next:** After 1850 the songs of slavery were printed for the first time, and freed Black students sang them for a president and a queen.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 18 minutes**

The songs of slavery reached print and the concert stage after the Civil War. Black singers carried them to audiences in America and Europe, while the officer who ran a boarding school for Native children set out to silence the children's drums. Three white Northerners printed the first book of spirituals, the religious songs that enslaved Black people had made, in 1867. Students at Fisk University, a school for freed Black people, sang those songs on tour to keep their school open.

That officer, at the Carlisle Indian School in Pennsylvania, gave the boys brass instruments to stop their drumming. The school's own paper said that as the band grew, the boys stopped singing their own songs. In the war itself, army bands played for soldiers on both sides, and bandsmen carried the wounded.

Singers recorded songs on wax cylinders from 1890. A wax cylinder was a tube of wax that held two or three minutes of sound, and a machine could play it back. Scott Joplin, a Black pianist in Missouri, published the "Maple Leaf Rag" in 1899, a piece of ragtime, piano music with a bouncing rhythm. In the South, Black farm workers were making the music later called the blues.

### Jenny Lind's tour, 1850 to 1852

The showman P. T. Barnum agreed in January 1850 to pay the Swedish singer Jenny Lind $1,000 a concert to tour the United States. She arrived in New York in September 1850, and Barnum sold tickets by auction. She sang 93 concerts for Barnum and earned about $350,000, while Barnum made at least $500,000. Lind gave her share to charities, most of it to free schools in Sweden.

### War songs and army bands, 1859 to 1865

Bryant's Minstrels, a white blackface group, first sang "Dixie" in New York on April 4, 1859. The song is credited to Dan Emmett, one of the Virginia Minstrels.

**Who wrote "Dixie"?** The accounts differ. Since the 1910s or 1920s, people in Mount Vernon, Ohio, have said that Emmett took the song from the Snowdens, a Black family of musicians in Knox County, Ohio. The writers Howard and Judith Sacks suggest it came from the parents of the family, Thomas and Ellen Snowden. Other scholars, such as E. Lawrence Abel, reject the Snowden story outright.

**A Confederate song.** In Charleston, South Carolina, in December 1860, a band played "Dixie" after each vote to leave the Union, as people then called the United States. A band played it in February 1861 when Jefferson Davis became president of the Confederacy, the group of Southern states that broke away from the United States.

**"Battle Hymn."** Union soldiers from Massachusetts made up the song "John Brown's Body" in 1861, about John Brown, who led an 1859 raid on Harpers Ferry, Virginia. They sang it to the tune of a hymn from camp meetings, big outdoor church gatherings.

Julia Ward Howe heard soldiers singing it near Washington, D.C., and in November 1861 she wrote new words to the same tune. She sold them for $4 to *The Atlantic Monthly*, a magazine. Its editors printed her "Battle Hymn of the Republic" on the front page in February 1862.

**Banned from the camps.** The Hutchinson Family sang a song against slavery to Union soldiers in Virginia in January 1862. Its words included "Let Slavery die!" Some of the soldiers booed. General George McClellan, who opposed using the war to end slavery, then banned the Hutchinsons from singing in the army camps.

**Bandsmen.** Under an army order of August 3, 1861, each Union regiment, one unit of soldiers, could have a band of 24 musicians. Members of Congress voted in July 1862 to send the regimental bands home. They kept one band for each brigade, a larger group of soldiers made up of several regiments.

Bandsmen also carried the wounded. Albert Mann, a bandsman from Massachusetts, wrote that the army surgeon taught the band to use "stretchers, bandages and tourniquets," bands tied tight around an arm or leg to stop heavy bleeding. The bandsmen were to go into battle with the regiment, "rescue the wounded, if possible, and carry them to the field hospital."

At the Battle of Gettysburg, fought from July 1 to 3, 1863, the bands of the 26th and 11th North Carolina regiments played while "heavy firing" went on, the 26th's band leader recalled. A British visitor heard a Confederate band play polkas and waltzes while cannon fired.

### Spirituals written down

Thomas Wentworth Higginson, a white abolitionist who worked to end slavery, commanded the 1st South Carolina Volunteers in 1862. The regiment was a Union unit of men who had been enslaved. A drummer boy in the regiment told Higginson about a hymn with the words "We'll soon be free." He said that enslaved people in Georgetown, South Carolina, had been whipped for singing it when Abraham Lincoln was elected in 1860.

**"De Lord."** The enslavers thought "de Lord" in the song meant the Yankees, the Northern soldiers, the boy said. In a later version of the story, Higginson wrote that the singers had been put in jail. Neither account names the drummer boy, the singers, or the people who punished them.

**The first book.** William Francis Allen, Lucy McKim Garrison and Charles Pickard Ware, three white Northerners, published *Slave Songs of the United States* in 1867. It contains 136 songs and was the first book of spirituals ever printed. Most of its songs came from Gullah Geechee people, Black people of the South Carolina islands, who lived on St. Helena Island and had been freed during the war.

### The Fisk Jubilee Singers, from 1871

Fisk University opened in Nashville, Tennessee, after the Civil War to teach freed Black people. By 1871 it was running out of money, and its classes met in old buildings of a Union army hospital. George White, a white church worker from the North, kept the school's money and led its music. He set out with nine students on a singing tour to raise money on October 6, 1871. Among them were Maggie Porter and Ella Sheppard.

At first they sang spirituals only as extra songs at the end of a concert. Audiences asked for more. George White named the group the Jubilee Singers, after the "year of jubilee" in the Bible, when slaves were set free.

**Hard roads.** After one early concert in Ohio, the singers gave their profit to the victims of the Chicago fire of October 1871. "We had thirty dollars and sent every penny to Chicago and didn't have anything for ourselves," Maggie Porter said. She also said, "There were many times, when we didn't have place to sleep or anything to eat."

Ella Sheppard wrote of "the ill treatment at hotels, on railroads, poorly attended concerts, and ridicule." George White and another man walked through sleet, snow and rain from hotel to hotel, looking for one that would take the singers in. The records do not name the hotels that turned them away.

**What they raised.** They sang for President Ulysses S. Grant at the White House in March 1872. By that spring they had raised the $20,000 that George White had promised. They sang for Queen Victoria in England in April 1873, and by May 1874 their total had reached nearly $50,000.

That money paid for Jubilee Hall, Fisk's first permanent building, which opened on January 1, 1876. It became a National Historic Landmark in 1975. Over seven years of touring, the singers raised about $150,000 in all.

### Ella Sheppard

> **Who:** Born into slavery, she became the pianist, arranger and assistant director of the Fisk Jubilee Singers.
>
> **When and where:** Born February 4, 1851, at the Hermitage, Andrew Jackson's plantation near Nashville, Tennessee. Toured the United States and Europe. Died in Nashville in 1914 or 1915 (the records differ).
>
> **Movie:** *Jubilee Singers: Sacrifice and Glory* (2000), a documentary about the group in the PBS series *American Experience*.

**"She is mine and she shall die mine," said her mother's enslaver.**

Ella Sheppard arranged most of the spirituals that the Fisk Jubilee Singers sang, writing out the parts for each voice. She was born into slavery at the Hermitage, Andrew Jackson's plantation near Nashville.

**Her mother.** Her father, Simon Sheppard, paid $1,800 to buy his own freedom, and then he bought Ella's. The woman who held Ella's mother, Sarah, refused to sell her. She said, "She is mine and she shall die mine. Let Simon get another wife." When Ella was three, her mother was sold to a plantation in Mississippi. Ella did not see her again until she was 15.

The records do not name the woman who held Sarah or the person who bought her. Her mother said, "My back was never struck, but my heart is like a checkerboard with its stripes of sorrow."

**Lessons through the back door.** After a riot in Nashville in 1856, white officials there made stricter rules for free Black people. Simon fell into debt and was afraid that his family would be seized and sold, so he took Ella to Cincinnati, Ohio. There a German woman taught her piano. A white teacher taught her in secret, at night, letting her in through the back door.

**To Fisk.** Her father died in 1866 of cholera, a gut infection that people catch from dirty food or water. It drains so much water from the body that a person can die. Ella taught music in Gallatin, Tennessee, and saved about $6 in five months. She entered Fisk in 1868. The money lasted three weeks, and she stayed by giving music lessons and washing dishes.

**With the singers.** On the first tour, in 1871, she sang with eight other students: Isaac Dickerson, Maggie Porter, Minnie Tate, Jennie Jackson, Benjamin Holmes, Thomas Rutling, Eliza Walker and Green Evans. She played piano, organ and guitar, arranged the spirituals for the group to sing in four parts, and collected more than a hundred songs.

On stage she led the singers from her place among them. In the summer of 1875 she wrote down the music of eight spirituals for a printed book of the group's songs, and the book did not name her.

She later wrote that the old songs "were sacred to our parents, who used them in their religious worship," and that at first the students did not want to sing them for strangers. In 1890 she trained a new group of Jubilee Singers at Fisk.

### Native songs, drums and the first recordings

The army officer Richard Henry Pratt opened the Carlisle Indian School in Pennsylvania, a boarding school for Native children, in 1879. Students came from 54 or more nations. Early in the school's history, a rule was made that students could not speak their own languages or practice "Indian customs." The school's paper does not say who made the rule.

**"Even in song."** An article in that paper, *The Red Man*, stated in 1896 that the school's aim was "the complete transformation of the Indians." It called any "display of savagery and barbarism, even in song and language," out of place in the school. Those were the paper's words for the students' own songs and languages. The article states that in the first year, the only music heard from the boys' rooms was the drum.

**Brass for drums.** Pratt told a Boston donor, Mrs. Walter Baker, that he wanted to stop the drumming. "If you will give me a set of brass band instruments I will give them to the 'tom tom' boys," he said, as the paper quotes him, and "this will stop the 'tom tom.'" The school band began in 1881.

The rule named languages and "Indian customs," but the same article states that "Indian singing was never prohibited" and that no order to stop the songs was ever given. As the band grew, the article says, the singers of those songs fell silent. Dennison Wheelock, an Oneida student who entered Carlisle in 1885, later led the school band.

**Dances made offenses.** Hiram Price, the federal Commissioner of Indian Affairs, issued rules on March 30, 1883, that made the Sun Dance and other religious dances "Indian offenses." His boss, Secretary of the Interior Henry Teller, had called Native dances "heathenish," an insulting word for not Christian. The rules named dances and feasts. They did not name songs. The punishment was the loss of rations, the food that federal officials handed out to Native people on reservations.

For a first offense, officials could hold back a person's rations for up to ten days, and for a later offense, 15 to 30 days. They could instead put the person in the agency prison, the jail at the government office on the reservation, for up to 30 days. Officials could enforce these rules until 1978.

**The first recordings.** The scientist Jesse Walter Fewkes recorded Passamaquoddy songs and stories on 36 wax cylinders in Calais, Maine, from March 15 to 18, 1890. The Passamaquoddy are a Native nation whose homeland is along the border between Maine and New Brunswick, in Canada. The singers were Peter Selmore, Newell Josephs and Peter Lacoute.

In a Library of Congress essay, Kelly Revak writes that these are "largely credited" as the first recordings of Native American music. Passamaquoddy speakers have used the recordings since the 1980s to bring old songs back. Wayne Newell said in 2009 that people were working on them at home "so we can sort of resurrect older songs."

**Wounded Knee.** Soldiers of the 7th Cavalry, an army unit on horseback, killed between 250 and 300 Lakota people at Wounded Knee on December 29, 1890, most of them women and children. The soldiers had been taking the guns of a Lakota band led by Spotted Elk. His people had taken up a religious movement called the Ghost Dance, whose followers danced in a circle, and the Ghost Dance had its own songs.

James Mooney, a scientist who studied Native peoples, recorded Ghost Dance songs in 1894. Library of Congress notes say the singer on those recordings is probably Mooney himself, not a Native singer.

### John Philip Sousa

> **Who:** Leader of the United States Marine Band and writer of more than 100 marches.
>
> **When and where:** Born November 6, 1854, in Washington, D.C. Led the Marine Band from 1880 to 1892, then his own band. Died March 6, 1932, in Reading, Pennsylvania.
>
> **Movie:** *Stars and Stripes Forever* (1952), a Hollywood film loosely based on his memoir.

**His father signed him into the Marines at 13.**

John Philip Sousa wrote more than 100 marches, including "The Stars and Stripes Forever," the national march of the United States. His father played in the Marine Band. When Sousa was 13, his father signed him into the Marine Corps as an apprentice musician, a boy learning the work. He did it to keep his son from joining a circus band. Sousa served seven years.

**The Marine Band.** Sousa became the 17th leader of the Marine Band on October 1, 1880. He led it for 12 years under five presidents, from Rutherford B. Hayes to Benjamin Harrison. In 1892 he formed a band of his own.

**The march.** Sousa was on a ship crossing the Atlantic on Christmas Day 1896. He had just learned that his band's manager, David Blakely, had died. On that voyage he began "The Stars and Stripes Forever," and he finished it in April 1897. Members of Congress voted in 1987 to make it the national march. Sousa also wrote 15 operettas, short comic operas, and he helped develop the sousaphone, a large brass horn made for marching bands.

### Recording begins

Thomas Edison's workers built his first phonograph, a machine that recorded sound and played it back, in December 1877. Machines good enough to sell came on the market in 1888.

**George W. Johnson.** In 1890 two phonograph companies paid George W. Johnson 20 cents for each two-minute song he recorded on a wax cylinder. Johnson was a Black street whistler, born in Virginia in 1846. The cylinders played in coin-operated machines. No way yet existed to copy a cylinder in large numbers, so Johnson sang the same songs over and over, one cylinder at a time. Between 1890 and 1895 he made an estimated 25,000 to 50,000 cylinders.

His two best sellers were "The Laughing Song," which he wrote, and a whistling song by a white writer that mocked Black people. The title of that song used a racist insult for a Black person. "The Laughing Song" was the best-selling record in the country for ten weeks in 1891, and Johnson is counted as the first Black recording star.

**What became of him.** Johnson was put on trial in 1899 for the murder of Roskin Stuart, the woman he lived with as his wife, who had been found beaten in their apartment. He was found not guilty. By 1905 record makers could press many copies from one recording, so they no longer needed him to sing each copy. His friend Len Spencer hired him as a doorman for his office. Johnson died in 1914 and was buried in a grave without a marker.

### Ragtime, and songs that mocked Black people

Ragtime is music with a "ragged" rhythm: the tune lands between the beats while a steady beat keeps time underneath. On the piano, the left hand keeps the steady beat and the right hand plays the tune. Ragtime began among African Americans in the late 1800s. Accounts differ about the first printed ragtime piece, and they date it to 1895 or 1897.

Ernest Hogan, a Black performer from Bowling Green, Kentucky, who had started out in minstrel shows, wrote a hit song in 1895 and 1896 whose title used a racist insult for Black people. The title said that all Black people look alike. Many other writers copied it. People at the time named these copies after the insult. They were songs that used racist words and pictures to mock Black people.

### Scott Joplin

> **Who:** A Black composer and pianist who wrote the "Maple Leaf Rag" and an opera, *Treemonisha*.
>
> **When and where:** Born in northeastern Texas between mid-1867 and early 1868 (the date is not known for certain). Lived in Texarkana, Sedalia and St. Louis, Missouri, and New York. Died April 1, 1917, in New York.

**His most famous rag earned him about $4 in its first year.**

Scott Joplin wrote the "Maple Leaf Rag," and in his last years he paid to print his own opera. He was born in northeastern Texas, and the exact date is not known. The historian Edward A. Berlin places it between June 1867 and the middle of January 1868.

His father, Giles, had been enslaved in North Carolina. His mother, Florence, was born free in Kentucky. She cleaned houses, and Scott learned to play on her employer's piano. A teacher, Julius Weiss, gave him lessons.

**Finding work.** Churches and brothels, houses where men paid women for sex, were among the few places where a Black pianist could find steady work. In 1891 he was a member of the Texarkana Minstrels, a group raising money for a monument to Jefferson Davis, the former president of the Confederacy. He moved to Sedalia, Missouri, in 1894. There he played the cornet, a brass horn like a small trumpet, in a town band and studied music at George R. Smith College.

**One cent a copy.** Joplin signed a contract on August 10, 1899, with John Stark, a Sedalia music store owner and publisher, to publish the "Maple Leaf Rag." Joplin was to get one cent for each copy sold. His first biographer said it sold 75,000 copies in six months. Berlin later found that the first 400 copies took a year to sell, which paid Joplin about $4. Later sales gave him a small, steady income. Berlin found that by 1909 they would have paid him about $600 a year.

**Treemonisha.** He moved to St. Louis in 1901 and to New York in 1907. He wrote an opera, *Treemonisha*, set on a Texas plantation after the Civil War. It tells of a young, educated Black woman who helps free her people from ignorance and superstition. No one would pay to stage it. In 1911 he printed it with his own money. In 1915 he played it in a hall in Harlem, with only a piano.

**His death.** By 1916 Joplin had syphilis in its late stage. Syphilis is a disease passed from person to person during sex. Without treatment it can spread to the brain, where it causes confusion, changes in personality and dementia, the loss of memory and of the ability to think.

He was admitted on February 2, 1917, to Manhattan State Hospital, a hospital for mental illness. He died there of the disease on April 1, 1917. No record describes how he was treated there. He was buried in a grave with no marker.

*Treemonisha* was first fully staged in January 1972, in Atlanta. His grave was given a marker in 1974, 57 years after his burial. In 1976, 59 years after he died, Joplin won a Pulitzer Prize, a top American award.

### The blues begins, and nobody wrote it down

The blues is a kind of Black music from the South. It grew out of the songs and calls that enslaved people sang as they worked in the fields, and out of the songs of Black workers on farms, docks and river boats after slavery ended. Writers on the blues place its beginning between 1870 and 1900.

**Sharecropping.** In those years, freed Black families in the South who had no land of their own farmed a landowner's fields in return for a share of the crop. This was called sharecropping. The families bought tools, seed and food on credit at the landowner's store prices. The debt rolled over from year to year, and families who owed it could not leave the land.

No written description of the blues from before 1900 is known. The first written accounts come from just after 1900.

**Not known:** No one knows who first played the blues, or when.

**If you remember one thing:** The songs of slavery were written down and sung across America and Europe in these fifty years, and music could now be recorded and sold.

In 1850: No book of spirituals had ever been printed, and the people who made them were still enslaved.

In 1900: *Slave Songs of the United States* was in print, the Fisk Jubilee Singers had sung for a president and a queen, and a Black whistler, George W. Johnson, had made the best-selling record in the country.

**Next:** After 1900 record companies began to record the blues and jazz, and the fight over who was paid moved into the recording studio.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 27 minutes**

Record companies began to record and sell the blues, jazz and country music in these years, and the companies and the men who held the copyrights kept much of the money. Black musicians in the South made the blues and jazz. Country music came from Southern singers and players, white ones like the Carter Family and Black ones like DeFord Bailey and Lesley Riddle. Bessie Smith's first record sold 780,000 copies, and Columbia paid her a set fee and no share of the sales.

Americans spent $106 million on records in 1921. From the 1920s, anyone with a radio could hear music at home for free. Owners and managers of clubs, hotels and concert halls kept Black people out, even Black stars. Billie Holiday recorded "Strange Fruit" in 1939, a song about Black people murdered by white mobs. That same year Marian Anderson sang outdoors in Washington to more than 75,000 people, after the leaders of two indoor halls in the city refused her.

### The first written accounts of the blues, 1901 to 1903

The first written account of the kind of songs later called the blues comes from Mississippi in 1901 and 1902. Charles Peabody, an archaeologist, dug into a Native mound in Coahoma County in May and June of both years for Harvard University's Peabody Museum. He hired nine to fifteen Black men from the town of Clarksdale to do the digging, and the men sang while they dug. Peabody wrote in 1903 that bosses sometimes hired a strong singer just to keep workers going.

The men's songs were about hard luck, love and pay day. In one line the singer said he had been arrested for murder though he had never harmed anyone. Peabody did not use the word blues.

**Tutwiler.** The bandleader W. C. Handy was waiting for a train at Tutwiler, Mississippi, in about 1903. A man beside him played a guitar by sliding a knife along the strings, and sang. No record names the man. Handy later published the song as "Yellow Dog Blues."

**"Father of the Blues."** Handy sold "The Memphis Blues" for $100 in 1912, and in 1914 he published "Saint Louis Blues." With Harry Pace, a Black banker, he ran a company called Pace and Handy that published music. Handy called himself the "Father of the Blues." Jelly Roll Morton disagreed. In a letter to the magazine *Down Beat*, he wrote that Handy had not started the music.

**"Mother of the Blues."** The singer Gertrude "Ma" Rainey said that in 1902 a girl in Missouri sang her a song about a man who had left a woman. Rainey began singing it in her shows. Paramount Records later advertised her as the "Mother of the Blues." Between 1923 and 1928 she made more than 100 records.

### Records for Black buyers, and who was paid, 1920 to 1938

Mamie Smith, a Black singer, recorded "Crazy Blues" for the Okeh record company on August 10, 1920. The songwriter Perry Bradford wrote it. Managers at Victor had turned Smith down after a try-out, so Bradford went to Fred Hager, who ran recording at Okeh. He told Hager that Smith could "do more with those songs than a monkey can do with a peanut."

Some white people had already warned Hager not to record Black musicians, and he recorded her anyway. Within two months, buyers had paid a dollar each for 75,000 copies. It was the first blues record to become a big hit.

**"Race records."** Record company managers then went looking for Black singers to sell records to Black buyers. By 1922 managers at Okeh were calling these records "race records." The Black businessman Harry Pace started Black Swan Records in 1921. Black Swan paid its singers fair wages and let them record under their own names. Paramount took over Black Swan in 1924.

**A set fee.** Columbia paid Bessie Smith a set fee for each side she recorded. A side was one song on one face of a record. She got no royalty, the small payment for every copy sold that lasts as long as the record sells. Columbia paid white singers more, and it paid them royalties. With a set fee, a singer earned the same whether the record sold a hundred copies or a million.

**Twenty-nine songs.** Robert Johnson, a Black guitarist from Mississippi, recorded 29 songs in 1936 and 1937, in a hotel room in San Antonio and in Dallas, both in Texas. His best seller, "Terraplane Blues," sold about 10,000 copies. His pay for the sessions is not on record. He died near Greenwood, Mississippi, on August 16, 1938, at 27. The cause of his death is not known. One story says he was poisoned, but no one has proved it.

Mississippi judges ruled in 1998 that his son, Claud Johnson, was his only heir, the one person with the right to what Johnson left. That right was worth more than $1 million in royalties.

The editors of *Billboard*, a music magazine, renamed its "race records" sales chart "rhythm and blues" in June 1949. A writer named Jerry Wexler suggested the new name.

### Bessie Smith

> **Who:** A Black blues singer whose first record sold 780,000 copies in six months.
>
> **When and where:** Born in Chattanooga, Tennessee, on April 15, 1894 (the 1900 government count of the people gives July 1892). Recorded for Columbia Records from 1923. Died near Clarksdale, Mississippi, on September 26, 1937.
>
> **Movie:** *Bessie* (2015), an HBO drama film, with Queen Latifah as Smith.

**Her first record sold 780,000 copies. She got $125 a side.**

Bessie Smith was born in Chattanooga, Tennessee. Her family kept April 15, 1894, as her birthday, but the 1900 census, the government's count of everyone in the country, gives July 1892. Both her parents died when she was a child. She and her brother Andrew sang and danced for coins on the streets of Chattanooga. In 1912 she joined a traveling show as a dancer, and Ma Rainey sang in the same show.

**The pay.** Frank Walker of Columbia Records signed her in 1923. Her first record, "Down Hearted Blues," sold 780,000 copies in six months. Her contract paid her $125 for each side that could be used. Later contracts paid $150 and then $200 a side, and none of them paid a royalty.

She recorded between 150 and 200 songs. Cary O'Dell's essay for the Library of Congress states 150 in one place and close to 200 in another. On tour she earned up to $2,000 a week, and she traveled in her own railroad car.

**The crash.** The car she rode in hit the back of a slow truck on Route 61 near Clarksdale, Mississippi, on September 26, 1937. Her partner, Richard Morgan, was driving. Her right arm was almost torn off at the elbow. A white doctor from Memphis, Hugh Smith, stopped to help. An ambulance took her to the G. T. Thomas Afro-American Hospital in Clarksdale. Doctors there amputated her arm, which means they cut it off, and she died that morning.

**A story that was not true.** The record producer John Hammond wrote in 1937 that she died because a white hospital refused to treat her. Dr. Smith said the ambulance would never have taken her to a white hospital. Her biographer, Chris Albertson, showed that Hammond's story was a myth.

More than 10,000 people came to her funeral in Philadelphia. Her grave had no stone for more than 30 years, until the singer Janis Joplin helped pay for one. Later Jack Gee Jr., the son of her husband, sued Columbia. The judges ruled against him because he had waited too long to sue. They did not decide whether she had been cheated.

### Jazz on record, 1917 to 1931

Jazz began in the Black communities of New Orleans in the late 1800s and early 1900s, but white musicians made the first jazz record. Five white musicians from New Orleans recorded two songs in New York for the Victor company on February 26, 1917. They called themselves the Original Dixieland Jass Band. Victor's managers put the record on sale in May 1917, and by some counts it sold more than a million copies. The band's leader, Nick LaRocca, later claimed that he had invented jazz.

**A legend.** One story says that in 1915 Victor had asked a Black New Orleans player of the cornet, a brass horn like a small trumpet, to record first. The player was Freddie Keppard, and the story says he said no. The historian John Edward Hasse calls that story a legend.

**The Cotton Club.** Owney Madden, a gangster who sold illegal liquor, ran the Cotton Club in Harlem, New York. Madden's managers hired Black musicians and dancers, and they let in only white customers, apart from a few Black stars. The club's dancers had to be light-skinned, at least 5 feet 6 inches tall and under 21. Duke Ellington's band played there from December 4, 1927, to June 30, 1931. When Ellington asked, the people running the club let in a few more Black customers.

**By 1927:** Blues records by Black singers sold in the hundreds of thousands, and the first jazz record, made by white musicians, had sold a million copies by some counts.

### Louis Armstrong

> **Who:** A Black trumpet player and singer from New Orleans who made jazz records with his Hot Five and Hot Seven.
>
> **When and where:** Born in New Orleans. Most sources give August 4, 1901. He often said July 4, 1900. Lived in Chicago and New York. Died in New York on July 6, 1971.
>
> **Movie:** *Louis Armstrong's Black & Blues* (2022), a documentary about him.

**"The government can go to hell," he told a reporter in 1957.**

Louis Armstrong learned to play the cornet in a home for Black boys in New Orleans, where a judge sent him after an arrest. On New Year's Eve 1912 he fired his stepfather's gun into the air. It was loaded with a blank, a shell with gunpowder but no bullet. Police arrested him, and the next day a judge sent him to the Colored Waif's Home, a reform home for Black boys. There a teacher, Peter Davis, taught him the cornet in the home's band.

**Hot Five, Hot Seven.** The bandleader King Oliver invited him to Chicago in 1922 to play second cornet in his band. From November 1925 Armstrong made records for Okeh with his own groups, the Hot Five and the Hot Seven.

**Little Rock.** A reporter in Grand Forks, North Dakota, asked Armstrong on September 17, 1957, about the fight over nine Black students entering Central High School in Little Rock, Arkansas. Armstrong said: "The way they are treating my people in the South, the government can go to hell." He called President Dwight Eisenhower "two faced" and said he had "no guts."

Staff at WBKJ, a radio station in Hattiesburg, Mississippi, threw out his records. Officials at the University of Arkansas cancelled his invitation to play a dance. The congressman Adam Clayton Powell said Armstrong "didn't know what he was talking about." On September 24 Eisenhower sent soldiers to protect the students. Armstrong then sent him a telegram: "If you decide to walk into the schools with the little colored kids, take me along Daddy. God bless you."

### Country music on record: Bristol, 1927

Ralph Peer of the Victor record company recorded 76 songs by 19 singers and groups in Bristol, Tennessee, from July 25 to August 5, 1927. He set up on the third floor of a hat and glove company's building. Each performer got $50 in cash for each side, plus 2½ cents for each record sold. The Carter Family recorded on August 1 and 2, and a singer named Jimmie Rodgers on August 4.

**What Peer kept.** Peer took no salary from Victor. Instead he took a royalty of one cent on each record side, which he split with the singer. He also kept the copyright of the songs he recorded, including old songs passed down from singer to singer, and with it the right to be paid whenever those songs were printed, recorded or played.

Peer started a company in 1928, Southern Music Publishing, to collect that money. He offered to publish the songs that A. P. Carter of the Carter Family had gathered, if Carter would claim that he wrote them.

### Maybelle Carter

> **Who:** Guitarist and singer in the Carter Family, who changed how the guitar is played in country music.
>
> **When and where:** Born May 10, 1909, in Nickelsville, Virginia. Recorded at Bristol, Tennessee, in 1927, at 18. Died October 23, 1978, in Hendersonville, Tennessee.
>
> **Movie:** *The Carter Family: Will the Circle Be Unbroken* (2005), a PBS *American Experience* documentary about the family.

**Her thumb played the tune, and one finger kept the rhythm.**

Maybelle Carter found a way to play the guitar that made it a lead instrument in country music. She picked out the tune with her thumb on the three low strings and strummed the three high strings with her index finger to keep the rhythm. It is called the thumb-lead style. She first recorded "Wildwood Flower," played this way, in 1928.

She sang and played with Sara Carter and A. P. Carter as the Carter Family. At Bristol in August 1927 she was 18. The Carter Family was paid Victor's rate of $50 a side and 2½ cents for each record sold.

**Lesley Riddle.** A. P. Carter went looking for old songs from December 1928 with Lesley Riddle, a Black guitarist from Burnsville, North Carolina. Riddle had lost his right leg at the knee in 1927 after an accident at a cement plant. On their trips, Carter wrote down the words while Riddle memorized the tunes. Riddle lived with the Carters for a time and taught Maybelle his finger-picking blues guitar style. Maybelle said she learned guitar runs from him, including the ones she played in "Cannonball Blues."

No record shows that Riddle was paid, or named as a writer, for any of the songs he helped gather.

Later Maybelle led a group with her daughters, called Mother Maybelle and the Carter Sisters. From 1968 she toured with her son-in-law, the singer Johnny Cash.

### How did the Grand Ole Opry get its name?

George D. Hay named the Grand Ole Opry on the air on December 10, 1927, right after a Black harmonica player, DeFord Bailey, played his "Pan American Blues." Hay had started the show on November 28, 1925, on WSM, a Nashville radio station owned by the National Life and Accident Insurance Company. He first called it the *WSM Barn Dance*. The first player was a 77-year-old fiddler, Uncle Jimmy Thompson.

That December night the *Barn Dance* came on the air after a program of opera music. After Bailey played, Hay told listeners, "from now on, we will present 'The Grand Ole Opry.'" One hour of the show went out across the country on the NBC radio network from 1939 to 1956.

### DeFord Bailey

> **Who:** A Black harmonica player, for fifteen years one of the best-loved stars of the Grand Ole Opry.
>
> **When and where:** Born December 14, 1899, in Smith County, Tennessee. Played on Nashville radio from 1926 to 1941. Died July 2, 1982.
>
> **Movie:** *DeFord Bailey: A Legend Lost* (2002), a Nashville Public Television documentary about him.

**White stars got him into hotels by the fire escape.**

DeFord Bailey's family in Smith County, Tennessee, played what he called "Black hillbilly music." He caught polio at three. The virus that causes polio can damage the nerves that move the muscles, and it stunted Bailey's growth and left his back bent.

**The pay.** He played on the *WSM Barn Dance* from June 1926. Accounts of his pay differ. One says he got a fixed $5 at first, less than the white players he toured with. The Country Music Hall of Fame says he was one of the best-paid stars on the show.

**On tour.** He toured the South with white stars such as Roy Acuff, Bill Monroe and Uncle Dave Macon. Hotel and restaurant owners would not serve him because he was Black. The other players brought him food, or got him into hotels by the fire escape.

**Fired.** The managers of most radio stations stopped playing songs licensed by ASCAP, a group that collected money for songwriters, during a fight over fees in 1941. Managers at WSM told Bailey not to play his ASCAP songs, which were some of his most popular ones. They fired him at the end of 1941.

**"Lazy."** Hay wrote a book about the show in 1945. In it he wrote, "Like some members of his race and other races, DeFord was lazy." Hay added that Bailey knew about a dozen tunes and "refused to learn more."

The historian Charles Wolfe reported in 1999 that Bailey remembered it the other way around. Bailey said he wanted to play new tunes, but Hay and the listeners kept asking for the same ones. Bailey also said that Hay had treated him kindly and had written those words to please his bosses.

Bailey ran a shoeshine stand and rented out rooms after 1941. He almost never played in public again until 1974. In 2005 he was named to the Country Music Hall of Fame.

### Radio, the Depression and two fights over pay, 1906 to 1944

John Philip Sousa wrote in 1906 that records and player pianos were becoming a "substitute for human skill, intelligence and soul." He called records "canned music." Members of Congress passed a copyright law in 1909 that let anyone record a song without asking, as long as they paid the song's owner a set fee.

**Sales up and down.** Americans spent $106 million on records in 1921. A history of records from the University of Michigan Press says they did not spend that much again until 1945. IASA, a group of sound archivists, says sales did not reach their old peak until the 1950s. During the Great Depression, in the early 1930s, record sales fell to about one tenth of what they had been in the 1920s.

**ASCAP and BMI.** Radio station owners paid ASCAP a fee for the right to play songs by its songwriters, and ASCAP passed the money on to the writers. When ASCAP's leaders announced a big rise in fees in 1939, radio station owners started a group of their own, BMI, so they would have songs to play without paying ASCAP.

Managers at almost every station, and at all three national networks, stopped playing ASCAP songs in 1941. ASCAP's leaders had not wanted writers of blues, gospel, country, folk and Latin music, and BMI became the first such group to sign them.

**The record ban.** James Petrillo, the head of the musicians' union, told its members to stop making records on August 1, 1942. He wanted musicians to be paid when radio stations and jukeboxes played records instead of hiring live bands. Decca's managers signed an agreement in September 1943 to pay a fee on every record into a union fund. Victor and Columbia signed on November 11, 1944. Union rules still let singers record with voices alone, so for two years singers made records without bands.

### Gospel, shape notes and prison recordings

Gospel is a kind of Black church music. Thomas A. Dorsey had played piano for Ma Rainey under the name "Georgia Tom." His wife, Nettie, and their newborn son died in August 1932, and he wrote "Take My Hand, Precious Lord." That year he started the first Black-owned company to publish gospel music, and in 1933 a national convention of gospel choirs. He led the music at Pilgrim Baptist Church in Chicago for fifty years. "I'm not ashamed of my blues," he said. "It's all the same talent."

**Mahalia Jackson.** She came to Chicago from New Orleans in 1927, and Dorsey trained her. She refused to sing the blues. Managers at Decca offered to keep recording her if she sang blues, and she refused. Her "Move On Up a Little Higher" of 1947 sold about two million copies.

**The Colored Sacred Harp.** Judge Jackson, a shape-note singer from Alabama, printed *The Colored Sacred Harp* in 1934. Judge was his first name, and "Colored" in the title was a word of that time for Black people. It was a book of 77 church songs printed in shape notes, notes whose shapes tell the singer which sound to sing. Eighteen of the songs were his own. He and Bishop J. D. Walker paid to print 1,000 copies, and Jackson sold them door to door.

**Lead Belly.** John Lomax and his son Alan recorded singers in Southern prisons from June 1933. John Lomax said he wanted music "not yet influenced by jazz and the radio." From 1934 he ran the Library of Congress's folk song collection, for a salary of one dollar. At Angola, the Louisiana state prison, they recorded Huddie Ledbetter, called Lead Belly. He was serving time for stabbing a man in a fight.

Years before, Lead Belly had been convicted in Texas of killing a relative, Will Stafford. He was in prison there from 1918 until the governor of Texas, Pat Neff, pardoned him in 1925, after Lead Belly sang him a song asking to be freed. He left Angola on August 1, 1934. A prison official later wrote that his singing had nothing to do with that release.

**"Goodnight, Irene."** John Lomax then managed Lead Belly and took a share of his pay. The two men split over money in 1935. Lomax published a book in 1936 that printed Lead Belly's song "Goodnight, Irene" with both men named as its writers. Lomax had recorded the song. He had not written it. A group called the Weavers sold 2 million copies of "Goodnight, Irene" in 1950, the year after Lead Belly died.

### The Carlisle band and Native songs on wax

The band of the Carlisle Indian School, a boarding school for Native children in Pennsylvania, played the "Aboriginal Suite" at Carnegie Hall in New York on March 28, 1900. Its composer and conductor was Dennison Wheelock, an Oneida graduate of the school. Richard Henry Pratt had made him the Carlisle bandmaster in 1892, the first Native bandmaster there. Wheelock later became a lawyer and argued cases for Native nations before the Supreme Court.

**Songs on wax.** Scientists recorded thousands of Native songs in these years on wax cylinders, tubes of wax that each held two or three minutes of sound. The Library of Congress holds about 10,000 cylinders, and nearly 8,000 of them hold Native songs and speech. Many held sacred songs meant only for ceremonies.

One collector, Francis La Flesche, took singers from Oklahoma to Washington, D.C., so that neighbors who objected could not stop him from recording ceremonial songs. No record shows that the singers were paid. Frances Densmore recorded the songs of the Ojibwe, Sioux, Mandan, Hidatsa, Tohono O'odham, Seminole and other nations for the Smithsonian Institution from 1907.

### The Hawaiian steel guitar

Joseph Kekuku, a Hawaiian student at the Kamehameha School for Boys, found in 1889 that he could change a guitar's pitch by sliding a steel bar along the strings. From 1904 he played his steel guitar in theaters across the mainland United States.

By then Hawaii belonged to the United States. A group of mostly American businessmen had overthrown Hawaii's queen, Liliʻuokalani, in 1893. Before they moved, John L. Stevens, the top US official in Hawaii, had 162 American sailors and Marines brought ashore. Native Hawaiians put 21,269 signatures on petitions, written requests to the government, against joining the United States in 1897. Members of Congress voted to annex Hawaii anyway in 1898, making it part of the United States.

### Irving Berlin, who owned his songs

Irving Berlin, born Israel Beilin, came to New York from the Russian Empire in 1893, at age five. He could not read music and could play the piano in only one key, and he wrote "Alexander's Ragtime Band" in 1911. Through his own publishing company he owned his own songs. He gave all the money from "God Bless America," which Kate Smith first sang in 1938, to the Boy Scouts and Girl Scouts.

**By 1939:** Anyone with a radio could hear music at home for free, and record sales were still below their 1921 peak. That year one hour of the Grand Ole Opry began going out across the country on NBC.

### Woody Guthrie

> **Who:** A folk singer and songwriter who wrote about poor farm families, workers and migrants in the 1930s and 1940s.
>
> **When and where:** Born July 14, 1912, in Okemah, Oklahoma. Lived in Oklahoma, California and New York. Died October 3, 1967, in New York.
>
> **Movie:** *Bound for Glory* (1976), a Hollywood film based loosely on his own book about his life.

**On his guitar he wrote "This machine kills fascists."**

Woody Guthrie wrote "This Land Is Your Land" and many other songs about poor farm families and workers. His mother, Nora, had Huntington's disease and was put in a hospital. No account names who sent her there. Huntington's is a disease passed down in families that destroys parts of the brain. A person with it makes movements they cannot control, has changes in mood, and loses the ability to think.

**The Dust Bowl.** In the 1930s Guthrie joined the farm families who left the Great Plains for California after years of drought, the time called the Dust Bowl. He sang on a Los Angeles radio station, KFVD. In 1940 he made an album called *Dust Bowl Ballads* for Victor.

**An answer to Berlin.** He wrote "This Land Is Your Land" in a New York hotel on February 23, 1940, as an answer to Irving Berlin's "God Bless America," which Kate Smith sang on the radio. His first title was "God Blessed America for Me." His handwritten copy had two verses that were often left out later. One is about a sign that says "No Trespassing." The other is about hungry people at a relief office, a place that gave out food or money to the poor.

**Twenty-six songs in a month.** Paul Raver, the head of a federal agency called the Bonneville Power Administration, hired him for one month in May 1941 for $266. Guthrie's boss there, Stephen Kahn, wanted three pages of songs a day for a film about the agency's dams on the Columbia River. Guthrie wrote 26 songs in that month. One of them was "Roll On, Columbia." Kahn later said the government had never gotten "a better investment on its money."

**His last years.** The fascists of his guitar's slogan were the followers of the dictators who ruled Italy and Germany. In the Second World War he served in the Merchant Marine, the ships that carried supplies. Doctors found in 1952 that he had Huntington's disease. He spent his last years in hospitals in New Jersey and New York, and he died at Creedmoor hospital in New York in 1967, at 55.

### Strange Fruit, 1939

"Strange Fruit" is a song about the lynching of Black Americans. Lynching means a mob killing a person without a trial, often by hanging. The song describes the bodies of Black people hanging from trees in the South: their bulging eyes and twisted mouths, and the smell of burning flesh.

Abel Meeropol, an English teacher in the Bronx, New York, wrote the song under the name Lewis Allan. He wrote it after he saw a photograph of the lynching of Thomas Shipp and Abram Smith in Marion, Indiana.

**Marion, Indiana.** A white mob of between 5,000 and 10,000 people broke into the jail in Marion on August 7, 1930. The mob wanted three young Black men held there for the murder of a white man, Claude Deeter, and the rape of a woman, Mary Ball. Rape means forcing a person to have sex. Men in the mob beat Shipp and Smith, who were both 19, and hanged them. People in the crowd took parts of their bodies as souvenirs.

**James Cameron.** The third prisoner, James Cameron, who was 16, was beaten but lived, after someone in the crowd said he was innocent. Cameron waited about a year in jail for his trial, and accounts of what Mary Ball said there differ. The historian James H. Madison writes that she said she had been raped but that the night was too dark to tell whether Cameron was one of the men. Fran Kaplan of America's Black Holocaust Museum writes that Ball testified she had not been raped at all.

Cameron was convicted on a lesser charge, of helping before the crime, and a judge sentenced him to 2 to 21 years. He served four years in prison. The governor of Indiana pardoned him in 1993.

**The trials.** Leaders of the NAACP, a group that fights for the rights of Black Americans, named 27 people they suspected of the lynching. All-white juries found the mob's leaders not guilty.

**Café Society.** Billie Holiday first sang "Strange Fruit" at Café Society, a club in New York, in 1939, and she closed her show with it. The waiters stopped serving, the room went dark except for a light on her face, and she sang no more songs after it. Managers at Columbia would not record it. John Hammond of Columbia said record stores and radio stations in the South would object. Milt Gabler of Commodore Records recorded it on April 20, 1939. It became her best-selling record.

### Billie Holiday

> **Who:** A Black jazz singer who recorded "Strange Fruit," a song about lynching, in 1939.
>
> **When and where:** Born Eleanora Fagan on April 7, 1915, in Philadelphia. Grew up in Baltimore. Sang in New York. Died July 17, 1959, in New York.
>
> **Movie:** *Billie* (2019), a documentary about her.

**Federal agents handcuffed her to her hospital bed as she was dying.**

Billie Holiday was a Black jazz singer whom federal drug agents arrested three times, the last time in her hospital bed. She was born Eleanora Fagan in Philadelphia and grew up in Baltimore.

At nine she was brought before a juvenile court, a court for children, for missing school. The judge sent her to the House of the Good Shepherd, a Catholic reform school for girls, where courts sent children who were in trouble. As a young girl she ran errands in a brothel, a house where men paid women for sex, and she scrubbed steps and floors in the homes of her neighborhood.

**The service elevator.** She sang with Artie Shaw's band in 1938, and its other members were white. At the Lincoln Hotel in New York, the managers made her use the service elevator because white guests complained. She left the band soon after.

**Anslinger's agents.** Harry Anslinger ran the Federal Bureau of Narcotics, the government's drug police, from 1930 to 1962. Federal agents arrested Holiday on May 16, 1947, for having narcotics, illegal drugs, in her New York apartment. She pleaded guilty, and a judge sent her to the Alderson Federal Prison Camp in West Virginia for a year. She said later: "It was called 'The United States of America versus Billie Holiday'. And that's just the way it felt."

Because of the conviction, she lost her New York City cabaret card, the police license a performer needed to work in any club that sold alcohol. After that she sang in concert halls and theaters. A federal agent named George White, a different man from the Fisk Jubilee Singers' leader, arrested her again in a San Francisco hotel in January 1949.

**Disputed:** No source before 2015 says that Anslinger's agents went after her because she sang "Strange Fruit," the jazz writer Lewis Porter points out. The writer Johann Hari wrote in 2015 that they did, from 1939.

**Her last arrest.** She was in Metropolitan Hospital in New York with liver and heart disease in 1959. Federal narcotics agents arrested her in her hospital bed on May 31 and handcuffed her to it. Writing in *TIME* in 2019, John Halpern and David Blistein said that Anslinger ordered the arrest. Police guarded her room until a judge ordered the handcuffs taken off. She died there on July 17, 1959, at 44, with 70 cents in the bank. Her liver was scarred, a disease called cirrhosis, and her heart failed.

### Marian Anderson at the Lincoln Memorial, 1939

Officials of Howard University in Washington, D.C., asked in January 1939 to rent Constitution Hall for an Easter concert by the Black singer Marian Anderson. The hall belonged to the Daughters of the American Revolution, or DAR, a women's group. Its leaders refused. DAR leaders had let only white performers use the hall since 1932. Frank Ballou, the head of Washington's public schools, also refused to let her use the hall of Central High School, a white school, and the members of the school board backed him.

**The Lincoln Memorial.** First Lady Eleanor Roosevelt quit the DAR on February 26, 1939. She wrote that its leaders had "an opportunity to lead in an enlightened way" and had "failed." Harold Ickes, the Secretary of the Interior, then set up a concert on the steps of the Lincoln Memorial. Anderson sang there on Easter Sunday, April 9, 1939, to more than 75,000 people, and millions more heard her on the radio. She began with "My Country, 'Tis of Thee."

### Marian Anderson

> **Who:** A Black contralto, a singer with a low woman's voice, who sang at the Lincoln Memorial in 1939 and was the first Black American singer at the Metropolitan Opera.
>
> **When and where:** Born February 27, 1897, in Philadelphia. Died April 8, 1993, in Portland, Oregon.
>
> **Movie:** *Marian Anderson: The Lincoln Memorial Concert* (1939), a short film of the concert.

**Toscanini told her she had "a voice heard once in a hundred years."**

As a young woman, Marian Anderson applied to a music school in Philadelphia. The school's officials turned her away because they took only white students. In Salzburg, Austria, in 1935, the conductor Arturo Toscanini told her she had "a voice heard once in a hundred years."

**Constitution Hall.** The DAR's president in 1939, when its leaders kept Anderson out of the hall, was Sarah Corbin Robert.

**The Met.** She sang at the Metropolitan Opera on January 7, 1955, at 57, in the part of Ulrica, a fortune teller, in Verdi's opera *Un ballo in maschera*. She sang at the March on Washington in August 1963. That year she was given the Presidential Medal of Freedom, an award given by the president.

**If you remember one thing:** In these fifty years record companies and radio stations brought the blues, jazz, gospel and country music to listeners across the country, and the companies and copyright holders kept much of the money.

**One number:** $125. Columbia paid Bessie Smith that much for each side of "Down Hearted Blues," a record that sold 780,000 copies in six months, and it paid her no royalty on any of them.

**Next:** After 1950 Black musicians made rock and roll out of rhythm and blues and gospel, and white singers sold more copies of some of their songs than they did.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 20 minutes**

Black musicians made rock and roll, soul and hip-hop. White singers then sold more copies of some of those songs than the Black singers who recorded them first. Record company owners, managers and publishers kept much of the money from songs such as "Hound Dog" and "That's All Right."

In Detroit, Berry Gordy built Motown, which became the largest Black-owned business on one magazine's list. Civil rights marchers sang old church songs with new words at their mass meetings.

A teenage DJ and his sister held a party in the Bronx, in New York City, in 1973 that people now name as the start of hip-hop. Senators held a hearing on the words of songs in 1985, and leaders of the RIAA, the record companies' own group, agreed to put warning labels on some albums.

### Rock and roll, and who got paid for it

Sister Rosetta Tharpe, a Black gospel singer from Arkansas, played electric guitar in church music from the late 1930s. Her "Strange Things Happening Every Day," from 1944, was the first gospel record to reach the rhythm and blues sales chart. Some scholars call it the first rock and roll record. She was an influence on Elvis Presley, Little Richard, Chuck Berry and Johnny Cash.

**Credit taken.** Fats Domino's "The Fat Man," from 1949, had sold a million copies by 1951. Chuck Berry's "Maybellene," from 1955, sold more than a million. When Berry first saw his record, it listed Alan Freed, a disc jockey who played records on the radio, and another man as its co-writers. That gave them a right to part of the money the song earned its writers. Berry later won back full credit.

**Cover versions.** White singers made cover versions of songs by Black singers, new recordings of songs that someone else had already recorded. Georgia Gibbs, a white singer, copied LaVern Baker's "Tweedle Dee" note for note in 1955. Baker's record reached No. 14 on the national pop chart, and Gibbs's copy reached No. 1.

Baker tried to sue Gibbs for $250,000. She asked Congress to treat such copies as a breach of copyright. Representative Charles Diggs led an investigation by Congress into what he called "song theft." No law came of it.

Pat Boone, a white singer, covered Fats Domino's "Ain't That a Shame" in 1955. It was Boone's first No. 1 record. Domino and his co-writer, Dave Bartholomew, still earned writers' royalties from it. Boone also covered Little Richard's "Tutti Frutti," and Boone's record ranked higher on the national pop chart than Little Richard's own.

**Little Richard's lawsuit.** Little Richard later said that the people running his record company, Specialty Records, had cut his royalty rate without telling him. He sued the company and its owner, Art Rupe, in 1984 for $112 million in royalties he said he was owed. They settled out of court in 1986, which means they reached an agreement and the case never went to trial.

**Payola.** Members of a House committee, led by Representative Oren Harris, held hearings in 1959 and 1960 on payola, secret payments to a disc jockey or a radio station to play a record. Alan Freed refused to sign a statement that he had taken no bribes, and the managers of the radio station WABC fired him in November 1959.

Members of Congress made payola a crime in 1960, punished by up to a year in jail. Freed told a court in 1962 that he was guilty of taking bribes and paid a $300 fine. The older song publishers in ASCAP pushed for the hearings, partly because they opposed rock and roll.

### Hound Dog: Big Mama Thornton and Elvis Presley

The songwriters Jerry Leiber and Mike Stoller wrote "Hound Dog." The chapter opening tells the start of this story: Big Mama Thornton's 1952 record, Don Robey's name on the copyright form, and her one check for $500. Robey's Peacock Records put her record out in 1953, and it stayed at No. 1 on the rhythm and blues chart for seven weeks. Robey guessed that it sold 500,000 to 750,000 copies. Thornton said, "That song sold over two million records."

**Presley's record.** Elvis Presley recorded "Hound Dog" for RCA on July 2, 1956. His record was No. 1 on the pop chart for 11 weeks. He followed a reworked version by Freddie Bell and the Bellboys, a band he had heard in Las Vegas that year. Leiber and Stoller earned large royalties only after Presley's record. Thornton died of heart and liver disease in 1984. She was buried in a grave shared with two other people.

### Elvis Presley

> **Who:** A white rock and roll singer from Mississippi and Tennessee whose records sold an estimated 500 million copies.
>
> **When and where:** Born January 8, 1935, in Tupelo, Mississippi. Moved to Memphis, Tennessee, in 1948. Died August 16, 1977, at his Memphis home, Graceland, at 42.
>
> **Movie:** *Elvis* (2022), a Hollywood drama film about him and his manager.

**His manager took 25 percent of his pay, and later 50.**

Elvis Presley recorded a Black singer's blues song at Sun Records in 1954, and his "Hound Dog" followed a song that had been a hit for a Black singer first. He first heard music at his family's church, an Assembly of God church. In Memphis he listened to Black blues and rhythm and blues singers on the radio.

**Sun Records.** Sam Phillips owned Sun Records in Memphis and recorded Black blues musicians such as Howlin' Wolf and B. B. King. His office manager, Marion Keisker, said he often told her: "If I could find a white man who had the Negro sound and the Negro feel, I could make a billion dollars." "Negro" was a word of that time for Black people. Presley sang "That's All Right," a blues song by the Black singer Arthur Crudup, at Sun on the night of July 5, 1954, and Phillips recorded it.

**Arthur Crudup.** Crudup had recorded the song for RCA in 1946. He said later: "I realised I was making everybody rich, and here I was poor." In 1968 a publisher backed out of a $60,000 settlement with him at the last moment. In 1971 a songwriters' group got him more than $10,000 in royalties he had not been paid. He died in 1974.

**Colonel Parker's share.** Phillips and Presley's manager, Colonel Tom Parker, sold Presley's contract to RCA for $40,000 in November 1955. Parker took 25 percent of Presley's pay. Presley agreed in 1967 to raise Parker's share to 50 percent of some of his income. Parker sold RCA the rights to all of Presley's old records in 1973 for $5.4 million. Because of that sale, Presley's family got no royalties on those records after he died.

Blanchard Tual, a lawyer whom a judge had appointed, called the 50 percent share "extortionate" in 1981, meaning unfairly high. He called the 1973 sale "unethical and poorly handled." Presley served in the Army from 1958 to 1960. His record sales are estimated at about 500 million copies around the world. He died at Graceland on August 16, 1977, at 42.

### Motown, soul and gospel

Berry Gordy Jr. of Detroit started a record company on January 12, 1959, with an $800 loan from his family's savings fund. It was later called Motown. From 1960 to 1969, 79 Motown songs reached the top ten of the national pop chart. The editors of *Black Enterprise* magazine began ranking the largest Black-owned businesses in 1973. Motown was first on that list, with $40 million in sales, and it stayed first until 1983. Gordy sold Motown in 1988 for $61 million.

**The Funk Brothers.** A group of Detroit studio musicians, later called the Funk Brothers, played on most Motown hits from 1959 to 1972. No Motown record listed their names until Marvin Gaye's album *What's Going On* in 1971. Gordy fined any of them he caught recording for other companies.

**Ray Charles.** He had been blind since he was about seven. In "I Got a Woman," from 1954, he mixed gospel with the blues, and some church people objected. He refused to play a dance in Augusta, Georgia, in 1961 when he learned that the audience would be split by race. The promoter sued him, and in 1962 a judge fined him $757. His 1959 contract with ABC-Paramount promised that he would own his master recordings, the original tapes that every copy is made from, in time.

**Sam Cooke.** A singer from Mississippi who had led the gospel group the Soul Stirrers, Cooke started his own record company and his own company to publish his songs. From 1963 his own company owned his master recordings, and he was among the first Black artists to control his own business.

A Los Angeles motel manager, Bertha Franklin, shot and killed him on December 11, 1964. A coroner's jury, a panel that decides how a person died, called it justifiable homicide, a killing the law excuses. His family has disputed that account.

**James Brown.** Brown paid for the recording of his 1963 album *Live at the Apollo* himself. Martin Luther King Jr. was shot and killed on April 4, 1968, and James Earl Ray later pleaded guilty to his murder. The next day, Brown gave a free concert in Boston that was shown on television. His song "Say It Loud, I'm Black and I'm Proud" came out that August.

**By 1970:** Motown had put 79 songs in the pop top ten, Sam Cooke's own company owned his master recordings, and Ray Charles had a contract that promised him his.

### Aretha Franklin

> **Who:** A Black singer who recorded "Respect" in 1967.
>
> **When and where:** Born March 25, 1942, in Memphis, Tennessee. Grew up in Detroit, Michigan. Died there August 16, 2018.
>
> **Movie:** *Amazing Grace* (2018), a documentary film of her 1972 gospel concert in a Los Angeles church.

**She spelled it out: R-E-S-P-E-C-T.**

Aretha Franklin took Otis Redding's song "Respect" and turned it into a woman's demand, and it went to No. 1 on the pop chart in 1967. Her father, the Reverend C. L. Franklin, led New Bethel Baptist Church in Detroit, and she sang there as a child. At 14 she recorded a gospel album, *Songs of Faith*. She had her first child at 12 and her second at 15.

She recorded for Columbia from 1960 to 1966 and had few hits. Jerry Wexler then brought her to Atlantic Records. In January 1967 she recorded for one day at FAME Studios in Muscle Shoals, Alabama, before a fight broke out in the studio.

**"Respect."** Redding had written and recorded "Respect" in 1965. In his song a man asks for respect when he comes home. Franklin recorded it in New York on February 14, 1967. She and her sister Carolyn made it a woman's demand. They spelled out the word "R-E-S-P-E-C-T" and added new lines.

It was No. 1 on the pop chart for two weeks and on the rhythm and blues chart for eight. It became a song of the women's movement and of the civil rights movement. Redding called it the song "that a girl took away from me."

**Angela Davis.** Franklin spoke up in 1970 for Angela Davis, a Black activist whom FBI agents had arrested that October. Davis was charged with kidnapping and with the murder of Judge Harold Haley, who was killed in an attack on a California courthouse. Franklin said, "Angela Davis must go free." An all-white jury found Davis not guilty in June 1972.

**Amazing Grace.** Franklin recorded the gospel album *Amazing Grace* at New Temple Missionary Baptist Church in Los Angeles in January 1972. It sold more than two million copies. The film made at the same time was not shown until 2018, because the sound and the pictures could not be matched. In 1987 she became the first woman named to the Rock and Roll Hall of Fame. She died in Detroit on August 16, 2018.

### Where did 'We Shall Overcome' come from?

"We Shall Overcome" started as a church hymn, "I'll Overcome Some Day," that Charles Albert Tindley wrote in 1901. Tobacco workers went on strike at a cigar factory in Charleston, South Carolina, in 1945 and 1946. One of them, Lucille Simmons, led the strikers in singing "We Will Overcome." Zilphia Horton of the Highlander Folk School learned it from her and printed it in 1947.

The folk singer Pete Seeger changed "will" to "shall," because, he said, "'We shall' opens the mouth wider." From 1959 Guy Carawan taught the song to young civil rights workers.

**The March on Washington.** Joan Baez led "We Shall Overcome" at the March on Washington on August 28, 1963. Mahalia Jackson, Marian Anderson, Odetta, Bob Dylan, and Peter, Paul and Mary sang there too. During Martin Luther King Jr.'s speech, Jackson called out to him, "Tell them about the dream, Martin!"

**Selma.** About 600 marchers set out from Selma, Alabama, on March 7, 1965. At the Edmund Pettus Bridge, Alabama state troopers and other officers, led by Major John Cloud, attacked them with nightsticks and tear gas. At least 50 marchers went to the hospital. President Lyndon Johnson spoke to Congress on March 15 and used the song's words: "And we shall overcome." In January 2018, after a court case, the owners of the song's copyright gave it up. Since then anyone may use it freely.

### Bernice Johnson Reagon

> **Who:** A Black student in Albany, Georgia, who led singing at civil rights meetings and sang with the SNCC Freedom Singers.
>
> **When and where:** Born October 4, 1942, in Albany, Georgia. Died July 16, 2024.

**"So instead I put in freedom," she said of an old song.**

Bernice Johnson Reagon led the singing at civil rights meetings in Albany, Georgia, and changed the words of old spirituals to fit the protests. She joined the NAACP Youth Council in Albany. Officials at Albany State College suspended her for her part in the protests.

At mass meetings she took old spirituals and put new words in them. Of one song she said: "So instead I put in freedom and by the second line everyone was singing."

**The Freedom Singers.** She joined the Freedom Singers of SNCC, the Student Nonviolent Coordinating Committee, with Cordell Reagon, Rutha Mae Harris and Chuck Neblett. She married Cordell Reagon, who had started the group. The group traveled 50,000 miles in nine months to sing about the movement, without taking a single flight, and its first tour raised nearly $50,000 for SNCC. "There weren't soloists, there were song leaders," she said. She called the group "a singing newspaper."

**Sweet Honey in the Rock.** She started Sweet Honey in the Rock in 1973, a group of African American women who sing without instruments. She later worked for the Smithsonian Institution as a curator, a person in charge of a museum's collections. Through radio, film and concerts, she helped people study the songs and stories that Black Americans passed down by word of mouth. She died on July 16, 2024.

### Bob Dylan

> **Who:** A songwriter of the folk music revival of the early 1960s and after, and winner of the Nobel Prize in Literature.
>
> **When and where:** Born Robert Allen Zimmerman on May 24, 1941, in Duluth, Minnesota. Grew up in Hibbing, Minnesota. Moved to New York in 1961.
>
> **Movie:** *No Direction Home: Bob Dylan* (2005), a documentary by Martin Scorsese.

**At the 1965 Newport Folk Festival he played an electric guitar.**

Bob Dylan won the Nobel Prize in Literature, a world prize for writers, in 2016 for his songs. The prize was "for having created new poetic expressions within the great American song tradition."

He moved to New York in January 1961 and visited Woody Guthrie, who was then in a mental hospital in New Jersey with Huntington's disease. He released the album *The Freewheelin' Bob Dylan* in 1963. At the March on Washington that August he sang "Only a Pawn in Their Game."

**Newport.** He played an electric guitar at the Newport Folk Festival in 1965. The leaders of the folk music world met him with hostility.

### Country music from Nashville and Bakersfield

Hank Williams learned guitar as a boy in Alabama from a Black street musician, Rufus "Tee-Tot" Payne, who taught him in return for money or meals. Williams had 12 No. 1 country records. He was born with a defect of the spine that caused him pain all his life, and he drank and took painkillers. Grand Ole Opry managers dropped him in August 1952 for drunkenness and missed shows. He died in the back seat of a car near Oak Hill, West Virginia, on January 1, 1953, at 29.

Patsy Cline recorded "Crazy," a song by Willie Nelson, in 1961. She died in a plane crash near Camden, Tennessee, on March 5, 1963, at 30. She became the first woman in the Country Music Hall of Fame in 1973.

**Bakersfield.** Buck Owens, Merle Haggard and other musicians in Bakersfield, California, played country music on electric guitars in the late 1950s, often two Fender Telecasters. Nashville records of those years added orchestras and a polished sound, and the Bakersfield musicians broke from it. Many of their listeners were the families of people who had come to California in the Dust Bowl years.

Johnny Cash recorded two concerts for prisoners at Folsom State Prison in California on January 13, 1968. The album ends with "Greystone Chapel," a song by a prisoner, Glen Sherley. It sold 500,000 copies by October 1968. Cash himself never served a prison sentence.

**"The Pill."** Loretta Lynn's song of 1975 is about a wife who is tired of being pregnant and starts taking birth-control pills. The people running a number of country radio stations refused to play it. It still reached No. 5 on the country chart.

**Charley Pride.** He became the first Black performer on the Grand Ole Opry in 1967 since DeFord Bailey last played there in 1941. Pride was one of eleven children of sharecroppers from Sledge, Mississippi, families who farmed another man's land for a share of the crop. His first records went to radio stations without his photograph. He had 30 No. 1 country records, and in 1971 he won the Country Music Association's award for Entertainer of the Year.

### Hip-hop from the Bronx, 1973 onward

Clive Campbell, a teenage DJ called Kool Herc, played records for dancers at a party at 1520 Sedgwick Avenue in the Bronx, New York, on August 11, 1973. His sister Cindy Campbell planned the party to earn money for back-to-school clothes. City officials named the building the birthplace of hip-hop in 2007.

**The fires.** The first hip-hop DJs played in the Bronx in the same years that fires burned much of the South Bronx. Most of the fires were arson, fires set on purpose. Landlords paid people who lived nearby to set fires in the landlords' own buildings, so the landlords could collect insurance money. One landlord collected $125,000 from 21 fires.

After a study of the fire service by the RAND Corporation, a research company, city officials closed 12 fire companies in the South Bronx between 1974 and 1976, when the city was nearly out of money. Seven census tracts, small areas the census counts separately, lost more than 97 percent of their buildings to fire and abandonment. About 250,000 people lost their homes.

**"Rapper's Delight."** The Sugarhill Gang's "Rapper's Delight" came out on Sugar Hill Records on September 16, 1979. Sylvia Robinson produced it and ran the company's work. It reached No. 36 on the national pop chart, and many writers call it the first rap record that sold widely. It used the music of Chic's song "Good Times." Chic's writers, Nile Rodgers and Bernard Edwards, got credit only after they threatened to sue. One of its rappers, Big Bank Hank, used rhymes written by Grandmaster Caz and did not credit him.

**"The Message."** The 1982 song by Grandmaster Flash and the Furious Five described poverty in the inner city. Ed "Duke Bootee" Fletcher, Melle Mel, Clifton "Jiggs" Chase and Sylvia Robinson wrote it. In 2002 it became the first hip-hop record added to the National Recording Registry, the Library of Congress's list of recordings chosen to be kept for the future.

### DJ Kool Herc

> **Who:** Born Clive Campbell in Jamaica, the DJ at the 1973 Bronx party that people name as the start of hip-hop.
>
> **When and where:** Born April 16, 1955, in Kingston, Jamaica. Moved to the Bronx, New York, in November 1967, at 13.

**He played two copies of one record to stretch the drums.**

**The Merry-Go-Round.** At parties he played funk records. The "break" of a funk record is its drum part. Herc used two copies of the same record. When the break ended on one, he started it again on the other, so the drum part lasted longer. He called this the "Merry-Go-Round." He called the dancers who danced to the breaks "b-boys" and "b-girls."

Later someone stabbed Herc at a club called the Executive Playhouse while he was trying to stop a fight. No record names who stabbed him. After that he pulled back from playing, and by 1980 he had stopped working as a DJ. No surviving document shows what he earned from hip-hop.

### Woodstock, music television, compact discs and the lyrics hearing

Thirty-two acts played at the Woodstock music festival, on Max Yasgur's dairy farm in Bethel, New York, from August 15 to 18, 1969. The organizers expected about 50,000 people. Estimates of the crowd run from 400,000 to more than 460,000, and no record names who counted. The fences were not finished, so the festival became free. Three people died. Two died from taking too much of a drug, and a tractor ran over a 17-year-old as he slept. No record names the driver.

**MTV.** The MTV television channel began playing music videos on August 1, 1981. Its managers said they kept to a "rock format," and they played few Black artists. Walter Yetnikoff, president of CBS Records, threatened to pull CBS's videos unless MTV's managers played Black artists. They then put Michael Jackson's "Billie Jean" into heavy rotation from March 1983, which means they played it often. Compact disc players went on sale in Japan on October 1, 1982, and in the United States in March 1983.

**The lyrics hearing.** Tipper Gore, Susan Baker and two other women in Washington started a group called the Parents Music Resource Center in 1985. They made a list of 15 songs they objected to and called it the "Filthy Fifteen." It included Prince's "Darling Nikki." Members of the Senate Commerce Committee held a hearing on September 19, 1985. The musicians Frank Zappa, Dee Snider and John Denver spoke against labels. Zappa called the plan "an ill-conceived piece of nonsense," a badly thought-out idea.

Leaders of the RIAA, the record companies' own group, agreed on November 1, 1985, to put warning labels on some albums. Record companies began putting a standard "Parental Advisory" sticker on albums in 1990. Managers at Walmart and some other stores would not sell albums with the sticker.

### Native ceremonies and a 1978 law

Many Native songs belong to religious ceremonies. Until 1978, federal officials could still enforce the rules against Native religious dances that Hiram Price, the head of the government's Indian office, had issued in 1883. In 1978 members of Congress passed the American Indian Religious Freedom Act. In it they wrote that Native "ceremonies have been intruded upon, interfered with, and in a few instances banned." The act does not name the people who did these things.

### Selena Quintanilla

> **Who:** A Mexican American singer of Tejano music, the Spanish-language music of Texas.
>
> **When and where:** Born April 16, 1971, in Lake Jackson, Texas. Killed March 31, 1995, in Corpus Christi, Texas, at 23.
>
> **Movie:** *Selena* (1997), a Hollywood drama film about her, with Jennifer Lopez.

**The woman who ran her fan club shot her at 23.**

Selena Quintanilla sang with her brother and sister in their father Abraham Quintanilla Jr.'s band, Selena y Los Dinos, and learned the Spanish words of her songs by their sound, with her father's help. She won the Tejano Music Award for Female Vocalist of the Year in 1987 and in each of the next nine years. In 1994 she won a Grammy Award for her album *Live!*

**Yolanda Saldívar.** Saldívar ran Selena's fan club and managed her clothing stores. She had secretly taken money from the business, more than $30,000 or more than $60,000 by different counts. Selena meant to fire her.

**The shooting.** Saldívar shot Selena with a gun at a Days Inn motel in Corpus Christi, Texas, on March 31, 1995, as Selena tried to leave the room. The bullet hit her lower right shoulder. Selena reached the lobby and named Saldívar. She died at the hospital that afternoon from loss of blood. Saldívar gave herself up to the police more than nine hours later.

**The trial.** A jury in Houston found Saldívar guilty of murder with a deadly weapon on October 23, 1995, and Judge Mike Westergren sentenced her to life in prison. Members of the Texas parole board, who decide whether a prisoner may leave prison early, refused to let her out on March 27, 2025. They set her next review for March 2030.

Between 30,000 and 40,000 people came to see Selena's coffin. Her album *Dreaming of You* came out after her death. It made her the first Latin artist whose album entered the national album chart at No. 1.

**If you remember one thing:** Black musicians made rock and roll, soul and hip-hop in these fifty years, and the owners of the copyrights and the master recordings kept much of the money.

**Left open:** Who would own the recordings, the companies or the singers who made them? Sam Cooke's company owned his masters from 1963, and Ray Charles had a contract that promised him his. After 2000 one singer lost hers to a buyer and recorded four albums again.

**Next:** After 2000 Americans moved from buying records to streaming them, and a stream paid the owner of the recording a fraction of a cent.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 22 minutes**

Most Americans now stream their music, playing songs over the internet without buying copies, and a streaming service pays the owner of each recording a fraction of a cent a play. By 2025, 82 cents of every dollar that American record companies took in came from streaming.

Sales of recorded music in the United States had peaked in 1999, when most people bought CDs. Then a free program called Napster let people copy songs from each other's computers, and by the record companies' own count, sales fell in 15 of the 16 years from 2000 to 2015.

A streaming service pays the owner of the recording, usually a record company, and not the singer. In a 2018 survey, most working musicians said they earned money from playing live. Dolly Parton, a songwriter from the mountains of Tennessee, died on August 25, 2026, at 80. In September 2026 record companies and musicians were in court against companies whose computer programs make songs.

### Napster, the iPod and streaming, 1999 to 2025

Shawn Fanning and Sean Parker started Napster in June 1999. It let people copy music files from each other's computers for free. Record companies sued in December 1999, and a federal judge ordered Napster to block copyrighted songs. Napster's owners could not do it, so they shut the service down in July 2001. At its peak, in February 2001, it had 26.4 million users by a checked count, though some estimates say 80 million.

**The iPod.** Apple's boss, Steve Jobs, showed the iPod, a pocket music player, on October 23, 2001. He said it held "1,000 songs in your pocket." Apple's iTunes Store opened on April 28, 2003, and sold most songs for 99 cents each. By 2014 it had sold 35 billion songs.

**Streaming.** Spotify, a company from Sweden, began streaming music in the United States in July 2011. By March 2026, the company said, Spotify had 300 million paying subscribers around the world.

**The numbers.** The Recording Industry Association of America, or RIAA, is the record companies' own group, and its staff count what the companies take in. Mark J. Perry of the American Enterprise Institute, a research group, used those figures in 2017. He found that sales peaked in 1999 at $20.9 billion, counted in 2016 dollars so that the rise in prices is taken out.

Sales then fell in 15 of the 16 years from 2000 to 2015. In 2016 they were $7.57 billion, a little more than a third of the 1999 figure. That year, for the first time, Americans paid more for streaming than for CDs, downloads and ringtones.

The RIAA reported in March 2026 that in 2025 the companies took in $11.5 billion at wholesale, the price the companies themselves are paid, which is lower than the price in stores. Counted that way, without taking out the rise in prices, the RIAA called 2025 the companies' best year. With the rise in prices taken out, the 1999 peak was still higher. Of the 2025 money, $9.5 billion came from streaming, and $1.04 billion came from vinyl records.

### What does a stream pay?

Spotify pays the owners of the music less than half a cent for each play, by one company's estimate. It pays about 70 percent of the money it takes in to the owners of the music, by its own account.

About 58.5 percent goes to whoever owns the recording, which is usually a record company. About 12 percent goes to whoever owns the song itself: the songwriter and the publisher, a company that manages the rights to the song. A singer who does not own the recording gets a share from the record company, under the singer's contract.

**The estimate.** Spotify does not pay a set price for each play. It pays each owner by that owner's share of all the plays. iMusician, a company that sends music to streaming services, put the average in February 2025 at $0.003 to $0.005 a play, and about $0.004 for a listener in the United States.

**The 1,000-play line.** From April 1, 2024, Spotify stopped paying anything for a recording played fewer than 1,000 times in a year. In a November 2023 statement, Spotify's managers wrote that recordings under that line had earned an average of about 3 cents a month, and that 99.5 percent of all plays were of recordings above the line.

Spotify's March 2026 report states that it paid the music business more than $11 billion in 2025. By its count, more than 1,500 artists earned over $1 million from it that year. The artist ranked 100,000th earned about $7,300.

**What musicians say.** A musicians' group, the United Musicians and Allied Workers, held protests in 31 cities in March 2021 and asked Spotify to pay one cent a play. A group called the Music Industry Research Association asked 1,227 American musicians about their work in 2018. Most earned money from playing live, and most could not live on music alone.

Of the women who answered, 72 percent said they had been treated unfairly because they were women, and 67 percent said they had been sexually harassed, which means they faced unwanted sexual remarks or touching. Of the musicians who were not white, 63 percent said they had been treated unfairly because of their race. The musicians who answered did not name the people who did it.

### Zoë Keating

> **Who:** A cellist and composer who sells her own recordings and publishes what streaming pays her.
>
> **When and where:** Born February 2, 1972, in Guelph, Ontario, Canada, to an English mother and an American father. Worked in San Francisco, California, and later Vermont.

**"206,011 Spotify streams. $753."**

Zoë Keating is a cellist who has published what streaming services paid her, so that other musicians could see real numbers. She posted those Spotify figures in September 2019. They came to a little more than a third of a cent for each play, and the company that sent her music to Spotify took no cut.

She played cello in the band Rasputina from 2002 to 2006. Alone, she uses a computer to record and repeat her own cello parts as she plays, so that one player sounds like many.

**On her own.** She released her album *One Cello x 16: Natoma* herself, without a record company. It reached No. 1 on the iTunes classical chart four times. She began publishing her income from sales and streaming in August 2012.

**Her husband.** Doctors found in May 2014 that her husband, Jeff Rusch, had stage 4 cancer, cancer that has spread through the body. Staff at their insurance company, Anthem, first refused to pay for his hospital stay. The records do not name them. Keating wrote about the refusal on her blog, as she publishes her pay. Anthem's staff reversed the refusal after local news stories about it. He died on February 19, 2015.

### Who owns a recording: masters and songs

Every recorded song has two copyrights. One covers the song itself, its words and tune. The other covers the master, the first recording, which every copy is made from. Whoever owns the master is paid for every copy and every stream of that recording. Sam Cooke's own company owned his master recordings from 1963. Ray Charles's 1959 contract promised that he would own his in time.

**The Universal fire.** Jody Rosen, a writer for the New York Times Magazine, reported in 2019 that a fire in 2008 had destroyed 118,000 to 175,000 of Universal Music Group's master tapes. He wrote that they might include records by Chuck Berry, Muddy Waters and John Coltrane. A statement from Universal Music Group said the report held "numerous inaccuracies," meaning many mistakes. The company's leaders confirmed that the masters of one Soundgarden album had burned.

The fire began at Universal Studios Hollywood on June 1, 2008, when a worker used a blowtorch to heat roof shingles and left before they cooled. It spread across the studio's backlot, the outdoor area of sets and storage buildings.

Bob Dylan sold the rights to all of his songs to Universal Music Publishing Group in December 2020. Reporters at *The New York Times* estimated the price at more than $300 million, and other reports said about $400 million.

### Taylor Swift

> **Who:** A songwriter and singer who recorded four of her first six albums again after a music manager bought the master recordings.
>
> **When and where:** Born December 13, 1989, in West Reading, Pennsylvania. Moved to Hendersonville, Tennessee, at 14.
>
> **Movie:** *Miss Americana* (2020), a documentary about her.

**She recorded four of her albums again, so she would own them.**

Taylor Swift made new versions of four albums after a music manager bought the masters of her first six. Under her 2018 contract with Universal, she owns the masters of her new recordings.

At 14 her family moved to Hendersonville, Tennessee. That year a Nashville music publisher signed her as a songwriter, the youngest it had ever signed. After a show at Nashville's Bluebird Cafe on November 3, 2004, she signed with Scott Borchetta's new company, Big Machine Records. Big Machine owned the masters of her first six albums.

**The sale.** The music manager Scooter Braun bought Big Machine on June 30, 2019, for about $330 million, and with it her masters. Swift said she had tried for years to buy them. She said she was offered them only if she signed up to make six more albums for the company. Braun sold the masters to Shamrock Holdings in October 2020 for a reported $405 million. Shamrock is owned by the family of Roy E. Disney.

**Taylor's Version.** Swift recorded four of the albums again, and each came out as "Taylor's Version." *Fearless* came out on April 9, 2021, and *Red* on November 12, 2021. *Speak Now* followed on July 7, 2023, and *1989* on October 27, 2023.

**Buying them back.** Her Eras Tour ran from March 17, 2023, to December 8, 2024, with 149 shows. It took in $2.07 billion, more than any concert tour before it. On May 30, 2025, she said she had bought all six of the original masters from Shamrock. The price was not made public.

### The Music Modernization Act, 2018

Members of Congress passed the Music Modernization Act in 2018. House members voted for it on April 25, and senators passed it on September 19 with no votes against. President Donald Trump signed it on October 11. Under the law, a nonprofit group, the Mechanical Licensing Collective, keeps a list of who owns each song and pays songwriters for streams. The group began paying out money in 2021 for songs whose owners nobody had identified.

**Older records.** Recordings made before February 15, 1972, had no federal copyright, so internet radio services did not have to pay for playing them. Many rhythm and blues records of the 1950s and 1960s were made before that date. Under the 2018 law, the singers and musicians on those older records are paid when digital radio plays them.

### Hip-hop, Latin music and country radio

Hip-hop and R&B made up 24.5 percent of all the music Americans bought or streamed in 2017, more than any other kind. Rock came second, with just under 21 percent. Analysts at Nielsen Music, a company that tracks sales and streams, made the count, and CNBC's reporters wrote about it in January 2018.

Sales of Latin music came to $1 billion in 2025, 8.8 percent of what the record companies took in across the United States. The RIAA reported in 2026 that Latin music's sales had reached a new high for the tenth year in a row.

**Country radio.** Jada Watson, a researcher, counts the songs played on country radio. She found that songs by women got 11 percent of the plays by 2022. She reported in 2023 that no song by a Black, Indigenous or other woman of color was in regular daytime rotation, the list of songs a station plays over and over each day.

**Beyoncé.** The Black singer Beyoncé sang her country song "Daddy Lessons" at the Country Music Association Awards on November 2, 2016. Some country fans said she did not belong there, and the association's staff deleted its online posts about her performance.

Her country album *Cowboy Carter*, from 2024, made her the first Black woman with a No. 1 album on the country album chart. The album got no nominations at the Country Music Association Awards that year. It won the Grammy Awards for Album of the Year and Best Country Album on February 2, 2025.

**By 2025:** Streaming made up 82 cents of every dollar that record companies took in, Latin music's sales reached a new high for the tenth year in a row, and Taylor Swift had bought back the masters of her first six albums.

### Kendrick Lamar

> **Who:** A Black rapper and songwriter, the first musician outside classical music and jazz to win the Pulitzer Prize for Music.
>
> **When and where:** Born June 17, 1987, in Compton, California.

**He won a Pulitzer Prize for an album of rap.**

Kendrick Lamar became the first musician outside classical music and jazz to win the Pulitzer Prize for Music, in 2018. His parents had moved to Compton, California, from the South Side of Chicago in 1984. When he was five, he saw a teenage drug dealer killed in a drive-by shooting outside his apartment. No record names the shooter. In seventh grade an English teacher, Regis Inge, introduced him to poetry.

**The albums.** He signed with the record label Top Dawg Entertainment in 2005. His albums include *Good Kid, M.A.A.D City* in 2012 and *To Pimp a Butterfly* in 2015. Protesters in the Black Lives Matter movement used his songs as anthems.

**The prize.** His album *DAMN.* won the Pulitzer Prize for Music on April 16, 2018. The Pulitzer board called it "a virtuosic song collection unified by its vernacular authenticity and rhythmic dynamism," praising the skill of the songs, their everyday speech and their strong rhythm. The prize was $15,000.

He performed at the Super Bowl halftime show on February 9, 2025. About 133.5 million people watched, more than had watched any halftime show before. By 2026 he had won 27 Grammy Awards, more than any other rapper.

### Deaths at music festivals, 2017 and 2021

More than 22,000 people were at the last night of the Route 91 Harvest country music festival in Las Vegas, Nevada, on October 1, 2017. At 10:05 p.m., while the country singer Jason Aldean was playing, Stephen Paddock, who was 64, began shooting into the crowd from his rooms on the 32nd floor of the Mandalay Bay hotel.

In ten minutes he fired more than 1,000 bullets. He killed 58 people that night and wounded at least 413 with gunfire, and about 867 people were hurt in all. Two wounded women died later, in 2019 and 2020, so the official count is 60 dead. Paddock shot himself. Investigators never found out why he did it.

**Astroworld.** About 50,000 people came to the Astroworld Festival in Houston, Texas, on November 5, 2021. When the rapper Travis Scott, who had started the festival, came on stage, the crowd pushed toward him. Ten people died of compressive asphyxiation: they were squeezed so hard they could not breathe. Thousands were hurt. The youngest to die was a boy of 9 or 10, and the reports differ on his age.

A Harris County grand jury, a group of citizens who decide whether someone should be charged with a crime, decided in June 2023 not to charge Scott or five others. Among the five was Brent Silberstein, a festival manager for the concert company Live Nation. Families of people who died sued Scott and Live Nation.

### Machines that make music

Auto-Tune is a computer program that moves a singer's off-key notes onto the right pitch. The engineer Andy Hildebrand invented it, and the company Antares put it on sale on September 19, 1997. The singer Cher used it as a sound effect on her song "Believe" in 1998, the first record sold in stores to use it that way. The rapper and singer T-Pain used it that way on his 2005 album *Rappa Ternt Sanga* and after, and Kanye West used it on his 2008 album *808s & Heartbreak*.

**Songs made by programs.** Companies such as Suno and Udio sell computer programs that make whole songs. To train such a program, its makers feed recordings into it, and the program uses them to work out how to make new songs.

**The lawsuits.** Record companies, led by the RIAA, sued Suno and Udio in June 2024. They said the two companies had trained their programs on the record companies' recordings without permission.

**The settlements.** Some of the cases were settled in 2025 and 2026, which means the two sides ended them by agreement. Universal settled with Udio, and Udio's owners agreed to use only music they had permission to use. Warner and BMG settled with Suno and gave it permission to use their music.

**Still in court.** Universal and Sony kept suing Suno. In court papers, Suno's lawyers admitted that it had downloaded audio from YouTube. They argued that this was fair use, a use of someone else's work that the law allows in some cases.

Suno put out a new version of its program in September 2026, and its makers said they trained it on music from companies that had given permission. Universal and Sony sued again that month over 60,202 recordings, saying the new version grew out of the old ones. The songwriter Jason Isbell and three other musicians sued Suno that month too, and asked to speak for other artists as well. In October a music publisher sued Suno over 1,050 songs.

**No final ruling.** A separate case is about song lyrics. In March 2025 a federal judge, Eumi Lee, turned down music publishers' request to stop the company Anthropic from using lyrics to train its computer program while that case went on. As of October 26, 2026, no American court had given a final ruling on whether a company may train a song-making program on recordings without permission.

### The Kennedy Center, 2025 and 2026

The Kennedy Center is a building for music, theater and dance in Washington, D.C., named for President John F. Kennedy. The National Symphony Orchestra plays there. Members of its board chose President Donald Trump as its chairman in February 2025. Trump then removed board members who had been appointed by Democrats and appointed his allies.

Board members voted on December 18, 2025, to add his name to the building, CBS News reporters wrote. Representative Joyce Beatty, a member of the board, said she had been muted on the call and that the vote had not been on the list of business for the meeting.

**In court.** Beatty went to court against the name change. A federal judge, Christopher Cooper, ruled on May 29, 2026, that the board could not rename the building. "Congress gave the Kennedy Center its name, and only Congress can change it," he wrote. He ordered the signs with Trump's name taken down within 14 days. Many performers canceled their shows at the center, saying it had become political, and ticket sales fell.

**Closed.** Board members voted to close the building on September 15, 2026, minutes after Judge Cooper again blocked the name change, Anastasia Tsioulcas of NPR reported. Trump wrote that repairs would not begin unless a higher court allowed his name. In a court filing, the center's executive director, Matt Floca, pointed to falling plaster and decay under the roof. He extended the closure to September 30, 2026, and said he would review it each week, reporters at WTOP, a Washington radio station, wrote.

The building did not reopen on September 30. Engineers had found rust and water damage on most of the panels under the building's overhanging roof, which could fall on people below.

NBC News and ABC News reported on October 1, 2026, an email in which Floca told the staff that the main building would "remain temporarily closed" while engineers checked whether people could safely use it and get out of it in an emergency. He expected that check to take one to two weeks, and he called that "an assessment timeline, not a reopening date." Judge Cooper asked for weekly reports on the repairs.

**The Honors moved.** The center's leaders moved the 2026 Kennedy Center Honors, a yearly award show, to Capital One Arena in Washington for December 7, Newsweek reported on October 2. It was the first time in nearly 50 years that the show would be held outside the Kennedy Center.

**The texts.** Beatty's lawyers asked Judge Cooper on October 25, 2026, to order the government's lawyers to hand over text messages they had kept back. They included 19 texts between Floca and Trump's assistant Natalie Harp and about 180 between Floca and Commerce Secretary Howard Lutnick, the Associated Press reported. The judge did not rule right away. As of October 26, 2026, the main building was still closed, with no date set for it to reopen.

### Dolly Parton

> **Who:** A singer and songwriter from Sevier County, in the mountains of Tennessee, who wrote more than 3,000 songs and mailed free books to children.
>
> **When and where:** Born January 19, 1946, in a one-room cabin in Pittman Center, Sevier County, Tennessee. Moved to Nashville in 1964. Died August 25, 2026, in Nashville, at 80.
>
> **Movie:** *Dolly Parton: Here I Am* (2019), a documentary about her.

**She told Elvis Presley's manager no, and kept her song.**

Dolly Parton wrote more than 3,000 songs, and in 1974 she refused to give Elvis Presley's manager half the rights to one of them. She started a program that mails free books to children, one a month from birth to age five.

**The cabin.** She was the fourth of 12 children, born in a one-room cabin in Pittman Center, in Sevier County, Tennessee. Her father, Robert Lee Parton, farmed tobacco and could not read or write. He paid the doctor who delivered her with a sack of cornmeal. Her mother was Avie Lee Parton. From age six Dolly sang in her grandfather's church.

By ten she sang on a radio and television show in Knoxville. At 13 she made her first record and sang at the Grand Ole Opry. The day after she finished high school in 1964, she moved to Nashville.

**Porter Wagoner.** The country singer Porter Wagoner hired her for his weekly television show in 1967. Their duets made the country Top 10 for six years in a row. From 1969 Wagoner owned nearly half of Owe-Par, the company that she and her uncle Bill Owens had started to publish her songs.

Her first No. 1 single as a solo singer was "Joshua," which she wrote by herself. It reached the top of the country chart in February 1971. That same year she recorded "Coat of Many Colors," about her family's poverty. She wrote "Jolene" and "I Will Always Love You" within a few days of each other in 1973.

"I Will Always Love You" was her goodbye to Wagoner, and she left his show in 1974. The two later settled a lawsuit between them, and their 1980 album came out as part of that settlement.

**Saying no.** That year Elvis Presley wanted to record "I Will Always Love You." His manager, Colonel Tom Parker, told her that the songwriter always signed over half the publishing rights, the rights to the song itself, on any song Presley recorded. She said no. Whitney Houston recorded the song in 1992, and her record sold more than 24 million copies around the world. "I made enough money to buy Graceland," Parton said later, meaning Presley's home.

**Hits.** She wrote "9 to 5" for a 1980 film of the same name, in which she also acted. It reached No. 1 on the country and pop charts in February 1981. She sold more than 100 million records, had at least 25 No. 1 country songs, and won 11 Grammy Awards. She turned down the Presidential Medal of Freedom three times.

**Who owned what.** Ed Christman wrote in the magazine *Billboard* in August 2026 that Parton owned her own songs for her whole career. The records do not say how long Wagoner kept his share of Owe-Par, so they do not settle how that share fits with Christman's account. Her older recordings belong to Sony Music: the ones from her years with RCA, and probably from her Columbia years, about 23 albums in all. From 1995 she owned most of her new recordings, through her own record label.

**Dollywood.** She became a partner in a theme park in Pigeon Forge, Tennessee, which reopened as Dollywood on May 3, 1986. It has about 4,000 to 4,500 workers, more than any other employer in Sevier County. From 2022 Dollywood paid college costs for workers who chose to go.

**The Imagination Library.** She started the Imagination Library in Sevier County in 1995. The program's website states that she started it because her father could not read or write. Each child who signs up gets one free book a month in the mail, from birth to age five.

Her foundation pays the program's running costs, and its staff bargain down the price of the books. Local partners raise the money for the books and the mailing, and families pay nothing. By 2026 more than 300 million books had gone out in five countries.

**Gifts.** After wildfires burned homes near Gatlinburg, Tennessee, in November 2016, she paid $1,000 a month for six months through her My People Fund to more than 900 families whose homes had burned, and $5,000 in the last month.

She gave $1 million to Vanderbilt University Medical Center in Nashville in the spring of 2020 for research on the coronavirus. Her longtime friend Dr. Naji Abumrad had told her that researchers there were making progress. A research paper on Moderna's COVID-19 vaccine listed her fund among its supporters. US government money for that vaccine came to about $2.5 billion. After Hurricane Helene in 2024, she and her businesses gave $2 million.

**Her death.** Her husband, Carl Thomas Dean, whom she married in 1966, died on March 3, 2025. She went into the Vanderbilt-Ingram Cancer Center in Nashville on August 21, 2026, and died four days later. Her family did not say what kind of cancer she had. Her nephew Bryan Seaver, her head of security for more than 20 years, announced her death, as she had asked him to.

That day Representative Tim Burchett of Tennessee said, "Tennessee lost one of our greatest ambassadors in Dolly Parton." President Trump ordered flags at federal buildings flown at half-staff for a week. Her family asked people who wanted to honor her to support the Imagination Library. They held a private funeral on August 28, and she was buried beside her husband in Nashville.

**If you remember one thing:** Since 2000 most Americans have stopped buying their music and started streaming it, and the money from each play goes first to whoever owns the recording.

- 2001: Napster's owners shut it down after record companies sued.
- 2019: A music manager buys the masters of Taylor Swift's first six albums. She records four of them again and, in 2025, buys all six back.
- 2026: Record companies and musicians are in court against Suno over a computer program that makes songs.

**Next:** The chapter closing is below. Chapter 34, Storytelling Evolution, follows.

**The three questions, answered**

- Where did the banjo and the blues come from? The banjo came from West African instruments, and enslaved Black people played it in the colonies from at least 1736, about a hundred years before a white man played it on a stage. The blues grew out of the work songs and field calls of enslaved people and the songs of Black workers in the South after slavery, between about 1870 and 1900.
- Why did so many musicians make hit songs and still die poor? Many were paid a set fee and no royalty, as Bessie Smith was at $125 a side, or someone else put his name on their song, as Don Robey did on "Hound Dog." Others, like Stephen Foster, sold their rights to future payments for money right away.
- Who tried to stop people from playing their own music, and why? South Carolina lawmakers banned drums and horns in 1740, saying the sound could call enslaved people together to rise up. Spanish friars burned Pueblo masks in the 1600s to punish Pueblo people for keeping their own religion. Richard Henry Pratt gave Carlisle students brass horns to stop their drumming, at a school whose own paper gave its aim as "the complete transformation of the Indians." Federal rules from 1883 to 1978 punished Native religious dances, which the Secretary of the Interior had called "heathenish."

**What changed:** Music in this land began as songs one singer taught to the next, and by 2026 most of it reached listeners as streams that paid the owner of a recording less than half a cent a play.

**Five dates to keep**

- May 10, 1740: South Carolina lawmakers ban enslaved people from using drums and horns.
- 1843: Four white men in blackface perform in New York as the Virginia Minstrels.
- October 6, 1871: The Fisk Jubilee Singers set out on their first tour.
- August 10, 1920: Mamie Smith records "Crazy Blues," the first blues record to become a big hit.
- August 11, 1973: Kool Herc plays records at the Bronx party that people name as the start of hip-hop.

**Not known:** No one knows who first played the blues, or when.

**Where to go:** *The Old Plantation*, the earliest known painting of a banjo, is at the Abby Aldrich Rockefeller Folk Art Museum in Williamsburg, Virginia.

**Next:** Chapter 34, Storytelling Evolution. It asks how Americans acted out stories, from Native performance and the minstrel stage to film, television and video games.
