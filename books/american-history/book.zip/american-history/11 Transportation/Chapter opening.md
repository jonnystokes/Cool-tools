# Chapter 11: Transportation

**Chapter 11 of 37 · Transportation · 10 eras · about 75 minutes**

**Each new way of moving people and goods made trips faster or cheaper, and enslaved people and immigrant workers did much of the building, on land taken from Native nations.**

Eight Chinese workers laid the last stretch of track at Promontory Summit, in Utah, on May 10, 1869. It joined two railroad lines into the first one across the country, and a golden spike marked the spot. With it, a trip from coast to coast took about a week instead of about four months. Chinese workers had built the line's western part for less pay than white workers got.

Era by era, this chapter describes how people and goods moved, from foot trails and canoes before 1500 to jets, container ships and ride apps after 2000. Watch two numbers fall as the eras go by: how long a trip took and what it cost. Look for old routes under new ones, too. Many colonial roads began as Native paths, and so did part of the first federal highway. And keep an eye on who did the digging and the track-laying, whose land and homes the routes went through, and who was told where to sit.

**Three questions this chapter answers**

- How much faster and cheaper did travel get?
- Who built the new routes, and whose land and homes did they take?
- How did Black travelers fight the laws that made them sit apart?

**Five minutes?** Read "The Chinese workers" in 1850 to 1900.

**Can skip:** "Trains and Jeeps in World War II", "The minivan", "Ports, trains and bridges". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 2 minutes**

Nobody in North America hauled loads on wheels before 1500, and nobody rode a horse. People moved themselves and their goods on foot and by water, over trails and rivers that crossed the whole continent. The horses of the Americas had died out after the ice age. North of Mexico, no large animal was left that could pull a cart.

With no animal to pull a cart, people here had no use for one. In Mesoamerica, the region that is now Mexico and Central America, people made toys with wheels, but they did not use wheels to haul loads.

### Trails that became highways

Native people built and kept up long trails across the continent, and many of those trails later became colonial roads. Some of those roads became highways. Many trails had names. The Great Trail, also called the Great Path, was a network of footpaths that linked New England, the middle of the Atlantic coast and the Great Lakes. People who spoke Algonquian and Iroquoian languages, two families of related languages, used it.

**The Natchez Trace.** This route began as paths worn by bison walking to salt licks, places where animals lick salt from the ground, near present-day Nashville. Natchez, Choctaw and Chickasaw people followed the paths, widened them and kept them clear. They used them for trade, travel, war and talks with other nations. People have used the route for about 8,000 years.

People traded over these trails and rivers for thousands of years. As early as 6000 BC, they carried seashells and native copper, copper found pure in the ground, between the Great Lakes and the coast of the Gulf of Mexico.

### Canoes, portages and the travois

On the rivers and lakes, people traveled in two kinds of canoe. A dugout was one log that builders hollowed out with fire and tools. For thousands of years dugouts were the main boats of the Southeast and of the Eastern Woodlands, the forests that covered the eastern part of the continent. Some dugouts found in Wisconsin lakes are more than 4,000 years old.

**Birchbark.** In the Northeast and around the Great Lakes, people built canoes from the bark of birch trees. One or two people could carry one. It floated in shallow water, and its owners repaired it with materials from the forest. Builders made them in sizes from one-person boats to big canoes that carried freight, goods being shipped.

Where one river or lake ended, travelers lifted their canoes and carried them over land to the next, a crossing called a portage. Portages and trails linked the waterways into one network across the continent.

On the Great Plains, dogs dragged loads on a travois, which Chapter 10 describes. The travois was the usual way to move goods on the Plains before horses came.

## The 1500s

**Era 2 of 10 · The 1500s · about 3 minutes**

Spanish soldiers and colonists brought horses and wagons into what is now the United States in the 1500s, and they built a port in Florida, all on land where Native nations already lived. The first horses in the Southwest came north with Coronado's soldiers in 1540. The port, St. Augustine, began inside a Timucua town, where Spanish colonists took over the chief's council house in 1565. Juan de Oñate's colonists followed in 1598 with 83 wagons and carts, bound for Pueblo land in New Mexico.

### Horses, a port and 83 wagons

**Horses.** Christopher Columbus carried horses to the Caribbean islands on his second voyage, in 1493. In 1539 Hernando de Soto landed about 250 horses in Florida, on a march that Chapter 10 tells. The next year a Spanish commander, Francisco Vázquez de Coronado, led a long march north from the west coast of Mexico, from 1540 to 1542. His soldiers brought more than a thousand horses, the first in what is now Arizona. The march went on into New Mexico and the Great Plains.

**A port.** Spanish colonists built St. Augustine, in what is now Florida, in 1565, and it became a port. Spanish ships sailing between Spain and the Caribbean stopped there for supplies and for protection. People have lived there without a break ever since. It is the oldest European town and port on the mainland of the United States.

The colonists built it inside a Timucua town. Their leader, Pedro Menéndez de Avilés, landed at Seloy on September 8, 1565. Seloy was also the name of the town's chief, who answered to a greater chief. One count gives Menéndez about 1,500 soldiers and colonists, and another gives 800 colonists, including 24 women and an unknown number of enslaved Africans.

The priest with the Spanish ships wrote that the Timucua received the Spanish well and gave them their chief's large house on the riverbank. It was the chief's council house, the building where the town's leaders met. The Spanish took it over. Two of their captains had a ditch, a moat and a wall of earth built around it, and it became their first fort there. Chapter 1 tells what happened between the colonists and the Timucua after that.

**Wagons.** Juan de Oñate led a Spanish colony north from Santa Bárbara, in northern New Spain, the Spanish colony that included Mexico, in January 1598. About 400 men came, about 130 of them with families. They brought 83 wagons and carts and more than 7,000 farm animals. In late April the long line of wagons, people and animals reached the Rio Grande near El Paso del Norte.

The land the colony moved into was the homeland of the Pueblo peoples. Oñate claimed New Mexico for Spain on April 30, 1598, in a ceremony the Spanish called La Toma, "the taking." In July he set up the colony's headquarters, which the Spanish called San Juan de los Caballeros, at the Tewa town of Ohkay Owingeh on the upper Rio Grande. Chapter 10 tells about the colony's water mills.

The route the wagons followed became El Camino Real de Tierra Adentro, Spanish for "the royal road of the interior." It ran about 1,600 miles from Mexico City to northern New Mexico.

## The 1600s

**Era 3 of 10 · The 1600s · about 3 minutes**

Boats carried most of the goods in the English colonies of the 1600s, from canoes and small open boats called shallops to ships that sailed along the coast from one colony to another. The leaders of the Massachusetts colony licensed a ferry across Boston's harbor in 1631. On land, colonists followed paths that Native people had made long before, and a rider carrying mail began using them between New York and Boston in 1673.

### The Boston Post Road, on Native paths

The first post rider, a man on horseback who carried letters, left New York for Boston in January 1673. The governor of New York, Francis Lovelace, had pushed for the route along with John Winthrop Jr. of Connecticut. The rider went by way of New Haven, Hartford, Springfield and Worcester. The trip was about 250 miles and took about two weeks. The path that he and later riders used grew into the Boston Post Road.

In time the road had two main routes between New York and Boston, an upper road inland and a lower road near the shore, and both followed Native paths.

**The upper road.** The first rider's route, through Hartford, Springfield and Worcester, became the upper road. Between Boston and the Connecticut River it followed the Old Connecticut Path and the Bay Path, Native trails from Massachusetts Bay to the river. Nipmuc people carried corn along them to Massachusetts Bay in the early 1630s and traded it there for copper, iron goods and wool cloth. Thomas Hooker led the members of his church along the same path in 1636 to found the town of Hartford.

**The lower road.** It ran near the shore, through New London and Providence. That stretch followed the Pequot Path, which Narragansett and Pequot people had traveled for hundreds of years. The path ran about 69 miles, from Providence to New London, Connecticut, and English settlers kept using it until it became part of the lower road.

**What Roger Williams saw.** The English colonist Roger Williams walked the Pequot Path in 1636. Along 20 miles of it he passed about a dozen Narragansett villages. He wrote: "It is admirable to see what paths their naked hardened feet have made in the wilderness in the most stony and rockie places" (by admirable he meant worth wondering at).

### Edward Converse

> **Who:** A Puritan settler and church deacon who ran the first ferry between Charlestown and Boston.
>
> **When and where:** Boston harbor, licensed June 14, 1631. Lived 1589 to 1663.

**The colony's rulers let him charge two pence a passenger.**

Edward Converse ran a ferry across the harbor between Charlestown and Boston, and the record that licensed it still exists. The members of the Massachusetts Court of Assistants, the colony's ruling council, wrote it on June 14, 1631: "Edw: Converse hath vndertaken to sett vpp a fferry betwixte Charlton & Boston." That is how people spelled English then. In modern spelling, Converse had taken on the job of setting up a ferry between Charlestown and Boston.

**The fares.** The same men set his prices. A passenger crossing alone paid two pence, or two of the small English coins called pennies. When two or more crossed together, each paid one penny. Their license was a charter, a written permission from a government.

**Two firsts.** A history page from the West End Museum in Boston states that Converse started his ferry in 1630, the first on that crossing, and ran it for about ten years. At the time it was the only way across the river there. The history page of Boston's transit agency, the MBTA, names a different first. It states that Thomas Williams opened the first chartered transit service in the United States in 1631, with his own ferry to Charlestown.

Converse was a Puritan, one of the English Christians who started the Massachusetts colony on land where Native people already lived. He was also a deacon, a church officer who helps the minister. The Charlestown ferry earned 50 pounds in English money in 1639. The next year the colony's leaders gave the ferry's earnings to Harvard College.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 4 minutes**

Stage lines for passengers and a big freight wagon called the Conestoga came into use in the English colonies between 1700 and 1750. Pennsylvania wagon builders made the Conestoga to haul freight to Philadelphia, and New Jersey officials licensed one of the first stage lines in 1706. The roads were still rough, as Sarah Kemble Knight wrote in her journal after she rode from Boston to New York in 1704.

### The wagon and the people it was named for

The Conestoga wagon was a big freight wagon from Lancaster County, Pennsylvania. Its name first shows up in writing on December 31, 1717. That day James Logan, who had been William Penn's secretary, wrote in his account book that he had bought a "Conestogoe Waggon."

German and Swiss wagon builders along the Conestoga River worked out the design. The wagon's bed curved down toward the middle, so the load settled toward the center, and a white cloth cover stretched over hoops above it. Drivers hitched teams of four to six horses to it and hauled loads more than 60 miles to Philadelphia. People in the East used it as their main freight wagon well into the age of railroads.

**The name.** The wagon took its name from the Conestoga River and from the Conestoga people who lived in Lancaster County. In December 1763 a mob of men from Paxton township, known as the Paxton Boys, killed the last of the Conestoga people. First they killed the six people at home at Conestoga Manor, a settlement under the colony's protection: three men, two women and a boy.

Lancaster officials then put the survivors in the county workhouse, a locked building where people who broke small laws were held and made to work, to protect them. On December 27 the mob broke in and killed them, 14 or 16 men, women and children by different counts. The mob killed about 20 Conestoga people in the two attacks, and no one was ever put on trial for it. Chapter 2 tells the killings in full.

### Stage lines, log roads and the Great Wagon Road

A stage line carried passengers in a wagon or coach along a fixed route between towns. New Jersey officials gave Hugh Huddy a patent, a legal right, to run one between Burlington and Perth Amboy in 1706. Coaches ran between New York and Philadelphia from 1732, though not on a fixed schedule.

New lines opened from Trenton to New Brunswick in 1738 and from Bordentown to New York in 1740. By 1756 several regular coach services ran between New York and Philadelphia, and the trip took about three days.

Where a road crossed swampy ground, builders laid logs side by side across it. People called it a corduroy road, after a cloth with raised ribs.

**The Great Wagon Road.** It ran from Philadelphia down the Shenandoah Valley of Virginia toward Augusta, Georgia, and colonists used it heavily from the 1720s on. Accounts give its length as about 730 miles or almost 800, depending on where the count ends.

South of Lancaster and York, in Pennsylvania, the road roughly followed a route that Europeans called the Great Warriors' Path. Native people had made that path to travel through the Shenandoah Valley, and they still valued it.

**The Treaty of Lancaster.** Leaders of the Six Nations of the Iroquois, six Native nations joined in one league, met officials of Pennsylvania, Virginia and Maryland in the town of Lancaster in June 1744. There the two sides made a treaty, a written agreement between nations. In it the Iroquois leaders gave up their use of the path and their claims to land in the Shenandoah Valley.

The two sides later disagreed about how much land the treaty covered. Virginia's leaders claimed land as far as the Ohio River and beyond it. The Iroquois said they had given up much less.

**Who built the roads.** In Virginia, colonists built and repaired the roads themselves, under road laws that the colony's lawmakers passed in 1632 and 1657 and added to in 1661. Each year the members of each county court chose an overseer of the highways, a man put in charge of the roads. He was usually given all the "Labouring Male Titheables" who lived on or near the road.

Titheables, or tithables, were the people counted for a tax on each person: all free men 16 and older, and all enslaved people 16 and older, women as well as men. The road orders required the working men among them to bring their own tools, wagons and teams of animals and to work six days a year on the roads. The surviving road orders do not say how many of these men were enslaved.

### Sarah Kemble Knight

> **Who:** A Boston businesswoman who rode from Boston to New York and wrote down what the road was like.
>
> **When and where:** October 1704, by road from Boston to New Haven and on to New York. Her journal was published in 1825.

**She wrote down which bridges she was afraid to cross.**

Sarah Kemble Knight traveled with post riders, the men who carried the mail, and hired guides from one town to the next. She crossed some rivers by canoe in the dark and others at fords, shallow places where people and horses can wade across.

Her journal is an eyewitness record of the road itself. It was published in 1825, more than a hundred years after her ride.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 3 minutes**

Around Philadelphia, between 1750 and 1800, investors paid for a road and charged travelers a fee to use it, and an inventor ran a boat pushed by a steam engine. The investors, people in and around Philadelphia and Lancaster, put their money into the road company in 1792. Their Philadelphia and Lancaster Turnpike, finished in the mid-1790s, was the first long-distance road of its kind in the country.

John Fitch's steamboat carried paying passengers on the Delaware River on a schedule in 1790, seventeen years before Robert Fulton's steamboat ran on the Hudson.

### The first turnpike

The Philadelphia and Lancaster Turnpike Company got its charter in 1792 to build a turnpike, a road whose owners charge travelers a fee, called a toll, at gates along the way. Work on the road began that year. People in and around Lancaster and Philadelphia bought 1,000 shares of the company's stock, pieces of ownership in the company, at $300 each. A Philadelphia merchant, William Bingham, led the company.

The road ran 62 miles between Philadelphia and Lancaster, mostly along the older Philadelphia-Lancaster Road, the first stretch of the Great Wagon Road. Its surface was broken stone and gravel. Some accounts say it was in use in 1794, and most say 1795.

**Known:** The records name the people who bought shares and the company's president.

**Not known:** who broke the stone, or how many men did the work.

The Lancaster Turnpike was the country's first long-distance engineered toll road, planned and built to a design, with a prepared surface. After it succeeded, people built many more toll roads, the historian Charlene Mires writes. By the 1830s the country had almost 12,000 miles of turnpikes, nearly 200 times the length of the first one.

### A steamboat before Fulton's

John Fitch tested a steamboat on the Delaware River on August 22, 1787, while delegates to the Constitutional Convention watched. They were the men meeting in Philadelphia that summer to write the Constitution of the United States. A steam engine on Fitch's boat worked rows of oars that pushed the boat through the water, and it moved upriver, against the current, at about three miles an hour.

Fitch's boat, the *Experiment*, carried passengers on a schedule in the summer of 1790. It was the first steamboat service anywhere in the world to carry paying passengers on a schedule. The boat carried up to about 30 passengers at a time on the Delaware, between Philadelphia and New Jersey towns such as Trenton, Burlington and Bordentown, and also to Wilmington.

### John Fitch

> **Who:** The builder of a working steamboat in 1787 and of the first steamboat service anywhere to carry paying passengers on a schedule.
>
> **When and where:** The Delaware River, 1787 to 1790. Died 1798.

**George Washington backed a rival's steamboat, not his.**

John Fitch had little money when he decided, at about 41, that a boat driven by steam could travel upriver against the current. The country had no national patent law yet. So in 1786 he went from state to state asking lawmakers for a patent, the legal right to be the only one to build and run such boats.

Benjamin Franklin, who had his own ideas about powering boats, showed little interest. Virginia's lawmakers turned Fitch down in favor of the boat of a Virginian, James Rumsey, which George Washington backed. New Jersey's lawmakers gave Fitch the only right to run steamboats on that state's waters for 14 years.

**Losing out.** His 1790 passenger service failed when too few people bought tickets, the machinery broke down and the people who had put money into his boats stopped paying. In 1791 the members of the federal patent board, led by Thomas Jefferson, gave steamboat patents to both Fitch and Rumsey and would not say that Fitch had been first. Fitch sailed to France and England in 1793 to look for backers and found none.

In 1796 he went to Kentucky, where he had claimed land, and found squatters, people living on it without his permission. He killed himself in Bardstown, Kentucky, in 1798, nine years before Robert Fulton's steamboat began running on the Hudson.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 13 minutes**

Moving people and goods got much faster and cheaper in the first half of the 1800s, on steamboats, canals and the first railroads. Robert Fulton's steamboat went from New York City to Albany in 32 hours in 1807, a trip that took a sailing boat about four days. After the Erie Canal opened in 1825, hauling a ton of goods from Buffalo to New York City cost under $10, against about $100 by wagon.

**Who did the work.** American-born laborers and Irish immigrants dug the Erie Canal. In the South, enslaved Black men dug most of the Dismal Swamp Canal, and enslaved people built most of the railroads. Owners rented the men out to the builders and kept their pay, and the men running Southern railroad companies also bought enslaved people outright.

### Steamboats on the rivers

Robert Fulton's North River Steamboat left New York City on August 17, 1807, and reached Albany, 150 miles up the Hudson River, 32 hours later. Sailing boats called sloops took about four days to make the same trip. Fulton's boat began carrying passengers on a regular schedule right away. People later called it the *Clermont*.

Many later accounts say that people who doubted the boat called it "Fulton's Folly" (a folly is a foolish project). Few records from 1807 show anyone using that name. It comes from stories told afterward.

**The western rivers.** Within a few years, steamboats were running on the Ohio and Mississippi Rivers. Twenty-one steamboats arrived at New Orleans in 1814, and 2,770 arrived in 1846, more than 130 times as many. A steamboat covered about 50 miles a day in the 1810s and about 100 by the 1820s.

Much of what the boats carried was cotton, grown and picked by enslaved people whom their enslavers forced to work. Farms in the state of Mississippi grew 20 million pounds of cotton in 1820 and 535 million pounds in 1860. Before the Civil War, more than half of all the cotton grown in the United States passed through New Orleans.

**Boilers.** Steamboat boilers, the tanks where water was heated into steam under pressure, exploded again and again on the Mississippi and the rivers that flow into it in these years. The explosions killed thousands of people.

### Robert Fulton

> **Who:** The man who made the steamboat a business that lasted.
>
> **When and where:** The Hudson River in New York, from August 17, 1807.

**His second boat steamed 1,800 miles from Pittsburgh to New Orleans.**

Robert Fulton's partner, Robert Livingston, paid for the building of his boats. Livingston held a monopoly on steamboats in New York, which meant that by law no one else could run them there.

Fulton and Livingston paid for a second boat, the *New Orleans*, built at Pittsburgh. It left Pittsburgh on October 20, 1811, traveled more than 1,800 miles down the Ohio and Mississippi Rivers, and reached New Orleans on January 10, 1812. It was the first steamboat on the western rivers.

### The National Road

The National Road was the first highway in the United States built entirely with money from the federal government, the national government in Washington. Members of Congress approved it in 1806, while Thomas Jefferson was president. Work began at Cumberland, Maryland, in 1811. The road reached Wheeling, on the Ohio River, in 1818, and by the 1830s it went on to Vandalia, Illinois, where the federal money stopped.

**An older path.** West of Cumberland, the road followed a path that a Delaware chief named Nemacolin and a colonist named Thomas Cresap marked and cleared in 1749 or 1750. It ran between the Potomac and Monongahela Rivers, from the site of Cumberland to the mouth of Redstone Creek, where Brownsville, Pennsylvania, now stands.

George Washington used the path on his first trip to the west, and General Edward Braddock's army used it in the French and Indian War. People called it Braddock's Road until the National Road was built on the same route.

**Who built it.** Irish laborers built sections of the National Road for six dollars a month.

### How much did the Erie Canal save?

Hauling a ton of goods from Buffalo to New York City cost about $100 by wagon. On the Erie Canal it cost under $10, and some accounts put it at about $6 a ton.

The Erie Canal was a waterway that people dug so boats could travel where no river ran. Workers dug it from 1817 to 1825, and it stretched 363 miles, from Albany on the Hudson River to Buffalo on Lake Erie. While it was being dug, people who mocked it called it "Clinton's Ditch," after DeWitt Clinton, who pushed for it.

The canal opened on October 26, 1825, and cost about $7.1 million. The tolls that boats paid to use it covered the cost of building it in about nine years.

**The hoggees.** Boys drove the mules that pulled the canal boats, and people called them hoggees. Many were about 10 years old. A hoggee walked 18 to 20 miles a day, six hours on and six hours off, for about $8 to $10 a month. Many hoggees were cheated out of their pay. Columns on the canal boys in the Lockport *Union-Sun & Journal*, a newspaper in a canal town, tell of the cheating but do not name the men who did it.

### Who dug the canals, and whose land they crossed

American-born workers and Irish immigrants dug the Erie Canal. Between 2,000 and 3,000 laborers were working on it in 1818, with a horse for every second man. Ads in Ireland that called for workers promised wages of 8, 10 or 12 dollars a month, and meals came on top of that pay: meat three times a day, and liquor.

**The pay.** Many men were paid by the day instead, 75 cents to $1.50 a day, and less as more workers arrived. They got no pay on rainy days, but they still had to pay for their lodging. Some contractors, the men who ran sections of the work, started fights among the workers to get out of paying them.

At Rochester, a contractor named William Brittin brought about 30 convicts, people serving prison sentences, from Auburn State Prison to work. Many escaped, and Irish workers took their places.

**Malaria.** The canal crews reached the Montezuma Marshes, wet ground full of mosquitoes, in 1819. The mosquitoes spread malaria, a disease that brings high fevers and chills again and again. The canal commissioners, the state officials in charge of the canal, reported that about 1,000 workers fell sick between the middle of July and October 1, 1819. Many died, and no one kept a count of the dead.

**Whose land.** The Erie Canal ran through the homelands of the Oneida, Onondaga, Cayuga and Seneca nations. The Oneida Indian Nation's history of the canal states that the Oneida lost the land for it through a series of 27 treaties with the State of New York, and it describes all 27 as illegal. New York State officials took parts of the Seneca Oil Spring Reservation, land set aside for the Seneca, from 1858 to 1871 for a canal reservoir, a lake made to store water.

**In the South.** Owners rented out enslaved men to dig canals and kept the men's pay. Enslaved men dug most of the Dismal Swamp Canal, which runs 22 miles from Deep Creek, Virginia, to South Mills, North Carolina, from 1793 to 1805.

Before the canal, George Washington and his brother John Augustine Washington ran a business called the Dismal Swamp Company. Through it they bought 54 enslaved men, women and children to dig ditches and cut timber in the swamp.

### DeWitt Clinton

> **Who:** The New York governor who pushed the Erie Canal through while people mocked it.
>
> **When and where:** New York State, 1811 to 1825.

**He predicted the Iroquois would be gone from New York.**

DeWitt Clinton pushed for the Erie Canal while critics called it "Clinton's Ditch" and "Clinton's Folly." In 1811 he was the mayor of New York City and a new canal commissioner, one of the state officials planning the canal. Its planned route ran through the land of the Iroquois, six Native nations joined in one league and also called the Six Nations.

**The speech.** That year Clinton spoke to the New-York Historical Society. He predicted that "before the passing away of the present generation, not a single Iroquois will be seen in this state." He was wrong. More people of the Six Nations live in New York now than lived there at the end of the American Revolution.

**The wedding of the waters.** As governor, Clinton rode on the *Seneca Chief*, the first boat to travel the whole length of the canal, in 1825. At the opening he poured water from Lake Erie into New York harbor, and people called it the "wedding of the waters."

### James Garfield, canal boy

> **Who:** A 16-year-old who worked on an Ohio canal boat. He later became president of the United States.
>
> **When and where:** The Ohio and Erie Canal, 1848, on the boat *Evening Star*.

**At 16 he ran away to drive a canal boat's mules.**

James Garfield was 16 when he ran away in 1848 to work on a canal boat called the *Evening Star*. The only job open was driving the mules that pulled the boat. The boat carried freight, goods being shipped, on the Ohio and Erie Canal, and for about six weeks he helped haul coal, copper ore and wood.

Later he caught malaria and went home. His six weeks on the canal made a strong picture for his campaign for president in 1880. Writers of biographies for that campaign told stories of him falling into the canal, fourteen times by their count. That number comes from those later stories, not from the record of his time on the boat.

### Moses Grandy

> **Who:** An enslaved man who ran boats through the Dismal Swamp canals, bought his own freedom three times, and described the men who dug the canals.
>
> **When and where:** Camden County, North Carolina, and the canals to Norfolk, Virginia, from the early 1800s. His book about his life was published in London in 1843.

**He paid for his own freedom three times.**

Moses Grandy was born into slavery in Camden County, North Carolina, around 1786. His owners hired him out each year to other men. He worked canal boats that carried shingles, boards and other freight through the Dismal Swamp canals to Norfolk.

**Three prices.** The first time, Grandy paid $600 to his owner, who kept the money and sold him to a man named Trewitt.

The second time, Grandy paid Trewitt $600, money he earned over two and a half years. But Trewitt had pledged Grandy as security for a loan, which meant the lender could take Grandy if the loan was not paid back. When Trewitt's business failed, the lender took Grandy and sold him to Enoch Sawyer, who put him to work in the fields.

The third time, a captain from Deep Creek, Edward Minner, lent Grandy $650, and Sawyer set him free for that price. Grandy paid Minner back over three years.

**His wife.** While Grandy worked on the canal, his wife's owner sold her. A group of enslaved people passed along the road beside the canal, and she called out to him. The man who had bought her, Mr. Rogerson, pulled out a pistol and said he would shoot Grandy if he came near the wagon. Grandy wrote: "I have never seen or heard of her from that day to this."

**The diggers.** Grandy also described the enslaved men who dug the canals. They worked "up to the middle or much deeper in mud and water, cutting away roots and baling out mud" (baling out means scooping out). They slept in open huts, still covered in mud, with no bedding. Once a month their owners came to collect the men's pay.

An overseer named Wiley M'Pherson, the man in charge of the workers, gave every man the same amount of digging each day. When men had not finished the day before, M'Pherson tied them up and flogged them. Flogging means whipping a person's bare back until the skin splits.

Then he had "pork or beef brine," the salt water used to keep meat, put "on their bleeding backs, to increase the pain." He left men tied all day with their feet barely touching the ground, while flies and mosquitoes settled on the cuts.

Grandy wrote: "I have seen him flog slaves with his own hands, till their entrails were visible" (entrails are the organs inside the body). He went on: "I have seen the sufferers dead when they were taken down. He never was called to account in any way for it."

**After freedom.** Grandy later married again. He lived in Boston, sawed wood, worked in coal yards, loaded and unloaded ships, and went on more voyages. He saved enough to buy his second wife out of slavery in Virginia, and she joined him in Boston.

He raised $450 to buy his son's freedom. His daughters in New Orleans paid for their own freedom, $1,200 for each of them. His book was sold to raise money for his relatives who were still enslaved.

### The first railroads

The Baltimore and Ohio Railroad was the first railroad in the United States to carry both passengers and freight on a schedule for anyone who paid. Its builders laid the first stone on July 4, 1828. Its first 13 miles of track, from Baltimore to Ellicott's Mills, opened in 1830.

**A legend.** In a well-known story, Peter Cooper's steam engine, the *Tom Thumb*, raced a horse pulling a railroad car on August 28, 1830, and lost when a belt on the engine slipped. The story comes from a talk that John H. B. Latrobe gave in 1868, 38 years later. No record from 1830 shows that the race took place, and the Baltimore and Ohio Railroad Museum's page on the *Tom Thumb* describes the race as a legend.

New York State's first steam passenger train ran on August 9, 1831, behind a locomotive, or train engine, named the *DeWitt Clinton*. It went 16 miles from Albany to Schenectady in about an hour, on the Mohawk and Hudson line.

**In the city.** Abraham Brower ran a horse-drawn coach called an omnibus on the streets of New York City from 1827. The *John Mason*, a horse-drawn car that rolled on rails, began carrying passengers in lower Manhattan for the New York and Harlem Railroad on November 14, 1832. It was the first street railway in the country.

**Who built the Southern railroads.** In the South, enslaved people built most of the railroads. The men running Southern railroad companies bought hundreds of enslaved men between the ages of 16 and 35 as early as 1841, and in the 1850s they bought or rented enslaved workers in groups of hundreds.

The historian Theodore Kornweibel Jr. found enslaved workers on 85 of the 113 railroads in the Confederate states, the Southern states that later fought the United States in the Civil War. Southern railroad companies owned about 15,000 enslaved people in 1860, and women and children were among them.

The president of the Mississippi Central Railroad told the people who owned shares in the company in 1855 that "the slave is preferable to free labor, and far better adapted to the construction of railways in the south." By free labor he meant workers who were not enslaved.

**If you remember one thing:** Steamboats, canals and the first railroads made moving people and goods far faster and cheaper, and in the South enslaved people did much of the digging and track-laying.

- 1807: Fulton's steamboat reaches Albany in 32 hours. Sloops took about four days.
- 1825: The Erie Canal opens. Hauling a ton from Buffalo to New York City drops from about $100 by wagon to under $10.
- 1841: The men running Southern railroad companies are buying enslaved men by the hundreds.

**Next:** After 1850 railroad builders pushed track across the whole country, through the homelands of many Native nations.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 13 minutes**

Railroad builders laid track across the whole country in the second half of the 1800s. The country had about 9,000 miles of railroad track in 1850 and more than 190,000 by 1900, more than twenty times as much. Counts for 1900 run from about 193,000 to 215,000 miles, depending on whether side tracks are counted.

**Coast to coast.** The first railroad across the country was finished in 1869. Central Pacific managers hired about 10,000 to 12,000 Chinese workers to build its western part. The tracks crossed the lands of the Cheyenne, Lakota, Arapaho, Shoshone and Paiute nations.

In the cities, streetcars ran on rails laid in the streets, and by the end of the century the companies that ran them were switching from horse-drawn cars to electric ones. Many Americans, women among them, were riding bicycles.

### Mark Twain, steamboat pilot

> **Who:** Samuel Clemens, who steered steamboats on the Mississippi River before he wrote books as Mark Twain.
>
> **When and where:** The Mississippi River. He got his pilot's license on April 9, 1859.
>
> **Movie:** *Mark Twain* (2001), a documentary by Ken Burns about his whole life. PBS showed it in January 2002.

**"Mark twain" was a river call meaning twelve feet of water.**

Steamboats still ran on the Mississippi River while the railroads spread. Samuel Clemens was a licensed steamboat pilot, the person who steers the boat, on the Mississippi. He got his license on April 9, 1859, when he was 23. He piloted boats until 1861, when the Civil War began and traffic on the river stopped.

He took his pen name from a call used on the river. A leadsman, the crew member who measured the depth of the water, called the depth out to the pilot. "Mark twain" meant two fathoms, and a fathom is six feet, so the call meant twelve feet of water. In 1883 he published *Life on the Mississippi*, a book about his years as a pilot.

### Cornelius Vanderbilt

> **Who:** A ferryman who moved his money from steamboats into railroads and left the largest American fortune of his time.
>
> **When and where:** New York, 1810 to 1877.

**The ferryman of 1810 died in 1877 with about $100 million.**

Cornelius Vanderbilt had owned steamboats, and early in the 1860s he moved his money into railroads. In 1867 he took control of the New York Central Railroad, in the East. He joined the New York Central with his Hudson River Railroad on November 1, 1869, and in 1871 he opened Grand Central Depot, a train station in Manhattan.

**The ferryman.** Vanderbilt had started at 16, in 1810, carrying freight and passengers between Staten Island and Manhattan in a periauger, a shallow sailboat with two masts. Other boat captains called him "the Commodore," the title of a navy officer who commands a group of ships, at first as a joke.

**Two stories.** Accounts of how he got the boat differ. One says he borrowed $100 from his mother and named the boat *Swiftsure*. The first account of his life, printed in 1853, says the boat was his father's and he kept half the profit. The website Biography.com describes the story of the young ferryman as a legend.

When he died in 1877, he left the largest American fortune of his time.

### The railroad across the continent

Two companies built the first railroad across the country. Union Pacific crews built west from Omaha, Nebraska, while Central Pacific crews built east from Sacramento, California. The two lines met at Promontory Summit, Utah, on May 10, 1869.

**Land and loans.** Members of Congress voted to give the two companies land and loans, and President Abraham Lincoln signed their Pacific Railroad Act on July 1, 1862. Under it, each company got 6,400 acres of public land, ten square miles, for every mile of track it built. Each also got up to $48,000 in government bonds, a kind of loan, for every mile. The top rate was for miles built through mountains.

The act also stated: "The United States shall extinguish as rapidly as may be the Indian titles to all lands falling under the operation of this act" (to extinguish a title means to end someone's ownership of land). With those words, the lawmakers directed federal officials to end Native nations' ownership of the land along the railroad as fast as they could.

Members of Congress voted to give railroads about 130 million acres of federal land from 1850 to 1871, and some counts run as high as 175 million acres. State lawmakers gave railroads about 51 million acres more.

### Whose land the railroad crossed

The companies' builders and US officials took land from many Native nations while the two lines were built, and they drove people from their homes. Among those nations were the Cheyenne, Lakota (also called Sioux), Arapaho, Shoshone and Paiute. Historians at the Utah Division of State History count 15 Native homelands that the track crossed.

**The bison.** The Lakota, Arapaho and Cheyenne hunted bison, also called buffalo, for food, shelter and trade. As the railroad crews pushed west, soldiers, railroad workers and travelers hunted the bison too. National Park Service writers state that the number of bison fell from tens of millions in the early 1800s until they had almost died out.

**Sand Creek.** The railroad crews worked in the middle of a war between the US Army and the Cheyenne, Arapaho and Lakota nations. US soldiers on horseback led by Colonel John Chivington attacked a camp of Cheyenne and Arapaho people at Sand Creek, in Colorado, on November 29, 1864. The camp flew a US flag and a white flag.

The soldiers killed about 230 people, most of them women and children, and the people they killed were not armed. Britannica and the National Park Service give that count, and PBS writers give 150. Chapter 2 tells Sand Creek in full.

**Striking back.** Cheyenne, Arapaho and Lakota fighters struck back for Sand Creek. They burned the town of Julesburg, Colorado, on January 7, 1865, and cut the telegraph line, the wire that carried messages by electric signals.

**Guards for the crews.** Six days later, on January 13, 1865, four army units of Pawnee soldiers, called companies, joined the US Army under Major Frank J. North. Union Pacific managers and US officials hired hundreds of Pawnee, who guarded the work crews alongside the Army. Some Paiute people worked for the Central Pacific.

The fighting reached the tracks. At Plum Creek, Nebraska, on August 27, 1867, Cheyenne men pulled up railroad track, wrecked a work train and killed all but one of its crew.

### The Chinese workers

Central Pacific managers hired about 10,000 to 12,000 Chinese workers from 1865 to 1869. Most came from Guangdong, a province in southern China. The Chinese workers were paid about $35 a month, and they had to buy their own food and housing. White workers got about $42 a month, plus housing.

**The dead.** The Central Pacific's managers kept no record of the Chinese workers who died, so no one knows how many there were. Avalanches, masses of snow sliding down the mountains, killed workers in the winter of 1866 to 1867, when 44 storms hit. In one, snow carried away the camp at Strong's Canyon.

Blasts of black powder and nitroglycerin, explosives used to cut through rock, killed others. Smallpox, a disease that spreads from person to person, killed more in 1868 and 1869.

Guesses of the number run from about 50 into the thousands. On June 30, 1870, a writer at the *Sacramento Union* reported "about fifty." The same day, a writer at the *Sacramento Reporter* told of "the accumulated bones of perhaps 1,200," about 20,000 pounds of bones being shipped home to China. Researchers on the online forum of the Central Pacific Railroad Photographic History Museum estimate 100 to 150 dead, and other estimates run to hundreds or thousands.

**The strike.** Chinese workers in the Sierra Nevada mountains went on strike on June 25, 1867, which means they stopped work to demand better terms. Estimates of how many struck run from 2,000 to 5,000. They asked for $40 a month instead of $35, for workdays of no more than ten hours, and for shorter shifts in the cramped tunnels. It was the largest strike by workers in the country up to that time.

The construction boss, Charles Crocker, and his foreman, James Harvey Strobridge, who ran the work crews, cut off food and supplies to the Chinese camps. After a week with little food, Crocker told the strikers that men who went back at once would only be fined. Men who stayed out would lose all their pay for June.

Most men, weak from lack of food, went back. The men who refused faced a group of armed white men, and work started again. Crocker gave the strikers no raise, though pay for experienced men later rose a little, according to the Library of Congress.

**Ten miles in a day.** Crews laid 10 miles and 56 feet of track in one day on April 28, 1869. Eight Irish workers carried the rails, and several thousand Chinese workers did the rest of the work.

**The last track.** Twelve days later, on May 10, 1869, a different crew of eight, all of them Chinese, laid the last track at Promontory Summit, joining the two lines, and a golden spike marked the place. Three of those eight, Ging Cui, Wong Fook and Lee Shao, rode on a float at the celebration of the railroad's 50th anniversary on May 10, 1919.

### Hung Wah

> **Who:** The leading Chinese headman on the Central Pacific.
>
> **When and where:** The Central Pacific Railroad, from January 1864.

**The payroll names him, and not most of his workers.**

Hung Wah is one of the few Chinese railroad workers whose names appear in the records. The company's payroll, its list of the people it paid, usually named only headmen, the men who led the Chinese work gangs. The names of most of the thousands of Chinese laborers are not in the records.

Hung Wah first appears on the Central Pacific's payroll in January 1864. With another headman, Ah Toy, he supervised the railroad's first Chinese crew, about 23 men. He became the leading Chinese headman on the line, over hundreds of Chinese workers and at times thousands. He handled the workers' pay and their living arrangements, and he dealt with the company for them.

### Clocks, sleeping cars and danger on the railroads

**Time zones.** Railroad managers in the United States and Canada began using standard time zones, regions where all clocks show the same time, on November 18, 1883. Before then, each railroad company ran its trains by its own clocks. William F. Allen, the editor of the *Traveler's Official Railway Guide*, a book of train schedules, drew up the plan.

On the day of the switch, railroad workers reset every railroad clock to the new time, even clocks that had already passed noon. In those places noon came twice, so people called it "the day of two noons." Members of Congress did not vote time zones into law until the Standard Time Act of March 19, 1918.

**Sleeping cars.** George Pullman built the *Pioneer*, his first sleeping car built for luxury, in 1865. It had upper beds that folded away and seats that pulled out. His company, the Pullman Palace Car Company, began in 1867.

**Danger.** About 8.5 of every 1,000 American trainmen, the workers who ran the trains, were killed on the job in 1889, twice the rate in Britain.

In the same year, 1.73 of every 1,000 trainmen died while coupling, the job of joining railroad cars together.

With the old link-and-pin coupler, a brakeman, the crew member who set the brakes and joined the cars, had to stand between two moving cars to join them. Mangled hands were known as "the badge of the experienced worker."

**Safer equipment.** Safer couplers and brakes existed for years before lawmakers required railroad owners to use them. Eli Janney got a patent, the legal right to be the only one to make and sell an invention, for an automatic coupler in 1873. It joined cars without a worker standing between them. George Westinghouse's air brake existed from 1869. A pump on the locomotive pushed air through hoses to every car, and when the engineer opened a valve, the air set the brakes on all the cars at once.

Members of Congress passed the Safety Appliance Act in 1893. Under it, railroad owners had to put automatic couplers and air brakes on trains that crossed state lines, starting in 1900. Accidents while coupling cars fell from about 11,000 in 1892 to about 2,000 in 1902, while the number of railroad workers grew.

### Who decided where Black passengers sat?

Train crews and lawmakers decided where Black passengers could sit. Ida B. Wells had a first-class ticket on a train in Tennessee in 1884, but the train crew ordered her into the car for Black passengers. She refused, and they forced her off the train. She sued the railroad and won $500 in a Tennessee court. The judges of the Tennessee Supreme Court threw out that decision in 1887.

**Plessy.** Louisiana lawmakers passed the Separate Car Act on June 10, 1890. Under it, railroads had to provide "equal but separate" cars for Black and white passengers. A passenger who broke the law could be fined $25 or jailed for 20 days.

Homer Plessy, a shoemaker in New Orleans, offered to test the law. To test it, he would break it on purpose so that judges would have to decide whether the law was allowed. He bought a ticket on the East Louisiana Railroad on June 7, 1892, and sat in the car for white passengers. The railroad's officials agreed to the test, because separate cars cost the company money. A private detective hired by the group planning the test, the Citizens' Committee, arrested him.

Judge John H. Ferguson ruled against Plessy. On May 18, 1896, the justices of the US Supreme Court ruled against him too, 7 to 1, in *Plessy v. Ferguson*. With that ruling, the justices allowed states to keep separating Black and white passengers by law. Nearly sixty years later, in 1954, the justices of the Supreme Court threw out that ruling's reasoning in *Brown v. Board of Education*.

### Electric streetcars and bicycles

Electric streetcars replaced horse-drawn ones in American cities between 1888 and 1902. Electric streetcars had run earlier in East Cleveland in 1884, in Baltimore in 1885 and in Montgomery, Alabama, in 1886. The Dictionary of American History describes the system that Frank Sprague built in Richmond, Virginia, in 1888 as the first successful one.

The owners of about 200 streetcar systems had switched to electricity or planned to by 1891. Street railway track grew from about 8,000 miles in 1890 to 22,500 miles in 1902. In those same years, the share of streetcar service pulled by animals fell from 75 percent to 1 percent. The last horse-drawn streetcar in paid service in New York City ran on July 26, 1917.

**Bicycles.** Cycling became a craze in the 1890s, something that very many people took up at the same time. Riders used the safety bicycle, which had two wheels of the same size, a chain drive and air-filled tires. Women rode as well as men.

Susan B. Anthony told the reporter Nellie Bly in the *New York World* on February 2, 1896, that bicycling "has done more to emancipate women than anything else in the world" (to emancipate is to set free). She said: "I stand and rejoice every time I see a woman ride by on a wheel."

### Frank Sprague

> **Who:** The engineer whose streetcar system in Richmond showed that electric streetcars could work in a city.
>
> **When and where:** Richmond, Virginia. Regular service began February 2, 1888.

**Ten electric cars began running in Richmond on February 2, 1888.**

Frank Sprague built the Richmond Union Passenger Railway, which began regular electric streetcar service that day with 10 cars. By May 1888 it had about 12 miles of track and 23 cars.

Within about two years, about 110 electric railways had been built or ordered using Sprague's equipment. Members of the Institute of Electrical and Electronics Engineers, a society of engineers, have named his Richmond railway a milestone in the history of engineering. Chapter 6 tells how builders put up new neighborhoods along the electric lines.

**If you remember one thing:** Railroad builders laid track from coast to coast, across the homelands of many Native nations, and Chinese workers built the western part of the first line.

In 1850: the country had about 9,000 miles of railroad track, and a trip from one coast to the other took about four months.

In 1900: it had more than 190,000 miles of track, and since 1869 the trip had taken about a week.

**Next:** After 1900 Ford's workers built cars by the millions, and airplanes began carrying mail and passengers.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 9 minutes**

Orville and Wilbur Wright flew a powered airplane in 1903, and Ford's Model T car went on sale five years later, for $825. Workers at Ford built 15 million Model Ts by 1927. The first airline to fly on a schedule began in 1914, across Tampa Bay in Florida, and by 1927 airplanes were carrying mail and paying passengers on schedules.

Trains carried about 43.7 million members of the armed forces in World War II, from 1941 to 1945. In Virginia, bus drivers had the power of police officers to make Black passengers sit apart from white passengers and to arrest riders who refused.

### The Model T and the new roads

The Ford Model T went on sale on October 1, 1908, at $825, and its price fell to $260 by 1925. From 1913 Ford's workers built it on a moving assembly line, and the time it took to build a car's frame fell from more than 12 hours to about 93 minutes. Chapter 8 tells how the line worked. The 15 millionth Model T left the factory on May 26, 1927, the last day Ford's workers made the car.

**The Lincoln Highway.** A group of private backers, among them Carl Fisher and Henry Joy, laid out the Lincoln Highway in 1913. It was the first named road for cars across the whole country, from Times Square in New York City to San Francisco. After 1926 highway officials made parts of it into sections of numbered routes.

**Route 66.** State and federal highway officials gave the main highways of the United States numbers on November 11, 1926, and Route 66 got its number that day. It ran 2,448 miles, from Chicago to Santa Monica, California, and people called it the "Main Street of America." It was fully paved only by the late 1930s.

**Crashes.** Car crashes killed about 4,100 to 4,200 people in the United States in 1913. In 1937 they killed about 37,800 to 39,600, about nine times as many, which was about 30 of every 100,000 Americans. The counts differ because the National Safety Council, a private safety group, and the federal officials who kept the national tables counted deaths in different ways.

### The Wright brothers

> **Who:** Orville and Wilbur Wright, the brothers who flew their powered airplane four times in one day.
>
> **When and where:** Near Kill Devil Hills, North Carolina, December 17, 1903.

**The first flight lasted 12 seconds and covered 120 feet.**

Orville and Wilbur Wright made four flights in a powered airplane near Kill Devil Hills, North Carolina, on December 17, 1903. Orville flew first. Wilbur made the fourth and last flight of the day, 852 feet in 59 seconds. Five people watched, and one of them, John T. Daniels, took the photograph. He belonged to a lifesaving station, a crew that rescued people from wrecked ships.

About ten years after those flights, an airplane in Florida was carrying paying passengers on a schedule. Chapter 8 tells how the brothers built their airplane.

### How the airlines began

The St. Petersburg-Tampa Airboat Line in Florida was the first airline in the world to fly on a schedule. Its first flight left on January 1, 1914. The pilot, Tony Jannus, flew a Benoist flying boat, a plane that takes off from and lands on water. The trip across Tampa Bay took about 23 minutes, low over the water.

Abram C. Pheil, a former mayor of St. Petersburg, paid $400 at an auction for the first round-trip ticket. The airline ran for about four months.

**Airmail.** Army pilots began flying mail on a regular route on May 15, 1918, 218 miles from Washington to Philadelphia to New York. Post Office pilots took over in August 1918. Members of Congress passed the Kelly Act in 1925, and under it private companies flew the airmail on contract. The airline companies began with those mail contracts.

**After Lindbergh.** Charles Lindbergh, an airmail pilot, flew the *Spirit of St. Louis* alone and without stopping from New York to Paris on May 20 and 21, 1927, about 3,600 miles in 33 hours and 30 minutes. Chapter 1 tells the flight in full. Airline passengers in the United States rose from 5,782 in 1926 to 173,405 in 1928, about 30 times as many. Applications for pilot licenses tripled in 1927.

**The DC-3.** The Douglas DC-3 airliner first flew passengers in 1936. It carried 21 or more passengers at up to 207 miles an hour. In the words of van der Linden, a curator, or collection keeper, at the Smithsonian's National Air and Space Museum, the DC-3 is "widely considered to be the first airliner capable of making money just by carrying passengers." By 1939 DC-3s carried about 90 percent of the world's airline travel.

### Jack Knight

> **Who:** An airmail pilot who flew through the night and a snowstorm to finish a test that kept the airmail going.
>
> **When and where:** North Platte, Nebraska, to Chicago, the night of February 22 to 23, 1921.

**The next pilot would not fly in the storm, so Knight did.**

Post Office officials ran a test in February 1921 to show that airplanes could carry mail across the country faster than trains. Pilots flew the mail in a relay, day and night, each pilot handing it to the next. Jack Knight flew his part, from North Platte, Nebraska, to Omaha.

At Omaha the next pilot refused to take off in the storm. Knight flew the mail on to Chicago himself, at night, through snow and fog, over ground he had never flown before. The mail crossed the country, 2,629 miles, in 33 hours and 20 minutes. After the test, members of Congress voted money to keep the airmail flying.

### The sleeping-car porters

Pullman Company managers hired Black men as the porters who served passengers in the company's sleeping cars. After the Civil War, George Pullman looked for men who had been enslaved to hire as his porters. By the early 1900s the Pullman Company was the largest single employer of Black men in the United States.

**400 hours.** Porters often had to work at least 400 hours a month to earn a full month's pay. A porter who worked every day of a 30-day month would still need more than 13 hours a day to reach 400. Their pay was among the lowest of all the workers on the train. Company managers built tips from passengers into the porters' pay, which saved the company money. To earn those tips, porters had to do whatever passengers asked.

**"George."** Passengers called porters "George," whatever their real names were, after George Pullman. Calling an enslaved person by the owner's name was a practice from slavery. Some passengers called the porters "boy."

The porters formed a union, a group of workers who bargain together with their employer. The union's leaders won a contract in 1937 that limited the porters' work to 240 hours a month.

### The porters of Miles of Smiles

> **Who:** C. L. Dellums, E. D. Nixon and six other retired Pullman porters, with Rosina Tucker, a porter's wife, who described the porters' work in their own words.
>
> **When and where:** Pullman sleeping cars across the country, from the 1910s to the 1940s. Filmed in 1982.
>
> **Movie:** *Miles of Smiles, Years of Struggle* (1982), a documentary by Jack Santino and Paul Wagner, made from the porters' own accounts.

**On the job, the porters had to smile for the passengers.**

Eight retired Pullman porters told two filmmakers in 1982 what their job had been like. Rosina Tucker, a porter's wife who worked to build the porters' union, tells the story in the film. The porters describe the smile Pullman managers required them to wear and the nights they worked without sleep.

Two of the men in the film are C. L. Dellums and E. D. Nixon. Pullman managers fired Dellums in October 1927 for organizing porters into a union. Nixon later called the meeting that organized the Montgomery bus boycott. From December 1955 to December 1956, most of the 40,000 Black people of Montgomery, Alabama, stayed off the city's buses, until federal judges ended bus segregation there. Chapter 25 tells the boycott in full.

### Trains and Jeeps in World War II

Trains carried about 43.7 million members of the armed forces from December 1941 to August 1945, more than 97 percent of all the troops moved in organized groups. About 100,000 of them rode troop trains on an average day, and half of all Pullman sleeping cars were in use carrying troops.

**The Jeep.** About 640,000 Jeeps, small army cars, were built in the war. About 363,000 of them were the Willys MB, and about 280,000 were the Ford GPW.

### Drivers with the power to arrest

Under Virginia law, buses had to seat Black and white passengers apart, and bus drivers were "special policemen." A driver could decide a passenger's race, order the passenger to another seat, throw the passenger off the bus and make an arrest. Refusing a driver was a crime with a fine of $5 to $25. Greyhound's own rules stated that the company had "full control and discretion as to the seating of passengers" (discretion means the power to decide).

**Riders thrown off.** Bessie Nelson and Mamie Kinchlow were thrown off a Greyhound bus in Alexandria, Virginia, in August 1932 and jailed for more than a week. Mildred Turpin and Caroline Johnson, clerks for the Navy Department, were jailed at Clarendon, Virginia, on January 16, 1943. Tonito Holmes was beaten, removed from a Greyhound bus and fined $14.25 in Johnson City, Tennessee, on February 19, 1945. The Encyclopedia Virginia account of these cases does not name the drivers and officers who threw the riders off, jailed them or beat them.

### Irene Morgan

> **Who:** A Baltimore war worker who refused to give up her bus seat in Virginia and won her case in the US Supreme Court.
>
> **When and where:** A Greyhound bus near Saluda, Virginia, July 16, 1944. The Supreme Court decided her case on June 3, 1946.

**She tore up the sheriff's warrant and threw it out the window.**

Irene Morgan, of Baltimore, was 27 and built B-26 bombers in a wartime factory. She had been visiting her mother in Gloucester County, Virginia, and on July 16, 1944, she took a Greyhound bus home to her husband and to see a doctor. Near Saluda, two white passengers got on the crowded bus. The driver told Morgan and the woman next to her, a Black woman holding a baby, to move to the back seat.

"I refused to move," Morgan said years later. The driver drove the bus to the jail in Saluda, where the sheriff showed her a warrant, a paper that allows an arrest. She "just took it and tore it up and just threw it out the window." "So then he put his hands on me," she said, and she kicked him. The sheriff and a deputy forced her off the bus.

**The courts.** Her mother paid $500 to get her out of jail. Morgan paid a $100 fine for resisting arrest on October 18, 1944. She would not admit breaking the seating law. A judge found her guilty of it anyway, and she refused to pay the $10 fine. The Encyclopedia Virginia account of her case does not name the judge.

Her lawyer was Spottswood W. Robinson III, and the lawyers Thurgood Marshall and William H. Hastie of the NAACP, a civil rights group, joined him. The judges of the Virginia Supreme Court of Appeals ruled against her on June 6, 1945.

The justices of the US Supreme Court ruled for her on June 3, 1946. Justice Stanley Reed wrote that a passenger crossing several states could meet a different seating rule in each one, and under Virginia's law might have to change seats again and again inside Virginia. Seating on trips across state lines, he wrote, needed "a single, uniform rule," so Virginia's law could not apply to those buses.

The ruling covered only trips between states. Reporters at the *Afro-American* newspaper wrote that bus companies' seating rules did not change right away.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 10 minutes**

Three new ways of moving people and goods over long distances began between 1956 and 1958: Interstate highways, shipping containers and American jet airliners across the Atlantic. President Dwight Eisenhower signed the law for the Interstates, the big highways that join the states, in 1956, the same year a ship called the *Ideal X* carried 58 shipping containers from New Jersey to Texas.

Pan Am's jets crossed the Atlantic about twice as fast as the older planes. Private railroads were losing money on passenger trains, and in 1971 a new company, Amtrak, took over most of them.

**Homes taken.** Highway officials forced the people of more than 475,000 households, more than a million people, out of their homes to make room for roads paid for by the national government. That number is the US Department of Transportation's estimate, a figure worked out rather than an exact count.

### The Interstate highways

President Eisenhower signed the Federal-Aid Highway Act on June 29, 1956. The law allowed for 41,000 miles of new highways, called the Interstate Highway System. It was the largest public works program, a set of projects that the government pays for and the public uses, in the history of the United States up to then. The system is about 48,900 miles long today, and in 1990 members of Congress added Eisenhower's name to it.

The new Interstates went around Route 66. Officials of AASHTO, the association of state highway officials, took Route 66 off the list of numbered US highways on June 27, 1985.

### Dwight Eisenhower

> **Who:** The president who signed the Interstate highway law, 37 years after he crossed the country in an Army motor convoy.
>
> **When and where:** The 1919 convoy from Washington, D.C., to San Francisco. The highway law, June 29, 1956.

**In 1919 an Army convoy needed 62 days to cross the country.**

The Army's first convoy of motor vehicles, a group of 81 vehicles traveling together, crossed the country in 1919. It went 3,251 miles, from Washington, D.C., to San Francisco. Its vehicles sank in mud and broke down, and bridges failed under them.

Dwight Eisenhower was a young Army officer, a lieutenant colonel, and he volunteered to go. He wrote a report on the trip. At the end of World War II, in 1945, he saw the autobahns, Germany's highways. After those two experiences, he argued for a system of highways across the United States, and as president he signed the law for it on June 29, 1956.

### The homes the highways took

The people who planned the Interstates ran many of them through city neighborhoods, and they took the homes that stood in the way. By the US Department of Transportation's estimate, highway officials took the homes of more than 475,000 households, more than a million people, for federal roads.

The planning scholar Alan Altshuler estimated in those years that the new system would push out up to a million people, "a disproportionate number of them Black," meaning more than their share. The law professor Deborah N. Archer says the neighborhoods chosen "were largely Black and poor."

**Montgomery.** Interstate 85 ran south of Montgomery, Alabama, in the plans drawn up in 1955. Sam Engelhardt became head of the Alabama State Highway Department in 1959. His business cards read "I Stand for White Supremacy and Segregation," a stand for white rule and for keeping Black and white people apart by law.

Under Engelhardt, state highway officials chose a final route through Montgomery's only middle-class Black neighborhood. Ralph Abernathy, a minister and civil rights leader, lived there, and Alabama State University stood next to it. An engineering firm had suggested a route through Oak Park, which city officials had closed rather than let Black people use it.

Highway officials took about 356 homes in the Centennial Hill, Bel Air and Bottoms neighborhoods and paid owners an average of $3,300 a house. Abernathy sent a telegram, a short message sent over electric wires, to President John F. Kennedy in 1961. He wrote that the route "will destroy one of the best negro neighborhoods in the south" ("negro" was the common word for Black people in his time). Rebecca Retzlaff, a researcher at Auburn University, told this history in a 2019 study.

**Rondo.** Highway officials built Interstate 94 through Rondo, a Black neighborhood in St. Paul, Minnesota, from 1956 to 1968. Counts of what was lost differ: about 600 families by one count, about 700 homes and 300 businesses by another. Chapter 6 tells Rondo's story in full.

### Jet airliners, a crash and cheaper fares

**The Grand Canyon crash.** Two airliners, TWA Flight 2 and United Air Lines Flight 718, left Los Angeles three minutes apart on June 30, 1956, and flew into each other over the Grand Canyon in Arizona. The crash killed all 128 people on the two planes, the deadliest airplane crash in the world up to that time. It was a major reason the Federal Aviation Agency was set up in 1958.

**The jet.** A Pan Am Boeing 707 jet flew from New York to Paris with 111 passengers and 12 crew members on October 26, 1958, in about 8 hours. It was the first jet service across the Atlantic by an American airline. The 707 flew about twice as fast as the older propeller airliners and carried about twice as many people.

**Fares.** Until 1978 the members of a federal board, the Civil Aeronautics Board, or CAB, decided which airlines could start or stop flying and what they could charge. President Jimmy Carter signed the Airline Deregulation Act on October 24, 1978, and under that law the board lost its control of fares and routes. Under the CAB Sunset Act, a part of that law, lawmakers set dates for the board to lose its powers one by one, and the board shut down on December 31, 1984.

Average fares fell about 40 to 45 percent in the decades after 1978, counted in dollars adjusted for rising prices, by government and industry figures. Two economists, experts on money, prices and trade, studied the change for a research group, the Brookings Institution, and found that fares ended up lower than they would have been under the old rules.

### Barbara "Dusty" Roads

> **Who:** An American Airlines stewardess who fought the airline's rule that fired women at age 32 or when they married.
>
> **When and where:** American Airlines, from 1950. She lived from 1928 to 2023.
>
> **Movie:** *Fly With Me* (2024), a PBS *American Experience* documentary about flight attendants, directed by Sarah Colt and Helen Dobrowski. Roads appears in it.

**American's managers fired stewardesses at 32 or when they married.**

Barbara Roads, called Dusty, joined American Airlines in 1950 as a stewardess, a woman who served passengers on an airplane. The job is now called flight attendant. In a 1953 contract, American's managers put in a rule that any stewardess hired after November 1953 would be fired at age 32. A stewardess who married was fired too.

In a radio interview, Roads gave her view of the reason: "It was cheaper to have someone that'll never get married, never have babies, never get pensions, never get the highest rate of pay."

**Fighting the rule.** Roads lobbied members of Congress, trying to talk them into acting, on her own flights to Washington, D.C. In 1963 she held a news conference that made the papers. At news conferences she also asked reporters to pick the 32-year-old stewardesses out of a lineup. Representative Martha Griffiths helped her.

The stewardesses came close to a strike, a refusal to work until their demands were met, in August 1968. By Roads's account, American's managers dropped the age rule the day after someone asked Griffiths to press the Equal Employment Opportunity Commission, the federal office that handles complaints of unfair treatment at work.

Roads helped start the Association of Professional Flight Attendants, a union, in 1977. She worked for American Airlines for 44 years.

### The Freedom Rides

Black and white riders traveled together by bus into the South in May 1961, and people called them Freedom Riders. They were testing a court order that banned separating Black and white travelers in bus stations used for trips between states. Two groups left Washington, D.C., on May 4 on a Greyhound bus and a Trailways bus, headed for New Orleans. Among the Black riders was John Lewis, who later led the Student Nonviolent Coordinating Committee, a civil rights group.

**Anniston.** A white mob with clubs and bats attacked the Greyhound at Anniston, Alabama, on May 14. They broke its windows and slashed its tires, then chased the bus until the flat tires stopped it several miles out of town. One of the attackers threw a firebomb, a bomb that starts a fire, through a window. The riders and other passengers barely got out of the flames.

A state officer riding the bus in plain clothes held the attackers back with his gun. The mob beat the riders while the bus burned, until police arrived. Later that day white men got on the Trailways bus at Anniston and beat the riders on it. Their beating left one rider, Walter Bergman, a white man, with permanent brain damage.

**Birmingham.** The same day, a crowd met the Trailways bus in Birmingham with pipes, chains and baseball bats. Many in the crowd belonged to the Ku Klux Klan, a group that used violence against Black people and their supporters. Eugene "Bull" Connor, the city official in charge of the police, had told Klan leaders that the police would hold back from the bus station for 15 minutes, and he encouraged the Klan to attack the riders.

With no police there, Klansmen beat the riders in the waiting room and in a dark hallway. They beat James Peck, a white rider, until he was unconscious, and he needed more than 50 stitches. Walter Bergman was among the riders they beat, for the second time that day.

**Montgomery.** A white crowd in Montgomery attacked a new group of riders arriving by Greyhound on May 20. They beat John Seigenthaler, a Justice Department official, until he was unconscious. Alabama's public safety director had arranged protection for the buses up to Montgomery, but Montgomery police did not take it over, and the director went into the fighting himself. Governor John Patterson blamed the riders for the violence.

**The ban.** The rides went on, and over the summer of 1961 the number of Freedom Riders grew to more than 400. Justice Department officials asked the members of the Interstate Commerce Commission, the federal officials in charge of trade and travel between states, to act. The commissioners banned keeping Black and white passengers apart in bus and train stations. They issued the ban on September 22, 1961, and it took effect on November 1, 1961. People in many Southern towns kept ignoring it.

### Amtrak takes over the passenger trains

Private railroad companies were losing money on their passenger trains. Members of Congress passed the Rail Passenger Service Act in 1970 and created a new company called Amtrak. Amtrak began running most of the passenger trains between American cities on May 1, 1971, after the private railroads gave them up.

### How much did a box save?

Loading a ton of cargo onto a ship by hand cost about $5.86 in 1956. Loading it in containers cost about 16 cents, less than a thirtieth as much, by the count of the writer Marc Levinson in his book *The Box*.

Before containers, dockworkers loaded cargo onto ships by hand. A ship called the *Ideal X* left Port Newark, New Jersey, on April 26, 1956, carrying 58 metal boxes, each 35 feet long, the size of a truck trailer. These boxes are called shipping containers. The ship reached Houston, Texas, five days later.

Members of an international standards group set standard sizes for containers in the late 1960s, and the same boxes came into use around the world.

### Malcom McLean

> **Who:** A North Carolina trucking owner who sold his trucking company to start shipping truck-sized boxes by sea.
>
> **When and where:** Port Newark, New Jersey, April 26, 1956.

**His trucking company began with one used truck in 1934.**

Malcom McLean built that one truck into a trucking company in North Carolina. Then he sold the trucking company and put the money into carrying containers by sea, and in 1956 he sent the *Ideal X* to sea with them.

### The deadliest year on the roads

Car crashes killed 54,589 people in the United States in 1972, the most in any single year before or since. By 1975 the yearly count had fallen to 44,525.

Federal safety officials have given part of the credit to a lower speed limit. During the oil shortage of 1973 and 1974, which Chapter 10 tells, members of Congress set a national speed limit of 55 miles an hour to save fuel, and by March 1974 every state had lowered its limit to match. A federal task force later estimated that the 55-mile limit saved 20,000 to 30,000 lives from 1974 to 1978.

### The minivan

Workers in Windsor, Ontario, in Canada, built the first Dodge Caravan and Plymouth Voyager minivans on November 2, 1983. The minivans went on sale as 1984 models.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 10 minutes**

With a phone in hand, Americans after 2000 could find their way and hire a ride, and some of them bought electric cars. About 8 of every 100 new cars sold in 2024 ran on batteries alone, according to Kelley Blue Book. About 7 of every 100 bridges in the country were rated in poor condition in federal records in 2025, by the count of a road builders' group.

**Deaths.** Federal safety officials counted 43,230 deaths in car crashes in 2021, and their early estimate for 2025, published in April 2026, is about 36,640. A container ship that had lost power hit a bridge in Baltimore in 2024, and the bridge's fall killed six road workers. An Army helicopter and a passenger jet collided near Washington, D.C., in 2025, and the crash killed all 67 people aboard.

### Maps and rides on a phone

GPS, the Global Positioning System, uses signals from satellites to show a GPS device where it is. Until 2000 a setting called Selective Availability made GPS less exact for ordinary users. Federal officials switched the setting off a few minutes after midnight at the end of May 1, 2000, and the error of an ordinary GPS device shrank from about 100 meters to about 20, according to the government's GPS website.

**Ride apps.** People also began hiring rides through apps on their phones. Uber began in March 2009 as a company called UberCab and started its app service in San Francisco on July 5, 2010. In October 2010, officials of San Francisco's city transit agency and of California's Public Utilities Commission ordered UberCab to stop operating. Its owners changed the company's name to Uber that month, so that it would not look like a taxi business. Lyft started its service in June 2012.

In a ride-hailing app, a rider asks for a ride, and a driver using a personal car takes the job. The companies' managers called their drivers independent contractors, people in business for themselves rather than employees. One driver, Barbara Ann Berwick, asked the state of California to decide whether she was Uber's employee.

### Barbara Ann Berwick

> **Who:** A San Francisco Uber driver who asked the state of California to decide whether she was Uber's employee, and won.
>
> **When and where:** San Francisco, July to September 2014. The decision came on June 3, 2015.

**A hearing officer ruled that Uber owed her 56 cents a mile.**

Barbara Ann Berwick drove for Uber in San Francisco, in her own car, for about eight weeks in the summer of 2014, and she quit on September 18. Uber's managers called her an independent contractor, and the company did not pay her back for the costs of her car. She took a claim to the California Labor Commissioner, the state office that handles pay disputes.

**The hearing.** Berwick argued her case herself on March 10, 2015, at a hearing, a meeting where each side tells its story to an official who decides. Uber sent two lawyers and a product manager, Brian Tolkin.

The hearing officer, Stephanie Barrett, listed the rules Uber's managers set for its drivers. The car could be no more than 10 years old, counted by its model year, and the company had to approve it. Drivers needed $1,000,000 in insurance. They had to keep a rating from riders of 4.6 stars or higher, or the company turned off their app. The agreement said riders did not tip. Barrett wrote that Uber was "involved in every aspect of the operation."

**The ruling.** Barrett ruled on June 3, 2015, that Berwick was Uber's employee, and she ordered Uber to pay Berwick $4,152.20. That was 56 cents a mile for 6,468 miles, plus $256 in bridge tolls and $274.12 in interest, extra money owed for the time she had waited to be paid. Barrett turned down Berwick's claim for unpaid wages, because Berwick agreed that Uber had paid her.

Uber's lawyers asked a court in San Francisco to undo the decision. In a statement, Uber's spokespeople said the ruling applied to Berwick alone, and Uber's managers kept treating the company's other drivers as contractors.

### The fight over drivers' pay

**What was at stake.** If app drivers were employees, the companies would have to pay back the costs of their cars, as the hearing officer ordered Uber to do for Berwick. As contractors, drivers paid those costs themselves.

California voters decided the question for app drivers in their state in November 2020. They passed Proposition 22, a law put to the voters directly, 58.6 percent to 41.4 percent. Under it, app drivers stayed contractors, but the companies had to pay them at least 120 percent of the minimum wage for the time they spent working on a ride request, plus 30 cents a mile.

**The money.** Uber, Lyft, DoorDash, Instacart and Postmates paid for the campaign for the law. It raised $205.7 million, the most for any California ballot question up to then, by the count of Ballotpedia, which tracks state ballot questions.

**In court.** Four drivers and a union, the Service Employees International Union, went to court on January 12, 2021, to overturn the law. The justices of the California Supreme Court ruled on July 25, 2024, that the law could stand.

**Massachusetts.** In June 2024 Uber and Lyft settled a lawsuit brought by Massachusetts, agreeing to pay $175 million and to pay drivers there at least $32.50 an hour for time spent driving to a rider or carrying one, while the drivers stayed contractors.

### Bigger vehicles and electric ones

Americans bought more light trucks, meaning pickups, sport utility vehicles (SUVs) and minivans, than cars for the first time in 2001. Light trucks made up 50.8 percent of new vehicle sales that year, against 49.2 percent for cars, according to trade magazines that follow the car business. The gap grew wider in the years after.

**Tesla.** The company Tesla delivered its first Model S electric cars to buyers in Fremont, California, on June 22, 2012. It is named after the inventor Nikola Tesla, who died in 1943 and had no connection to it.

Americans bought about 1.3 million battery electric cars, which run on electricity alone, in 2024 and almost as many in 2025, by the counts of Kelley Blue Book and Cox Automotive, car-market research companies, published in January 2026. They made up 8.1 percent of new car sales in 2024 and 7.8 percent in 2025. Chapter 10 gives larger shares that also count hybrids, which have both a gasoline engine and an electric motor. Tesla sold nearly half of all the battery electric cars bought in 2025.

**The tax credit.** Members of Congress passed a budget law in July 2025, and President Donald Trump signed it on July 4. Under it, the federal tax credits for buying electric cars, money taken off what a buyer owes in taxes, ended for cars bought after September 30, 2025. In the last three months of 2025, Americans bought 234,000 electric cars, 46 percent fewer than in the three months before.

**Scooters.** A company called Bird put electric scooters for rent on the streets of Santa Monica, California, in September 2017. Another company, Lime, followed in 2018, and city officials began trial programs for scooters.

### Ports, trains and bridges

**Ports.** Ships carrying containers backed up outside American ports in 2021. Staff at the Marine Exchange of Southern California counted a record 109 container ships waiting off the ports of Los Angeles and Long Beach on January 9, 2022. By October 2022 the line was down to about 4 ships.

**A fast train.** California voters approved $9.95 billion in bonds, a kind of loan, for high-speed trains from San Francisco to Anaheim in November 2008. The state's high-speed rail officials then put the cost of the whole system at $33.6 billion. Workers broke ground in Fresno on January 6, 2015, and the first section planned is 171 miles, from Merced to Bakersfield.

US Transportation Secretary Sean Duffy canceled about $4 billion in federal grants, money the national government had promised, for the California line in July 2025. He said the state's rail agency had "no viable plan," meaning no plan that could work. California officials sued, then dropped the case in December 2025.

The project now gets $1 billion a year through 2045 from cap-and-trade, a state program that makes polluters pay for permits to pollute. Associated Press reporters wrote in December 2025 that cost estimates are now above $100 billion, about three times the $33.6 billion estimate. No passenger had ridden a California high-speed train as of 2026.

**Bridges.** Researchers at ARTBA, a group for companies that build roads, counted the federal bridge records for 2025. The United States had 624,167 bridges, and 41,677 of them were rated in poor condition, about 7 of every 100. Drivers crossed those poor bridges 163 million times a day.

### Deaths on the roads and in the air

Car crashes killed 43,230 people in the United States in 2021, the most in recent years, and the count then fell four years in a row. In April 2026 officials at the National Highway Traffic Safety Administration published an early estimate of 36,640 deaths in 2025. That is 1.10 deaths for every 100 million miles driven, and the only lower rate on record was 1.08, in 2014.

**The Key Bridge.** The container ship *Dali* was leaving Baltimore for Sri Lanka at about 1:30 in the morning on March 26, 2024, when it lost power and steering and hit a support of the Francis Scott Key Bridge. The bridge fell into the Patapsco River. The fall killed six men who were filling potholes on the bridge on an overnight shift.

Maryland Governor Wes Moore named them in a statement: Dorlian Ronial Castillo Cabrera, Carlos Daniel Hernandez Estrella, Alejandro Hernandez Fuentes, Miguel Angel Luna Gonzalez, Jose Mynor Lopez and Maynor Yassir Suazo Sandoval. They were immigrants from Mexico and Central America.

**The cause.** Members of the National Transportation Safety Board, the federal board that investigates crashes, reported the cause in November 2025. A label band had been put on a wire the wrong way. The band kept the wire from going all the way into its connector, so the connection came loose and cut the ship's power.

The board's press release does not say who put the band on or when. The board's members sent safety advice to several groups, among them the ship's builder, HD Hyundai Heavy Industries of South Korea.

**The charges.** Federal prosecutors, the government lawyers who bring criminal cases, charged the two Synergy Marine companies that ran the ship with crimes on May 12, 2026. They also charged the *Dali*'s technical superintendent, Radhakrishnan Karthik Nair, the manager in charge of the ship's machinery and upkeep. The charges include causing the deaths of the six workers.

A charge is an accusation, not proof. Under the law, the companies and Nair are innocent unless a judge or jury finds them guilty. The same day, Attorney General Anthony Brown, Maryland's top lawyer, announced a $2.25 billion settlement, a deal that ends a legal claim, with the ship's owner, Grace Ocean, and with Synergy.

**Near Washington.** An Army Black Hawk helicopter collided with an American Eagle passenger jet that was landing at Reagan National Airport, near Washington, D.C., on January 29, 2025. The crash killed all 67 people on the two aircraft, 64 on the jet and three soldiers on the helicopter. It was the deadliest crash of an American passenger airline in more than 20 years.

The head of the National Transportation Safety Board, Jennifer Homendy, said on January 27, 2026: "This was preventable. This was 100% preventable." CNN reported that the board's members blamed Federal Aviation Administration officials for helicopter routes that ran close to the path planes took down to the runway, and for failing to act on years of reports of near misses.

**The three questions, answered**

- How much faster and cheaper did travel get? On the Erie Canal a ton of goods went from Buffalo to New York City for under $10 instead of about $100 by wagon, and on the first railroad across the country a coast-to-coast trip took a week instead of four months. By 1956, loading a ton of cargo onto a ship cost about 16 cents in containers, against about $5.86 by hand.
- Who built the new routes, and whose land and homes did they take? Irish and American-born laborers dug the Erie Canal, enslaved people dug the Dismal Swamp Canal and built most of the Southern railroads, and Chinese workers built the western part of the first railroad across the country. Builders and US officials took Native nations' land, and highway officials building federal roads took the homes of more than 475,000 households, many in Black neighborhoods.
- How did Black travelers fight the laws that made them sit apart? They refused to move, went to court and stayed off the buses: Ida B. Wells sued a railroad in 1884, Homer Plessy tested a Louisiana law and lost in 1896, Irene Morgan won in the Supreme Court in 1946, and Black riders in Montgomery, Alabama, stayed off the city buses for more than a year in 1955 and 1956. After white mobs and Klansmen beat the Freedom Riders in Alabama in 1961, federal officials banned separating passengers in bus and train stations.

**What changed:** People here went from moving on foot, by canoe and with dogs before 1500 to railroads, highways, jets and container ships today, each faster or cheaper than what came before.

**Five dates to keep**

- January 1673: the first post rider leaves New York for Boston.
- October 26, 1825: the Erie Canal opens.
- May 10, 1869: Chinese workers lay the last track of the first railroad across the country.
- May 18, 1896: the Supreme Court rules against Homer Plessy.
- June 29, 1956: Eisenhower signs the Interstate highway law.

**Not known:** Nobody knows how many Chinese workers died building the Central Pacific, because its managers kept no record of their deaths.

**Where to go:** Golden Spike National Historical Park, at Promontory Summit in Utah, marks where the last track was laid, and from May to October you can see working copies of the engines Jupiter and No. 119 there.

**Next:** Chapter 12, Landmarks. It asks who built the country's best-known structures and monuments, and what people have argued about them.
