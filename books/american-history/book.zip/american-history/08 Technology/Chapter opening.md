**Part 3: Making and Building**

# Chapter 8: Technology

**Chapter 8 of 37 · Technology · 10 eras · about 85 minutes**

**Many famous American inventors had help that their patents did not name, and the hardest work around the new machines often fell to people who had no say in it.**

The Smithsonian's National Museum of American History holds a strip of paper tape from May 24, 1844. It records the first public message sent from Washington to Baltimore by telegraph, a machine that sent messages over a wire as pulses of electricity. The words were "What hath God wrought" (What has God done).

Samuel Morse sent the message, and the code is named for him. He also held the patents, the government grants that gave him alone the right to make and sell the telegraph for a set number of years. His partner, Alfred Vail, who built the instruments, received the message in Baltimore. In 1911 one of Vail's sons had his father's gravestone changed to read "INVENTOR OF THE TELEGRAPHIC DOT AND DASH ALPHABET."

This chapter follows American tools and machines from fish traps under a Boston street to the AI programs of the 2020s. As you read, notice whose name goes on each invention. A patent could name one man while a partner, a team of workers or an enslaved man did part of the work. In 1858 the government's chief lawyer ruled that an enslaved person's invention could not be patented.

Notice also who did the hard work: Scottish prisoners at an ironworks, enslaved people at furnaces and in cotton fields, children at spinning machines. The last era covers smartphones and AI programs, and what happened when people trusted a machine's answer.

**Three questions this chapter answers**

- Why did planters enslave far more people after the cotton gin?
- Why could an enslaved inventor not get a patent?
- What went wrong when people trusted a computer's answer?

**Five minutes?** Read "Who could own an invention?" in 1850 to 1900.

**Can skip:** "The Cambridge printing press", "Tractors replace horses", "What is inside a smoke detector?", "Batteries, printers and gene tools". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 4 minutes**

People in North America made their tools from wood, stone, bone, clay and animal skin, and near Lake Superior from copper. With no metal machines, they built traps that caught fish with the tide, fields that grew three crops together and boats of birch bark. The names of the people who first worked out these methods are not recorded. Some of the methods are still in use, and an Ojibwe builder in Wisconsin still makes birchbark canoes.

### Spear-throwers, fish traps and fields

Before the bow and arrow, hunters in western North America threw spears with an atlatl, a spear-thrower stick that holds the back end of the spear during the throw.

Hunters across the West began using the bow and arrow about 1,400 years ago, around A.D. 600 to 700. A study published in 2026 in the *Journal of Archaeological Method and Theory* gives that date. South of an east-west line called the 55th parallel, archaeologists, the scientists who dig up and study what people left behind, stop finding atlatls soon after the bow appears. North of that line, hunters used both weapons side by side for more than 1,000 years.

**Fish weirs.** People built fixed traps called fish weirs, fences of wooden stakes set across the water with bundles of brush woven between the stakes. Fish swam in over the mud flats with the rising tide, and the fence trapped them when the water went out. People then scooped them up with baskets and nets, or caught them by hand.

Lines of wooden stakes from fish weirs lie under Boylston Street in Boston. People built these weirs in channels that filled and emptied with the tide, between about 4,700 and 3,700 years ago. They used them for more than a thousand years, until mud filled the bay around 1550 B.C., about 3,500 years ago.

Native farmers planted corn, beans and squash together in the same field, three crops known as the Three Sisters. They also set controlled fires, started on purpose and kept in bounds, to shape the land.

### Crafts, and a calendar made of posts

People made pottery from clay and wove baskets. They tanned animal hides, treating the skins so they stayed soft and did not rot, and they made canoes from the bark of birch trees.

At Cahokia, in what is now Illinois, people built the largest city north of Mexico before 1500. Between about A.D. 900 and 1100, builders there raised five circles of upright wooden posts, one after another.

Each circle had between 24 and 72 posts and measured about 240 to 475 feet (73 to 145 meters) across. The biggest was wider than a football field is long. The posts marked the places on the horizon where the sun rose at different times of the year, so the circles worked as a calendar.

Near Lake Superior, people worked copper for thousands of years. They worked it cold, shaping it without melting it.

### Wayne Valliere

> **Who:** An Ojibwe builder of birchbark canoes who has taught more than 100 students and teaches the Ojibwe language.
>
> **When and where:** Lac du Flambeau, Wisconsin, in the present day.

**Spruce roots are the thread that sews his canoes together.**

Wayne Valliere builds birchbark canoes, the same kind of boat people built in North America before 1500. He is a member of the Lac du Flambeau Band of Lake Superior Ojibwe, in Wisconsin. A profile of him by the National Endowment for the Arts, a US government agency that gives money and honors to artists, describes the Ojibwe way of building canoes as handed down over many generations.

Valliere began learning at 16 from elders, among them Joe Chosa, Marvin DeFoe and Ojaanimigiizhig. He also studied old objects kept in museums, along with writings and photographs.

Valliere builds each canoe from birchbark, cedar, spruce roots and pitch. The hull, the body of the boat, is thick birchbark. Ribs of straight-grained cedar hold the hull in shape, and spruce roots sew the pieces of bark together. To seal the seams against water, he mixes pitch, a sticky tree sap, with oak ash and deer tallow, the fat of a deer. Each material is gathered in a different season of the year.

More than 100 students have learned from him. At least one of them now builds canoes without his help, and a second is learning as an apprentice, working beside him. Valliere also teaches the Ojibwe language at Lac du Flambeau Public School.

Valliere's National Heritage Fellowship, which he received from the National Endowment for the Arts in 2020, is the highest honor in the United States for folk and traditional arts, the crafts and music that families and communities hand down.

## The 1500s

**Era 2 of 10 · The 1500s · about 1 minute**

European metal reached Native towns on the East Coast before most Europeans did. Native smiths, people who shape metal into tools, cut up European copper and brass, a yellow metal made by melting copper and zinc together, and made tools of their own design from it.

### Copper kettles cut into arrow points

Copper and brass from Europe reached the East Coast through trade with Europeans along the shore. Both metals had been made in European furnaces from rock dug out of the ground. Native traders passed the metal from one group to the next, so it spread along the East Coast ahead of most Europeans. In 1524 Verrazzano, a European sailing along the Northeast coast, wrote that the Native people there had sheets of worked copper.

Some of the metal came as kettles, large cooking pots. Native smiths cut the kettles apart and hammered the pieces into arrow points, knives, pipe stems, bells and ornaments. They took the new metal and made it into the tools and goods they already used.

Spanish expeditions, groups of men sent out to explore, crossed parts of what is now the United States in the 1500s, through lands where Native nations lived. The men on these expeditions carried iron weapons and tools. They left behind no lasting trade in tools.

## The 1600s

**Era 3 of 10 · The 1600s · about 9 minutes**

English colonists used running water to drive machines. They dammed streams to turn waterwheels, and the wheels drove grist mills, which ground grain into flour, and sawmills, which cut logs into boards. At ironworks, places where workers made iron from rock dug out of the ground, waterwheels worked the bellows and the hammers.

The first ironworks begun in the English colonies stood on Powhatan land in Virginia. The first one that ran for years stood on Pawtucket land in Massachusetts. Its workers were skilled English ironworkers, nearby farmers, at least two Native woodcutters, and Scottish prisoners of war whom the company's agents forced to work there for seven years.

### Falling Creek, 1619 to 1622

Powhatan warriors destroyed the ironworks at Falling Creek, Virginia, in 1622, three years after Virginia Company officers sent the first ironworkers there. It was the first ironworks begun in the English colonies. Colonists built it at the falls of the James River, where the river drops over rocks, near present-day Richmond. In 1619 officers of the Virginia Company, the English company that ran the colony, hired Captain Benjamin Bluett to run the ironworks and sent workers with him.

Bluett died on the voyage or soon after he arrived. Others of his men died too, of what colonists called seasoning, the sickness that killed between 50 and 90 percent of early newcomers, according to Chesterfield County's history of the site. The men who lived could not finish the furnace, the tall oven where iron is melted out of rock.

Company officers hired John Berkeley to take over in 1621. He sailed with his son Maurice and 25 other men, according to the county, and he promised iron by June 9, 1622.

**Why the Powhatan attacked.** Like the colonists' tobacco farms, the ironworks stood on Powhatan land. Opechancanough, a Powhatan leader, planned an attack across the colony to force the English to leave Powhatan territory, as the county's history states it. From 1618 to 1620, English tobacco planters, owners of large farms called plantations, had taken Powhatan land without paying for it. Virginia Company officials had pressed to take Powhatan children for English schooling.

**The attack.** Powhatan warriors attacked the ironworks on March 22, 1622. They killed 27 English people there, John Berkeley among them. Two children at Falling Creek survived. The warriors left the works in ruins. Across the colony that day, Powhatan warriors killed about 350 English colonists.

Maurice Berkeley was away from the works and lived. He tried to start the ironworks again and failed. Another Englishman tried from 1634 to 1636 and failed too.

Whether Falling Creek ever made iron is disputed. Virginia's official list of historic places states that workers produced iron there in 1620, and it calls Falling Creek the first successful ironworks in English North America. The county's history states that Bluett's men could not finish the furnace, and that in 1621 Berkeley was still promising iron for the next year. Either way, the first ironworks in the English colonies that ran for years was the one at Saugus, in Massachusetts.

### Seven waterwheels at Saugus

The first ironworks in the English colonies that ran for years stood on the Saugus River in Massachusetts. By 1643 John Winthrop Jr. had gathered about two dozen investors for it, people who put in money hoping for a profit. They formed the Company of Undertakers of the Iron Works in New England, using undertakers in an old sense, people who take on a big job. The works ran from 1646 to about 1670.

Seven waterwheels drove three kinds of machine. The first was a blast furnace. Air blown into its fire made the fire hot enough to melt iron out of rock, about 3,000 degrees Fahrenheit. The air came from bellows, giant bags that squeeze air into a fire, and these bellows were 18 feet long.

Next came a forge, where 10 to 12 men hammered the iron. The last machine was a rolling and slitting mill, which pressed iron into flat sheets and cut it into thin rods.

The ironworks burned more than 3,600 cords of wood a year, each cord a stack 8 feet long, 4 feet wide and 4 feet high. Set end to end, one year's cords would have made a stack more than 5 miles long. Workers cut the wood with axes and saws made at the works.

The Saugus works closed because of debt, high costs and competition from iron brought in from overseas. The men who had lent money sued. Some of the ironworkers, such as James Leonard, went on to run forges in other places. The works have been rebuilt on the old site, which is now the Saugus Iron Works National Historic Site.

### Who did the work at Saugus?

About 100 people worked at the Saugus ironworks. The company's managers brought skilled ironworkers over from the iron-making parts of England, and colonists from nearby farms did the unskilled work. Company records show that at least two Native people cut wood for the same wages as the other workers. The records do not give their names.

The workers lived in a village the company owned, called Hammersmith after the English town that many of the ironworkers came from. The works stood on the land of the Pawtucket, the Native people who lived there when the English arrived. Saugus had been a Native settlement, and the English first called it Lynn.

**The Scots.** Some of the workers were prisoners of war. In September 1650, Oliver Cromwell's English soldiers defeated a Scottish army at Dunbar, in Scotland, and captured Scottish soldiers. Members of England's Council of State, the leaders who ran England's government at the time, ordered 150 of the prisoners handed over to agents of two of the ironworks company's investors.

The agents shipped the prisoners across the ocean on the ship *Unity*, which left Gravesend, England, on November 11, 1650, and reached Boston in December. How many died on the voyage is not known. The company kept 62 of the prisoners for its ironworks, and about 36 of them went to work at Saugus, though a National Park Service history gives about 35. The agents sent others to mills in Maine and New Hampshire and sold the rest to farmers and merchants in New England.

The company held the Scots at Saugus to seven years of forced labor under indentures, written contracts that required a person to work for a master for a set number of years. The Scots cut wood, worked as colliers, who make charcoal, and did other labor. They received clothing, food and tobacco.

Some of the Scots are known by name. A list of 35 Scots at the works in 1653 includes James Adams, John Clark, Alexander Innes, Peter Grant, John Stewart and Thomas Tower. A November 1653 list of the property of the works includes Alexander Innes, with a value of 10 pounds. The Scottish Prisoners of War Society prints these lists from the company's record books.

**The danger.** Flying sparks and pieces of hot metal were a constant danger to the men at the forge. The forge hammer weighed 500 pounds, and its noise cost many workers their hearing. The surviving records of the works do not give a count of deaths.

### The Cambridge printing press

The first printing press in the English colonies, a machine that presses paper hard onto metal letters covered in ink, arrived in Cambridge, Massachusetts, in 1638. The Reverend Jose Glover, a minister, bought the press and hired a locksmith named Stephen Daye to run it. Glover died on the voyage across the ocean. His widow, Elizabeth Glover, owned the press, and Daye ran it.

Daye printed the *Bay Psalm Book* on the press in 1640. It was a book of psalms, the religious songs of the Bible, and the first book printed in what is now the United States.

### Joseph Jenks

> **Who:** A London sword maker who ran the blacksmith shop at the Saugus ironworks and asked the colony to protect his machines from copiers.
>
> **When and where:** Saugus, then part of Lynn, Massachusetts. At the works from 1646. Died in 1683.

**The colony gave Jenks 14 years of protection from copiers.**

Joseph Jenks wanted to stop other men from copying his machines. In 1646 Massachusetts leaders gave him a patent for his water-driven mills. A National Park Service page about his shop states that US Patent Office officials credit him with the first patent for a machine in what is now the United States.

Jenks learned his trade in England. In the 1630s he worked for a sword maker whose sword mill at Hounslow ran on water power. A sword marked with Jenks's name as its maker survives in a museum in Wales.

**The petition.** In May 1646 Jenks asked the Massachusetts General Court, the leaders who made the colony's laws, for the only right to build water-driven mills for 14 years. The mills would make scythes, long curved blades for cutting grass. He also asked to build "a new Invented Saw Mill" and other machines for making tools with edges. His written request survives in the Massachusetts Archives, dated May 10, 1646.

In it he explained why he wanted protection. Without it, another man would see his machine and copy it, and Jenks would lose the profit. In his own spelling: "Another when he seeth it makes the like," and "soe I loose the benefit." The court's magistrates, the leaders who sat as its judges, granted his request.

**The shop.** The agent in charge of the ironworks let Jenks build a water-driven hammer at the tail of the blast furnace on January 20, 1647. It ran on the water that had already turned the furnace wheel. The company owned the shop, and Jenks paid rent.

There he made saw blades, felling saws for cutting down trees, and steelyards, a kind of weighing scale. He drew iron into fine wire, pulling it through small holes to make it thin. In 1652 he sent two saw blades for a water-powered sawmill that John Winthrop Jr. ran in Connecticut.

When the ironworks company went bankrupt, unable to pay its debts, Jenks bought a share of his shop in September 1656 and the rolling and slitting mill that October, with borrowed money. By October 1667 he had little money left, and he asked the court for 50 pounds to start making iron wire. He died in March 1683.

**What the ground showed.** An archaeologist dug up the site of Jenks's shop in 1952. He found waterwheels, the supports of a water-driven hammer, an anvil base and a stone forge.

**Not known:** whether Jenks made the dies, the stamps, for the first silver coins made in New England in 1652, as a marker put up in 1898 states, because no document from the time shows that he did.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 5 minutes**

Iron furnaces and forges went up across Pennsylvania, Maryland and Virginia, and in Maryland many of the ironworkers were enslaved people or convicts. At the Baltimore Iron Works, which opened in 1731, 42 of the first 89 workers, almost half, were enslaved. Waterwheels still drove the machines, and the furnaces still burned charcoal. In Philadelphia, the printer Benjamin Franklin designed a new kind of stove in 1741 or 1742 and refused to patent it.

### How the Franklin stove saved heat

Benjamin Franklin designed a stove that sent more of a fire's heat into the room and less of it up the chimney. He made it in 1741 or 1742. The Franklin Institute, a science museum in Philadelphia, states 1742 in its history of his inventions.

Franklin's stove was a fireplace lined with metal that stood a few inches out from the chimney. At the back was a hollow iron wall, called a baffle. Air from the room flowed into the baffle, picked up the fire's heat and came back out into the room.

Behind the baffle was a U-shaped passage called an inverted siphon. The smoke had to go up over the baffle, down behind it and only then up the chimney. On that longer path, the iron took in more of the smoke's heat. The stove made less smoke than an ordinary fireplace, too.

Franklin refused to patent the stove. He gave his reason later in his autobiography, the story of his life that he wrote himself. "As we enjoy great Advantages from the Inventions of others," he wrote, "we should be glad of an Opportunity to serve others by any Invention of ours." He added, "and this we should do freely and generously." Everyone gains from other people's inventions, he meant, so people should share their own for free. He never patented any of his inventions.

### Enslaved people and convicts at the Maryland furnaces

Many of the workers at the Maryland ironworks were enslaved people or convicts. In 1719, investors in Britain set up the Principio Company in Cecil County, Maryland. In 1731 Dr. Charles Carroll and four other Maryland planters, two of them also named Carroll, founded the Baltimore Iron Works on the Patapsco River. Dr. Carroll put in 2,200 acres of land and served as the first manager. The five partners supplied the money and the enslaved workers.

**Whose land.** Susquehannock leaders had signed away the Patapsco valley in 1652, though the Piscataway lived in the region too. Five Susquehannock war chiefs signed that treaty, a written agreement between nations, with Maryland colonial officials. In it they gave up their claim to a long stretch of the Chesapeake Bay shore that includes the valley. Emma Bilski, a history graduate student at Johns Hopkins University, points out that the land was not really the Susquehannock's to give away.

**Convicts.** The Baltimore Iron Works opened with 89 workers, and 42 of them were enslaved. Over the years, many other workers there were convicts, people found guilty of crimes in Britain. Under a British law of 1718, English judges sentenced many such people to be shipped to the colonies. Merchants who held contracts with the British government carried them across the ocean and sold their labor to colonists, most often for seven years. Iron makers were among the buyers.

The managers of the Baltimore Iron Works preferred enslaved workers to convicts. Many of the enslaved ironworkers were Igbo people from West Africa, who brought their own skill at working metal. By 1785 an advertisement for the works listed a workforce of "more than 200 Negroes," using a word of that time for Black people.

**The work.** The workers hauled charcoal, oyster shells and iron ore to the top of the furnace. They worked 12-hour shifts, day and night, six or seven days a week.

The owners lived away from the works and often quarreled, and they refused to send the food and workers they had promised. In 1775 the manager, Clement Brooke, wrote to the partners: "I cannot do my job unless you send more slaves and more corn." The Mount Clare Museum's history of the works states that the workers and the animals were starving.

Each of the five owners took one fifth of the iron. In good years the partners earned 55 percent on their money each year. The works closed in 1799. In 1810 the 30 heirs of the original owners, the people who had inherited their shares, had the land that was left sold at auction. It came to more than 30,000 acres. The heirs had 200 enslaved people sold at the same auction.

Some workers ran away. In August 1754 the *Maryland Gazette* newspaper printed a notice for the capture of people who had escaped. Others worked slowly.

An enslaved blacksmith named Anthony and an indentured servant named Thomas Livy were jailed for robbing a store in the spring of 1771. They were caught with the stolen goods, most likely food. The Mount Clare Museum's account of the case does not say who caught them or who jailed them. The overseer, the man in charge of the workers, was William Hammond. He wrote about Anthony: "We shall feel the loss of Anthony's time very much, I cannot tell how we can carry on the Forge business without him."

### Benjamin Franklin

> **Who:** A Philadelphia printer who designed the Franklin stove and, later, the lightning rod, and refused to patent either one.
>
> **When and where:** Born in Boston in 1706. Worked in Philadelphia. Died there in 1790.
>
> **Movie:** *Benjamin Franklin* (2022), a two-part documentary by Ken Burns, shown on PBS. It is about Franklin's life.

**A London ironmonger patented a copy of Franklin's stove.**

Benjamin Franklin made his living as a printer in Philadelphia. He printed a newspaper and a yearly almanac, a book of calendars, weather guesses and sayings.

Franklin gave the model of his stove to an old friend, Robert Grace, who owned an iron furnace in Pennsylvania. Grace cast the iron plates for the stoves there, and he made money on them, because more and more people wanted one. To help sales, Franklin wrote a pamphlet in 1744 that explained how the stove worked.

Governor Thomas of Pennsylvania liked the stove so much that he offered Franklin a patent, which would have let only Franklin sell the stoves for a set number of years. Franklin turned the offer down.

In London an ironmonger, a seller of iron goods, copied much of Franklin's pamphlet. He made small changes to the stove that "rather hurt its operation," took out a patent on it in England and, Franklin wrote, "made, as I was told, a little fortune by it." Other people patented Franklin's inventions too. Franklin never challenged them, he wrote, "having no desire of profiting by patents myself, and hating disputes."

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 9 minutes**

Machines began to do work that had taken many hands, and after one of them, the cotton gin, planters enslaved far more people. Eli Whitney built the gin in 1793. One small gin could clean about 50 pounds of cotton a day, work that took several hundred hours by hand.

Planters grew far more cotton, counted in bales, large bundles pressed tight and tied: fewer than 9,000 bales a year around 1790, more than 200,000 by 1800. To grow it, they held far more people in slavery, about 700,000 in 1790 and nearly 4 million by 1860.

Other machines came into use in the same years. Benjamin Franklin's lightning rods went up on Philadelphia roofs in the 1750s, and by 1755 the first steam engine in America was pumping water from a New Jersey mine. Samuel Slater's cotton-spinning mill began work at Pawtucket, Rhode Island, in 1790, the start of the factory cloth industry in the United States. Slater hired children to run its machines.

### Franklin's lightning rod, step by step

Franklin described a way to protect buildings from what he called "electrical fire" in a letter of 1750 to Peter Collinson. After lightning tests in France in 1752, and then the kite test that Franklin described, the first lightning rods went up on buildings in Philadelphia.

Franklin printed instructions for making one in *Poor Richard's Almanack* for 1753. Readers were to take a small iron rod and push one end three or four feet into moist ground, with the other end standing six or eight feet above the top of the building. A foot of brass wire, sharpened to a fine point, went on the top end. Small staples held the rod to the house.

When lightning struck, it would hit the point and pass through the metal into the ground, "without hurting any Thing," Franklin wrote. Pointed rods soon stood on buildings throughout the colonies.

### The first steam engine in America

The first steam engine in America pumped water out of a mine. It was ordered from England in 1748 for Colonel John Schuyler's copper mine, in what is now North Arlington, New Jersey. The parts arrived in 1753. An engine builder named Josiah Hornblower put it together, and it was pumping by 1755.

It was a Newcomen engine, named for Thomas Newcomen, who built the first one in England in 1712. A boiler filled a large tube, called a cylinder, with steam. Then a spray of cold water turned the steam back into water, which left the cylinder nearly empty. The weight of the air outside pushed a piston, a tight-fitting plug, down into the cylinder. The piston pulled one end of a big rocking beam, and the other end of the beam worked the pump in the mine.

### The cotton gin and slavery

The cotton gin cleaned cotton so fast that planters grew far more of it, and they held far more people in slavery to grow and pick it. Upland cotton has sticky seeds caught in its fiber. Before 1793, enslaved people pulled the seeds out by hand, and one worker needed many hours to clean a single pound. Planters could grow only as much cotton as their workers could clean.

Eli Whitney's cotton gin did the cleaning by machine. It used two cylinders that combed the cotton through small holes. The seeds could not pass through the holes and stayed behind. A history of the gin by the Eli Whitney Museum states that one small gin could clean 50 pounds of cotton a day. By hand, that much cotton took several hundred hours of work.

Planters used the gin to grow far more cotton. Across the United States they grew fewer than 9,000 bales of cotton a year around 1790 and more than 200,000 bales by 1800. By 1860 the cotton crop was more than 400 times as large as in 1790.

**More people enslaved.** With the gin cleaning cotton so fast, planters wanted far more enslaved people to grow and pick it. The 1790 census, the government's count of everyone in the country, recorded 697,897 enslaved people in the United States. By 1860 there were nearly 4 million, more than five times as many, and about 2.5 million of them lived in the cotton-growing regions from eastern Maryland to Texas. Slaveholders spread slavery west across the South.

Enslaved people picked the cotton by hand in the summer sun, about 200 pounds each a day. Solomon Northup was a free Black man from New York. Kidnappers seized him in Washington, D.C., in 1841 and forced him into slavery. Slaveholders held him for twelve years. He picked cotton on Edwin Epps's plantation in Louisiana until he was rescued in 1853.

Northup described the rule in his book *Twelve Years a Slave*, published that year. "An ordinary day's work is two hundred pounds," he wrote. "A slave who is accustomed to picking, is punished, if he or she brings in a less quantity than that." Each night the cotton was weighed at the gin-house, the building where the gin stood. "After weighing, follow the whippings," Northup wrote.

The punishment was the lash, one stroke of a whip on a person's bare body. Northup wrote that twenty-five lashes were "deemed a mere brush," thought of as a small punishment. Fifty was "the ordinary penalty," and one hundred was "called severe." Northup described Epps himself seizing the whip and lashing the people he enslaved.

**Patsey.** Epps once forced Northup to whip an enslaved woman named Patsey, and then took the whip himself. Northup wrote that her back was "covered with long welts," raised and swollen stripes, and that "the lash was wet with blood," meaning the whip itself. Epps then had her washed with salt and water.

Enslaved people ran the gins and the cotton presses too, the machines that squeezed cotton into bales. The machines had many moving parts that could catch and injure a worker. The tiny cotton fibers the gins threw into the air damaged the workers' lungs.

The people who owned the plantations kept the profit. With the gin, Southern plantation owners gained money and political power. Their cotton supplied cloth mills in the Northern states and in Britain. By 1830, cloth and other finished cotton goods were the largest group of factory-made goods the country sold to other countries.

**Cotton land.** Planters wanted new land for cotton. The Eli Whitney Museum's history of the gin states that this demand was "a major factor" in the removal of five Native nations from their homelands in the Southeast: the Cherokee, Chickasaw, Choctaw, Muscogee (Creek) and Seminole.

President Andrew Jackson signed the Indian Removal Act on May 28, 1830. Under it, the president could trade land west of the Mississippi River for the lands of Native nations inside the states. US officials then forced the five nations west to Indian Territory, land that is now part of Oklahoma. At least 60,000 people were forced to make the journey, and more than 8,000 of them died on the way.

US Army soldiers under General Winfield Scott began forcing the Cherokee out of their homeland in 1838. Scott was sent to another post soon after the removal began. The soldiers first held the Cherokee in crowded, dirty camps, where many died.

About 4,000 Cherokee died on the march west that the soldiers forced them to make in the fall and winter of 1838 and 1839. On the march they faced heavy rain, rivers blocked by ice and too little food. Many died of illness, and some died of disease after drinking dirty standing water. White landowners took the land the five nations had been forced to leave.

### Eli Whitney

> **Who:** The builder of the cotton gin, patented in 1794, and the subject of a famous myth about machine-made gun parts.
>
> **When and where:** Georgia and New Haven, Connecticut. Born 1765, died 1825.

**Workers at Whitney's gun factory never made parts that fit any gun.**

Eli Whitney graduated from Yale College in 1792 and traveled south to work as a tutor, a private teacher. On the way, Catherine Littlefield Greene invited him to her plantation, Mulberry Grove, north of Savannah, Georgia. She was the widow of General Nathanael Greene, who had died in 1786 and left her dozens of enslaved people. Enslaved workers on the plantation grew mostly rice and some cotton.

There, in 1793, Whitney built the machine that pulled cotton fiber away from its seeds. He applied for a patent in 1794, and the patent was granted on March 14, 1794.

**Catherine Greene's part.** Whitney held the patent. In 1870 the women's rights activist Matilda Joslyn Gage wrote that Catherine Greene invented the cotton gin. The Eli Whitney Museum states that it "has been suggested that Catherine Greene also contributed ideas to the design."

**Not known:** how much of the design was Catherine Greene's.

**The gun parts.** Whitney signed a contract in 1798 to make muskets for the federal government. He promoted the idea of interchangeable parts, gun parts made by machine so that any part would fit any gun of the same model. According to a famous story, he showed government officials such parts in 1801.

The historian Robert S. Woodbury showed in 1960 that Whitney did not start the idea, and that the credit people gave him for it rests on a myth. Gunmakers at French armories, factories that made weapons, had worked on the idea before Whitney. Workers at Whitney's own factory never made parts that truly fit any gun.

The best-documented first American use of interchangeable parts in a factory came at John H. Hall's rifle works at the Harpers Ferry armory. Hall's workers were putting rifles together from interchangeable parts by 1819.

### Samuel Slater

> **Who:** An English mill worker who rebuilt England's spinning machines from memory at Pawtucket and hired children to run them.
>
> **When and where:** Trained in Derbyshire, England. The mill ran at Pawtucket, Rhode Island, from December 1790.

**He crossed the ocean with England's spinning machines stored in his memory.**

Samuel Slater rebuilt English cotton-spinning machines from memory in the United States. In England, Richard Arkwright had patented a spinning machine in 1769, called the water frame because a waterwheel drove it. Arkwright and his partners built a mill several floors high at Cromford, in Derbyshire, with waterwheels to drive the machines. He moved cotton spinning out of homes and into powered mills with hundreds of workers, and other mill owners copied his system.

Slater trained in a mill in Derbyshire that used Arkwright's machines. Under British law, machines for making cloth could not leave the country, and skilled cloth-mill workers could not move abroad. In 1789 Slater left England without telling officials that he was a trained mill worker.

**Pawtucket.** Moses Brown hired him in December 1789, and Brown's family firm, Almy & Brown, put up the money and the building. With local mechanics, people who build and repair machines, among them the Wilkinson family, Slater rebuilt two kinds of machine from memory. Carding machines combed raw cotton so the fibers lay straight, and spinning machines twisted the fibers into thread, called yarn. The machines at Pawtucket spun their first yarn in December 1790.

**The children.** Slater had worked in a factory for part of his own childhood. At Pawtucket he hired children to run the machines, which were built for children to run. Most of the children at Slater's mill were about 10 years old, and some were as young as six. They were paid by the hour, and they earned much less than adults.

A Boston politician in 1801 described mills that employed "children from four to Ten years old." In the mill villages that grew up later, the child workers were 8 to 14 years old. The names of the first children who worked for Slater are not recorded.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 8 minutes**

The men whose names went on the patents of these years had help. Samuel Morse, Charles Goodyear, the sewing machine maker Elias Howe and the reaper maker Cyrus McCormick each held a patent, a government grant of the only right to make and sell an invention for a set number of years. Morse's partner Alfred Vail built the telegraph instruments. Jo Anderson, a man enslaved by the McCormick family, worked on the first McCormick reaper.

Inventors in the United States built machines to cut grain, plow prairie soil and sew cloth between 1831 and 1846. Goodyear found a way to treat rubber with sulfur so that heat did not melt it. People in Philadelphia made a new French way of taking photographs work in 1839, within weeks of hearing about it. By 1844 Morse's telegraph line ran 40 miles, from Washington to Baltimore.

### How the telegraph sent a message

The electric telegraph sent messages as pulses of electricity through a wire. At the receiving end, each pulse worked an electromagnet, a magnet that works only while electricity flows through it. The magnet moved an arm with a pen-like point, called a stylus.

A clockwork motor, which ran on gears like the inside of a wind-up clock, pulled a strip of paper tape past the stylus. For each pulse, the stylus pressed a small dent into the tape, a short one for a dot or a longer one for a dash. Every letter and number had its own pattern of dots and dashes, and the patterns are called Morse code.

Morse asked Congress for $30,000 in 1843 to build a telegraph line from Washington to Baltimore. Members of the House and then senators voted for the money, and President John Tyler signed the bill.

Ezra Cornell, a man hired to build the line, was supposed to lay the wire underground. When he ran into bad wire, he suggested stringing the wires overhead on trees and poles instead. A signal in a long wire grows weaker as it goes, and Leonard Gale showed Morse how to boost it at points along the line with a device called a relay.

**The first message.** Morse sent the first public message over the line from the US Capitol in Washington on May 24, 1844, and Alfred Vail received it in Baltimore. The words were "What hath God wrought," from the Bible, in the book of Numbers, chapter 23, verse 23. They mean "What has God done."

Annie G. Ellsworth chose the words. Her father was the commissioner of the Patent Office, the head of the government office that grants patents. The paper tape with the message still exists, and the Smithsonian's National Museum of American History holds it.

### Samuel Morse

> **Who:** The inventor who held the patents on the electric telegraph and sent the first public message over the Washington to Baltimore line.
>
> **When and where:** The story is that the idea came to him in 1832. The first public message went from Washington to Baltimore on May 24, 1844.

**Morse got the fame. Alfred Vail built the instruments.**

Samuel Morse held the patents on the American electric telegraph and got the fame for it. According to a Library of Congress history, the idea of sending messages over a distance by electricity came to Morse in 1832, during a conversation on a ship coming home from Europe.

Alfred Vail built and improved the instruments in the shop at the Speedwell Ironworks. The same Library of Congress history identifies hiring Vail as one of the keys to Morse's success.

**The code.** Who worked out the dot and dash code is still argued. Morse held the patents, and people call it Morse code. Starting in 1887, Vail's son Stephen Vail sent letter after letter to newspaper editors claiming the credit for his father. In 1911 another son, J. Cummings Vail, had Alfred's gravestone changed to read "INVENTOR OF THE TELEGRAPHIC DOT AND DASH ALPHABET."

The writer Joseph Connor, in a 2020 article in *American History* magazine, credits Vail with the practical version, which gives the shortest codes to the letters people use most. According to Connor, Vail learned which letters were most common from printers, who kept the metal type for those letters closest at hand.

### Sewing machines, rubber and the camera

Elias Howe patented a sewing machine on September 10, 1846. It sewed a lockstitch, in which two threads lock together through the cloth. Isaac Singer made a more practical machine, and it sold better than Howe's. Howe sued the makers who used his invention. In 1854 judges ruled that Howe's patent was good, and the makers had to pay him royalties, fees for using a patent. At the peak, the fees paid to Howe reached as much as $4,000 a month.

**The Combination.** Howe and the biggest makers, Singer, Wheeler & Wilson, and Grover & Baker, pooled their patents in 1856, so each member could use the others' patented inventions. The members of their group, called the Sewing Machine Combination, controlled the sewing machine trade until 1877.

**Rubber on a hot stove.** A piece of Charles Goodyear's mix of rubber and sulfur landed on a hot stove in Woburn, Massachusetts, in 1839. The rubber charred like leather instead of melting. It took Goodyear five more years to learn to make the change happen every time. He patented the process in 1844, and rubber treated this way is called vulcanized rubber.

The accounts of how the piece reached the stove differ. Mass Moments, a Massachusetts history site, states that he either dropped it or placed it there. A speech in his honor printed in 1860 states that the piece was in his hand and was thrown into the stove "by a violent gesture." The encyclopedia Britannica's account states that it flew from his hand while he was trying to sell his rubber.

**The camera.** François Arago announced the daguerreotype, an early way of making photographs invented by the French artist Louis Daguerre, at a meeting of the French Academy of Sciences in Paris on August 19, 1839. The news reached the United States in late August and September. Within weeks, people in Philadelphia had made the process work for themselves.

Robert Cornelius of Philadelphia made a photograph of himself in October or November of 1839. It is the oldest surviving portrait photograph made in America, and the Library of Congress holds it.

### Cyrus McCormick and John Deere

> **Who:** Two makers of farm machines: McCormick's reaper cut grain, and Deere's steel plow cut through sticky prairie soil.
>
> **When and where:** The reaper at Walnut Grove and Steele's Tavern, Virginia, 1831. The plow at Grand Detour, Illinois, 1837.

**An enslaved man carried the grain that tested the first reaper.**

Cyrus McCormick held the patent on the McCormick reaper, a machine that cuts ripe grain, and he built the business that sold it. Other people worked on the first one.

His father, Robert McCormick, tried for several years to build a reaper at Walnut Grove, the family farm in Rockbridge County, Virginia. In 1831 he gave up. Within six weeks, Cyrus showed a working reaper by cutting oats at nearby Steele's Tavern. A blacksmith named John McCown worked on the machine. So did Jo Anderson, a man the McCormicks enslaved.

**Jo Anderson's own words.** Anderson was born on Robert McCormick's plantation in about 1807. In 1885 a white interviewer, William J. Hanna, wrote down Anderson's words in dialect spelling, which tries to show how a person's speech sounded. Hanna recorded Anderson as 78 years old and unable to walk.

"I was born at old Massa Rob't McCormick's house," Anderson said. "I was his slave, but when a baby was given to Massa Cyrus." Massa meant master. Robert McCormick owned Anderson from birth and gave him to his son Cyrus while Anderson was still a baby.

Anderson said he carried grain to the blacksmith shop to test the machine: "I fotched loose grain to the shop so he could see how it cut it." He also worked as "blower and striker for the blacksmith," the helper who pumps the bellows, the big bag that blows air onto the fire, and swings the heavy hammer.

Anderson gave Cyrus the credit for the reaper and said Robert "tried it and gave it up." He said Cyrus freed him before the Civil War.

**The business.** Another inventor, Obed Hussey, patented a reaper in December 1833. McCormick patented his own in 1834 and printed a warning against Hussey's machine in *Mechanics' Magazine*. He made his first sales in 1840 and moved to Chicago in 1847. In 1859 he and his brothers made and sold more than 5,000 reapers.

**The steel plow.** John Deere made plows at Grand Detour, Illinois. The sticky prairie soil there clogged iron plows. In 1837 Deere built a plow with a polished steel moldboard, the curved blade that turns the soil over. The sticky soil slid off the smooth steel, so the plow scoured, or cleaned, itself as it moved. By 1846 Deere was selling nearly 1,000 plows a year.

**Whose land.** Ho-Chunk people, long called the Winnebago in English, had lived in a village at the bend of the Rock River where Grand Detour stands. Settlers who came later said they could still see signs of that village.

US officials pressured the Ho-Chunk into selling more of their land in 1832. That year Ho-Chunk leaders signed a treaty with two men sent to make it for the United States, General Winfield Scott and John Reynolds, the governor of Illinois. In it the Ho-Chunk gave up their land along the Rock River and across southern Wisconsin, and kept only their land farther north. US officials agreed to pay them $10,000 a year for 27 years and hoped they would move west to Iowa.

The records do not make clear whether this treaty or an earlier one covered the exact spot where Grand Detour stands. Five years after this treaty, Deere built his steel plow there, on land where Ho-Chunk people had lived.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 15 minutes**

Inventors after 1850 worked with patent lawyers and teams of workers, and US officials decided who could own an invention at all. In 1858 the US attorney general, the government's chief lawyer, ruled that an invention by an enslaved person could not be patented. According to the law scholar Kara Swanson, after that ruling free Black inventors could not get patents either.

Alexander Graham Bell received the first telephone patent in 1876. Thomas Edison's team at Menlo Park, New Jersey, made a long-lasting electric lamp in 1879, building on 40 years of work by other inventors.

### Who could own an invention?

Only the person who made an invention could get a patent for it. In 1858 the government's chief lawyer ruled that an enslaved inventor could not get one, and that his owner could not get one either.

**Ned's invention.** An enslaved blacksmith named Ned, near Holmesville in Pike County, Mississippi, had invented a new farm tool by August 1857. It was a "double Cotton Scraper, and two plows" that could "Scrape both Sides of the Cotton ridge at the same time, and plough out the middles," meaning both sides of a raised row of cotton and the low strips between the rows.

Everything known about Ned comes from the letters of Oscar J. E. Stuart, a white planter and lawyer who claimed to own him. Ned's second name, if he had one, is not recorded. How his life ended is not known.

Stuart applied for a patent on Ned's invention on November 15, 1857. He swore that he owned Ned and that Ned was the inventor. Stuart threatened Ned, too. If Ned wrote to the Patent Office himself, Stuart said, he would "correct" Ned "according to our Southern usage," and to correct meant to punish. Stuart made the threat in a letter he later sent to the secretary of the interior, one of the president's top officials. He did not write in it what the punishment would be.

The patent commissioner, Joseph Holt, sent the application back. Under the law, the inventor had to swear an oath, a solemn promise before the law, that he had made the invention, and Holt decided that an enslaved man could not take the oath. Stuart complained to Jacob Thompson, the secretary of the interior. Thompson sent the question to the attorney general, Jeremiah S. Black.

**The ruling.** Jeremiah Black ruled in 1858 that "a machine invented by a slave, though it be new and useful, cannot, in the present state of the law, be patented." He based his ruling on the *Dred Scott* decision of 1857, in which the justices, the judges of the Supreme Court, ruled that African Americans were not citizens. Without citizenship, Jeremiah Black reasoned, an enslaved inventor could not swear the oath. The owner could not get the patent either, because only the "original and first inventor" could.

Free Black inventors had received patents before this. The law scholar Kara Swanson writes that Jeremiah Black's opinion "created a formal racial barrier" to the patent system, a bar written into the rules. After it, free Black inventors could not get patents either.

Stuart asked Congress twice for a patent and failed both times. In 1859 Senator Albert Gallatin Brown of Mississippi backed a bill that would let enslavers patent the inventions of the people they enslaved, but senators never moved the bill forward. Stuart sold the "Stuart Double Plough and Scraper" anyway, without a patent.

**A propeller for boats.** Benjamin Montgomery, enslaved in Mississippi by Joseph Davis, invented a better propeller for boats. In the late 1850s Joseph Davis tried to patent it through his brother, Jefferson Davis, then a US senator from Mississippi. Patent Office officials turned him down for the same reasons they had given Stuart: Joseph Davis was not the inventor, and an enslaved inventor could not swear the oath.

**The Confederacy.** Delegates from seven Southern states that had broken away from the United States met in Alabama in February 1861. There they set up their own government, the Confederate States of America, also called the Confederacy, and chose Jefferson Davis as its president. On May 21, 1861, he signed a Confederate patent law under which enslavers could patent the inventions of the people they enslaved.

Benjamin Montgomery was free by June 1864, when he applied for a patent on his propeller in his own name. No patent was ever issued, and the records do not say why.

**Patents again.** At the end of the Civil War in 1865, members of Congress and lawmakers in the states added the 13th Amendment, a change to the Constitution, and with it ended slavery everywhere in the country, except as a punishment for a crime. Under the 13th Amendment and the amendments that followed it, Black inventors could get patents again.

**Counting Black inventors.** Henry E. Baker, a Black patent examiner who checked patent applications for the government, published a count of the patents Black inventors had received. He wrote it in 1913, to mark fifty years since the Emancipation Proclamation of 1863, President Abraham Lincoln's order declaring free the enslaved people in the Confederate states.

Baker called the pamphlet *The Colored Inventor*, using a word of the time for Black Americans. The publishers of *The Crisis*, the magazine of the NAACP, a group that works for the rights of Black Americans, printed it.

The Patent Office's records did not show an inventor's race. To find Black inventors, Patent Office staff wrote to thousands of patent lawyers, to newspapers and to factory owners, then checked each answer against the records. Baker counted about 800 patents granted to Black inventors. He judged that the real number was at least twice that, because many lawyers said they could not remember the names of their Black clients.

### The telephone, 1876

A telephone turns the sound of a voice into electric current and back into sound. In Bell's own description from 1876, the voice makes a thin sheet, called a membrane, shake in time with the sound. The shaking makes the electric current in the wire grow stronger and weaker in the same pattern. At the other end, the changing current makes a second sheet shake, and the listener hears the voice.

Bell's lawyer filed an application for a patent called "Improvement in Telegraphy" on the morning of February 14, 1876. It was the fifth filing at the Patent Office that day. A few hours later, papers from Elisha Gray arrived as the 39th filing. Gray filed a caveat, a notice that he was working on an invention and planned to apply for a patent. Both papers described a liquid transmitter, a sending part that used a liquid. On the advice of his lawyers, Gray withdrew.

Patent Office officials issued patent number 174,465 to Bell on March 7, 1876. On March 10 Bell spoke the first sentence ever sent by telephone. He spoke to his assistant, Thomas A. Watson, who was in the next room of Bell's laboratory in Boston. Bell's notebook records the words "Mr. Watson," then "come here," then "I want to see you."

Bell filed first and held the patent. People have argued ever since about whether Bell or Gray deserved the credit.

### Alexander Graham Bell

> **Who:** A Boston inventor whose lawyer filed for the telephone patent a few hours before a rival's papers arrived.
>
> **When and where:** Boston, 1876.

**Bell's first working telephone used a sending part like his rival's.**

Alexander Graham Bell was a professor at Boston University when he worked on the telephone. He hired Thomas A. Watson, who had worked in a Boston machine shop since 1872, as his assistant.

The telephone Bell spoke through on March 10, 1876, had a liquid transmitter like the one Elisha Gray had described in his caveat, which was supposed to stay secret. Benjamin Lathrop Brown studied whether Bell had copied Gray, and he concluded that Bell and his lawyers did not.

Brown published his study in November 2020 in an engineering journal, the *Proceedings of the IEEE*, as "The Bell Versus Gray Telephone Dispute: Resolving a 144-Year-Old Controversy." He based his finding on letters, notes kept by a man who worked with Bell, and the engineering details of the two designs. He was answering several people who had claimed that Bell saw Gray's papers on a trip to Washington and copied the idea.

### Emma Nutt

> **Who:** The first woman telephone operator.
>
> **When and where:** Boston, hired September 1, 1878.

**Her pay as the first woman telephone operator: $10 a month.**

Emma Nutt left a job at a telegraph office on September 1, 1878, to work for the telephone dispatch company in Boston. She became the first woman to work as a telephone operator, the person who connected each caller to the person being called. Her pay was $10 a month for a 54-hour week, less than 5 cents an hour. Her sister, Stella, started work as an operator the same day.

The first operators had been teenage boys, who were rude to callers and played pranks on them. The telephone companies' managers replaced the boys with women. By the late 1880s, almost every telephone operator was a woman. It was one of the first big jobs in a new technology open to women.

Emma Nutt worked as an operator for more than 30 years. The New England Historical Society, *Boston Magazine* and *Time* give the exact length as anything from about 33 to about 37 years.

### Edison's team at Menlo Park

An electric lamp makes light when an electric current heats a thin thread inside it, called a filament, until the filament glows. Inventors had worked on electric lamps for 40 years before Edison's team made its lamp in 1879. British inventors showed arc lamps, which make light from a spark between two rods, starting in 1835. Joseph Swan in England patented a lamp design before Edison did, and so did William Sawyer and Albon Man.

Edison ran a laboratory at Menlo Park, New Jersey, with a team of workers. Among them were Charles Batchelor, John Kruesi and Francis Upton. In October 1879 the team made a lamp with a filament of cotton thread that had been baked into carbon. It burned for about 14.5 hours. Edison showed the lamps to the public at Menlo Park on New Year's Eve, 1879. The team kept testing filaments and settled on one made of bamboo. It let Edison's lamps burn for up to 1,200 hours, 50 full days.

**Lighting a district.** Edison's team built the other parts needed to light a whole district: the dynamo, a machine that makes electricity when it is turned, the wiring, and a meter to measure how much electricity each customer used. The Pearl Street station at 257 Pearl Street in Manhattan began supplying electricity on September 4, 1882, to the first district of paying customers.

The Menlo Park team built other machines too. Two years before the lamp, in early December 1877, John Kruesi built a phonograph, a machine that records sound and plays it back, to Edison's design. The first one recorded on a sheet of tinfoil, and on December 6, 1877, Edison recorded himself saying "Mary had a little lamb."

### Thomas Edison

> **Who:** An inventor whose team at Menlo Park made a long-lasting electric lamp, the phonograph and the system that brought electric light to paying customers.
>
> **When and where:** Menlo Park and West Orange, New Jersey. Born 1847, died 1931.
>
> **Movie:** *Edison* (2015), a documentary in the PBS series *American Experience*. It is about Edison's life and work.

**Edison's West Orange laboratory had room for 20 projects at once.**

Thomas Edison worked with a team. In 1876 he moved his staff of assistants to Menlo Park, New Jersey, and set up a laboratory with all the equipment needed to work on any invention. The National Park Service calls it the first research laboratory of its kind anywhere, the model for later ones.

In November 1887 Edison opened a much bigger laboratory in West Orange, New Jersey, less than a mile from his home. It had five buildings, with machine shops, a library and separate rooms for work in physics, chemistry and metals. Because the laboratory was so large, Edison and his staff could work on as many as 10 or 20 projects at once.

Edison first showed motion pictures in 1891. Two years later he began making movies to sell, in a building on the laboratory grounds called the Black Maria. Factories to make Edison's inventions grew up around the laboratory, and at the peak, during World War I, 10,000 people worked there.

### Lewis Latimer

> **Who:** A self-taught draftsman who drew the telephone patent and patented a better way to make the carbon filaments inside electric lamps.
>
> **When and where:** Boston and New York. Born 1848, died 1928.

**The son of two people who escaped slavery drew the telephone patent.**

Lewis Latimer's parents had freed themselves from slavery in Virginia by escaping, and he was born in Chelsea, Massachusetts, on September 4, 1848. He taught himself to be a draftsman, someone who makes exact drawings of machines and buildings. While he worked at a patent law firm, he made the patent drawings for Bell's 1876 telephone application.

**The filament.** Latimer patented a better way of making the carbon filaments that glow inside electric lamps. The patent, number 252,386, was issued on January 17, 1882, for a "Process of Manufacturing Carbons." His method made filaments that were more even and lasted longer.

He received his filament patent while working at the U.S. Electric Lighting Company of Hiram Maxim. In 1884 he went to work for Edison's company, where he made patent drawings and testified in court as an expert on patents. He also oversaw lamp factories and the setting up of electric lighting in New York, Philadelphia, Montreal and London.

Latimer became one of the 28 first members of the Edison Pioneers, a group of people who had worked closely with Edison before 1885, on January 24, 1918. He was its only Black member. He died in Flushing, in Queens, New York, on December 11, 1928, at the age of 80. The house in East Flushing where he lived from 1903 is now the Lewis Latimer House Museum.

### Granville T. Woods

> **Who:** A Black inventor who patented a way to send messages between moving trains and railroad stations.
>
> **When and where:** Cincinnati, Ohio. Patent issued November 29, 1887.

**People on Edison's side claimed his inventions twice. Woods won both hearings.**

Granville T. Woods invented a way for moving trains and stations to send messages to each other. He patented it as the Synchronous Multiplex Railway Telegraph on November 29, 1887, while working in Cincinnati. With it, the people who directed train traffic, called dispatchers, could know where the trains were.

Woods's telegraph worked by induction, in which a changing electric current in one wire makes a current flow in another wire nearby, without the two touching.

Twice, people on Edison's side claimed that inventions Woods had patented were theirs. Each time Patent Office officials held a hearing, called an interference proceeding, to decide who had invented first. Woods won both times. Edison offered him a job, and Woods turned it down. Over his career Woods received dozens of patents for electrical and railroad inventions.

### Nikola Tesla

> **Who:** A Serbian immigrant inventor whose induction motor used alternating current to make a shaft turn.
>
> **When and where:** New York. Patent issued May 1, 1888.

**Westinghouse paid him $60,000 and promised $2.50 a horsepower.**

Nikola Tesla patented a motor that ran on alternating current, or AC, electric current that switches direction back and forth many times each second.

Other motors carried current to their turning part through brushes, sliding electrical contacts. Tesla's motor worked without brushes because it used induction, the same effect Woods used for his train telegraph.

Tesla was a Serbian immigrant who came to the United States in 1884. He filed for the motor patent in October 1887. The patent, number 381,968, was issued on May 1, 1888.

**The deal.** Westinghouse was a company that built electric generators and motors. In July 1888 it bought a license, the right to use Tesla's patents on AC motors. Tesla received $60,000 in cash and in stock, shares in owning the company. Under the deal he was also to get $2.50 for each horsepower, the measure of a motor's power, of the motors the company sold.

At her first pay of $10 a month, Emma Nutt, the first woman telephone operator, would have had to work 500 years to earn $60,000.

### The typewriter and barbed wire

Christopher Latham Sholes, Carlos Glidden and Samuel Soule patented a typewriter on June 23, 1868. E. Remington & Sons began making it on March 1, 1873. The Sholes & Glidden Type-Writer went on sale in 1874 for $125. Its keyboard began with the letters Q, W, E, R, T and Y across the top row of letters. That arrangement, called QWERTY, is still used on keyboards.

**Barbed wire.** Joseph Glidden, a farmer from De Kalb, Illinois, received patent number 157,124 for barbed wire on November 24, 1874. He was a different man from the Carlos Glidden of the typewriter. Joseph Glidden's barb was a short piece of wire that locked onto a wire of two strands, and he built machines to make the wire in large amounts. Nine wire-fence designs were patented, and Glidden's was the one that sold well.

With barbed wire, people could fence land where there was little wood to build fences. In the West, landowners fenced off land and water that had been open to all. Some were homesteaders, families who had claimed farms, and some were ranchers. Their fences ended the open range, the unfenced land where cattle had grazed freely.

**Range wars.** Other cattlemen had grazed their herds on the open range, treating it as land for everyone's use. In Texas, New Mexico, Colorado and Wyoming, they found their old grazing land fenced off. They first asked officials for the right to use it. Then they fought what the National Archives calls "fierce range wars" against the farmers who owned the fenced land.

Native peoples who moved with the seasons had always used these lands too. The fences blocked them from more of those lands, according to the National Archives, and they called barbed wire "the Devil's rope."

**If you remember one thing:** Inventing became the work of teams and patent lawyers, and the end of slavery changed who could own an invention.

- In 1858: an enslaved blacksmith like Ned could not get a patent for his own cotton scraper, and the man who claimed to own him could not get one either.
- In 1887: Granville T. Woods, a Black inventor, patented his railway telegraph in his own name.

**Next:** After 1900, machines moved into American factories and homes, and two bicycle builders from Dayton, Ohio, flew.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 9 minutes**

Americans brought machines into their factories, farms and homes in these fifty years. Workers at Henry Ford's car plant in Michigan started building car frames on a moving assembly line on October 7, 1913. Electric refrigerators and radios went into American homes, tractors began to replace horses on farms, and chemists made new materials, starting in 1907 with Leo Baekeland's Bakelite, the first plastic made entirely from chemicals.

The airplane and the electronic computer both date from these years. Wilbur and Orville Wright flew a powered airplane in North Carolina on December 17, 1903. In February 1946 engineers at the University of Pennsylvania showed ENIAC, the first general-purpose electronic computer, one that could be set up to solve many kinds of problems.

Scientists at Bell Labs, the research laboratory of the telephone company AT&T, made the first working transistor in December 1947. It was a small part that could control the flow of electricity and make a weak signal stronger. Transistors later replaced vacuum tubes, glass tubes with the air taken out, like light bulbs, in machines like ENIAC.

### The Wright brothers

> **Who:** Wilbur and Orville Wright, bicycle builders from Dayton, Ohio. They invented an airplane with an engine that a pilot could steer and control.
>
> **When and where:** Near Kill Devil Hills, North Carolina, December 17, 1903.
>
> **Movie:** *Wright Brothers' Flying Machine* (2003), a documentary in the PBS series *NOVA*, first shown on November 11, 2003. It is about the brothers' flying machine.

**The first photograph of a flight was the photographer's first photograph ever.**

The Wright brothers made four flights in an airplane with an engine near Kill Devil Hills, North Carolina, on December 17, 1903. Orville flew first. He stayed in the air for 12 seconds and covered 120 feet. On the fourth flight of the day, Wilbur flew 852 feet in 59 seconds.

Five people watched. One of them, John T. Daniels of the Life-Saving Station at Kill Devil Hills, squeezed the camera's shutter bulb and took the photograph of the first flight. It was the first photograph he had ever taken.

The brothers worked out how to steer an airplane on gliders, which have no engine, in 1901 and 1902. Besides going forward, an airplane can move in three other ways, and the Wrights built a control for each.

When the wing tips move up and down, the airplane rolls. The Wrights controlled roll with cables that twisted the tips of the wings. To control pitch, the nose moving up and down, they added a movable part at the front, called an elevator, in 1901. Yaw is the nose swinging from side to side. In 1902 they added a movable upright part at the back, called a rudder, to control it.

To test the shapes of wings, they built their own wind tunnel, in which a fan blows a steady stream of air past a model. They built a light gasoline engine, too, in the workshop of their bicycle shop in Dayton.

**The first death.** Army officers were testing the Wright airplane at Fort Myer, Virginia, on September 17, 1908. Orville flew it with Lieutenant Thomas E. Selfridge of the Army Signal Corps as his passenger. The Signal Corps, the Army's communications branch, was then in charge of the Army's first aircraft.

One of the propellers split and hit a wire, and the plane dived into the ground. Selfridge's skull was broken. He never woke up, and he died that evening, the first person killed in an airplane crash. Orville broke a leg and several ribs and spent seven weeks in the Army hospital.

### Henry Ford

> **Who:** The carmaker whose workers at Highland Park, Michigan, built the Model T on a moving assembly line.
>
> **When and where:** Highland Park, Michigan. The moving chassis line started on October 7, 1913.
>
> **Movie:** *Henry Ford* (2013), a documentary in the PBS series *American Experience*, directed by Sarah Colt. It is about Ford's life and his company.

**A motor and a rope pulled each car frame past 140 workers.**

At Henry Ford's plant in Highland Park, Michigan, the time it took to build the frame of a car fell from more than 12 hours to about 93 minutes. The workers got that speed by building on a moving assembly line. On a moving line, a motor pulls the car or part past the workers, and each worker adds parts or does one task as it goes by.

Ford's workers tried the line first on one part. In the spring of 1913 they put together the flywheel magneto, an engine part that makes electricity, on a line, with the job split into 29 steps done by 29 men along a moving belt.

The chassis line started on October 7, 1913. Each chassis, the frame of the car with its wheels, moved along a line 150 feet long. At first the time to build one fell to under 3 hours.

**Five dollars a day.** Ford announced a pay of $5 for an eight-hour day in January 1914. Before that, workers had earned about $2.34 for nine hours, so the new pay was more than double. Part of his reason was to keep workers who hated the pace of the line.

Ford's workers built cars in a year when about 23,000 workers in American industry died on the job, about 63 a day. Staff at the Bureau of Labor Statistics, a federal office that gathers facts about work, made that count for 1913. It covers every kind of industrial work across the country and gives no number for Ford's plant.

### Radios, refrigerators and plastic

Lee de Forest's Audion of 1906 made weak radio signals stronger. The Audion was a vacuum tube. Inside its glass were a thin wire called a filament, a metal plate, and a bent wire between them called the grid. A small electric current on the grid controlled a bigger current between the other two parts. The Audion could pick up radio signals too, and tubes like it made radios for the home practical.

Philo Farnsworth, age 21, sent the first all-electronic television picture from his lab on Green Street in San Francisco on September 7, 1927. The picture was a straight line, made with his own camera tube, called the image dissector.

**The refrigerator.** The General Electric company began selling the Monitor Top, an electric refrigerator for the home, the same year. It cost about $300, and by the middle of 1929 buyers had bought more than a quarter of a million of them. It was the first home electric refrigerator sold in large numbers.

The researcher Emanuela Cardia studied what American households owned, using the census, the government's count of everyone in the country, taken every ten years. In 1930, 14 percent of households had a mechanical refrigerator, one that kept itself cold with a motor instead of a block of ice. By 1940 the share was 44 percent, and by 1950 it was 80 percent, four homes in five.

**Plastic.** Leo Baekeland, a chemist born in Belgium who lived in the United States, made Bakelite in 1907 from two chemicals, phenol and formaldehyde. It was the first fully synthetic plastic, made entirely from chemicals rather than from anything that grew. He filed for a patent in July 1907 and received it on December 7, 1909.

Nylon, a strong thread-like material made from chemicals, came from Wallace Carothers's work at the DuPont chemical company, which he joined in 1928. Gerard Berchet made the first half ounce of nylon on February 28, 1935, and DuPont officials announced it to the public on October 27, 1938.

### Tractors replace horses

Census takers counted 246,000 tractors on American farms in 1920, and about 26 million horses and mules, more than 100 for every tractor. The Fordson tractor of 1917 was cheap and made in large numbers. About three out of every four American tractors built in the 1920s were Fordsons.

The International Harvester company began selling the Farmall in 1924. It could do the jobs other tractors did, and it could also cultivate, breaking up the soil and clearing weeds between rows of growing crops. Cultivating was the last farm job that horses still did.

The Census of Agriculture of 1954 was the first to record more tractors than horses and mules on American farms: about 4.6 million tractors and about 4 million horses and mules.

### The first computers and the transistor

ENIAC, the first general-purpose electronic computer, was shown to the public at the University of Pennsylvania in February 1946. John Mauchly and J. Presper Eckert designed it at the university's Moore School, and the US Army paid to build it. It was built to work out artillery firing tables, charts that told soldiers how to aim their big guns.

ENIAC had 17,468 vacuum tubes, weighed more than 27 tons, and filled 1,800 square feet. It could not store a program. For each new set of calculations, its programmers, a team of six women, moved its switches and plugged its cables into new places by hand.

**The transistor.** At Bell Labs, a group of scientists led by William Shockley looked for a replacement for vacuum tubes, which often failed. On December 16, 1947, John Bardeen and Walter Brattain placed two gold contacts, very close together, on a small slab of germanium, a chemical element. The electric push, or voltage, on one contact controlled the flow of electricity, or current, through the other.

The device made a signal up to 100 times stronger. It was the first transistor. Workers at Bell Labs chose the name "transistor" in a vote, and the company's officials announced it to the public on June 30, 1948. Bardeen, Brattain and Shockley shared the Nobel Prize in Physics in 1956.

### The six ENIAC programmers

> **Who:** The six women who programmed ENIAC, the first general-purpose electronic computer, and were left out of its celebration.
>
> **When and where:** University of Pennsylvania, Philadelphia, 1945 and 1946.
>
> **Movie:** *The Computers* (2014), a short documentary first shown at the Seattle International Film Festival in 2014. The six programmers are its subject.

**Six women programmed ENIAC. None was invited to its dinner.**

The six were Jean Jennings Bartik, Betty Snyder Holberton, Kathleen McNulty Mauchly Antonelli, Marlyn Wescoff Meltzer, Frances Bilas Spence and Ruth Lichterman Teitelbaum. No one invited them to the dinner held for the machine's public showing in 1946. The records do not say who made the guest list.

At first the six had only drawings of the machine's wiring to learn from. They were hired to work out the paths of artillery shells for the Army, and later they also ran calculations for the scientists at Los Alamos, the laboratory in New Mexico where the atomic bomb was built.

Their story went untold for decades, until Kathy Kleiman learned about the six while she was researching her college thesis, a long paper written at the end of college. She started the ENIAC Programmers Project to record their story. In 1997 the group Women in Technology International named all six to its Hall of Fame. Four of them were there to accept. Ruth Teitelbaum had died, and her husband, Adolph, accepted for her. Frances Spence is not named among those who were there.

### Ernest Lawrence

> **Who:** A scientist who built the cyclotron, a machine that whirls particles in a spiral and uses them to smash atoms.
>
> **When and where:** Berkeley, California, from 1930 and 1931.

**One of his machines had a magnet that weighed 220 tons.**

Ernest O. Lawrence's first cyclotron was small enough to hold in one hand. He built it at Berkeley, California, in 1930 and 1931, out of glass, sealing wax and bronze. It sped up hydrogen ions, hydrogen atoms with an electric charge, to an energy of 80,000 electron volts, a very small unit of energy used for particles.

Each machine Lawrence built after that was bigger. The first model was followed by machines 11 inches, 27 inches and 37 inches across. The 60-inch cyclotron of 1939 had a magnet that weighed 220 tons. Inside each machine, particles whirled in a spiral and then struck atoms and broke them apart.

Scientists used cyclotrons to make elements that do not occur in nature. They made radioactive materials for use in medicine, too, materials whose atoms break down and give off energy and tiny particles. Lawrence won the Nobel Prize in 1939. One later machine at Berkeley, the 88-Inch Cyclotron, still runs.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 9 minutes**

Computers shrank from machines that filled a room to machines that sat on a desk at home, and people linked them into networks. Jack Kilby of Texas Instruments built the first integrated circuit, a whole electronic circuit on one small chip, in 1958. The Altair 8800, a computer sold as a kit of parts, was announced in the magazine *Popular Electronics* in January 1975, and IBM began selling the IBM PC in 1981. The IBM PC became the standard office computer.

A student at the University of California, Los Angeles, or UCLA, sent the first message between two computers on ARPANET, a network that linked computers at universities, on October 29, 1969. Martin Cooper of Motorola made the first call on a handheld cell phone four years later. All 24 satellites of the Global Positioning System, or GPS, were working by 1995.

### Grace Hopper

> **Who:** A mathematician and Navy officer whose A-0 compiler let people write instructions for a computer in words closer to English.
>
> **When and where:** Harvard University from 1944, then Remington Rand, the company that made the UNIVAC computer. Born in New York in 1906, died in 1992.
>
> **Movie:** *The Queen of Code* (2015), a short documentary directed by Gillian Jacobs, part of the FiveThirtyEight series *Signals*. It is about Hopper's life and work.

**At 79 she was the oldest officer still serving in the Navy.**

Grace Hopper's A-0 compiler, built in 1951 and 1952, was a program that takes instructions written closer to human language and translates them into instructions the computer can carry out.

Hopper trained as a mathematician. During World War II she served as a lieutenant in the WAVES, the women's branch of the Navy. In July 1944 she was assigned to the Harvard Mark I computer, and she became one of its first programmers. In 1946 she wrote the first long manual on how to program a computer.

She built the A-0 compiler while working on the UNIVAC computer at the Remington Rand company. From 1955 to 1959 she worked on FLOW-MATIC, a programming language for business. Like other programming languages, it was a set of words and rules for writing instructions a computer can follow, and its words were English words. Later, the designers of COBOL, another business programming language, drew on FLOW-MATIC.

Hopper retired from the Navy in 1986 as a rear admiral, one of the Navy's highest ranks. She was 79, and at that time she was the oldest officer still serving in the Navy.

### Who invented the chip?

Two engineers at two different companies, Jack Kilby and Robert Noyce, each made a chip. The encyclopedia Britannica and the German Patent and Trade Mark Office both name the two men as its inventors. A chip, or integrated circuit, puts a whole electronic circuit, the path electricity flows through and the parts along it that do jobs such as switching it on and off, onto one small piece of material.

Kilby, of Texas Instruments, showed the first integrated circuit on September 12, 1958. He made it from germanium and connected its parts with wires by hand.

Noyce, of Fairchild Semiconductor, designed a chip made of silicon, another chemical element, in 1959. On Noyce's chip the wiring lay flat and was printed onto the surface, so factories could make chips in large numbers. Every later chip was built in Noyce's flat form. Silicon Valley, the area south of San Francisco where many computer companies started, is named for this element.

Kilby received the Nobel Prize in Physics in 2000. Noyce had died in 1990. Kilby said in public that Noyce deserved to share the prize.

### Martin Cooper

> **Who:** A Motorola engineer who made the first call on a handheld cell phone.
>
> **When and where:** A street in Manhattan, New York City, April 3, 1973.

**The first handheld cell phone call went to his rival.**

Martin Cooper, an engineer for the Motorola company, made the first call on a handheld cell phone while walking along a street in Manhattan on April 3, 1973. He called Joel Engel, his rival at Bell Labs.

The phone Motorola sold to the public came 10 years later. The DynaTAC 8000X went on sale in 1983. It cost $3,995 and weighed 28 ounces, almost 2 pounds. One charge of its battery gave about 30 minutes of talking.

### The personal computer

The Altair 8800, a computer sold as a kit, a box of parts that the buyer puts together, was announced in the magazine *Popular Electronics* in January 1975. About 30 people came through a rainstorm to Gordon French's garage in Menlo Park, California, on March 5, 1975, to see an Altair. That meeting was the first of the Homebrew Computer Club, a group of people who built their own computers.

Steve Jobs, Steve Wozniak and, for a short time, Ron Wayne founded Apple Computer on April 1, 1976. The Apple II, which came out in June 1977, was a finished computer that people could plug in at home. IBM brought out the IBM PC on August 12, 1981, and its design became the standard for computers in offices.

### Lee Felsenstein

> **Who:** An engineer who ran the meetings of the Homebrew Computer Club and designed two early small computers, the Sol-20 and the Osborne 1.
>
> **When and where:** Berkeley and the San Francisco Bay Area, California, from 1973. Born in Philadelphia in 1945.

**He put a public computer terminal in a Berkeley record store.**

**Arrested at Sproul Hall.** Nine years before he set up that terminal, Lee Felsenstein was a student at the University of California, Berkeley. He took part in the Free Speech Movement of 1964, a protest by Berkeley students for the right to speak and organize about politics on campus. He was at the Sproul Hall sit-in, where students sat inside a campus building and refused to leave. On December 3, 1964, hundreds of police officers went into the building and arrested nearly 800 students, Felsenstein among them.

**Community Memory.** Felsenstein earned a degree in electrical engineering and computer science at Berkeley in 1972. The next year he and four partners, among them Efrem Lipkin and Jude Milhon, set up a computer terminal that anyone could use, a keyboard and a printer or screen connected to a computer somewhere else. They called the project Community Memory and put the terminal in a Berkeley record store, Leopold's Records, next to the store's paper bulletin board.

People typed notes about music, politics, housing, services, women's groups and technology, and other people read them. The Computer History Museum's profile of Felsenstein describes it as one of the earliest online communities. The last version of the project closed in 1992.

Community Memory ran on a large computer called an SDS-940, which was donated for the project. It was a time-sharing computer, one that many people could use at once from different terminals. The project's team worked with Resource One, a nonprofit group, run for a cause rather than for profit. Three students who had dropped out of computer science at Berkeley had started Resource One.

**Homebrew.** Felsenstein was one of the first members of the Homebrew Computer Club, and he ran its open meetings, keeping order with a blackboard pointer.

With Gordon French and Bob Marsh, at a company called Processor Technology, he designed the Sol-20, one of the first small computers sold with its own case and keyboard. More than 10,000 were sold from 1977 to 1979. He then designed the Osborne 1 for Adam Osborne's company, a portable computer with a 5-inch screen. It cost $1,795, and more than 125,000 were sold in 1982.

His motto, as the Computer History Museum records it, is "To change the rules, change the tools." In 2016 the museum's leaders gave him their Fellow Award for his influence on early personal computing.

### Steve Jobs and Steve Wozniak

> **Who:** The founders of Apple Computer: Wozniak designed its first two computers, and Jobs made the first sale.
>
> **When and where:** Jobs's garage in California, from 1976.
>
> **Movie:** *Steve Jobs* (2015), directed by Danny Boyle and written by Aaron Sorkin. It is a drama, not a documentary. Actors play the real people, and it is based on Walter Isaacson's biography of Jobs. *Steve Jobs: The Man in the Machine* (2015), directed by Alex Gibney, is a documentary about Jobs.

**A Volkswagen and a calculator paid for the first Apple computer.**

Steve Wozniak designed Apple's first two computers, and Steve Jobs found the first buyer. The two met while they were both working at the Hewlett-Packard company. In 1975 Wozniak began developing the Apple I. He later said that the Homebrew Computer Club was where the Apple I got its start.

To pay for the first working model, Jobs sold his Volkswagen and Wozniak sold his scientific calculator, for $1,300 in all. On April 1, 1976, they founded Apple Computer, with Ron Wayne as a partner for a short time. Jobs and Wozniak built the first Apple I computers in Jobs's garage.

On his first sales call, Jobs got an order for 50 of them at $500 each, $25,000 in all, from a store called the Byte Shop. The Apple I came without a case, a keyboard, a screen or a power supply. Buyers added their own.

**The Apple II.** Wozniak designed the Apple II in 1977. Its electronics, keyboard and power supply came together in one case, and it could show color pictures. The programming language BASIC came stored in its permanent memory, a part that keeps what is stored in it even when the power is off.

A floppy disk drive for storing files became available for it in 1978, and in 1979 VisiCalc came out, a spreadsheet program for working with tables of numbers. With those two, the Apple II sold in large numbers. Apple's sales grew from $7.8 million in 1978 to $117 million in 1980, 15 times as much in two years.

### How the internet began

The internet began with ARPANET, a computer network paid for by the Department of Defense to link computers at universities. On October 29, 1969, Charley Kline, a student programmer in Leonard Kleinrock's lab at UCLA, tried to log in to a computer at Stanford Research Institute. He typed "L" and "O," the first two letters of LOGIN, and then the system crashed. So the first message ever sent on the network was "LO." About an hour later the full login worked.

The computers on ARPANET began using TCP/IP, the internet's shared set of rules for moving data between computers, on January 1, 1983.

**The web.** Many people use "the web" and "the internet" to mean the same thing, but they are two different things. The internet is the network of linked computers. The World Wide Web is a system of pages linked to one another, which people read over the internet.

A British computer scientist, Tim Berners-Lee, invented the web at CERN, a European physics laboratory in Switzerland. He proposed it in 1989 and opened it to the public on August 6, 1991. Americans built the program that let ordinary people use the web easily. Marc Andreessen, Eric Bina and others at the University of Illinois released Mosaic, the first widely used graphical browser, a program that shows web pages with pictures, on April 22, 1993.

**GPS.** The Global Positioning System, or GPS, is a set of satellites owned by the United States. Each satellite sends out a signal that gives its position and the time, and a GPS receiver picks up these signals and uses them to work out where it is. The first GPS satellite went up on February 22, 1978, and the full set of 24 was working in 1995.

Until 2000, under a policy called Selective Availability, US government officials made the GPS signals for the public less exact on purpose, for national security. President Bill Clinton ordered the policy ended in May 2000. After that, ordinary GPS receivers could find their place to within about 10 to 20 meters (about 30 to 65 feet) or better, close enough to give driving directions turn by turn.

### What is inside a smoke detector?

The ionization smoke detector, a cheap alarm made in large numbers for homes, holds about a third of a millionth of a gram of americium-241. Americium is a radioactive element, one whose atoms break down and give off energy and tiny particles, and scientists discovered it in 1944 and 1945.

The americium gives off tiny particles called alpha particles. The particles knock bits of electric charge loose from the air in a small chamber inside the detector, so a very small electric current can flow through the air. When smoke enters the chamber, it disturbs the current, and the alarm goes off.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 11 minutes**

Nine in ten American adults carried a smartphone by 2025, a survey by the Pew Research Center found, and new programs could write answers and match faces, sometimes wrongly. Apple began selling the iPhone in 2007. In 2022 the company OpenAI released ChatGPT, a program that writes answers to typed requests, and by February 2026, 44 percent of American adults told Pew they had used it.

ChatGPT is an AI program. AI, short for artificial intelligence, is a name for computer programs that do tasks such as recognizing a face or writing a paragraph, and these programs make mistakes. In 2020 Detroit police arrested the wrong man after a face-recognition search, a computer comparison of a photo of a face with a collection of photos, returned a false match.

### The smartphone

Steve Jobs of Apple announced the iPhone on January 9, 2007. It went on sale on June 29, 2007, for $499 or $599, with a phone contract, a promise to pay a phone company for service every month. On September 10, 2007, Apple officials announced that the company had sold its one millionth iPhone the day before, 74 days after the phone went on sale.

A smartphone puts a computer, a camera, a phone, a GPS receiver and a music player into one machine that fits in a pocket. Social media apps run on these phones.

Researchers at the Pew Research Center, a group that runs large surveys, have asked Americans whether they own a smartphone since 2011. In their first count, in 2011, 35 percent of adults owned one, about one in three. In a survey of 5,022 adults from February to June 2025, 91 percent did, and 98 percent owned some kind of cell phone.

Older people were less likely to own a smartphone. Among adults aged 18 to 29, 97 percent had one, against 78 percent of those 65 and older.

For some Americans, the phone is the only way to get online. In the same 2025 survey, 78 percent of adults had broadband at home, a fast internet connection that is always on. Among adults in households earning less than $30,000 a year, 34 percent reached the internet only through a smartphone. Among those earning $100,000 or more, 4 percent did.

### Batteries, printers and gene tools

The battery in an electric car is a lithium-ion battery, a kind that can be recharged many times. Scientists in three countries worked on it, starting in the 1970s, when M. Stanley Whittingham began work on rechargeable lithium batteries for the company Exxon in New Jersey.

John Goodenough, an American chemist then working at Oxford in England, found the material for the battery's cathode, its positive end, in 1980: lithium cobalt oxide. Akira Yoshino in Japan built a safe early model with a carbon anode, the negative end, in 1985. The Sony company in Japan began selling the first lithium-ion batteries in 1991. Whittingham, Goodenough and Yoshino shared the Nobel Prize in Chemistry in 2019.

**3D printing.** A 3D printer builds a solid object out of many thin layers, one on top of another. Chuck Hull invented stereolithography, a method of 3D printing in which the machine hardens each thin layer in turn, in 1983 and 1984. He applied for a patent on August 8, 1984, and received it on March 11, 1986. In the 2010s, 3D printers spread to factories and to hobbyists' desks.

**Gene tools.** CRISPR is a tool for changing genes, the instructions inside living cells that shape how a living thing grows and works. Chapter 9 tells how the scientists Jennifer Doudna and Emmanuelle Charpentier made it into that tool in 2012.

### Limor Fried

> **Who:** An engineer who founded Adafruit Industries, a company that makes electronics kits and teaches people to build with them.
>
> **When and where:** MIT in Cambridge, Massachusetts, then New York City, from 2005.

**Adafruit's designs are open source: anyone may copy and change them.**

Adafruit Industries began in 2005 in Limor Fried's dorm room at the Massachusetts Institute of Technology, or MIT, a university in Cambridge, Massachusetts. She had earned a bachelor's degree from MIT in 2003, and she finished a master's degree in engineering there in 2005. Adafruit sells electronics kits along with lessons on how to build them, and it shares its designs as open source, free for anyone to copy and change.

According to the company's website, Fried was the first woman engineer on the cover of *Wired* magazine, and women own all of the company. Adafruit's workers make its products in the company's factory in New York City. In 2024 Adafruit moved to Industry City in Brooklyn. The company's website states that it has more than 100 employees.

### How AI programs work, and why they make mistakes

One kind of AI program, a neural network, learns from examples instead of following step-by-step instructions written by a person. To train a network to name what is in photographs, a computer shows it a huge number of photos whose right answers are already known.

Each time the network gives an answer, the computer compares it with the right answer and adjusts the network's settings a little, so that the next answer comes closer. After enough examples, the network can name what is in photos it has never seen, though it still makes mistakes.

**A contest.** Alex Krizhevsky, Ilya Sutskever and Geoffrey Hinton of the University of Toronto won ImageNet in 2012 with a neural network called AlexNet. ImageNet was a contest that scored computer programs on naming what is in photographs. Each program gave its five best guesses for each picture. AlexNet missed with all five on about 15 of every 100 pictures, and the second-place program missed on about 26 of every 100. After AlexNet's win, neural networks came into wide use, a time called the deep-learning era.

ChatGPT and programs like it produce text, pictures and computer code from requests typed in plain language. OpenAI released ChatGPT on November 30, 2022. Five days later, OpenAI's chief executive, Sam Altman, posted online that it had "crossed 1 million users." Analysts at the bank UBS estimated that by the end of January 2023, about 100 million people a month were using it.

**Why they make mistakes.** Staff at the National Institute of Standards and Technology, a federal agency, published a report in July 2024 on how large language models, programs that write text, work and why they make mistakes. A program of this kind predicts the next word in a sentence, over and over. That kind of guessing can produce true statements, and it can also produce false ones. The report states that the programs give false answers in a confident way, and that people who believe them can be misled.

**Fake cases in court.** Two lawyers in a federal court case in New York cited court decisions in 2023 that ChatGPT had made up. Lawyers cite, or point to, earlier decisions to show a judge how courts have ruled in cases like theirs.

Roberto Mata had sued the airline Avianca, saying a metal serving cart struck his knee on a flight. On March 1, 2023, his lawyers, Steven A. Schwartz and Peter LoDuca, filed a court paper that cited earlier decisions to support Mata's side. ChatGPT had made up those decisions and the quotes from them.

Schwartz later said that he asked ChatGPT whether one case was real, and it answered that the case "does indeed exist." In written orders, the judge then asked whether the cases existed, and the lawyers kept standing by them. On June 22, 2023, Judge P. Kevin Castel found that the lawyers had acted in bad faith, meaning dishonestly. He ordered the two lawyers and their law firm to pay a penalty of $5,000.

### Karla Ortiz

> **Who:** A San Francisco concept artist whose designs went into Marvel films and who told US senators how AI image programs affected artists.
>
> **When and where:** San Francisco and Washington, D.C., from 2022.

**"I am no longer certain of my future as an artist."**

Karla Ortiz is a concept artist, an artist who draws the first designs for characters and scenes. Her designs went into Marvel films, including *Doctor Strange*, *Black Panther* and *Avengers: Infinity War*. She worked on the video game *Final Fantasy 16* and the card game *Magic: the Gathering*, too.

Ortiz first saw an AI image program in April 2022. A website showed pictures made by a machine that copied the styles of named artists, her friends among them. No one had asked them. By August and September of 2022, the programs Midjourney, Stable Diffusion and DALL-E were in wide use.

**The lawsuit.** Ortiz, Sarah Andersen, Kelly McKernan and other artists sued Stability AI, Midjourney and DeviantArt in federal court on January 12, 2023. They said the companies had broken copyright law, the law that protects an artist's right to decide who copies their work.

**Her testimony.** Ortiz gave written testimony, a statement to lawmakers, to a subcommittee of the US Senate Judiciary Committee on July 12, 2023. In it she explained how the popular image programs were built. Their makers trained them on a collection of 5.8 billion pictures with captions, "taken indiscriminately from the web," meaning without anyone choosing which ones.

People at a nonprofit group called LAION, which the company Stability AI funded, built the collection. Ortiz wrote that the collection "includes almost all of my fine art work."

She described what she had seen in her own work. She had been part of three productions where generative AI, AI that makes new pictures, text or sound, had been "utilized," or used, "at different levels." "Some of my peers have lost jobs, some have had their duties lessened (and of course, their proposed pay)," she wrote.

She also wrote, "I am no longer certain of my future as an artist." She worked with researchers at the University of Chicago on Glaze, a program meant to protect artists' pictures from having their style copied.

US District Judge William Orrick ruled on August 12, 2024, that the artists' main copyright claims could go forward toward a trial. As of October 2, 2026, the case had not gone to trial. On September 28, 2026, Judge Orrick changed the schedule so that the next major motions in the case, formal requests to the judge, are to be heard by September 29, 2027.

### Arrested by a false match

Detroit police officers arrested Robert Williams, a Black man, at his home in Farmington Hills, Michigan, in January 2020, after a face-recognition search matched him by mistake. They arrested him in front of his wife and two young daughters and in view of his neighbors.

The software, which names possible matches for a face from a collection of photos, had matched a blurry picture from a store's security video to his expired driver's license photo. The video showed a theft of watches from a Shinola store in Detroit in 2018. Williams was not the man in the video.

Police used the match to build a photo lineup, a set of photos shown to someone who might pick out the thief. They showed it to a contractor hired to prevent theft at the store, who had not seen the theft and knew it only from the video.

**Thirty hours.** Detroit police held Williams for 30 hours. The ACLU, the civil rights group whose lawyers represented him, described the place he was held as "an overcrowded, dirty cell." Wayne County prosecutors dropped the charges, but they kept the right to bring them again.

The county's prosecutor, Kym Worthy, apologized. "This case should not have been issued based on the DPD investigation, and for that we apologize," she said, using the initials of the Detroit Police Department. His was the first publicly reported case in which police wrongly arrested someone after a false face-recognition match.

At least three Detroit arrests of this kind are publicly known, according to reporting by Michigan Public in 2024. In 2023 Detroit police wrongly arrested Porcha Woodruff, who was pregnant, for a carjacking, stealing a car from its driver.

**The settlement.** Williams and lawyers for the City of Detroit settled his lawsuit on June 28, 2024. Under the settlement, Detroit police may not arrest anyone based on a face-recognition result without other evidence, and they may not build a photo lineup from a face-recognition match alone. They must train officers, including on the higher rate of wrong matches for people of color, and they must review cases back to 2017.

### AI at work, by the numbers

The share of Americans who have used ChatGPT has grown in each Pew survey. Researchers at the Pew Research Center found in February 2026, in a survey of 5,119 American adults, that 44 percent had used it, up from 18 percent in 2023 and 34 percent in 2025.

About half of adults in the 2026 survey used some AI chatbot, a program that answers typed questions in sentences. Among adults with jobs, 38 percent used chatbots for tasks at work. Forty percent of adults expected AI to have a bad effect on society over the next 20 years.

Some employers say AI is the reason they are cutting jobs. Staff at Challenger, Gray & Christmas, a company that helps laid-off workers find new jobs, count the job cuts that American employers announce and the reasons the employers give.

From January through August 2026, employers named AI as the reason for 116,175 announced job cuts. That was about 22 percent of all the cuts they announced, more than one in five and more than for any other reason. These numbers are employers' own statements, not a government count of jobs lost to AI.

**The three questions, answered**

- Why did planters enslave far more people after the cotton gin? One gin cleaned about 50 pounds of cotton a day, work that took several hundred hours by hand. Planters grew far more cotton and enslaved far more people to grow and pick it, nearly 4 million by 1860.
- Why could an enslaved inventor not get a patent? Only the inventor could get a patent, and only by swearing an oath. In 1858 Attorney General Jeremiah Black ruled that an enslaved man was not a citizen and could not swear it, and that the enslaver could not take the patent instead.
- What went wrong when people trusted a computer's answer? In 2023 two lawyers cited court decisions that ChatGPT had made up, and a judge ordered them and their law firm to pay a $5,000 penalty. In 2020 Detroit police held Robert Williams for 30 hours after a face-recognition search matched him by mistake.

**What changed:** Work done by hand moved to machines run by water, then steam and electricity, then pocket-sized computers.

**Five dates to keep**

- 1646: Joseph Jenks gets a patent for his water-driven mills.
- 1793: Eli Whitney builds the cotton gin.
- May 24, 1844: Morse sends the first public telegraph message.
- December 17, 1903: The Wright brothers make the first powered flights.
- November 30, 2022: OpenAI releases ChatGPT.

**Not known:** Ned's second name, if he had one, was never recorded, and nobody knows how his life ended.

**Where to go:** The Saugus Iron Works National Historic Site, in Saugus, Massachusetts, where the 1640s ironworks stands rebuilt.

**Next:** Chapter 9, Science. It follows Americans who measured the world and the people some scientists studied without asking.
