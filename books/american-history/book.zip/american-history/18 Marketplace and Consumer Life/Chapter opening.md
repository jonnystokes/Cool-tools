# Chapter 18: Marketplace and Consumer Life

**Chapter 18 of 37 · Marketplace and Consumer Life · 10 eras · about 75 minutes**

**Americans have taken goods home and paid later since the 1600s, and new ways of selling, from the peddler's trunk to the online store, kept changing who could buy and what they paid.**

In Springfield, Massachusetts, the merchant John Pynchon kept a page in his account book for John Stewart, a Scottish soldier captured in battle in 1650 and "sold for eight years service." On December 29, 1653, Pynchon wrote that Stewart owed him 30 pounds in English money "for releasing him from my Service." Stewart had bought his freedom on credit. For 36 years his page filled with iron, boots, pepper and sugar. He paid in shell beads, blacksmith's work, land and a day of haymaking, almost never in coins.

This chapter describes buying and selling from the trading place on the Columbia River, long before there were shops, to buying online. The peddler at the door, the department store with a price tag on every item, the mail-order catalog, the supermarket, the mall and the credit card come in between. Watch how people paid: in shells and crops, in work, on the shopkeeper's book, a little each month, and at last with plastic. Watch, too, who was turned away and who was sold. Printers ran advertisements offering enslaved people for sale in the same newspapers as everything else, and in the South the people who ran Woolworth's lunch counters served white customers only.

**Three questions this chapter answers**

- How did colonists pay for goods when they had almost no coins?
- Where were people bought and sold like goods?
- How much of what Americans buy today is bought online?

**Five minutes?** Read "The ledger" and the story of John Stewart, in the 1600s.

**Can skip:** "Barnum's American Museum", "The franchise", "Buying secondhand clothes". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 3 minutes**

People in this land traded copper, seashells and stone blades across hundreds of miles long before there were any stores. They traded one thing for another, and goods passed from hand to hand. At a few great trading places, people from many nations gathered to fish and to trade.

### Where was the biggest market in the Northwest?

The biggest trading place in the Northwest was a ten-mile stretch of the Columbia River. It ran from Celilo Falls down to a place called The Dalles, on the border of what are now Oregon and Washington. People fished and lived there. Archaeologists, scientists who study the past from what people left behind, date the first human use of the site to at least 10,000 years ago. Some newspaper and museum writers give 15,000 years.

Traders came from as far north as what is now British Columbia and as far south as California. Some accounts, cited by the Oregon Historical Society, state that traders came from as far east as the Great Lakes.

Northern traders brought coiled baskets, skins and berries. Traders from the south carried obsidian, a black volcanic glass that makes sharp blades, along with bows and captives, people seized by force and traded away with the other goods. The accounts of the trade do not identify who seized them. From the east came buffalo hides and camas, a root that people dug up and ate. From the coast came whale oil, dentalium shells and wapato, another root people ate.

**Dentalium shells.** These are the shells of a small sea animal. Each one is shaped like a tiny elephant tusk and can grow a few inches long. Most of them came from the sea off Vancouver Island, and people passed them from hand to hand over a wide area. So many people accepted them that traders used them to measure what other goods were worth.

Horses came later, after 1500. Spanish colonists had brought horses to the Americas. In the early 1700s, Native traders passed horses north to this part of the river.

Much later, in October 1805, two American explorers, Meriwether Lewis and William Clark, reached this stretch of river. President Thomas Jefferson had sent them west to look for a water route to the Pacific Ocean. In his journal, Clark called the place a "mart," an old word for a market: the "Great Mart of all this Country." People had been trading there long before his visit.

**Under the lake.** The trading place is now under water. Workers for the US Army Corps of Engineers, the part of the army that builds dams and other large works, built The Dalles Dam eight miles downstream. At 10 o'clock on the morning of March 10, 1957, the dam's floodgates were closed.

Four and a half hours later, Celilo Falls lay under the lake behind the dam. The villages of Wyam, on the Oregon side, and S'kin, on the Washington side, went under too. US government officials later paid the Warm Springs, Yakama, Umatilla and Nez Perce nations $26.8 million for the fishing sites they lost.

### Goods that traveled without a store

Archaeologists have found copper from Lake Superior, shells from the Gulf of Mexico, obsidian from the West and turquoise from the Southwest hundreds of miles from where each was dug up or gathered. People carried and traded these goods over those distances, one exchange at a time.

Cahokia was a city near what is now St. Louis. It was at its largest from about 1050 to 1150. Around 1100, about 10,000 to 20,000 people lived there. People at Cahokia controlled the trade in hoe blades made from Mill Creek chert, a hard stone that holds a sharp edge. Archaeologists have found those blades more than 400 miles away. People that far from Cahokia got the blades by trading for them.

No trader from before 1500 is known by name.

## The 1500s

**Era 2 of 10 · The 1500s · about 2 minutes**

Native traders chose which European goods to take, and copper and brass kettles were among the things they wanted most. They traded for them with the crews of European whaling and trading ships off what is now eastern Canada. There were still no stores. Archaeologists can see the traders' choices in the kettles they cut up and made into new things, and in the metal they passed far inland, as far as the Great Lakes.

### What Native customers chose

Native buyers in the Northeast and around the Great Lakes traded for copper and brass kettles in the late 1500s. Basque, French and Dutch traders carried the kettles across the ocean because those buyers asked for them. Crews from the Basque Country, a mountain region on the border of Spain and France, crossed the ocean to hunt whales. They traded with the Beothuk of Newfoundland, the Innu of Labrador and the Mi'kmaq.

Many of these kettles were not used for cooking. Archaeologists dig them up cut into flat sheets. Native craftspeople turned the sheets into beads, tubes, arrow points and pendants, which are ornaments that hang from a cord. For a long time, people in these nations had made the same shapes from copper found as pure metal in the ground. Buyers like these used a kettle as a supply of metal.

Pieces of Basque copper kettles from the late 1500s and early 1600s turn up from the Canadian Maritimes, on the Atlantic coast, to the lower Great Lakes. Native traders passed the metal along among themselves, far inland. Basque kettles and axes reached the lands of the Huron and their neighbors in what is now Ontario.

Native traders chose carefully what they took in trade, and they kept doing so as the trade grew. In the fur trade of later years, they were skilled bargainers who asked for useful tools and for fine goods alike, such as iron knives, wool cloth and glass beads.

**Good guns.** One fur-trading company, the Hudson's Bay Company, began in 1670. Its Native customers demanded good guns, so the men running the company sent gunsmiths to its trading posts to check the guns and repair them.

## The 1600s

**Era 3 of 10 · The 1600s · about 5 minutes**

Colonial shoppers in the 1600s took their goods home first and paid later, mostly in crops, other goods and work. In Springfield, Massachusetts, John Pynchon wrote down in his account books what each customer owed and let the debts run for months. In the same century, public markets opened in the colonial towns, and colonists built trading posts to trade with Native people.

### Market days

A market day was a set day when farmers brought meat, milk, butter, cheese, fruit and vegetables into town to sell. Town people could not travel out to the farms for these foods, so the farmers came to them.

Governor John Winthrop of Massachusetts ordered a market for Boston in 1634. It is the first public market of the European kind recorded by officials in the English colonies. Hartford, in Connecticut, had a market in 1643. New York had one by 1686, and Philadelphia had one in 1693.

### Trading posts

A trading post was a building where colonists traded goods with Native people and with other traders. In 1627, the colonists of Plymouth Colony built one at Aptucxet, on the Manomet River on Cape Cod. It was about 20 miles from Plymouth. The post stood on land of the Wampanoag people, who used the place as summer fishing grounds. The name Aptucxet meant "little trap in the river."

At Aptucxet the Plymouth colonists traded with the Wampanoag for corn and beans, and with Dutch traders. That same year, Isaack de Rasieres, the secretary of the Dutch colony, brought wampum, small beads made from shells and strung together, into Plymouth's trade.

### The ledger

A colonial shopkeeper kept two books. The first, the journal, listed every sale and every purchase in the order it happened. The second, the ledger, gave each customer a page of their own. The customer's purchases went on the left side of the page and the customer's payments on the right.

Customers bought on credit, taking the goods home and paying for them later. A shopkeeper usually let a customer's debt run for up to a year. Customers paid in crops, in other goods, in work and sometimes in coins.

John Pynchon kept a shop in Springfield, Massachusetts. The town and the shop stood on land on both sides of the Connecticut River that his father, William Pynchon, bought from the Agawam people on July 15, 1636. William Pynchon paid for the land in goods, with no coins: 18 fathoms of wampum, strings of beads six feet long, and 18 coats, 18 hatchets, 18 hoes and 18 knives. The Agawam kept their planted fields and the right to fish, hunt deer and gather nuts there.

Seven of John Pynchon's account books survive, with entries from 1651 to about 1702. Almost every adult in Springfield bought goods at his shop. The editors who printed the books found only a few payments in coins. Books like these record what ordinary colonists bought, item by item.

### John Stewart

> **Who:** A Scottish soldier, captured in war and sold into forced labor, who became the blacksmith of Springfield and bought on credit at John Pynchon's shop for more than thirty years.
>
> **When and where:** Springfield, Massachusetts, 1653 to 1689.

**A prisoner of war who owed 30 pounds for his freedom.**

Soldiers of Oliver Cromwell's army captured John Stewart, a Scottish soldier, at the Battle of Dunbar, in Scotland, in 1650. The men on the council that ruled England ordered the governor at Newcastle to hand over 150 of the Dunbar prisoners to the agents of two men who had put money into an ironworks in Massachusetts. In his own recorded words, Stewart was "sold for eight years service." He was forced to work for whoever owned his service until the eight years ran out.

Stewart and the other prisoners crossed the ocean on a ship called the *Unity*. He reached New England in December 1650 and worked at the ironworks at Lynn, in Massachusetts. Then the merchant John Pynchon bought his service and took him to Springfield.

**Buying his freedom.** Pynchon wrote in his account book on December 29, 1653, that Stewart owed him 30 pounds, the main English unit of money, "for releasing him from my Service." While Pynchon waited for the money, Stewart agreed to pay an extra 12 shillings, a smaller unit, each year for three years. He paid that extra in blacksmith's work, "in mending or making of Iron worke."

Stewart became the Springfield blacksmith, and his page in Pynchon's ledger lists what he bought, item by item. For his forge, the fire where a blacksmith heats iron to shape it, he bought 241 pounds of iron by weight in one purchase, then more bars of iron every few weeks, bars of steel and a coal basket. Pynchon charged him for using Pynchon's tools at the shop and for an old bellows, the air pump that blows on a forge fire.

He bought a sword and belt, a grindstone, a pair of boots, wool cloth, silk and buttons, a bushel of apples, soap, a comb, pepper and ginger. Almost none of it was paid in coins. By December 23, 1654, he had paid in two lots of wampum and in smith's work, including work on Pynchon's mill, and neighbors had paid wheat to Pynchon for him. He still owed 13 pounds 6 shillings. Later he paid in land and in a day of haymaking.

The editors of the account books explain that he was fined in 1660 for striking a man named William Morgan and breaking his nose, and in 1662 for playing cards at his house.

**Ten years on.** By 1664 he was still buying on the book: sugar again and again, salt, gunpowder, scissors, pins, a knife for "the Boy," and iron for the horseshoes of the troopers, soldiers on horseback. On February 20, 1666, he owed 11 pounds 17 shillings and 1 penny.

**His wife.** By then Stewart was married. The books charge him for church seats for himself and his wife, but they never give her name. His page also records a charge of 1 pound, a fine for the two of them, for "unseasonable night meetings" (meetings at an improper hour of the night).

Pynchon's books list his purchases until 1689. They do not say what became of his wife. Stewart died at Springfield on April 21, 1691. The Scottish Prisoners of War Society, a group that traces the Dunbar prisoners, records that he left "no family, so far as is known."

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 4 minutes**

Goods made in Britain became cheap enough in the 1700s for colonial families to buy them in large amounts. Shops in the port towns sold these goods, and in Philadelphia Benjamin Franklin made advertisements pay for much of his newspaper. Colonists bought and sold enslaved people in the same towns. In New York, city officials set up a market for those sales, and printers, Franklin among them, ran advertisements offering people for sale.

### The consumer revolution

Colonists began buying many of the clothes, tools and kitchen things they had once made for themselves, mostly from Britain. Historians call this big change in buying by consumers, the people who buy goods to use them, the "consumer revolution."

In Britain, makers found better ways to make goods. Merchants got better at shipping goods across the ocean and at selling them on credit. Prices fell. At the same time, colonial families earned more. Goods that only rich families had owned became ordinary.

Families who drank tea bought a whole set of goods to go with it: a teapot, cups, sugar and a table to set them on. Buying goods like these became a sign that a family was respectable.

### A market where people were sold

In New York, colonists bought and sold enslaved people at a market created by the men who ran the city, the aldermen of the Common Council. They set it up by law on November 30, 1711, at the bottom end of Wall Street, near Pearl Street and Water Street.

Slaveholders sold enslaved Africans at this market and rented them out to others as workers. They sold and rented out Native people held in slavery there too. Under the law, owners who rented out enslaved people as workers by the day had to do it at this market. Buyers inspected the people for sale there, looking them over before buying. The accounts of the market do not describe how the inspections were done.

**The building.** The market was a wooden building with a roof and open sides. Slaveholders used it for 51 years, until 1762.

New York had about 5,000 people in 1700, and at least 750 of them, about one person in seven, were enslaved. Jim O'Grady, a reporter for the New York radio station WNYC, wrote in 2015 that thousands of people were sold at the market: men, women, shiploads of children and captured Native people. The accounts of the market do not identify the men who bought and sold people there.

A sign now marks the place. Jumaane Williams, a member of the New York City Council, asked for it in 2015, and in June of that year Mayor Bill de Blasio officially opened it at Wall Street and Water Street.

### Newspaper advertising begins to pay

Benjamin Franklin bought a newspaper in Philadelphia, the *Pennsylvania Gazette*, from a printer named Samuel Keimer on October 2, 1729. It had about 90 subscribers, the people who paid to get every copy. Under Franklin, the money that sellers paid to print their advertisements became one of the main ways the paper made money.

Franklin changed the way the advertisements looked. He put more empty space around them and used letters of different sizes. He made the *Gazette* four pages instead of two, partly to make room for more advertisements. By 1748 it had more than 1,500 subscribers, and it was the most widely read newspaper in the colonies.

**The partnership.** Franklin stepped back from printing in 1748, when he was 42. He made a partnership with a printer named David Hall, who ran the shop while Franklin kept a share of the profits. Much of the money that let Franklin stop working at his trade so early came from the paper's advertising.

### Benjamin Franklin

> **Who:** The Philadelphia printer who ran advertisements offering enslaved people for sale in his newspaper, and took the fees.
>
> **When and where:** Philadelphia, from October 2, 1729.
>
> **Movie:** *Benjamin Franklin* (2022), a documentary by Ken Burns, shown on PBS. It covers Franklin's whole life.

**At least 277 of his paper's advertisements listed enslaved people for sale.**

Benjamin Franklin published the *Gazette* for 37 years, counting the years when he was David Hall's partner in the paper. In those 37 years, the *Gazette* contained at least 277 advertisements offering at least 308 enslaved people for sale. Franklin ran these notices and took the fees for them. He also acted as the go-between for the buyers and the sellers.

**The runaways.** Slaveholders paid Franklin to print notices about enslaved people who had run away from them. He printed notices about runaway servants too: workers bound to a master for a set number of years, who had left before their years were up.

### Shops and shopkeepers in the port towns

Shopkeepers in the port towns ordered cloth and other goods from London and sold them. Some sold haberdashery, small sewing goods such as thread, ribbons and buttons. Colonists who bought on credit could end up in debt to a local shopkeeper or to a merchant in London.

Women ran some of these shops. Elizabeth Murray came to Boston from Scotland in 1749, when she was 23. She opened a shop that sold cloth and other goods from Britain. Her brother's business friends helped her get started. She traveled to London to choose the goods for her shop, and she earned enough to support herself. Later she helped other women open shops.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 7 minutes**

Many colonists refused to buy British goods from 1767 to 1770, as a protest against British taxes. Merchants promised not to bring the goods in, and families made their own cloth instead of buying it. Members of merchants' committees warned the shopkeepers who kept selling British goods. In Boston, Ebenezer Richardson fired from his house during a protest at one of those shops, next door, and killed a boy named Christopher Seider. Away from the ports, a single storekeeper sold a whole farming neighborhood its goods on credit until the next harvest.

### The boycott of British goods

Members of Parliament, the lawmakers in London, passed a tax law called the Townshend Revenue Act in 1767. Under it, customs officials collected duties, taxes on goods brought into the colonies from Britain. Colonists who opposed the duties answered with a boycott, refusing to buy British goods as a protest.

The seniors at Harvard College in Massachusetts voted in the autumn of 1767 not to drink tea or wear clothes from Britain at their graduation, as a protest against the Townshend duties. At the next year's graduation, the seniors' theses, a printed sheet of the ideas they were ready to argue for in public at the ceremony, were on paper made in New England.

**The agreement.** About 60 Boston merchants and traders signed the Boston Non-Importation Agreement on August 1, 1768. They promised not to bring in most British goods from January 1, 1769, to January 1, 1770. Within two weeks, all but 16 of the town's merchants had joined.

The value of British goods brought into Boston fell by about half, from about 420,000 pounds in 1768 to about 208,000 pounds in 1769. In 1770, members of Parliament took back most of the Townshend taxes. The agreement in Boston ended that year.

### Spinning instead of buying

Families who did not buy British cloth had to make their own, called homespun. To make it, women first spun wool or flax, a plant whose stems give the threads for linen, into yarn on a spinning wheel. Then the yarn was woven into cloth.

Women in New England held at least 46 spinning meetings between 1768 and 1770, where they spun together in public. In all, 1,644 women took part. Ministers held 30 of the meetings, and 94 out of every 100 spinners came to those 30.

**One day in Brookfield.** Women in Brookfield, Massachusetts, met at the minister's house from 5 o'clock in the morning one day in August 1769. The young woman who did best on the linen wheel spun 70 knots, measured lengths of yarn. One married woman did her morning work at home and made cheese first. Then she rode more than two miles carrying her wheel, spun from 9 in the morning to 7 at night, and finished 53 knots. After that she went home to do the milking.

Members of a society in Hartford, Connecticut, offered a prize of 12 pounds to whoever made the most yards of woolen cloth in a year. Printers ran newspaper stories about the meetings. Only six of those stories called the spinners "Daughters of Liberty," a name for women on the side of the protest.

### Ame and Elizabeth Cuming

> **Who:** Two sisters who kept a shop in Boston, refused to join the boycott and were named in the newspaper and the town record for it.
>
> **When and where:** Boston, 1765 to 1776, then Halifax, Nova Scotia.

**A shipment worth 300 pounds, and a warning of "consequences."**

Ame and Elizabeth Cuming kept a shop in Boston and would not stop selling British goods when the town's merchants told them to. The sisters were in their middle thirties and not married, and by 1765 they earned their own living. They sold fashionable goods from London, taught embroidery, sewing pictures and patterns with colored thread, and took in young women who paid to live with them. Elizabeth Murray had helped them start their business.

**The warning.** A shipment of silk and haberdashery worth 300 pounds reached them from London in late 1769. In the middle of November, men from the merchants' committee came to the shop and warned the sisters of "consequences" if they sold the goods. The sisters refused. They said they had never signed any agreement to stop bringing in goods. They called themselves "two industrious Girls" (two hard-working girls) who were trying "in an honest way" to earn their bread.

A notice in the *Boston Gazette* described them as "enemies to their country" who "preferred their own little private Advantage to the Welfare of America." On March 19, 1770, the men at Boston's town meeting voted to write the sisters' names into the town record. The wording of the vote states that this was so that "POSTERITY" (the people who live later) "may know" they had "opposed their Country."

The sisters left Boston in March 1776 with the Loyalists, the colonists who sided with Britain in the Revolutionary War, and went to Halifax, Nova Scotia. By 1780 they were "more prosperous than ever they were in Boston."

### A killing at a shop door, 1770

A Boston man named Ebenezer Richardson shot and killed a boy, Christopher Seider, during a protest at a shop door in February 1770. Theophilus Lillie kept the shop, in Boston's North End, and he went on selling British goods during the boycott.

A carved head on a long pole went up in front of Lillie's shop door on February 22, 1770. According to some accounts, it was a sign that read "Importer." Thomas Hutchinson, the acting governor of Massachusetts, wrote about that day in a letter. Hutchinson was running the colony for the king while the governor was away in England. A crowd of boys and young men gathered and let no one go into the shop.

Richardson lived next door to Lillie and worked as a customs informer. Customs officials collected the taxes on goods brought in by ship, and they paid informers like him to report smugglers. When Richardson tried to pull the pole down, the crowd threw stones and sticks at him, chased him into his house and broke his windows. From inside, he fired a musket at the boys. The shot hit Christopher Seider in the chest, and he died soon after.

Hutchinson wrote that Richardson "killed one & wounded another." The second boy was hit in the thigh. Christopher was 10 and a half years old in Hutchinson's letters, and 11 in most other accounts.

**The funeral.** Christopher Seider's funeral was on February 26, 1770. Hutchinson wrote that people said the procession, the line of people walking behind the coffin, "reached from the Town House to Liberty Tree," two places in Boston. The modern editors of his letters call it the largest procession ever seen in Boston, as people reported it at the time.

Richardson was tried for murder on April 20, 1770, and the next day the jury found him guilty. The judges believed he was innocent, and they put off his sentence. Richardson stayed in jail for almost two years. On March 10, 1772, the news came that the king had pardoned him, and he went free.

### The country store and the crop ledger

Away from the port towns, one country storekeeper sold goods to a whole farming neighborhood. Customers paid in crops, in work and in promises to pay later. The storekeeper wrote each family's debt in a ledger. A farm family bought goods all through the year and paid after the harvest. When a harvest failed, the family could not pay, and the debt carried into the next year.

**A shop near the city.** Not every store worked this way. Robert Townsend kept a shop in Oyster Bay, on Long Island, close to New York City, and kept account books there and in New York. His surviving books record sales from 1773 to 1785. Staff at the East Hampton Library have copied them out and published them.

One book records sales from April 1, 1773, to November 15, 1779. In 1773 it lists tea at 4 shillings 8 pence a pound, stockings, calico, a cotton cloth, linen cloth, gloves, packs of pins, molasses, a dark sweet syrup, and large barrels of spirits, a strong liquor.

Townsend sold on credit too, and he let a customer's debt run for months, but usually not for more than a year. Unlike the farm families above, most of his customers paid in cash. Library staff counted the payments in his book from 1773 to 1779. In their count, 73 out of every 100 were cash, 22 were farm goods and 5 were notes, written promises to pay. Some customers paid with their work, as a washerwoman, a doctor, a barber or a tailor.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 6 minutes**

Peddlers carried goods from house to house in the first half of the 1800s, selling to farm families in the country. In the cities, P.T. Barnum sold tickets to his shows with posters and newspaper advertisements, and he lied in them. His first show was an enslaved woman, Joice Heth, whom he advertised as 161 years old. A. T. Stewart opened a store in New York in 1846 with several floors of goods and a set price on each one.

### The peddler's trade

A peddler traveled a route through the countryside and sold goods at people's doors. Some went on foot. Others drove a wagon. They carried tinware, clocks, pins, needles, combs, books and patent medicines, bottled remedies sold under a brand name. The best known were the tin peddlers from Connecticut, who sold tinware: pots, pans, cups and other things made of thin sheets of metal coated with tin.

### James Guild

> **Who:** A Vermont farm boy who set out to peddle with a trunk of goods and wrote down what happened to him.
>
> **When and where:** Tunbridge, Vermont, and the roads beyond it, 1818 to 1824.

**Three days on the road, and 30 cents' worth of goods sold.**

James Guild grew up in Tunbridge, Vermont, bound out from the age of 9 to work on a farm, which meant he had to work for a farmer until he turned 21. His journal does not say who bound him out. He turned 21 on July 9, 1818. He wrote that his "disposition," his nature, "would not allow me to work on a farm."

Guild held a note, a written promise that someone would pay him money. He could not turn the note into cash, so he traded it for "a trunk of goods." The first entry in his journal is headed "Tunbridge Oct, 5th 1818." Tunbridge is a town about thirty miles from Montpelier. He felt ashamed of the work and wondered why he "should stoop so low as to follow so mean a calling" (so low a trade).

At the houses he visited, he asked, in his own spelling, "do you wish to by some harecombs, needles, buttons, buttonmolds, sewing silk." Customers who wanted to buy "would want to banter" (haggle over the price) "until they could get it for nothing."

**On the road.** At first he sold very little. On the road toward the Dog River, he wrote, "I think I traveled 3 days and selling but 30 cent worth of goods." At poor houses that wanted "a needle or a few pins," he gave them away, and he believed he gave away more than he sold.

He killed a partridge with a stone and traded it for "a dish of bread and milk." A flood had carried off a bridge, so he crossed the river on a log and fell in with his trunk.

Over the next six years, Guild went from peddling to mending pots and pans as a tinker, then to teaching school, then to painting portraits. In the end he went to London. In 1937 an editor at the Vermont Historical Society printed his journal as *From Tunbridge, Vermont, to London, England*.

### P.T. Barnum

> **Who:** A showman who sold tickets through advertising, and whose first paid show was an enslaved woman he put on show under a false claim.
>
> **When and where:** New York City and towns across the Northeast, from 1835.
>
> **Movie:** *The Circus* (2018), a two-part documentary in the *American Experience* series on PBS. It is about the American circus and tells a large part of Barnum's story.

**He advertised an elderly blind woman as 161 years old.**

Phineas Taylor Barnum started his career in show business by showing an enslaved woman named Joice Heth to paying crowds. In 1835 a man named R. W. Lindsay of Kentucky signed a contract selling Barnum possession of Heth, the right to hold her and show her for ten months. Heth was Black, elderly and blind. Barnum advertised her as George Washington's nurse and said she was 161 years old. He lied about her age.

**On show.** For seven months, Barnum and his partner, Levi Lyman, showed Heth to paying crowds in cities and towns across the Northeast. They put her on show in taverns and inns, places where people drank, ate and stayed the night, and in museums, railway houses and concert halls. To bring in the crowds, they used posters and advertisements in the *New York Sun*.

When fewer people came, Barnum wrote a letter to a Boston newspaper without signing his name. In it he claimed that Heth was a machine made of whalebone and old leather, and not a person. People came back to see for themselves.

**After her death.** Joice Heth died in February 1836. Barnum then sold tickets to a dissection of her body, the cutting open of a dead body to look at its insides. On February 25, 1836, at the City Saloon in New York, 1,500 people paid 50 cents each to watch.

Dr. David L. Rogers, a surgeon, cut open her body while doctors and medical students watched from the crowd. Rogers examined her heart, her lungs, her brain and the places where the bones of her skull join. He decided that she had been no more than 75 years old, or at the most 80.

Barnum called himself the "Prince of Humbug," from humbug, a trick or a false claim made to fool people. He wrote a book called *The Humbugs of the World*, which came out in the middle of the 1860s. In it he wrote that humbug did not include crimes or swindles, tricks to cheat people out of their money.

*The Greatest Showman*, a musical movie about Barnum, came out in 2017. Its story is mostly made up, and Joice Heth does not appear in it.

### Barnum's American Museum

Barnum bought John Scudder's American Museum, at Broadway and Ann Street in New York, in 1841. A day's ticket cost 25 cents.

Barnum showed the Feejee Mermaid there in 1842. His advertisements showed pictures of a beautiful creature, half woman and half fish. The object in the museum was the head and upper body of a monkey sewn to the tail of a fish. Large crowds came to see it in New York for about a month.

### The Marble Palace

Alexander Turney Stewart opened a dry goods store, selling cloth, clothing and sewing supplies, at 280 Broadway in New York on September 21, 1846. The building was faced with Tuckahoe marble, and it became known as the Marble Palace.

Stewart sold goods to shoppers on several floors, and that was new. Before, shopkeepers sold to shoppers only on the ground floor and used the upper floors for wholesale, selling goods in bulk to other sellers, or as living space. Stewart set one standard price on his goods, so that customers did not haggle, and he held sales to bring in women customers.

Many writers call the Marble Palace the first American department store, a large store with many kinds of goods, each kind in its own section, called a department. Other writers name Macy's or Wanamaker's as the first, because definitions of a department store differ. The building still stands and is now called the Sun Building.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 13 minutes**

City shoppers got the department store between 1850 and 1900, and farm families got the mail-order catalog. Store owners such as John Wanamaker made price tags and money-back promises common. Edward Clark, a partner in the Singer sewing machine business, sold the machines across the whole country on monthly payments. Sellers used advertisements to sell medicines that harmed people. In 1859 a slave dealer advertised the largest recorded sale of people in the United States.

### Paying a little each month

Edward Clark began selling Singer sewing machines on installments in 1856, letting buyers take a machine home and pay for it in small amounts over time. Isaac Singer's company made the machines, and Clark, a lawyer, was Singer's business partner.

**The trade-in.** Clark announced in February 1856 that customers could trade in any old sewing machine, even a worthless one, for $50 off a new Singer. In September he began the installment sales. Furniture makers in New York and clock makers in New England already sold goods this way. But no business selling across the whole country had done it before, Peter Lyon wrote in 1958, in a history of Singer's machine for the magazine *American Heritage*.

**Paying more.** A writer for the magazine *Scientific American* thought buyers would pay twice as much in order to pay a little at a time. He said that a woman "would rather pay $100 for a machine in monthly installments" than pay $50 all at once. A Singer machine that sold for $110 could cost as little as $23 to make.

### The department store

Rowland Hussey Macy opened a small dry goods store at Sixth Avenue and 14th Street in New York on October 28, 1858. It grew into Macy's department store. On the first day he took in $11.06, by most accounts. In his first year he took in about $85,000.

John Wanamaker opened a store called the Grand Depot in Philadelphia in 1876. It stood at Thirteenth Street and Market Street, in an old freight station of the Pennsylvania Railroad, a building where trains loaded and unloaded goods.

Wanamaker gets the credit for making three practices common: one price for every customer, a printed price tag on the goods and a promise of money back on anything returned. Before stores like his, customers bargained over prices, as James Guild's customers did when he peddled in Vermont. Wanamaker was not the first to use all three. A. T. Stewart had set fixed prices in 1846, and histories of the Wanamaker stores describe Wanamaker as "one of the first" to use the other two.

With a money-back promise, a customer who bought something poor could return it and get the money back. Montgomery Ward, a mail-order seller, made the same promise to customers who bought goods without seeing them first.

### John Wanamaker

> **Who:** The Philadelphia store owner who bought the first full-page newspaper advertisement for an American department store, and who later ran the national mail service.
>
> **When and where:** Philadelphia, from 1861, and the Grand Depot from 1876.

**A whole newspaper page for one advertisement, in 1879.**

John Wanamaker bought a whole page of a newspaper in 1879 and filled it with one advertisement. It was the first full-page newspaper advertisement bought by an American department store. His first store, which he opened in Philadelphia in 1861 with his brother-in-law Nathan Brown, sold men's clothes.

**Postmaster General.** From 1889 to 1893, Wanamaker was the US Postmaster General, the official in charge of the national mail service. He pushed for rural free delivery, a service in which postal workers carried mail to farm families' homes. Later, mail carriers on those rural routes brought catalogs from mail-order companies, his competitors, to the same farms.

### People sold at auction: Savannah, 1859

Slave dealers advertised sales of people in the newspapers, the same way sellers advertised goods. Pierce Mease Butler held people in slavery on Georgia plantation land. On March 2 and 3, 1859, he sold between 429 and 436 of them, men, women and children, to pay his gambling debts. The sale took place at the Ten Broeck Race Course, a racetrack near Savannah, Georgia. It was the largest single sale of enslaved people recorded in the United States.

**The advertising.** Joseph Bryan, a slave dealer in Savannah, ran the sale. He advertised it for weeks in the Savannah newspapers and in papers in seven other Southern cities, from Richmond to New Orleans. The sale brought Butler $303,850. It rained hard on both days.

Mortimer Thomson, a reporter for the *New York Tribune*, went to the sale pretending to be a buyer. He wrote a long account of what he saw, and the *Tribune* printed it under the title "What Became of the Slaves on a Georgia Plantation?"

**Sold in families.** Butler had ordered that the people be sold in families as far as possible, and Bryan's advertisement promised it. But a couple counted as a family only if they were married. Thomson told of a young man named Jeffrey, 23, who planned to marry a woman named Dorcas. Dorcas was to be sold in a family of four, and no buyer could buy her alone.

The man who bought Jeffrey thought about buying Dorcas too, until he learned that she could not be bought without the rest of her family. Jeffrey begged him, "Please buy Dorcas, mas'r" (master). Another buyer bought her. At this sale, parents were sold away from their children, and couples who planned to marry were sold away from each other. Black Georgians remembered the two days as "the weeping time."

### Chain stores and the five-cent store

George Gilman started a business in New York selling tea and coffee in 1859. By most accounts, George Huntington Hartford was his partner from the start.

**The A&P.** The owners named the business the Great Atlantic and Pacific Tea Company in 1869, to mark the finishing of the first railroad across the country, and people called it the A&P. It grew into a chain store, one of many stores that belong to the same owners and sell the same kinds of goods. The A&P had 70 stores by 1878 and nearly 200 by 1900.

Frank Winfield Woolworth opened a store in Utica, New York, on February 22, 1879. Everything in it cost five cents. The store did well for about two weeks and then failed. On June 21, 1879, he opened another five-cent store in Lancaster, Pennsylvania, and that one succeeded.

### Advertising agencies and patent medicines

Francis Wayland Ayer was 21 when he started an advertising agency in Philadelphia in 1869. He planned advertisements for sellers and bought space for them in newspapers and magazines. His father, Nathan Wheeler Ayer, gave him $250, and Francis named the business after him: N. W. Ayer & Son. It is usually called the first advertising agency in the country.

Ayer showed his customers what each newspaper charged for space. That way the sellers knew he was working for them and not for the newspapers.

Lydia E. Pinkham's Vegetable Compound, a patent medicine, went on sale in the middle of the 1870s. Its advertisements stated that it cured almost any "female complaint," meaning a health problem of women. Smithsonian museum records and other histories state that the mixture was 18 to 20 percent alcohol. Its label stated that the alcohol was there to dissolve and preserve the other ingredients.

Pinkham's sons put her picture in the newspaper advertisements. She asked customers to write to her personally, and she used their letters to sell more of the compound.

**A syrup for babies.** Mrs. Winslow's Soothing Syrup was older. Jeremiah Curtis and his partner, Benjamin A. Perkins, began selling it in 1849, to mothers to give to babies who were teething, growing their first teeth. The syrup held alcohol and morphine, about 65 milligrams of morphine in each ounce. Morphine is a strong painkilling drug. It slows a person's breathing, and too much can kill, especially a child.

One teaspoon of the syrup held enough morphine to kill an average child. The makers advertised it on recipe cards, in newspapers, on calendars and on trade cards, small printed cards given out to customers.

Members of Congress passed a food and drug law in 1906. Under it, makers had to list the drugs in their medicines on the label. Some time after that law, the makers of Mrs. Winslow's syrup took out the morphine and dropped the word "soothing" from its name.

The American Medical Association, the national organization of doctors, printed a book in 1911 called *Nostrums and Quackery*, which means fake cures and the selling of fake medicine. The book listed Mrs. Winslow's syrup under the heading "Baby Killers." No one counted how many children the morphine in the syrup killed.

### Mail order reaches the farm

Aaron Montgomery Ward mailed his first catalog, a printed list of goods that customers could order by mail, from Chicago on August 18, 1872. It was one sheet of paper. It listed 163 items, by the Chicago History Museum's count.

Leaders of the Illinois Grange, an organization of farmers, made Ward their buyer late in 1872. His catalog grew to 32 pages in 1874 and to 152 pages in 1876, with about 3,000 items.

Richard Warren Sears began selling watches in 1886, while he was the railroad worker in charge of a station in Minnesota. He moved his watch business to Chicago, where he worked with a watchmaker, Alvah Roebuck. In 1893 their company became Sears, Roebuck and Company, and that year its catalog ran to 196 pages.

**Mail to the farm.** In 1890 nearly 41 million Americans, about 65 out of every 100, lived in the countryside. Many city people had their mail brought to their homes for free from 1863, but farm families had to pick up their mail at the post office. A Postal Service history describes farmers who had to unhitch the horse from the plow and go five or six miles into town to get it.

Postal workers began bringing mail to farm families' homes in West Virginia on October 1, 1896, on three routes that started from Charles Town, Halltown and Uvilla. This service was called rural free delivery. Within a year, 44 routes were running in 29 states.

### Aaron Montgomery Ward

> **Who:** A traveling salesman who worked out that a farm family could buy from a printed list instead of from a country store.
>
> **When and where:** Chicago, from August 18, 1872.

**A newspaper called his company a "swindling firm," then took it back.**

Aaron Montgomery Ward built his mail-order business on a complaint he heard from farmers about their country stores. He had worked as a clerk at the Chicago store that later became Marshall Field's, and then as a traveling salesman for a St. Louis company that sold goods in bulk to stores.

On the road, Ward heard the farmers' main complaint. Country general stores charged high prices and had few goods to choose from. The farmers blamed the middlemen, the sellers between the maker and the buyer, for taking too much profit. Ward's plan was to buy straight from the factories, pay cash and sell straight to customers by mail.

The Chicago Fire of 1871 destroyed Ward's savings. In 1872 he started over with $1,600 of his own and $800 from his brother-in-law, George R. Thorne.

**"Grangers, Beware!"** Editors at the *Chicago Tribune* printed an article with that heading on November 8, 1873. It described Montgomery Ward & Co. as a "swindling firm" that hid behind a post-office box. Ward sued the *Tribune* for libel, printing something false that harms a person's name, and asked for $20,000.

The editors printed a notice taking back the charge on December 24, 1873. In it they called Ward's company "a bona fide firm" (a real one), "composed of respectable persons, and doing a perfectly legitimate business."

Ward promised that customers could send goods back for their money. By 1875 his catalog included the words "satisfaction guaranteed or your money back." When he died in 1913, his company sold $40 million worth of goods a year and had 6,000 workers.

### Richard Sears

> **Who:** A railroad station agent who started by selling watches and went on to build the Sears catalog.
>
> **When and where:** Minnesota in 1886, then Chicago.
>
> **Movie:** *Mr. Sears' Catalogue* (1989), a documentary in the *American Experience* series on PBS, about Richard Sears and his catalog.

**A box of watches a jeweler refused, sold for $14 each.**

Richard Sears was 22 when 1886 began. He was the station agent for the Minneapolis and St. Paul Railroad at North Redwood, Minnesota, next to the town of Redwood Falls.

That year a jeweler refused a shipment of watches that came to Sears's station. Sears got permission to sell the watches himself, and he sold them to other station agents along the line for $14 each. Then he quit the railroad and started the R. W. Sears Watch Company in Minneapolis. He moved the business to Chicago, where he hired a watchmaker, Alvah C. Roebuck, to repair watches that customers sent back.

**The big book.** Sears wrote the words in the catalog himself. At its biggest, the Sears catalog ran to about 1,500 pages and listed about 100,000 items. The documentary *Mr. Sears' Catalogue* states that it went to about 20 million people at its height.

Sears resigned as president of the company in 1908 or 1909. He died on September 28, 1914.

### Persis Foster Eames Albee

> **Who:** The first woman to sell door to door for the company that later became Avon.
>
> **When and where:** Winchester, New Hampshire, and across the Northeast, from 1886.

**At 50, she took perfume from door to door.**

Persis Foster Eames Albee was 50 years old in 1886 when David McConnell hired her to sell perfume door to door. McConnell had sold books from house to house. He gave away perfume as a free gift with the books, and he found that customers liked the perfume more than the books. He started a perfume company, the California Perfume Company. It later became Avon.

Albee, who lived in Winchester, New Hampshire, became the company's first General Traveling Agent. Her product was the Little Dot Perfume Set, which held five scents: violet, white rose, hyacinth, lily of the valley and heliotrope, a small purple flower. She sold it from house to house in Cheshire County, New Hampshire, and then across the Northeast, and she found other women to sell for the company and trained them.

Most of what is known about Albee comes from Avon's own history of itself.

**Selling without a vote.** Albee could sell across the Northeast and train other women to sell, but she could not vote. When she started selling, women could vote in only three western territories, lands that were not yet states: Wyoming, Utah and Washington. In 1887, lawmakers in Congress took the vote away from women in Utah, and judges on Washington's highest court struck down that territory's law.

A change called the Nineteenth Amendment became part of the Constitution in 1920, 34 years after Albee started selling. It states that no state and no federal official may keep a citizen from voting because of whether the citizen is a man or a woman.

**If you remember one thing:** Between 1850 and 1900, shoppers began paying by the month, buying at marked prices and ordering from catalogs, while dealers in the South still sold people like goods.

- 1856: Edward Clark starts selling Singer sewing machines on monthly payments.
- 1859: Pierce Butler sells between 429 and 436 people at a racetrack near Savannah, the largest recorded sale of people in the United States.
- 1872: Montgomery Ward mails his first catalog, one sheet of paper.
- 1876: John Wanamaker opens the Grand Depot in Philadelphia. He gets the credit for making price tags and money-back promises common.

**Next:** After 1900, one grocery chain grew to about 15,000 stores, and shoppers began taking goods off the shelves themselves.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 13 minutes**

Chain stores spread across the country, and the biggest grocery chain, the A&P, grew from about 200 stores in 1900 to about 15,000 by 1930. Grocers began letting customers take goods off the shelves themselves, and families bought cars and radios on monthly payments. Sellers began paying radio and television stations to air their advertisements. Coal companies paid miners in their own money, which only the company store accepted at full value. During the Second World War, shoppers needed ration stamps as well as money to buy many foods.

### The chain store at full size

The A&P had 1,600 stores by 1915. By 1930 it had about 15,000 stores and sold $2.9 billion worth of goods a year. That made it the world's largest retailer, a business that sells goods to the people who use them. The A&P was the largest grocery seller in the United States from 1915 to 1975.

### F. W. Woolworth

> **Who:** The storekeeper who built a national chain of five-cent and ten-cent stores and paid cash for the tallest building in the world.
>
> **When and where:** Utica and Lancaster, 1879, and New York, 1911 to 1913.

**$13.5 million for the world's tallest building, paid in cash.**

Frank Winfield Woolworth turned his five-cent stores of 1879 into the largest store company in the world. On November 12, 1911, he signed agreements to join his chain with four rival chains, the Knox, Kirby, Charlton and C. S. Woolworth chains.

The new F. W. Woolworth Company started with 596 stores and $65 million in capital, the money put into a business to run it. The company was formally set up in 1912, so some histories list that year as its start.

**The building.** The Woolworth Building in New York was finished in 1913. At 792 feet, it was the tallest building in the world at the time. It cost $13.5 million, and Woolworth paid for it himself, in cash.

### Who first let shoppers serve themselves?

Clarence Saunders started self-service shopping when he opened the first Piggly Wiggly store at 79 Jefferson Street in Memphis, Tennessee, on September 6, 1916, by most accounts. His customers picked goods off the shelves themselves instead of asking a clerk to fetch them.

**The turnstile.** Customers came in through a turnstile, a gate with turning arms that lets one person through at a time. Then they had to follow a single fenced path past every shelf in the store before they reached the place where they paid.

Saunders asked the government for a patent, a paper that lets only the inventor use an invention for a number of years. He applied for one on his "Self-Serving Store" on October 21, 1916, and received Patent 1,242,872 on October 9, 1917.

Michael J. Cullen opened King Kullen in Jamaica, in Queens, New York, on August 4, 1930. He had worked for the Kroger grocery company and had sent its managers a plan for a supermarket, which they ignored.

By the account of the Smithsonian, the national museum in Washington, King Kullen was the first supermarket. It met the museum's five tests: separate departments, self-service, low prices, many stores under one name and buying goods in huge amounts. Cullen's slogan, a short phrase repeated in advertising, was "Pile it high. Sell it low."

### Clarence Saunders

> **Who:** The Memphis grocer who started self-service shopping and then lost his company fighting traders on Wall Street.
>
> **When and where:** Memphis, Tennessee, 1916 to 1923, and later stores. He died in 1953.

**Orders for 196,000 of the 200,000 shares, and he still lost.**

Clarence Saunders built Piggly Wiggly into a chain of 1,268 stores and then lost it in a fight over its stock. By 1923 the stores sold $100 million worth of groceries a year, and Piggly Wiggly was the third-largest grocery business in the country. Saunders had put the company's stock up for sale on the New York Stock Exchange, a market where people buy and sell shares, small pieces of ownership in a company.

Writers on the history of money and business describe the fight this way. In early 1923, some Piggly Wiggly stores in New York that other owners ran under the Piggly Wiggly name failed. Traders then began selling Piggly Wiggly stock short. Selling short is a bet that a stock's price will fall. The trader sells shares he has borrowed, and later he must buy the same number of shares to give back. If the price has fallen by then, he buys them for less than he sold them for.

Saunders fought back. He borrowed about $10 million from bankers in the South, added his own money and kept buying shares. In the end he held orders for 196,000 of the 200,000 shares that existed.

**Why he still lost.** Many of the shares Saunders bought came from the short sellers, who now had to hand them over. Saunders held almost every share, so if they had to buy from him, he could name the price.

Then the men who ran the Stock Exchange stopped trading in the stock. They gave the short sellers five days to hand over the shares, instead of the usual one day. In those five days, shares poured in from distant places, and the short sellers used them to pay what they owed.

Saunders still owed the bankers, and a payment of $2.5 million on his loan was due on September 1, 1923. He did not have the money. In August he gave up the company and handed what he owned to the people he owed. He was bankrupt, which means he could not pay his debts.

He started again with a new chain called the "Clarence Saunders, Sole Owner of My Name" stores. They did well until the 1930s, when they failed during the Great Depression, the years of hard times that began in 1929. Later he built the Keedoozle, a grocery store that worked like a vending machine. It never made a profit. Saunders died on October 15, 1953.

### The company store

Many coal companies in Appalachia owned the store in their mining towns and paid their miners mostly in scrip, the company's own money, made as metal coins or paper. A miner could draw scrip against pay he had already earned. The company store accepted it at full value, but a miner could not turn it in for cash.

**Scrip at other stores.** Other merchants nearby took scrip only at a discount of 10 to 30 percent. A miner who spent $1 of scrip at another store got only 70 to 90 cents' worth of goods.

Researchers for the US Coal Commission, a government group that studied the coal industry, checked prices in coal towns in 1922. Food cost 4.2 percent more at company stores than at independent stores in southern West Virginia, and 7 percent more in Alabama. Later, Price Fishback, an economist who studies how money, work and business fit together, looked at these numbers. He found that at most companies a miner's store debt ran no longer than two weeks.

**Two views.** A page by the West Virginia Mine Wars Museum describes scrip differently. It describes the system as debt bondage, being forced to keep working to pay off a debt. In its words, scrip "created a kind of debt bondage that kept coal miners and their families tied to their employer for almost everything they needed to survive." Fishback found small price gaps and short debts.

West Virginia lawmakers passed a law in 1891 under which companies could give out scrip only as pay for work already done or as an advance on wages. In 1925 they made it against the law to pass scrip from one person to another. Scrip disappeared when the coal industry collapsed in the 1950s.

### The catalog under Jim Crow

Jim Crow is the name for the laws and customs in the South under which white lawmakers and officials kept Black people apart from white people in schools, railroad cars, waiting rooms, courtrooms and cemeteries, and at water fountains. White mobs enforced it with murder. Between 1877 and 1950, white mobs lynched more than 4,400 Black people, killing them without any trial, by the count of the Equal Justice Initiative.

**Hyman's argument.** Louis Hyman, a historian at Cornell University, argued in 2018 that mail-order catalogs helped Black farm families in the South get around Jim Crow at the store. NPR, the *Washington Post* and America's Black Holocaust Museum reported his argument.

According to Hyman, many Black farm families had to buy on credit at a white-owned country store, often owned by the landlord whose land they farmed. The storekeeper set the prices and made Black customers wait until white customers were served. A catalog order cost the same national price for everyone, and no clerk decided who was served first. Instead of the landlord's credit, the family could use the mail-order company's.

Hyman says that some Southern storekeepers held bonfires to burn catalogs, and told white customers that Sears was owned by Black people to keep them from buying there. These are Hyman's claims.

### Woolworth's lunch counter, 1960

Woolworth's stores had lunch counters, where customers sat and ate. In the South, the people who ran these counters served white customers only, and the rule was still in force in 1960. On February 1 of that year, four Black students from North Carolina A&T, a college in Greensboro, North Carolina, sat down at the Woolworth counter there and asked to be served. They were Ezell Blair Jr., Franklin McCain, Joseph McNeil and David Richmond. The counter staff refused to serve them.

Hundreds of people joined their protest over the next six months. On July 25, 1960, the staff of the Greensboro counter began serving Black customers. By the account of Geneva Tisdale, who worked in the store's kitchen, the manager of the lunch counter picked her and two other Black kitchen workers to be the first. He told them to get dressed, walk around the store like customers and then sit at the counter. Tisdale ordered an egg-salad sandwich. Chapter 25, Rights Movements, tells the sit-ins in full.

### Buying on time

Americans began buying cars, radios, furniture and household machines on installments in the 1920s, paying a little at a time, as buyers of sewing machines had since the 1850s. By the end of the 1920s, about 60 percent of cars and about 80 percent of radios were bought on installments, according to the reference site Encyclopedia.com. The number of cars registered in the United States grew from about 9 million in 1920 to nearly 27 million by 1929, nearly three times as many.

Members of the National Association of Finance Companies, a group of lending companies, agreed on standard terms for car buyers in 1924. A buyer paid one-third of the price at the start for a new car and two-fifths for a used car. The buyer then had no more than twelve months to pay the rest.

### Advertising on radio and television

The first paid radio advertisement went on the air on August 28, 1922, on the station WEAF in New York. The Queensboro Corporation paid $50 for about ten minutes of air time to promote the Hawthorne Court apartments in Jackson Heights, Queens.

No television station could sell advertising until officials of the Federal Communications Commission, the government office that licenses stations, gave licenses to 10 stations on May 2, 1941. Under those licenses, the stations could sell advertising from July 1, 1941. Two years earlier, people at NBC had shown test advertisements for three companies.

**Nine dollars for ten seconds.** The first commercial under the new licenses ran on WNBT in New York on July 1, 1941, before a Brooklyn Dodgers baseball game against the Philadelphia Phillies. For about ten seconds it showed the face of a Bulova watch over a map of the United States, while a voice said, "America runs on Bulova time." It cost Bulova $9: $4 for the air time and $5 in station charges. There were about 4,000 television sets in the New York area at the time.

Mary Frances Gerety wrote advertisements at N. W. Ayer & Son, the advertising agency. For the diamond company De Beers, she wrote the slogan "A Diamond Is Forever" in the late 1940s. In 1999 the editors of the magazine *Ad Age* named it the most memorable slogan of the 1900s.

### Shopping under rationing

Officials of the US government's Office of Price Administration rationed many goods during the Second World War, limiting how much of each one a person could buy. Sugar, meat, cheese, fats, shoes, gasoline and processed foods, foods that were canned, dried or frozen, were among them. At the start, each person could buy 26 pounds of sugar a year, about 8 ounces a week. Every person in the country, babies included, got a ration book full of stamps.

War Ration Book Two came into use on March 1, 1943. Its blue stamps bought processed foods, and its red stamps bought meat, cheese, fats and oils. Each stamp was worth a number of points, such as 8, 5, 2 or 1, and every food had a price in points as well as in money. In a cartoon the US government made to teach the system, a shopper's string beans cost 3 blue points.

Each person got 48 blue points and 64 red points a month, so a family of four had 192 blue points a month for processed food. Every cut of almost every kind of meat had its own point value.

At the store a shopper paid with stamps and with money together. The price could not go above the ceiling price, the highest price government officials allowed. Point values changed often. Newspaper editors printed them, radio announcers read them out and members of local ration boards posted them. By the end of the war, more than 100,000 volunteers were running the program through about 5,600 local boards.

### Emilia Ruth Palmquist Lundberg

> **Who:** A widowed mother of six in Jersey City who shopped for her family with ration books during the Second World War.
>
> **When and where:** Jersey City, New Jersey, about 1942 to 1943.

**Six children, $100 a month and a ration book for each.**

Emilia Lundberg, who was born in Göteborg, Sweden, in 1894, fed six children on a small, fixed income, and during the war she had to count ration stamps as well. In 1930 her husband was killed in an explosion at the dry-cleaning plant where he was in charge. As her son Donald remembered it, his father left her with six children, no relatives to turn to and no money.

She raised the children on workmen's compensation, money paid to a worker's family after the worker is hurt or killed on the job, of $100 a month. The rent was $35 a month. Her oldest daughter, 16, moved to night school and took a job keeping accounts for $12 a week. Donald packed and delivered groceries at a store after school and on Saturdays for $5 a week.

**At the store.** Rationing changed little at the family's table. Before the war, they ate a roast on Sunday after church and potatoes and macaroni the rest of the week. Under rationing, they still bought meat only for Sunday and ate macaroni, spaghetti and mashed potatoes the rest of the week.

Everyone in the family had a ration book with stamps for meat and other goods, and they took the books to the store and bought what the stamps allowed. The ration was counted for each person, so a large family got more in all than a small one. Shoes were rationed too. Each child had one good pair for school and one pair of sneakers for play.

Emilia had a 1933 Plymouth car. Donald remembered the family's gasoline ration as about a gallon and a half, but he did not say whether that was for a week or a month. When they told the ration board they were driving to visit his older brother, a soldier at Camp Kilmer in New Jersey, they got a coupon for about two more gallons. Donald described all of this in an interview for the Rutgers Oral History Archives in 2008, about 65 years later.

**If you remember one thing:** Between 1900 and 1950, shoppers began picking goods off the shelves themselves in ever-bigger chain stores, and they bought cars and radios on monthly payments.

**One number:** 15,000. The A&P had nearly 200 stores in 1900 and about 15,000 in 1930, about 75 times as many.

**Next:** After 1950, shoppers drove to the first enclosed malls and paid with plastic cards.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 9 minutes**

Americans began shopping at enclosed malls and discount stores after 1950, and paying with plastic cards. The first fully enclosed shopping mall in the United States opened in Minnesota in 1956. Kmart, Target and Wal-Mart all opened their first stores in 1962. In 1974 a cashier in Troy, Ohio, made the first sale with a scanner that read a printed code on a package. By 2000, people could shop at home on television shopping channels, and from 1995 on a computer.

### The enclosed mall

Southdale Center opened in Edina, Minnesota, on October 8, 1956. It was the first fully enclosed shopping mall in the United States with its own heating and cooling. It had 72 stores on two levels around a brightly lit central court. Its two biggest stores were the department stores Dayton's and Donaldson's.

The Dayton family owned department stores in Minneapolis. In 1952 they hired the architect Victor Gruen and his firm, Victor Gruen & Associates, to design the mall. Building began in 1954. Southdale cost $20 million.

### Victor Gruen

> **Who:** The architect who designed the first enclosed American mall and later rejected what developers built from his idea.
>
> **When and where:** Vienna, then New York and Minnesota. Southdale opened October 8, 1956.
>
> **Movie:** *The Gruen Effect: Victor Gruen and the Shopping Mall* (2009), a documentary by Anette Baldauf and Katharina Weingartner, about Gruen and the malls he started.

**He arrived in New York with eight dollars and no English.**

Victor Gruen designed Southdale as the center of a new neighborhood, and developers copied only the mall. Gruen was a Jewish architect from Vienna, in Austria.

**Leaving Vienna.** In March 1938 the leaders of Nazi Germany, the Germany ruled by Adolf Hitler's Nazi Party, took over Austria and made it part of Germany, a takeover called the Anschluss. In the weeks after, Austrian Nazis and others beat, attacked and humiliated Jews. In Vienna, Nazis forced Jews to scrub the city's streets while crowds jeered at them. Soon Nazi officials put Austria's Jews under the same laws that German officials already used to take away Jewish rights in Germany.

Gruen fled Vienna that year. He reached New York on the ship *Statendam* with an architect's degree, eight dollars and no English. One of his early jobs was a shop front on Fifth Avenue in New York, for Ludwig Lederer's leather-goods shop. Gruen designed its entrance as an arcade, a covered walkway, meant as a "customer trap" to draw people inside.

For Southdale, the Dayton company bought about 500 acres of land in Edina. Gruen's plan for the land around the mall had apartment buildings, houses, schools, a medical center, a park and a lake. He said he wanted "the Minneapolis downtown you would get if you started over and corrected all the mistakes." The medical center opened in 1965. The Daytons sold the rest of the land for housing.

In a speech in London in 1978, Gruen rejected the malls that American developers had built. He said he refused to pay alimony, the money a person pays a former husband or wife after a divorce, for those developments, and he used a rude word to describe them. He went back to Vienna and objected to a shopping center built there.

### Plastic at the counter

With a credit card, a shopper could take goods home from any store that took the card and pay the bank later. Chapter 17, Money, describes how the cards began: the cardboard Diners Club card of 1950, which holders had to pay off in full every month, and the BankAmericards that officers of Bank of America mailed to people in Fresno, California, in September 1958.

**At the counter.** The Fresno cards came ready to use, though nobody had asked for them. Each of the 60,000 or so cardholders got $300 to $500 of credit at once, good in any store that took the card, and each store that took it paid the bank 6 percent of every sale. The bank's officers later licensed the card across the country, and in 1976 it was renamed Visa. In 1970 members of Congress banned mailing credit cards to people who had not asked for them.

**Women and credit.** Before 1974, lenders often turned women down for credit because they were women, or because they were married or single. Mortgage lenders, who lend money to buy houses, often counted only part of a married woman's pay, especially if she was young enough to have children. Lawmakers in Congress passed the Equal Credit Opportunity Act in October 1974. Under it, lenders could no longer treat people differently because of their sex or whether they were married.

In March 1976 the lawmakers added more reasons lenders could not use: race, color, religion, national origin, which means the country a person or their family came from, age, and getting money from government aid programs.

### Four discount chains in one year

Four discount chains, selling goods at prices below what other stores charged, began in 1962. The first Kmart store opened in Garden City, Michigan, on March 1, 1962, and reports stated that 4,000 customers waited in line on the first day. Target's first store followed on May 1, in Roseville, Minnesota. On July 2, Sam Walton opened the first Wal-Mart in Rogers, Arkansas. Woolco's first store opened that year too.

Kmart grew out of the S. S. Kresge chain of five-and-dime stores, which sold small goods for 5 and 10 cents, and Woolco out of F. W. Woolworth's company. Target grew out of the Dayton Company's department stores, run by the same Dayton family that had hired Victor Gruen to design Southdale.

### Sam Walton

> **Who:** The Arkansas storekeeper who put discount stores in small towns and built the largest retailer in the United States.
>
> **When and where:** Rogers, Arkansas, from July 2, 1962.
>
> **Movie:** *Wal-Mart: The High Cost of Low Price* (2005), a documentary by Robert Greenwald. It argues against the company and is not a life story of Walton.

**He put discount stores in towns too small for the big chains.**

Sam Walton built Walmart, spelled Wal-Mart at first, by opening discount stores in small towns. The heads of the large chains had judged those towns too small to bother with. Before 1962 Walton ran Ben Franklin variety stores in Arkansas, which sold many kinds of small, cheap goods. He bought goods in huge amounts and priced them below the stores nearby. Walmart became the largest retailer in the United States and the largest private employer, which means it had more workers than any other company.

Economists have measured what happened to shoppers and to towns when Walmart stores opened. Two economists, one at MIT and one at the US Department of Agriculture, reported in 2007 that shoppers gained a great deal from Walmart's low prices, most of all households with lower incomes.

**Jobs and sales.** Three other economists reported in 2008 that when a Walmart opened, the county around it lost about 150 retail jobs, or 2.7 percent. By their count, each Walmart worker replaced about 1.4 workers at other stores.

**Small towns.** Kenneth Stone, an economist at Iowa State University, has studied Walmart in Iowa since 1988. In a 2012 study, he and a co-author followed 28 Iowa towns of 3,000 to 20,000 people for 15 years after each got a Walmart. Total retail sales in those towns rose, but most of the gain went to Walmart, and other stores in town that sold the same things lost sales.

None of the study's Walmart towns had fewer than 3,000 people. In Iowa's smallest towns, under 2,500 people, retail sales fell 30 percent, about $1.5 billion, in the years after Walmart came to the state. In those years, shopping in Iowa moved to the bigger cities and to the Walmart towns, where people from nearby towns now came to shop.

### The franchise

Roy Allen bought a recipe for root beer in 1919. In 1924, by most accounts, he began selling A&W franchises: the right for other people to run a business under the A&W name, following his rules. Writers on the history of franchising often call A&W the first successful food franchise. J. Willard Marriott was one of its early franchise owners.

The Howard Johnson's restaurant business sold its first franchise to Reginald Sprague in 1935. By the end of 1936 there were 41 Howard Johnson's restaurants. By 1939 there were 107, with about $10.5 million in sales.

### The barcode

The Universal Product Code, or UPC, is the barcode printed on packages in stores, read by a scanner at the checkout.

The people who planned the first scan chose a small pack of gum on purpose. They wanted to show that the code could be printed clearly on a package that size. The Smithsonian's National Museum of American History keeps one of the first ten scanners, a Spectra-Physics Model A.

### Sharon Buchanan

> **Who:** The supermarket cashier who made the first sale ever scanned with a barcode.
>
> **When and where:** Marsh Supermarket, Troy, Ohio, 8:01 a.m., June 26, 1974.

**A ten-pack of Juicy Fruit gum, 67 cents, at 8:01 in the morning.**

Sharon Buchanan was the cashier at the first sale ever made with a barcode scanner. At 8:01 in the morning on June 26, 1974, she was working at the Marsh Supermarket in Troy, Ohio. The customer was Clyde Dawson, who headed research and development, the work of trying out new ideas, at Marsh. He bought a ten-pack of Wrigley's Juicy Fruit gum. Buchanan passed it over the scanner. The price was 67 cents.

### Stamps, television selling and the end of the big catalog

**Green Stamps.** About 80 percent of American households collected S&H Green Stamps in the 1960s and 1970s. These trading stamps were small stamps that shoppers got with purchases at grocery stores, gas stations and other stores. Shoppers pasted them into books and traded full books for goods at a Green Stamps store or from a catalog. In the 1960s more S&H stamps were printed than US postage stamps, and about 35 million S&H catalogs went out each year.

**Shopping on television.** The Home Shopping Network began with a radio station. In 1977 a company that advertised on Lowell "Bud" Paxson's radio station paid him in electric can openers instead of money. The station's host, Bob Circosta, sold them on the air for $9.95 each. In 1982 Paxson and Roy Speer started the Home Shopping Club on cable television in Pinellas County, Florida, and it went national on July 1, 1985.

Joe Segel founded QVC, another shopping channel, in 1986. It first went on the air that November, and the first thing it sold was a radio made to be used in the shower.

**The last Sears catalog.** Sears officials announced on January 25, 1993, that they were closing the company's catalog business, cutting 50,000 jobs and closing 113 stores. The last general catalog went out that spring. The catalog had run for about a hundred years.

### Buying on a computer begins

Jeff Bezos filed papers to start a company called Cadabra, Inc., on July 5, 1994, working from a rented house with a garage in Bellevue, Washington. The company became Amazon. Amazon.com opened for orders on July 16, 1995. The first book it sold was *Fluid Concepts and Creative Analogies*, by Douglas Hofstadter. In its first week it took in about $12,000 in book orders.

Pierre Omidyar started a website called AuctionWeb, where people sold goods at auction to whoever offered the most money. He started it over Labor Day weekend, on September 3, 1995. It later became eBay. The first thing sold on it went for $14.83. By eBay's account, it was a broken laser pointer.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 11 minutes**

About one dollar in six of all American retail spending went to online sales from April to June 2026, by the count of the US Census Bureau. Since 2005, members of Amazon Prime have paid a fee for two-day shipping. Drivers carry the orders to people's doors, including on days of summer heat. Sellers now buy the right to show advertisements to one person at a time, chosen from records of what that person has done online.

### How much shopping is online?

Online sales were 17.1 percent of all retail sales in the United States from April through June 2026, by the count that workers at the US Census Bureau publish every three months. In all of 2025 they were 16.4 percent. The April-to-June figure came to $340.2 billion, 12.2 percent more than in the same months of 2025. The bureau's staff released those numbers on August 18, 2026. By those numbers, more than four dollars in five were still spent in stores.

Researchers at the Federal Reserve, which acts as a bank for other banks, ask people to keep diaries of how they pay. In 2024, credit cards were the most-used way to pay in the United States, used for 35 percent of all payments. Cash was used for 14 percent.

### Jeff Bezos

> **Who:** The founder of Amazon, which began as an online bookstore and grew into a store selling books, music, movies and many other kinds of goods.
>
> **When and where:** Bellevue and Seattle, Washington, from July 1994.
>
> **Movie:** *Amazon Empire: The Rise and Reign of Jeff Bezos* (2020), a documentary by James Jacoby and Anya Bourg in the PBS series *Frontline*. It is an investigation that argues a case against Amazon's power.

**Web use was growing 2,300 percent a year, so he quit.**

Jeff Bezos was a vice president at D. E. Shaw, an investment company in New York, when he read in 1994 that use of the web had been growing by 2,300 percent a year that spring. He quit his job to sell goods online.

He and his wife, MacKenzie Bezos, moved from Manhattan to the Seattle area. They chose it because software engineers lived and worked there, at Microsoft and the University of Washington, and because of its taxes. Bezos studied which product would sell best online, and he chose books. Music and DVDs were the next goods Amazon added.

**Prime.** When Amazon Prime began on February 2, 2005, members paid $79 a year and got two-day shipping on their orders at no extra charge, according to Amazon's announcement. By 2021, more than 200 million people around the world were members. In 2026 Prime in the United States cost $139 for members who paid once a year, or $14.99 a month for members who paid monthly, about $180 over a year. Those prices had not changed since February 2022, according to the shopping news site dealnews.

**The workers.** Senate committee staff, drivers and union representatives have complained about how Amazon treats the people who pack and deliver its orders. A Senate committee's staff counted more injuries in Amazon's warehouses than in other warehouses. In 2023 Amazon ended its contract with one delivery company soon after the company's drivers joined a union, a group that workers form to bargain together with their employer. Amazon's representatives said the contract ended for other reasons.

### Malls empty out

As shoppers moved online or to newer outdoor shopping centers, the anchor department stores of many malls closed. Anchor stores are the big stores that draw shoppers to the smaller shops around them, and the smaller shops that had depended on the department stores' crowds lost customers. Mall owners could not find new stores to fill the empty space. Owners and builders have turned some empty malls into apartments, clinics, colleges and warehouses.

**How empty.** Nobody keeps an official government count of malls, and the private counts disagree, because people define a mall in different ways. In 2017, Green Street Advisors, a company that grades malls for investors, sorted them by how well they were doing. The more than 300 malls it gave its lowest grades were only about 72 percent full, while the best malls were about 95 percent full. In the weakest malls, more than a quarter of the space stood empty.

Across the whole country, researchers at Coresight Research, a company that studies stores, counted about 3,000 more stores closing than opening in 2025.

### Advertising aimed at one person

When a person visits a website, the company that runs the site can save small files and codes on the person's device that record what the person looked at. Companies called data brokers collect records like these and combine them with records from outside the internet, such as store purchases, warranty cards and property records. Then they sell what they have gathered, including the chance to show an advertisement to a chosen group of people.

The staff of the Federal Trade Commission, the government office that protects shoppers, published a report in May 2014 called *Data Brokers: A Call for Transparency and Accountability*. The commission's staff found that data brokers held "billions of data elements," meaning billions of separate facts, about nearly every American shopper. They gathered most of it without people knowing.

The report describes how brokers attached offline records to the files in a person's web browser, so the person could be followed from site to site and shown advertisements chosen for them. The commissioners asked Congress to pass a law under which people could see the information held about them.

Website and app owners use money from this advertising to keep their services free to use, and the advertisements can show a person something they want to buy. But companies the person has never heard of buy and sell records of what the person reads and buys. As of 2026, members of Congress had passed no general federal privacy law. By June 29, 2026, lawmakers in 24 states had passed their own, according to the law firm Husch Blackwell.

### Selling to children inside a game

Fortnite is a video game made by Epic Games that came out in 2017. It is free to play. Epic sells V-Bucks, game money that players buy with real money to get costumes and dance moves for their characters. By 2022, the game had more than 400 million players around the world, according to the Federal Trade Commission.

**The $520 million.** Officials of the Federal Trade Commission announced on December 19, 2022, that Epic had agreed to pay $520 million. Of that, $275 million was a penalty under the Children's Online Privacy Protection Act, a law that requires a company to get a parent's permission before it collects personal information from a child under 13. The officials said Epic had collected personal information from children under 13 who played Fortnite without telling their parents or getting their permission.

The other $245 million went back to customers as refunds. The officials said Epic had used "dark patterns," confusing buttons and screens that led players into charges they did not mean to make. They said children could buy V-Bucks just by pressing buttons, with no parent or card owner agreeing, and that the game could charge a player who was only waking it from sleep mode.

The officials cited "hundreds of millions of dollars in unauthorized charges," meaning charges that players had not agreed to. Lina Khan was the head of the commission at the time.

### Payday loans

A payday loan is a small loan from a storefront lender that the borrower is supposed to pay back on the next payday. Researchers at the Consumer Financial Protection Bureau, a government office that watches over lenders, published a study of these loans in April 2013. They found that a borrower who took the typical $350 loan, with a fee of $15 for each $100, had to find more than $400 in 14 days.

Nearly half of payday borrowers took out more than 10 loans in a year, and the typical borrower was in debt 199 days of the year, more than half of it. Chapter 17, Money, describes the rest of the study, including how a fee like that comes to 391 percent a year.

### Buying secondhand clothes

The staff of ThredUp, a company that sells used clothes online, publish a yearly report on the market for secondhand clothes. Because ThredUp sells used clothes, its report is a company's estimate, not a government count.

By ThredUp's 2025 report, the market for used clothes in the United States grew 14 percent in 2024, and online sales of used clothes grew 23 percent. In 2024, 58 percent of shoppers bought something secondhand, up from 52 percent in 2023. The firm GlobalData did the research for ThredUp's 2026 report, which states that in 2025 used clothing sales grew almost four times as fast as all clothing sales. GlobalData's researchers forecast that the US secondhand market will reach $78.8 billion by 2030.

### The last step: heat in the delivery truck

The drivers who make fast delivery possible keep delivering in summer heat. Injury records kept by OSHA, the government's workplace safety office, list at least 40 UPS drivers taken to the hospital since 2015 for heat illness, which happens when the body gets too hot and cannot cool itself down. Danielle Kaye of NPR gave that count in July 2023.

José Cruz Rodriguez was 23. He died of heat illness during a UPS delivery shift in Waco, Texas, in August 2021, according to OSHA. His family sued UPS for causing his death, and the case was settled.

Esteban Chavez Jr., a UPS driver for four years, died after he was found unconscious in his truck. It was June 25, 2022, the day after his 24th birthday, and he was on his route in Pasadena, California. The temperature that day reached the upper 90s. UPS trucks had no air conditioning then. His family said at least 20 minutes went by before anyone noticed him and called for help.

The medical examiner, the doctor whose job is to find out why a person died, found that his heart stopped working. His family believes the heat caused it.

UPS managers and leaders of the Teamsters union, which represents UPS drivers, agreed in June 2023 that every small delivery truck UPS bought after January 1, 2024, would have air conditioning, heat shields and fans.

**Inside the warehouses.** Warehouse workers pack the orders before drivers carry them. In December 2024, Senator Bernie Sanders released a report by staff of the Senate committee he led, staff members who work for the party that holds the most seats in the Senate. They found that in 2023 Amazon recorded more than 30 percent more injuries at its warehouses than the average for the warehouse industry. For seven years in a row, Amazon warehouse workers were nearly twice as likely to be hurt as workers at other warehouses.

The report states that Amazon had plans to lower injuries and did not use them, because the plans would slow down work.

### Renica Turner

> **Who:** A driver who delivered Amazon packages in the California desert for a small delivery company, and who joined a union to push for protection from the heat.
>
> **When and where:** Palmdale and Victorville, California, about 2022 to 2023.

**110 degrees, a broken air conditioner and 300 packages to go.**

Renica Turner delivered Amazon packages for a company called Battle Tested Strategies. It was one of about 3,000 small companies under contract to deliver Amazon's packages. Its vans were leased from Amazon, and its drivers worked out of an Amazon building in Palmdale, California.

**The hot day.** In a July 2023 story by the NPR reporter Danielle Kaye, Turner described a day in Victorville, California, when the temperature reached 110 degrees. The van's air conditioning and fans were not working, she said. When she rolled the windows down, hot air came in. Her body began to tingle, and she thought she might pass out.

She told the Amazon dispatcher, the worker who sends drivers out and keeps track of them, and the dispatcher gave her a 20-minute break. In her words, "They never sent no one out to help me with the rest of the route." The route was 300 packages, and she was expected to deliver 25 every hour. She finished it herself, feeling woozy and numb.

Amazon's representatives told NPR that its vans had working air conditioning and that any van without it was taken off the road at once. The delivery companies were in charge of fixing the vans, they said, and Amazon had changed some routes the year before so drivers could take more breaks to cool down. The owner of Battle Tested Strategies, Johnathon Ervin, said Amazon regularly failed to fix broken air conditioning, sometimes for weeks or months.

**The union.** Turner and 83 other drivers at the company joined the Teamsters union in April 2023 and bargained a contract with Battle Tested Strategies. NPR reported that they joined the union in large part to push for protection from the heat.

Amazon ended its contract with the company in June 2023. Teamsters representatives and the company's owner said Amazon was punishing the drivers for joining a union. Amazon's representatives said Amazon ended the contract over safety violations and missed insurance payments by the company. The drivers went on strike, stopping work as a protest.

**What the drivers got.** Lawyers for the National Labor Relations Board, the government office that enforces labor law, brought a case against Amazon. They argued that Amazon was the drivers' employer too, even though another company had hired them. In April 2026 they settled the case with Amazon, agreeing on terms that ended it. Turner and the other drivers, about 84 of them, were each to get two weeks of pay, about $250,000 in all.

Under the settlement, Amazon did not admit that it had been the drivers' employer. A judge approved the settlement in May 2026, and the Teamsters asked to appeal. The news stories about the case do not say what Turner did after the strike.

**The three questions, answered**

- How did colonists pay for goods when they had almost no coins? They took goods home on credit and paid later in crops, other goods, work and wampum, while the shopkeeper wrote each debt in a ledger.
- Where were people bought and sold like goods? At the market New York's aldermen set up on Wall Street in 1711, in newspaper advertisements such as the 277 or more in Franklin's *Pennsylvania Gazette*, and at a racetrack near Savannah, where Pierce Butler sold between 429 and 436 people in 1859.
- How much of what Americans buy today is bought online? About one dollar in six: online sales were 17.1 percent of all retail sales from April to June 2026, by the US Census Bureau's count.

**What changed:** Before 1500, goods passed hand to hand at trading places like the one on the Columbia River, and by 2026 one dollar in six of American retail spending went to online orders carried to the door.

**Five dates to keep**

- 1653: John Stewart owes John Pynchon 30 pounds for his freedom.
- 1711: New York's aldermen set up a market for selling enslaved people.
- 1872: Montgomery Ward mails his first catalog.
- 1916: The first Piggly Wiggly lets shoppers serve themselves.
- 1995: Amazon.com opens for orders.

**Not known:** No one counted how many children the morphine in Mrs. Winslow's Soothing Syrup killed.

**Where to go:** A sign at Wall Street and Water Street, in New York City, marks where the city's market for enslaved people stood from 1711 to 1762.

**Next:** Chapter 19, Big Business and Its Power. It describes how a handful of companies grew huge, and what Americans did about their power.
