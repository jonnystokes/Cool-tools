# Chapter 27: Disasters and Rescue

**Chapter 27 of 37 · Disasters and Rescue · 10 eras · about 130 minutes**

**Fires, floods, storms and earthquakes strike suddenly, but people's choices decided how many died and who got help, and most safety rules came only after the deaths.**

The South Fork Dam stood 69 feet high, 14 miles up the valley from Johnstown, Pennsylvania. It belonged to a club of rich Pittsburgh men. Their workers lowered its top by as much as 3 feet for a carriage road, and screened the channel that let extra water out, to keep the club's fish in. On May 31, 1889, after the heaviest rain ever recorded there, the dam broke and the flood killed 2,208 people. In court, two club members who were lawyers called it an "act of God," and the survivors lost.

This chapter follows sudden disasters in order, from a volcano in Oregon about 7,700 years ago to a flood in the Texas Hill Country in 2025. Each era has three things to look for. The first is the choice someone made before the disaster: a town built of wood, a locked door, a warning nobody passed on. The second is who got help afterward, and who was made to do the work or left to wait. The third is the rule that came after, from Boston's first fire wardens in 1711 to the smell put into natural gas in 1937.

**Three questions this chapter answers**

- What rules did Americans make after disasters, and did they work?
- Was anyone punished when people's choices killed others?
- Did everyone get the same help after a disaster?

**Five minutes?** Read "The Triangle fire, March 25, 1911" in 1900 to 1950.

**Can skip:** "Fire insurance, 1752", "Hurricanes and the war on the Gulf Coast, 1779 and 1780", "Black Sunday, April 14, 1935". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 5 minutes**

Sandals woven from sagebrush bark lay under the ash of an Oregon volcano for thousands of years, and they show that people lived through this land's disasters long before anyone wrote one down. Those people belonged to Native nations. When ash buried their fields or the rain stopped for decades, many of them moved away. What is known comes from layers of ash, from the growth rings of old trees, and from the accounts the nations told to each new generation.

### Two volcanoes

Mount Mazama is a volcano in the Cascade Range of southern Oregon, about 60 miles north of the California line. About 7,700 years ago it erupted, and its top fell in. The eruption lasted only a few days. Scientists estimate that it was more than forty times as powerful as the eruption of Mount St. Helens in 1980. Its ash fell as far away as what is now central Alberta, in Canada.

Over several hundred years, rain and snow filled much of the hole that the collapse left behind. The water became Crater Lake. It is 1,943 feet deep, the deepest lake in the United States. In the Klamath language its name is *giiwas*.

**The sandals.** People had lived in the region for about 1,500 years or more before the eruption. In 1938 Luther Cressman, an archaeologist who studied the past from the things people left behind, dug in Fort Rock Cave, in Lake County, Oregon. Under a layer of ash from Mount Mazama, he found dozens of sandals woven from sagebrush bark.

Radiocarbon dating, a test that measures how much of one kind of carbon is left in something that was once alive, later showed that the sandals were more than 9,000 years old. Sandals of the same kind from half a dozen sites date from between about 10,500 and 9,100 years ago. The families who wore them lived there long before the mountain erupted.

The Klamath Tribes say that they have lived in the Klamath Basin for 13,000 years. They tell the eruption as a battle between Llao, chief of the Below World, and Skell, chief of the Above World. In their account, Llao attacked the people with fire after a chief's daughter refused him. Skell defended the people, and two holy men gave up their lives. Skell drove Llao back into Mount Mazama, the mountain fell in, and water filled the basin.

**Sunset Crater.** A second volcano, Sunset Crater, near what is now Flagstaff, Arizona, erupted around the year 1085. Scientists fixed the date from chemical changes in the growth rings of trees that were alive then. Ash fell on land 12 to 15 miles away and buried people's homes. Crops cannot grow in ash deeper than about 6 to 8 inches.

The Sinagua farmers who lived closest to the volcano were ancestors of today's Pueblo peoples. National Park Service scientists think they had to leave their fields because of the eruption and move farther away. Where the ash lay thin, it worked as a mulch, a covering that keeps soil from drying out, and crops there grew better. No record counts any dead. The people of the area told stories of the eruption, and those stories are still told today.

### How do tree rings show a drought?

A tree adds one ring of new wood each year, and in a year of drought, with too little rain for crops, the ring is thin. Scientists read those rings in very old trees and wooden beams to find out which years were dry.

The rings show that the Colorado Plateau, in the dry Southwest, had too little rain from about 1130 to 1180. From 1140 to 1162 there were 23 dry years in a row. Susan Ryan, a researcher at the Crow Canyon Archaeological Center in Colorado, calls it the greatest drought recorded for North America. The Colorado River carried less water in the middle 1100s than at any other time in the past 1,200 years.

At Chaco Canyon, in present-day New Mexico, builders had stopped putting up the large stone buildings called great houses by about 1130. In the decades after that, the people of the Chaco towns moved away.

**The Great Drought.** A second drought, called the Great Drought, lasted from 1276 to 1299. Ryan found it less severe than the drought of the 1100s. By about 1300 the Pueblo people of the Mesa Verde region, in present-day southwestern Colorado, had moved south. They went to the Rio Grande valley, to Zuni and Acoma, and to the Hopi mesas, where rain came more reliably.

Archaeologists at Crow Canyon count the drought as one cause of that move among several. Other causes on their list are changes in how the communities got along, how they were ruled and how they made a living. In their view, the drought probably caused food shortages in a region crowded with people, and the hard times that followed may have led to quarrels and fighting.

Attackers killed at least 41 people at Castle Rock Pueblo and at least 8 at Sand Canyon Pueblo around 1280. Both places are in the Mesa Verde region. Kristin Kuckelman and two other scientists studied the skeletons. They found that someone had cut the bodies apart and broken, crushed and burned the bones, during or after the fighting. They also found signs that people probably ate human flesh there. No evidence shows who the attackers were, or who cut up the dead.

### A fault under the northwest coast

The outer layer of the earth is broken into huge slabs called plates. Off the coast of present-day Washington, Oregon and northern California, one plate slides under another. The line where they meet is a fault, a crack in the earth's crust where the rock on each side can move. Scientists call this one the Cascadia Subduction Zone, from subduction, one plate sliding down under another.

When the rock along a fault moves suddenly, the ground shakes. Scientists have found signs of 19 great earthquakes on this fault in the last 10,000 years. The most recent one struck in January 1700.

## The 1500s

**Era 2 of 10 · The 1500s · about 6 minutes**

A hurricane in Pensacola Bay sank six Spanish ships in 1559 with the food for 1,500 colonists still on board. Spanish and English colonists of the 1500s wrote down the disasters they lived through, and this storm is one of them.

Two kinds of disaster hit the colonists hardest. Hurricanes, huge storms that form over warm ocean water with winds that spin in a circle, sank their ships and flooded their towns. Droughts left the colonists and their Native neighbors short of corn, and hungry colonists went looking for food in Native towns.

### A hurricane wrecks a colony, 1559

A hurricane in September 1559 sank most of the ships of the largest Spanish colony yet sent to the Southeast. Nearly all of the colony's food went down with them. The colonists had landed on August 15, 1559, at Pensacola Bay in present-day Florida. The Native name of the bay was Ochuse. They came from Veracruz, in Mexico, on 11 ships, towing a 12th, smaller ship behind them.

About 1,500 people made the voyage. They included an army of 500 soldiers and about 200 Aztec warriors and craftsmen from Mexico City. Servants, enslaved Africans, and some wives and children came too. For five weeks they unloaded people and tools and began building a town on high, flat ground above the bay. They left the food for all 1,500 people on board the ships, because they thought it was safer there than on land.

**The storm.** One of the 11 ships, a galleon, had already sailed back to Mexico in late August or early September. On the night of September 19 to 20, 1559, a hurricane came into the bay. It sank six ships and pushed a seventh a short way onto the land. Three of the 11 ships came through the storm, and the small towed ship later carried supplies on relief voyages. The people who drowned were mostly the sailors and passengers still on board. No record gives their number.

After the storm the colonists did not have enough to eat. One ship came from Havana, in Cuba, with supplies soon after the hurricane. Relief ships from Mexico came after that, one every five to seven months. The colonists sent about 200 men inland to look for towns with food to spare. The men found a large town called Nanipacana, on the Alabama River in present-day central Alabama. Its people left before the Spaniards arrived. As they went, they destroyed the food they had stored.

Many colonists grew sick and died from lack of food. Native people attacked and killed others, and the records do not state which Native people they were. The colonists shipped many survivors back to Mexico. By September 1560, 362 people were left at the bay, and another 200 were far inland.

A new commander, Ángel de Villafañe, arrived in April 1561. He took most of the roughly 150 settlers still at the bay to Havana. Two small ships of his fleet later sank in another storm off Cape Hatteras, with everyone aboard. The last Spanish soldiers left the bay in August 1561. In February 1562 the viceroy, the Spanish king's governor in Mexico, gave up the colony.

### Tristán de Luna y Arellano

> **Who:** A Spanish noble and soldier who led the colony at Pensacola Bay when the hurricane of 1559 destroyed its ships and food.
>
> **When and where:** Pensacola Bay, Florida, and the Alabama River, 1559 to 1561.

**Luna ordered his hungry soldiers to march, and every one refused.**

Tristán de Luna y Arellano led the colony at Pensacola Bay. It was the largest Spanish attempt up to that time to settle the Southeast, and the one with the most money behind it. Years before, Luna had marched with the Spanish explorer Coronado.

**Looking for food.** From February to June 1560, Luna moved most of his people inland to Nanipacana, the town the first search party had found. In April he sent a second group of 200 men, under Mateo del Sauz, farther north to look for food. They went to Coosa, a chiefdom, a group of towns under one head chief, in present-day northwestern Georgia. They stayed there until November.

**The refusal.** Luna ordered 100 soldiers and 50 servants to march to Coosa in late summer 1560, on short rations, meaning with less food than they needed. All of his soldiers refused, and the march never took place.

When Ángel de Villafañe arrived at the bay with a small fleet in early April 1561, he dismissed Luna and ordered him back to Spain. Luna died in New Spain, the Spanish colony in Mexico, on September 16, 1573.

### The droughts behind the Lost Colony

Tree rings from old bald cypress trees on the border of Virginia and North Carolina show two long droughts in the 1500s. A team of scientists led by David Stahle published the record in 1998. The first drought lasted from 1562 to 1571 and was worst from 1565 to 1569.

A Spanish priest in the Chesapeake Bay region, Father Juan Batista de Segura, wrote about it in September 1570. He wrote that the region had gone six years with too little corn and wild fruit, with hunger, death and dry soil.

**The driest years.** From 1587 to 1589 came the driest three years in the whole 800-year record. English colonists on Roanoke Island, in present-day North Carolina, disappeared during those years. They are known as the Lost Colony. The Stahle team counts the drought as one of several causes of the colony's end. An earlier English colony on Roanoke had come in wetter years, 1585 and 1586. Only 4 of its 108 people died.

The Croatan people were allies of the English colonists, and in 1587 their crops were poor. That same year the people of the town of Dasemunkepeuc killed George Howe, an adviser to the English governor, John White. They spoke an Algonquian language, one of a large family of Native languages along the coast.

They killed Howe in revenge. Men under Ralph Lane, leader of the earlier colony, had attacked and killed their leader, Wingina, in June 1586. After Howe's death the people of Dasemunkepeuc left their town.

**The wrong people.** John White led his soldiers in an attack on Dasemunkepeuc before daylight on August 8, 1587. The people they found there were Croatan, who had come to the empty town looking for food. White's men killed one of them and wounded many before they saw their mistake. The Stahle team links the killing to the drought, because hunger had brought the Croatan to the empty town.

### St. Augustine burns and floods

St. Augustine, in present-day Florida, was burned, raided or flooded again and again in its first 35 years. Spanish soldiers and colonists founded it in 1565 at Seloy, a town of the Timucua people. The Timucua were tired of the Spaniards living in their town. In 1566 Timucua warriors shot flaming arrows at the fort. On April 1, 1566, the fort was half burned, and all its supplies were lost. The records do not state whether the arrows started that fire.

**Thirty-five hard years.** The colonists moved the town across the bay to Anastasia Island that year. In 1570 soldiers there rose against their officers and destroyed the fort. The sea was washing away the rebuilt fort by 1572. Native people attacked the town in 1577 and burned many houses. Then, in 1586, the English privateer Francis Drake, a ship captain who raided enemy ships and towns with his own government's permission, burned the whole town and its fort with his men.

A fire swept through the town in March 1599. It was built of wood, with roofs of thatch, meaning dried plants. In September of the same year a hurricane flooded the buildings that the townspeople had not yet repaired.

## The 1600s

**Era 3 of 10 · The 1600s · about 8 minutes**

Of the 104 English colonists who landed at Jamestown in 1607, only 38 were alive a year later. The English colonies of the 1600s were that small, and one drought or one storm could kill a large share of the people in them.

Colonists built their towns mostly of wood, so a fire in one house could spread to the next. After two big fires, Boston's leaders bought a fire engine from England and ordered new buildings made of brick, with roofs of slate or tile. Governors and ordinary colonists wrote down what they lived through, in letters and journals full of detail.

### Jamestown: drought and a hurricane

English colonists landed at Jamestown, in present-day Virginia, in April 1607. They built their fort inside Tsenacomoco, the land of the Powhatan people. Tsenacomoco was a paramount chiefdom, a group of many towns and chiefs under one head chief. Its head chief was Powhatan.

Chapter 26, Health, Disease, and Medicine, tells how salty river water, sickness and hunger killed most of the first colonists. Tree rings show that the colonists arrived during the driest seven years in 770 years, from 1606 to 1612. The drought hit the Powhatan towns as well as the English.

**The relief fleet.** The leaders of the Virginia Company of London, the business that ran the colony, sent nine ships and about 600 people to Jamestown on June 2, 1609, with farm animals and enough food to last a year. It was the largest English fleet yet to sail west.

A hurricane struck the fleet on July 24, 1609, about seven days from land. It drove the lead ship, the *Sea Venture*, away from the others. The ship began to leak so badly that one passenger wrote, "we almost drowned within."

The *Sea Venture* reached Bermuda, an island in the Atlantic. All 150 people on board got ashore, among them the colony's new governor, Sir Thomas Gates. Before the ship sank, the crew saved many of the supplies. The castaways stayed on Bermuda for ten months and built two small ships, the *Patience* and the *Deliverance*. The playwright William Shakespeare drew partly on their story for his play *The Tempest*.

The other eight ships reached Jamestown in late August 1609. Many passengers were sick, and the crews had thrown many of their supplies overboard in the storm.

### Why Jamestown starved, 1609 to 1610

Most of the people at Jamestown starved to death in the winter of 1609 to 1610, the winter called the Starving Time. The colonists had not farmed, hunted or fished to feed themselves. They lived on supplies from England and on food they bargained for from the Powhatan people, or often stole from them. In the drought the Powhatan towns had little food to spare.

The killing began on both sides in the autumn of 1609. The colonist Francis West cut off the heads of two warriors of the Patawomeck people while he was trading with them. In November 1609 warriors ambushed a party of colonists led by John Ratcliffe at Orapax. They tortured Ratcliffe to death. That same month Powhatan ordered his people to surround Jamestown and cut off its food.

**How many died.** About 500 colonists were in Virginia when the winter began. The historian Martha McCartney counts 240 of them in the fort at Jamestown. By May 1610 only about 60 of those 240 were alive. Some survivors dug up and ate the bodies of dead colonists and of Native people the colonists had killed.

The *Sea Venture* castaways reached Jamestown in their two small ships on May 24, 1610. Gates decided to give up the colony and sail home with the survivors. On the river they met Thomas West, Lord De La Warr, an English nobleman. He was bringing a year's supply of food, and everyone went back to Jamestown. Between 1607 and 1625, the company's leaders sent about 6,000 people to Jamestown. About 4,800 of them died.

### The Great Colonial Hurricane, August 1635

A hurricane struck New England on August 15, 1635. The English then used an older calendar that ran ten days behind the one used today. By today's calendar the date was August 25. William Bradford, the longtime governor of Plymouth Colony, wrote that no one living there, "either English or Indeans, ever saw" a storm like it (*Indeans* is his spelling of Indians).

South of Plymouth the sea rose more than 20 feet above its normal height. Bradford wrote that many Native people climbed into trees to escape the water. No record gives the number of Native people who drowned. The wind blew down houses and, in Bradford's words, "many hundered thowsands of trees." The worst of the storm lasted five or six hours.

The same storm wrecked the *Angel Gabriel*, a ship full of English settlers, at Pemaquid, in present-day Maine. Three or four passengers and one sailor died. Off Cape Ann, in Massachusetts, it wrecked a small boat carrying two families.

### Anthony Thacher

> **Who:** An English colonist who survived the wreck of a small boat in the hurricane of 1635 and described it in a letter to his brother Peter.
>
> **When and where:** Off Cape Ann, Massachusetts Bay Colony, August 11 to 15, 1635.

**Of 23 people on the boat, only he and his wife lived.**

Anthony Thacher wrote down what happened in a letter to his brother Peter, a few days after the wreck. On August 11, 1635, Thacher and his wife, Elizabeth, and their family left Ipswich, in Massachusetts, for the town of Marblehead. With them went his cousin John Avery, a minister, and Avery's family. The people of Marblehead had asked Avery to be their minister, and they sent a pinnace, a small sailing ship, to carry the two families.

Thacher's letter lists 23 people on board: 11 in Avery's family, 7 in his own, a man named William Elliot, and four sailors.

**On the rock.** At about 10 on the night of August 14, the wind split the pinnace's old sails. Before daylight the hurricane struck. The anchor dragged along the bottom, and the storm drove the boat onto the rocks of a small island. A wave threw Thacher onto a rock with his oldest daughter, Mary. His cousin Avery and Avery's oldest son joined them there.

The next wave broke the boat to pieces. It carried his wife toward the shore on a piece of the deck. All the others still on board drowned. Thacher's letter names four of his children who died. They were his oldest daughter Mary, his son William, his daughter Edith, and baby Peter, whom Edith was holding in her arms.

Another wave swept the four on the rock into the sea: Thacher, Mary, Avery and Avery's son. Thacher was in the water for at least a quarter of an hour before he crawled ashore.

**On the island.** He and his wife found a knapsack with a flint, a piece of steel for striking sparks from it, and dry gunpowder. They also found a drowned goat, two cheeses, some butter, a hat and his son William's coat. He struck a fire and they cooked some of the goat. They had only salty water to drink. He found the body of Avery's oldest daughter on the shore. She is buried on the island.

On the following Monday a passing boat picked them up. Thacher named the island "Thatchers Woe" and the rock "Avery's Fall." On September 3, 1635, the colony's lawmakers, meeting as the Massachusetts General Court, voted him 40 marks, an English unit of money, from the treasury toward his losses. In March 1637 they gave him the island. It is still called Thacher Island.

### An earthquake, 1638

An earthquake shook New England on about June 1, 1638, by the old calendar. Bradford wrote that people heard it before they felt it. He compared the sound to faraway thunder. Dishes rattled and fell from shelves. People outdoors could not stand without holding on to posts. Native people felt it inland, and ships along the coast shook.

**How strong.** Scientists at Boston College's Weston Observatory estimate the 1638 earthquake at about magnitude 6.5, on the scale scientists use for an earthquake's strength. Each step up the scale, such as from 6 to 7, means the ground moves about ten times as far, and the quake lets out about 32 times as much energy.

The scientists think it was centered in central New Hampshire, but the few reports of the time make that uncertain. People felt the aftershocks, smaller quakes that follow a large one, for 20 days. No deaths were recorded.

Bradford wrote that the shaking looked like a sign that God was displeased. He added that for years afterward the summers were not warm enough for the corn to ripen well. He left the cause, in his words, "to naturallists to judge," meaning people who study nature.

### Boston burns, and the town buys a fire engine

A fire in Boston on January 14, 1653, destroyed many buildings and killed three children. After it, town officials hired the owner of a water engine, a pump that sprays water, to bring it to fires. They bought six long ladders, four strong iron hooks and fire buckets. They required every property owner to keep a ladder and a swab pole, a long pole with a mop on the end for putting out sparks on roofs.

A fire in Boston's North End destroyed 45 buildings on November 27, 1676. Among them were several warehouses, the North Meeting House, a church, and the home of its minister, Increase Mather.

**The first paid firefighters.** Town officials brought a fire engine from England in 1678 and hired men to run it. A Boston Public Library guide calls them the first paid fire department in what is now the United States. Officials also made a law that roofs be slate or tile and walls be brick. Large fires burned parts of Boston again in 1679, 1682 and 1691.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 10 minutes**

Every member of Philadelphia's Union Fire Company kept six leather buckets ready for the next fire. In these fifty years townspeople began to organize against the fires that kept burning their wooden towns. In 1722 about two-thirds of Boston's nearly 3,000 houses were built of wood. Boston got its first fire wardens after a fire in 1711, and neighbors in Boston and Philadelphia formed fire companies.

When a fire came, the help and the blame did not fall evenly. After Charleston burned in 1740, most of the money from London went to rich merchants. After a string of fires in New York in 1741, officials blamed enslaved Black people and poor white people and put at least 30 people to death. On the coasts, an earthquake in 1700 sent a tsunami across the Pacific to Japan, and a hurricane in 1715 wrecked a Spanish treasure fleet off Florida.

### How Japan's records dated the Cascadia earthquake, 1700

The Cascadia fault broke along about 620 miles of the Pacific coast at about 9 at night on January 26, 1700. The break ran from Vancouver Island, in present-day Canada, to northern California. Scientists at the Pacific Northwest Seismic Network call it one of the largest earthquakes known anywhere in the world. They put its size at about magnitude 9.

The coast dropped when the fault broke. Salt water flooded forests of cedar trees that had grown above the reach of the tides. The salt water killed the trees. Their dead trunks, called ghost forests, still stand along rivers and bays in Washington and Oregon.

**The waves in Japan.** The earthquake also set off a tsunami, a series of huge waves that can cross a whole ocean. The waves reached Japan the next day. At Miyako the water destroyed 13 houses, and a fire afterward burned 20 more. Near Nakaminato the waves drove a ship carrying rice onto rocks, and two sailors died.

The Japanese records describe the waves but no shaking. In 1996 scientists used those Japanese records to work out the day and the hour of the earthquake. Tree rings from the ghost forests confirmed the year.

No one counted the dead on the American coast. The Native nations there had no written records then. In their accounts, whole villages were lost. The Makah, in present-day Washington, tell of a great earthquake at night. The Quileute tell of a flood that carried canoes far inland. Archaeologists have found Native villages on the coasts of Washington and Oregon that sank, flooded and were left empty after 1700.

**The raised water.** Annie Miner Peterson, a Coos woman from Oregon, told what her grandfather had seen. Melville Jacobs, a scholar who was writing down Coos stories, recorded her words in 1933. Her grandfather had seen an old woman who survived the "raised water."

When the old woman was a girl, the water had left her hanging high in a tree. She tied her pack line, the rope she used to carry loads, to a branch to climb down, and she fell. The fall broke her back, and she had a humped back for the rest of her life. Scientists who studied the account date the flood she described to between 1690 and 1805.

### A hurricane sinks the Spanish treasure fleet, 1715

A hurricane drove eleven Spanish treasure ships onto the reefs of Florida's east coast early on July 31, 1715. At least 1,000 people died. The fleet of twelve ships had left Havana, in Cuba, a few days before, bound for Spain. The 1715 Fleet Society gives the day it sailed as July 24, and a NOAA writer gives July 27.

The eleven Spanish ships carried silver and gold from Spain's colonies in the Americas. They were wrecked along the coast from present-day Fort Pierce to Wabasso, north of Vero Beach. The twelfth ship, the French *Grifon*, escaped, because its captain had sailed farther from shore.

**The count.** About 2,500 people were on board the fleet. Scientists at NOAA, the US government's ocean and weather agency, count about 1,000 dead. The 1715 Fleet Society, a group that studies the wrecks, says well over 1,000. Spanish records from Cuba state about 1,500. The fleet's commander, Juan Esteban de Ubilla, was among the dead.

The survivors camped on the beach in the land of the Ais people. The Ais lived along the coast from Cape Canaveral to the Indian River. On August 6, Admiral Francisco Salmón sent the pilot Nicolás de India and 18 men in a small boat to Havana for help. They reached it 11 days later.

Ships from Havana and from St. Augustine brought emergency supplies, officials, soldiers and tools for salvage, which means bringing up goods from a wreck. By late October 1715 the salvagers had raised more than 5 million pieces of eight, the silver coins of Spain.

A man the records call Captain Barrett came for the silver too. Ned Grant was an enslaved man, and his enslaver hired him out to Barrett. Barrett took Grant to the wrecks to work as a diver.

**The pirates.** The pirates Henry Jennings and John Wills attacked the Spanish salvage camp in the winter of 1715 to 1716. The 1715 Fleet Society dates the raid to early January 1716 and says the pirates took about 120,000 pieces of eight. Other accounts put the raid in December 1715, name the pirate Charles Vane beside Jennings, and give the haul as about 87,500 pounds in English money.

### Boston's first fire wardens, 1711

Boston's fire of 1711 began in a building of rented rooms off Cornhill on the evening of October 2. A Scottish woman named Mary Morse was working there with oakum, old rope fiber picked apart and used to seal the seams of ships. A flame nearby set it on fire.

By 2 in the morning the fire had burned about 100 buildings. Among them were the Town House, where the colony's government met, and the town's first meeting house, a building used as a church. The fire left 110 families without homes.

Four sailors climbed the meeting house steeple to save its bell. The roof fell in, and they died. Other people died when they went too close to the fire. Still others died in gunpowder blasts, because people fighting the fire blew up houses in its path so that it would have nothing to burn. The full count of the dead is not known.

**After the fire.** Members of Boston's churches raised 700 pounds, in English money, for the families who lost their homes. A few months after the fire, 12 men became Boston's first board of fire wardens. Each was in charge of the firefighting tools in one part of the town. Bostonians rebuilt the Town House and the meeting house in brick. The new Town House is known today as the Old State House.

### Charleston: a hurricane in 1700 and a fire in 1740

A hurricane struck Charleston, South Carolina, on September 3, 1700. It knocked down thousands of trees and dozens of buildings. The Scottish ship *Rising Sun* sank at anchor. It carried people from a failed Scottish colony at Darien, in Panama. About 100 people on board drowned, including the captain.

A fire broke out in Charleston at 2 in the afternoon on November 18, 1740. A strong wind from the northwest carried burning pieces across the town. In less than a day the fire destroyed more than 300 houses and shops and several docks. The officers and crews of British navy ships in the harbor pulled down and blew up houses to stop it. The records that survive do not say whether anyone died.

Lieutenant Governor William Bull ordered every townsman to fight the fire, "by themselves and slaves." Townsmen were to send the people they enslaved to fight it as well. He called out the militia, the colony's armed citizens, to stop people from stealing from the ruins.

**Who got the money.** Most of the help from London after the fire went to the rich. Officials in London promised 20,000 pounds, in the king's name, for the people "most affected." They paid it out by the size of each person's losses, so most of it went to wealthy merchants, whose losses were large. Poorer people depended on gifts and loans from the vestry, the governing board of St. Philip's Church.

Mary Bedon, an innkeeper with three children, and Catharine Joor, a shopkeeper, lost their businesses in the fire and opened again in rented houses. By February 1741 the two women needed aid from the St. Philip's vestry to get through the winter.

### New York, 1741: fires and blame

Thirteen fires broke out in lower Manhattan in March and April 1741. The first, in March, burned the governor's house and its chapel inside Fort George. Accounts give its date as March 8 or March 18. New York officials claimed that enslaved Black people and poor white people had plotted together to burn the city. A witness named Mary Burton told the court that the fires were such a plot.

Three judges, James De Lancey, Daniel Horsmanden and Frederick Philipse, tried about 200 people. Officials burned 13 Black men alive at the stake, which means they tied each man to a post and set a fire around him. They hanged 17 Black men and 4 white people, two men and two women. Counts of the people put to death range from 30 to 34. Officials shipped 70 to 84 more people to the Caribbean islands to be sold into slavery there.

Historians disagree about whether any plot existed. Judge Horsmanden had offered Mary Burton, a young servant bound to a tavern keeper, an end to her years of service and a reward in money. Other enslaved witnesses spoke after they were promised their lives. Two of the men burned at the stake, Quack and Cuffee, had no lawyers at their trial. Chapter 24, Slavery and Freedom, tells the trials in full.

### An earthquake in New England, 1727

An earthquake shook New England at about 10:40 on the night of October 29, 1727. By today's calendar the date was November 10. Scientists at the Weston Observatory estimate it at about magnitude 5.6. At Newbury, Massachusetts, it knocked down many stone walls and the tops of almost all the chimneys.

Some solid ground turned to mud, and some marshes dried up. People felt it from Maine to the Delaware River, and smaller shocks went on for months. The records that survive show no one badly hurt.

**What the ministers said.** In Boston the minister Cotton Mather heard "a horrid rumbling like the noise of many coaches." Ministers in New England preached that God had sent the earthquake to show his anger. Writers blamed it on sins such as swearing and failing to keep the Sabbath, the day of rest. Towns such as Medford, Massachusetts, held a day of fasting, when people went without food and prayed.

John Barnard, a minister at Marblehead, came to a different view. He decided that the surface of the earth had moved because of shocks deep underground.

### Who came when a house caught fire?

In Boston, groups of neighbors formed mutual fire societies. Members promised to help save one another's houses, and only those. On December 7, 1736, Benjamin Franklin and about 25 other men in Philadelphia signed the articles, or rules, of the Union Fire Company. Every Union member kept six leather buckets for water and two linen bags for carrying goods out of burning houses. They promised to come to every fire in the town, not only to the houses of members.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 8 minutes**

Massachusetts lawmakers voted 3,000 pounds in 1760 for the Boston families whose homes had burned, and lawmakers in Pennsylvania and New York sent money too. Help after a disaster was starting to come from public money that lawmakers voted, and not only from churches and neighbors.

Philadelphians started a company to insure houses against fire in 1752. After big fires, officials in Boston and New Orleans ordered new buildings made of brick. During the Revolutionary War, hurricanes sank Spanish warships and troop ships on the Gulf Coast, and a fire burned a large part of New York while British troops held it.

### Charleston under water, 1752

A hurricane pushed the sea more than 10 feet above the normal high-water mark at Charleston, South Carolina, on the morning of September 15, 1752. The water covered the whole town. People fled to the upper floors of their houses. Before 11 o'clock nearly every ship in the harbor had been thrown onto land. Only one, the British warship *Hornet*, rode out the storm.

About 500 buildings were destroyed. No one kept an exact count of the dead. Many people drowned, and others died when houses fell apart around them. A second storm on September 30 ruined crops and killed farm animals. Officials then limited how much corn, peas and rice could be shipped out of the colony, to keep food prices down.

### Fire insurance, 1752

Benjamin Franklin organized the Philadelphia Contributionship, a fire insurance company, in Philadelphia in 1752. Under fire insurance, many owners each pay a small amount into a shared fund, and the company that keeps the fund pays any owner whose house burns. The Contributionship's inspectors looked at each house before insuring it. They set the price by how likely the house was to burn. Insured houses carried a sign showing four hands.

Owners who insured with the Contributionship had to remove the trees from their land, because trees got in the way of firefighters. A rival company, the Mutual Assurance Company, let its customers keep their trees. People called it the Green Tree.

### The Cape Ann earthquake, 1755

An earthquake centered in the ocean about 25 miles off Cape Ann, Massachusetts, shook New England at about 4:30 in the morning on November 18, 1755. Scientists estimate it at about magnitude 6.2. In Boston the shaking lasted more than a minute. It threw down about 100 chimneys and damaged as many as 1,500 more. Some church steeples were left leaning. People felt it from Nova Scotia, in present-day Canada, to South Carolina. No deaths were recorded in the Boston area.

**The argument.** After the quake, a Boston minister and a Harvard professor argued in public over what had caused it. Seventeen days before the Cape Ann quake, a large earthquake had struck Lisbon, in Portugal. New England ministers held prayer services, and officials named days of fasting. Writers in New England published at least 27 sermons (talks given in church), poems and accounts about earthquakes after the one at Cape Ann.

The Boston minister Thomas Prince wrote that Boston had more lightning rods, metal rods on buildings that carry lightning into the ground, than any other New England town. He argued that the rods had drawn electricity into the ground and made the shaking worse. John Winthrop, a professor at Harvard College, answered him in lectures. He said that heat and gases deep in the earth had caused the earthquake.

### Boston burns, and other colonies send help, 1760

A fire started in a house on Cornhill in Boston at about 2 in the morning on March 20, 1760. No one ever found the cause. The fire burned 349 buildings, 174 of them homes. It left 220 families, more than 1,000 people, without homes. No one was killed. A Boston Public Library guide describes it as the worst fire in the American colonies up to that time.

Lawmakers in Massachusetts voted 3,000 pounds for the families who lost their homes. Lawmakers in Pennsylvania and New York voted to send money too. People in Nova Scotia raised money for Boston, and people as far away as London sent gifts. Afterward Massachusetts lawmakers passed a law that any building more than 7 feet high had to be made of brick or slate.

### Fires in wartime: New York, 1776, and Charleston, 1778

British troops under General William Howe took New York City in September 1776, during the Revolutionary War. On the night of September 20, a fire broke out near the southern tip of Manhattan. Accounts differ on the exact spot. John Joseph Henry, an American prisoner on a British ship, said it began in the Fighting Cocks Tavern, near Whitehall Slip.

Dry weather and strong winds spread the fire north and west. By morning it had burned between 400 and 1,000 buildings. That was between one tenth and one quarter of the city. Trinity Church burned.

**Killed without a trial.** British commanders blamed rebel arsonists, people who set fires on purpose. British soldiers and sailors killed a few men they suspected of setting the fire. They killed them on the spot, without a trial. The records do not give the men's names or an exact number. British officers questioned more than 200 suspects and charged none of them.

Historians still disagree about how the fire started. The historian Barnet Schecter found that no accusation of arson holds up. The historian Benjamin Carp argued in 2023 that rebels most likely set the fire on purpose. Gene Procknow, who reviewed Carp's book, wrote that Carp's evidence is not strong enough to prove it for certain.

**Charleston, 1778.** In Charleston, people found a fire in a bakery at 4 in the morning on January 15, 1778. By noon it had destroyed more than 250 houses and killed six people, both Black and white. People who had lost their homes got beds and food in the city's public buildings, paid for with public money. The next day South Carolina's lawmakers, meeting as the General Assembly, voted 20,000 pounds to help them.

### Hurricanes and the war on the Gulf Coast, 1779 and 1780

Spain's leaders joined the war against Britain on June 21, 1779. That year Bernardo de Gálvez, the Spanish governor of Louisiana, was getting ships ready to attack the British fort at Baton Rouge. A hurricane destroyed the ships in less than three hours. Gálvez had to put off his attack for ten days.

Another hurricane struck a Spanish fleet of 64 ships under Admiral José Solano on October 20, 1780. The fleet was carrying Gálvez and 4,000 soldiers from Havana to attack the British town of Pensacola, in Florida. An unknown number of the ships sank. A NOAA writer counts half of the soldiers, about 2,000, as lost. The NOAA account does not say how many of them drowned. The attack on Pensacola did not go ahead that year.

A different storm that same month crossed the islands of the Caribbean. It is called the Great Hurricane of 1780. About 22,000 people died in the Lesser Antilles, the chain of small islands at the eastern edge of the Caribbean, from October 10 to 16. The storm also struck Puerto Rico. Scientists at NOAA count 1780 as the deadliest Atlantic hurricane season on record.

### Why New Orleans was rebuilt in brick

New Orleans was a Spanish town in 1788. On March 21 of that year, a fire started at about 1:30 in the afternoon in the house of Vicente José Núñez, the army treasurer. That day was Good Friday, the Christian holy day before Easter. Church bells were the town's fire alarm, but the priests refused to let the bells ring on Good Friday. The fire burned 856 of the town's 1,100 buildings. Governor Esteban Miró set up tents for the people who lost their homes.

Another fire burned 212 more buildings on December 8, 1794. Spanish officials then required new buildings to be built with thick brick walls. Builders rebuilt the town in brick, with courtyards and iron balconies.

### Charleston, 1796

A fire started in Lodge Alley in Charleston on the afternoon of June 13, 1796, and burned until nearly dawn. It burned the buildings on more than 250 lots and left at least 300 families without homes. A committee of church leaders and town leaders handed out the money that other townspeople gave, according to what each family needed. The fire reached the roof of St. Philip's Church. An enslaved man named Will climbed up and saved it.

### Will

> **Who:** An enslaved man in Charleston who put out the fire on the roof of St. Philip's Church, and whom the church's leaders then bought and freed.
>
> **When and where:** Charleston, South Carolina, June to September 1796.

**The church's leaders bought him for $707.14, then set him free.**

Will put out the fire on the bell tower of St. Philip's Church during the Charleston fire of June 13 to 14, 1796. He climbed to the very top of the tower and tore off the burning wooden shingles of its roof. In 1854 the writer Charles Fraser wrote that he did it "at the risk of his life."

Will was enslaved by Charles Lining. Lining was a member of the vestry, the board that ran St. Philip's Church. On August 14, 1796, two months after the fire, the vestry's members voted to reward Will by making him free.

The next month they bought Will from Charles Lining for $707.14. Then they freed him with a deed of manumission, a legal paper that freed an enslaved person.

The vestry's records include only his first name. A later history of the church describes the man who saved it as a Black boatman.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 11 minutes**

All four boilers of the steamboat *Moselle* burst at once near Cincinnati in April 1838, and about 150 people died. Between 1800 and 1850, steam engines brought a new kind of sudden death to the country's rivers and lakes. Boilers exploded, and the steamboat *Erie* burned on Lake Erie. In 1838 members of Congress passed the first federal law, a law for the whole country, to inspect steamboats, but no federal officer enforced it.

Earthquakes, a city fire and a tornado killed hundreds more people. After the New Madrid earthquakes of 1811 and 1812, members of Congress voted to give land to people whose farms the quakes had ruined. Most Missourians came to believe that speculators who moved fast got most of the benefit.

### The New Madrid earthquakes, 1811 and 1812

Three strong earthquakes shook the middle Mississippi Valley in the winter of 1811 to 1812. They are named for New Madrid, Missouri, the largest town on the Mississippi River between St. Louis and Natchez. The first struck northeast Arkansas at about 2:15 in the morning on December 16, 1811. The others came on January 23 and February 7, 1812.

Experts at the U.S. Geological Survey estimate these quakes at about magnitude 7.3 to 7.5, on the scale scientists use for an earthquake's strength. The seismologist Susan Hough, a scientist who studies earthquakes, has argued that they were closer to magnitude 7.0.

The shaking threw down log cabins and chimneys as far away as Cincinnati and St. Louis. The first quake woke people in New York City, Washington, D.C., and Charleston, South Carolina. The Encyclopedia of Arkansas states that the shaking rang church bells in Boston. No story about it appeared in Boston's newspapers of the time. Susan Hough thinks the story began with bells that rang in Charleston, South Carolina, and that someone mixed up Charleston with Charlestown, a part of Boston.

**The river.** On the Mississippi River, high banks and whole islands fell into the water. Huge waves sank boats or threw them onto the shore. The river ran backward. Most accounts say it did so for a few minutes, and others say for up to three days.

Land sank near the St. Francis River in Arkansas. In the northwest corner of Tennessee the ground sank and formed Reelfoot Lake, about 18 miles long and 5 miles wide. Aftershocks, the smaller quakes that follow a large one, went on into 1816.

Reports of the time counted fewer than 100 deaths on land. No one counted the dead on the river or in the Native towns of the region. The historian William E. Foley writes that recent scholars believe the real number of deaths was far higher. Groups of Cherokee people who had already moved west from their homelands farmed along the St. Francis River. The earthquakes ruined their land. They left their farms and cattle and moved west again, where the Osage people living there resisted them.

**Who got the land.** Missouri was then a territory, land that belonged to the country but was not yet a state. In 1814 its governor, William Clark, and two other leaders asked Congress for help. In February 1815 members of Congress passed a law for people whose land the quakes had ruined. Each owner could claim the same amount of public land somewhere else, up to 640 acres. It was one of the country's earliest laws to help people after a disaster.

Speculators, people who buy things cheaply to sell them later for a profit, learned of the law first. In the spring of 1815 they hurried to New Madrid. They bought the ruined land at low prices from owners who had not yet heard of the law. Most Missourians came to believe that the speculators got most of the benefit. The records do not identify them by name.

### Fire in the cold: New York, 1835

A gas pipe burst in New York's business district on the night of December 16, 1835. A coal stove lit the gas. The temperature that night fell as low as 17 degrees below zero. The rivers were frozen. Firefighters cut holes in the ice to reach water, and the water froze again in their hoses. They had fought two large fires two days before, and the city's water tanks were nearly empty.

The fire burned 17 blocks and between 530 and 700 buildings in New York's business district. Two people died. At about 3 in the morning, U.S. Marines and sailors brought gunpowder from the Brooklyn Navy Yard. They blew up buildings in the fire's path so that it had nothing left to burn. The damage came to about 20 million dollars. Twenty-three of New York's 26 insurance companies went out of business. The people who investigated the fire blamed no one.

### Why steamboat boilers exploded, 1838

A steamboat's boiler is a large metal tank where a fire turns water into steam to drive the engine. A boiler can burst if the steam pressure grows too high. It can also burst if the water inside runs low and someone then lets cold water in on the hot metal.

All four boilers of the steamboat *Moselle* burst at once on April 25, 1838, as it pulled away from a landing just east of Cincinnati. The captain, Isaac Perin, had kept the boilers at full steam during the stop, to impress people watching from shore. Many witnesses said he was racing another boat, the *Ben Franklin*. The blast threw Perin onto the riverbank and killed him.

A committee of Cincinnati citizens met the next day. Its members counted at least 280 passengers on board and estimated about 150 dead. Later accounts give 160.

**The *Pulaski*.** The steamship *Pulaski* ran between Savannah, Georgia, and Baltimore, Maryland. On June 14, 1838, it left Charleston, South Carolina, for Baltimore. At about 11 that night, about 40 miles off the coast of North Carolina, its starboard boiler, the one on the ship's right side, exploded. The ship broke in two and sank in about 45 minutes.

About 128 people died, and 59 were saved. The records of the numbers do not agree. One record lists 168 people on board, 37 crew and 131 passengers. Yet 128 dead and 59 saved add up to 187.

Investigators at the end of 1838 found that the engineers had run the boilers wrongly. An account written with the help of two survivors identifies the cause. The second engineer let the water boil away in the boiler and then let a full load of cold water in on the hot copper. The account does not include his name.

Families on the *Pulaski* brought enslaved people with them. The passenger list does not name them. It puts the word "servant" after the family's name. The list also names three Black women, Jenny, Priscilla and Sallie Middleton, and does not say whether they were enslaved or free. The records do not say how many enslaved people died.

### Rebecca Lamar

> **Who:** A survivor of the *Pulaski* explosion who lived on a floating piece of the wreck from Thursday night until the next Tuesday, and later wrote down what happened.
>
> **When and where:** Off the coast of North Carolina, June 14 to 19, 1838.

**She tore her dress into squares to cool the children's heads.**

Rebecca Lamar survived on a floating piece of the *Pulaski* from Thursday night, June 14, until the next Tuesday, and later wrote down what happened there. She was traveling north with her brother, the Savannah banker Gazaway Bugg Lamar. With them were his wife, Jane, and their six children. Another niece of hers was also on board. Her brother owned shares in the ship.

The explosion woke her in her cabin. Her bed had jammed the door, so she began to climb out through the small window above it. Her brother put her and a niece into a small boat. A moment later something struck her, and she was in the sea. She caught hold of a piece of wood and pulled herself onto a floating section of the ship. Her niece Martha and her nephew Charles reached her there. A stranger brought her nephew Thomas to her.

**On the wreck.** The people on that section of the wreck had almost no food or water. They saved the wine and peppermint for the children. Rebecca Lamar tore strips from her dress into squares. She wet them and laid them on the children's heads during the day, to keep the children from getting thirsty. On the second day six men who could swim took the best small boat to row for help. Her brother was one of them. They reached the beach 40 miles above Wilmington, North Carolina.

People on the wreck died one by one. A man named Mr. Brown drank sea water. In a storm a woman named Mrs. Woart died, and a wave carried off her body and her husband, the Reverend Woart. Two men became delirious, which means confused and out of their minds, and walked into the sea.

A man named Mr. Smith set off on a raft he had built and was never heard from again. On the Monday night her nephew Thomas died in her lap.

**The third search.** On the following Tuesday the schooner *Henry Cameron*, a sailing ship with two masts or more, under Captain Eli Davis, found them. The *Pulaski*'s sailing master, the officer in charge of sailing the ship, Captain Pearson, was already on board, rescued from another piece of the wreck. That group numbered 23 people in all. He asked Davis three times to search for more survivors. The third search found Rebecca Lamar's group.

Her brother's wife, five of their six children and a niece died. Her brother and his son Charles, age 14, lived. Charles later led the investors who paid for the ship *Wanderer* to smuggle captive Africans into Georgia in 1858. Chapter 24, Slavery and Freedom, tells that voyage.

Rebecca Lamar later married Hugh McLeod. She wrote her account of the wreck without planning to publish it. The *Georgia Historical Quarterly* later printed it.

### A safety law no one enforced, 1838

Members of Congress passed a law "to provide better security of the lives of passengers" on steamboats on July 7, 1838. It was the first federal law that required steamboats to be inspected. Under it, federal judges named engineers as inspectors. The inspectors checked each boat and gave the owner two certificates, signed papers the owner needed to get a license to run the boat. Owners paid 5 dollars for each inspection, repeated every 6 or 12 months.

**No one to enforce it.** No federal officer enforced the law. Only a person who sued the owner in court could make an owner obey it. After 1838 steamboat disasters came more often and killed more people.

### A tornado at Natchez, 1840

A tornado, a spinning column of wind that reaches down from a storm cloud to the ground, struck the Mississippi River at Natchez, Mississippi, at about 1 in the afternoon on May 7, 1840. It struck Vidalia, Louisiana, across the river, too. At the Natchez landing it threw 116 of the 120 flatboats into the river. Flatboats were large, flat-bottomed boats that carried farm goods and people downriver, and their crews and passengers drowned.

At least 317 people died, 269 of them on the river and 48 on land. The courthouse at Vidalia fell and killed Judge Keeton. Many bodies were never identified. By that count it is the second deadliest tornado in the country's history.

**Left out of the count.** The count of 317 leaves out the enslaved people killed on plantations in Louisiana. P. M. Lapice reported that on his plantation below Vidalia the tornado blew down all the houses of the enslaved workers. Four or five people were killed outright. About twenty were badly hurt, and some of them had wounds so bad that they were dying.

The *Mississippi Free Trader*, a Natchez newspaper, printed reports of hundreds of enslaved people killed on plantations up to 20 miles away, but no one made an exact count.

After the storm Stephen Duncan, a planter, the owner of a large farm worked by enslaved people, paid to turn the Tremont House hotel into a hospital. Doctors and several thousand dollars came from New Orleans. Other slaveholders in the area sent large groups of enslaved people to clear the ruins and pull out the bodies.

### The steamboat Erie burns, 1841

The steamboat *Erie* carried passengers between Buffalo, New York, and Chicago. On the evening of August 9, 1841, it left Buffalo with about 340 people on board. The boat had just been painted and varnished.

A group of six painters, hired by William G. Miller of Buffalo, planned to ride only to the first stop, in Pennsylvania. They had left jugs of paint, varnish and turpentine, a paint thinner that burns easily, on the deck, near the boiler's vent pipe. That spot on the deck had caught fire three times before.

At about 8 p.m., off Silver Creek, New York, on Lake Erie, the turpentine exploded. Fire spread over the freshly painted boat within seconds. Two of the lifeboats turned over. The third carried the captain, Thomas Jefferson Titus, and four others. At 10 p.m. the crew of another steamboat, the *DeWitt Clinton*, arrived and pulled survivors from the lake. Fewer than 100 people were saved. The first counts put the dead at about 170. Later counts found as many as 254. All six painters died.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 16 minutes**

More than 2,000 Union soldiers were crowded onto the steamboat *Sultana*, built to carry 376, in April 1865. Its sinking, the Peshtigo fire and the Johnstown Flood each killed more than 1,000 people. They are still the country's deadliest shipwreck, deadliest wildfire and deadliest dam failure. After the *Sultana* and Johnstown, survivors and investigators blamed named men, and no court punished any of them.

In the same years Americans built groups whose job was to warn people of danger or to help them afterward. Under a law of 1870, Army soldiers took on the job of warning people about storms. Clara Barton founded the American Red Cross in 1881.

### What the Steamboat Act of 1852 changed

Steamboat explosions and fires went on after the law of 1838. From 1847 to 1852, boiler explosions caused a long run of disasters. On August 30, 1852, members of Congress passed a stronger law, the Steamboat Act. Under it, officials of the Treasury Department enforced the rules through supervising inspectors, who were in charge of the local inspectors. Under the old law, only a lawsuit could make an owner obey.

Inspectors had to test every boiler by filling it with water under pressure, to see whether it leaked or burst before it was used with steam. Owners had to fit each boiler with a safety valve, a part that lets steam out before the pressure gets too high. Pilots and engineers had to earn a license from the inspectors. The law left out freight boats, ferries and tugboats. A law of 1871 covered all steam vessels and their crews.

### The Sultana, 1865: 2,000 men on a boat built for 376

The worst shipwreck in the country's history happened on the Mississippi River in April 1865, just as the Civil War was ending. The steamboat *Sultana* was built to carry 376 passengers. At Vicksburg, Mississippi, Union Army officers crowded more than 2,000 Union soldiers onto it. Most of the soldiers had just been freed from Confederate prison camps at Cahaba, Alabama, and Andersonville, Georgia.

**The deal.** Army officials paid boat owners for each soldier they carried home. They paid 2 dollars and 75 cents for each enlisted soldier, meaning one who was not an officer, and 8 dollars for each officer. Captain Reuben Hatch was the Army's chief quartermaster, or supply officer, at Vicksburg. He offered the *Sultana*'s captain, J. Cass Mason, a full load of about 1,000 soldiers. In return Hatch wanted a kickback, a secret payment for the favor.

One of the boat's boilers was leaking. Mason had it patched instead of making the longer repairs a full fix would take. Captain George Williams, the officer in charge of loading, put every man at the Vicksburg parole camp, where freed prisoners waited to go home, on board. He believed there were fewer than 1,500.

**The explosion.** The boilers exploded at about 2 in the morning on April 27, 1865, about seven miles north of Memphis, Tennessee. The boat caught fire. Investigators blamed low water in the boilers while the overloaded boat leaned to one side, along with the patched boiler. Men who were thrown into the river floated past Memphis in the dark.

Crews of other steamboats and of U.S. Navy ships pulled survivors from the water. On the Arkansas shore, the Fogelman family tied logs into a raft and took 25 soldiers off the burning boat. Franklin Hardin Barton, a Confederate soldier of the 23rd Arkansas Cavalry, was among the rescuers. The *Sultana* burned and sank at about 7 a.m.

Almost everyone on board was a Union soldier. Counts of the dead range from about 1,100 to about 1,800. General William Hoffman investigated for the Army and counted 1,238 in May 1865. Officials of the Customs Service, who kept records of ships, counted 1,547. The researcher Jerry Potter estimates about 1,800. About 200 of the men pulled out alive later died of their burns. Mason and most of the boat's officers died.

**No one punished.** Captain Frederic Speed of the Army was tried and found guilty of overcrowding the boat. The Army's top lawyer, the Judge Advocate General, overturned the verdict. He found that Speed had spent the whole day at the camp and had not put a single soldier on board. Hatch quit the Army and refused three orders to come and testify. No one was punished.

### Fire on October 8, 1871: Chicago and Peshtigo

On the evening of October 8, 1871, two fires began that together killed well over a thousand people. The smaller one burned the city of Chicago. The larger one burned the forests and towns of northeastern Wisconsin and Michigan's Upper Peninsula.

The Chicago fire started at about 8:30 p.m. in or near a small barn that belonged to Catherine O'Leary's family. More than two-thirds of the buildings in Chicago were made entirely of wood, and most had roofs of tar or wooden shingles, which burn easily. Only 1 inch of rain had fallen since early July. Strong winds from the southwest carried burning pieces toward the center of the city.

The fire burned until October 10. It destroyed about 17,500 buildings over more than 3 square miles and left 90,000 to 100,000 people without homes. Searchers found 120 bodies. The county coroner, the official who looks into deaths, said that an exact count was impossible. The death toll may have been as high as 300.

**The cow story.** A newspaper reporter, Michael Ahern, wrote that Catherine O'Leary's cow and a lantern had started the fire. She was a poor Irish Catholic immigrant, which made her an easy person to blame. In 1893 Ahern admitted that he had made the story up. In 1997 the members of the Chicago City Council voted to clear her name. The historian Richard Bales has suggested that a man named Daniel Sullivan started the fire.

Mayor Roswell B. Mason put the city under martial law, rule by the army, and placed General Philip Sheridan in charge from October 11 to 24. He also gave a private charity, the Chicago Relief and Aid Society, control of the relief. Donors in New York City gave $450,000 and donors in St. Louis $300,000. Money came from London too.

**Peshtigo.** The fire in Wisconsin began with people who were clearing forest for farms and railroads. They set small fires to burn away the brush. On October 8 a cold front, the edge of a large mass of cold air, moved east and made the wind stronger, and the wind joined several of those fires into one.

It burned about 1.2 million acres. It destroyed Peshtigo, Wisconsin, a town of about 1,700 people, and 16 other towns. People jumped into the Peshtigo River, into wells and into other water nearby to escape the flames. Some drowned, and others died of cold in the water.

The fire burned the town's records, so no one knows exactly how many people died. Estimates run from 1,200 to 2,400. In 1873 a report to Wisconsin's lawmakers listed 1,182 names of people who died or went missing. More than 350 bodies were buried in one grave, because no one was left alive who could name them. It is the deadliest wildfire in the country's recorded history.

Peshtigo stood on forest land that had belonged to the Menominee Nation. Henry Dodge, the governor of Wisconsin Territory, signed a treaty, a written agreement between nations, with the Menominee in 1836, at a place called The Cedars, on the Fox River. Under the Treaty of the Cedars, the Menominee handed over about 4 million acres to the United States, and United States officials agreed to pay $700,000. Loggers and white settlers then moved onto the land.

### The Red Cross, 1881, and an earthquake in Charleston, 1886

Clara Barton and a group of supporters founded the American Red Cross in Washington, D.C., on May 21, 1881. On September 5, 1881, forest fires burned more than a million acres in the Thumb, the part of Michigan shaped like a thumb. The fires killed 282 people and left thousands without homes. Red Cross workers sent money, clothes and furniture to about 14,000 people in need there. It was the Red Cross's first disaster relief.

An earthquake of about magnitude 7 shook Charleston, South Carolina, at about 9:50 on the night of August 31, 1886. It killed 60 people and damaged about 2,000 buildings. Most of the damage, 81 percent of it, was to brick buildings. Wooden buildings were damaged much less than brick ones.

### Storm warnings and the blizzards of 1888

President Ulysses S. Grant signed a law on February 9, 1870, that started a national weather service inside the Army's Signal Service, the branch that handled signals and telegraph messages. The law required the Secretary of War to have weather readings taken and to send notice of coming storms, by telegraph and signals, to the northern lakes and the seacoast.

**The Schoolchildren's Blizzard.** A blizzard, a snowstorm with very strong wind and bitter cold, struck the northern Great Plains without warning on January 12, 1888. The morning had been warm, near 50 degrees. In Huron, Dakota Territory, many children left for school without winter coats. About 235 people died in Dakota Territory, Nebraska, Minnesota and Iowa, by one count. Other estimates range from 250 to 500, and some go as high as 1,000. People call it the Schoolchildren's Blizzard.

Near Ord, Nebraska, the wind tore the door and the roof off the schoolhouse of Minnie Freeman, a teacher of 19. The schoolhouse was made of sod, blocks of earth held together by grass roots. Freeman tied her students together with twine and carried the youngest in her arms. She led them to a farmhouse about half a mile away, and all of them lived.

In Plainview, Nebraska, the teacher Loie May Royce tried to lead three students to her home, less than 90 yards from the school. The wind-driven snow blinded them, and they lost their way. Searchers found them the next morning. The three children were dead. Royce's arms and legs were frostbitten, which means the cold had frozen and damaged the flesh.

In Turner County, in present-day South Dakota, five boys were found dead four days after the storm. They were John Albrecht, Peter Graber, and Henry, John and Elias Kaufman.

**A new Weather Bureau.** Another blizzard struck the Northeast in March 1888 and killed about 400 people. Forecasters of the Signal Service had predicted brisk winds and rain, then fair weather. After the two storms, members of Congress passed a law on October 1, 1890. Under it, weather forecasting moved from the Army to a new Weather Bureau in the Department of Agriculture. The bureau's forecasters were civilians, people who were not in the army.

### Who weakened the Johnstown dam?

The dam that broke above Johnstown, Pennsylvania, belonged to a private club of wealthy Pittsburgh men. The changes they made had weakened it. The South Fork Dam was 69 feet high and held back a lake 14 miles up the valley from Johnstown. Henry Clay Frick led a group of Pittsburgh businessmen who bought the lake for the South Fork Fishing and Hunting Club. The club had more than fifty members, most of them steel, coal and railroad owners.

Workers the club hired lowered the top of the dam by as much as 3 feet to make room for a road for carriages. They put a screen across the spillway, the channel that lets extra water out, to keep the club's fish in the lake. Someone had removed the pipes at the bottom of the dam, which could let water out, before the club bought it, and club members never replaced them. The club's members had no way to lower the lake in an emergency.

**May 31, 1889.** The heaviest rain ever recorded in that part of the country fell on western Pennsylvania on May 30 and 31. Army weather officers estimated 6 to 10 inches in 24 hours. The dam broke in the afternoon of May 31, 1889.

Earlier that day the club's president, Elias Unger, had twice sent a man named Parke on horseback to a telegraph office to warn Johnstown. The people who received the warnings did not pass them on to the town's leaders, because there had been many false alarms before.

The water rushed down the valley. The railroad engineer John Hess drove his engine backward toward East Conemaugh with the whistle blowing the whole way. His warning saved many people. At the Stone Bridge in Johnstown, the wreckage piled up against the bridge and caught fire. At least 80 people died there, and the fire burned for three days.

**The dead.** The flood killed 2,208 people. The first count was 2,209, until Leroy Temple, counted among the dead, turned up alive eleven years later. Ninety-nine whole families died. National Park Service staff count 396 children under the age of 10 among the dead. Of all the dead, 777 were never identified.

**Who was left.** The flood left 124 women and 198 men widowed. It left 98 children orphaned, and by the Park Service's count 568 children lost one or both parents.

**Who paid.** The American Society of Civil Engineers, a group of engineers, released a report in 1891. It stated that the dam would have failed even if the club had kept it as first built. The group's president in 1890, William Shinn, had been a business partner of Andrew Carnegie. The report was kept from the public for two years. The authors of a study published in 2016 found that the club's changes cut the amount of water the dam could safely let out by half.

Survivors sued the club. Two of its members, the lawyers Philander Knox and James Hay Reed, defended it in court. They argued that the flood was an "act of God," a natural event that no person could be blamed for. The survivors lost, and no one ever paid them for their losses. Frick and about half of the club's members gave money to help the survivors. Andrew Carnegie built the town a new library.

### Victor Heiser

> **Who:** A 16-year-old who rode the Johnstown Flood on a barn roof, lost both his parents, and later became a doctor.
>
> **When and where:** Johnstown, Pennsylvania, May 31, 1889.

**From a barn roof he watched his house crushed at 4:20 p.m.**

Victor Heiser was 16 when the Johnstown Flood destroyed his home and killed his parents. As the river rose that afternoon, his father sent him to the barn to untie the horses. He heard what he called a "dreadful roar." He looked back and saw his parents at a window of the house. His father waved at him to climb onto the barn roof.

From the roof he saw his house "crushed like an eggshell." He noted the time: 4:20 p.m. The barn floated away with him on its roof. When it was about to hit a neighbor's house, he jumped onto that house. It began to fall in, and he fell back onto the barn roof. The water carried him down to the Stone Bridge.

He spent the night in a house with 19 other people. The next day he went looking for his parents. He tried to help people trapped in the burning wreckage at the bridge. For two weeks he searched among the bodies of the dead. He found the body of his mother, Mathilde Heiser. He was never able to identify his father, George.

Heiser later studied at Jefferson Medical College and became a doctor. He worked in many countries against diseases such as leprosy, cholera and malaria. In 1936 he told his story in a book, *An American Doctor's Odyssey*.

### The Sea Islands hurricane, 1893

A hurricane came ashore near Savannah, Georgia, on August 27, 1893, and drove the sea over the low Sea Islands of South Carolina. Between 1,000 and 2,000 people died, most of them drowned. Most people on the islands were Black. On St. Helena Island about 6,000 Black people lived, and most of them owned their land. Many of their houses stood no more than 2 feet above the ground.

**Who got the food.** Red Cross workers arrived on October 1, more than a month after the storm, and ran a relief effort for 10 months. By the Red Cross's own count, Clara Barton's workers helped about 30,000 people left homeless by the storm, most of them Black. The historian Caroline Grego wrote about the relief work in 2019. She found that South Carolina politicians and newspaper writers pushed Red Cross leaders to send supplies to white farmers instead of to Black islanders. The Democratic Party leaders who ran the state government worked against the efforts of Black islanders to earn a steady living again.

In an online exhibit for the College of Charleston, Grego names some of the people involved. In March 1894 Eugene Gregorie, a white farmer at Pocotaligo, asked the politician William Elliott to tell Clara Barton that the free food the Red Cross handed out was hurting the white planters. Gregorie wrote that Black workers were refusing to work in the planters' fields while the Red Cross fed them, and he wanted the food stopped before planting time in May.

Black farmworkers on the rice plantations nearby sent seven petitions, written requests signed by many people, to Barton that spring. They wrote that they wanted to work, but the planters had little work to give and paid about 40 cents a day.

The *Columbia Daily Register* printed an article titled "Cursing the Red Cross!" in May 1894. It said that outside the towns of Beaufort and Port Royal, not a dozen white men in Beaufort County had a good word for the Red Cross. Governor Benjamin Tillman backed a collection of money for white farmers at Bluffton, after newspapers claimed that the Red Cross was discriminating against white sufferers.

### Clara Barton

> **Who:** The founder of the American Red Cross, who led its relief work after fires, floods and hurricanes.
>
> **When and where:** Michigan, 1881. Johnstown, Pennsylvania, 1889. The South Carolina Sea Islands, 1893. Galveston, Texas, 1900.

**Her house was built from the lumber of Johnstown's Red Cross buildings.**

Chapter 26, Health, Disease, and Medicine, tells how Clara Barton carried supplies to Civil War battlefields and founded the American Red Cross. She led its relief work after disasters for more than 20 years.

She reached Johnstown on June 5, 1889, five days after the flood. She was 67. About 50 Red Cross workers came with her from Washington, D.C., and they stayed five months. Her workers built "Red Cross hotels" where people who had lost their homes could stay. Most of the people who rented rooms in them were merchants and businessmen. Red Cross workers gave out supplies worth $211,000 and helped about 25,000 people.

A separate Red Cross group from Philadelphia ran a hospital in Johnstown. The historian David McCullough wrote that Barton "spoke her mind once or twice" to the head of that group. Within a few days neither group would have anything to do with the other.

After the Sea Islands hurricane of 1893 she led the Red Cross relief on the islands. Her last relief work came after the Galveston hurricane of September 1900.

Her house in Glen Echo, Maryland, was built partly from lumber of the Red Cross buildings at Johnstown. She lived there from 1897 to 1912.

**If you remember one thing:** The deadliest shipwreck, wildfire and dam failure in the country's history all came in these fifty years, and no one was punished for the *Sultana* or for Johnstown.

- 1865: More than 2,000 freed Union prisoners crowd onto the *Sultana*, and between 1,100 and 1,800 of them die.
- 1871: The Peshtigo fire kills between 1,200 and 2,400 people on the same night that Chicago burns.
- 1889: The South Fork Dam breaks, and 2,208 people die in Johnstown.

**Next:** In September 1900 a hurricane flooded Galveston, Texas, and killed more people than any other natural disaster in the country's history.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 24 minutes**

The Galveston hurricane of September 1900 killed between 6,000 and 12,000 people, more than any other natural disaster in the country's history. In the fifty years after it, many more people died because of choices other people made.

Witnesses said the owners of a New York blouse factory kept an exit door locked. Near Los Angeles the city's chief engineer and his assistant judged a leaking dam safe, and in Texas members of a school board piped waste gas into a school to save money. After the Triangle fire, the *Titanic*, the New London school explosion and the Cocoanut Grove fire, lawmakers wrote new safety rules for factories, ships, gas lines and nightclubs.

In three disasters, the people in charge treated Black survivors and Black victims worse than white ones. In Galveston, members of an armed militia forced Black workers at gunpoint to bury the dead. In the 1927 Mississippi flood, the local leaders who ran many relief camps gave supplies to white people first and forced Black people to work. After the 1928 hurricane in Florida, officials saved the few coffins for white victims, and the bodies of Black victims were burned in piles or thrown into mass graves.

### Galveston, September 8, 1900

A hurricane flooded Galveston, Texas, on September 8, 1900, and killed more people than any other natural disaster in the country's history. Galveston was a port city of about 38,000 people on an island in the Gulf of Mexico. At about 6:30 that evening, a storm wave put the city under as much as 15 feet of water. The highest water mark was 15.7 feet. The storm destroyed a third of the city, including between 2,636 and about 3,600 homes by different counts.

Between 6,000 and 8,000 people died in the city. Estimates for the whole island and the nearby coast run from 10,000 to 12,000. The *Galveston News* printed a list of 4,263 dead in early October, months before searchers found the last body.

Searchers found about 70 bodies a day during the first month. The last body was found on February 10, 1901. Galveston's leaders put the city under martial law, which means soldiers or armed guards take over from the police and courts. A volunteer militia, a group of armed citizens, patrolled the streets against looters, people who steal from damaged buildings. Some accounts say that men accused of looting were shot, but the records do not give their names or a count.

**Forced at gunpoint.** Too few volunteers came forward to handle the dead, so armed men rounded up other men at gunpoint or bayonet point to do it. The writer Elizabeth Blasius found that members of the volunteer militia did this, and that many of the men they forced were Black workers. About one fifth of the people of Galveston were Black. Even before the storm, the city's segregation rules, which kept people apart by race, kept Black Galvestonians from drinking at the public fountains or going to the public schools.

At first, workers loaded bodies onto barges, tied heavy rocks to them and dropped them into the Gulf. Days later, some of the bodies floated back to shore. After that, workers burned the dead in large fires. The fires burned into November.

Clara Barton, 78, arrived with Red Cross workers on September 17, nine days after the storm. Mayor Walter C. Jones led a Central Relief Committee that included the banker John Sealy. The committee's members spent its money on 483 new houses and on partial help toward 1,114 more.

**The seawall.** Afterward, workers built a seawall that stood 17 feet above the low-tide line. Its first section ran three and a half miles. Workers then raised the ground under the city by as much as 17 feet. They lifted about 2,000 buildings on jacks first. St. Patrick's Church, which weighed 3,000 tons, went up five feet.

### Isaac Cline

> **Who:** The chief of the U.S. Weather Bureau office in Galveston, whose pregnant wife died in the 1900 hurricane.
>
> **When and where:** Galveston, Texas, September 8, 1900.

**He had called a hurricane harming Galveston "a crazy idea."**

Isaac Cline took charge of the Galveston weather office in 1889, when the Army's Signal Service still ran the country's weather service. The office passed to the new Weather Bureau in 1890, and his brother Joseph joined him there in 1892. Isaac wrote an article for the *Galveston Daily News* in 1891, nine years before the storm. In it he called the thought of a hurricane seriously harming Galveston "a crazy idea." Many people in the city had asked for a seawall. His article was one reason no seawall was built before the storm.

**The flags.** On September 8, 1900, water began flooding the low parts of the city. Around noon, Cline raised the hurricane warning flags without waiting for approval from the Weather Bureau's main office in Washington. Weather Bureau rules required that approval.

Cline later wrote that he drove a horse-drawn cart along the beach and warned people to leave. No eyewitness ever reported seeing him do it. The writer Erik Larson argued that Cline warned no one before his office sent out its official warning.

Cline's wife, Cora, was pregnant with their fourth child, and she died in the storm. Cline nearly drowned. He saved his youngest daughter, Esther, who was 6. Joseph saved the two older girls, Allie May, 12, and Rosemary, 11.

Cline moved to New Orleans in 1901. Between 1900 and 1924 he charted the paths of 16 storms.

### San Francisco, 1906: the fire after the earthquake

Fire did most of the damage after the San Francisco earthquake of April 18, 1906. The earthquake struck at 5:12 in the morning. It had a magnitude, the number scientists use for an earthquake's strength, of about 7.9, and it shook the city for about 42 seconds. It broke gas pipes, and within three days more than 30 fires had spread across the city. Between 80 and 95 percent of the damage came from the fires.

Firefighters tried to blow up buildings with dynamite to make empty gaps the fire could not cross. They had no training with dynamite, and some of their blasts started new fires. The city's fire chief, Dennis T. Sullivan, had been hurt in the earthquake itself, when a building next door fell onto the fire station where he lived. He died four days later.

General Frederick Funston sent in Army soldiers. Some building owners set fire to their own damaged buildings, because their insurance paid for fire damage and not for earthquake damage.

More than 80 percent of the city was destroyed. Between 227,000 and 300,000 people lost their homes, out of about 410,000. The first counts of the dead ran from 375 to more than 500. Those counts left out hundreds of deaths in Chinatown that no one recorded. In 2005 the members of the Board of Supervisors, San Francisco's city lawmakers, voted to accept more than 3,000 as the official count. They voted for a written statement by the novelist James Dalessandro and the city historian Gladys Hansen.

On the day of the earthquake, Mayor Eugene Schmitz announced that he had given soldiers and police permission "to kill any and all persons found engaged in Looting or in the Commission of Any Other Crime." The records do not say how many people they killed. People also accused soldiers themselves of looting.

**Chinatown.** About 15,000 Chinese people lived in Chinatown, and they lost nearly everything. Even before the earthquake, some city officials had wanted to move the Chinese out of Chinatown to Hunters Point. After it, they tried to use the ruins to take Chinatown's land for business buildings.

The Chinese were the only group that officials kept apart in the camps for people who had lost their homes. Army officers moved the Chinese survivors to camps farther and farther from Chinatown. Most Chinese survivors left for Oakland, and only about 400 stayed in the city. The officials' plan to move Chinatown failed. Chinese residents rebuilt Chinatown.

### Hugh Kwong Liang

> **Who:** A 15-year-old in San Francisco's Chinatown who lived through the 1906 earthquake and fire.
>
> **When and where:** San Francisco, April 1906.

**He was 15, and the building across the street fell down.**

Hugh Kwong Liang was 15 when the earthquake woke him in Chinatown. He is one of the few Chinese survivors whose own account of the earthquake has lasted to today. He remembered seeing "pieces of plaster falling down like water." He ran out into Washington Street, and the building across from his home fell down.

As the fire spread, city officials who were directing the people fleeing told him and his family to go to the open ground of the Presidio. The Presidio was an Army post by the Golden Gate, the entrance to San Francisco Bay. He remembered the moment he left: "I turned away from my dear old Chinatown for the last time."

At the Presidio, Army officers kept the Chinese survivors apart from everyone else. They moved them from camp to camp. The last camp stood in a cold, windy corner of the Presidio near Fort Point.

### The Triangle fire, March 25, 1911

A fire at the Triangle Waist Company in New York City killed 146 workers on March 25, 1911. Witnesses said the owners kept one of its exit doors locked. The company made women's blouses on the top three floors of the ten-story Asch Building. Most of its workers were young immigrant women, and many were teenagers. The youngest who died, Kate Leone and Rosaria Maltese, were 14.

The fire started on the eighth floor just before the 4:45 p.m. quitting time. Workers ran down the Greene Street stairs, crowded into the elevators, and climbed onto the one fire escape, which collapsed.

**The locked door.** On the ninth floor, the door to the Washington Place stairs would not open. Witnesses told the court that the owners, Max Blanck and Isaac Harris, kept it locked so workers could not leave with stolen blouses. Harris later admitted that all the blouses ever stolen were worth less than 25 dollars.

The firefighters' ladders reached only to the seventh floor. Workers trapped on the ninth floor could not get past the fire, and many jumped from the windows. A crowd in the street watched 62 people jump or fall to their deaths. Joseph Flecher, who worked in the company office, watched from the roof and saw his workers "hit the sidewalk spread out and still."

On the tenth floor, workers climbed to the roof. A law professor at New York University, Frank Sommer, and his students found ladders that painters had left and set them across to the school's roof. Workers climbed over them to safety.

**The trial.** Blanck and Harris were put on trial for manslaughter, the crime of killing a person without meaning to, through carelessness. Judge Crain told the jury it had to find that the owners knew the door was locked. On December 27, 1911, after less than two hours, the jury found them not guilty. One juror, Victor Steinman, said he believed the door was locked, "but we couldn't find them guilty unless we believed they knew the door was locked."

The families in 23 lawsuits against the building's owner settled on March 11, 1914, which means they agreed to take money and end the lawsuits. They got an average of 75 dollars for each life.

New York lawmakers set up a nine-member Factory Investigating Commission. From 1911 to 1914 they passed 36 new laws to change the state's rules for workplaces. A state law already in force at the time of the fire had required factory doors to open outward where possible and to stay unlocked during working hours.

### Kate Alterman

> **Who:** A worker who escaped the Triangle fire and told the jury how another worker, Margaret Schwartz, died at the locked door.
>
> **When and where:** New York City, March 25, 1911, and the trial in December 1911.

**With her coat turned inside out, she ran through the flames.**

Kate Alterman saw another worker, Margaret Schwartz, catch fire at the locked Washington Place door, and she told the jury what she saw. Margaret died in the fire. Kate worked on the ninth floor. She had lived in Philadelphia for nine years, and she had been in New York and worked at the Triangle factory for four months.

When the fire reached the ninth floor, the two women ran to the Washington Place door. The manager's brother, whose last name was Bernstein, tried it and could not open it. Margaret tried next. Then Kate pulled the handle "in and out, all ways," and it still would not open.

Kate saw Margaret kneel down by the door. She saw the hem of Margaret's dress and the ends of her loose hair start to burn. Margaret screamed, "Open the door! Fire! I am lost, there is fire!"

Kate turned her coat inside out and put it over her head with the fur against her face. She covered her head with a bunch of dresses. Then she ran out through the flames. "The whole door was a flame right to the roof," she said.

**In court.** At the trial the prosecutor, Charles Bostwick, used her account to show that the locked door caused Margaret Schwartz's death. The owners' lawyer, Max Steuer, made her tell the story again and again. She used almost the same words each time. In this way Steuer made her story seem less believable without ever saying she was lying. She said she told it the same way "because he asked me the very same story over and over."

**By the end of 1911:** Thousands had died in Galveston and San Francisco, a jury had found the Triangle owners not guilty, and New York lawmakers were writing new rules for the state's factories.

### Ships: the Titanic, 1912, and the Eastland, 1915

The *Titanic* carried lifeboats for only some of the people on board, and United States senators blamed British officials for that. The *Titanic* was a British passenger ship. It hit an iceberg in the North Atlantic and sank on April 15, 1912. More than 1,500 passengers and crew died. The ship *Carpathia* picked up about 710 survivors.

The ship had too few lifeboats for everyone, but it met the rules of the British Board of Trade, the government office in charge of British ships. Senator William Alden Smith of Michigan led a Senate investigation. It began in New York on April 19, four days after the sinking. The senators found that Captain Edward Smith's "indifference to danger" was one of the direct causes of the deaths. They blamed the Board of Trade's officials for the missing lifeboats.

The senators called for ships to slow down near ice, to carry enough lifeboats for all on board, and to keep a radio operator on duty day and night. In March 1915, after the *Titanic* sinking, members of Congress passed the Seamen's Act, pushed by Senator Robert La Follette of Wisconsin.

**The *Eastland*.** The Great Lakes passenger ship *Eastland* rolled over on July 24, 1915, while it was tied to a dock in the Chicago River. It was taking workers of the Western Electric Company and their families to a company picnic in Indiana, and it had already filled to its limit of 2,500 passengers.

The ship had tipped badly before, including in 1906. Under the new law, its owners had added a full set of lifeboats so it could carry more people. That added weight may have made the ship more dangerous. At 7:28 a.m. it rolled onto its side and settled on the river bottom, only 20 feet down. In all, 844 people died. Many of the dead were immigrants, and 220 of them were Czech.

A deckhand, Peter Boyle, drowned while saving people. A nurse, Helen Repa, led much of the rescue work on shore. An Illinois grand jury, a group of citizens who decide whether there is enough evidence for a trial, charged the president of the steamship company and three other company officers with manslaughter. It charged the captain and the engineer with criminal carelessness.

**No trial.** The men were outside Illinois, and a federal court refused to send them there for trial. The court found "barely a scintilla of proof," meaning almost no evidence, because the four company officers had not been on the ship. None of the men was ever tried in Illinois.

### Who was helped first in the 1927 flood?

About 637,000 people had to leave their homes in the Mississippi River flood of 1927. In the relief camps, local leaders gave supplies to white people first and forced Black people to work. In the spring the river broke through its levees, walls of earth built along a riverbank to hold the water in, in at least 145 places. Water covered 27,000 square miles, as deep as 30 feet. About 500 people died.

**The dynamite.** A group of New Orleans bankers arranged to set off about 30 tons of dynamite on the levee at Caernarvon, Louisiana, below their city, on April 29. They wanted to let the river out there to keep it from badly damaging New Orleans. The water flooded St. Bernard Parish and part of Plaquemines Parish, as Louisiana calls its counties. Blowing up the levee turned out to be unnecessary. The New Orleans businessmen never paid the people whose homes and land they flooded.

**In the camps.** About 325,000 people lived in relief camps, and 69 percent of them were Black. Near Greenville, Mississippi, more than 13,000 people escaped to the top of a levee that had held. Many of them were stranded there for days without food or clean water.

Local leaders from the countryside ran many of the camps. They gave supplies and boats to white people first, and Black people got what was left. A Black person got supplies only by giving the name of a white employer. Black people in the camps were forced to work and were not allowed to leave. The records do not name the camp leaders who gave these orders.

A white police officer ordered a Black man at gunpoint to unload a relief boat. The man refused, and the officer shot and killed him. The records do not give the name of the man who was killed.

Near Helena, Arkansas, a plantation overseer, the man who bossed the workers, tried to force a Black man, Owen Flemming, to rescue the plantation owner's mules. Flemming killed the overseer. Then he was lynched, which means he was killed by a mob without a trial. The records do not name the men who killed him.

Herbert Hoover, the Secretary of Commerce, led the national government's relief work. A group of Black leaders headed by Robert Russa Moton studied the camps and reported what was happening in them. Hoover asked that their reports be kept out of the newspapers, and they were. After the flood, members of Congress passed the Flood Control Act of 1928.

### Two disasters of 1928: the St. Francis Dam and Lake Okeechobee

The St. Francis Dam in northern Los Angeles County broke just before midnight on March 12, 1928. That same day its builder had looked at a new leak and judged it safe.

William Mulholland was the chief engineer of the city's Bureau of Water Works and Supply. His workers had built the dam from 1924 to 1926. Leaks and cracks showed up in 1927 and 1928. That morning the dam keeper, Tony Harnischfeger, found a new leak. Mulholland and his assistant, Harvey Van Norman, looked at it and decided it was not dangerous.

The dam gave way at about 11:57 that night. Harnischfeger and his family were probably among the first people killed. The flood ran 54 miles to the Pacific Ocean and killed at least 431 people. Among them were 84 workers of the Southern California Edison company at a construction camp beside the river.

At the investigation afterward, the *Express* newspaper reported that Mulholland said, "the only ones I envy are those who are dead." The *Los Angeles Times* printed his words as "on an occasion like this I envy the dead."

**The jury's finding.** A coroner's jury, a group of citizens who decide how people died, ruled on the collapse on April 12, 1928. The jurors found an error in engineering judgment about the rock under the dam, and they put that blame on Mulholland's bureau and its chief engineer. They found a second error, in the rules meant to keep the public safe. They put that blame on the people the chief engineer answered to: the city's water and power commissioners, the lawmakers of the city and the state, and the public.

The jurors wrote that a great dam should never be left "to the sole judgment of one man, no matter how eminent," meaning no matter how famous and respected. They found no crime and recommended that no one be charged. Mulholland's career as chief engineer ended after the dam broke.

**Lake Okeechobee.** Six months later, early on September 17, 1928, a hurricane came ashore near West Palm Beach, Florida. It had already killed 312 people in Puerto Rico. The storm pushed the water of Lake Okeechobee over the low dike, a bank of earth built to keep water back, at the lake's south end. Floods more than 20 feet deep covered the farm towns of Belle Glade, Canal Point, Chosen, Pahokee and South Bay.

At least 2,500 people died in the United States. For many years the official count was the Red Cross estimate of 1,836. About three out of four of the dead were migrant farm workers, people who moved from farm to farm to pick crops. Most of them were Black.

Black workers did most of the cleanup after the storm. Officials saved the few coffins they had for the bodies of white people. White victims were buried with a service, in a shared grave at Woodlawn Cemetery in West Palm Beach. The bodies of Black victims were burned in piles or thrown into mass graves. One mass grave at Port Mayaca holds 1,600 bodies. The records do not name the officials who made these decisions.

Robert Hazard of West Palm Beach started a group to win recognition for the Black victims buried in the city's mass grave. The city bought the grave site back in 2000. In 2003 a state historical marker was put up there.

**By 1929:** The Mississippi flood had driven about 637,000 people from their homes, the St. Francis Dam and the Okeechobee hurricane had killed thousands more in 1928, and members of Congress had passed the Flood Control Act of 1928.

### Black Sunday, April 14, 1935

A wall of blowing dirt swept across the southern Great Plains on April 14, 1935, with winds of up to 60 miles an hour. It reached Beaver, Oklahoma, at about 4 p.m. and Boise City, Oklahoma, at about 5:15 p.m. For a short time the sky was so black that people could not see their own hands in front of their faces. The day became known as Black Sunday.

An Associated Press reporter, Robert Geiger, and a photographer, Harry Eisenhard, were caught in the storm six miles from Boise City. The next day Geiger wrote a news story that began, "Residents of the southwestern dust bowl marked up another black duster today." A duster was a dust storm. His story is generally accepted as the first use of the words "dust bowl."

### Why natural gas smells: New London, 1937

A gas explosion destroyed a school in New London, Texas, on March 18, 1937, and killed about 298 people, most of them children. Members of the school board had piped in the gas to save money. Early that year, board members canceled the school's contract for natural gas. They had plumbers connect the school to a pipe of leftover waste gas from a nearby company, the Parade Gasoline Company.

Natural gas that has not been treated has no smell and no color. Gas leaked from the new connection and built up in the closed crawlspace, the low space under the floor, which ran the whole 253-foot length of the building's front. Students had been complaining of headaches for some time, but few people paid attention.

About 500 students and 40 teachers were in the building that afternoon. At 3:17 p.m. Lemmie R. Butler, who taught shop, turned on an electric sander. A spark from its switch probably set off the gas. The *Handbook of Texas*, published by the Texas State Historical Association, records about 298 dead. Other counts run from 294 to more than 400, and the exact number is not known.

More than 70 lawsuits were filed. Judge Robert T. Brown dismissed the ones that came to trial, for lack of evidence, and no one was ever found responsible. The school superintendent, W. C. Shaw, whose son was killed, resigned. Texas lawmakers gave the state's Railroad Commission the power to require a chemical with a strong smell in natural gas, so that people can smell a leak. Within weeks of the explosion, that chemical was being mixed into the gas.

### The Hindenburg, 1937, and the Cocoanut Grove, 1942

The German passenger airship *Hindenburg* caught fire on May 6, 1937, as it came in to land at the Naval Air Station in Lakehurst, New Jersey. An airship is a giant aircraft held up by a gas lighter than air, with engines to push it and a cabin for passengers. The *Hindenburg* was filled with hydrogen, a gas that burns very easily. Of the 97 people on board, 35 died. A man working on the ground, Allen Hagaman, died too.

Cameramen from four newsreel companies, which made short news films shown in movie theaters, were filming the landing and filmed the fire. None of them caught the moment the fire started. The radio reporter Herbert Morrison recorded what he saw as it happened. What caused the first spark has never been settled. Passenger travel by giant airship ended after the fire.

**The Cocoanut Grove.** Fire spread through the Cocoanut Grove nightclub in Boston at about 10:15 p.m. on November 28, 1942, and killed 492 people. Many of them were trapped behind doors that were locked, hidden or blocked. More than 1,000 people were inside a club that was allowed to hold 460. The owner, Barnett Welansky, had locked some exits, hidden others behind curtains, and bricked one up.

The main entrance was a single revolving door. Bodies piled up on both sides of it and jammed it until it broke. Other doors opened inward, so people could not open them against the crush of the crowd. Fire officials later told the court that if the doors had swung outward, at least 300 lives could have been saved. How the fire started is not known.

Welansky was found guilty of manslaughter and spent nearly four years in prison. Lawmakers then passed new laws that banned decorations that burn easily. The laws required emergency exits to stay unlocked, and a revolving door could no longer be a building's only exit.

### Explosions at the docks: Port Chicago, 1944, and Texas City, 1947

Two ships being loaded with ammunition blew up at the Port Chicago Naval Magazine in California, a Navy base for storing explosives, on July 17, 1944. The blast killed 320 men, and 202 of them were Black sailors. Navy officers had given Black sailors the job of loading the ships without enough training or equipment.

**Texas City.** A fire broke out in the cargo of the French ship *Grandcamp* at the docks of Texas City, Texas, on the morning of April 16, 1947. The ship carried about 2,300 tons of ammonium nitrate, a chemical used as fertilizer that can explode.

The ship's captain ordered his crew not to use water on the fire, so that the cargo would not be ruined. The crew closed the hatches and pumped in steam. The unusual smoke drew a crowd of about 500 people to the shore to watch, many of them children.

At 9:12 a.m. the ship exploded. Flying pieces of metal set fire to oil refineries and chemical tanks along the waterfront. The Monsanto chemical plant beside the ship took the worst of the blast, and seven broken oil tanks at the Republic Refinery caught fire. Another ship, the *High Flyer*, which carried 961 tons of ammonium nitrate, blew up at 1:10 the next morning.

At least 581 people died. The first explosion killed 26 of the town's volunteer firefighters, all but one member of the fire department, and destroyed all of the city's firefighting equipment. The anchor monument in Texas City lists 576 people known to have died. Sixty-three of them were buried without names.

More than 8,000 people sued the United States government. They used a 1946 law that let people sue the government for harm caused by the carelessness of its workers. In 1953 the justices of the Supreme Court ruled against them, 4 to 3. In 1955 members of Congress voted to pay the claims anyway. The government paid 1,394 awards, worth nearly 17 million dollars in all.

**If you remember one thing:** People's choices turned fires, floods and gas leaks into mass deaths in these fifty years, and of all the owners and officials blamed, one went to prison: Barnett Welansky, who locked the Cocoanut Grove's exits.

In 1900: Galveston had no seawall, and natural gas had no smell to warn anyone of a leak.

In 1950: Galveston stood behind a seawall 17 feet high, Texas officials could require a strong smell in natural gas, and a revolving door could no longer be a building's only exit.

**Next:** After 1950 forecasters began giving hurricanes names, and a president put most of the national government's disaster work under one office.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 17 minutes**

Hurricane Audrey killed at least 416 people on the Louisiana coast in June 1957. Warnings got faster after 1950, and help got organized. Weather Bureau forecasters began giving hurricanes human names in 1953. In 1979 President Jimmy Carter put much of the national government's disaster work under one new office, the Federal Emergency Management Agency, called FEMA.

Choices made by owners and engineers still killed hundreds of people. A coal company's waste dam in West Virginia broke in 1972 and killed 125. Two hotel walkways in Kansas City fell in 1981 and killed 114, after an engineer approved a design change without checking the math. News reporters broadcast a rescue from a frozen river in Washington, D.C., live as it happened. After Hurricane Andrew in 1992, Florida got a single building code, a set of rules for how strong buildings must be.

### Hurricanes with names: Audrey, 1957, and Camille, 1969

By the time Hurricane Audrey struck in 1957, hurricanes had names. In 1953 forecasters of the U.S. Weather Bureau began giving human names to storms. In 1956 Weather Bureau officials opened a hurricane center in Miami.

Forecasters warned the whole Louisiana coast at 10 a.m. on June 26, 1957, that a hurricane was coming. About 75,000 people left. Audrey came ashore the next day near Cameron, about 24 hours after the warning. The storm had sped up and arrived sooner than forecasters or residents expected.

Its storm surge, the wall of seawater that a hurricane's winds push onto land, rose as high as 12 feet. The water did damage as far as 25 miles inland. At least 416 people died, most of them in Cameron Parish. The final count may never be known.

**Camille.** Hurricane Camille came ashore near Bay St. Louis, Mississippi, late on August 17, 1969, with winds of 175 miles an hour. The water rose 24.6 feet at Pass Christian, Mississippi. Camille killed 172 people in Mississippi and 9 in Louisiana. As the storm moved north, its rain caused floods in Virginia that killed more than 153 people there. At least 343 people died in all.

### The Alaska earthquake, March 27, 1964

The strongest earthquake ever recorded in North America struck southern Alaska at 5:36 p.m. on March 27, 1964. Most of the people it killed drowned in the giant waves it caused. The earthquake had a magnitude of 9.2 and lasted four minutes and 38 seconds.

The shaking and underwater landslides sent tsunamis, giant waves set off by an earthquake or a landslide under the sea, into the coast. Scientists of the U.S. Geological Survey count 131 dead: 122 killed by the tsunamis and 9 by the shaking. Other counts reach 139. At Valdez, 32 people died when the town's harbor and docks collapsed. Tsunamis also reached Oregon and California. In Crescent City, California, one killed 10 people.

**Chenega.** Chenega was a village of Chugach Alutiiq people, also called Sugpiaq, on an island in Prince William Sound. Their people had lived there since before Russians came to Alaska. About four minutes after the shaking began, a wave 27 feet high struck the village. It knocked down every building except the school and one house.

Between 23 and 26 of the roughly 70 people who lived there died, by different counts. Scientists of the Geological Survey found that Chenega lost a larger share of its people than any other town. The survivors outran the wave and climbed to high ground.

Rescuers took the survivors to Cordova. Officials of the federal Bureau of Indian Affairs later moved them for good to the village of Tatitlek. In 1971 members of Congress passed the Alaska Native Claims Settlement Act. Under it, Alaska Natives received 44 million acres and $962.5 million, held by companies that Alaska Natives own. Former Chenega residents formed one of them, the Chenega Corporation, and won the right to choose 76,093 acres of land. People began living in a new village, Chenega Bay, in 1984.

President Lyndon Johnson declared all of Alaska a disaster area the day after the earthquake. Army engineers of the U.S. Army Corps of Engineers led the work of rebuilding roads, clearing wreckage and laying out new town sites, at a cost of 110 million dollars. The people of Valdez moved their town to higher ground four miles to the west. In 1967 federal scientists of the Coast and Geodetic Survey opened a tsunami warning center at Palmer, Alaska.

### Floods of 1972: Buffalo Creek and Rapid City

The Pittston Company's coal waste dam above Buffalo Creek, West Virginia, broke at about 8 a.m. on February 26, 1972, and the flood killed 125 people. The Buffalo Mining Company, part of Pittston, owned and ran three dams made of coal waste on the creek's Middle Fork.

The third dam sat on a layer of soft coal mud instead of solid rock. Neither Pittston nor the mine's earlier owner had sent the dams' plans to the state for approval. Four days before the flood, a federal mine inspector called the dam "satisfactory."

The dam gave way and let out 132 million gallons of water, coal waste and mud. The flood ran down the narrow valley through 16 coal towns. It killed whole families, injured about 1,000 people, and destroyed 507 houses and 44 mobile homes. About 4,000 of the 5,000 people who lived along the creek lost their homes.

**"An act of God."** Pittston officials blamed three days of rain and called the flood "an act of God," meaning a natural event that no person could have prevented. Members of the governor's commission that investigated wrote that "the Pittston Company, through its officials, has shown flagrant disregard for the safety of residents of Buffalo Creek," meaning that its officials had openly ignored the residents' safety.

Members of a separate commission formed by citizens said the company was guilty of murdering at least 124 people. The records show no Pittston official charged with a crime.

Pittston paid 13.5 million dollars in 1974 to settle a lawsuit by survivors and family members. One count gives 645 of them, and another gives 625. That came to about 13,000 dollars each after the lawyers were paid. Governor Moore settled the state's own lawsuit in 1977 for 1 million dollars. Members of Congress and West Virginia lawmakers passed new laws on how such dams must be built and kept up.

**Rapid City.** Less than four months later, on June 9 and 10, 1972, about 15 inches of rain fell on part of the Black Hills of South Dakota. Rapid Creek flooded Rapid City, where people had built houses and businesses on the creek's flood plain, the low land beside a river that the river covers when it floods. The flood killed 238 people. Afterward, new zoning rules set what could be built where, and most of the flood plain was rebuilt as parks.

### FEMA and Three Mile Island, 1979

President Jimmy Carter put much of the national government's disaster work under one new office in 1979, the Federal Emergency Management Agency, or FEMA. Before then, officials of more than 100 separate federal offices could each claim a part in the response to a single disaster. On April 1, 1979, Carter signed two executive orders, written orders from the president, that started FEMA. In July he signed another order that moved disaster relief into it.

Members of Congress passed the Stafford Act in 1988. It set the rules for when a president may declare a disaster, so that federal money and help can be sent.

**Three Mile Island.** Four days before FEMA started, the worst accident in the history of the country's nuclear power plants began at Three Mile Island, near Harrisburg, Pennsylvania. A nuclear reactor makes heat from uranium fuel in its core, and water must keep flowing around the core to cool it.

At 4 a.m. on March 28, 1979, a small fault in the cooling system of the Unit 2 reactor set off a chain of failures. A relief valve stuck open and let cooling water escape. The operators had no instrument that showed them the valve was open. They thought the system held too much water, so they cut the flow of new water. The core overheated, and at least 45 percent of it melted.

The operators at the plant, officials of Metropolitan Edison, the power company that ran it, and state and federal officials gave the public unclear and conflicting reports. Station manager Gary Miller declared an emergency at the plant. Federal nuclear officials had no power to order people to leave.

On March 30, Governor Richard Thornburgh advised pregnant women and small children within five miles to leave. He told people within ten miles to stay indoors. About 140,000 people left on their own. In at least 12 studies since 1981, scientists have found no deaths and no health harm that can be measured from the radiation that escaped. A commission of 12 members, led by John G. Kemeny, reported on the accident on October 31, 1979.

### Mount St. Helens, 1980, and the Hyatt Regency walkways, 1981

Mount St. Helens, a volcano in Washington State, blew out its north side at 8:32 a.m. on May 18, 1980, and killed about 57 people. An earthquake loosened the side of the mountain, and the whole weakened north face slid away. Hot gas and shattered rock blasted north toward Spirit Lake. The blast turned hundreds of square miles into wasteland. Most of the people who died were suffocated, and a few died of burns.

Among the dead were Harry R. Truman, who owned a lodge at Spirit Lake, the photographers Reid Blackburn and Robert Landsburg, and David Johnston, a volcano scientist of the U.S. Geological Survey. Johnston was on duty at a lookout post about six miles north of the mountain.

**The walkways.** Two walkways fell onto a crowd in the lobby of the Hyatt Regency Hotel in Kansas City, Missouri, on the evening of Friday, July 17, 1981. Engineering mistakes caused the fall. About 1,600 people had come to a dance in the lobby. The two walkways hung over the lobby. They killed 114 people and injured 216.

Engineers at Jack D. Gillum and Associates, the firm of the engineer Jack D. Gillum, designed the walkways. Their first design was already too weak. It could hold only 60 percent of the weight that Kansas City's building code required.

Then the makers of the steel parts, at a company called Havens Steel, proposed a change in how the walkways hung. The engineer Daniel M. Duncan accepted the change in a phone call without doing the math to check it. The change doubled the load on the walkway beams on the fourth floor. Investigators found that the walkways would have failed under one third of the weight they held that night.

Members of a Missouri state board found the engineers to blame for gross negligence, which means a serious failure to take the care their job required. They also found them guilty of misconduct and unprofessional conduct, meaning they had broken the rules of their profession. Gillum's company lost its engineering licenses in Missouri, Kansas and Texas. The engineers were cleared of the crimes they were first charged with, and no one was convicted of a crime.

### Air Florida Flight 90, January 13, 1982

Air Florida Flight 90 took off from Washington National Airport on the snowy afternoon of January 13, 1982, with snow and ice on its wings. It crashed into the Potomac River. The captain, Larry Wheaton, 34, and the first officer, Roger Pettit, 31, had not turned on the engines' ice protection. The jet hit the 14th Street Bridge, struck seven cars with people in them, and fell through the ice of the river. Of the 79 people on the plane, 74 died. Four drivers on the bridge died too.

**In the water.** Six people held on to the wreck in water of about 34 degrees. The rescuers who reached the riverbank had no equipment that could reach them. Roger Olian, the boss of the sheet-metal workers at St. Elizabeths Hospital, was the first to jump into the water to try. A U.S. Park Police helicopter arrived at about 4:20 p.m. and pulled most of the survivors out.

One passenger, Arland D. Williams Jr., 46, was a bank examiner, a person who checks that banks follow the rules. He was strapped into the wreckage and could not free himself. Twice he passed the rescue line to others. When the helicopter crew came back for him, the wreckage had rolled and he was under the water. The coroner, the official who finds out how people died, found that he was the only passenger who drowned. The bridge span was later renamed for him.

The Carnegie Hero Fund, which gives medals for bravery, says that its staff could not firmly establish who the sixth person in the water was. The coroner and the renamed bridge name Williams.

A passenger, Priscilla Tirado, was badly hurt and blinded by jet fuel, and she was too weak to grab the line when the helicopter came back to her. Lenny Skutnik, an assistant at the Congressional Budget Office, took off his coat and boots, swam out in short sleeves and pulled her to shore. "Somebody had to go into the water," he told *Time* magazine. News reporters recorded the rescue and broadcast it live.

**The cause.** Investigators of the National Transportation Safety Board, the federal office that looks into crashes, found that the pilots caused the crash. The investigators blamed the pilots' failure to use the engines' ice protection and the pilots' decision to take off with snow or ice on the wings. The captain did not listen when the first officer told him the engine readings looked wrong. He did not stop the takeoff while there was still room on the runway. Both pilots died in the crash.

### Melvin Windsor

> **Who:** A U.S. Park Police officer who stood on a helicopter's skid over the frozen Potomac River to pull a survivor out.
>
> **When and where:** Washington, D.C., January 13, 1982.

**Patricia Felch had been in the frozen river for 30 minutes.**

Melvin E. "Gene" Windsor, 41, pulled the last survivor of Air Florida Flight 90 out of the Potomac. He did it standing on one of the helicopter's skids, the long metal bars it lands on, with no safety line. He had joined the Park Police in 1971, and by 1982 he was a rescue technician.

He flew with the chief pilot, Donald W. Usher, 31. Earlier that day Usher had decided that no routine flights would go up. At about 4:09 p.m. a radio call came in. They took off at 4:16 and reached the river at about 4:20. Usher steered by watching the highway below through the windows in the helicopter's floor.

The people holding on to the wreck were in water up to their shoulders and necks. Windsor dropped life jackets and lines to them while Usher flew so low that the skids went under the water.

**The last one out.** The last survivor out of the water was Patricia Felch. She had been in the river for 30 minutes. Windsor unbuckled his seat belt and stepped out onto the right skid, which was under the water. He grabbed her with one arm and held the back of her head with the other.

Of the passenger who twice passed the line to others, Windsor told *Time*: "In a mass casualty, you'll find people like him, but I've never seen one with that commitment." A mass casualty is an event in which many people are hurt or killed at once. Windsor, Usher, Skutnik and Olian each received the Carnegie Medal for bravery. Windsor served 22 years with the Park Police.

### Hurricane Hugo and the Loma Prieta earthquake, 1989

Hurricane Hugo hit two U.S. territories before it reached the mainland in September 1989. On St. Croix in the U.S. Virgin Islands, it damaged more than 90 percent of the buildings and killed three people. In Puerto Rico it killed eight people and left nearly 28,000 without homes. On September 22 it came ashore on Sullivan's Island, South Carolina. The storm surge reached 20.2 feet near McClellanville, and 13 people died in South Carolina.

**Loma Prieta.** An earthquake of magnitude 6.9 struck about 10 miles northeast of Santa Cruz, California, at 5:04 p.m. on October 17, 1989, and killed 63 people. A World Series baseball game was about to begin at Candlestick Park in San Francisco.

In Oakland, the upper deck of the Cypress Street Viaduct fell onto the lower deck, and 42 people were crushed to death in their cars. The viaduct was a two-level section of the Nimitz Freeway, a highway raised above the ground. A section of the San Francisco-Oakland Bay Bridge also fell, and a 23-year-old woman, Anamafi Moala, died there.

### Why help was slow after Hurricane Andrew, 1992

Hurricane Andrew struck Florida on August 24, 1992, and destroyed more than 63,500 houses. Help from the national government was slow to come. Andrew came ashore at Homestead with winds as high as 165 miles an hour. It damaged more than 124,000 other houses and wrecked 99 percent of the mobile homes in Homestead. It killed 44 people in Florida. Fifteen died in the storm itself and 29 from its effects afterward. In all, the storm left 65 people dead.

**"Where in the hell is the cavalry?"** Three days after the storm, Dade County's emergency management director, Kate Hale, went on national television. "Where in the hell is the cavalry on this one?" she asked. "They keep saying we're going to get supplies. For God's sake, where are they?" The cavalry were soldiers on horseback, and she meant the rescuers and supplies that had not come.

Many people criticized FEMA for the slow start. Some critics blamed Florida's governor, Lawton Chiles, instead. FEMA officials believed they could not act until he sent a formal request for federal help. By that account, he waited five days to send it.

Engineers who surveyed the damaged roofs found that concrete roof tiles had been glued to felt paper and shingles stapled on the wrong way. A single building code for the whole state of Florida was set up in 1998, and it took effect in 2002.

### Northridge, 1994, and the Chicago heat wave, 1995

The Northridge earthquake, magnitude 6.7, struck Los Angeles at 4:30 a.m. on January 17, 1994. The official count of the dead is 57, and other counts run from 60 to 72. Sixteen people died when the Northridge Meadows apartment building collapsed. Buildings with parking on the bottom floor held up poorly in the shaking.

**The heat wave.** A heat wave in Chicago in mid-July 1995 killed 739 more people in one week than usually die in a week. Most of the dead were poor, old people. Many had no air conditioning, or had it and could not afford to run it. Many kept their windows shut and would not sleep outside, because they were afraid of crime. Black residents were more likely to die than white residents.

City officials did not issue a heat emergency warning until the last day of the heat wave. The records do not say who made that choice. Few people used the city's five cooling centers.

The morgue run by the medical examiner, Edmund Donoghue, a doctor who examines the dead to find out how they died, could hold 300 bodies, and it filled. Refrigerated trucks were parked outside to hold the rest.

Donoghue said later that his office was not allowed to hold press conferences, and that Mayor Richard M. Daley was not told until the weekend. A later study counted 692 deaths above normal over the whole summer, from June 21 to August 10. That is fewer than the worst week's 739, because some of the people the heat killed would have died later that summer anyway, the study found. In August, 41 victims whose bodies no one claimed were buried together in one grave in Homewood, Illinois.

**If you remember one thing:** Warnings and federal help got faster after 1950, but the choices of owners and engineers still killed hundreds of people, and no one in these fifty years was convicted of a crime for those deaths.

**More than 100:** the number of federal offices that could each claim a part in the response to a single disaster before 1979. That year President Carter put most of that work under one office, FEMA.

**Next:** After 2000, people waited days for help in New Orleans and months for electricity in Puerto Rico, and fires started by power lines burned whole towns.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 20 minutes**

Ethel Freeman, 91, died in her wheelchair outside the New Orleans Convention Center in September 2005, waiting for a bus that police had said would come.

In the disasters after 2000, many of the dead were old or sick, like her, and many died in the days and months after the storm or the fire, waiting for help, for electricity or for a warning. Hurricane Katrina killed 1,392 people in 2005, by the National Hurricane Center's count as corrected in 2023. Most of them died in Louisiana, many of them in New Orleans, where floodwalls broke. Investigators found that the U.S. Army Corps of Engineers was responsible for those floodwalls.

After Hurricane Maria struck Puerto Rico in 2017, officials of the island's government counted 64 dead. In 2018 they raised the official count to 2,975, after a study of deaths in the months after the storm. Power lines owned by utility companies started deadly fires in California in 2018 and 2025 and in Hawaii in 2023. In late September 2026, members of Congress were still debating whether to keep FEMA.

### September 11, 2001, and the illnesses afterward

Three hundred forty-three members of the New York City Fire Department died in the attacks on the World Trade Center on September 11, 2001, and by 2026 more of its members had died from breathing the dust of the ruins.

That morning 19 hijackers from the group al-Qaeda took over four passenger jets by force. They flew two into the Twin Towers of the World Trade Center in New York City and one into the Pentagon, near Washington, D.C. On the fourth plane, United Airlines Flight 93, passengers and crew fought back, and it crashed into a field near Shanksville, Pennsylvania.

The attacks killed 2,977 people, not counting the 19 attackers. Seventy-one police and other law officers also died in New York.

**The dust.** For months afterward, firefighters, police officers, construction workers and volunteers dug through the ruins. They breathed dust of crushed concrete, glass fibers, asbestos, lead and mercury. Asbestos is a mineral whose tiny fibers lodge in the lungs and can cause cancer years later. Fires in the ruins burned for three months.

Many of the workers later got cancer or lung disease. In September 2026 leaders of the Fire Department reported that 453 more of its members had died of illnesses tied to the dust. That is more than the 343 it lost on the day of the attacks.

In December 2010 members of Congress passed the James Zadroga 9/11 Health and Compensation Act. President Barack Obama signed it on January 2, 2011. It set up the World Trade Center Health Program, which gives medical checkups and treatment to responders and survivors with illnesses tied to the attacks. Members of Congress renewed it in December 2015.

### Hurricane Katrina, August 29, 2005

Most of the people Hurricane Katrina killed died in Louisiana, where New Orleans flooded after its floodwalls broke. On August 28, 2005, Mayor Ray Nagin ordered the first mandatory evacuation in the city's history, meaning everyone was ordered to leave. Governor Kathleen Blanco opened all lanes of the highways to traffic leaving the city, and about one million people left. Between 100,000 and 150,000 people stayed in the city. City officials opened the Superdome stadium as a "refuge of last resort," a place to go when there was nowhere else.

Katrina came ashore on August 29. The levees and floodwalls broke in more than 50 places, and water covered 80 percent of the city. In the Lower Ninth Ward, a neighborhood where most homeowners were Black, the water was more than 10 feet deep.

**Who built the floodwalls.** Members of Congress had put the Corps of Engineers in charge of the city's flood protection in a law of 1965. Investigators found that the Corps was responsible for the floodwalls that broke, and that the flood protection system the national government built had engineering flaws. Judges of a federal appeals court later ruled that, under a law of 1928, the Corps could not be made to pay for the damage.

Scientists at the National Hurricane Center lowered their count of the dead from 1,833 to 1,392 in 2023, after new studies. Other studies found that most of the dead in New Orleans were old people who lived near the broken levees, in the Lower Ninth Ward and Lakeview neighborhoods.

**Waiting.** Coast Guard crews rescued more than 33,500 of the roughly 60,000 people stranded in the city. People waited for days at the Convention Center, which had no food, water or medical help. Early news reports of mass crime at the Superdome later turned out to be false or exaggerated.

Federal officials did not begin to act in earnest to help the people at the Convention Center until September 2. Michael Brown, the head of FEMA, lost charge of the relief work to Vice Admiral Thad Allen and resigned on September 12.

**Guns on the bridges.** Some police officers turned their guns on survivors. On September 1, police from the city of Gretna and from the Crescent City Connection bridge police, with deputies of the Jefferson Parish sheriff, blocked the bridge over the Mississippi River. They turned back people walking out of New Orleans at gunpoint. Gretna's police chief, Arthur Lawson, made that decision with the sheriff's office and the bridge police.

On September 4, New Orleans police officers shot six unarmed Black people on the Danziger Bridge. They killed James Brissette, 17, and Ronald Madison, 40, a man with a mental disability. Madison was shot seven times, five times in the back. Among the officers were Kenneth Bowen, Robert Gisevius, Anthony Villavaso and Robert Faulcon. Police officers then tried to cover up the killings. In 2016 five former officers pleaded guilty and were sentenced to between 3 and 12 years in prison.

**Memorial Medical Center.** Patients, visitors and workers were trapped in Memorial Medical Center, a New Orleans hospital, during the flood. After the storm, 45 bodies were found there. In July 2006, the office of Charles Foti, Louisiana's attorney general and top lawyer, finished an investigation of nearly a year. A judge then ordered the arrest of a doctor, Anna Pou, and two nurses, Lori Budo and Cheri Landry, for murder, which Louisiana law called second degree murder.

They were accused of giving deadly doses of morphine and midazolam to four patients: Emmett Everett Sr., 61, Hollis Alford, 66, Ireatha Watson, 89, and Rose Savoie, 90. Morphine is a strong painkiller, and midazolam is a drug that makes people calm and sleepy. In large doses, both slow and then stop a person's breathing. In 2007 a grand jury refused to charge any of the three. The state later paid Pou's legal bills of more than 450,000 dollars.

### Herbert Freeman Jr.

> **Who:** A New Orleans man who took his 91-year-old mother, Ethel Freeman, out of their flooded home by boat, then stayed beside her body outside the Convention Center after she died waiting for help.
>
> **When and where:** New Orleans, August 31 to early September 2005.

**He borrowed a friend's boat to get his mother out.**

Herbert Freeman Jr. rescued his mother from their flooded house, and she died the next day outside the New Orleans Convention Center, where police had sent them to wait for a bus. Ethel Mayo Freeman was 91. She had a pacemaker for her heart and a feeding tube, and she used a wheelchair. She was often sick, and she decided to stay home when Katrina came.

The floodwater filled her house several feet deep. On August 31, Herbert, 58, borrowed a friend's boat. He put his mother in her wheelchair, lifted her into the boat and took her to dry ground. New Orleans police officers there sent them to the Convention Center. Herbert told officers his mother needed a doctor. They told him a bus would come.

**At the Convention Center.** The Convention Center had no food, no water, no medical help and no way out. "She was calling out for a doctor or a nurse, but there was nothing there," Herbert said. Ethel Freeman died at the Convention Center on September 1. Her body stayed outside for days, slumped in the chair and covered with a poncho. Pictures of it were shown on national television.

Herbert watched over his mother's body for nearly four days, until he was ordered onto a bus. The NBC News report of his story does not say who gave the order. Before he left, he put a note with his name and phone number in her pocket. It took him seven weeks to find her body, at a morgue in St. Gabriel, Louisiana. Her funeral was held in New Orleans in November 2005.

He and the families of two other people who died sued the national government. In 2009 federal appeals judges ruled that, under the Stafford Act, the government could not be sued over decisions like these in a disaster, and they threw out the case.

### How many died after Hurricane Maria, 2017?

Hurricane Maria left all 3.4 million people in Puerto Rico without electricity on September 20, 2017, and thousands died in the months that followed. Puerto Rico is a U.S. territory, and its people are U.S. citizens. Maria struck two weeks after Hurricane Irma crossed the region. It caused the worst blackout in U.S. history. Some customers did not get their power back until August 2018, 11 months later.

After Irma, FEMA officials had shipped many of the supplies they kept in Puerto Rico to the U.S. Virgin Islands. After Maria, they admitted to failures in moving supplies, too few staff and poor communication.

The mayor of San Juan, Carmen Yulín Cruz, spoke of the national government's relief work on September 29, 2017: "We are dying and you are killing us with the inefficiency." On October 3, President Donald Trump compared the count of dead at that time, 16, with "a real catastrophe like Katrina."

**How many died.** Officials of Governor Ricardo Rosselló's government counted 64 dead for months. Researchers found that many more people than usual died in the months after the storm. People who needed dialysis, a treatment that cleans the blood of people whose kidneys have failed, could not reach emergency care for long stretches of time.

Researchers at George Washington University estimated between 2,658 and 3,290 extra deaths from September 2017 to February 2018. On August 28, 2018, Rosselló's officials accepted their study and raised the official count to 2,975. A Harvard University study in 2018 estimated 4,645 extra deaths from September to December 2017, with a very wide range, from 793 to 8,498.

Trump wrote on Twitter on September 13, 2018, that "3000 people did not die" and blamed Democrats for the number. The official count of 2,975, based on the George Washington University study, has stood since August 28, 2018.

### Jesse Vazquez

> **Who:** A retired veteran in Bayamón, Puerto Rico, who lived for months without electricity after Hurricane Maria with his 89-year-old mother, Mercedes Mercado.
>
> **When and where:** Calle Alameda, Bayamón, Puerto Rico, September to December 2017.

**His children flew in from New York with a generator.**

Jesse Vazquez and his mother, Mercedes Mercado, went 96 days without electricity after Hurricane Maria. Maria cut the power to their house on Calle Alameda in Bayamón on September 20, 2017. For weeks the family ran electric fans and charged their phones from the battery of Jesse's car.

A small generator cost about 600 dollars on sale, more than Jesse could afford. In October his son, also named Jesse, and his daughter, Megan, flew in from New York to bring him a generator. "It's basically cheaper to buy a flight, get a generator and bring it down here," his son said. Running it five hours a day took about 80 dollars of gasoline a month.

Exhaust from a neighbor's generator blew into the family's living room. Megan said they needed a detector for carbon monoxide, a poison gas in engine exhaust that has no smell.

By Christmas the house had been without power for 96 days. Jesse and his mother used the generator to run the refrigerator, and fans at night so they could sleep. A FEMA inspector told Jesse he could not get help to fix his damaged roof. "It's kind of humiliating," he said. With his son's help he bought four solar panels. He and his mother decided to stay in Puerto Rico.

**By 2018:** Puerto Rico's officials had raised the count of Maria's dead from 64 to 2,975, and federal judges had thrown out the lawsuit that Herbert Freeman Jr. and two other Katrina families brought against the national government.

### Floods: Harvey, 2017, Helene, 2024, and the Texas Hill Country, 2025

Hurricane Harvey struck Texas in late August 2017 and dropped more rain than any other hurricane or tropical storm in U.S. records. Scientists at the National Hurricane Center recorded 60.58 inches near Nederland, Texas. Rescuers made more than 17,000 rescues. Their report records at least 68 people killed by the storm's direct effects in Texas and about 35 more by causes such as electric shock, car crashes and being cut off from medical care.

Hurricane Helene came ashore in Florida, near Perry, late on September 26, 2024. The next day its rain fell on North Carolina and Tennessee. Busick, North Carolina, got 30.78 inches of rain, and the rain set off more than 2,000 landslides. Scientists at the National Hurricane Center count at least 250 dead in the United States, 107 of them in North Carolina.

**The plastics factory.** In Erwin, Tennessee, six people died at the Impact Plastics factory as the Nolichucky River rose on September 27. The flood swept 11 people away, and five were rescued. A worker who survived and the families of the dead spoke out. They said the workers were not told they could leave until floodwater had covered the road to the plant and the power had gone out. Five employees and a contractor who cleaned the offices were killed.

Inspectors of Tennessee's workplace safety agency found in April 2025 that the company had "exercised reasonable diligence," meaning it had taken reasonable care, and that the deaths were not work-related. They issued no citations, which are official notices that a company broke a safety rule. District Attorney General Steven Finney filed no charges against the company's president, Gerald O'Connor, in July 2025, after a review by the Tennessee Bureau of Investigation.

The investigators said they found no evidence that workers were told they could not leave or that they would be fired for leaving, and that the workers had a little more than an hour to get out. The family of Johnny Peterson, one of the dead, sued the company.

**Camp Mystic.** As much as 20 inches of rain fell on the Texas Hill Country early on July 4, 2025, and the Guadalupe River rose about 26 feet in 45 minutes. The flood killed 136 people, 117 of them in Kerr County, by counts reported in July 2026. At Camp Mystic, a Christian summer camp for girls, 25 campers, two counselors, Chloe Childress and Katherine Ferruzzo, and the camp's owner and director, Dick Eastland, died.

The first flash flood warning for Kerr County went out at 1:14 a.m. At 4:03 a.m. a flash flood emergency, a more urgent alert, told people in the towns of Hunt and Ingram to "seek higher ground now!"

Kerr County had no warning system built just for floods. In 2016 the county sheriff had asked for one, with sirens. County Commissioner H. A. "Buster" Baldwin said, "I think this whole thing is a little extravagant for Kerr County, with sirens and such."

After appeals from the camp, FEMA officials took 15 of its buildings on the Guadalupe River off the federal map of land likely to flood in 2013. They took 15 buildings at a newer camp site off the map in 2019 and 2020, the Associated Press reported.

Texas lawmakers passed new camp safety laws in September 2025, at an extra meeting called a special session, among them the Heaven's 27 Camp Safety Act. On June 18, 2026, members of the Texas Senate and House investigating committees released a report. The lawmakers found that the camp had no written emergency plans, which state rules required. They also found that the camp's leaders did not move the campers out in time even though they had chances to.

By July 2026 Kerr County had six new sirens. In the week before July 18, when floods came to the Hill Country again, officials sounded three of them to warn people, an official of the Upper Guadalupe River Authority said.

### Fires started by power lines: Paradise, 2018, Lahaina, 2023, and Los Angeles, 2025

A single metal hook broke on a power line tower owned by Pacific Gas and Electric, called PG&E, on the morning of November 8, 2018. The tower was part of a line built in the early 1900s, and it was poorly maintained. The line started a fire. The Camp Fire burned through the town of Paradise, California. It killed 85 people and destroyed more than 18,000 buildings. On June 16, 2020, the company pleaded guilty in court to 84 counts of involuntary manslaughter, the crime of killing people through carelessness.

**Lahaina.** A wildfire destroyed the town of Lahaina on the island of Maui, Hawaii, on August 8, 2023, and killed 102 people. That is the most people killed in a U.S. wildfire since 1918. High winds knocked down power lines of Hawaiian Electric, and the lines started a fire that morning. Maui firefighters declared that fire under control and left. Less than an hour later, embers from it started the fire again.

Firefighters lost water pressure in the hydrants. Many people died in their cars. Some jumped into the ocean to escape the flames.

The fire destroyed a town that had been the capital of the Kingdom of Hawaii for 35 years. It burned the homes of many Native Hawaiian families who could afford to live in Lahaina only because they had inherited houses that were already paid for.

Maui has more than 80 outdoor warning sirens, and none of them sounded. Herman Andaya, the head of the Maui County Emergency Management Agency, said the sirens would have sent people toward the mountains and into the fire. He resigned the next day.

In an October 2024 report, federal fire investigators and the Maui Fire Department called the fire accidental, meaning no one set it on purpose. They found that the power lines brought down by the wind had started it, but they did not hold any person or company responsible.

Under a settlement of the survivors' lawsuits, Hawaiian Electric, Maui County and others agreed to pay 4 billion dollars. As of August 2026, none of that money had been paid, because of a court fight over the lawyers' fees, the *Honolulu Star-Advertiser* reported.

**Los Angeles.** Fires pushed by winds of up to 100 miles an hour burned parts of Los Angeles in January 2025. They killed at least 31 people and destroyed more than 18,000 homes and other buildings. The Eaton Fire in Altadena killed 19 people. In August 2026 Los Angeles County and state fire investigators reported that it started from electric sparks on an unused Southern California Edison tower.

Seventeen of the 19 died in west Altadena, a neighborhood with a long history as a Black community. Reviewers from the firm Citygate Associates found in May 2026 that county officials' orders to leave reached west Altadena hours after the fire turned toward it. The records do not name the officials who made those decisions. The dead had an average age of 77. California's attorney general, Rob Bonta, opened an investigation into whether race, age or disability affected how officials warned people.

The Palisades Fire killed 12 people. In October 2025 Jonathan Rinderknecht, 29, was arrested and charged with starting it. Prosecutors say he set a small fire on January 1, and that strong winds rekindled it, or started it burning again, on January 7 as the Palisades Fire. Firefighters had thought the January 1 fire was out. A Los Angeles Fire Department battalion commander ordered crews to leave that site, although they reported that the ground was still burning slowly.

His first trial ended in June 2026 when the jury could not agree: ten jurors voted not guilty and two voted guilty. Prosecutors charged him again with arson, the crime of setting a fire on purpose, and he pleaded not guilty. As of October 26, 2026, his second trial had not begun, and he had not been convicted of any crime.

### Cold, a collapse and FEMA's future: 2021 to 2026

A winter storm struck Texas in February 2021, and more than 4.5 million homes and businesses lost power, some of them for days. Officials of the Texas Department of State Health Services counted 246 deaths from the storm. Almost two-thirds of the dead died of hypothermia, which means the body gets so cold that it stops working. Some estimates run as high as 702 deaths. Cristian Pavón Pineda, 11, died of carbon monoxide poisoning in his family's mobile home in Conroe, Texas. The home had no power.

**Surfside.** Part of Champlain Towers South, a 12-story apartment building in Surfside, Florida, fell down at 1:22 a.m. on June 24, 2021, and killed 98 people. For years, water had seeped into the concrete and steel supports of the parking garage under the pool deck, and the steel had rusted.

Engineers of the firm Morabito Consultants reported the damage in 2018. They warned that if the waterproofing was not replaced soon, the damage to the concrete would spread fast. Each family owned its own apartment, and the owners together had a board. On April 9, 2021, Jean Wodnicki, the president of that board, wrote to the residents that "the concrete deterioration is accelerating," meaning the concrete was breaking down faster. A 15-million-dollar repair had been approved, but the main work had not started.

**What followed.** In June 2022 Judge Michael Hanzman approved a settlement of the lawsuits. The families of the dead and the people who were hurt shared nearly a billion dollars, paid by 20 defendants, the people and companies they had sued, among them insurance and engineering companies. None of the defendants admitted doing anything wrong. The apartment owners split about 96 million dollars from the sale of the land.

Florida lawmakers passed a law in May 2022. Under it, apartment buildings owned by their residents, three stories or taller, must have a safety inspection of their structure when they turn 30, or 25 if they stand within three miles of the coast, and every 10 years after. The owners must also set aside money for the repairs that a study says the building will need.

In June 2026 engineers of the National Institute of Standards and Technology, a federal science office, reported that the collapse began in early June 2021, when two connections between garage columns and the pool deck broke. They found that the original design strayed widely from the building rules of its time, and that the builders did not follow the drawings. Changes to the pool deck and years of rust weakened the building further.

**FEMA's future.** President Trump called for getting rid of FEMA. On February 17, 2025, officials of the Trump administration fired more than 200 FEMA workers. On March 24, 2025, Homeland Security Secretary Kristi Noem said she would move to eliminate FEMA. The acting head of FEMA, Cameron Hamilton, told members of Congress: "I do not believe it is in the best interest of the American people to eliminate the Federal Emergency Management Agency." He was removed from his job the next day.

More than 180 current and former FEMA workers signed a public statement of protest in August 2025 that they called the "Katrina Declaration." On May 7, 2026, a review council the president had set up approved a report with ten recommendations. On September 15, 2026, members of a House committee voted for one bill to change FEMA, the Post-Disaster Protection Act. In late September 2026, FEMA still existed, and members of Congress were still debating its future.

**If you remember one thing:** Since 2000 many of the dead were old or sick, and many died waiting: for a bus at the Convention Center, for electricity in Puerto Rico, for an order to leave west Altadena.

**Still open:** As of August 2026 none of Lahaina's 4 billion dollars had been paid, and in late September 2026 members of Congress were still debating whether to keep FEMA.

**Next:** The chapter closing is below. Chapter 28, Drugs and Alcohol, follows.

**The three questions, answered**

- What rules did Americans make after disasters, and did they work? Some worked, some failed and some are still being tested. Lawmakers and officials wrote new rules after many disasters, from Boston's fire wardens in 1711 to one building code for Florida after Hurricane Andrew. The rule to put a smell in natural gas after the New London school explosion was in use within weeks, but the 1838 steamboat law had no one to enforce it. In late September 2026 members of Congress were still debating FEMA's future.
- Was anyone punished when people's choices killed others? Rarely. No one was punished for the *Sultana*, the Johnstown club won in court, a jury found the Triangle owners not guilty, and no Pittston official was charged after Buffalo Creek. Barnett Welansky went to prison for the Cocoanut Grove fire, and PG&E pleaded guilty to 84 counts of involuntary manslaughter after the Camp Fire.
- Did everyone get the same help after a disaster? No. Officials paid out London's money for Charleston in 1740 by the size of each loss, so most of it went to rich merchants. Armed men forced Black workers to handle Galveston's dead in 1900, and camp leaders forced Black people to work in the 1927 flood. In 2005 police turned back people walking out of New Orleans at gunpoint, and in 2025 orders to leave reached west Altadena hours late.

**What changed:** Over ten eras, help after a disaster moved from neighbors and churches to public money and a national office, and warnings moved from church bells to the telegraph and sirens. After 2000, FEMA's help was slow at Katrina, its officials admitted failures after Maria, and none of Maui's sirens sounded in 2023.

**Five dates to keep**

- January 26, 1700: The Cascadia fault breaks, and its tsunami reaches Japan the next day.
- May 31, 1889: The South Fork Dam breaks, and 2,208 people die in Johnstown.
- September 8, 1900: A hurricane floods Galveston, the deadliest natural disaster in the country's history.
- March 25, 1911: The Triangle fire kills 146 workers in New York.
- August 29, 2005: Hurricane Katrina comes ashore, and New Orleans floods when its floodwalls break.

**Not known:** No one knows how many people died in the Galveston hurricane of 1900, and the estimates run from 6,000 to 12,000.

**Where to go:** Clara Barton's house in Glen Echo, Maryland, built partly from the lumber of the Red Cross buildings at Johnstown, is now the Clara Barton National Historic Site.

**Next:** Chapter 28, Drugs and Alcohol. It follows the drinks, tobacco and drugs Americans have used, and the laws they made to control them.
