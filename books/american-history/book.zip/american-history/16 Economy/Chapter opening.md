# Chapter 16: Economy

**Chapter 16 of 37 · Economy · 10 eras · about 80 minutes**

**Much of this country's wealth came from work that people were forced to do for little or no pay, and in crash after crash, the poorest families lost the most.**

The census of 1860 lists Mayer Lehman, a merchant in Montgomery, Alabama, as the owner of seven enslaved people. He and his brothers, Henry and Emanuel, took cotton grown by enslaved people as payment for the goods they sold, and then they began trading cotton. Their company, Lehman Brothers, failed on September 15, 2008, owing about 619 billion dollars. It was the largest bankruptcy, the court case of a company that cannot pay its debts, in the country's history.

This chapter follows how people here made a living, from Native trade before 1500 to the jobs of 2026. They made it first mostly by farming, then more and more in mines, mills and factories, and by 2026 mostly in services: stores, offices, hospitals and schools. Two things come back in era after era. One is who did the work and who kept the money: servants, enslaved people, convicts and sharecroppers did much of it for little or nothing. The other is the crash: the panics of 1819, 1837, 1857, 1873 and 1893, the Great Depression of the 1930s and the crash of 2008. In each one, watch who lost a job, a farm or a home.

**Four words for hard times.** In a panic, fear spreads, many people rush to take their money out of the banks at once, and businesses close. A crash is a sudden fall in prices, of stocks or of homes. A depression is the long stretch of hard times that can follow, lasting years. A recession is a shorter one, measured in months.

**Three questions this chapter answers**

- How did slavery make money for people far from any plantation?
- What happened to ordinary families when a boom turned into a crash?
- When did the national government start helping people who lost their jobs?

**Five minutes?** Read "The Panic of 1837" in 1800 to 1850.

**Can skip:** "Shell, copper and obsidian", "Parliament's molasses and iron laws", "Where the name Gilded Age comes from", "Why farmers joined the Grange". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 2 minutes**

Native people here traded without money. They had economies of their own, ways of making, sharing and trading the things they needed. Nobody had coins or wages, and nothing had a set market price. They traded by barter, swapping one good for another, and by giving gifts between people and between nations. Stone tools, shells and copper traveled hundreds of miles this way. No record names any one person who took part in this trade.

### How far did Cahokia's hoe blades travel?

The people of Cahokia controlled the making and trading of stone blades for hoes, farm tools for breaking up soil. Archaeologists, scientists who study the past from the things people left behind, have found these blades more than 400 miles away, from Louisiana to Minnesota and in the Arkansas River valley.

**The city.** Cahokia stood near what is now St. Louis. It was the largest city north of Mexico, and it was at its biggest from about 1050 to 1150. Its farmers grew more corn than they ate, and that surplus, the extra corn, fed specialists: people who spent most of their time on one kind of work, such as making tools, instead of growing food.

**The stone.** Workers chipped the blades from Mill Creek chert, a tough stone found only in southern Illinois. They dug it out of quarries, open pits for stone, and some of the pits were 10 to 20 feet deep.

### Shell, copper and obsidian

People carried the shells of whelks, large sea snails, north from the coast of the Gulf of Mexico. Traders moved copper from the land around Lake Superior. At Cahokia, workers made shell beads in large numbers, and families on small farms made them too.

In the West, people traded obsidian, a natural glass that forms in volcanoes, across their own trade networks. Archaeologists have traced pieces found in western Canada back to Obsidian Cliff, in what is now Wyoming, and Bear Gulch, in what is now Idaho. Some pieces had traveled as far as 750 miles from where the stone formed.

## The 1500s

**Era 2 of 10 · The 1500s · about 2 minutes**

Explorers found no gold or silver in the land that became the United States, though the kings and queens of Spain, France and England paid for their voyages in the 1500s to find it. The Spanish silver came from mines in Mexico and South America. Fishing was the first steady European business in these waters. Some ship crews traded with Native people on the coast, and some of that trade was for furs. Almost no Europeans settled here yet, so there was no colonial economy.

### Fish, furs and a rope from a cliff

European fishing crews worked the cod waters off the northeast coast all through the 1500s and dried their catch on shore.

**The rope.** Abenaki people on the coast of what is now Maine traded with the crew of Giovanni da Verrazzano's ship in 1524 from the top of a cliff. They would not let the crew come ashore, so they lowered baskets of goods to the ship on a rope.

Crews of earlier European ships had already taken Native people from the Maine coast to sell as slaves. That is why the Abenaki kept this crew off the land. Verrazzano called the place "the land of bad people." The records do not say whether the baskets held furs.

**Furs on sticks.** Mi'kmaq traders held up beaver furs on sticks to the crew of Jacques Cartier at Chaleur Bay, north of Maine in what is now Canada, in July 1534. They traded the furs for knives and other iron goods. Cartier wrote the trade down in his own account of the voyage, one of the earliest records of furs traded between Europeans and Native people on the Atlantic coast of North America. The fur trade reached the land that became the United States in the next century.

**St. Augustine.** The Spanish town of St. Augustine in Florida began in 1565 as a military post, and the Spanish king's government paid its costs. Unlike the English colonies that came later, it was not set up to make a profit.

## The 1600s

**Era 3 of 10 · The 1600s · about 7 minutes**

Tobacco became Virginia's main business in the 1600s. The planters who owned the fields changed who did the work. At first the field workers were indentured servants from England, people who had signed contracts to work for a master for a set number of years. Near 1700 the planters switched to buying enslaved Africans, whom they could hold for life. Farther north, Dutch traders shipped beaver skins to Europe, and lawmakers in London wrote rules that required colonists to ship their main crops only to England or its colonies.

### Tobacco in the Chesapeake

The first colonists at Jamestown hoped to find gold. John Smith wrote that there was "no talk, no hope, no work but dig gold, wash gold, refine gold, load gold." They found none. Colony officials tried glassmaking and other small businesses, and none of them made money.

**Tobacco.** Then Virginia's planters began to grow tobacco as a cash crop, a crop grown to sell rather than to eat. They shipped about 2,300 pounds of tobacco in 1615 and 1616, about 20,000 pounds by 1617, and about 1.5 million pounds by 1629 and 1630.

The trade kept growing. Planters in Virginia and Maryland, the two colonies around Chesapeake Bay called the Chesapeake colonies, together sent about 22 million pounds of tobacco a year to England by 1700. They also used tobacco as money.

### John Rolfe

> **Who:** A Jamestown colonist whose tobacco shipments to London began Virginia's trade in its main crop.
>
> **When and where:** Jamestown, Virginia, 1612 to 1614.

**Rolfe grew tobacco from West Indies seed and shipped it to London.**

John Rolfe began Virginia's export trade in tobacco, the business of sending it away to be sold in another place. He lived at Jamestown, the English colony in Virginia. By July 1612 he was growing tobacco from seed brought in from the West Indies, the islands of the Caribbean Sea. He sent his first shipments to London in 1614.

### Who worked the tobacco fields?

Indentured servants did the tobacco work for most of the 1600s. Each servant's contract was called an indenture. In return for the servant's years of work, the master paid for the trip across the ocean and gave food, clothing and a place to sleep.

**The terms.** Adults usually served four to seven years, and children sometimes served much longer. At the end of the term, the master owed the servant "freedom dues." Depending on the contract and the colony, these could be land, tools, clothes or farm animals.

**How many.** Of about 120,000 English people who moved to Virginia and Maryland in the 1600s, about 90,000 came as servants, three out of every four. These are historians' estimates from ship records and court records.

**The headright.** Planters gained from each servant in two ways. Under Virginia's headright rule, whoever paid for a person's passage, the cost of the ocean trip, received 50 acres of land for that person. So a planter who paid a servant's passage got the servant's years of work and 50 acres as well. The large tobacco planters built their estates, their large holdings of land, this way.

### What servants went through

Officers of the Virginia Company could hang, burn to death or shoot runaway servants they caught, under the company's first form of contract, used from 1609 to 1619. The Virginia Company of London, a group of investors in England, started Jamestown in 1607 and ran the colony until 1624. That year the king of England took the colony away from the company and put it under his own control.

**Whippings and added years.** Masters could whip their servants. When a servant ran away, judges in the colony's courts added years to the servant's term. They also added years when a woman servant had a child outside marriage. Under a Virginia law of March 1662, she served two more years or paid her master 2,000 pounds of tobacco.

**When the master was the father.** Some of the fathers were the masters themselves. Virginia's lawmakers wrote a second law in December 1662 about a woman servant "gott with child by her master," that is, made pregnant by him. When her years ran out, officers of the local church, called churchwardens, sold her to work two more years "for the good of the parish," the church district where she lived. Under this law the churchwardens sold the woman, not the master who was the father.

Some masters also forced women servants into sex. Julie Richter, a historian of colonial Virginia, writes that some masters "physically and sexually abused their servants." She gives no count of how many.

**The rules for masters.** A Virginia law required masters to give servants "Competent Dyet, Clothing & Lodging," which meant enough food, clothes and shelter. The same law required masters not to "exceed the Bounds of moderation in correcting them," which meant not to go too far in punishing them.

Many servants died of disease before their contracts ended. Most of those who lived to the end of their terms stayed poor.

### From servants to enslaved Africans

About 300 Africans lived in Virginia by 1650, next to about 4,000 white servants. In the 1660s, members of Virginia's assembly, the colony's lawmakers, passed the colony's first laws that treated Africans as slaves for life.

**The first law.** Under a law of March 1661, an English servant who ran away together with Africans had to serve extra time for the Africans' missing time as well as his own. Judges punished runaway servants by adding years to their terms. But the law's words said the Africans were "incapable of makeing satisfaction by addition of time." Judges could add no years to their time, because they were already held for life.

Servants and enslaved Africans fought on the same side in Bacon's Rebellion of 1676 and 1677, an armed uprising in Virginia. Nathaniel Bacon led colonists who wanted to kill or drive out every Native person in Virginia. When the governor, William Berkeley, tried to stop him, Bacon's men turned on the governor and burned Jamestown in September 1676.

The rebellion showed that poor white and Black people could unite, and the planters who ruled Virginia feared it would happen again. After it, the planters passed new laws. Historians at the College of Charleston describe the purpose of those laws as "to harden Virginia's racial caste system," a system that sorts people at birth into ranks they can never leave.

**The slave code.** Members of Virginia's assembly gathered the colony's slave laws into one slave code in 1705. Under it, enslaved people were property, and being baptized, going through the church ceremony that makes a person a Christian, did not free anyone. A master who killed an enslaved person while "correcting" them faced no punishment.

**The planters' choice.** Planters chose to buy enslaved Africans instead of servants near 1700. Fewer English servants were coming by then, because life in England had improved. In the same years the Atlantic slave trade grew, as ship crews carried captive Africans across the ocean to be sold.

The economist David Galenson, a scholar who studies how people make and spend money, explains the choice in money terms. A servant worked for a master for about five years. A planter who bought an enslaved person held that person, and that person's children, for life. So the planter got a whole lifetime of unpaid work, and the work of the children too, instead of five years.

### Beaver skins, and rules from London

One ship of the Dutch West India Company, the *Arms of Amsterdam*, carried 7,246 beaver skins to Amsterdam in a single cargo in 1626, along with the skins of otters, minks, lynxes and muskrats. A letter known as the Schaghen letter lists the cargo. People in Europe bought hats made of felt from beaver fur, and those buyers were the reason traders wanted the skins.

English leaders followed an idea called mercantilism, the belief that colonies existed to make the home country richer. Colonists were to send raw goods, such as tobacco, to England and buy back finished goods, things already made in England.

**The Navigation Acts.** Members of Parliament, England's lawmakers, wrote this idea into laws called the Navigation Acts. Under the act of 1651, colonists had to ship their trade goods only in English or colonial ships. The act of 1660 listed "enumerated goods," a phrase that means listed goods, and colonists could ship these only to England or to other English colonies. The list included tobacco, sugar, cotton, ginger and indigo, a plant used to make blue dye.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 6 minutes**

Much of the colonies' wealth, most of all in the South, came from the work of enslaved people, who were paid nothing. Free colonists were doing well. By 1774 they earned more on average than the people of England, the economic historians Peter Lindert and Jeffrey Williamson found. Among free colonists only, income was spread more evenly than in any other place the two could measure at that time. In the rice country of South Carolina, though, the wealth from rice stayed with a small group of white planters.

**Convicts for sale.** From 1718, British judges sent about 50,000 convicts across the ocean to be sold as laborers.

### What the colonies sold

Tobacco came from the Chesapeake colonies, wheat and flour from the middle colonies, such as Pennsylvania, New York and New Jersey, and fish, rum and ships from New England. In the Lowcountry of South Carolina, the low land along the coast, enslaved workers grew rice and indigo and prepared them for sale.

Timber cost little in the colonies, so colonial shipbuilders could build ships for less than builders in England. By the Revolution, about one-third of the British merchant fleet, all the ships that carried Britain's goods for trade, had been built in America.

### Rice, and the people who knew how to grow it

Enslaved Africans built and worked the rice fields of the South Carolina Lowcountry. Rice was the Lowcountry's main cash crop from the early 1700s. Enslaved Africans were a majority of the people in South Carolina from about 1708, and by 1740 they were about two out of every three.

Nic Butler of the Charleston County Public Library writes that enslaved people "moved earth on a massive scale" to build the rice fields. By the 1720s, Carolina planters were asking slave traders for Africans from the region called the Rice Coast, because people from there already knew how to grow rice. The wealth from rice, Butler writes, "remained concentrated in the hands of a small minority of white planters."

**The children.** Historians at the College of Charleston record that enslaved children in the Lowcountry died at especially high rates. Their account gives no count of those children's deaths in the early 1700s. The number of enslaved people there did not grow through births until the 1760s.

### Eliza Lucas Pinckney

> **Who:** A young woman who ran her father's three South Carolina plantations from the age of 16 and directed the colony's first successful indigo dye crop.
>
> **When and where:** South Carolina, 1744 to the 1750s.

**Her first crop, in 1744, made 17 pounds of blue dye.**

Eliza Lucas directed the first successful crop of indigo dye in South Carolina in 1744 and shared her seed with neighboring planters. From the age of 16 she had run her father's three plantations. She later married and became Eliza Lucas Pinckney.

**What followed.** South Carolina's indigo exports grew from about 5,000 pounds in 1745 and 1746 to about 130,000 pounds by 1748. By the middle of the 1750s, planters there shipped more than a million pounds a year. Indigo became the colony's second biggest export after rice, and by the Revolution it made up more than a third of the value of the colony's exports.

**Whose work.** Enslaved workers on her father's plantations did the growing. Her father sent skilled dye-makers from the Caribbean, and enslaved workers did the processing, the work of turning the plant into dye. She relied on their knowledge and their labor.

### Convicts sold at the dock, 1718 to 1775

British judges sent about 50,000 people convicted of crimes to the North American colonies between 1718 and 1775, and merchants sold them there as laborers. The convicts were about one in four of all the people who moved from Britain to colonial America in those years.

**The law.** Members of Parliament passed the Transportation Act in 1718. Transportation here meant sending convicts away across the ocean as a punishment. Under the act, a judge could send a person convicted of a felony, a serious crime, to the colonies instead of hanging them: for seven years for one of the less serious felonies, and for fourteen years for worse crimes.

**Sold at the dock.** Most convicts went to Maryland and Virginia. There, merchants sold them at the dock as bound laborers, people who had to work for whoever bought them until their term ended. In the records of four Maryland counties, about 82 of every 100 convicts were men and 18 were women. On two ships of 1721 and 1724, most convicts were between 20 and 29 years old, and about half were laborers with no trade.

**The money.** British government officials paid a London merchant named Jonathan Forward £3, three British pounds, for each convict he carried, and later £5. A Maryland firm, Stevenson, Randolph and Cheston, sold convicts in Maryland from 1767 to 1775. The firm's own sales books record that most men sold for £11 to £14 and most women for £9 to £10. The planters who bought them got years of work without paying wages.

Convicts died on the crossing. On 38 voyages from London between 1718 and 1736, the ships carried 3,599 convicts, and 385 of them died, about 11 of every 100. The historian A. Roger Ekirch points out that the records of some of these voyages list no deaths at all. If those blanks are gaps in the clerks' records, the true count was about 15 of every 100. On 12 voyages from Bristol in the 1770s, 23 of 990 convicts died.

### Rhode Island's slave ships

Merchants in Rhode Island sent out at least 1,000 slaving voyages in the century before 1807. That year members of Congress made a law that banned bringing captive Africans into the United States, starting on January 1, 1808. The Rhode Island ships carried more than 100,000 Africans into slavery.

About 60 of every 100 slaving voyages that left North America sailed from Rhode Island, and in some years more than 90 of every 100 did. These numbers come from *Slavery and Justice*, a 2006 report from Brown University.

**The loop.** The merchants who sent out these ships made their money by buying and selling human beings. Their crews sailed a loop around the Atlantic Ocean. Colonists made rum from Caribbean molasses, a thick, dark syrup left over when sugar is made.

Captains carried the rum and other goods to West Africa and traded them for captive people. Crews then carried the captives across the ocean, on the crossing called the Middle Passage, to be sold in the Caribbean and on the mainland. The ships brought sugar and molasses back north.

### Parliament's molasses and iron laws

Members of Parliament passed the Molasses Act in 1733. Under it, colonists had to pay a duty, a tax on goods brought in, on molasses from colonies that did not belong to Britain. The duty was sixpence, six British pennies, for each gallon. Many colonists dodged it by smuggling, bringing the molasses in secretly.

Under the Iron Act of 1750, raw iron from the colonies could enter Britain with no duty. The act forbade colonists to build new steel furnaces, rolling and slitting mills or plating forges, the works that turned raw iron into finished goods. Colonists built them anyway.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 6 minutes**

Americans paid for the Revolution with paper money and debt. In 1790 the new national government and the states still owed about 79 million dollars for the war, and Alexander Hamilton wrote the plan to pay those debts in full. Members of Congress taxed whiskey to help pay them, and in 1794 farmers in western Pennsylvania rose up against that tax. Both before and after the war, Rhode Island merchants sent ships to Africa to buy captive people.

### The Browns and the slave ship Sally

Four merchant brothers of Providence, Rhode Island, sent their ship *Sally* to West Africa to buy people in 1764. They were Nicholas, John, Joseph and Moses Brown. The ship carried 17,274 gallons of rum, along with chains, guns and shackles, metal rings locked around a person's wrists or ankles. By that year Rhode Island had about 30 rum distilleries, places where rum was made, and 22 of them were in Newport. The distillers made the rum from molasses shipped from the Caribbean.

**The voyage.** The captain, Esek Hopkins, bought 196 Africans, and at least 109 of them died, by the count in Brown University's report. Hopkins kept the ship on the African coast for more than nine months while he bought them. The captives died from disease and starvation, by killing themselves, and in an uprising.

Nineteen died before the ship left Africa. They included several children and a woman who hanged herself below deck. On the day the ship sailed, another woman was "left for dead," in the words of the report, which does not say who left her or what became of her.

Sixty-eight people died during the crossing. Four of them, a woman and three children, died in the first week at sea. Twenty more died soon after the ship reached the West Indies, and one more died on the way to the Brown brothers in Providence.

**The uprising.** When the captives rose up, Hopkins's crew fired on them. Hopkins wrote in his account book: "Slaves Rose on us was obliged fire on them and Destroyed 8 and Several more wounded badly." By "Destroyed 8" he meant that his crew killed eight people. The survivors were so sick that buyers paid only £5 for some of them.

**Brown's next ship.** John Brown kept trading in people. In 1795 the crew of his ship *Hope* took 229 Africans from the Gold Coast of Africa, and 198 of them lived to be sold in Cuba. Under a law of 1794, Americans could not own, equip, put money into or work on ships that carried captive people to other countries.

**The trial.** Members of the Providence Abolition Society, a group working to end slavery, took Brown to a United States court for breaking that law. On August 5, 1797, he became the first American tried under it. The jury found him not guilty and ordered the society's members who had charged him to pay his court costs. He did not get the *Hope* back.

### Paying for the war with paper money

Members of the Continental Congress had almost no power to tax. From 1775 they paid for the war by printing paper money called Continental dollars, and the paper dollars quickly lost their value. By the end of 1777 it took about 4 paper dollars to buy what 1 silver dollar bought, and by 1781 it took about 100. The paper money was close to worthless. The saying "not worth a Continental," meaning worth nothing at all, comes from this money.

### Alexander Hamilton

> **Who:** The author of the plan to pay the Revolution's debts in full.
>
> **When and where:** The new United States government, 1790 and 1791.
>
> **Movie:** Alexander Hamilton (American Experience, 2007), a two-hour documentary shown on PBS, with Brían F. O'Byrne as Hamilton.

**After a dinner deal, members of Congress voted his debt plan through.**

Alexander Hamilton planned how the new United States would pay the debts of the Revolution. He set out the plan in his First Report on Public Credit in January 1790. He counted the national debt at about 54 million dollars, and the states owed about 25 million dollars more for the war.

**Paying in full.** Hamilton proposed that the national government pay every debt in full and take over the states' war debts, a step called assumption. The people who were owed money would then look to the new government to be paid, and they would want it to last so that they got their money. Paying in full would also build the government's credit, the trust lenders have that a borrower will pay back what it borrows.

**The dinner.** Assumption did not have enough votes to pass in the House of Representatives in June 1790. Thomas Jefferson invited Hamilton and James Madison, a member of the House from Virginia, to dinner, and the three men made a deal.

**The deal.** Madison agreed to stop blocking assumption and to win over enough Southern members to pass it. In return, Hamilton agreed to find Northern votes for putting the country's permanent capital on the Potomac River, where Washington, D.C., stands today. Members of Congress passed both: first the capital on the Potomac, then assumption.

**Factories.** Hamilton's Report on Manufactures is dated December 5, 1791. In it he laid out a plan to grow American manufacturing, the making of goods in workshops and mills, with tariffs (taxes on goods brought in from other countries) and subsidies (money paid to help a business grow). Members of Congress never brought the plan to a vote.

Hamilton also helped found the Society for Establishing Useful Manufactures. Through it, he and the other founders started a factory town at the falls of the Passaic River, which is Paterson, New Jersey.

### Why farmers fought the whiskey tax

Farmers in western Pennsylvania sent their corn to market as whiskey, so a tax on whiskey fell on the crop they sold. Members of Congress passed that tax in 1791 to help pay the war debt. It was an excise, a tax on goods made and sold inside the country, of 7 cents a gallon on distilled spirits such as whiskey.

**Tar and feathers.** A gang in disguise caught a tax collector named Robert Johnson in September 1791 and tarred and feathered him: they coated him with hot tar and stuck feathers to it.

**Bower Hill.** About 600 armed men attacked the house of John Neville, the tax inspector, at a place called Bower Hill in July 1794. When their leader, James McFarlane, stepped into the open, someone inside the house shot and killed him. The accounts do not say who fired. The attackers then set the house on fire. This uprising is called the Whiskey Rebellion. President George Washington called up about 13,000 militia, soldiers drawn from the states, and the rebels broke up without a battle.

**The Dreadful Night.** Troops under General Henry Lee broke into houses on the night of November 13, 1794, pulled people from their beds and arrested about 150 of them. They held the prisoners in animal pens and basements. For years afterward, people in the area called it "the Dreadful Night."

The troops took 20 of the prisoners to Philadelphia for trial. Two men, Philip Wigle and John Mitchell, were found guilty of treason, the crime of making war against their own country. Washington pardoned them both, setting aside their punishment.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 11 minutes**

In 1800 most American families grew and made most of what they used. By 1850 far more of them grew crops and made goods to sell, and bought what they needed, a change called the market revolution. The biggest thing Americans sold to other countries was cotton grown by enslaved people, and by 1860 enslavers valued the people they held at 3 billion dollars or more.

**Two panics.** In the panics of 1819 and 1837, many people rushed to get their money out at once, and businesses closed. About 50,000 people in three big cities had no steady work in 1819, and by one estimate a third of all workers had no jobs by the fall of 1837.

### From household to market

Farm families and workshops could sell goods far from home once moving them got cheaper. Before the Erie Canal opened in 1825, it cost about 100 dollars to haul a ton of goods by road from Buffalo to New York City. By canal boat the same ton cost about 10 dollars, and the trip took about ten days instead of twenty.

The owners of the new cotton mills in New England hired young women from farm families and paid them wages in cash. These women were among the first large groups of Americans who worked for cash wages.

**Copper and gold.** A rush for copper began on the Keweenaw Peninsula of Michigan, a point of land with water on three sides, in 1843. It began after Douglass Houghton, a scientist who studied rocks for the state as its geologist, reported on the copper there. By 1849 miners there dug 96 of every 100 pounds of copper mined in the United States.

Gold was found at Sutter's Mill in California early in 1848. About 80,000 people went to dig for it in 1849, and about 300,000 people came to California between 1848 and 1855. The merchants who sold the miners their supplies made steadier money than most of the miners did.

### King Cotton

Cotton was the most valuable American export, and enslaved people did the work of growing it. They planted it, picked it and got it ready for sale. The crop was known as King Cotton.

**More than half.** Cotton made up 51.6 percent of the value of everything the United States sold to other countries in 1840, and it stayed above half almost every year until the Civil War. About three of every four pounds grown here were sent abroad. From 1820 to 1860, about 80 of every 100 pounds of cotton used in the world came from the United States.

The cotton crop more than doubled in six years. Enslaved people grew about 300 million pounds of cotton in 1831 and more than 600 million pounds in 1837.

**Forced south.** To grow it, enslavers forced people out of the older slave states and into the new cotton states. They moved about 155,000 enslaved people this way in the 1820s and at least 250,000 in the 1830s. Between about 1790 and 1860, enslavers moved more than 1 million people from the Upper South, the older slave states farther north such as Virginia, to the Deep South, the cotton states farther south.

### People counted as property worth billions

Enslavers counted the people they held as capital, money or property that an owner uses to make more money. Census takers, the government workers who count every person in the country, counted 3,953,760 enslaved people in the United States in 1860. Enslavers valued them at 3 billion dollars or more. That was the price enslavers put on human beings as property, and it was more than all the money invested in American railroads and factories put together.

Enslavers used enslaved people as capital in two ways. The people grew the cotton and were paid nothing for it. Enslavers could also borrow money by promising the people themselves to a lender, and if the loan was not repaid, the lender could take the people and sell them.

### Banks and bond sellers

Planters in Louisiana and Mississippi set up their own banks in the 1830s. The banks lent planters money on mortgages, loans in which the borrower promises property to the lender, and these mortgages covered land and enslaved people. The banks then sold bonds, paper promises to repay a loan with interest, to investors in Europe and in the Northern states. The mortgages on land and people backed those bonds.

**Far from any plantation.** Investors in Europe and the North who bought these bonds made money from loans backed by enslaved people. Bankers in London, Amsterdam and New York sold the bonds to them. Baring Brothers of London and its partners in New York sold 7 million dollars in bonds for the Union Bank of Louisiana in 1832. Hope and Company of Amsterdam sold 12 million dollars in bonds for the Citizens' Bank of Louisiana in 1833.

**A bank's own report.** Two Louisiana banks, the Citizens Bank and the Canal Bank, lent planters money and took about 13,000 enslaved people as collateral, property a borrower promises to hand over if the loan is not repaid. When planters failed to pay, the two banks came to own about 1,250 of those people.

JPMorgan Chase, a bank that grew in part out of those two, made these figures public in a report in January 2005. JPMorgan Chase's leaders apologized and set up a 5-million-dollar scholarship fund for students in Louisiana. They made the report because, under a 2003 Chicago law, companies that did business with the city had to search their records for ties to slavery.

### Insurers, cotton traders and Northern mills

Northern insurance companies sold enslavers policies, written deals, on the lives of enslaved people. The enslaver paid the company a fee, and when an enslaved person died, the company paid the enslaver.

**Two insurers.** New York Life, then called Nautilus Insurance, insured the lives of 520 people from 1846 to 1848. Those people appear to have been enslaved, and the company paid out money for 15 of their deaths. In March 2000, leaders of the insurer Aetna apologized for policies the company sold on enslaved people's lives in the 1850s. They said Aetna would pay no reparations, payments made to make up for a wrong.

**The Lehmans.** The Lehman brothers of Montgomery, Alabama, whose story opens this chapter, made their start as merchants who took slave-grown cotton as payment and then traded it.

**The Lowell mills.** Northern mill owners made money from slave-grown cotton too. Francis Cabot Lowell, Nathan Appleton, Patrick Tracy Jackson and the other Boston merchants who built the Lowell mills were called the Boston Associates. They founded the Boston Manufacturing Company in 1813, and their mills spun cotton grown by enslaved people in the South.

The mills also made a cheap, rough cloth known then as "negro cloth," from the word white Americans of that time used for Black people. The mill owners sold the cloth to planters, who used it to clothe the people they enslaved. By 1845, 31 cloth companies tied to the Boston Associates, in Massachusetts, New Hampshire and southern Maine, made one-fifth of all the cotton and wool cloth in the United States.

Senator Charles Sumner of Massachusetts named the two sides by their tools: the lash, a whip, and the loom, a machine that weaves thread into cloth. He called the tie between planters and mill owners an "unholy union ... between the lords of the lash and the lords of the loom."

### The Panic of 1819

The Panic of 1819 began the first major depression that the American public lived through, a long stretch of hard times, from about 1819 to 1822, when businesses closed and many people lost their work.

**What caused it.** The prices that buyers paid for cotton fell sharply. Officers of the Second Bank of the United States called in loans, asking borrowers to pay back money right away. Under an 1817 order from Congress, buyers of land from the national government had to pay in gold or silver coin. Owners closed American factories because buyers chose cheaper goods from Britain.

**No work.** During the panic, employers let workers go, and judges jailed people who could not pay their debts. In New York, Philadelphia and Baltimore, about 50,000 people had no work or only odd jobs. One observer from abroad estimated that half a million people across the country had no work. Nobody made a real count.

**Debtors' prison.** In those years, a person who was owed money could sue, and a judge could order the borrower arrested and locked in a debtors' prison, with no set date for release. In Philadelphia, judges sent 1,808 people to debtors' prison this way. In Boston, judges sent 3,500.

Land lost its value. Farmland in Pennsylvania fell from 150 dollars an acre in 1815 to 35 dollars in 1819, and property in Richmond, Virginia, lost half its value.

**The poor.** In New York City, a city of about 120,000 people, the number of paupers, people too poor to feed themselves without help, rose from 8,000 in 1819 to 13,000 in 1820. Mathew Carey, a publisher and economist in Philadelphia, estimated that 3 million people, about one-third of the nation, were hurt by the panic.

Small cotton planters went bankrupt in 1819, and again in 1837: they could not pay their debts, so their lenders could take what they owned. Larger planters bought up the small planters' land and the enslaved people those planters had held.

### The Panic of 1837

A depression began with the Panic of 1837 and lasted until about 1843. In the years before it, buyers speculated in western land and in cotton, buying in the hope of selling later at a higher price. Then British lenders made loans harder to get, and the price of cotton fell, by half in New Orleans.

**The banks stop paying.** The bankers of New York City stopped paying out gold and silver on May 10, 1837. People who brought in the banks' paper money could no longer trade it for coins.

Of the country's 850 banks, 343 closed, about 4 of every 10, and 62 more partly failed, by the count in a history collection edited by Hubert Howe Bancroft in 1902. A college textbook gives a smaller count, 200 banks closed. The governments of seven states and one territory did not pay back their loans.

**How many lost work.** By one widely repeated estimate, a third of all workers had no jobs by the fall of 1837, and within two years employers cut the pay of people who kept their jobs by 30 to 50 percent. Other estimates put New York's unemployment, the share of people who want work and cannot find it, at about 25 or 30 percent in 1837 and 1838.

Nobody counted the jobless at the time, so these are later estimates, and the teaching guides that repeat them do not say who made them.

**The flour riot.** Food had already grown costly before the banks stopped paying. A barrel of flour in New York rose from 7 dollars to 12 between 1836 and 1837. About 5,000 New Yorkers met in City Hall Park on February 13, 1837, to protest the price of food and fuel.

Part of the crowd broke into the store of the flour merchants Eli Hart and Company. They took or destroyed 500 to 600 barrels of flour and 1,000 bushels of wheat, about 60 pounds of wheat to each bushel.

**Who paid.** Mississippi planters owed 33 million dollars to the banks of New Orleans, and their 1837 cotton crop sold for only 10 million dollars. What happened next depended on whom a debtor owed.

Some planters had borrowed from banks in Mississippi and Florida whose bonds those states had backed. A bond is a paper promise to repay borrowed money with interest, and a state that backed a bank's bonds promised to pay the buyers itself if the bank could not. Lawmakers in both states later refused to pay those bonds. So the investors in Europe and the North who had bought them lost their money, and the planters who owed those banks kept their land and the people they enslaved.

**Families sold apart.** Debtors who owed other creditors, the people they owed money to, could lose the people they enslaved. When such a debtor could not pay, a judge could order his property taken, and the creditors seized the people he enslaved and sold them. Two Louisiana banks came to own about 1,250 enslaved people when planters failed to repay their loans. Many debtors fled to Texas at night and took the people they enslaved with them.

A single creditor's claim against a debtor who failed to pay could force the sale of a whole enslaved community. The creditors sold its people to different buyers and scattered them, and sales like these split families. By the count of the Equal Justice Initiative, a group that studies the history of slavery, enslavers and traders separated nearly half of all the people they moved inside the country from a husband, a wife or a parent.

### Philip Hone

> **Who:** A New York merchant whose diary recorded the Panic of 1837 as it happened.
>
> **When and where:** New York City. He kept the diary from 1828 to 1851.

**Hone wrote down the crash of 1837 and lost money in it.**

Philip Hone sold goods at auction in New York City, and he had served as the city's mayor in 1826 and 1827. During the Panic of 1837 he wrote in his diary how business in the city stopped: "No goods are selling, no business stirring, no boxes encumber (crowd or block) the sidewalks of Pearl Street."

Hone lost part of his own fortune in the crisis years. His diary was printed in 1889, after his death, as *The Diary of Philip Hone*.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 14 minutes**

American mills made 11.4 million tons of steel in 1900, more than Britain and Germany together. By then the United States was an industrial country, one where much of the work is done in mines, mills and factories. Railroad track grew from about 9,000 miles in 1850 to 193,346 miles by 1900. The era is called the Gilded Age.

**In the South.** After slavery ended, Southern landowners farmed with sharecroppers, families who worked a landowner's land for a share of the crop and stayed in debt to him. Officials in Southern states leased prisoners, renting them out to private companies, and in Alabama 90 or more of every 100 prisoners were Black.

**Hard times.** About one in four workers in New York City lost their jobs after the Panic of 1873, by estimates of the time. For the Panic of 1893, estimates for the whole country run from about 17 to 25 percent of workers.

### Where the name Gilded Age comes from

The name Gilded Age comes from an 1873 novel by Mark Twain and Charles Dudley Warner, *The Gilded Age: A Tale of Today*, in which the two writers made fun of their own time. Something gilded is covered with a thin layer of gold, so the name means a thin shine of gold over serious problems underneath.

### Steel, rails, cattle and metal

Steel rails got cheap in these years. According to histories of the steel industry, a ton of steel rails cost about 140 dollars in 1872, about 35 dollars in 1882 and about 20 dollars by 1900. American mills made more steel than Britain's by about 1889 or 1890.

**Cattle.** Cattle ranchers in Texas drove herds north to the railroads in Kansas, where a Texas longhorn worth up to about 5 dollars at home could sell for up to about 40 dollars. From 1866 to 1884, cowboys drove more than 5 million cattle north.

Ranchers also kept cattle on the open range, land with no fences, where the animals grazed wherever they wandered. Four things ended the open-range cattle business. Barbed wire fences went up across the range, and more railroads were built. Officials put a quarantine on cattle in 1885 and 1886, keeping animals apart from others to stop the spread of a disease. The last was the winter of 1886 to 1887.

**Homesteads.** Members of Congress passed the Homestead Act in 1862. Under it, a settler could claim up to 160 acres of land and own it after living on it and farming it for five years. Settlers filed about 4 million claims, and about 270 million acres, about a tenth of the country's land, became private farms. US officials had taken that land from Native nations.

**Silver, copper and aluminum.** The Comstock Lode, a long vein of silver running through rock near Virginia City, Nevada, was the richest body of silver in North America. It was found in 1859. Copper from Michigan, and later from Butte, Montana, became the wire for electric lights and telephones.

Charles Martin Hall, a 22-year-old college graduate, made aluminum by a new method in his family's woodshed in Oberlin, Ohio, on February 23, 1886, with help from his sister Julia. The Pittsburgh Reduction Company began making the metal by his method in 1888, and a new industry began. A pound of aluminum cost about 12 dollars in the early 1880s and less than 1 dollar by the middle of the 1890s.

### The panics of 1857 and 1873

The Ohio Life Insurance and Trust Company failed on August 24, 1857. Its manager in New York had stolen from it, and its officers had made bad loans. News of the failure went out by telegraph, and people in many places rushed to take their money out of banks, a rush called a bank run. A short but deep depression followed.

The Panic of 1873 began on September 18, when Jay Cooke and Company failed. It was an investment bank, a firm that sold bonds and shares to raise money for businesses such as railroads, and Jay Cooke and his partners had put too much money into bonds of the Northern Pacific Railroad.

**The exchange closes.** The New York Stock Exchange, where people buy and sell shares of companies, closed for ten days. It had never closed like this before. About 18,000 businesses failed. Economists at the National Bureau of Economic Research set the dates when hard times begin and end, and by their count this depression lasted 65 months, until March 1879. It was the longest stretch of hard times on their record until the 1930s.

**New York's jobless.** About one of every four workers in New York City had lost their jobs by the winter of 1873 to 1874, according to estimates drawn from newspapers of the time. The historian Howard Zinn wrote that more than 90,000 homeless workers, almost half of them women, slept in New York police stations.

**Tompkins Square.** About 7,000 people with no work met in Tompkins Square Park in New York City on January 13, 1874. They wanted Mayor William F. Havemeyer to create public jobs. Soon after 10 in the morning, New York police, some of them on horseback, charged into the crowd. The police commissioner, the official in charge of the city's police, was Abram Duryée.

The police beat people with clubs, and men, women and children ran. The accounts give no count of the people who were hurt. Men from a German workers' club fought back, and someone hit one policeman on the head with a hammer. The police drove the crowd out of the square and arrested 46 people.

### Why farmers joined the Grange

Farmers were angry about what railroads charged to ship their grain and what grain elevators, the tall buildings where grain is stored before it is shipped, charged to hold it. In 1867 Oliver Hudson Kelley founded the Patrons of Husbandry, known as the Grange (husbandry is an old word for farming). By the middle of the 1870s it had about 800,000 members.

Grange members pushed state lawmakers to pass the Granger laws, which set the highest rates that railroads and grain elevators could charge. In *Munn v. Illinois* in 1877, the justices of the Supreme Court ruled that those laws were allowed under the Constitution.

### The Panic of 1893 and Coxey's Army

About 500 banks and 15,000 businesses failed in the Panic of 1893, and more than 150 railroad companies later went bankrupt. Nobody counted the people out of work at the time. Later estimates for the worst of it run from about 17 to 25 percent of workers. The economic historian Stanley Lebergott estimated that unemployment rose from about 3 percent in 1893 to 18.4 percent in 1894.

**The march.** A businessman named Jacob Coxey led a march of men without work from Massillon, Ohio, to Washington, D.C., in 1894. About 100 men left on March 25, and about 500 arrived on May 1, while a crowd of about 30,000 watched them. It was the first large protest march on Washington.

The marchers, called Coxey's Army, asked the national government for a 500-million-dollar program of public works. Under it, federal officials would have hired people without jobs to build public projects. When Coxey tried to speak at the Capitol, police arrested him for walking on its grass, and he served 20 days in jail.

### Sharecropping and debt

Most freedpeople in the South, the people freed from slavery, had no land after the Civil War. Many families went to work as sharecroppers.

**The furnish.** A landowner gave a family a plot of land, usually about twenty acres. He also "furnished" the family with food, seed, tools and a cabin on credit, to be paid for later, and this was called the furnish. On the furnish, landowners charged interest, the fee a borrower pays for borrowing, far above a fair rate.

At harvest the landowner sold the crop and took out the cost of the furnish and the interest. Then he gave the family its share, usually half of what was left or less.

Landlords held a lien on the crop, a legal claim on it until the debt was paid, and they kept the account books. So most sharecroppers were still in debt when the landlord settled the yearly accounts, year after year. A landlord could put a sharecropping family off the land whenever he chose.

Sharecropping lasted into the 1930s. Census takers counted 1,831,470 tenant farmers in the South in 1930, farmers who worked land they did not own, about half of all farmers there. About 700,000 of them were share tenants, who owned mules or tools and kept two-thirds to three-quarters of the crop.

Most Black farmers in the country owned no land by 1935: 77 of every 100. Nearly half of white farmers owned none. In 1937 members of the President's Committee on Farm Tenancy counted about 775,000 sharecroppers in the South, almost equal numbers of white and Black.

### Debt peonage and Alonzo Bailey

Members of Congress banned peonage, forcing a person to work to pay off a debt, in the Peonage Abolition Act of 1867. Lawmakers in Southern states then wrote laws that had the same effect. Peonage was most common in the cotton belt, the part of the South where cotton was grown, and in the turpentine camps of southern Mississippi, Alabama, Georgia and the Florida panhandle, where workers collected sap from pine trees to make turpentine, a liquid used in paint.

Alonzo Bailey, a Black farm laborer in Montgomery County, Alabama, signed a work contract on December 26, 1907, with the manager of the Riverside Company, a company that ran a farm. Bailey received 15 dollars before he started work, to be paid back out of wages of 12 dollars a month. He quit after about a month.

**The charge.** Under Alabama law, a worker who quit without paying back money he got this way was a criminal. An Alabama court found Bailey guilty, fined him 30 dollars and sentenced him to 136 days of hard labor, heavy work done as a punishment.

**The appeal.** A Montgomery lawyer, Edward S. Watts, and a city judge, William H. Thomas, helped Bailey take his case to the United States Supreme Court, and Booker T. Washington helped in secret. On January 3, 1911, in *Bailey v. Alabama*, the justices ruled that the Alabama law broke the Thirteenth Amendment, the part of the Constitution that bans slavery. Other states' peonage laws stayed in force until the justices struck down Georgia's and Florida's in the 1940s.

### Convict leasing in Alabama

The Thirteenth Amendment bans slavery "except as a punishment for crime." Under that exception, state and county officials in the South rented out prisoners to private companies, which was called convict leasing. The companies paid the government a fee for each prisoner, and the companies' bosses made the prisoners work in mines, on farms and in lumberyards.

Officials in Alabama leased prisoners from 1846 to July 1, 1928. After a money crisis in the state government in 1875, the warden John G. Bass, the official in charge of the state's prisoners, leased them to coal mines, farms and lumberyards for monthly fees.

**Three coal companies.** From 1883, under the warden John Hollis Bankhead, officials leased most state prisoners to three coal companies: the Pratt Coal and Iron Company, the Tennessee Coal, Iron and Railroad Company, called TCI, and the Sloss Iron and Steel Company. In 1888 TCI signed a ten-year contract for every state prisoner able to work, paying the state 9 to 18.50 dollars a month for each prisoner.

More than 95 of every 100 county prisoners in Alabama were Black, and so were 90 of every 100 state prisoners. The companies' bosses whipped prisoners to make them work. Coal company officials wrote false reports of "bad conduct" so that the prisoners would have to serve longer sentences.

**What the state made.** Alabama's state officials collected money from leasing prisoners. Fees for leased prisoners were about 10 of every 100 dollars the state took in during 1883, and in 1898 they were nearly 73 of every 100 dollars.

**Deaths.** Leased prisoners died at about ten times the rate of prisoners in states that did not lease them, according to Digital History, a history website of the University of Houston. By the same source, 25 of every 100 Black leased prisoners in Alabama died in 1873. At Sloss's Coalburg mine, 9 of every 100 prisoners died each year, Dr. Thomas D. Parke, the health officer of Jefferson County, reported in 1895.

Alabama's mines held 1,710 state prisoners and 745 county prisoners in 1896. In the two years before, 233 state prisoners and 181 county prisoners had died.

**James Knox.** A prisoner named James Knox, from Mobile, was killed at Sloss's Flat Top mine in 1924. Men there whipped him with a steel wire and lowered him into a vat of boiling water. The published accounts of his death do not name the men who did it.

His death was first reported as a suicide by poison, and it led to an investigation. An autopsy, an examination of a dead body by doctors, found that his heart had stopped and that the poison had been put into his body after he died. Investigators found that the whipping and the boiling water caused the injuries that killed him.

Sloss's managers kept county prisoners working in the company's mines until 1928. That year Alabama's officials ended convict leasing. Alabama was the last state to end it, about five years after Florida.

**Breaking strikes.** TCI's managers also used leased prisoners in Tennessee, where officials leased prisoners from 1871 to 1896. A TCI official told the *New York Times* that "one of the chief reasons" the company took up convict leasing "was the chance it offered for overcoming strikes," the times when workers stop working until their employer agrees to better pay or conditions.

The official said free miners would not want to strike once they saw the company had plenty of prisoners to put to work. The account of the interview does not give his name. TCI's managers used prisoners to keep unions, groups of workers who join together to bargain with their employer, out of the mines.

### Andrew Carnegie

> **Who:** A Scottish immigrant who started work as a mill boy, built a steel company, sold it for 480 million dollars and gave away more than 350 million dollars.
>
> **When and where:** Scotland and Pennsylvania, 1835 to 1919. He built steel mills from the 1870s and sold his company in 1901.
>
> **Movie:** The Richest Man in the World: Andrew Carnegie (American Experience, 1997), a documentary about him shown on PBS.

**His first job, at about 13, paid 1.20 dollars a week.**

Andrew Carnegie's family moved from Dunfermline, Scotland, to Allegheny, Pennsylvania, in 1848. At about 13 he went to work in a cotton mill as a bobbin boy, changing the spools that held the thread. He worked as a telegraph messenger and then as a manager for the Pennsylvania Railroad. From the 1870s he built steel mills, among them the Edgar Thomson works.

**Selling and giving.** In 1889 Carnegie wrote an essay called "The Gospel of Wealth." In 1901 he sold Carnegie Steel to a group led by J. P. Morgan for 480 million dollars. He gave away more than 350 million dollars, including money for about 2,500 public libraries. Counts of the libraries vary, and some go above 2,800 around the world.

**Homestead.** Workers at Carnegie Steel's works in Homestead, Pennsylvania, went on strike in 1892. Henry Clay Frick, one of the men running Carnegie's company, hired 300 armed agents of the Pinkerton detective agency, a private company that hired out guards and detectives, to take back the plant. On July 6 the Pinkertons came up the river on barges, and they and the strikers fought a gun battle.

Seven workers and three Pinkertons were killed, and some accounts count more. No record names the men who fired the shots that killed them. Governor Robert E. Pattison of Pennsylvania sent about 8,000 state soldiers. By November the strike had failed, and Frick and the company's other managers had broken the steelworkers' union at Homestead.

### John D. Rockefeller

> **Who:** The founder of Standard Oil, which by 1880 controlled about 90 percent of oil refining in the United States.
>
> **When and where:** Cleveland, Ohio, from 1870. He lived from 1839 to 1937.
>
> **Movie:** The Rockefellers (American Experience, 2000), a documentary shown on PBS about four generations of his family, not about him alone.

**Lamp oil dropped from about 26 cents a gallon to 7 cents.**

John D. Rockefeller built the company that controlled most of America's oil refining, the work of turning crude oil from the ground into fuels people can use. He founded the Standard Oil Company in Cleveland in 1870, and by 1880 his company controlled about 90 percent of the oil refining in the United States.

**Cheap light.** Kerosene was the fuel that ordinary families burned in their lamps. A gallon of it cost about 26 cents in 1870, about 9 cents by 1880 and about 7 cents by 1890, so lamp light became cheap for ordinary homes.

Rockefeller became the richest man in the country. Later he gave large sums of money to universities and to medical research.

**If you remember one thing:** After slavery ended, Southern landowners and state officials used debt and prison leasing to keep many Black workers laboring for little or nothing.

**One number:** 73. In 1898 nearly 73 of every 100 dollars that Alabama's state government took in came from leasing prisoners, up from about 10 in 1883.

**Next:** After 1900 Henry Ford roughly doubled his workers' pay, and after the crash of 1929 hungry families stood in breadlines.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 14 minutes**

Stock prices, the prices of shares in companies, crashed in October 1929, and by 1933 about one of every four workers had no job. In Chicago and Pittsburgh, more than half of Black workers had no job in 1932, by later estimates. In 1935 members of Congress and President Franklin D. Roosevelt set up old-age pensions and unemployment insurance in the Social Security Act. The pensions were regular payments to people too old to work, and the insurance paid workers who had lost their jobs.

**Farm and household workers.** The law did not include farmworkers and domestic workers, people who cleaned, cooked and cared for children in other people's homes. Most Black workers did those two jobs, so most of them could get neither payment. Two accounts disagree about who left these workers out. One points to Southern members of Congress, and the other to the Treasury Secretary, who asked for the change for reasons that had to do with collecting the tax.

**War work.** Unemployment fell to 1.2 percent in 1944, when factories were making goods for the Second World War.

### Henry Ford

> **Who:** The carmaker who roughly doubled his workers' pay in 1914 and cut the price of his Model T car from 825 dollars to 260 dollars.
>
> **When and where:** Ford's Highland Park car factory. He announced the five-dollar day on January 5, 1914.
>
> **Movie:** Henry Ford (American Experience, 2013), a documentary about him shown on PBS.

**Ford's managers hired almost four new workers a year for every job.**

Henry Ford roughly doubled his workers' pay in 1914. He did it to stop workers from quitting, and workers who earned more could also buy the cars they built.

**Why they quit.** Ford's managers put in an assembly line, which moves each car past a row of workers who each do one step over and over. After that the work never let up and was dull. Turnover, the count of workers who quit and had to be replaced, reached 370 percent at the Highland Park factory in 1913.

**The five-dollar day.** Ford announced five dollars for an eight-hour day on January 5, 1914, and the new rate began on January 12. Before, a Ford worker earned about 2.34 dollars for a nine-hour day.

The raise came with conditions. Ford paid the extra money as profit-sharing, a share of the company's profits, and a worker qualified only after six months. Staff of the company's Sociological Department inspected workers' homes before granting the full rate. They checked whether workers saved their money and whether they drank alcohol, and they checked for what they called "proper" living. Ford left out men under 22, and at first most women.

After the raise, fewer workers quit. The price of the Model T kept falling, from 825 dollars in 1908 to 260 dollars by 1925.

Ford fought unions, the groups workers form to bargain with their employer, for decades. He owned a newspaper, the *Dearborn Independent*, and through the 1920s he published antisemitic articles in it, articles hateful toward Jewish people. Ford later apologized in public for the articles.

### The crash and the Great Depression

The Dow Jones average is a number built from the stock prices of a group of large companies. It climbed through most of the 1920s and reached 381 on September 3, 1929. Prices fell hard on Black Thursday, October 24, 1929, and again on Black Tuesday, October 29. By July 8, 1932, the Dow stood at 41, about 89 percent below its peak.

The hard times of the 1930s are called the Great Depression. By 1933 about 25 percent of workers, one in four, had no job, and about 9,000 of the country's 25,000 banks had failed and closed. Government officials and scholars made the jobless estimate later, because nobody counted the jobless every month at the time.

**Output and prices.** GDP, the total value of all the goods and services made in the country in a year, fell from about 104 billion dollars in 1929 to about 56 billion dollars in 1933. Part of that drop came only from lower prices: from October 1929 to April 1933, the prices of the things people bought every day fell by about 27 percent.

Economists take the change in prices out of GDP to see how much less the country actually made. Counted that way, as real GDP, output fell by about 30 percent.

Hungry people stood in breadlines, lines for free food. Some lived in shantytowns, groups of shacks, which people called Hoovervilles.

### The Bonus Army

Veterans of the First World War camped in Washington, D.C., in the summer of 1932 to ask for a bonus they were owed for their war service. The bonus was not due until 1945, and the veterans asked to be paid early in cash. Estimates of their number run from about 10,000 to more than 20,000, and many had their families with them. Members of the Senate voted the payment down on June 17.

**The shooting.** Police trying to clear veterans out of some buildings in the city on July 28 shot and killed two veterans, William Hushka and Eric Carlson. Hushka had come from Lithuania. He sold his butcher shop to join the army in the First World War and became a citizen while he served. He was buried at Arlington National Cemetery less than a week after he was shot.

**The Army.** President Hoover then ordered the Army to clear the camps. General Douglas MacArthur sent in infantry, soldiers on foot, and cavalry, soldiers on horseback, with tanks and tear gas. The gas stings the eyes, nose and throat, so people cough and their eyes stream with tears. MacArthur's soldiers burned the main camp.

Members of Congress later voted to pay the bonus over the veto of President Franklin D. Roosevelt, who had refused to sign the bill. The payments began in June 1936.

### Benjamin Roth

> **Who:** A lawyer in Youngstown, Ohio, who kept a diary of the Great Depression for more than ten years.
>
> **When and where:** Youngstown, Ohio. He began the diary in 1931.

**People sold their frozen bank savings for 50 cents on the dollar.**

Benjamin Roth's diary records the banks that closed in Youngstown, the stocks that became worthless, prices, and what lawyers and workers earned. When the banks closed, people could not get their savings out. Even after the banks reopened, savers could take out only a small part. Roth wrote down how people with cash bought up these frozen bank accounts for 50 cents on the dollar, half of what was in them.

When cash ran out, he wrote, people turned to barter, trading goods instead of paying money, and to scrip, paper that stood in for money.

**The umbrella.** In 1931 Roth wrote that "banks are absolutely terrible in their insistence on payments of notes and mortgages," meaning that bankers demanded that borrowers pay back their loans. "It is the old story of lending you an umbrella when the sun is shining and then demanding it back when it rains."

His son, Daniel B. Roth, and James Ledbetter edited the diary in 2009, and the publisher PublicAffairs printed it as a book, *The Great Depression: A Diary*.

### Pushed out when jobs ran short

Black workers lost their jobs first and at higher rates than white workers. Employers hired Black workers last and fired them first, a pattern called "last hired, first fired." By 1932 nearly half of all Black Americans had no work, according to the National Museum of African American History and Culture.

More than half of Black workers in Chicago and Pittsburgh had no job in 1932, History.com reports, drawing on the Library of Congress. About a quarter of white workers in Northern cities had none. In Atlanta in 1934, nearly 70 percent of Black workers had no job. These numbers are all later estimates, because nobody kept an official count by race.

**Forced to Mexico.** Government officials and private employers forced people whose families came from Mexico to leave for Mexico, starting in 1929. Federal officials and the officials of local welfare agencies blamed Mexican immigrants for taking scarce jobs and for costing public money when they got relief, the aid given to people without work.

California's lawmakers found in 2005 that about 400,000 American citizens and legal residents had been forced to go from California alone. They estimated that about two million people were forced out across the country, and that about 1.2 million of them had been born in the United States. Local officials sold some families' property to pay for sending them away.

### The New Deal

The federal government, the national government in Washington, paid no unemployment insurance and no old-age pensions before 1933. Members of Congress set up both in the Social Security Act of 1935. President Roosevelt and his officials started many programs from 1933 on, including the CCC, the WPA and Social Security, and together they are called the New Deal.

**Jobs.** President Roosevelt set up the Civilian Conservation Corps, or CCC, a federal jobs program for young men, on March 31, 1933. About 3 million young men worked in it over the years it ran. They earned 30 dollars a month and sent about 25 dollars of it home.

The Works Progress Administration, or WPA, ran from 1935 to 1943. About 8.5 million people worked for it. WPA workers built about 650,000 miles of roads, 125,000 public buildings and 75,000 bridges.

**The first check.** President Roosevelt signed the Social Security Act on August 14, 1935. The first monthly old-age check went to Ida May Fuller of Ludlow, Vermont, on January 31, 1940. It was for 22.54 dollars, and she had paid a total of 24.75 dollars in Social Security taxes.

### Frances Perkins

> **Who:** The Secretary of Labor who chaired the committee that planned Social Security, and the first woman in a United States Cabinet.
>
> **When and where:** Secretary of Labor from 1933 to 1945. She lived from 1880 to 1965.
>
> **Movie:** Summoned: Frances Perkins and the General Welfare (2020), a documentary about her.

**Her committee wrote the plan for Social Security in under seven months.**

As chair of the Committee on Economic Security, Frances Perkins led the planning of Social Security. She was Secretary of Labor from 1933 to 1945 and the first woman in a United States Cabinet, the group of the president's top officials.

**The committee.** President Roosevelt set up the committee on June 29, 1934, and its members planned old-age pensions and unemployment insurance. They sent their report to Roosevelt on January 15, 1935, and he signed the Social Security Act on August 14, 1935.

According to the historian Larry DeWitt, Perkins wanted farmworkers and domestic workers covered by the new law, and so did Harry Hopkins, the official in charge of aid to the jobless.

### Who was left out of Social Security

Of every 100 Black workers in 1930, 65 were farmworkers or domestic workers, the two kinds of work the Social Security Act of 1935 did not include. So about two-thirds of Black workers could get neither an old-age pension nor unemployment insurance, and in the South the share was higher. The president of the NAACP, a civil rights group, gave these figures in 2020.

**What Houston said.** Charles Hamilton Houston spoke for the NAACP at the hearings on the bill in 1935. He used the word Negro, the common word for Black people at that time. The bill, he said, would leave out "Negro sharecroppers and Negro cash tenants, who are just about at the bottom of the economic scale." Sharecroppers paid for the land they farmed with part of the crop, and cash tenants paid in money.

Houston called the law "a sieve with the holes just big enough for the majority of Negroes to fall through," comparing it to a strainer full of holes.

**Who made the choice.** Two accounts disagree about who left these workers out. Jon Dubin, in a 2024 article in a Stanford law journal, points to Southern members of Congress. One of them, Representative Howard Smith of Virginia, argued for keeping Black sharecroppers and domestic workers dependent on their employers.

Dubin also points to Senator Harry Byrd of Virginia, whose words show what Southern members feared from the bill. Byrd opposed a rule that payments be high enough for "decency and health." He said that rule "might serve as an entering wedge," a first step that opens the way to more, "for federal interference with the handling of the Negro question." Byrd did not want federal officials to have a say in how matters touching Black people were handled.

The executive director of Perkins's committee reported that Byrd's position was "supported by nearly all of the southern members of both committees," the two committees in Congress that worked on the bill.

**The other account.** Larry DeWitt, a historian at the Social Security Administration, gave a different account in 2010. He found that Treasury Secretary Henry Morgenthau asked for the changes to the bill that left these workers out, for reasons that had to do with collecting the tax. DeWitt wrote that charges of racial bias, unfair treatment because of race, in the founding of Social Security did "not hold up under detailed scrutiny," meaning close study.

**The changes.** Members of Congress changed the law in 1950 to cover farm and domestic workers who worked regularly for one employer, and in 1954 they covered the rest. Representative Smith opposed these changes too. Of eight House members who voted against them, six were Southern Democrats. In the Senate, Byrd opposed them, and so did a senator from Mississippi.

### Farm payments and evicted sharecroppers

Federal farm payments in the 1930s went to landowners, and many sharecroppers lost their places on the land. The landowners are also called landlords, or planters.

**Paid to grow less.** Members of Congress passed the Agricultural Adjustment Act in May 1933. Under it, officials of the Agricultural Adjustment Administration, or AAA, ran a farm program under Agriculture Secretary Henry Wallace, and they paid farmers to grow less. Their aim was to raise farm prices: with less cotton and pork for sale, buyers would have to pay more for them.

That year farmers plowed under about 10 million acres of growing cotton, turning the plants back into the soil. AAA officials bought about 6 million pigs and had them killed.

**Who got the checks.** Under the AAA's cotton contracts of 1934 and 1935, officials paid landowners to take land out of cotton. Agriculture Secretary Henry Wallace "rented" about three-eighths of the country's cotton land in this way. Sharecroppers got only about 11 percent of the payments.

A landlord could keep the whole check by evicting the sharecroppers, putting them off the land and out of their homes, and hiring day laborers, who were paid by the day. When planters cut their cotton land by 40 or 50 percent, they cut the number of their tenants, the families who farmed their land, by the same share. More than two-thirds of Black sharecroppers made no profit or went into debt, according to the National Museum of African American History and Culture.

**The union.** Seven Black men and eleven white men founded the Southern Tenant Farmers' Union in Arkansas in July 1934 to protest the evictions. Planters and the men who worked for them attacked the union.

Lawmen arrested and jailed a white organizer. Four armed white men told Black members they would be lynched, killed by a mob, if they were caught at another union meeting. Many members were beaten and threatened with guns, and the accounts do not name the men who beat them. A mob attacked the home of the union's lawyer. Chapter 15 tells the union's story in full.

**The purge.** A group of AAA lawyers, led by Jerome Frank, ruled that landlords had to keep the same tenants. AAA administrator Chester Davis had Wallace fire those lawyers in February 1935, a firing called the AAA purge.

The justices of the Supreme Court ruled the Agricultural Adjustment Act unconstitutional, against the Constitution, in 1936. Members of Congress wrote a new version in 1938, and federal officials have paid farmers ever since.

### War work ends mass unemployment

Factory workers made war goods during the Second World War, and unemployment fell from 14.6 percent in 1939 and 1940 to 1.2 percent in 1944. The figure for 1939 and 1940 was estimated later. The official yearly records begin in 1944, and 1.2 percent is the lowest rate in them.

Workers in American factories built 299,230 military aircraft from January 1940 to August 1945. Real GDP rose about 72 percent from 1940 to 1945. By 1945 the United States made about half of all the manufactured goods in the world.

**If you remember one thing:** During the Great Depression, members of Congress set up the first national payments for people out of work or too old to work.

**In 1929:** The federal government paid no unemployment insurance and no old-age pensions.

**In 1950:** Old-age checks had gone out since 1940, and members of Congress changed the law to cover farm and domestic workers who worked regularly for one employer.

**Next:** In 1956 a ship carried 58 shipping containers from Port Newark to Houston, and in 1985 three musicians played the first Farm Aid concert to raise money for farm families.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 7 minutes**

The income of the typical American family roughly doubled between 1947 and 1973, counted with the rise in prices taken out. Families who were poor, in the middle and rich all gained. In the 1970s prices and unemployment rose at the same time, and after June 1979, when factory jobs peaked at 19.6 million, their number fell.

**Mills and farms.** About 50,000 people in the Mahoning Valley around Youngstown, Ohio, lost jobs in steel and related work within about five years of 1977. The owners of about 300,000 farms could not repay their loans in the 1980s. By the 2000s, more than 80 of every 100 jobs outside farming were in services, in places such as stores, offices, hospitals and schools. The country went 120 months in a row without a downturn from March 1991 to March 2001.

### The postwar boom

Pay rose for families at every level of income for about twenty-five years after the Second World War. Between 1947 and 1973 the median family income, the income of the family in the middle, roughly doubled, counted with the rise in prices taken out. Half of all families earned more than the median family, and half earned less. A general rise in prices like that is called inflation, and it means each dollar buys less than before.

The economists Claudia Goldin and Robert Margo studied the gap between high wages and low wages. They found that the gap narrowed sharply in the 1940s and stayed narrow into the 1970s, and they named this the Great Compression, from compress, to squeeze together.

**The G.I. Bill.** Under the G.I. Bill, veterans of the Second World War could use federal money for school or job training, and federal officials backed their home loans, promising to repay the lender if a borrower could not. By July 1956, when the first version ended, 7.8 million of the 16 million veterans had used its money for education or job training. From 1944 to 1952, officials of the VA, the federal agency for veterans, backed about 2.4 million home loans.

**A duty to keep people working.** Members of Congress made "maximum employment, production, and purchasing power" (how much people can buy with their money) a stated duty of the federal government in the Employment Act of 1946. Under the same act they created the Council of Economic Advisers, a group of economists who advise the president.

The ideas behind the act came from the British economist John Maynard Keynes, who argued for government spending against slumps, the times when business falls off. Members of Congress took a promise of full employment out of the bill before they passed it.

**Shipping boxes.** Malcom McLean's ship *Ideal X* carried 58 large shipping boxes, called containers, from Port Newark to Houston on April 26, 1956. By the economist Marc Levinson's calculation, loading loose cargo onto a ship by hand cost about 5.86 dollars a ton in 1956, and loading it in containers cost about 16 cents a ton.

### What was stagflation?

Stagflation was the name for a mix of inflation and a stagnant economy, one that is not growing. In the 1970s prices and unemployment rose together, which most economists had thought could not happen.

**The oil embargo.** Leaders of Arab oil-selling countries stopped the sale of their oil to the United States in October 1973, a ban on trade called an embargo. The price of oil roughly quadrupled in six months. Consumer prices, the prices of the things people buy for daily life, rose about 11 percent in 1974, and unemployment reached 9.0 percent in May 1975.

Inflation passed 13 percent in 1979 and 1980, and in 1980 prices rose 13.5 percent. Unemployment reached 10.8 percent in November and December 1982, the highest rate since the Great Depression.

### Factory jobs fall

A shrinking share of American workers had jobs in manufacturing, making goods in factories, after 1950. In 1955, 30.6 of every 100 jobs outside farming were in manufacturing, by 2005 about 11 of every 100 were, and by the 2020s about 8. The number of factory jobs peaked at 19.6 million in June 1979. By the 2000s, more than 80 of every 100 jobs outside farming were in service industries.

**Black Monday.** The managers of Youngstown Sheet and Tube announced on September 19, 1977, that they would close the company's Campbell Works steel mill in Youngstown, Ohio. About 5,000 workers lost their jobs at once, and the day became known as Black Monday. Within about five years, about 50,000 people in the Mahoning Valley around Youngstown lost jobs in steel and related work. These numbers come from later news reports.

### Gerald Dickey

> **Who:** A Youngstown steelworker who proposed that the workers and the town buy their closed mill and reopen it.
>
> **When and where:** Youngstown, Ohio, 1977 to 1979.

**The mill stayed closed after federal officials said no in 1979.**

After the Campbell Works closed, Gerald Dickey proposed that the steelworkers and the people of Youngstown buy the mill and reopen it. To buy it, they needed about 100 million dollars in federal loan guarantees, the government's promise to repay the loans if the borrowers could not. From 1976 to 1979 Dickey was the recording secretary, the keeper of the written record of meetings, of Local 1462, a branch of the United Steelworkers union.

**The coalition.** Church leaders led the Ecumenical Coalition of the Mahoning Valley, a group that brought together people of different churches, and its members took up Dickey's plan.

**The answer.** Officials in President Carter's government first signaled that they supported the guarantees. In 1979 officials of the Economic Development Administration, a federal agency, turned the guarantees down, and the mill stayed closed. Accounts differ a little on when officials first signaled support, and all of them agree on the refusal and the closing.

Dickey and the coalition spread the idea of workers owning their own workplaces among unions and their members.

### The farm crisis of the 1980s

The owners of about 300,000 farms defaulted in the 1980s, which means they could not repay their loans. About 300 farm banks failed.

**Borrowing.** Farmers sold more crops abroad in the 1970s, planted more of their land and borrowed at low rates of interest, the extra money a borrower pays a lender for a loan. They borrowed against the value of their land.

**Higher rates.** Then officials of the Federal Reserve, the country's central bank, which sets interest rates for other banks, raised interest rates to bring down inflation, which passed 13 percent in 1979 and 1980. Under their chairman, Paul Volcker, the rate they set for banks passed 20 percent in 1981. Every new loan now cost farmers more than the cheap loans of the 1970s.

**The grain embargo.** After Soviet troops invaded Afghanistan, President Jimmy Carter stopped many sales of American farm goods to the Soviet Union, the main rival of the United States. With his order of January 4, 1980, he canceled contracts for about 17 million metric tons of wheat, corn and soybeans (a metric ton is about 2,205 pounds). Farmers lost those sales abroad, and exports fell.

With loans costing more and fewer crops sold abroad, the land that farmers had borrowed against lost value. In parts of the Midwest, farmland lost up to 60 percent of its value from 1981 to 1986. Farm debt reached about 215 billion dollars by 1984, double the debt of 1978.

**Farm Aid.** Willie Nelson, John Mellencamp and Neil Young played the first Farm Aid concert at Memorial Stadium in Champaign, Illinois, on September 22, 1985. About 80,000 people came, and the three musicians raised more than 7 million dollars for farm families.

### The 1980s and 1990s

Income tax rates on the highest incomes fell in the 1980s. Under the Economic Recovery Tax Act of 1981, President Reagan's tax cut, the top income-tax rate, the tax on each dollar of income above a high level, fell from 70 percent to 50 percent. Under the Tax Reform Act of 1986, it fell to 28 percent.

Inflation fell from 13.5 percent in 1980 to between 3 and 4 percent by the middle of the 1980s. The national debt, the total that the federal government owes on money it has borrowed, roughly tripled during the 1980s.

**The long boom.** The country went 120 months in a row without a downturn, from March 1991 to March 2001. A stretch of growth like this is called an expansion, and it was the longest on record until then, according to the National Bureau of Economic Research, the group of economists that dates the country's booms and downturns.

Unemployment fell to 3.9 percent in the fall of 2000. In the government's budget years of 1998 through 2001, federal tax money coming in was more than federal spending, which is called a budget surplus.

The NASDAQ index, a single number built from the stock prices of many companies, among them many technology companies, rose about 600 percent from 1995 to March 2000.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 8 minutes**

Three recessions have come since 2000, stretches of months when output falls and people lose their jobs. The longest ran from December 2007 to June 2009, after home prices crashed. In that crash lenders foreclosed on homes, taking them because the borrowers could not keep up the loan payments. They foreclosed on Black and Latino families at higher rates than on white families.

**Where things stand.** The unemployment rate was 4.1 percent in August 2026, and about 86 of every 100 jobs outside farming were in services. From April to June 2026, the richest tenth of households held about 69 of every 100 dollars of household wealth, and the poorer half held about 2.

### The dot-com crash

Technology stock prices crashed from 2000 to 2002. The NASDAQ index peaked at 5,048 on March 10, 2000, and by October 2002 it had fallen about 78 percent. The boom and the crash are called the dot-com bubble, after companies that did business on the internet: prices climbed far above what the companies were worth and then fell. A recession followed. It lasted eight months, from March to November 2001.

### The crash of 2008

The Great Recession, from December 2007 to June 2009, began with a crash in home prices. Home prices rose for years before the crash, and lenders made home loans, called mortgages, that many borrowers could not repay. Bankers bundled many of these mortgages together into investments and sold the investments as safe. When home prices fell, the investments failed, and some of the biggest financial firms began to fail too.

**Lehman Brothers.** The financial firm Lehman Brothers failed on September 15, 2008, owing about 619 billion dollars. It was the largest bankruptcy, the court process for a person or company that cannot pay its debts, in the country's history. It was the same firm that the Lehman brothers began in Alabama, trading cotton grown by enslaved people.

**The rescue.** Members of Congress passed a rescue plan for financial firms in October 2008, the Troubled Asset Relief Program, or TARP, worth up to 700 billion dollars. Treasury officials paid out about 443 billion dollars under it, and the firms that got the money paid most of it back.

Employers cut about 8.7 million jobs in the Great Recession, and unemployment peaked at 10.0 percent in October 2009. Lenders foreclosed on about 3.8 million homes from 2007 to 2010, and they kept taking homes for years after. Counting those later years, estimates for the whole crisis run from 7.7 million to 10 million homes.

### Who lost homes and wealth

Black and Latino homeowners lost their homes at higher rates than white homeowners, and they lost more of their wealth. Latino and Hispanic both name Americans whose families came from Spanish-speaking countries, and African American is another name for Black Americans.

**The foreclosure counts.** The Center for Responsible Lending, a research group that campaigns on lending, studied the people who took out home loans from 2005 to 2008. By 2010, lenders had foreclosed on about 8 percent of the African American borrowers in that group and 8 percent of the Latino borrowers, against 4.5 percent of the non-Hispanic white borrowers. Because there were more white borrowers, white families still lost more than half of all the homes that lenders took.

**Countrywide.** Lawyers at the Justice Department said that from 2004 to 2008, Countrywide Financial, a mortgage lender, charged at least 200,000 qualified Black and Latino borrowers higher fees and rates or steered them into subprime loans, loans with higher interest rates meant for borrowers that lenders think are more likely to fall behind.

Bank of America had bought Countrywide, and in December 2011 its officers agreed to pay 335 million dollars in a settlement, an agreement to pay money to end a legal case. It was the largest settlement up to that time in a case about lenders treating borrowers unfairly because of their race.

**Wells Fargo.** The Justice Department's lawyers said Wells Fargo charged Black and Latino borrowers higher rates and fees, and steered some into subprime loans when they qualified for regular ones. The lawyers said at least 34,000 borrowers were treated this way from 2004 to 2009.

Officers of the bank agreed on July 12, 2012, to pay at least 175 million dollars. Of that, 125 million dollars went to borrowers, and 50 million dollars went to help with down payments, the part of a home's price that the buyer pays at the start.

Assistant Attorney General Tom Perez said that a Black borrower in the Chicago area with one kind of Wells Fargo loan paid on average 2,937 dollars more than a similar white borrower. Wells Fargo's officers denied that the bank discriminated, treating people unfairly because of their race, and said they settled to avoid a fight in court.

**What families lost.** Researchers at the Pew Research Center reported in 2011 on wealth, or net worth, what a household owns minus what it owes. From 2005 to 2009, with the rise in prices taken out, the wealth of the typical Hispanic household fell 66 percent. For the typical Black household it fell 53 percent, and for the typical white household 16 percent.

The typical white household had 113,149 dollars in wealth in 2009. That was 20 times as much as the typical Black household had, and 18 times as much as the typical Hispanic household had. These were the largest gaps since government officials began collecting the numbers in 1984.

About 35 of every 100 Black households and 31 of every 100 Hispanic households owned nothing or owed more than they owned, against 15 of every 100 white households.

### Ed Neufeldt

> **Who:** A worker who built cabinets for recreational vehicles in Elkhart, Indiana, lost his job in 2008 and introduced President Obama in 2009.
>
> **When and where:** Elkhart, Indiana, from 2008 into the middle of the 2010s.

**He built RV cabinets for 32 years, then lost his job.**

Ed Neufeldt worked at Monaco Coach, a plant in Elkhart, Indiana, until the fall of 2008. The plant built RVs, recreational vehicles that are homes on wheels, and Elkhart was known as the "RV capital of the world." As the RV plants shut, unemployment in Elkhart's county went from about 5 percent to nearly 20 percent in about a year.

**The president's visit.** Neufeldt introduced President Obama at a town hall meeting in Elkhart on February 9, 2009. Obama was on his first trip to promote the stimulus bill, a plan to spend federal money to bring back jobs.

Reporters from ProPublica, NPR and NBC News followed Neufeldt for years. He worked three low-wage jobs, and later he got a factory job again. NPR reporters visited him again in 2015 and 2016.

### The long recovery and the shift to services

The recovery after 2009 was slow at first, with years of high unemployment. It then became the longest expansion in the country's records, which go back to 1854. It lasted 128 months, from June 2009 to February 2020, and the National Bureau of Economic Research announced these dates on June 8, 2020.

**Gig work.** Researchers at the Pew Research Center found that by August 2021, 16 percent of American adults had earned money at some time through an online gig platform, an app or a website that connects workers with short, one-time jobs.

**Where the jobs are.** The country had 159.1 million jobs outside farming in August 2026. About 12.6 million of them, about 8 percent, were in manufacturing, and about 137.5 million, about 86 percent, were in services, counting government jobs. The Bureau of Labor Statistics, the government office that counts jobs and prices, gave these numbers. They are early figures, and the bureau's staff can still change them.

### 2020 and the price rises after

The shortest recession on record lasted two months, from February to April 2020, as the COVID-19 pandemic, a disease that spread around the world, began. Unemployment reached 14.8 percent in April 2020.

**The CARES Act.** Members of Congress passed the CARES Act, a relief law of about 2 trillion dollars, on March 27, 2020. It was the largest relief law up to that time. GDP fell at a yearly rate of 31.4 percent from April to June 2020, which means output would have fallen that far in a full year at that speed. From July to September, output rose at the fastest rate on record.

**Prices jump.** Consumer prices rose 9.1 percent in the 12 months to June 2022, according to the Bureau of Labor Statistics, the largest rise since November 1981. By the middle of 2023, prices were rising near 3 percent a year.

Economists disagree about the causes. Some blame breakdowns during the pandemic in supply chains, the chains of factories, ships and trucks that bring goods to stores. Others point to federal relief spending, or to higher energy prices after Russian forces invaded Ukraine.

### The economy in 2026

**Who holds the wealth.** In 2026 the richest tenth of American households held most of the country's wealth, and the poorer half held almost none of it. Economists at the Federal Reserve, the country's central bank, keep the count. Of every 100 dollars of household wealth from April to June 2026, the richest 10 percent of households held about 69 dollars, the next 40 percent held about 29, and the poorer half held about 2.

The same economists also divide the wealth by race. Households they count as white held about 82 of every 100 dollars, Black households about 3, and Hispanic households about 2.

**Jobs and prices.** The unemployment rate was 4.1 percent in August 2026, about 7.0 million people. It was 6.0 percent for Black workers, 4.8 percent for Hispanic workers, 3.7 percent for white workers and 3.2 percent for Asian workers. Consumer prices rose 3.4 percent in the 12 months to August 2026. As of September 2026, the National Bureau of Economic Research had announced no recession since the two months in 2020.

**The three questions, answered**

- How did slavery make money for people far from any plantation? Bankers in London, Amsterdam and New York sold bonds backed by mortgages on enslaved people, Northern companies insured their lives, and Boston mill owners spun the cotton that enslaved people grew. Rhode Island merchants sent out ships that carried more than 100,000 Africans into slavery.
- What happened to ordinary families when a boom turned into a crash? Judges jailed debtors in 1819, creditors sold enslaved families apart in 1837, one worker in four had no job by 1933, and lenders took 7.7 million to 10 million homes in the crisis that began in 2007. In the 1930s and after 2007, Black families lost jobs and homes at higher rates than white families.
- When did the national government start helping people who lost their jobs? In the 1930s. Before 1933 the federal government paid no unemployment insurance or old-age pensions, and members of Congress set up both in the Social Security Act of 1935, though farm and domestic workers had to wait until 1950 and 1954.

**What changed:** People here went from trading by barter, with no money at all, to working for wages, and by 2026 about 86 of every 100 jobs outside farming were in services.

**Five dates to keep**

- 1614: John Rolfe sends his first tobacco to London.
- 1860: Census takers count 3,953,760 enslaved people.
- October 29, 1929: Stock prices fall hard on Black Tuesday.
- August 14, 1935: President Roosevelt signs the Social Security Act.
- September 15, 2008: Lehman Brothers fails.

**Not known:** Nobody kept a regular count of the jobless in 1837, in 1893 or in the early 1930s, so every figure for them is a later estimate.

**Where to go:** Lowell National Historical Park, in Lowell, Massachusetts, tells the story of the Lowell mills and the slave-grown cotton they spun.

**Next:** Chapter 17, Money. It follows coins, paper dollars, banks and the Federal Reserve.
