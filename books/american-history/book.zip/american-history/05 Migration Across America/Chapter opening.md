# Chapter 5: Migration Across America

**Chapter 5 of 37 · Migration Across America · 10 eras · about 75 minutes**

**Many of the biggest moves across this land were forced or driven. Soldiers marched whole nations west, and slave traders and enslavers forced more than a million enslaved people south. Later, about 6 million Black Southerners went north to get away from mob killings and from Jim Crow laws, the laws that kept Black and white people apart.**

In about 1805, in Maryland, a slave trader from Georgia locked an iron collar around the neck of a man named Charles Ball. A padlock fastened the collar to a chain about 100 feet long. Fifty-one other people were locked to the same chain, and the trader handcuffed the men in pairs. He had just bought Ball away from his wife and children. The line of people walked south for more than a month, to Columbia, South Carolina.

This chapter follows people moving across the land that became the United States, from the first walkers out of Asia to the families who left New Orleans after Hurricane Katrina in 2005. Some went because they chose to: a church walking to the Connecticut River, wagon families on the Oregon Trail, homesteaders on the Great Plains. Others were driven out: the Acadians, the Tuscarora, the Cherokee, the Navajo, Japanese Americans in 1942. In each move, watch who decided that people would go, and whose land they went to. Before 1900 that land almost always belonged to a Native nation.

**Three questions this chapter answers**

- How did horses reach the Native nations of the Plains?
- How many Cherokee died when soldiers forced them west?
- Why did about 6 million Black Americans leave the South between 1910 and 1970?

**Five minutes?** Read "Indian removal and the Trail of Tears" in 1800 to 1850, the Rebecca Neugin story after it, and the next section, "The overland trails."

**Can skip:** "Seasonal rounds and trade paths", "The cattle drives", "The frontier line disappears from the census, 1890". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 2 minutes**

People were moving across this land for thousands of years before any European saw it. The first people came on foot from Asia during the ice age, and their descendants kept moving. Some built towns and later left them. Some nations traveled south over a long time, and many families moved with the seasons to hunt, fish and gather food.

Hundreds of Native nations lived here. There were no horses and no wagons. Trails and trade paths crossed the continent, and later newcomers followed many of them.

### Cahokia and Chaco Canyon: towns people built and left

Cahokia was the largest town north of Mexico. It stood on the Mississippi River, on the Illinois side, near where the city of St. Louis is today. People lived there from about the year 700 to about 1400. Around 1100, between 10,000 and 20,000 people lived in the city, about as many as lived in London at the time. Some estimates put as many as 50,000 people in the area around it.

Most of Cahokia's people had moved away by about 1350, and by the 1400s the town was nearly empty. Nobody knows for sure why they left. The main explanations are floods, a shortage of wood and food, and drought, a long stretch with little or no rain. No single cause has been settled.

Chaco Canyon, in what is now New Mexico, was a center of the Ancestral Puebloan people, the ancestors of today's Pueblo peoples. People started to leave the canyon around 1140, after a run of bad droughts, and most had gone by the end of the 1100s. They moved out and joined the Pueblo communities of the Southwest.

### The Navajo and Apache move south

The ancestors of the Navajo and the Apache came from the far north, from what is now western Canada and eastern Alaska. The Navajo call themselves the Diné. Over a long time, groups of them moved south along the edge of the Rocky Mountains and the Great Plains toward the Southwest. Their long move is called the Athabascan migration.

When they arrived in the Southwest is disputed. Many accounts place their arrival between the 1400s and about 1525. Others argue that they came earlier, in the 1200s.

### Seasonal rounds and trade paths

Many peoples moved in a pattern called a seasonal round, a yearly circuit from one camp to the next. Over a year, a family moved between its fishing places, its hunting grounds and the spots where wild plants ripened.

Trade goods moved across the land as well. Traders passed turquoise, seashells, copper and obsidian, a black glass made by volcanoes, from nation to nation along trade paths. Some of these goods ended up hundreds of miles from where they were found.

## The 1500s

**Era 2 of 10 · The 1500s · about 4 minutes**

Spanish colonists brought two things north in the 1500s that later changed how people moved across this land: horses, and families who came with wagons and herds to stay. The whole land from coast to coast was still Native land. Europeans reached its edges, but no crowds of settlers moved across the interior. The first colony that came over land to stay arrived at the very end of the century, when Juan de Oñate led Spanish colonists north into what is now New Mexico in 1598.

### Why there were no horses here, and how they came back

Horses lived in North America during the ice age and died out here thousands of years ago. Spanish sailors and colonists brought them back.

Christopher Columbus carried horses on his second voyage across the Atlantic, in 1493. Spanish expeditions, groups of men sent out to explore, then brought horses onto the mainland. Francisco Vázquez de Coronado's expedition had them from 1540 to 1542, and Juan de Oñate's colonists brought them to New Mexico in 1598. In the next century, horses changed how people lived on the Great Plains.

### Oñate's colony on the Camino Real, 1598

Juan de Oñate and his colonists left Santa Bárbara in January 1598. It was a town in northern New Spain, the Spanish colony that included Mexico. Earlier Spanish expeditions had followed the Conchos River north. Oñate's column, the long line of people, wagons and animals, cut straight across the Chihuahuan Desert instead.

The column reached the Rio Grande in late April, at El Paso del Norte, near where El Paso, Texas, and Ciudad Juárez, Mexico, stand today. On April 30, 1598, Oñate claimed New Mexico for Spain in a ceremony called La Toma, which means "the taking." In July he set up the colony's headquarters at San Juan Pueblo, which its people call Ohkay Owingeh.

**Whose land.** The colonists moved onto the homeland of the Pueblo peoples. Families from Chaco Canyon had joined the Pueblo communities after the droughts of the 1100s, about 400 years earlier.

The road the colonists traveled was later called El Camino Real de Tierra Adentro, the royal road of the interior. It ran from Mexico City to northern New Mexico, and Oñate's march made it more than 600 miles longer. Its stretch inside the United States is a National Historic Trail today.

**Two colonies by sea.** Before Oñate, two groups of Spanish colonists had come to what is now the United States by ship. Tristán de Luna y Arellano brought about 1,500 people in 11 ships to Pensacola Bay, in what is now Florida, in 1559. They were soldiers, colonists, enslaved people and Aztec allies.

A hurricane sank many of the ships a month later, and Spanish ships took the survivors back to Mexico in 1561. Pedro Menéndez de Avilés founded St. Augustine, also in Florida, with about 600 settlers in 1565.

### Juan de Oñate

> **Who:** The Spanish leader of the first known colonists to travel over land, with families, wagons and herds, into what is now the United States, and the man who ordered the attack on Acoma Pueblo.
>
> **When and where:** From Santa Bárbara in northern New Spain to San Juan Pueblo (Ohkay Owingeh), New Mexico, January to July 1598. Acoma Pueblo, December 1598 to February 1599.

**He sentenced each Acoma man over 25 to lose a foot.**

Oñate's column had about 400 men, about 130 of them with their families, and 83 wagons and carts. The colonists drove more than 7,000 head of livestock, or farm animals, with horses among them. The colony included soldiers, farmers, workers, servants and Franciscan friars, men who belong to a Catholic religious order. Enslaved people walked in the column too. The surviving records do not say how many.

**Acoma.** Oñate's nephew, Juan de Zaldívar, went to Acoma Pueblo in December 1598 with about thirty soldiers to demand food. In the Acoma people's own account, the soldiers also raped an Acoma woman, forcing her into sex. The Acoma killed Zaldívar and between eleven and fourteen of his men.

Oñate sent Zaldívar's brother, Vicente de Zaldívar, with about seventy soldiers in January 1599. Acoma stands on top of a mesa, a steep hill with a flat top. The soldiers climbed it, killed Acoma men, women and children, and burned much of the town.

Nobody counted the Acoma dead at the time. Estimates run from about 300 to about 1,500. The number given most often is about 800, which Pueblo leaders gave in a 2023 statement from the All Pueblo Council of Governors, the governors who lead the 20 Pueblo nations of New Mexico and Texas.

**The sentences.** The soldiers captured about 500 people. In February 1599 Oñate sentenced them in four groups. Each man over 25 was to have a foot cut off and do twenty years of forced work as a slave. Boys and men from 12 to 25 got twenty years as slaves. Girls and women over 12 got the same twenty years. Children under 12 were to be taken from their families and given to the friars.

The Acoma's own account, passed down since 1599, gives the number of men whose feet were cut off as 24, and so do news reports. Reporters for AP and NPR, and Pueblo leaders, say it was the right foot. Two historians, Marc Simmons and John Kessell, doubt that the feet were ever cut off. Simmons had once written that they were.

A National Park Service page on the Camino Real states that about 70 Acoma girls were sent down the road to convents, homes for nuns, in Mexico. The same page states that probably none of the girls ever came home. Pueblo leaders count 60 children taken to Mexico, and they say none came home.

## The 1600s

**Era 3 of 10 · The 1600s · about 5 minutes**

Native nations of the Plains and the Rocky Mountains got horses in this century, and that changed how they moved more than anything else did. People on horseback could travel farther and faster than on foot, and they could follow the buffalo herds.

Along the Atlantic coast, English, Dutch and other colonists settled at places like Jamestown, founded in 1607, and Plymouth, founded in 1620. Almost none of them went far inland. The Appalachian Mountains were hard to cross, and many Native nations lived on the far side of them. The few colonists who did move inland went short distances. Thomas Hooker's group walked from Massachusetts to the Connecticut River in about two weeks.

### How did horses spread to the Plains nations?

Two accounts explain how horses spread, and the timing is still not settled. In the older account, horses passed north through trade after the Pueblo Revolt of 1680. In the newer one, many nations already had horses by the early 1600s.

**The older account.** In this account, Pueblo peoples drove the Spanish out of New Mexico in 1680, and the Spanish left their horses behind. The trouble began with the Spanish governor of New Mexico, Juan Francisco Treviño. In 1675 he ordered the arrest of 47 Pueblo medicine men, who were religious leaders, on a charge of sorcery, or witchcraft. Spanish officials sentenced four of them to be hanged. They hanged three, and the fourth killed himself. Treviño's men whipped the others in public and put them in prison.

Pueblo people went to Santa Fe and demanded that the prisoners be let go, and the Spanish freed them. One of the freed men was Popé, a religious leader of the Tewa, one of the Pueblo peoples. In 1680 Popé led the Pueblo peoples of what is now New Mexico in a rising against Spanish rule. They killed about 400 Spaniards and drove the rest out of New Mexico for more than a decade.

The horses the Spanish left behind, perhaps more than 1,500, were the largest number of horses to pass into Native hands at one time. In the older account, these horses then moved north and east through trade. The Ute, Navajo and Apache got them first. Over the next few decades horses reached many other nations, as far as the northern Plains.

**The newer account.** It comes from a study published in the journal *Science* in 2023. The archaeologist William Taylor, a scientist who studies the past through the things people left behind, led it, working with Lakota, Comanche, Pawnee and other Native partners. The team tested horse bones from Kansas, New Mexico and Wyoming to find their age. Some dated from the 1500s and 1600s.

Marks on the teeth and bones showed that people had put bridles on these horses and fed them corn, so people were keeping and caring for them. The team found that many nations across the Plains and the Rocky Mountains had horses by the early 1600s, decades before the Pueblo Revolt. The finding matches what Native people have long said in their nations' own histories, passed down by word of mouth.

Over the next century, horses changed how the Comanche, Lakota, Cheyenne and the other Plains nations hunted and traveled.

### The first colonial moves inland

Two English ministers moved out of the colony of Massachusetts Bay in 1636 and started new towns in what are now Connecticut and Rhode Island. Thomas Hooker chose to go, and his story follows this section.

**Roger Williams.** The other minister did not choose. The leaders of Massachusetts ordered Roger Williams out of the colony for what he preached: he taught that the government should not force religious beliefs on people. He fled in the winter rather than be sent back to England, and Wampanoag people helped him survive.

With help from Wampanoag and Narragansett people, Williams then traveled by canoe to a freshwater spring at a place called Moshassuck. He settled there with the permission of the Narragansett and named the place Providence. In 1638 two Narragansett sachems, or leaders, named Miantonomi and Canonicus signed a deed, a paper that says who owns a piece of land, for the settlement.

### Thomas Hooker

> **Who:** A minister who led about 100 members of his church from Massachusetts to the Connecticut River, where they settled Hartford.
>
> **When and where:** From Newtown (now Cambridge), Massachusetts, to Hartford, Connecticut, May and June 1636.

**His church walked for two weeks, living partly on milk from 160 cows.**

Thomas Hooker was the pastor of the church at Newtown, the town that is now Cambridge, Massachusetts. His church set out on foot for the Connecticut River in May 1636.

They drove 160 cattle with them and lived partly on the cows' milk. They followed Native trails, a route later called the Old Connecticut Path. John Winthrop, a leader of Massachusetts Bay, wrote about the departure in his journal on May 31, 1636: "Mr. Hooker, pastor of the church of Newtown, and most of his congregation (the people of his church), went to Connecticut." Winthrop also noted that Hooker's wife rode on a horse litter, a stretcher carried by horses.

**Whose land.** The place where they settled was Suckiaug, which means "black earth." It was the main village of the River Indians, and their sachem was Sequassen. In 1636 Sequassen and his people signed the land over by deed to Samuel Stone and William Goodwin, two men in Hooker's group. The land ran along the river between the towns of Wethersfield and Windsor, and six miles west of the river.

Nobody wrote the deed into the official land records at the time, and the settlers and the Native owners argued over its terms for generations. The histories of the deed do not say what Sequassen's people received for the land.

Dutch traders had built a fort there, the House of Hope, before Hooker's group came. The town the settlers built is Hartford. In 1639 the people of Hartford and the towns near it adopted a plan of government called the Fundamental Orders of Connecticut.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 4 minutes**

Settler families began moving inland from the Atlantic coast in the first half of the 1700s, because land near the coast had filled up and grown expensive. They moved into the valleys and hills behind the older settlements, an area colonists called the backcountry. The main road inland was the Great Wagon Road.

Native nations were moving too. After a war with colonists in North Carolina, the Tuscarora walked north to New York. On the southern Plains, the Comanche moved in on horseback and took control, and many Apache there fled south. The country beyond the Appalachian Mountains was still Native land.

### Who traveled the Great Wagon Road?

Many of the families on the Great Wagon Road were German or Scots-Irish. The road ran about 730 miles into the backcountry. It started in Philadelphia and went southwest through the Shenandoah Valley of Virginia. Then it ran down through the hill country of the Carolinas, called the Piedmont, toward Augusta, Georgia. Heavy traffic began in the 1720s.

Both groups had come to Pennsylvania. By the time of the Wagon Road, land there had grown costly, so many families moved on. The Scots-Irish were Protestants, Christians whose churches had split from the Catholic Church. Their families had moved from Scotland to the north of Ireland in the 1600s and then on to America. The Germans were called the "Pennsylvania Dutch," from *Deutsch*, the German word for German. Moravians, members of a Protestant church from central Europe, came along the road as well.

**An older path.** The road followed a Native path that colonists called the "Indian Road." When settlers began arriving in the Shenandoah Valley in about 1729, most of the people living near the present-day town of Winchester, Virginia, were Shawnee. Other nations used the valley too, among them the Iroquois, a league of six nations also called the Six Nations or the Haudenosaunee. The valley's north-south trail was a war path between nations to the north and the Catawba nation to the south.

**The Treaty of Lancaster.** Officials sent by Virginia's governor, William Gooch, met Iroquois leaders at Lancaster, Pennsylvania, in 1744. In the treaty they signed there, a written agreement between nations, Gooch's officials bought the Iroquois claim to the valley, meaning their right to the land. Colonists also got the right to use the Indian Road. Accounts of how much the officials paid do not agree.

The Native delegates at Lancaster came from five nations of the Iroquois league, the West Virginia Encyclopedia states. None came from the Shawnee, who lived in the valley. Even more settlers traveled the road after 1744.

### Why did the Tuscarora walk north?

The Tuscarora nation moved about 500 miles north, from North Carolina toward Pennsylvania and New York, after colonists defeated them in war. The move took from 1713 to 1722, and they traveled in stages.

**Neoheroka.** The war ended at Neoheroka, a Tuscarora fort on Contentnea Creek in what is now Greene County, North Carolina. Colonel James Moore of South Carolina led the attack. He commanded militia, colonists called up to fight as soldiers, from both Carolinas, and Native warriors who fought on the colonists' side.

Moore's men laid siege to the fort, which means they surrounded it and kept attacking it, from March 1, 1713. They dug under an outer wall and set the fort on fire. It fell on March 23.

History pages from North Carolina's state government list 950 Native people killed or captured at Neoheroka. They list about 1,000 Tuscarora sold into slavery during the whole war. The colonists and allies who won the war sold these captives, and those state pages do not name who bought them. The colonists' side also forced more than 3,000 other Native people from their homes. About 200 colonists and about 1,000 Native people died in the war.

About 1,500 Tuscarora survivors made the walk north. The Oneida nation sponsored them in the Haudenosaunee league, which means the Oneida backed their joining. In 1722 the Tuscarora became its sixth nation.

### How the Comanche took the southern Plains

The Comanche had moved onto the southern Plains by the early 1700s, and they became the strongest power there. The land they held became known as Comanchería, Comanche country.

Apache groups were already living on the southern Plains. The Handbook of Texas, a history reference, states that by 1700 the Comanche, Wichita and Tejas Indians were "better armed through trade with the French." Those nations took control of the southern Plains, and the Apache began moving southwest. Many Apache, most of all the Lipan and the Mescalero, "fled southward into Central Texas as well as into northern Mexico."

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 7 minutes**

Crowds of American settlers crossed the Appalachian Mountains for the first time in these fifty years, onto land that belonged to Native nations. As many as 300,000 went through the Cumberland Gap into Kentucky and beyond between 1775 and about 1810. After the Revolutionary War ended in 1783, more settlers moved into the Ohio Valley. Members of Congress passed two laws, in 1785 and 1787, that set out how western land would be measured, sold and governed.

**The Acadians.** Farther north, British officers began forcing the French-speaking Acadians out of Nova Scotia, north of the British colonies, in 1755. They forced out about 10,000 to 11,500 people, and about 2,600 to 3,000 of them later made their way to Louisiana.

### The Acadians forced from Nova Scotia, 1755

The Acadians were French-speaking Catholic farm families in Nova Scotia and the land around it, in what is now eastern Canada. Between 14,000 and 18,000 Acadians lived there in 1755. Nova Scotia was a British colony, and Charles Lawrence, its lieutenant governor, was one of the top British officials there.

**The decision.** Lawrence and his council of advisers in Halifax decided on July 28, 1755, to remove the Acadians from the colony. A navy admiral and the colony's top judge sat on the council that day. Some council members had recently come from New England and wanted the Acadians' farmland.

Lawrence had first asked Acadian delegates, men chosen to speak for their villages, to swear loyalty to Britain with no conditions. When they refused, Lawrence and his council had them jailed.

**Grand-Pré.** Lieutenant Colonel John Winslow commanded New England troops. On September 5, 1755, he ordered every Acadian male aged 10 and older at Grand-Pré to gather in the church there at 3 p.m., and he held them there. The order read to them said that their land, houses, cattle and other livestock now belonged to the Crown, meaning the British king. They could keep their money and household goods, and they would be removed from the colony.

Winslow wrote that the order was "very disagreeable to my nature," but that his job was "to obey such orders as I receive." Two other officers led arrests and removals in other districts.

**The plan.** Charles Morris, a New Englander, drew up the plan. Soldiers would surround the churches on a Sunday morning and capture as many men as they could. Then they would break the earth walls that kept the sea off the Acadians' fields, and burn their houses and crops.

New England and British soldiers did burn many Acadian houses, barns and churches that year. Around the Minas Basin, where Grand-Pré stands, Winslow's own list records 698 buildings that the soldiers under him burned by November 1755, most of them houses and barns, and one Catholic church.

**The ships.** When the men refused to go, the soldiers threatened their families with bayonets, blades fixed to the ends of their guns. By the fall of 1755, soldiers had put about 1,100 Acadians on ships bound for three colonies, South Carolina, Georgia and Pennsylvania, the historian James H. Marsh writes. That count includes only the people on ships for those three colonies. Winslow's own table records everyone shipped from the Minas district alone, to all places: 2,242 people, 1,510 of them by his men and 732 by a second company.

British officers and soldiers kept removing Acadians until 1764. One count gives about 10,000 Acadians forced out between 1755 and 1763, and another gives about 11,500 between 1755 and 1764. British ships carried them to the thirteen colonies, to England and to France. Many Acadians escaped into the forests, and British soldiers hunted them for the next five years. In French the forced removal is called *Le Grand Dérangement*, the great upheaval.

**Known:** In one group of about 3,100 Acadians removed in 1758, about 1,649 died by drowning or disease.

**Disputed:** One count puts all the Acadian dead at close to 5,000, from disease, shipwreck or violence, and other counts put the dead at as many as half of those forced out.

### How did the Acadians become Cajuns?

About 2,600 to 3,000 Acadians made their way to Louisiana between 1764 and 1785, and their descendants are the Cajuns. The word Cajun comes from the word Acadian.

Louisiana was then a Spanish colony. The largest group came in 1785, when Spanish officials paid for seven ships that carried 1,596 Acadians from Nantes, in France, to Louisiana. The first of them reached New Orleans on July 29, 1785. The Acadians settled along the bayous, slow-moving streams through low, wet land, and on the prairies west of New Orleans.

### Joseph Broussard (Beausoleil)

> **Who:** An Acadian who fought the British removal of his people, then led one of the first Acadian groups to Louisiana.
>
> **When and where:** Acadia (Nova Scotia and New Brunswick), 1755 to 1762. New Orleans and the Attakapas district of Louisiana, 1765. Born about 1702, died 1765.

**Freed from a British prison, he led about 200 Acadians to Louisiana.**

Joseph Broussard, whom people called Beausoleil, organized armed resistance when British officers began forcing the Acadians out in 1755. He and his men raided British troops. British soldiers captured him and held him at Halifax until 1763. That year Britain and France signed the Treaty of Paris, a peace agreement that ended their war.

**South.** Broussard and about 600 Acadians hired a ship in late 1764 to carry them to Saint-Domingue, the island colony that is now Haiti. He and about 193 to 200 of them sailed on to Louisiana in February 1765 and reached New Orleans late that month. He was one of the first Acadians to settle there.

Colonial officials named him a militia captain on April 8, 1765. They also made him the commander of the "Acadians of the Attakapas," the district around the present-day town of St. Martinville.

A sickness spread through the new settlement that year. Most accounts say it was yellow fever, and Broussard died of it in October 1765. Officials at Parks Canada, the Canadian government office that runs historic sites, have named him a National Historic Person, a title they give to people who were important in Canada's history.

### The Wilderness Road and the Cumberland Gap

The Cumberland Gap is a low notch through the mountains near the place where Kentucky, Virginia and Tennessee meet. In 1775 Daniel Boone and about 30 axmen cut a road through it called the Wilderness Road. As many as 300,000 settlers traveled that road into Kentucky and beyond between 1775 and about 1810. Kentucky filled with settlers and became a state in 1792.

**The deed.** Boone cut the road for Richard Henderson's Transylvania Company, a business its partners formed to buy up what they called "wild lands" and open them to settlers. At Sycamore Shoals on the Watauga River, from March 14 to 17, 1775, Henderson got a deed from Cherokee leaders, among them Attakullakulla, Oconostota and Old Tassel.

The deed covered about 20 million acres between the Cumberland and Ohio rivers, most of Kentucky and part of Tennessee. In return the Cherokee received trade goods, which one estimate values at about 10,000 British pounds.

**Who objected.** Dragging Canoe, Attakullakulla's son, spoke against selling land that the Cherokee nation held in common, and he rejected the sale. Other nations had claims to the land too, among them the Shawnee, who had once lived on part of it. The Tennessee Encyclopedia describes the Cherokee claim as the strongest of these.

By buying the land, Henderson broke a British rule of 1763, the Royal Proclamation, which banned private buyers from buying Native land. Officials in Virginia and North Carolina and members of the Continental Congress, the meeting of leaders from the colonies, all refused to accept Henderson's colony as lawful.

### Into the Ohio Valley, and a grid laid over the land

Settlers moved in large numbers into the Ohio Valley and the Northwest Territory after the Revolutionary War ended in 1783. The Northwest Territory was the land north of the Ohio River that later became the states of Ohio, Indiana, Illinois, Michigan and Wisconsin. It was the land of the Shawnee, Miami, Delaware and other nations, and in the 1790s those nations and the settlers fought each other.

**The grid.** Members of Congress adopted the Land Ordinance, a law, on May 20, 1785. Under it, surveyors, workers who measure land, marked the western land into squares called townships, each six miles on a side, and divided each township into 36 sections of 640 acres. In the law, the members of Congress set aside one section in every township to pay for public schools. Because of that grid, much of the American countryside is laid out in squares today.

Two years later, on July 13, 1787, members of Congress passed the Northwest Ordinance. In it they wrote the rules for governing the territory, set out how parts of it could become new states equal to the original thirteen, and banned slavery north of the Ohio River. Five states later came from the territory.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 14 minutes**

Two kinds of journey crossed the country in these fifty years: families who chose to go west in wagons, and whole nations and enslaved people whom soldiers and slave traders forced to move. The United States about doubled in size in 1803, and by 1850 its land reached the Pacific Ocean. Families drove wagons over the Oregon, California and Mormon trails, and about 300,000 people rushed to California for gold between 1848 and 1855.

**Forced journeys.** United States soldiers drove the Cherokee, Choctaw, Muscogee, Chickasaw and Seminole nations from their homelands in the Southeast. Slave traders and enslavers forced more than a million enslaved Black people to move from the Upper South to the Deep South, in chains or in ships.

### The Louisiana Purchase, 1803

American officials bought about 827,000 square miles of land west of the Mississippi River from France in 1803. The price was 15 million dollars, and afterward the country was about twice as big as before. All or part of 15 later states came from this land.

Thousands of Native people, in dozens of nations, already lived on this land. None of them had a part in the sale. After the purchase, American settlers began moving onto it, into the interior of the West.

### The domestic slave trade: a forced march south

Slave traders and enslavers forced more than one million enslaved people to move from the Upper South to the Deep South between about 1790 and 1860. The Upper South meant Virginia, Maryland, the Carolinas, and later Kentucky and Tennessee. The Deep South meant the cotton lands from Georgia west to Texas.

Traders and enslavers moved about 200,000 people this way every ten years from 1820 to 1860. This trade inside the country was later called the "Second Middle Passage," after the first Middle Passage, the voyage of captured Africans across the Atlantic Ocean.

Traders moved people south in two ways. They marched some on foot in coffles, lines of enslaved people chained together and marched over land. They shipped others down the coast to New Orleans, which had the largest slave market in the country.

**Franklin and Armfield.** The largest slave-trading company in the country was Franklin and Armfield, founded in Alexandria, Virginia, in February 1828. John Armfield bought people in Alexandria. Isaac Franklin sold them in Natchez, Mississippi, and after 1829 in New Orleans. Rice Ballard joined them in the early 1830s and ran their office in Richmond. The partners bought, moved and sold more than 8,500 people, 1,000 to 1,500 a year in their busiest years, the mid-1830s.

Near the end of each summer, the partners sent coffles "in chains over the mountains." Each coffle held from several dozen to several hundred people, and the partners timed it to reach the Deep South for the fall selling season. They also owned three ships fitted to carry enslaved people, the *Tribune*, the *Uncas* and the *Isaac Franklin*. The voyage from Virginia to Louisiana took about three weeks, and at the busiest time one of these ships left every two weeks. The last shipload left in November 1836.

**Sold, or taken along.** Some of these people were sold to traders. Others were forced to move when the enslavers who held them moved to new land and took them along. Historians' estimates of the traders' share run from about 16 percent to about two-thirds. Walter Johnson puts it near the top, at about two-thirds sold and one-third taken along, and Michael Tadman gives 60 to 70 percent for the years after 1808.

### Charles Ball

> **Who:** An enslaved man who was chained into a coffle and marched from Maryland to South Carolina. He later escaped and told his life story.
>
> **When and where:** Sold in Maryland about 1805. Marched to Columbia, South Carolina. His story was printed in Philadelphia in 1837.

**He escaped slavery twice, hiding by day and walking at night.**

The chapter opening describes how a Georgia slave trader chained Charles Ball into a coffle of 52 people in Maryland in about 1805 and marched them for more than a month to Columbia, South Carolina. At Columbia the trader sold Ball again, into Georgia.

**Escape.** Years later Ball escaped and walked north back to Maryland, hiding by day and moving at night. He was captured again and held as a slave. After his second escape he settled near Philadelphia.

Ball told his story to Isaac Fisher, a white abolitionist, someone who worked to end slavery. Fisher wrote it down, and it came out in 1837 as *Slavery in the United States: A Narrative of the Life and Adventures of Charles Ball*. Because Fisher did the writing, the book records Ball's story in Fisher's words. Many of the dates in Ball's life are known only roughly, even his birth, in about 1780 in Calvert County, Maryland.

### Indian removal and the Trail of Tears

President Andrew Jackson signed the Indian Removal Act in 1830. He then directed the removal of the Cherokee, Muscogee (Creek), Choctaw, Chickasaw and Seminole nations from their homelands in the Southeast. Federal troops forced them to Indian Territory, which is now Oklahoma.

**The Choctaw.** Federal troops removed the Choctaw from 1831 to 1833, forcing the first groups out in snow and river ice. Andrew K. Frank, writing for the Oklahoma Historical Society, counts more than 14,000 Choctaw removed and says hundreds died. Other counts give about 15,000 removed and about 2,500 dead.

**The Creek.** After a war with the Creek, United States troops marched the remaining Creek people west in five large groups in August and September of 1836. Soldiers put chains on Creek men taken prisoner in the war and marched them to Montgomery, Alabama, and their families followed in wagons. More than 14,500 Creek were removed. Several hundred died on the way. About 3,200 more died after they arrived, from disease, hunger and exposure, the harm cold and bad weather do to the body.

The steamboat *Monmouth*, carrying about 600 Creek people, was in a collision in October 1837. About half of the Creek on board died.

**The Chickasaw.** Under the Treaty of Pontotoc, signed in 1832, the Chickasaw had to leave their lands in Mississippi. They moved west from 1837, and more than 500 Chickasaw died of smallpox during the removal.

**The Seminole.** Many Seminole in Florida fought removal in a war that lasted from 1835 to 1842. For every four Seminole sent west, US Army soldiers killed one, the National Park Service states. A few hundred Seminole stayed in the Everglades, the swamps of southern Florida, and never surrendered.

**The Cherokee.** The Cherokee removal of 1838 and 1839 is called the Trail of Tears. United States Army troops under General Winfield Scott began rounding up the Cherokee who had not moved west in May 1838. President Martin Van Buren had sent Scott with about 7,000 soldiers, and state militia, part-time soldiers called up by a state, joined them, Georgia's among them. Soldiers took families from their homes and farms, often with no time to pack.

The soldiers held about 16,000 Cherokee in stockades, pens with walls of tall logs, in Tennessee and Alabama. They sent three groups west by river in June 1838. After that, Scott agreed to let John Ross, the Cherokee's Principal Chief, organize the rest. Ross organized fourteen groups, which left between August and December 1838. The walk over land was about 800 miles, and people died on the way from cold, hunger and disease.

**How many died.** The number of Cherokee dead is not settled. The count most often given is about 4,000. The National Park Service's history of the trail states that more than 1,000 people died on the journey itself, and "perhaps several thousand" more died later because they had been forced from their homes.

Higher estimates run from above 5,000, in an article on the History.com website, to about 8,000 or more, twice the usual figure. Russell Thornton, a scholar who studies population, gave that highest estimate in 1984. Andrew K. Frank, writing for the Oklahoma Historical Society, says as many as one in four Cherokee died.

### Rebecca Neugin

> **Who:** A Cherokee woman who, at about three years old, was forced west on the Trail of Tears. She told what she remembered when she was 97 or 98.
>
> **When and where:** Soldiers took her from Georgia in 1838. Interviewed in 1932 in what is now Oklahoma.

**She rode west in a wagon at three and remembered it at 97.**

Soldiers rounded up Rebecca Neugin's family in Georgia in 1838. Her father was Tickaneesky, and her mother was Sallie Ketcher. The soldiers held the family in a camp in Tennessee.

The family started west in September 1838 with the group led by Mose Daniel and George Still. Rebecca and the smaller children rode in a wagon. Her mother, her father and her older brother Dick walked the whole way.

The historian Grant Foreman interviewed her in 1932, when she was 97 or 98 years old and one of the last living people who had made the journey. Her memory of it is one of the few first-hand accounts by a survivor. She died on July 15, 1932.

### The overland trails

Most of the western trails started from towns on the Missouri River, mainly Independence and St. Joseph, in Missouri.

The Santa Fe Trail opened in 1821, when William Becknell led the first trading trip from Missouri to Santa Fe, which then belonged to Mexico. It was mainly a road for traders hauling freight.

The Oregon Trail ran about 2,000 to 2,170 miles, from Independence, Missouri, to the Willamette Valley in Oregon, and the trip took four to six months. About 1,000 people set out on it on May 22, 1843, with about 120 wagons and thousands of oxen and cattle, and they reached Oregon that fall. This trip was called the "Great Migration" of 1843. It is a different event from the Great Migration of Black Southerners in the 1900s, which this chapter describes later.

After it, other families knew that wagon trains could make the whole journey, and hundreds of thousands followed over the next twenty years. From the 1840s on, tens of thousands of them came to the Willamette Valley, where at least twenty Native nations lived, among them the Kalapuya, Molala and Chinook peoples.

The California Trail split off from the Oregon Trail and turned southwest toward California. Traffic on it grew fast after gold was found in 1848.

### How did people die on the wagon trails?

About one in ten people who set out on the wagon trails died on the way, between 20,000 and 30,000 people. Most of the dead had cholera, a disease that causes severe diarrhea and vomiting, or typhoid, a disease that causes a high fever. Both spread through dirty water at crowded camps.

Other emigrants, people leaving one home to settle in another, died in accidents or drowned while crossing rivers. Later stories often showed Native people attacking wagon trains, but most of the emigrants who died on the trails died of disease. Families traveled in groups for safety, in covered wagons pulled by oxen.

### Why the Latter-day Saints moved west

Members of the Church of Jesus Christ of Latter-day Saints, also called Mormons, moved west after armed men attacked them in Missouri and in Illinois.

**Missouri.** Missouri's governor, Lilburn Boggs, ordered on October 27, 1838, that the Latter-day Saints be driven out of the state. If necessary, in the order's own word, they were to be "exterminated," killed off entirely. Three days later about 200 armed Missourians led by Colonel Thomas Jennings attacked the Mormon settlement at Haun's Mill. They killed seventeen or eighteen men and boys. One of the boys, Sardius Smith, was ten years old. No record shows that anyone was ever tried for the killings.

Both sides in Missouri used force that year. The Missouri State Archives records that mobs of older Missouri settlers and armed Mormon groups roamed the countryside. Armed Mormon groups raided the towns of Gallatin and Millport in mid-October 1838 and burned property there. Over the next year, about 8,000 church members left Missouri for Illinois, many of them ragged and stripped of their property, and settled at Nauvoo.

**Illinois.** About 100 men from Illinois militia units broke into the jail at Carthage, Illinois, on June 27, 1844. They killed the church's founder, Joseph Smith, and his brother Hyrum. Five men were tried for the killings, and all five were found not guilty. Vigilantes, people who use force to punish others without any legal right to, then attacked Mormon farms around Nauvoo.

Brigham Young, a leader of the church, planned to move about 15,000 people west. The first wagons crossed the Mississippi River into Iowa on February 4, 1846, and by March 1 about 500 wagons were on the move. More than 70,000 Latter-day Saints had traveled the Mormon Trail by 1869. Some of the poorer groups pulled handcarts, small two-wheeled carts pulled by hand, instead of driving wagons.

**Whose land.** The Salt Lake Valley lay between the lands of the Ute, to the south, and the Shoshone, to the north. A few Native people crossed the valley itself, but none had camps there. The Ute, Goshute, Shoshone, Paiute and Navajo peoples lived in what is now Utah, and their homelands had been there for thousands of years.

### Brigham Young

> **Who:** The Latter-day Saint leader who led the first company of Mormon emigrants to the Salt Lake Valley.
>
> **When and where:** From Winter Quarters, in what is now Nebraska, to the Salt Lake Valley, in what is now Utah. Arrived July 1847.

**Three of the men in his first company were enslaved.**

The Saints called Young's first company the vanguard company, the group that goes ahead of the rest. About 148 people traveled in it in 1847, about 1,300 miles from Winter Quarters, a camp in what is now Nebraska, to the Salt Lake Valley.

Counts of who was in the company differ. One count lists 143 men, 3 women and 2 children. Three of the men were enslaved Black men: Hark Lay, Green Flake and Oscar Crosby.

**The three men.** William Lay and his wife, Sytha, held Hark Lay in slavery and took him along. James Madison Flake held Green Flake in slavery, and William Crosby held Oscar Crosby, according to the Century of Black Mormons project at the University of Utah. The two enslavers sent Green Flake and Oscar Crosby ahead to build shelters and plant crops for their white families, who came later.

The three enslaved men hunted for the travelers, guarded the animals, and went into the Salt Lake Valley on July 22, 1847, ahead of most of the company. The rest reached the valley that July, and Young himself arrived on July 24.

### New land from Mexico, and the Gold Rush

A journalist named John O'Sullivan wrote the phrase "Manifest Destiny" in the *Democratic Review* in 1845. It named an idea that many Americans held: that the United States was meant to spread across the continent to the Pacific Ocean. People used the idea to argue for moving west and for going to war with Mexico.

**The Mexican Cession.** The Mexican-American War lasted from 1846 to 1848 and ended with the Treaty of Guadalupe Hidalgo. In it, Mexican officials, after losing the war, gave up California, Nevada and Utah, most of Arizona and New Mexico, and parts of Colorado and Wyoming. The land they gave up is called the Mexican Cession. Texas had already been annexed, made part of the United States, in 1845. In 1846 officials of the United States and Britain agreed on the border of Oregon.

**Gold.** Gold was found at Sutter's Mill in California in early 1848, and the rush came in 1849. About 80,000 people, called forty-niners, arrived that year. From 1848 to 1855 about 300,000 people came to California, about half by sea and about half over land on the California Trail.

California's population, not counting Native people, grew from about 14,000 in 1848 to about 250,000 in 1852. San Francisco grew from about 200 people in 1846 to about 36,000 in 1852.

**Whose land.** The forty-niners arrived on the land of California's Native nations. About 150,000 Native people lived in California in 1848, and by 1870 only about 30,000 were left, about 120,000 fewer. The historian Benjamin Madley documents the causes: killings, kidnapping, forced labor, disease, hunger, and newcomers driving Native people off their land.

Vigilantes and United States Army soldiers killed 1,000 or more Native people between December 1849 and May 1850. On the last day of 1854, 116 volunteer militiamen attacked the Tolowa people and killed hundreds of them. One militiaman died. Madley documents that state and federal officials took part in the killings, and that taxpayers paid for militia campaigns.

**If you remember one thing:** The country grew to the Pacific in these fifty years, and soldiers and slave traders forced hundreds of thousands of people to move across it.

In 1800: the United States ended at the Mississippi River, and the Cherokee, Choctaw, Muscogee, Chickasaw and Seminole lived in their homelands in the Southeast.

In 1850: the country reached the Pacific, soldiers had forced those five nations to Indian Territory, and wagon trains had carried families to Oregon, Utah and California.

**Next:** After 1850, settlers claimed free farmland on the Great Plains, and soldiers forced the nations who lived there onto reservations.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 15 minutes**

Settlers filled the Great Plains and the far West after 1850, and United States soldiers forced the Native nations who lived there onto reservations, areas of land that federal officials set aside for them, often far from their homelands. In 1864 soldiers marched about 8,500 Navajo people more than 300 miles to one of them.

**Free land and fast travel.** Under a law of 1862, settlers could claim free farmland, and they filed about 4 million claims under it. After 1869 a railroad could carry them across the country in about a week. Tens of thousands of Black Southerners also moved west, to Kansas, to get away from violence and cheating in the South. By 1890 the officials who counted the country's population no longer found a clear line between settled land and thinly settled land in the West.

**Still on the trail.** Wagon trains kept rolling west on the Oregon Trail after 1850. One family that set out in 1853 was Amelia Stewart Knight's.

### Amelia Stewart Knight

> **Who:** A wife and mother who kept a diary, day by day, of her family's wagon journey on the Oregon Trail.
>
> **When and where:** From Monroe County, Iowa, to the Willamette Valley near Milwaukie, Oregon Territory, April to September 1853.

**Her diary says nothing of her pregnancy until the baby came.**

Amelia Stewart Knight, her husband and their seven children left Monroe County, Iowa, for Oregon in April 1853. She was pregnant, and she kept a diary of the trip.

Her diary records rain and mud, dust, sick children and hard river crossings. It also records the daily work of handling the wagons and the cattle.

The family reached Oregon on September 17, 1853. The next day she gave birth to her eighth child, a son named Adam.

### Why were the handcart companies trapped in the snow?

More than 1,000 Latter-day Saint emigrants set out late in the season in 1856 to walk to Salt Lake City pulling handcarts, small carts they pulled by hand. Church leaders urged them to go forward that late in the year, even after one of their own leaders, Levi Savage, warned that snow would catch them. Snow trapped many of them in what is now Wyoming. Counts of the dead run from about 170 to about 250.

The emigrants traveled in two companies. The Willie company, about 500 people, left Florence on August 17, and the Martin company left on August 27. Florence was in Nebraska Territory, land the United States governed that was not yet a state.

An early blizzard struck on October 19, 1856, just after the Martin company had waded across the North Platte River, near where Casper, Wyoming, is today. More than 300 rescuers came from Salt Lake with wagons, and they brought the survivors in through November.

Counts of the dead differ. Modern counts give about 67 to 77 dead in the Willie company and about 103 to 150 in the Martin company. Older accounts say about 200 to 250 people died in the stranded companies and the wagon trains traveling with them.

### Levi Savage

> **Who:** A leader in the Willie handcart company who warned the emigrants not to leave so late, then stayed with them through the blizzards. His journal records what happened.
>
> **When and where:** From Florence, Nebraska Territory, to Salt Lake City, August to November 1856. Born 1820 in Ohio.
>
> **Movie:** *17 Miracles* (2011), a film directed by T. C. Christensen about the Willie handcart company. It draws on Savage's journal.

**He warned that leaving so late would bring snow and deaths.**

Levi Savage was 36 and one of the Willie company's sub-captains, the leaders under the captain. At a camp meeting at Florence on August 13, 1856, he spoke to the roughly 500 emigrants. They still had more than 1,000 miles to go, and he urged them to wait until spring.

In his journal, Savage wrote that most of the emigrants still meant to go on if the church's leaders said go. At later meetings, church leaders urged them to go forward whatever happened. Out on the trail on September 12, the church leader Franklin D. Richards scolded Savage "very severely in open meeting for his lack of faith in God."

Savage went with the company anyway, and when the blizzards came he worked through them to keep people alive. His journal survives, and most modern accounts of the Willie company rely on it.

### The Weeping Time, 1859

The domestic slave trade went on through the 1850s. Its largest single sale took place at the Ten Broeck Race Course near Savannah, Georgia, on March 2 and 3, 1859. Pierce Mease Butler sold between 429 and 436 enslaved men, women and children there to pay his gambling debts. The sale brought him $303,850. It rained hard on both days.

Joseph Bryan, a broker who arranged sales for others and the largest slave dealer in Savannah, ran the sale. For weeks he advertised it in newspapers across the South, from Richmond to New Orleans. Mortimer Thomson, a reporter for the *New York Tribune*, came to the sale dressed as a buyer and wrote a long account of it. The surviving accounts do not say where the buyers took the people they bought.

**Sold in families.** Butler required that people be sold in "families" as far as possible, and Bryan's advertisement promised that they would be "sold in families." Thomson told the story of a 23-year-old man named Jeffrey, who planned to marry a woman named Dorcas. Because they were not married, they could not be sold as a family. Jeffrey begged his buyer, "Please buy Dorcas," but she was being sold with her family of four and could not be bought alone, and another buyer took her. Parents were also separated from children at the sale. Black Georgians remembered the sale as "the weeping time."

### Free land and the railroad

President Abraham Lincoln signed the Homestead Act on May 20, 1862. Under it, an adult who headed a household could claim up to 160 acres of public land for free, and after living on the land and farming it for five years, the settler owned it. Federal officials had taken much of that land from the Native nations who lived on it. Women could claim land. After the Civil War, freed people could claim land too, and so could immigrants who planned to become citizens.

Settlers filed about 4 million claims over the years the law was in force. Settlers and other private owners got about 270 million acres this way, about 10 percent of all the land in the United States. Many settlers moved onto the Great Plains to claim land under the law.

**The railroad.** The first railroad across the country was finished at Promontory Summit, Utah, on May 10, 1869. By wagon, a trip from coast to coast took four months or more, and by train it took about a week. Under the Pacific Railroad Act, which Lincoln signed in 1862, each railroad company got 6,400 acres of federal land for every mile of track it built. The railroads' owners sold that land to settlers, and their trains carried settlers and immigrants west by the trainload.

### The Long Walk of the Navajo, 1864

United States soldiers forced more than 10,000 Navajo people from their homeland in what is now Arizona and New Mexico from 1863 to 1866. General James Henry Carleton ordered Colonel Christopher "Kit" Carson to make the Navajo surrender.

**Burning the food.** Carson's troops, guided by Ute scouts and warriors, began burning Navajo fields in August 1863. They took more than 5,000 sheep, goats and mules, and they destroyed more than 75,000 pounds of wheat and the Navajo peach orchards.

**The march.** Starving, 6,000 Navajo had gathered at Fort Canby and Fort Wingate by March 1864. Soldiers then marched about 8,500 people more than 300 miles to the Bosque Redondo reservation at Fort Sumner, New Mexico. The walk took from 18 to 40 days, and the soldiers gave them food planned to last 8 days. This march is known as the Long Walk.

About 200 people died on the march, in winter. Navajo accounts passed down in families say soldiers shot people who could not keep up, among them old people, sick people and pregnant women.

Soldiers held more than 8,000 Navajo and Mescalero Apache people at Bosque Redondo, and thousands more died there. On June 1, 1868, Navajo leaders signed a treaty with the United States, and under it the Navajo could go home.

### Reservations on the Plains

Through the 1870s and 1880s, soldiers forced many nations of the Great Plains onto reservations. In the Treaty of Fort Laramie of 1868, United States officials had set aside the Great Sioux Reservation, all of present-day South Dakota west of the Missouri River, the Black Hills included, "for the absolute and undisturbed use" of the Lakota.

After soldiers on an Army expedition reported gold in the Black Hills in 1874, federal officials ignored the treaty. In December 1875 they ordered the Lakota bands in their winter camps to move onto the reservation by January 31, 1876, and then they sent the Army against the bands that stayed out.

### Laura Ingalls Wilder

> **Who:** The author of the Little House books. As a child she moved with her family by covered wagon again and again.
>
> **When and where:** Born February 7, 1867, near Pepin, Wisconsin. Family moves from 1869 to 1879. Her own last move, to Mansfield, Missouri, in 1894.
>
> **Movie:** *Little House on the Prairie* (NBC series, 1974 to 1983). It ran for nine seasons and 205 episodes, with Michael Landon as Charles Ingalls. It is loosely based on the books.

**Her family's Kansas cabin stood on land that belonged to the Osage.**

Laura Ingalls Wilder's family moved six times between 1869 and 1879. In 1869 they went to Montgomery County, Kansas, near the town of Independence. Their cabin stood on the Osage Diminished Reserve, land that still belonged to the Osage Nation, and the family had no right to be there. They left in 1871 and went back to Pepin, Wisconsin.

The family moved to Walnut Grove, Minnesota, in 1874, and swarms of grasshoppers ate their wheat crops there in 1875 and 1876. Then they moved to Burr Oak, Iowa, where they helped run a hotel from 1876, and back to Walnut Grove in 1877. In 1879 they settled at De Smet, in Dakota Territory. There Laura's father, Charles Ingalls, took a job at a railroad camp and then claimed a homestead.

**Her own move.** Laura married Almanzo Wilder in 1885. In 1894, a year of drought, Laura, Almanzo and their daughter Rose drove a covered hack, a light wagon with a cover, about 650 miles from De Smet to Mansfield, Missouri. She kept a diary of the trip, published in 1962 as *On the Way Home*. In Mansfield she later wrote the Little House books.

**What the books changed.** The books came out from 1932 to 1943, and in them Wilder changed the real story. In *Little House on the Prairie*, Laura is several years older than she really was in Kansas, where she was 2 to 4 years old. The books leave out the Burr Oak years completely, and they do not say that the family was living on Osage land.

### The cattle drives

Cowboys drove herds of longhorn cattle north from Texas to Kansas after the Civil War. They took the cattle to railheads, the towns at the end of a railroad line, where the cattle were loaded onto trains. Abilene was one of these towns. The railroad reached Abilene in 1867, and after that cowboys used the Chisholm Trail from Texas heavily.

About 5 million cattle or more were driven north from Texas between 1866 and 1884. Some estimates put the total for the whole era at about 6 million. About 700,000 cattle reached the railheads in Kansas in 1871 alone.

The long drives ended in the mid-1880s for several reasons. Barbed wire fences went up across the open range. Railroads reached deeper into Texas, so the cattle no longer had to walk to Kansas. Kansas lawmakers passed a quarantine law in 1885 and 1886, keeping Texas cattle out of the state to stop the spread of disease. Then the cold of the winter of 1886 and 1887 killed much of the cattle herd.

### Why did the Exodusters go to Kansas?

Thousands of Black Southerners left their homes in 1879 and moved to Kansas, to get away from violence and cheating in the South. People called them Exodusters, after the Exodus, the story in the Bible of the Israelites' escape from slavery in Egypt. Many came from Mississippi, Louisiana, Texas and Tennessee. As many as 40,000 moved to Kansas, Oklahoma and Colorado between about 1879 and 1881, and about 6,000 reached Kansas in the spring of 1879 alone.

**What they left.** Former Confederates took away their votes, white landowners cheated them, and armed white men attacked them. Many were sharecroppers, who farmed someone else's land and paid the owner with a share of the crop.

The Confederates had been the Southerners who fought against the United States in the Civil War to keep slavery. After the presidential election of 1876, former Confederates took back control of the Southern states and took away Black Southerners' right to vote. The historian Damani Davis calls what Black Southerners faced "relentless terror."

**Henry Adams's list.** In Louisiana, the Black organizer Henry Adams collected the names of nearly 700 Black people who had been attacked. For each one he listed where it happened and what was done. Most of them had been whipped, beaten, shot or killed by white men, often by armed groups. Some entries name the man. One entry says that a white man, Dr. Moore, killed a Black man named Calvin in 1871, after Calvin was accused of cursing a white woman.

Many Exodusters traveled up the Mississippi River by steamboat, and crowds of them waited on the docks at St. Louis. In 1880 a United States Senate committee of three Democrats and two Republicans looked into why they had left. The three Democrats, the majority, held that the move had been planned to settle Black voters in Northern states for political gain. A 1912 history of Kansas states that the evidence hardly supported that idea.

The two Republicans wrote their own report. It said the migrants had fled because they could no longer bear the hardship, unfair treatment and suffering that "a class of Democrats in the South" had brought on them.

The migrants saw Kansas as a safe place. John Brown, who fought to end slavery, had lived there, and before the Civil War many Kansans had wanted it to be a free state, a state without slavery.

### Benjamin "Pap" Singleton

> **Who:** A man born into slavery who organized thousands of Black Southerners to move to Kansas.
>
> **When and where:** Born enslaved in Nashville, Tennessee, about 1809. Led the move to Kansas in the late 1870s. Died 1900.

**He called himself the "Father of the Exodus."**

Benjamin Singleton ran away from slavery several times, and in the end he escaped to the North and to Canada. He came back to Tennessee in about 1871, after the Civil War. He worked there as a carpenter, a cabinetmaker and an undertaker, a person who prepares the dead for burial.

Singleton was angry that white landowners cheated the Black sharecroppers who worked their land, and he believed Black Southerners would never get a fair chance at land in the South. He printed handbills, short printed notices, to draw Black settlers to Kansas. He formed a group called the Edgefield Real Estate and Homestead Association to move people there.

Singleton said under oath, at a hearing, that his work helped more than 7,400 people move. Between 1877 and 1879, his group steered more than 20,000 people toward Kansas. He died in 1900.

### The Oklahoma Land Run, 1889

About 50,000 people raced into central Oklahoma at noon on April 22, 1889, to claim land. The land they entered was called the Unassigned Lands. It covered about 1.9 million acres in the middle of Indian Territory, and nearly 2 million acres were claimed in a single day.

Indian Territory was the land in present-day Oklahoma where federal officials had moved many Native nations. The Unassigned Lands were the last part of it that federal officials had not given to any of those nations. Federal officials had taken land in Indian Territory from the nations there.

**How the land was taken.** After the Civil War, federal officials pressed the Creek and Seminole nations to give up land. Dennis N. Cooley, the Commissioner of Indian Affairs, was the federal official in charge of dealings with Native nations. In 1865 he told the nations' leaders that they had lost their rights under the old treaties by joining the Confederacy.

The Creek had to sign over the western half of their land for $975,168 in treaties of 1866, and the Seminole had to sign over all of theirs for fifteen cents an acre. With these treaties the Five Tribes, the Cherokee, Choctaw, Muscogee (Creek), Chickasaw and Seminole nations, lost the western half of present-day Oklahoma.

**The boomers.** Groups of settlers called boomers, led by David L. Payne and William Couch, entered the Unassigned Lands against the law from 1879 to 1888. Cavalry soldiers, who fought on horseback, arrested them and took them out again and again. Representative William Springer of Illinois changed a bill in Congress in 1889 so that President Benjamin Harrison could open the land, and Harrison announced the opening on March 23, 1889.

Each settler could claim 160 acres under the Homestead Act. People who sneaked in before the start to grab land were called "Sooners." By the end of that day, Guthrie and Oklahoma City were towns of about 10,000 to 15,000 people each.

### The frontier line disappears from the census, 1890

The officials who ran the United States census, the official count of the population taken every ten years, reported in 1890 that the country no longer had a clear "frontier line." The frontier line had been the edge of thinly settled land in the West, where two to six people lived on each square mile.

The historian Frederick Jackson Turner wrote an essay about that census finding in 1893, called "The Significance of the Frontier in American History." Many people later treated 1890 as the end of the years when settlers could still find open land in the West, land that had belonged to Native nations.

**If you remember one thing:** In these fifty years settlers claimed farms across the Great Plains and the far West, and soldiers forced the Native nations who lived there onto reservations.

**One number:** about 270 million acres. That is how much land settlers and other private owners got under the Homestead Act, about a tenth of all the land in the United States.

**Next:** After 1900, millions of Black Americans left the South, and Plains farm families fled the Dust Bowl.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 11 minutes**

About 6 million Black Americans left the South between about 1910 and 1970 to get away from lynch mobs, crowds that kill a person without any trial, and from Jim Crow laws, and most of the early travelers went north by train. Plains farm families moved too. In the late 1930s more than 250,000 people left the dried-out farms of the southern Plains for California.

**Forced out.** United States Army officers ordered Japanese Americans out of their homes on the West Coast in 1942. Soldiers and officials forced them into camps.

### The Great Migration, the first wave

The movement of Black Americans out of the rural South from about 1910 to 1970 is called the Great Migration. The first wave, from about 1910 to 1940, went mostly to cities in the North and the Midwest. Most people rode the trains north, and later travelers also went by car and by bus.

**The cities.** Between 1910 and 1920, Chicago's Black population grew to about two and a half times its size, and Detroit's grew to about seven times. New York's and Philadelphia's grew by more than half, and many newcomers also went to Pittsburgh.

The growth went on in the 1920s. New York's Black population more than doubled in those ten years, from about 152,000 to about 328,000. About 90 percent of Black Americans lived in the South in 1900. By 1970 fewer than 55 percent did.

**Why they left.** Georgia is one example. Black Georgians had several reasons to leave. The boll weevil, a beetle that eats cotton plants, and floods ruined the cotton crop in 1915 and 1916. Lynch mobs killed more than 450 people in Georgia between 1880 and 1930, most of them Black.

Under Jim Crow laws, the Southern laws that kept Black people and white people apart, nearly all Black Georgians could not vote. About 74,000 Black Georgians left between 1910 and 1920, and about 260,000 more left in the 1920s.

**The Chicago Defender.** Black Southerners from across the South went north for jobs, and some people in the North urged them to come. Robert S. Abbott started a Black newspaper, the *Chicago Defender*, in 1905. In its pages, job listings and train schedules ran beside editorials, articles that give a newspaper's opinion, and the editorials urged Black Southerners to come north. The *Defender* listed May 15, 1917, as the date for a "Great Northern Drive." Some Northern employers paid migrants' train fares and then took the money back out of their wages.

White officials in the South worked to keep Black workers from leaving. Officials in Macon, Georgia, charged Northern labor recruiters, people hired to find workers, a license fee of $25,000 for permission to work there.

**Chicago, 1919.** Black people in the North also met violence. Eugene Williams, who was 17, and four friends drifted on a homemade raft in Lake Michigan in Chicago on July 27, 1919. They crossed an unmarked line into the water off a beach at 29th Street where only white people were allowed. George Stauber, a 24-year-old white man, threw rocks at them until Williams drowned. A white police officer, Daniel Callahan, refused to arrest Stauber and stopped a Black officer from arresting him.

Five days of attacks followed, through August 3. The white attackers included youth gangs and groups that called themselves athletic clubs. Thirty-eight people were killed, 23 Black and 15 white, and the histories of the riot do not say who killed each of them. About 537 people were injured, two-thirds of them Black. Hundreds of homes were burned or damaged. Of the 138 people charged with crimes afterward, two-thirds were Black.

### Ida Mae Brandon Gladney

> **Who:** A sharecropper's wife who left Mississippi with her family after white men nearly beat a cousin to death.
>
> **When and where:** From Chickasaw County, Mississippi, by train, late October 1937. Settled in Chicago.

**The turkeys turned up the next day, and no one apologized.**

Ida Mae Brandon Gladney and her husband, George Gladney, were sharecroppers in Chickasaw County, Mississippi, farming another man's land for part of the crop. They grew cotton on the plantation of Edd Pearson, whom they called Mr. Edd.

In 1937 a group of white men beat a cousin of theirs, Joe Lee, nearly to death with heavy chains. The men had falsely accused him of stealing turkeys. The accounts of the beating do not name them. After the beating, George came home and told Ida Mae, "This is the last crop that we're making."

**The train north.** The cotton was picked by late October 1937, and George settled with Mr. Edd over what the year's work was worth. None of the family had ever been on a train or out of Mississippi. A brother-in-law drove Ida Mae and the two children, James and Velma, in his truck to the train station at Okolona. There they met George and rode north through the night.

The family settled in Chicago. One account says they stopped first in Milwaukee, where Ida Mae's sister Irene lived. In Chicago, George hauled ice up four and five flights of stairs, and Ida Mae did housework for other people and then found work as a hospital aide. In time the family bought a house. Ida Mae died in 2002. The writer Isabel Wilkerson told Ida Mae's life, from interviews with her, in the 2010 book *The Warmth of Other Suns*.

### The Dust Bowl move

Drought, years with too little rain, and windstorms tore the topsoil off farms across the southern Great Plains in the 1930s. The Dust Bowl was the name for those parts of Oklahoma, Texas, Kansas, Colorado and New Mexico.

More than 250,000 people left the Dust Bowl states for California from about 1935 to 1940. Another count covers only Oklahoma but every destination: everyone who left Oklahoma for any place, minus the people who moved in. By that count Oklahoma may have lost as many as 440,000 people. Many of the travelers went west on U.S. Route 66, and in California the newcomers were called "Okies."

**The "bum blockade."** The Los Angeles police chief, James E. Davis, sent his officers to the state line in February 1936 to turn back poor migrants. People called it the "bum blockade."

Davis's officers, 136 of them, stood at 16 crossing points from February 3 on California's roughly 700-mile border with Arizona, Nevada and Oregon, far outside the city. Davis pointed to a 1933 state law against bringing poor people into California. His officers stopped trains, cars and people hitchhiking. They took people's fingerprints and turned back anyone they judged unable to support themselves.

The officers arrested 122 people for vagrancy, the crime of having no home or means of support, on February 8 alone. A week into the blockade, Davis announced that he would force the people arrested to work without pay in quarries, digging rock, sand and gravel out of the ground for public projects. Many of the people arrested were locked up in prisons far from the state line.

**For and against.** Railroad executives and some county sheriffs backed the blockade. So did the people who ran the *Los Angeles Times* and the Los Angeles Chamber of Commerce, a group of the city's business owners. California's attorney general, the state's top lawyer, Ulysses S. Webb, said Davis had "no jurisdiction beyond the city's territorial limits," meaning no power outside Los Angeles. Arizona's governor, Benjamin Moeur, called the blockade illegal and against the Constitution.

Davis called his officers home in early April 1936. He claimed they had turned back about 11,000 people. Writing in *Smithsonian* magazine in 2025, Olatunji Osho-Williams reports that the real number was probably much lower.

### Florence Owens Thompson

> **Who:** A farmworker born in what is now Oklahoma, whose parents said their families were Cherokee, who moved from crop to crop in California. She is the woman in Dorothea Lange's 1936 photograph "Migrant Mother."
>
> **When and where:** Born in Indian Territory in 1903. Moved to California in the 1920s. Photographed at a pea-pickers' camp in Nipomo, California, in March 1936.

**Lange took seven pictures of her in about ten minutes.**

Florence Owens Thompson was born Florence Leona Christie in Indian Territory, which is now Oklahoma, in 1903. Both of her parents said their families were Cherokee.

She married Cleo Owens in 1921, and during the 1920s, years before the Dust Bowl, they moved west with several of his relatives to Oroville, California. Cleo died in 1931. In about 1933 she and her parents moved to Shafter, California, and she worked in the fields as a farm laborer, following the crops from one harvest to the next.

**Nipomo.** The timing chain in the family's car, an engine part the car could not run without, snapped on March 6, 1936. The family stopped at a camp of pea pickers near Nipomo, where freezing rain had destroyed the pea crop. The photographer Dorothea Lange took seven pictures of Thompson in about ten minutes. One of them became known as "Migrant Mother," and it became one of the most reproduced pictures of the 1930s.

Thompson's name was not made public until 1978, when Emmett Corrigan, a reporter for the *Modesto Bee*, found her. She died on September 16, 1983.

### The forced removal of Japanese Americans, 1942

United States Army officers forced more than 110,000 Japanese Americans out of their homes on the West Coast in 1942. The United States had been at war with Japan since Japanese forces attacked Pearl Harbor, in Hawaii, on December 7, 1941. President Franklin D. Roosevelt signed Executive Order 9066, a rule issued by a president, on February 19, 1942. Under it, military commanders could keep "any or all persons" out of areas they named.

**The reason given.** Roosevelt gave his reason in the order's opening words. Winning the war, he stated, required "every possible protection" against spying and against damage done on purpose to war supplies and to buildings and services needed for the war. The order does not identify any group of people.

General John L. DeWitt commanded the Army on the West Coast. In March and April 1942 he issued orders aimed at one group, "all persons of Japanese ancestry," meaning everyone whose family came from Japan. United States citizens and people who were not citizens were ordered out alike.

**108 orders.** DeWitt set up an Army office on March 11 to carry out the removal. Karl Bendetsen, an Army officer, commanded it, and the next day, at 34, he was made a colonel. Bendetsen's staff divided the coast into 108 areas of about 1,000 Japanese Americans each and issued a separate order for each area.

Under each order, the people in that area had to report on a set day, about a week later, and they could bring only what they could carry. Under the first order, issued on March 24, the 55 Japanese American families on Bainbridge Island, near Seattle, had six days to leave their homes. Army officers carried out the 108 orders and forced out 110,442 people.

**The camps.** Army engineers built 15 temporary camps, many of them at fairgrounds and racetracks. When people arrived, soldiers searched their bags. At the Tanforan camp in California, half of the people lived in horse stables, three to six people in a stall built for one horse.

After about three months, on average, officials moved them again, to 10 larger camps run by officials of a federal office called the War Relocation Authority. Staff at the National Archives count about 120,000 people removed in all, a larger total than the count for the 108 orders alone.

**The end.** None of the people removed was charged with a crime or tried. Officials lifted the order that kept Japanese Americans off the West Coast on January 2, 1945, and they closed Tule Lake, the last camp, on March 20, 1946.

In 1983 the members of a federal commission that studied the removal found that the order "was not justified by military necessity," meaning there was no military need for it. They found that the causes of the removal were "race prejudice, war hysteria and a failure of political leadership." Under the Civil Liberties Act, which President Ronald Reagan signed in 1988, each surviving person who had been held received a written apology and $20,000.

### George Swanson Starling

> **Who:** A Florida fruit picker who organized the other pickers to ask for better pay, then fled north when he learned that the grove owners were plotting to hang him.
>
> **When and where:** From Wildwood, Florida, to Harlem in New York City, by train, April 14, 1945.

**For asking ten cents more a box, grove owners plotted to hang him.**

George Swanson Starling grew up in Eustis, in Lake County, Florida. He finished first in his high school class and went to Florida Agricultural and Mechanical State College in Tallahassee. In the middle of his second year, his father told him he had had enough schooling and must go to work.

**The groves.** Starling went to work picking citrus fruit. The pickers climbed trees as tall as 40 feet, and some fell and broke arms or legs. Starling organized the pickers to ask for better pay. In one dispute, the packing house, where the fruit was packed for sale, would pay the pickers ten cents for each box of tangerines. The pickers asked for twenty cents. At auction in 1944, tangerines sold for an average of $4.40 a box.

**The plot.** The grove owners were angry. Someone overheard them planning to take Starling and two other pickers out to the cypress swamps at Blackwater Creek and hang them. Starling left within days, on April 14, 1945. A man named Roscoe Colton drove him in his truck to the train station in Wildwood.

There Starling boarded the Silver Meteor, a train to New York. He rode in the Jim Crow car, the car set aside for Black passengers, where luggage was also stored. The ride took 23 hours. His wife, Inez, stayed behind until he could send for her.

Starling settled in Harlem, where an aunt and many of his friends lived. He later got a steady job working on the same train that had carried him north. Isabel Wilkerson's book *The Warmth of Other Suns* also describes his life. The accounts of Starling's life do not name the grove owners who planned to kill him.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 5 minutes**

Americans moved south and west after 1950, toward jobs, warmer weather and cheaper land. The population of the South grew by about 36 percent between 1970 and 1990, and the population of the West by about 51 percent. In the second wave of the Great Migration, many Black Southerners moved to cities on the West Coast. Federal officials paid for Native people to move from reservations to cities.

By the late 1990s more Black Americans were moving to the South than were leaving it.

### Where the second wave of the Great Migration went

The second wave of the Great Migration lasted from about 1940 to 1970, and it was larger than the first. More of its travelers went west, to Los Angeles, Oakland, Seattle and Portland, for factory jobs, first during World War II and then after it. These travelers are counted in the same total of about 6 million people who left the South between 1910 and 1970.

### Robert Joseph Pershing Foster

> **Who:** A Black surgeon who could not work in the hospital of his own home town in Louisiana. He drove alone to California and opened his own medical practice in Los Angeles.
>
> **When and where:** From Monroe, Louisiana, to Los Angeles, California, by car, April 1953.

**Motel clerks in Arizona turned him away under "vacancy" signs.**

Robert Joseph Pershing Foster had served as a surgeon in the Army. Back home in Monroe, Louisiana, he found that the people who ran St. Francis Hospital there would not let Black doctors do even a simple operation to take out a patient's tonsils. Isabel Wilkerson traced his trip in *The Warmth of Other Suns*.

**The drive.** Foster set out alone on Easter Monday, April 6, 1953, in his 1949 Buick Roadmaster, a dark red car with white-walled tires. He planned to send for his family once he was settled. Once he was long past Texas, he thought he was a safe distance from the South.

In Arizona, motel clerks turned him away, a Black man traveling alone, even under "vacancy" signs, which tell drivers that rooms are free. One clerk told him they had forgotten to turn off the sign. Others said the rooms had just been rented. He could not find a place to stay the night, so he drove on until he reached California.

Alone in the dark desert, he asked himself what he was doing. If he turned back, Wilkerson writes, "the I-knew-its would ring in his ear," meaning the people who would say they had known he would fail.

In Los Angeles, Foster opened his own medical practice. Many of his patients were migrants from the South, as he was. One of them was the musician Ray Charles.

### Why did Americans move to the Sun Belt?

Many Americans moved from the older factory states of the North to the South and the West after World War II, for jobs, for warmer weather and for cheaper land. People later nicknamed the Northern factory states the "Rust Belt" and the South and the West the "Sun Belt." Air conditioning made hot places comfortable all year, which helped the Sun Belt grow.

The South grew by about 36 percent between 1970 and 1990, and the West by about 51 percent. By counts from the Census Bureau, the federal office that counts the population, the whole country grew by about 22 percent in those years, from about 203 million people to about 249 million. California passed New York as the state with the most people in 1962. It had about 17 million people then, roughly three times as many as before World War II.

**The interstates.** Members of Congress passed the Federal-Aid Highway Act in 1956. Under it, work began on the Interstate Highway System, a network of big highways across the country. The interstates made long moves by car easier, and they made it easier to live in a suburb, a town at the edge of a city.

### Federal officials move Native families to cities

Officials of the Bureau of Indian Affairs, the federal office in charge of the government's dealings with Native nations, paid for Native people to move from reservations to cities from about 1950 into the 1970s. They started the program, called Relocation, between about 1948 and 1952, and members of Congress backed it with the Indian Relocation Act in 1956.

**The aim.** Bureau officials opened relocation offices in Denver, Salt Lake City and Los Angeles in 1951 to help Native people from reservations find jobs in big cities. The National Archives describes Relocation as part of termination. Members of Congress declared that policy on August 1, 1953, to end the government's recognition of Native nations and the services that came with it. The federal officials behind termination aimed to make Native people live like most other Americans.

The officials promised people one-way tickets to a city and help for a short time after they arrived. About 30,000 Native people moved to cities in the 1950s, and more than 100,000 had moved by the time the program ended in the 1970s. They went to Minneapolis, Chicago, Oakland and San Francisco, Los Angeles, Denver and other cities. Many of them lived in poverty there. They also built new Native communities in those cities.

### When did the Great Migration turn around?

A small number of Black Americans began moving back to the South in the 1970s, and the number grew through the 1990s. By the late 1990s the South gained more Black migrants than it lost to each of the other three regions of the country, the Northeast, the Midwest and the West. For 35 years before that, more Black Americans had left the South than moved to it. William H. Frey, a researcher at the Brookings Institution, a research group, calls this return the New Great Migration.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 7 minutes**

Hurricane Katrina and the broken levees around New Orleans forced more than 1 million people from their homes on the Gulf Coast in 2005, the largest sudden move of these years. After Hurricane María hit Puerto Rico in 2017, about 130,000 people left the island for the mainland within a year.

**A steadier flow.** By Census Bureau estimates, the South gained about 2.7 million more people from other states than it lost to them from 2020 to 2024.

### How many people moved south after 2020

Census Bureau staff count moves between states as net domestic migration: the number of people who move into a state from other states, minus the number who move out to other states. By this measure the South gained about 2.7 million people from 2020 to 2024.

Many of the people who moved between states left coastal states where homes cost a lot. California lost about 343,000 people to other states from April 2020 to July 2022, and New York lost about 300,000, by Census Bureau counts. The metro areas, cities together with their suburbs, that lost the most people included New York, Los Angeles, San Francisco and Chicago.

**Working from home.** Some people could work from home after 2020. Researchers at the Pew Research Center, a group that studies how Americans live and what they think, reported that working from home let some people choose where to live by the cost of a home and the space it offered, not by where their job was.

**Florida slows down.** Florida's gains from other states shrank after 2022. By Census Bureau counts, Florida had a net gain of about 311,000 people from other states in 2022, about 184,000 in 2023, and about 23,000 in the year from July 2024 to June 2025. Census Bureau staff released the 2025 figures in January 2026. In that same year North Carolina gained the most people from other states, about 84,000, and Texas and South Carolina each gained about 67,000.

Researchers at the National Association of Realtors, a group for people who sell houses, ranked the states from the same Census figures. In that ranking, nine of the fifteen states with the biggest gains in 2024 to 2025 were in the South. The Midwest also gained about 16,000 people from other states that year, its first such gain of the 2020s.

**The New Great Migration.** The movement of Black Americans to the South went on. William Frey of the Brookings Institution found that the Black population of metro Atlanta grew about five times over from 1970 to 2020, and by 2010 it had passed Chicago's to rank second in the country. Atlanta was the most common destination of young Black adults aged 16 to 26 who moved between 2000 and 2018, and seven of their ten most common destinations were in the South.

### Leaving New Orleans after Hurricane Katrina, 2005

Hurricane Katrina struck the Gulf Coast in late August 2005, and the levees around New Orleans, walls of earth or concrete built to hold back water, broke. The storm and the broken levees forced more than 1 million people from their homes in the New Orleans area and along the Gulf Coast. A month later, the people of up to 600,000 homes were still away. These counts come from The Data Center, a research group in New Orleans, and from the federal housing department.

**Many never came back.** New Orleans had 484,674 people at the 2000 census. By July 2006 an estimated 230,172 people lived there, fewer than half as many, The Data Center reported. In 2024 the city had about 363,000 people, about 120,000 fewer than in 2000, by an estimate reported by the news site The Center Square in 2025.

The New Orleans metro area's seven parishes, the Louisiana name for counties, had 970,849 people in July 2025, 3.6 percent fewer than in April 2020, The Data Center found.

**The bridge.** Police stopped some of the people who tried to walk out of the flooded city. On September 1, 2005, officers from three police forces blocked the Crescent City Connection bridge over the Mississippi River: the Gretna police, the bridge police and the Jefferson Parish sheriff's office. They turned back people on foot at gunpoint. Two paramedics from San Francisco, medical workers who ride ambulances, were in the crowd, and they reported that police "fired their weapons above their heads."

Gretna Police Chief Arthur Lawson made the decision together with officials of the sheriff's office and the bridge police. Gretna's mayor, Ronnie Harris, defended it. He said the town was not a shelter or an evacuation route and had no running water, no electricity and no food. Members of the Gretna City Council voted to support the blockade, which lasted until Labor Day, September 5, 2005. No count survives of how many people the officers turned back.

**Houston.** About 250,000 evacuees, people who leave a place to escape danger, came to Houston at the peak, and about 150,000 were still there a year later. Those are Houston officials' own estimates, reported by the *Texas Tribune* in 2010. By 2010 Houston's mayor, Annise Parker, said city officials no longer counted them apart from other residents: "They are Houstonians."

### Kimberly Rivers Roberts

> **Who:** A woman of 24 from the Lower Ninth Ward of New Orleans who wanted to be a rap singer. With her husband, Scott Roberts, she filmed the Katrina flood from inside it.
>
> **When and where:** New Orleans, August 2005. Then Alexandria and northern Louisiana, then Memphis, Tennessee, then home to New Orleans.
>
> **Movie:** *Trouble the Water* (2008), a documentary about Kimberly and Scott Roberts, directed by Tia Lessin and Carl Deal and built largely on her own video. It won the Grand Jury Prize for documentary at the 2008 Sundance Film Festival and was nominated for an Academy Award.

**She filmed the Katrina flood on a $20 camcorder.**

Kimberly Rivers Roberts and her husband, Scott Roberts, were still in their New Orleans neighborhood when Katrina's flood came, because someone had recently stolen their car. "If I had wheels I'd be gone too," she told a neighbor. She began filming on August 28, 2005, two days before the storm reached the city, with a camcorder she had bought for $20.

As the water rose, the couple and their neighbors climbed into an attic. They called 911 and heard that police would not come until conditions got better. A neighbor floated people to safety on a punching bag.

**The Navy base.** Afterward the group tried to take shelter at a Navy base that stood nearly empty. The couple's film shows men at the gate turning them away at gunpoint, and a voice says, "Get off our property, or we're going to start shooting." Navy officials deny that this happened. The accounts of the film do not name the men at the gate.

Kimberly's grandmother died in a hospital that was not emptied of its patients, and one of her uncles, called Uncle Ned in the film, was later found dead in his home. The accounts do not say who decided to leave the hospital's patients there, and they do not state the cause of either death.

The couple went to a Red Cross shelter in Alexandria, Louisiana, then to the trailer of another uncle, in northern Louisiana. Next they moved to Memphis, Tennessee, to stay with one of Kimberly's cousins and try to start over. They waited for a promised check from FEMA, the federal office for disaster help, but it did not arrive, and they had a hard time settling in a new city.

**Home.** Kimberly and Scott went back to their home in the Ninth Ward and set out to rebuild it. Scott got a job with a builder repairing houses that the flood had ruined. Kimberly started her own record label, Born Hustler Records.

### Leaving Puerto Rico after Hurricane María, 2017

About 130,000 people left Puerto Rico for the mainland within a year after Hurricane María hit the island in September 2017. That was almost 4 percent of the people of Puerto Rico. The count is the Census Bureau's estimate for July 2017 to July 2018.

Other counts run higher. Researchers writing in the science journal PNAS in 2020 described estimates made from air travel records, phone records and social media data. Those estimates run from about 160,000 to 470,000, depending on which data the researchers used.

Puerto Rico is a territory of the United States, land that belongs to the country but is not a state, and Puerto Ricans are United States citizens. A move from the island to the mainland is a move within the country. About a third of the people who moved from Puerto Rico to the mainland in 2018 went to Florida, by Census Bureau figures.

**The three questions, answered**

- How did horses reach the Native nations of the Plains? In the older account, horses spread north through trade after the Pueblo Revolt of 1680, when the Spanish left perhaps more than 1,500 of them behind. A 2023 study of horse bones found that many nations had horses by the early 1600s, decades earlier, as the nations' own histories say.
- How many Cherokee died when soldiers forced them west? Nobody knows exactly. The count most often given is about 4,000, and estimates run from more than 1,000 on the journey itself to about 8,000 or more.
- Why did about 6 million Black Americans leave the South between 1910 and 1970? They left lynch mobs, Jim Crow laws and cotton crops ruined by the boll weevil and floods, and they went toward jobs in Northern and Western cities. In Georgia, one example, lynch mobs killed more than 450 people between 1880 and 1930, and nearly all Black Georgians could not vote.

**What changed:** Before 1900 most of the moves in this chapter went west onto Native land, many of them forced, and after 1900 millions of Black Southerners went north, until the flow began turning back toward the South in the 1970s.

**Five dates to keep**

- April 30, 1598: Oñate claims New Mexico for Spain in La Toma, "the taking."
- May 1838: US soldiers begin rounding up the Cherokee for the Trail of Tears.
- May 20, 1862: Lincoln signs the Homestead Act.
- February 19, 1942: Roosevelt signs Executive Order 9066.
- August 2005: Hurricane Katrina forces more than 1 million people from their homes.

**Not known:** Nobody knows for sure why most of the people of Cahokia had left their city by about 1350.

**Where to go:** The Trail of Tears National Historic Trail, run by the National Park Service, marks more than 2,200 miles of the removal routes across nine states.

**Next:** Chapter 6, City Building. It asks how Americans built the towns and cities where so many of these travelers ended up.
