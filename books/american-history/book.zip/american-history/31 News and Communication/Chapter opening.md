# Chapter 31: News and Communication

**Chapter 31 of 37 · News and Communication · 10 eras · about 125 minutes**

**Again and again, from a runner with a knotted cord to a phone, a new way of carrying news in America has come with a fight over who may carry it and what it may say.**

One copy of the first newspaper printed in the English colonies is known to survive, and it is in London. It is called *Publick Occurrences, Both Forreign and Domestick*. Benjamin Harris printed it in Boston on September 25, 1690. It has three printed pages and a blank fourth page, where readers could write more news before they passed the paper on. Four days later the governor and his council stopped the paper and ordered every copy handed back. There was never a second issue.

This chapter follows the news through ten eras. Watch two things as you go. The first is speed. In 1775 riders took five days and seven hours to carry the news of Lexington to Philadelphia. In 1860 the first Pony Express run took ten days to reach California. By the 1920s radio brought the news into homes as it happened. The second is who tried to stop the news, and who was kept from carrying it. Look for governors and judges, mobs that wrecked printing presses, a law that let only free white people carry the mail, and station managers who cut the news off the air.

**Three questions this chapter answers**

- Did the First Amendment stop the government from punishing people for what they printed?
- Who was shut out of carrying and printing the news?
- Why have so many local newspapers closed since 2005?

**Five minutes?** Read "The station that cut the news: WLBT, 1955 to 1971" in 1950 to 2000.

**Can skip:** "The telephone, 1876 to 1900", "Newspapers in Chinese, 1854 and 1855", "Pictures by wire, 1935", "Television begins, 1927 to 1941". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 2 minutes**

News traveled on foot in this land before 1500. Runners carried messages from one nation to another, and nations that spoke different languages talked with their hands. What is known about how they did it comes from two places. One is the accounts that Native nations and Europeans gave later. The other is the old objects that archaeologists, scientists who study the past by digging, have found in the ground.

### Runners and wampum

The Haudenosaunee have lived for a thousand years and more in what is now central New York. They are also called the Iroquois, or the Six Nations. Five nations joined together before Europeans came, and the Tuscarora became the sixth in 1722.

**The runners.** Haudenosaunee runners called the nations to council, a meeting of their leaders. They also carried news from nation to nation and warned of danger. A runner carried a string of wampum, small beads cut from the white and purple parts of a clam shell, to show that his message was official. His pouch held pounded, dried corn mixed with maple sugar.

The Onondaga Nation keeps the wampum records of the Haudenosaunee. Its people describe how a council is called. Each nation receives a string of wampum that stands for the topic the leaders will meet about. A wooden stick is tied to the end of the string. Its notches count the days until the meeting. As each day passes, someone cuts a notch off the stick.

**Older beads.** Shell beads as old as 4,500 years have been found in the Northeast. Early bead makers drilled them with stone drill bits. Drilling with stone was hard, so their beads were larger than later wampum, and there were fewer of them. After Europeans arrived, Native bead makers drilled with nails and with iron awls, thin pointed tools for making holes.

### Hand signs and trade

People in this land spoke many different languages. Near the Gulf coast and in what is now Texas, nations that could not understand each other's speech talked with their hands.

The first and fullest written accounts of this sign language come from the survivors of Cabeza de Vaca's Spanish expedition, which sailed in 1527. They noted which groups spoke the same language and which groups could understand each other only through signs. Scholars who study these accounts, among them Jeffrey E. Davis, think the sign language was in use across that region well before the Spanish came.

Trade goods moved hundreds of miles. Copper from Lake Superior and shells from the Gulf of Mexico have been found far from where they came from. No record survives of what news the traders passed along with the goods.

## The 1500s

**Era 2 of 10 · The 1500s · about 5 minutes**

Newcomers from Spain, France and England sent their news home across the ocean in letters and printed books, and each side told its own version. On the plains, Native people made themselves understood to the Spanish in hand signs. On Roanoke Island, English colonists left a message carved in a post.

### A letter to a king and a book by a survivor, 1565 and 1566

The news of the killings in Florida in 1565 reached Europe in two accounts. One came from the Spanish commander who ordered the killings, in a letter to his king. The other was a book by a French survivor.

**The killings.** The Spanish commander Pedro Menéndez de Avilés and his soldiers killed French Protestants, Christians who do not belong to the Catholic Church, at Fort Caroline in Florida in September 1565. The fort stood in the homeland of Timucua-speaking peoples. Menéndez's men then killed two more groups of Frenchmen at Matanzas Inlet, south of the fort. Both groups had given up before they were killed. Matanzas is the Spanish word for "slaughters." Menéndez gave his reason himself: the Frenchmen were Protestants.

**The letter.** Menéndez reported the killings to King Philip II of Spain in a letter dated October 15, 1565. By his own count, his men cut the throats of 132 men at the fort. The next day they cut the throats of 10 more, prisoners they had caught in the woods.

At the inlet, he wrote, the first group of Frenchmen gave up their weapons. "I had their hands tied behind them and put them to the knife." He meant that his men killed them with knives. He spared sixteen men of that group: twelve sailors, and four craftsmen he said he needed.

**How many.** The National Park Service counts about 245 Frenchmen killed at the inlet, among them their leader, Jean Ribault, on October 11 or 12. By these counts, Menéndez's men killed nearly 390 Frenchmen in about three weeks. Chapter 22, War and the Military, describes the killings in full.

**The book.** Nicolas Le Challeux, a carpenter who escaped from Fort Caroline, wrote the French account. A printer in Dieppe, France, published it in 1566. Its title describes the killings as the cruelty of the Spaniards against the French king's subjects. Le Challeux told how he fled from the fort into the woods. Two of the men with him climbed a tall tree and signaled to a small French ship, and a boat came to pick them up. The survivors then sailed home to France.

### Hand signs on the plains, 1541

Francisco Vázquez de Coronado and his Spanish expedition met a Native nation on the plains of what is now the Texas Panhandle in 1541. The Spaniards called them Querechos. Pedro de Castañeda, a member of the expedition who later wrote its history, recorded that "although they conversed by means of signs they made themselves understood so well that there was no need of an interpreter," someone to put one language into another.

### A message carved in a post, Roanoke, 1587 to 1590

John White left 117 English colonists on Roanoke Island, in what is now North Carolina, in 1587 and sailed to England for supplies. The island and the coast around it were the land of peoples who spoke Algonquian languages, a family of related languages. Among them were the Roanoke, the Secotan and the Croatoan.

**The signal.** Before White left, he and the colonists agreed on a signal. If they moved, they would carve the name of their new place on a tree or a doorpost. If they left because they were in danger, they would carve a cross above the name.

White could not sail back for three years. England's queen took every English ship for her navy in 1588, to fight the Spanish Armada, a great fleet of warships sent from Spain. When White landed on August 18, 1590, the houses were gone and a fence of posts stood around the empty site. The letters CROATOAN were carved on one post "in fayre Capitall letters," old spelling for neat capital letters. The letters CRO were cut into a tree. There was no cross.

White wrote that Croatoan was "the place where Manteo was borne," and he called the people of that island "our friends." Manteo was an Algonquian man who had learned English and interpreted for the English. A hurricane blew White's ship out to sea before he could search there. White never found the colonists.

**Books for Europe.** Readers in Europe learned about this coast from printed books. Thomas Harriot came to Roanoke Island with the English in 1585, and he and John White explored and mapped the area. Harriot published *A Briefe and True Report of the New Found Land of Virginia* in London in 1588. Two years later the engraver Theodor de Bry, who cut pictures into metal plates for printing, printed it again in four languages. De Bry made his pictures from John White's watercolor paintings.

### Manteo

> **Who:** An Algonquian man, born on Croatoan by John White's account, who learned English and interpreted for the English.
>
> **When and where:** The Outer Banks of North Carolina, and London, 1584 to 1590.

**He crossed to London in 1584 and came home speaking English.**

The English captains Philip Amadas and Arthur Barlowe spent six weeks on the Outer Banks in 1584. When they sailed home, Wingina, a leader of the Algonquian people there, chose two men to go with them. They were Manteo and Wanchese.

Both men began to learn English from the sailors during the voyage. The ship reached England in mid-September. In London they met Sir Walter Raleigh, who sent the voyages. By the end of 1584 Manteo could speak enough English to interpret. He sailed home on April 9, 1585, on the *Tyger*, the lead ship of Raleigh's fleet.

**Back on Roanoke.** Manteo helped the colonists of 1587 set up a village near the old English fort on Roanoke Island. On August 13 that year the English baptized him into their church, a Christian ceremony with water that made him a member. They also named him Lord of "Dasamongueponke." When White came back in 1590, he found neither the colonists nor Manteo.

**Not known:** The National Park Service's account of his life says that what happened to Manteo is unknown.

## The 1600s

**Era 3 of 10 · The 1600s · about 7 minutes**

The men who governed the English colonies in the 1600s decided who could print news, and they stopped printers they had not approved. Virginia's governor, Thomas Culpeper, and his council, a small group of men who advised him, ordered the printer William Nuthead to stop printing in 1683. Seven years later, in Massachusetts, Governor Simon Bradstreet and his council shut down the first newspaper printed in the English colonies.

The colonies also got their first mail service, a rider who carried letters from New York to Boston. In New Mexico in 1680, Pueblo runners carried the plan for a revolt against Spanish rule from town to town.

### Letters by ship, by tavern and by planter

Most letters in the early colonies crossed the ocean, between the colonies and the countries in Europe that ruled them. In 1639 the lawmakers of Massachusetts, who met as the General Court, named Richard Fairbanks's tavern in Boston as the place to leave and collect letters sent "beyond the seas." Inside the colonies, people sent letters with friends, with merchants and with Native messengers.

Virginia officials around the middle of the 1600s wrote "for public service" on the outside of government letters. Virginia's rulers required each planter to send such a letter on to the next plantation. A planter who failed to do it had to give up a hogshead, a large barrel, of tobacco as a fine. On the big plantations of the South, Postal Service historians write, the messengers were usually enslaved people.

### The first post rider, 1673, and a mail service for all the colonies, 1692

The first post rider, a man on horseback who carried the mail along a set route, left New York for Boston on January 22, 1673. The ride was about 250 miles, through New Haven, Hartford, Springfield and Worcester. Governor Francis Lovelace of New York set up the route with John Winthrop Jr. of Connecticut. The rider was to make the trip once a month. It took him about two weeks.

The monthly service did not last long. The rider's trail became known as the Boston Post Road, and part of it is now US Route 1. In 1683 William Penn set up the first post office in Pennsylvania.

**A mail service for all the colonies.** A man named Thomas Neale got the right in 1692 to run a mail service for all the colonies for 21 years. The right came from the English Crown, the king or queen of England and the royal government. Neale never came to America. Andrew Hamilton, the governor of New Jersey, ran the service for him.

### Virginia: no printing allowed, 1671 to 1730

William Berkeley was the governor of Virginia. In 1671 he wrote to the king's officials in London: "I thank God, there are no free schools nor printing, and I hope we shall not have these hundred years." He gave his reason. Printing, he wrote, had spread new religious groups, disobedience and attacks on the government.

**Printing stopped.** A merchant named John Buckner brought a printer, William Nuthead, to Virginia in 1682. By February 1683 Nuthead had printed the laws that Virginia's lawmakers had just passed. Governor Thomas Culpeper and his council ordered both men to stop printing, and Nuthead moved on to Maryland.

The next governor, Francis Howard, arrived in 1684 with orders from King Charles II that barred printing in Virginia. The first printing press that Virginia's rulers allowed arrived in 1730, when William Parks opened a print shop in Williamsburg.

### The first newspaper, 1690, closed after one issue

Printers in Massachusetts had printed single sheets of news called broadsides since 1667, one at a time, with no plan for a next issue.

**Numb. 1.** Benjamin Harris printed *Publick Occurrences, Both Forreign and Domestick* in Boston on September 25, 1690. It was the first newspaper in the English colonies. Harris marked it "Numb. 1," number one, and planned to print it once a month.

**Four days.** Governor Simon Bradstreet and the men of his council ordered the paper "Suppressed and called in" on September 29. That meant it was stopped, and every copy had to be handed back. They said Harris had printed it without their permission.

They also objected to what he had printed. Harris had accused Native allies of the English of "barbarous" cruelty to French prisoners. He had complained that colonial officials told the Mohawks, one of the Six Nations of the Haudenosaunee, too much about the colonists' war plans. The paper also carried a rumor that King Louis XIV of France was having sex with his son's wife.

Bradstreet and his council then ordered that no one could print news in the colony without a license, written permission from the government.

### Benjamin Harris

> **Who:** The London printer who printed the first newspaper in the English colonies.
>
> **When and where:** London, then Boston, 1679 to 1695.

**Three arrests in London came before his one Boston newspaper.**

In London in the 1670s and 1680s Harris printed pamphlets, short printed booklets, for Protestants who had broken away from the Church of England. He was a Baptist, a member of one of those Protestant groups, and he spoke out against King Charles II.

Harris printed a newspaper without a license in 1679, *The Domestick Intelligence*. English officials jailed him twice. After a third arrest in 1685 he fled to the Netherlands. A year later he sailed to Boston and opened a print shop.

**The paper.** His opening notice in *Publick Occurrences* said he wanted to stop the "many False Reports, maliciously made, and spread among us." The paper reported a fire that burned about 20 houses. It also reported an outbreak of smallpox, a disease that spreads from person to person and kills many of the people who catch it. The governor and his council forbade Harris to print any newspaper in the colony again.

Harris obeyed. Massachusetts officials named him the colony's official printer in 1692. He went back to England in 1695 and started a London paper, the *London Post*, in 1699. He died in 1720.

### Knotted cords and the Pueblo Revolt, 1680

Pueblo leaders in New Mexico planned a revolt in 1680 to drive out the Spanish, and runners carried the plan. Spanish soldiers and settlers had come in 1598 under Juan de Oñate to take Pueblo land, labor and food.

**The arrests of 1675.** The Spanish governor Juan Francisco Treviño ordered the arrest of 47 Pueblo religious leaders in 1675 for "practicing sorcery," using magic. Spanish officials sentenced four of them to hang. They hanged three, and the fourth man killed himself. They whipped the others in public and put them in prison. Pueblo people went to Santa Fe and demanded that the prisoners be let go, and the Spanish released them. One of the men released was Po'pay, a Tewa leader from Ohkay Owingeh.

**The knotted cords.** Po'pay planned the revolt with towns that spoke at least five different languages. All of them had to rise on the same day. To set that day, he sent runners with knotted cords. Each town untied one knot a day, and when the last knot was untied, the revolt would begin. The accounts differ on the day planned. The National Museum of the American Indian gives August 11, and the Indian Pueblo Cultural Center gives August 13.

The revolt began on August 10, 1680, earlier than planned, because the Spanish caught two of the runners. Pueblo fighters killed about 400 people, including 21 of the 33 Spanish priests in New Mexico. Governor Antonio de Otermín led about 2,000 Spanish settlers out of Santa Fe on August 21 and south to El Paso. The Spanish did not return until 1692.

### Nicolás Catua and Pedro Omtua

> **Who:** Two young runners from Tesuque Pueblo who carried the knotted cords of the Pueblo Revolt.
>
> **When and where:** New Mexico, August 8 and 9, 1680.

**Their cord had two knots, and the Spanish hanged them for it.**

Pedro Omtua and Nicolás Catua set out on the morning of August 8, 1680, with cords for the Tano towns. They came from Tesuque Pueblo, whose Tewa name means "village of the narrow place of the cottonwood trees." The first town they reached was Pecos.

After they left Pecos, Christian Pueblo people told Fernando de Velasco that two Tewa messengers had visited the war chief's house. Velasco was a leader of the Franciscan missionaries, Catholic priests sent to turn the Pueblo people Christian. Two Pueblo leaders from the Galisteo Basin who sided with the Spanish also sent word of a revolt to Governor Antonio de Otermín. Otermín ordered the messengers arrested, and the Spanish caught them on August 9.

**Tortured, then hanged.** Spanish officials tortured Catua and Omtua to make them explain the knotted cord. Torture means hurting a person's body on purpose to force him to talk. The surviving accounts do not say how the two young men were hurt.

The historian Charles W. Hackett worked from Otermín's own records. He wrote in 1911 that the two told Otermín they had been given a cord with two knots, to carry to the chiefs of the Tano towns, San Marcos and La Cienega. The two knots stood for the two days left before the revolt. Then the Spanish hanged them. The accounts do not name the men who tortured and hanged them.

When Po'pay heard that the runners had been caught, he ordered the revolt to start a day early.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 10 minutes**

The first colonial newspaper that lasted began in Boston in 1704, and many of the men who printed the colonies' papers also ran the post office. Printers and postmasters started papers in Boston, Philadelphia, New York, Charleston and Williamsburg. Colonial governors and lawmakers still had printers jailed when the printers offended them. The owners made their money from advertisements, and some of those advertisements offered human beings for sale.

### The Boston News-Letter, 1704

John Campbell, the postmaster of Boston, published the first issue of the *Boston News-Letter* on April 24, 1704. It was one small sheet printed on both sides, and it came out once a week. A printer named Bartholomew Green printed it for Campbell. The words "Published by Authority," meaning with the approval of the people in power, appeared in its title from 1704 to 1720, and again from 1723 to 1725.

Most of the first issue was copied from London newspapers of mid-December, more than four months old. Local news filled one column. The *News-Letter* came out every week until February 1776, the first newspaper in the colonies to keep going. Boston had no other newspaper until the *Boston Gazette* began on December 21, 1719. The *American Weekly Mercury* started in Philadelphia the next day.

### The Courant: a paper the government did not approve, 1721 to 1726

James Franklin started the *New-England Courant* in Boston on August 7, 1721, during an epidemic of smallpox, an outbreak that spread to many people at once. He soon used the paper to take a side in a fight over how to stop the disease.

**Inoculation.** The minister Cotton Mather and the doctor Zabdiel Boylston urged people to try inoculation. A doctor put a little pus from a sick person into a cut in the skin of a healthy person. The healthy person usually got a mild case of smallpox and soon got well. Mather had learned of the method from Onesimus, an African man he had owned as a slave since 1706, and from other enslaved Africans.

Almost every doctor in Boston except Boylston opposed inoculation. James Franklin printed attacks in the *Courant* on the people who supported it. Someone threw a lit bomb through a window of Mather's house on November 14, 1721. A note with it read: "Cotton Mather, You Dog, Dam You: I'll inoculate you with this, with a Pox to you." The fuse came off, and the bomb did not explode. No record names the person who threw it.

Nearly 6,000 people caught smallpox in the epidemic, and 844 of them died. Boylston inoculated 248 people, and 98 out of every 100 of them lived. Among people who caught smallpox the ordinary way, 85 out of every 100 lived.

**A month in jail.** Pirates were raiding along the coast of New England in 1722. In June, James Franklin printed a short item in the *Courant* saying that Massachusetts officials were fitting out a ship to chase them. The ship, it said, would sail "some time this Month, if Wind and Weather permit." The item hinted that the officials were in no hurry to go after the pirates.

Massachusetts officials read it as a hidden attack on them. The members of the General Court, the colony's lawmakers, had James Franklin jailed for a month. His younger brother Benjamin, then 16, ran the paper while James was locked up. James was let out on July 2, 1722.

The members of the General Court then ordered censorship, checking and cutting what a printer may print before it comes out. Early in 1723 they forbade James Franklin to print the *Courant* unless officials checked each issue first. James then put the paper in Benjamin's name, and it came out that way until it closed in 1726.

### The Weekly Journal and the Zenger trial, 1733 to 1736

For years New York had one newspaper, the *New-York Gazette*. Its printer, William Bradford, printed for the government and supported Governor William Cosby. In 1733 Lewis Morris, the chief judge of New York, wrote a dissent, a judge's written disagreement with the other judges, in a court case of Cosby's called Cosby v. Van Dam. Cosby removed Morris from office.

**A second paper.** Morris and two lawyers, James Alexander and William Smith, then started the *New-York Weekly Journal* on November 5, 1733. Alexander edited it and used it to accuse Cosby and his officials of tyranny, cruel and unjust rule. John Peter Zenger, a printer born in Germany, printed it. Cosby had copies of the *Journal* burned by the hangman.

**Arrested for libel.** Officials arrested Zenger on November 17, 1734, for seditious libel. Under the law of that time, seditious libel meant printing blame of any official, of the law, or of anything the law had set up, without a lawful excuse. Whether the words were true did not matter.

The court set Zenger's bail, the money paid to a court so that a prisoner can go free until his trial, at £400. Zenger stayed in jail for more than eight months, until his trial.

**Not guilty.** At the trial, the judge would not let Zenger's lawyer prove that the printed words were true. The jurors, the judge said, must decide only whether Zenger had printed the papers. Zenger's lawyer told them they had the right to judge the law as well. The jurors went further than the judge allowed. They found Zenger not guilty on August 4, 1735. Chapter 20, Government, Law, and Politics, describes the trial in full.

The verdict changed no law. In New York, a printer could not defend himself by showing that his words were true until 1805, when the state's lawmakers passed a law that allowed it. An account of the trial came out as a pamphlet in 1736, *A Brief Narrative of the Case and Tryal of John Peter Zenger*. Printers reprinted it many times.

### Anna Catharina Zenger

> **Who:** The printer's wife who kept the *New-York Weekly Journal* coming out while her husband was in jail, and who ran the print shop after he died.
>
> **When and where:** New York City, 1734 to 1748.

**Instructions came, the story goes, through a hole in the jail door.**

Anna Catharina Zenger was born Anna Catharina Maulin, and she married John Peter Zenger on September 11, 1722. When officials jailed him, she took charge of the shop. She and his apprentices kept the *New-York Weekly Journal* coming out while he was held. They missed only one issue. The writer Ann T. Keene reports the story that Zenger gave her his instructions "through the hole of the door of the prison."

**After the trial.** Zenger became New York's official printer in 1737. He died on July 28, 1746. Anna Zenger then ran the family print shop for more than two years, until their eldest son, John, took it over in December 1748.

### Printers who were postmasters, and papers in German

A printer who was also the postmaster got the letters and newspapers from other towns first, and so got the news first. He could also stop the post riders from carrying a rival's newspaper.

**Bradford and Franklin.** Andrew Bradford printed the *American Weekly Mercury* in Philadelphia and also kept the town's post office. He forbade the post riders to carry Benjamin Franklin's paper. Franklin wrote that he got his papers carried only by bribing the riders to take them in secret.

Alexander Spotswood, a former governor of Virginia, was in charge of the post office for the colonies. He was unhappy with how carelessly Bradford kept the post office's accounts, and in 1737 he took the job away from Bradford and gave it to Franklin, who was 31.

Franklin also set up partners as printers in other towns. He made Lewis Timothy the printer of the *South-Carolina Gazette* in Charleston in November 1733. In Virginia, William Parks printed the first issue of the *Virginia Gazette* in Williamsburg on August 6, 1736. Virginia's lawmakers allowed only one printing office in the colony, and they wanted it to print what the government needed first.

**Papers in German.** Franklin tried a German-language paper, the *Philadelphische Zeitung*, in May and June 1732, and it failed. Christopher Sauer, a German printer in Germantown, started a German-language paper on August 20, 1739. His family printed it, under changing names, until 1777. Each month sixteen newspapers from Europe reached Sauer, and he took his news of Europe from them.

### Elizabeth Timothy

> **Who:** A widow born in Holland who ran the *South-Carolina Gazette*. The *South Carolina Encyclopedia* names her the first woman in the American colonies to own and publish a newspaper.
>
> **When and where:** Charleston, South Carolina, 1738 to 1746.

**A widow with six children, she owned the paper within a year.**

Elizabeth Timothy's husband, Lewis Timothy, printed the *South-Carolina Gazette* in Charleston under a six-year partnership with Franklin. He died in December 1738 after what was described at the time as "an unhappy Accident," meaning an unlucky one. He left her with six small children and a seventh about to be born. Franklin wrote that she was "born and bred in Holland."

Their eldest son, Peter, was too young to run the shop, so Elizabeth Timothy ran it herself. She printed the next issue on January 4, 1739, and promised to make the paper "as entertaining and correct as may be reasonably expected." By the end of 1739 she had bought out Franklin's share. Franklin praised how exactly she kept her accounts.

She handed the shop to Peter when he came of age in 1746 and opened a bookstore next to it. She died in 1757. In her will she left her children eight enslaved people, along with her other property.

### Advertisements for people as property

Newspaper owners made much of their money from advertisements, and some of those advertisements were for human beings. Franklin printed advertisements in the *Pennsylvania Gazette* that slave owners and slave traders paid for. Some offered enslaved people for sale. Others were notices about enslaved people who had escaped, so that readers would help catch them. According to the International Printing Museum, by the 1750s these made up nearly a quarter of the paper's advertisements.

Franklin himself owned enslaved people. According to the Benjamin Franklin House museum in London, he and his household held enslaved people from about 1735 until 1790 and bought at least seven people. Their names were Joseph, Jemima, Peter, King, Othello, George and Bob. Peter and King went with Franklin to London.

Enslaved people had no say in how owners and traders described them in those advertisements. In South Carolina, lawmakers made it a crime in 1740 even to teach an enslaved person to write.

### Benjamin Franklin

> **Who:** A Boston printer's apprentice who became a Philadelphia newspaper owner and the town's postmaster.
>
> **When and where:** Boston, 1718 to 1723, and Philadelphia, 1723 to 1753.
>
> **Movie:** *Benjamin Franklin* (2022), a documentary by Ken Burns about his life, shown on PBS.

**At 17 he ran away from his brother's print shop.**

Benjamin Franklin grew rich as a printer, and much of his money came from the advertisements in his newspaper. In 1718 he became an apprentice, a young worker bound to a master for years to learn a trade, to his older brother James, a printer in Boston. Benjamin carried copies of the *New-England Courant* through the streets to the people who paid for it. In 1722, at 16, he wrote letters to the paper under the made-up name "Silence Dogood." He later wrote that his brother "had often beaten me."

**Running away.** Benjamin broke his apprenticeship and ran away in 1723, at 17. He landed at the Market Street wharf in Philadelphia on a Sunday morning.

**The Gazette.** Franklin bought the *Pennsylvania Gazette* from the printer Samuel Keimer on October 2, 1729. Advertising became the paper's main source of money, and Franklin grew the paper from two pages to four, partly to hold more advertisements.

He began *Poor Richard's Almanac*, a book that came out once a year with a calendar and other useful facts, in 1732. He wrote it under the made-up name Richard Saunders. He said that he sold "near ten thousand" copies a year, and that ordinary people "bought scarcely any other books."

**The post office.** As postmaster of Philadelphia, Franklin wrote that the post office "facilitated the correspondence that improv'd my newspaper." He meant that the job helped him get the letters and news that made his paper better, and with them more readers and more advertisements. British officials named him and William Hunter in 1753 to run the royal post office for all the colonies together.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 16 minutes**

Printers, letter writers and post riders carried the news and the arguments that led to the American Revolution. Supporters of independence also wrecked the press of a New York printer who took Britain's side. Once the war was won, the new country's leaders fought over how free the press should be.

Lawmakers in three-fourths of the states approved the First Amendment to the Constitution in 1791, and it protects freedom of the press. Seven years later the Federalists, President John Adams's party, used their majority in Congress to pass the Sedition Act. Federal judges then jailed newspaper editors who had criticized Adams.

### The Stamp Act and the printers, 1765

The members of Parliament in London, Britain's lawmakers, passed the Stamp Act in March 1765. It took effect on November 1, 1765. Under it, colonists had to pay a tax on newspapers, pamphlets, almanacs and legal papers. Printers had to print on stamped paper made in London, which showed that the tax was paid.

**The tax.** Colonists paid a halfpenny, a small British coin, on each copy of a newspaper printed on half a sheet of paper, and a penny on each copy printed on a whole sheet. They paid two shillings, or 24 pennies, on each advertisement in a newspaper.

**Black borders.** The Philadelphia printer William Bradford printed his *Pennsylvania Journal* on October 31, 1765, the day before the tax began, with thick black borders, like a tombstone. In the place for the official stamp he printed a skull and crossbones. Across the top of the front page he printed that the paper was "EXPIRING," or dying, "In Hopes of a Resurrection to LIFE again."

This William Bradford was born in 1722 and was a different man from the New York printer of the same name. He never actually stopped printing. He put out the next issue on November 7.

John Hughes had the job of handing out the stamps in Philadelphia. Opponents of the tax threatened him with violence and with destroying his property, and he promised not to enforce the act. The members of Parliament voted in 1766 to repeal, or cancel, the Stamp Act.

### Committees of correspondence, 1772 to 1774

Samuel Adams proposed a committee of correspondence for Boston, a small group of men chosen to write letters to other towns and share news. Boston's town leaders voted on November 2, 1772, to set up a Committee of Correspondence of 21 men. They did it in answer to news that the colony's judges would now get their pay from the royal treasury, the king's own money.

The 21 men wrote a set of reports on the colonists' rights and on how Parliament had broken them. Printed as the Boston Pamphlet, the reports went to every town in Massachusetts.

**Virginia's committee.** Dabney Carr asked the members of Virginia's House of Burgesses, the colony's elected lawmakers, to set up an 11-man committee on March 12, 1773, and they did. Patrick Henry and Thomas Jefferson were two of its members.

The 11 men wrote to the lawmakers of the other colonies. They asked them to share news of laws from London and of what each colony's leaders planned to do about them. Within a year, lawmakers in eleven colonies had set up their own committees. North Carolina and Pennsylvania were the two that did not.

### The news of Lexington, April 1775

British soldiers fired on the militia, ordinary men trained to fight when they were called, at Lexington, Massachusetts, on the morning of April 19, 1775. At about 10 o'clock that morning, in Watertown, Joseph Palmer wrote a letter "To all the Friends of American liberty." It said the soldiers had killed six men and wounded four.

Palmer was a member of the Massachusetts Committee of Safety. The colonists' own congress had set up this committee to gather supplies for a fight with the British army in Boston and to spread the alarm if the army marched.

**Copy by copy.** Palmer gave the letter to a rider, Isaac Bissell, to carry toward Connecticut. At Worcester the town clerk, Nathan Baldwin, copied the letter, wrote that the copy was true and signed it. Someone made another copy at Springfield. Other riders then carried copies on, and the alarm reached Philadelphia five days and seven hours after it left Watertown.

Palmer took care to make his letter believable. Seven months earlier, in September 1774, thousands of militiamen had turned out for nothing after false rumors of a British attack.

### Isaac Bissell

> **Who:** A 26-year-old blacksmith from Suffield, Connecticut, who carried a written report of the killings at Lexington from Massachusetts toward Connecticut.
>
> **When and where:** From Watertown, Massachusetts, to Connecticut, April 19 and 20, 1775.

**His name was Isaac, not Israel, and he stopped in Connecticut.**

Isaac Bissell came from Suffield, a town on Connecticut's northern border. He was in Watertown, Massachusetts, on April 19, 1775, when Joseph Palmer handed him the letter. The letter said that "the Bearer Mr. Isaac Bissell" was "charged to alarm the country quite to Connecticutt." His job was to warn people all the way to Connecticut. The letter asked people along the way to give him the horses he needed.

Bissell reached Worcester in the early afternoon. On the morning of April 20 the letter reached Connecticut's leaders.

**Too fast to believe.** In Wethersfield, the home town of Governor Jonathan Trumbull, Silas Deane wrote in his journal that the news "was discredited," not believed, "from the suddeness of its arrival." After men from Massachusetts confirmed the news, Trumbull agreed to call Connecticut's lawmakers together.

**The unpaid bill.** Bissell then joined the siege of Boston, where colonial soldiers surrounded the British army in the town. He served as a private in Captain Elihu Kent's company from Suffield. In July 1775 the members of the Massachusetts committee of safety approved his bill as a post rider, two pounds and one shilling. The colony's treasurer then would not pay it without a signed approval from the colony's congress.

**The story that grew.** Many books call the rider "Israel Bissell" and say he rode all the way to Philadelphia. The historian J. L. Bell found that his name was Isaac, that he carried the letter only as far as Connecticut, and that the long ride to Philadelphia is a story that grew up later. Many riders, most of them unnamed, carried the news the rest of the way.

### Common Sense and the Declaration in print, 1776

The printer Robert Bell published *Common Sense* on January 10, 1776. It was a pamphlet by Thomas Paine that argued for independence from Britain. Printers printed it at least twenty-five times, sixteen of them in Philadelphia.

**The claims.** Paine claimed in April 1776 that 120,000 copies had sold, and later he claimed 150,000. Moncure Conway, who wrote a book about Paine's life, guessed half a million in 1892.

**Not known:** No sales records survive, so nobody knows the real number. The historian Trish Loughran put the highest possible number at 75,000, and she thinks the real number was much lower.

**The Declaration.** Members of the Continental Congress, the meeting of men sent by each colony to act for all of them, declared independence in Philadelphia on July 4, 1776. Over that night the Philadelphia printer John Dunlap printed about 200 copies of the Declaration of Independence as broadsides.

The members of Congress ordered the copies sent to the new states and to the soldiers, read aloud, and put up in public places. George Washington's soldiers in New York City heard it read aloud on July 9. Twenty-six of Dunlap's copies are known to survive.

### Thomas Paine

> **Who:** An English-born writer whose pamphlet *Common Sense* argued that the colonies should declare independence.
>
> **When and where:** Philadelphia, 1774 to 1776, and with the army, 1776.

**He promised his share of the profits to buy mittens for soldiers.**

Thomas Paine met Benjamin Franklin in London, and Franklin gave him letters of introduction to people in America. Paine arrived in Philadelphia on November 30, 1774. He helped edit the *Pennsylvania Magazine* and wrote articles under pen names, made-up names that hid who the writer was.

**The slavery essay.** For a long time Paine was named as the writer of "African Slavery in America," an essay printed in March 1775 under the name "Justice and Humanity." The essay calls slavery unjust. Gary Berton of the Thomas Paine National Historical Association later concluded that a Rhode Island minister, Samuel Hopkins, most likely wrote it, so the accounts differ.

**Common Sense.** The pamphlet came out on January 10, 1776. Paine agreed to pay for the printing whether it sold or not, and the printer, Robert Bell, was to get half of any profits. Paine promised his own half to buy mittens for the American soldiers outside the city of Quebec, in Canada, that winter. Bell handed over no money.

Then Bell printed a second edition that Paine had told him not to print. Paine took a new, longer edition to the printers of the *Pennsylvania Journal* instead. He never received any money from the sales. He later wrote that he gave the right to print it to every state.

Paine published *The American Crisis* on December 19, 1776. It began, "These are the times that try men's souls." Washington ordered it read to all his troops. Paine died in New York City on June 8, 1809.

### A Loyalist printer's press wrecked, 1775

Colonists who stayed loyal to Britain were called Loyalists, and supporters of independence attacked the printers among them. The New York printer James Rivington printed the *New-York Gazetteer*, one of the most widely read newspapers in the colonies, and he used it to back the British government.

**The press wrecked.** Isaac Sears led a group of Sons of Liberty, colonists who organized against British taxes and rule, from New Haven, Connecticut, to Rivington's shop in New York City in November 1775. The men wrecked Rivington's press and his type, the set of metal letters that a printer puts together by hand to print a page. Type was a printer's most valuable possession. Rivington left for England a few weeks later.

After British soldiers captured New York, Rivington came back with the title of King's Printer, the official printer for the British government there. He printed his paper on the British side until the British left in November 1783.

### A postal service for the new country, 1774 to 1792

British officials fired Benjamin Franklin from his job running the royal post office in the colonies in 1774. In the words of the Postal Service's own history, he was "too much of an American."

**A rival post.** The printer William Goddard set up a rival mail service, which he called the Constitutional Post. He warned that letters could be stopped and opened on the orders of the king's ministers, the men who ran Britain's government. What the letters said, he warned, could be twisted into proof of treason, the crime of betraying one's own government. By 1775 Goddard's service had nearly 50 post offices from Maine to Virginia.

The members of the Continental Congress made Franklin their postmaster general, the head of their post office, on July 26, 1775, at $1,000 a year.

**Post roads.** The Constitution, approved in 1788, lists among the powers of Congress the power "To establish Post Offices and post Roads." In 1789 the country had 75 post offices and about 2,400 miles of post roads, for almost four million people. The members of Congress passed a new law about the mail on February 20, 1792. Under it, printers could send newspapers through the mail at very low rates, some for free. The law also forbade postal officials to open people's letters.

### Mary Katharine Goddard

> **Who:** A printer and newspaper publisher who ran Baltimore's post office for 14 years and printed the first copies of the Declaration that listed the signers.
>
> **When and where:** Baltimore, Maryland, 1774 to 1789.

**Readers could pay for her newspaper in beeswax or pork.**

Mary Katharine Goddard learned printing in her brother William's shop in Providence, Rhode Island, in the 1760s. She moved to Baltimore in 1774. She ran his print shop and his newspaper, the *Maryland Journal*, during his many trips away, and she reprinted *Common Sense* in it.

**Postmaster.** She became the postmaster of Baltimore in 1775. Postal Service historians call her the first known woman postmaster in the colonies. Postmasters then earned a share of the postage instead of a salary. The members of Congress often failed to pay her, so she paid the post riders and the high rent of the office herself. In 1778 she let readers pay for the newspaper in beeswax, flour, lard, butter, beef or pork.

**The Declaration with names.** The Continental Congress was meeting in Baltimore in January 1777. Its members ordered new copies of the Declaration of Independence, and Goddard printed them on January 18. Hers were the first printed copies to show the signers' names. At the bottom she printed "Baltimore, in Maryland: Printed by Mary Katharine Goddard." Nine of her copies are known to survive.

**Pushed out.** Her brother William "apparently forced his sister out" of the *Maryland Journal* in January 1784, Smithsonian Magazine reports. The new postmaster general, Samuel Osgood, replaced her with a man in October 1789. Osgood's assistant, John Burrell, said the job might need "more travelling ... than a woman could undertake."

More than 200 people in Baltimore signed a letter asking Osgood to give her the job back. She wrote to President George Washington and to the Senate, and neither helped her. She ran a bookshop in Baltimore until about 1810, and she died there on August 12, 1816.

### The First Amendment and the party papers, 1789 to 1793

The First Amendment, an addition to the Constitution, took effect on December 15, 1791. It states that "Congress shall make no law ... abridging," or cutting back, "the freedom of speech, or of the press."

**Party papers.** Newspaper editors took sides in the quarrels inside Washington's government. John Fenno used his *Gazette of the United States* to push the plans of Alexander Hamilton, the head of the Treasury. Secretary of State Thomas Jefferson called Fenno's paper "a paper of pure Toryism," using the old name for colonists who had sided with Britain's king.

Jefferson hired Philip Freneau as a translating clerk at the State Department, paid $250 a year, even though Freneau knew only English and French. Freneau started the *National Gazette* on October 31, 1791. It came out twice a week and had about 1,700 subscribers, people who paid to get each issue. Freneau closed it on October 26, 1793.

Benjamin Franklin's grandson, Benjamin Franklin Bache, printed a paper in Philadelphia called the *Aurora*. In it he attacked Washington and John Adams.

### The Sedition Act, 1798 to 1801

American and French warships began fighting each other in the Caribbean Sea in 1798. President John Adams's party, the Federalists, held a majority in Congress. The Federalist members voted through the Sedition Act, named for sedition, the crime of stirring people up against their government. Adams signed it on July 14, 1798.

**What it banned.** Under the act, it was a crime to write or print "any false, scandalous and malicious writing" against the federal government, Congress or the President. The punishment was a fine of up to $2,000 and up to two years in prison. Unlike the law in the Zenger trial, the act let a person charged try to prove that his words were true, and the jury could decide what the law meant as well as what the facts were.

**Who was charged.** Federal prosecutors and judges used the act mostly against editors of newspapers that supported Jefferson's party, the Democratic-Republicans. The counts of people found guilty differ. The lowest is 10, the number scholars long used. The highest, from the National Constitution Center, a museum about the Constitution, is more than two dozen. The legal historian Wendell Bird found cases against 16 people that the old count missed.

**Some of those charged.** They included Congressman Matthew Lyon of Vermont, William Duane of the *Aurora*, Ann Greenleaf of New York's *Argus*, and Anthony Haswell of the *Vermont Gazette*. Luther Baldwin and Brown Clark of Newark, New Jersey, were charged for words they spoke against President Adams in a tavern.

**Bache.** Federalist supporters physically attacked Benjamin Franklin Bache in Philadelphia. Jonathan Dayton of New Jersey, a Federalist, was Speaker of the House of Representatives, the member chosen to run its meetings. Dayton barred Bache from the floor of the House, the room where its members met, so that he could not report its debates.

A federal judge in Philadelphia, Judge Peters, signed an order for Bache's arrest on June 24, 1798, more than two weeks before the Sedition Act became law. The charge was seditious libel against President Adams, the same crime that officials had charged Zenger with in 1734. Peters let Bache out on bail, and his trial was set for October.

Bache kept printing the *Aurora* through an epidemic of yellow fever, a disease carried from person to person by mosquitoes. He died of the fever on September 10, 1798, at 29, a month before his trial date. His widow kept the paper going, with William Duane as editor. The text of the Sedition Act stated that it would stay in force only until March 3, 1801.

### Matthew Lyon

> **Who:** An Irish-born congressman and newspaper owner, the first person tried under the Sedition Act.
>
> **When and where:** Vermont, 1798 to 1799.

**He ran for Congress from a jail cell and won.**

Matthew Lyon came to America from Ireland and fought in the Revolutionary War. He went to Congress for Vermont in 1797, and he also owned a newspaper. In 1798 he became the first person tried under the Sedition Act.

**His words.** In a letter that a newspaper printed, Lyon wrote of seeing the public good "swallowed up in a continual grasp for power, in an unbounded thirst for ridiculous pomp, foolish adulation, or selfish avarice." Adulation is an old word for too much praise, and avarice for greed. At campaign meetings he also read aloud a letter by the poet Joel Barlow, which said Adams should be sent to a "madhouse."

**The trial.** A federal grand jury in Vermont, a group of citizens who decide whether there is enough evidence to charge someone, charged Lyon with three crimes under the Sedition Act on October 5, 1798. A deputy marshal, an officer who made arrests for the federal courts, arrested him the next day. At his trial in Rutland on October 9, Lyon defended himself. He pleaded not guilty, and in a second plea he stated that the Sedition Act broke the Constitution.

Justice William Paterson of the Supreme Court told the jury that its job had "nothing whatever to do with the constitutionality or unconstitutionality of the sedition law." He meant that the jurors must not decide whether the law broke the Constitution. The jurors came from towns that supported Adams's party. They found Lyon guilty within an hour. Paterson sentenced him to four months in jail and a $1,000 fine.

Lyon was held in the jail at Vergennes. He ran for Congress again from his cell, and the voters of his district re-elected him. He was let out on February 9, 1799.

**If you remember one thing:** Printers and riders carried the news of the Revolution, and seven years after the First Amendment took effect, federal judges were jailing editors under the Sedition Act.

- April 19, 1775: Joseph Palmer's letter about Lexington starts a chain of riders that reaches Philadelphia five days and seven hours later.
- December 15, 1791: The First Amendment takes effect.
- October 9, 1798: A jury finds Congressman Matthew Lyon guilty, the first person tried under the Sedition Act.

**Next:** By 1850 the country had 2,526 newspapers, and Black and Cherokee editors had started papers of their own.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 16 minutes**

The fight over slavery reached into the print shops and the post office as newspapers spread across the country. The number of American newspapers grew from about 900 in the 1830s to 2,526 in 1850. That year they printed half a billion copies, for a population of about 23 million, or about 22 copies for every person.

A New York printer began selling a daily paper for one cent in 1833, when most daily papers cost six cents. From 1844 news could travel along a telegraph wire, faster than any horse or train.

Free Black New Yorkers started the first Black-owned newspaper in 1827, and Cherokee leaders started the first Native American paper a year later. Men who defended slavery attacked the editors who wrote against it. Men of the Georgia Guard, a band of armed men from the state of Georgia, seized the Cherokee press in 1835. That same year Amos Kendall, the Postmaster General, who ran the post office, let Southern postmasters hold back antislavery papers. In Illinois in 1837, a mob killed an editor who was defending his press.

### The last Sedition Act trials, 1800

The Sedition Act was still the law in 1800, and federal judges used it that year against two more writers. Under the act it was a crime to print "false, scandalous and malicious" writing against the government, Congress or the President.

**Callender.** A grand jury, a group of citizens who decide whether there is enough proof for a trial, charged the writer James Callender in the federal court at Richmond, Virginia, on May 24, 1800. The charge was over his pamphlet *The Prospect Before Us*, in which Callender wrote words that harmed the good name of President John Adams. The trial began on June 3, and the jury found him guilty the same day.

Justice Samuel Chase sentenced Callender to nine months in prison and a fine. The Federal Judicial Center's history of the trials states the fine as $400 in one place and $200 in another.

**Cooper.** In Philadelphia the same year, Chase sentenced the writer Thomas Cooper to six months in prison. The same history gives Cooper's fine as $400 in one place and $500 plus court costs in another.

The act ended on March 3, 1801. After Thomas Jefferson became president that year, he pardoned, or officially forgave, Callender. Jefferson also paid $50 of his own money toward giving back Callender's fine.

### Newspapers by mail, and who could carry it

Newspapers went to readers through the mail. Under the postal law of 1792, readers got newspapers by mail at very low rates, and editors mailed their papers to each other for free. A small-town editor could then reprint news from papers all over the country. Indiana had one newspaper in 1810 and 73 by 1840.

**More than Europe.** In 1840 the United States had about 17 million people, and Europe had about 230 million. Even so, more copies of American newspapers went out each week than of all the newspapers in Europe.

Most people who worked for the federal government worked for the post office. By 1831, 76 of every 100 federal workers outside the army and navy were postal workers. Postmasters outnumbered soldiers, 8,764 to 6,332.

Letters cost much more to mail than newspapers. From 1799 to 1815, one sheet of paper cost 8 cents to send 40 miles or less, and up to 25 cents to send more than 500 miles. A second sheet doubled the price. In 1845 postal officials began charging by weight instead, and in 1847 they began selling postage stamps.

**"Free white persons."** Some enslaved men carried the mail in the South until 1802. That March, Postmaster General Gideon Granger warned a senator that enslaved post riders, "hourly mixing with people," would "acquire information." "They will learn that a man's rights do not depend on his color," he wrote. "They will, in time, become teachers to their brethren," meaning their brothers.

Granger began his letter by pointing to "the scenes which St. Domingo has exhibited to the world." On Saint-Domingue, a French island colony in the Caribbean, the enslaved people had risen in a revolution.

Members of Congress then passed a law, and from 1802 to 1865 the postal laws said that mail carriers had to be "free white persons." A mail contractor, a person paid to carry the mail, who broke the rule had to pay a fine. The Postal Service's own history of Black postal workers names no one who was fined. For 63 years, no Black American, free or enslaved, could legally carry the mail.

### Freedom's Journal, the first Black-owned newspaper, 1827

A group of free Black New Yorkers met in March 1827 to start a newspaper of their own. It was the first newspaper in the United States owned and run by Black Americans. Samuel Cornish and John Brown Russwurm edited it. Cornish was a Presbyterian minister, a preacher in one of the Protestant churches. Russwurm was one of the first Black Americans to graduate from a college in the United States.

*Freedom's Journal* came out on March 16, 1827, from 5 Varick Street in Manhattan. In the first issue the editors wrote: "We wish to plead our own cause. Too long have others spoken for us." Editors of other New York papers printed attacks on Black people, and Cornish and Russwurm answered them. They also wrote against slavery.

**Readers in 11 states.** A year of the paper cost $3. More than 800 copies went out to readers in 11 states and Washington, D.C., and copies also went to Canada, Europe and Haiti. David Walker was one of the agents who sold subscriptions to it.

Russwurm came to support a plan called colonization, which meant sending free Black Americans to live in Africa. Cornish opposed the plan and quit in September 1827. The last issue of *Freedom's Journal* came out on March 28, 1829. Russwurm moved to Liberia, in Africa, and started a newspaper there.

### The Cherokee Phoenix, 1828 to 1835

The *Cherokee Phoenix* was the first newspaper printed by a Native American nation. The members of the Cherokee Nation's council set aside $1,500 in 1825 for a printing press and type. Samuel Worcester, a missionary, or Christian preacher sent to win people to his faith, helped the Cherokee set up a print shop at New Echota, their capital. New Echota was in land that the state of Georgia claimed. An iron press came by ship from Boston.

**Type for Sequoyah's letters.** Workers cast type for the Cherokee syllabary, the writing system that Sequoyah made, in which each of 85 symbols stands for a syllable. The first issue came out on February 21, 1828. Columns in Cherokee ran beside columns in English. The Cherokee leaders who ran the paper opposed every plan to move the Cherokee west, and they used it to argue their side.

Georgia and federal officials made the paper hard to keep going. Colonel Charles Nelson commanded the Georgia Guard, a unit that Georgia officials set up to police the Cherokee land their state claimed. He threatened to shut the paper down and to beat its editor.

**The money cut off.** President Andrew Jackson ordered the federal government's yearly payment to the Cherokee Nation paid to separate people instead of to the Nation. That cut off the paper's money. Georgia officials ordered the paper's white printer to leave. A local sheriff sued the editor, Elijah Hicks, for libel, printing false words that harm someone. The last issue came out in May 1834.

John Ross, the Principal Chief, the Cherokee Nation's top leader, planned in 1835 to start the paper again. Men of the Georgia Guard went to New Echota, took the press and threw out the type. Two accounts say they also burned the building, and that Stand Watie, a Cherokee who supported moving the Cherokee west, helped them. The records do not name the officer who led them.

A new Cherokee Nation newspaper, the *Cherokee Advocate*, began in Tahlequah in September 1844, with William Potter Ross as its editor.

### Elias Boudinot

> **Who:** A Cherokee writer who edited the *Cherokee Phoenix*, the first Native American newspaper, and later, with a small group of Cherokee, signed a treaty that gave up the Cherokee homeland.
>
> **When and where:** New Echota, Cherokee Nation, in present-day Georgia, 1826 to 1835, and Park Hill, Indian Territory, 1837 to 1839.

**He edited the Cherokee paper, then signed away the Cherokee homeland.**

Elias Boudinot was born in the Cherokee Nation, in what is now northwest Georgia. His Cherokee name was Gallegina, which means "the Buck."

As a young man he studied at a school run by missionaries in Cornwall, Connecticut, and there he took the name of Elias Boudinot, the president of the American Bible Society. In Cornwall he became engaged to Harriet Gold, a white woman. Opponents of the marriage burned the couple in effigy, setting fire to dummies made to look like them. The two married in 1826.

**The press.** That year Boudinot went on a speaking tour that included Philadelphia. In a speech called "An Address to the Whites" he asked for money for a Cherokee press, and he collected it. When the *Cherokee Phoenix* began in 1828, he was its editor. The paper printed reports of the Georgia Guard's campaign against the missionaries in the Cherokee Nation, and the Guard's commander, Charles Nelson, threatened to beat Boudinot.

**The treaty.** Members of Congress passed the Indian Removal Act in 1830. Under it, the president could make treaties, written agreements between nations, with Native nations to move them west. In 1832 Boudinot's cousin John Ridge began to speak openly for moving west, and Boudinot began writing in the paper in favor of it. Principal Chief John Ross opposed moving west on any terms. Ross pressured Boudinot to resign, and he did on August 1, 1832.

In December 1835 Boudinot and a small group of Cherokee signed the Treaty of New Echota. In it they gave all Cherokee land east of the Mississippi River to the United States for five million dollars. They also agreed that the Cherokee would move west to Indian Territory, in what is now Oklahoma.

**Killed under Cherokee law.** Boudinot moved west to Park Hill, in Indian Territory, in 1837. A group of Cherokee who supported John Ross stabbed him to death there on June 22, 1839. On the same day, other men killed his uncle, Major Ridge, and his cousin John Ridge, who had also signed the treaty. The killers were never identified or tried.

A man named Allen Ross described a secret meeting before the killings. He told of it in 1890. The men at the meeting decided that the three should die under a Cherokee law. That law said anyone who agreed to sell the Nation's land "should forfeit their lives," meaning they should be put to death.

### Newspapers against slavery, and the men who attacked them, 1831 to 1835

William Lloyd Garrison, a white abolitionist, someone who worked to end slavery, began *The Liberator* in Boston on January 1, 1831. Garrison demanded an immediate end to slavery, with no payment to the enslavers. About 3,000 people paid for his paper.

The drawing across the top of its front page showed whippings and the sale of children, set in Washington, D.C. Garrison believed that "slavery and freedom of the press cannot exist together." By 1835 members of the American Anti-Slavery Society were printing more than a million papers and pamphlets a year.

**Mail burned in Charleston.** Members of the society mailed their papers to people in the South in the summer of 1835. A small group of men broke into the post office in Charleston, South Carolina, on the night of July 29. They took the bags of antislavery papers, and a mob burned them. Opening or holding back the mail was against federal law. Even so, Postmaster General Amos Kendall, a close ally of President Andrew Jackson, gave Southern postmasters permission to refuse to deliver antislavery papers.

**Garrison dragged.** A crowd gathered outside *The Liberator*'s office in Boston on October 21, 1835, where the Boston Female Anti-Slavery Society was meeting. A newspaper of the time put the crowd at 5,000. A member of the society later described the men as "gentlemen of wealth and standing."

The men forced the women out, seized Garrison, tied a rope around his waist and dragged him through the streets. They nearly tarred and feathered him. Tarring and feathering means pouring warm pine tar over a person's body and then covering it with feathers, and the tar often blistered or burned the skin.

The mayor stopped them and had Garrison held in the city jail overnight for his own safety. Garrison later wrote that "every mail" brought letters telling him he had "only so many days to live."

### Elijah Lovejoy

> **Who:** A white Presbyterian minister and newspaper editor who wrote against slavery and was shot dead by a mob while defending his press.
>
> **When and where:** St. Louis, Missouri, 1833 to 1836, and Alton, Illinois, 1836 to 1837.

**Men who supported slavery broke four of his presses, then shot him.**

Elijah Lovejoy wrote against slavery in a state where slavery was legal. He became the editor of the *St. Louis Observer*, a Presbyterian weekly paper in St. Louis, Missouri, in 1833. A group of leading men in St. Louis signed a letter in 1835 asking him to tone down what he wrote. He refused.

**Francis McIntosh.** A white mob in St. Louis chained Francis McIntosh, a free Black steamboat worker, to a tree and burned him alive on April 28, 1836. Judge Luke Lawless refused to convict anyone and blamed abolitionists. Lovejoy attacked the judge in the *Observer*. In May 1836 men in St. Louis threatened him with mob violence and ran him out of town.

He moved his paper across the Mississippi River to Alton, in the free state of Illinois. Men in Alton who supported slavery destroyed his press three times. They threw one press from a second-floor window. A fourth press arrived by steamboat on November 6, 1837. Lovejoy and his supporters stored it in a stone warehouse owned by Benjamin Godfrey and Winthrop Gilman.

**The warehouse.** A mob surrounded the warehouse the next night. Its members said they would burn the building and kill every man inside. About twenty men inside had guns, and one of them shot and killed a man in the mob named Bishop. A man from the mob climbed a ladder to set fire to the roof. When Lovejoy stepped outside, men in the mob shot him five times. He was 34. The mob went into the warehouse, broke the press and threw it into the river.

**The trials.** No one was ever charged with killing Lovejoy. In January 1838 Alton's prosecutors, the lawyers who bring charges for the government, put twelve of the press's defenders on trial for riot. Illinois Attorney General Usher F. Linder, the state's top lawyer, joined the case against them. A jury found Gilman not guilty in ten minutes, and the city attorney dropped the charges against the other eleven.

Prosecutors then tried men from the mob, on January 19, 1838, for breaking into the warehouse and destroying the press. This time Linder was the lawyer for the mob. The jury found the men not guilty.

**The men from the mob who were tried:** Frederick Drucher, William Carr, James M. Hock, David Butler, Horace Beall, Levi Palmer, and two men named Nutter and Jennings.

### The penny press, 1833

Benjamin Day, a New York printer, started *The Sun* in 1833, partly to bring more work to his print shop. Most daily papers cost six cents. Day sold *The Sun* for one cent a copy, a penny, so people with little money could buy it every day. Boys sold it on the street. Day printed crime stories, and he hired George Wisner, the first police reporter in the United States, to write short reports from the police office.

**Life on the Moon.** Day printed a made-up report in *The Sun* in 1835 that living creatures had been found on the Moon. Sales rose, and critics attacked Day when readers learned it was false. By 1839 *The Sun* sold 50,000 copies a day. Day paid for the paper mostly by selling advertisements. By 1842 New York City had nine daily papers that cost one or two cents.

### The telegraph, 1844, and who owned it

Members of Congress voted Samuel Morse $30,000 in 1843 to build a test line from Washington to Baltimore for his telegraph, which sends messages along a wire as pulses of electricity. Morse sent the first message over the line from the US Capitol on May 24, 1844: "What hath God wrought," old words for "What has God done." Alfred Vail received it in Baltimore and sent it back.

**Who owned the wires.** Morse and his partners tried to sell the right to use his invention to the federal government and to groups of businessmen. No one bought it. Morse hired Amos Kendall, the former Postmaster General, to run the business. Kendall sold the right to use Morse's patent, the legal right to be the only one to make or use an invention, to separate companies, one region at a time.

Census Bureau officials, who count the people for the government, reported 75 telegraph companies with 21,147 miles of wire in 1851. Private companies owned the lines. From 1844 on, many newspapers printed a section headed "News by Telegraph."

The war between the United States and Mexico began in 1846, and fast news of the war cost much more than news had cost before. Moses Yale Beach, who owned *The Sun*, got the owners of the leading New York papers, six counting his own, to share the cost. That group grew into the New York Associated Press.

### Frederick Douglass

> **Who:** A man who escaped slavery in Maryland and started his own newspaper, the *North Star*.
>
> **When and where:** Rochester, New York, from 1847.
>
> **Movie:** *Becoming Frederick Douglass* (2022), a PBS documentary about his life, directed by Stanley Nelson.

**His paper's motto began: "Right is of no sex."**

Frederick Douglass started his own newspaper because he believed that Black Americans had to lead the fight for their own freedom. He was born enslaved in Talbot County, Maryland, in February 1818, and he escaped on September 3, 1838.

**Speeches first.** Douglass spoke about his life in slavery at a meeting of the Massachusetts Anti-Slavery Society on Nantucket island in 1841. The society's leaders then asked him to travel and give speeches for pay. He published the story of his life in 1845. He then gave speeches in Britain and Ireland, and the money from that tour paid to start his paper.

Douglass broke with Garrison in the late 1840s over whether politics could help end slavery, because Douglass came to believe that political action could. He published the first issue of the *North Star* in Rochester, New York, on December 3, 1847. Its motto was "Right is of no sex, Truth is of no color, God is the Father of us all, and we are brethren."

The *North Star* was four pages long and came out every week. It had more than 4,000 subscribers in the United States, Europe and the West Indies. On the front page Douglass wrote that the paper would "attack SLAVERY in all its forms and aspects." He also wrote that it would "promote the moral and intellectual improvement of the COLORED PEOPLE," using a word Americans of that time used for Black people. Its first printer and publisher was William Cooper Nell, a Black man from Boston.

**If you remember one thing:** Newspapers got cheaper and faster, and men who defended slavery burned antislavery mail, wrecked presses and killed an editor.

- In 1800: A federal judge sent James Callender to prison for his words about President Adams, and news traveled no faster than a horse or a ship could carry it.
- In 1850: The country had 2,526 newspapers, a daily paper could cost one cent, and news crossed the telegraph wires.

**Next:** A telegraph wire crossed the continent in 1861, and the Civil War sent reporters to the battlefields.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 19 minutes**

One company, Western Union, came to carry nearly every telegram in the country, while army officers and white mobs shut down newspapers. A telegraph wire crossed the continent in 1861, and by 1866 Western Union had more than 90 percent of the country's telegraph business. During the Civil War, Northern editors sent dozens of reporters to the battlefields. Generals of the Union, as the Northern side in the war was called, and members of Lincoln's cabinet closed newspapers and had editors arrested without trials.

Boston's postmaster hired the first Black American known to work for the federal government in 1863. In New York, Joseph Pulitzer and William Randolph Hearst competed for readers, and some of the stories they printed were false. Postal workers began carrying mail to farm families at their homes in 1896. White men drove Black editors out of Memphis in 1892 and out of Wilmington, North Carolina, in 1898. In Wilmington a white mob burned a Black-owned newspaper and murdered Black men in the streets.

### The Pony Express and the wire across the continent, 1860 to 1861

William H. Russell and his partners, Alexander Majors and William B. Waddell, started the Pony Express on April 3, 1860. Riders carried mail on horseback nearly 2,000 miles, from St. Joseph, Missouri, to Sacramento, California, across land where mostly Native Americans lived. The riders changed horses every 10 to 15 miles and covered 75 to 100 miles a day. The first run took ten days.

**Lincoln's speech in under eight days.** The riders carried President Abraham Lincoln's inaugural address, the speech a new president gives on taking office, across in 7 days and 17 hours in March 1861. The company charged as much as $5 for half an ounce of mail, when ordinary postage was ten cents or less. Workers finished the first telegraph line across the continent on October 24, 1861. Two days later the Pony Express shut down.

### News of the Civil War, 1861 to 1865

The North had far more newspapers than the South when the Civil War began. In 1860 fewer than 10 of every 100 print shops in the country were in the South. The South had 70 of the country's 387 daily papers, and those 70 sold only about 10 of every 100 daily copies.

Soldiers of the Confederacy, the Southern states that had broken away from the United States, fired on Fort Sumter in April 1861. The next day the *New York Herald* printed 135,000 copies, about as many as all the South's daily papers together. Only about 20 Southern daily papers were still printing when the war ended.

**Reporters with the armies.** The editors of the *New York Herald* alone kept more than 40 reporters with the armies. At Gettysburg the telegraph lines had been cut. A. Homer Byington of the *New York Tribune* repaired the wires near Hanover, and in return he got the first use of them. George W. Smalley of the *Tribune* wrote his story of the Battle of Antietam, in September 1862, on a train to New York. The *Tribune* had thousands of copies on the streets the second morning after the battle.

Southern papers could no longer get the news of the Associated Press, the group of New York papers that shared news. So Southern publishers started their own Press Association in 1862.

Photographs of the time could not show action or reach many readers quickly. The editors of weekly papers such as *Frank Leslie's Illustrated Newspaper* and *Harper's Weekly* sent artists to draw the battles. Engravers carved the drawings into blocks of wood for printing. Readers saw the pictures within about a week.

### Editors arrested and papers closed, 1861 to 1864

Union officers and members of Lincoln's cabinet shut down newspapers and arrested editors during the Civil War, most of the time without any court case. The First Amendment states that Congress shall make no law "abridging the freedom ... of the press." From April 1861, Lincoln's officials censored reporters' telegraph messages to and from Washington.

Soldiers arrested editors and closed their presses. Army officers sitting as military courts banished some editors to the Confederacy, forcing them to leave the North and not come back.

**Seward and Stanton.** William Seward, Lincoln's Secretary of State, the cabinet member in charge of dealings with other countries, ordered the arrest of an editor of the *Freeman's Journal*. Officials held the editor for 11 weeks and then let him go without a trial. Edwin Stanton, the Secretary of War, who ran the army for Lincoln, allowed a military governor, an army officer put in charge of a place, to destroy the office of the *Sunday Chronicle* in Washington.

**McGregor.** In Canton, Ohio, Archibald McGregor edited the *Stark County Democrat*. He printed words that his opponents called treason, and a mob then destroyed his paper's office. The record does not name the men in the mob. A year later soldiers arrested him without saying what the charge was.

General Ambrose Burnside closed the *Chicago Times*, a paper that backed the Democratic Party, in 1863. Lincoln canceled Burnside's order. He said he was "embarrassed" that his general had failed to weigh the needs of the Union against "the Liberty of the Press."

**A forged announcement.** Two New York reporters forged an announcement signed with Lincoln's name in May 1864, and the *New York World* printed it. It called for a day of fasting and a much larger draft, the government's order for men to join the army. The two men did it to change the price of gold. One of them, Joseph Howard Jr., had bought gold. A call for more soldiers meant a longer war, and he expected worried investors to buy gold and push its price up.

Lincoln ordered General John A. Dix to arrest the *World*'s editors and take over its offices. He canceled the order once it was clear the two reporters had faked the announcement.

### The first Black postal workers, 1863 to 1869

Federal law had barred anyone but "free white persons" from carrying the mail since 1802. The law named the post riders and the drivers of the carriages that carried the mail along the roads. In early 1863, during the Civil War, John Palfrey, the postmaster of Boston, hired William Cooper Nell as a clerk inside the Boston Post Office. Nell was the first Black American known to work for the federal government.

Members of Congress ended the rule on March 3, 1865. Their new law said that "no person, by reason of color, shall be disqualified from employment in carrying the mails." That meant no one could be kept from the job because of the color of his skin.

James Christian began delivering mail in Richmond, Virginia, in June 1869. He was the first Black letter carrier known in the United States. Richmond's postmaster, Elizabeth Van Lew, hired him along with other Black clerks and letter carriers.

### William Cooper Nell

> **Who:** A Black writer and printer from Boston who printed Frederick Douglass's first newspaper and became the first Black American known to work for the federal government.
>
> **When and where:** Boston, and Rochester, New York, 1840s to 1874.

**His night shifts at the post office ran from 11 to 5:30.**

William Cooper Nell was born in Boston. He went to Rochester, New York, in the 1840s and worked for nearly two years with Frederick Douglass, as the first printer and publisher of the *North Star*.

**The schools.** The members of the Boston School Committee, who ran the city's public schools, kept Black children apart from white children. Nell and other Black Bostonians sent the committee a petition in 1844, a written request signed by many people, asking it to open the schools to their children.

Eleven years later, in 1855, the governor of Massachusetts signed a law that made it illegal to turn a child away from a public school because of race. The same year, Nell published a 396-page book, *The Colored Patriots of the American Revolution*, about Black Americans who fought in the Revolution.

**The post office.** Nell wrote in a letter in 1873 that the post office was handling more and more letters, so he had been put on the night mail. His shifts began at 11 at night and usually ended at 5:30 in the morning.

He called himself "the first colored man employed about the United States Mail," using the word of his time for a Black man. He also wrote that he had "never lost a day from sickness or any cause." Nell worked at the post office until he died in 1874.

### One company owns the telegraph, 1866 to 1900

Western Union bought its last two big rivals in 1866 and ended up with more than 90 percent of the country's telegraph business. Tomas Nonnenmacher of Allegheny College calls it the country's first nationwide industrial monopoly, a company with no real competition that can set its own prices.

**Lobbyists.** In almost every session of Congress, members brought bills to control the company or to put the government into the telegraph business itself. Western Union's lobbyists, people paid to persuade lawmakers, blocked nearly all of them.

The number of telegrams the company carried rose from 5.8 million a year in 1867 to 63.2 million in 1900. The average price of a telegram fell from $1.09 to 30 cents. Of every dollar customers paid, about 30 to 40 cents was profit for the company.

The New York Associated Press, run by the owners of a few New York papers, held what the American Antiquarian Society calls a news monopoly by the late 1800s. Chicago newspaper owners formed a rival group, the Western Associated Press, and they broke the New York group's hold. A new, national Associated Press began in 1892.

### The telephone, 1876 to 1900

Alexander Graham Bell patented the telephone in 1876. He offered the patent to Western Union for $100,000, and the company's leaders turned it down. In 1900 the United States had about 1.36 million telephones, fewer than 2 for every 100 people. Of every 100 telephone calls, 97 were local calls within one town.

### Newspapers in Chinese, 1854 and 1855

Before the Civil War there were already American newspapers in German, French, Spanish, Polish, Swedish, Norwegian, Hawaiian and other languages. Chinese was harder to print because it uses thousands of characters instead of an alphabet. The first Chinese-language paper in the country, *Golden Hill's News*, came out in San Francisco in 1854 and lasted a few months.

The second, *The Oriental*, began there on January 4, 1855. Its editor was William Speer, a Presbyterian minister. Its printers drew the characters on stone with a grease pencil and printed from the stone. The paper closed in 1857. No one tried another Chinese paper until the 1870s.

### Nellie Bly

> **Who:** A newspaper reporter who pretended to be mentally ill so that she could report from inside New York City's asylum for women.
>
> **When and where:** Pittsburgh, 1885 to 1887, and New York City, 1887 to 1895.
>
> **Movie:** *Escaping the Madhouse: The Nellie Bly Story* (2019), a Lifetime television film that its makers call a fictionalized account.

**She pretended to be insane to get locked inside an asylum.**

Nellie Bly was the pen name of Elizabeth Cochran, from Cochran's Mills, Pennsylvania. The *Pittsburgh Dispatch* printed an article called "What Girls Are Good For" in 1885. Cochran wrote an angry letter to the paper answering it, and its editor hired her. At the *Dispatch* she wrote about working girls and poor neighborhoods in Pittsburgh.

**Ten days inside.** Bly went to work for Joseph Pulitzer's *New York World* in 1887. For her first big story she pretended to be insane until she was locked in the city's asylum for women on Blackwell's Island, a hospital where people with mental illness were kept. She stayed ten days.

When she arrived, a nurse, Miss Grupe, took her to a cold, wet bathroom. The nurses pulled off her clothes while a group of patients watched from the door. A patient scrubbed her with soft soap. Then three buckets of ice-cold water came down over her head, and Bly did not say who poured them.

Bly saw 52 women tied together by wide leather belts locked around their waists and fastened to one long rope.

A nurse, Miss Grady, told a patient named Urena Little-Page that "the doctors say that you are thirty-three instead of eighteen," and the other nurses laughed. Then Grady and the other nurses slapped Little-Page, knocked her head and choked her, and dragged her into a closet. The marks of their fingers stayed on her throat all day. A patient told Bly that "the nurse would beat them if they told."

Bly's reports ran in the *World* and then as a book, *Ten Days in a Mad-House*. A grand jury looked into the asylum. Bly wrote that New York City officials had set aside $1,000,000 a year more than ever before for the care of people with mental illness.

**Around the world.** Bly then asked her editor to let her travel around the world faster than Phileas Fogg, the hero of Jules Verne's novel *Around the World in Eighty Days*. She set out in November 1889. In France she met Verne himself, who asked about her route. The whole trip took 72 days, 6 hours, 11 minutes and 14 seconds. The *World*'s contest to guess her time drew nearly a million entries. She died in New York on January 27, 1922.

### Ida B. Wells

> **Who:** A Black newspaper editor in Memphis who counted lynchings, printed what she found and was driven from her city for it.
>
> **When and where:** Memphis, Tennessee, 1892, and New York City, 1892 to 1895.

**She counted 728 lynchings in eight years and printed the count.**

Ida B. Wells counted the lynchings in the South, killings by a crowd outside the law with no trial, and she printed what she found. White men in Memphis drove her out of the city for it. She was born into slavery in Holly Springs, Mississippi, on July 16, 1862. By 1892 she was an editor and part owner of the *Free Speech*, a Black newspaper in Memphis, Tennessee.

**The People's Grocery.** A white mob took three Black men out of their cells in the Memphis jail in the early morning of March 9, 1892, and shot them to death. They were Thomas Moss, Calvin McDowell, and a third man whom the records name as Will Stewart or Henry Steward. Moss was part owner of the People's Grocery, a store run by Black people that was taking business from a white-owned store nearby.

Wells wrote that the white store's owner, a man named Barrett, led twelve officers to the grocery at night. The grocery's defenders fired on them and wounded three. Officers then arrested 31 men, and the mob took the three from among them. Wells wrote that Black people in Memphis asked the authorities to bring the killers to justice, and "No attempt was made to do so."

Wells and the other editors of the *Free Speech* advised Black people to leave Memphis. Wells wrote that Black men "left the city by thousands." Those who stayed stopped riding the streetcars. The streetcar company lost so much money that its managers came to the *Free Speech* and asked the editors to tell people to ride again.

**The count.** Wells began to study lynchings, using the lists that the *Chicago Tribune* printed each year. She wrote in 1892 that mobs had killed 728 Black people in the past eight years, and that only one-third of the 728 had even been charged with rape. Rape means forcing someone into sex. Her list included "the boy Will Lewis," hanged in Tullahoma, Tennessee, "for being drunk and 'sassy' to white folks." It also included a fifteen-year-old girl hanged in Louisiana.

**The editorial.** Wells printed an editorial, an article that gives the paper's opinion, in the *Free Speech* on May 21, 1892. It listed eight Black men lynched since the last issue, and it called the claim that Black men raped white women "the old thread-bare lie." Wells was in New York at the time.

White men in Memphis held a meeting at the Cotton Exchange Building on May 24 and sent a group to find the paper's editors. Wells wrote that these men made "open threats of lynching" and did not carry them out only because they could not find the editors.

The business manager and half owner, J. L. Fleming, fled the city. Wells wrote that he was later "ordered not to return," and she did not say who gave the order. Letters and telegrams warned Wells that she would be hurt if she came home.

**The office.** Wells wrote in 1892 that people the paper owed money to took over the office and sold "the outfit," meaning the printing equipment. She described no fire. Later accounts by the National Park Service and the National Women's History Museum say a mob destroyed or burned the office.

**Exiled.** Wells did not go back. T. Thomas Fortune's *New York Age*, a Black weekly newspaper, printed most of her account on June 25, 1892, under the name "Exiled." It ran on the front page, and 10,000 copies went out across the country.

Black women in New York and Brooklyn held a meeting at Lyric Hall on October 5, 1892, and raised the money to print her account as a pamphlet. It was called *Southern Horrors: Lynch Law in All Its Phases*. In 1895 she published *A Red Record*, 100 pages of tables of lynchings.

### Rural Free Delivery, 1896

People in cities had had their mail brought to their homes for free since 1863, but farm families still had to travel to a post office to get their letters and newspapers. In 1890 about 41 million Americans, 65 of every 100, lived in the country. One farmer asked, "Why should the cities have fancy mail service and the old colonial system still prevail in the country districts?"

Postmaster General John Wanamaker argued that rural people, those who lived in the country, needed the information in newspapers. Congressman Tom Watson of Georgia won $10,000 in 1893 to test home delivery in the country. The next Postmaster General, Wilson S. Bissell, did not use it. Members of Congress added $20,000 in 1895 and $10,000 in 1896.

**The first routes.** Postal officials began Rural Free Delivery on October 1, 1896, at Charles Town, Halltown and Uvilla, in West Virginia. Within a year 44 routes ran in 29 states. Rural families sent more than 10,000 petitions asking for routes. Rural delivery became permanent on July 1, 1902, with about 8,500 rural carriers.

### Yellow journalism and the war with Spain, 1895 to 1898

Joseph Pulitzer owned the *World* in New York, and William Randolph Hearst owned the *Journal*. In 1896 Hearst hired away Pulitzer's cartoonist, Richard F. Outcault, whose comic strip had a character called the Yellow Kid. Pulitzer hired another cartoonist to keep drawing the Kid. People began to call the two men's kind of reporting "yellow journalism."

The State Department's historians define yellow journalism as reporting that put exciting stories ahead of facts. Pulitzer and Hearst printed stories about Cuba's fight for independence from Spain, and some of those stories turned out to be false.

**The Maine.** The US battleship *Maine* blew up and sank in the harbor of Havana, Cuba, on the night of February 15, 1898. Hearst and Pulitzer printed rumors that someone had planned to sink it, a plot that was never proved. Officials of Spain's government in Cuba wrote an early report that said the explosion started inside the ship.

A court of US Navy officers decided in March that a mine, a bomb placed in the water outside the ship, had set off the explosion. The court found no evidence of who was responsible, and no one has ever found out who placed a mine, or whether there was one. In 1976 a study led by Admiral Hyman Rickover found that a fire in a coal bin most likely set off the explosives stored next to it. People still argue over the cause.

By early May the war between the United States and Spain had begun. The State Department's historians say the two papers helped make Americans ready for a war, but that the papers alone did not cause it.

### A Black newspaper burned in Wilmington, 1898

A mob of white men in Wilmington, North Carolina, burned the city's Black newspaper in 1898, murdered Black men in the streets and forced the elected city government out.

Alex Manly edited the paper, the *Daily Record*. In August 1898 he printed an editorial answering a speech by Rebecca Felton, a white woman who had urged the lynching of Black men accused of raping white women. Manly wrote that white newspapers blamed all Black people for the crimes of the few who might be guilty. He also wrote that in many cases called rape, the white woman had chosen to meet the Black man in secret. When people found out, he wrote, a mob lynched the man for rape.

Democratic Party leaders, with Furnifold Simmons at the head of their campaign, used the editorial to stir up white voters before the November election. Democratic newspapers reprinted it under headings such as "An Insult to the White Women of North Carolina."

**The demands.** The day after the Democrats won, a meeting of white men in Wilmington passed a set of demands. They ordered Manly to close his paper and leave the city, and they demanded that the mayor and the chief of police resign. Alfred Moore Waddell, a former Confederate officer and congressman, led a crowd of white men to the *Daily Record* office on November 10, 1898. About 500 men gathered at the start, and the crowd grew to as many as 2,000. They broke in and burned the building.

**The killings.** Later that morning, members of the white mob shot and killed Black men in the streets of Wilmington. Every person reported killed was Black. The shooting started where groups of Black and white men were arguing, and each side there said the other fired first. A white militia company, the Wilmington Light Infantry, had a machine gun mounted on a wagon, which white businessmen had bought before the election.

**How many.** The coroner, the official who looks into deaths, counted 14 men dead. A state commission, a group of people chosen to study the killings, found in 2006 that at least 14 and perhaps as many as 60 men were murdered. North Carolina's state history office notes unconfirmed reports of many dozens or even hundreds of deaths. The records do not name the men who set the fire or the men who killed.

By late afternoon Waddell and his allies had forced the elected mayor and city council to resign, and the new board of aldermen, the city council, made Waddell mayor. They then banished people from the city. Manly came first, and he escaped. Black leaders, successful Black business owners and white Republicans came next. A federal investigation ended in 1900, and no one was charged.

**If you remember one thing:** By 1900 one company carried almost all the country's telegrams, and white mobs had driven Black editors out of Memphis and Wilmington.

**One number:** 728. That is how many Black people Ida B. Wells counted killed by mobs in the eight years before 1892, and only one-third of them had even been charged with rape.

**Next:** In the new century, magazine reporters dug into big companies and city governments, and radio brought the news into people's homes.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 16 minutes**

Radio carried the news into American homes as it happened, and in two world wars federal officials worked to control what Americans printed and heard. Magazine reporters investigated companies and city governments from 1902 on and printed long reports about what they found. During World War I, federal officials ran the government's first large propaganda office. They also barred dozens of newspapers from the mail and filed more than 2,000 criminal cases against people for what they said or printed.

The Westinghouse company owned one of the first radio stations, KDKA, from 1920, and then networks paid for by advertisers took over. In World War II, government officials asked newspapers and radio stations to keep military secrets. Japanese Americans forced into camps printed their own newspapers, and camp officials checked what they printed.

### The muckrakers, 1902 to 1912

Some reporters in the early 1900s dug into one subject and then wrote long reports about it, and editors at magazines such as *McClure's*, *Cosmopolitan* and *Collier's* printed them. The January 1903 issue of *McClure's* contained three such reports.

**Three reports in one issue.** One was part of Ida Tarbell's history of the Standard Oil Company. By 1880 that company controlled 90 to 95 percent of the oil refining in the United States, the work of turning crude oil from the ground into products people can use. Another was Lincoln Steffens's report on corruption, officials using their jobs to get money or favors illegally, in the city government of Minneapolis. The third was Ray Stannard Baker's report on coal miners.

**The Jungle.** Upton Sinclair spent about seven weeks undercover, hiding who he was, in the meatpacking plants of Chicago, the factories where animals were killed and the meat was cut up and packed. His novel *The Jungle* came out as a book in February 1906. He wanted readers to care about the workers, but readers were most upset about what went into their meat. "I aimed at the public's heart, and by accident I hit it in the stomach," Sinclair wrote.

**Patent medicines.** In a series that ran in *Collier's* in 1905 and 1906, Samuel Hopkins Adams reported on patent medicines, bottled cures sold with false claims. He wrote that Americans would "swallow huge quantities of alcohol, an appalling amount of opiates and narcotics" in them. By opiates he meant drugs made from the opium poppy.

President Theodore Roosevelt signed two new laws on June 30, 1906. Under the Meat Inspection Act, federal inspectors worked in the packing plants. The Pure Food and Drug Act banned food and medicine with false labels or harmful added ingredients from being sold across state lines.

**Muckrakers.** David Graham Phillips attacked members of the US Senate in a series called "The Treason of the Senate." Roosevelt answered with a speech on April 14, 1906. He compared these writers to the Man with the Muck Rake in John Bunyan's religious book *The Pilgrim's Progress*, a man raking up muck, mud and filth, "who could look no way but downward."

Roosevelt meant it as an insult. The writers took his word "muckraker" as a name to be proud of. By 1912 this kind of reporting had mostly disappeared from the magazines, in part because large companies stopped buying advertisements in them.

### Robert S. Abbott

> **Who:** The son of formerly enslaved parents who founded the *Chicago Defender* and sent it into the South, where it urged Black families to move north.
>
> **When and where:** Chicago, 1905 to 1940.

**He printed "(white)" after white people's names.**

Robert S. Abbott started the *Chicago Defender* with 300 copies in 1905, and by 1920 it outsold every other Black newspaper in the country. He was born on St. Simons Island, Georgia, in 1868. His parents, Thomas and Flora Abbott, had been enslaved.

**Shut out.** Abbott learned printing at Hampton Institute in Virginia. After he graduated in 1896 he moved to Chicago, where he was shut out of the printing business because he was Black. The record does not name the shops that turned him away. He earned a law degree in 1899, but because he was Black he could not get work as a lawyer in Indiana and Kansas.

Abbott printed the first issue of the *Chicago Defender* on May 5, 1905, and sold the 300 copies himself. In his paper's headlines and articles he attacked lynching and white supremacy, the belief that white people should rule over everyone else. One headline read, "When the Mob Comes and You Must Die Take at Least One with You."

White papers such as the *Chicago Tribune* printed "colored" after the names of Black people. Abbott printed "(white)" after the names of white people.

**North.** At that time 90 of every 100 Black Americans lived in the South, and Abbott sent the paper there. He urged readers to leave the South. In the *Defender* he printed job listings, train schedules, and photos of what he presented as the best schools, parks and housing in Chicago. For four years starting in 1916, more than 10,000 Black Southerners left the South each month. Between 1916 and 1919 about 500,000 left.

**Smuggled south.** Local police in Southern towns tried to stop the paper. They seized copies, and they arrested people who sold it under vagrancy laws, which made it a crime to have no job. Some police departments banned the sale of Black newspapers altogether. The accounts do not name the towns. Abbott arranged for Pullman porters, the Black workers who served passengers on railroad sleeping cars, to carry bundles of the paper south and sell them in secret.

The *Defender* sold more than 250,000 copies a week by 1929, and Abbott was one of the first Black millionaires. He died in Chicago on February 29, 1940.

### World War I: the government's propaganda office, 1917 to 1919

The United States entered World War I on April 6, 1917. That month President Woodrow Wilson set up the Committee on Public Information and put George Creel, a former newspaper reporter, in charge. It was the federal government's first large office for propaganda, information made and spread to push people toward one opinion.

Creel's staff sent articles to newspapers, and Creel later estimated that their material filled 20,000 newspaper columns a week. The committee's staff printed their own paper, the *Official Bulletin*, and about 115,000 copies went out. Its artists made posters, and one showed a German soldier as a gorilla carrying a club.

Staff in one division of the committee watched the hundreds of newspapers printed in other languages in the United States. After the war, many Americans concluded that Creel and his staff had pushed the war too hard, and that they had made it harder for people to speak against it.

### World War I: papers banned from the mail and people jailed for words, 1917 to 1921

Members of Congress passed the Espionage Act, named for espionage, or spying, on June 15, 1917. Under it, it was a crime to get in the way of the draft or to stir up disloyalty in the armed forces. Papers that urged treason could not go through the mail.

**Banned from the mail.** Postmaster General Albert S. Burleson told local postmasters to report anything suspicious. By 1918 his officials had barred 74 newspapers from the mail. The New York City postmaster, Thomas G. Patten, stopped *The Masses* magazine from going through the mail, and its November-December 1917 issue was its last.

Newspapers printed in German and other languages faced one more rule. Under the Trading with the Enemy Act of October 6, 1917, they had to file English translations of their war news with the local postmaster.

**The Sedition Act of 1918.** Members of Congress added the Sedition Act to the Espionage Act the next year, on May 16, 1918. Under it, it was a crime to speak or write anything "disloyal" about the government, the Constitution, the armed forces or the flag. The punishment was up to 20 years in prison and a $10,000 fine.

Federal prosecutors filed more than 2,000 cases under the two laws, and more than 1,000 ended in convictions. They used the Sedition Act mainly against pacifists, people who oppose all war. They also used it against anarchists, who want to do away with government, and socialists, who want the public rather than private owners to own big businesses.

The Socialist leader Eugene V. Debs gave a speech against the war to about 1,200 people in Canton, Ohio, on June 16, 1918. A judge sentenced him to 10 years in prison, and the justices of the Supreme Court upheld his conviction in 1919. President Warren G. Harding shortened his sentence, and Debs walked out of prison on Christmas Day 1921.

### Victor Berger

> **Who:** An immigrant newspaper owner in Milwaukee whose paper was barred from the mail for opposing World War I, and who was sentenced to 20 years in prison.
>
> **When and where:** Milwaukee, Wisconsin, 1892 to 1929.

**Voters kept electing him, and the House kept refusing to seat him.**

Victor Berger was born to a Jewish family in Austria-Hungary. He came to the United States in 1878 and taught German in Milwaukee's public schools. He bought a German-language newspaper in 1892, and in 1898 he and Eugene V. Debs founded the Social Democratic Party. Milwaukee voters made him the first Socialist elected to the US House of Representatives in 1910. A year later he started a daily paper in English, the *Milwaukee Leader*.

**The permit.** Berger opposed the war and said so in his paper. In 1917 an official in Postmaster General Albert S. Burleson's department, the third assistant postmaster general, took away the *Leader*'s "second-class mailing privilege," the permit that let it go by mail as a newspaper.

Federal prosecutors charged Berger under the Espionage Act in 1918. He and four other Socialist leaders were convicted in Chicago, and in early 1919 Judge Kenesaw Mountain Landis sentenced each of them to 20 years in prison.

**The empty seat.** Milwaukee voters elected Berger to Congress again in 1918, while his case went on. In November 1919 the other members of the House refused to let him take his seat. Voters elected him again in a special election, a vote held to fill the empty seat, with 55 percent of the vote, and the members of the House refused him again.

The justices of the Supreme Court overturned his conviction in 1921. Voters elected him to Congress three more times, in 1922, 1924 and 1926. He died in 1929 after a streetcar accident.

### Radio, and who owned it, 1920 to 1934

Radio station KDKA in Pittsburgh broadcast the results of the presidential election between Warren G. Harding and James M. Cox on the evening of November 2, 1920. KDKA belonged to the Westinghouse company. Its studio was a shed on the roof of a building at the Westinghouse works in East Pittsburgh.

Eight stations were on the air by the end of 1921, and by November 1, 1922, federal officials had licensed 564. At first, money for radio came from two places: selling radio sets and selling advertising. The Queensboro Corporation paid station WEAF in New York $50 on August 28, 1922, for about ten minutes of advertising for its apartments. Over the following years, advertising became the main way American radio was paid for.

**Networks.** The National Broadcasting Company, NBC, bought WEAF in 1926 and set up a permanent network, a group of stations in different cities that carry the same programs. Other networks followed, among them the Columbia Broadcasting System, CBS.

**Rules for the air.** By the middle of the 1920s, so many stations were on the air that their signals crossed and drowned each other out. Federal judges had ruled that the secretary of commerce, who gave out the licenses, could not stop giving them out even when the dial was full. The broadcasters themselves asked the federal government to restore order.

The biggest makers of radio equipment and the biggest broadcasters had also made business deals with each other. Those deals could have given a few companies a monopoly over radio, with no real competition from anyone else.

Members of Congress passed the Radio Act of 1927. Under it, the members of a federal commission decided which station could use which wavelength, the spot on the radio dial where a station is heard. They gave each of the 732 stations a set place on the dial, and they could turn down a new station when no room was left. In 1934 Congress's members passed the Communications Act and with it set up the Federal Communications Commission, the FCC, to oversee radio and messages sent by wire.

### The president on the radio, 1933 to 1944

President Franklin D. Roosevelt gave his first fireside chat, a talk to the country by radio, on Sunday night, March 12, 1933. He had closed every bank in the country on March 6, two days after he took office.

In the talk Roosevelt explained in simple terms how banks worked to some 60 million listeners. He told them it was safer to keep money in a reopened bank than under the mattress. When the banks opened again, people put in more money than they took out. Harry Butcher of CBS gave these talks the name "fireside chats." According to Encyclopaedia Britannica, scholars count between 27 and 31 of them, from 1933 to 1944.

### The War of the Worlds broadcast, 1938

The actor Orson Welles and his Mercury Theatre on the Air performed H. G. Wells's novel *The War of the Worlds* on CBS on the evening of October 30, 1938. Welles was 23. The writer Howard Koch, the producer John Houseman and Paul Stewart had rewritten the story as fake news bulletins about Martians landing in New Jersey. The program did not stop to say it was a play until almost 40 minutes in.

Some listeners believed it and called the police, newspapers and radio stations. The next morning, editors across the country printed stories about a nationwide panic.

**The count.** That night the C. E. Hooper company had asked 5,000 households what they were listening to, and 2 of every 100 named the Welles program. A. Brad Schwartz, who wrote a book about the broadcast, *Broadcast Hysteria*, found that only some listeners were fooled. Their worried phone calls convinced many journalists that the show had caused a panic across the country, and the journalists reported one.

### Pictures by wire, 1935

Newspapers mostly got photographs by mail, train or airplane until 1935, and a picture could take up to 85 hours to arrive. The AT&T telephone company had run a service that sent photographs by wire from 1926, but it closed in 1933. Associated Press staff sent their first photograph over wires on January 1, 1935. It was a picture taken from the air of a plane crash near Morehouseville, New York. Forty-seven newspapers in 25 states received it.

### Edward R. Murrow

> **Who:** A CBS radio reporter whose eyewitness reports from Europe before and during World War II made him famous across the United States.
>
> **When and where:** London, 1937 to 1945.
>
> **Movie:** *Good Night, and Good Luck* (2005), directed by George Clooney, about Murrow's television reports on Senator Joseph McCarthy in 1953 and 1954.

**From London he reported the war to Americans by radio.**

Edward R. Murrow's radio reports from Europe for CBS, from 1938 to 1940, made him famous across the United States. He also helped bring to the United States German scholars whom the Nazis, Adolf Hitler's party, which ruled Germany, had driven out.

Murrow joined CBS in 1935. CBS executives sent him to London in 1937 to run the network's European office. On the radio he described Germany's moves across Europe as an eyewitness. In 1938 he reported Germany's takeover of Austria and the Munich Conference, a meeting of European leaders. He reported the takeover of Czechoslovakia in 1939, and the Battle of Britain, when German planes attacked Britain, in 1940.

**McCarthy.** After the war Murrow ran the news department at CBS. In 1954 he made a television program about Senator Joseph McCarthy. McCarthy had charged that Communists, people who wanted one party to run the government and the government to own the farms and factories, were working in the government. Murrow died on April 27, 1965.

### World War II: secrets, propaganda and the Black press, 1941 to 1945

Japanese planes attacked the US Navy base at Pearl Harbor, Hawaii, on December 7, 1941. Twelve days later President Roosevelt set up the Office of Censorship. Its director, Byron Price, had been an editor at the Associated Press. The office had about 13,500 workers, and most of them read letters and cables, messages sent by wire under the ocean, going into and out of the country.

**The code.** Price and his staff gave newspapers and radio stations a code of rules, and editors agreed to follow it of their own free will. The code listed topics to keep out of the news: troop and ship movements, how war factories were doing, the president's travels, and even the weather. Price persuaded the reporters Drew Pearson and William L. Laurence not to write about the building of the atomic bomb.

Roosevelt set up the Office of War Information on June 13, 1942. Its staff ran programs, at home and in other countries, that told people how the government said the war was going and what its war plans were.

Federal prosecutors charged far fewer people for their words than in World War I. Philip A. Dynia, writing in the First Amendment Encyclopedia, counts dozens charged, against thousands in 1917 to 1919. Roosevelt kept pressing his attorney general, Francis Biddle, to "indict the seditionists," meaning to charge with crimes the people he saw as turning others against the government.

**Double V.** Writers for Black newspapers such as the *Chicago Defender* reported on the armed forces' separate units for Black troops, white officers placed over Black soldiers, blood supplies kept apart by race, and violence against Black servicemen. They ran a "Double V" campaign: victory over the enemy abroad and victory over prejudice at home.

Federal officials threatened to charge Black publishers with sedition. The *Defender*'s publisher, John H. Sengstacke, insisted on meeting Biddle. Biddle agreed to block the charges as long as Black editors did not make their criticism of the war any stronger.

### Newspapers behind barbed wire, 1942 to 1945

President Roosevelt signed Executive Order 9066, a written command from the president, on February 19, 1942. Under it, Lieutenant General John L. DeWitt ordered Japanese Americans on the West Coast out of their homes, some with only 48 hours' notice. Soldiers and federal officials forced them into camps because of their Japanese ancestry.

**How many.** The National Archives counts about 122,000 people, and nearly 70,000 of them were American citizens. Another count gives 110,000 to 120,000. The First Amendment Encyclopedia describes the camps as concentration camps, places where people are held by force without a trial.

Inside the camps, Japanese Americans wrote, printed and handed out their own newspapers. The papers in the first camps, run by the army, were copied on mimeograph machines, which print copies from a cut paper stencil. Army officials required those papers to be written in English only. All ten camps run by the War Relocation Authority had papers in both English and Japanese, among them the *Manzanar Free Press* in California and the *Heart Mountain Sentinel* in Wyoming.

Officials checked what the papers printed. Army officials censored the papers in the first camps. In the later camps, officials of the War Relocation Authority interfered with what the papers printed, and in some cases they censored the papers outright.

### Television begins, 1927 to 1941

Philo Farnsworth, who was 21, sent the first picture by all-electronic television, a straight line, in his laboratory in San Francisco on September 7, 1927. Station WNBT in New York showed the first television advertisement allowed by law on July 1, 1941, before a baseball game. It showed a Bulova watch face over a map of the United States. It lasted about ten seconds and cost $9.

**If you remember one thing:** Radio put the news in people's homes, and during World War I federal prosecutors won more than 1,000 convictions for what people said or printed.

**The question this era leaves open:** Television was only starting in 1950. Who would decide what its viewers were allowed to see? Era 9 answers it in Jackson, Mississippi.

**Next:** Television reached most American homes within ten years, and two newspapers printed what a president wanted kept secret.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 17 minutes**

Television became the way most Americans got the news. About 9 of every 100 American homes had a television set in 1950, and by 1960, 87 of every 100 did. After the DuMont network closed in 1955, three national television networks were left: NBC, CBS and ABC.

Managers of one Mississippi station, WLBT, cut civil rights news off the air. A church leader and two Mississippi leaders fought the station before the government and in court, and its owners lost their license.

Reporters printed a secret history of the Vietnam War in 1971 and tied a burglary to the White House in 1972, and officials in Washington tried to stop them. By 1996 cable channels such as CNN and Fox News showed news all day and night, and the World Wide Web had been open to the public since 1991.

### Television and the blacklist, 1950 to 1954

Senator Joseph McCarthy of Wisconsin gave a speech in Wheeling, West Virginia, in February 1950. He said that 205 communists, followers of a system in which one party runs the government and owns the farms and factories, worked in the State Department. When senators asked him, he could not name a single one.

**The book.** Three former FBI agents who ran a company called American Business Consultants published a book called *Red Channels* in June 1950. The book named 151 people who worked in radio and television and claimed they had ties to communism.

The company's owners then visited networks, advertisers and sponsors. For a fee, they offered to "clear" the people they had named. To be cleared, a person usually had to give the FBI or the House Un-American Activities Committee, a committee of Congress, the names of other people. Network executives and advertisers fired people on the list, which became a blacklist, a list of people whom employers refuse to hire or keep.

**On camera.** A Senate hearing on McCarthy's charges against Army officers and officials was shown on television across the country in 1954. It lasted 36 days. On camera, Joseph Welch, the Army's lawyer, asked McCarthy, "Have you no sense of decency, sir, at long last?"

Edward R. Murrow showed McCarthy's methods on his weekly CBS program *See It Now* that same year. Members of the Senate voted 67 to 22 on December 2, 1954, to condemn McCarthy.

### Radio and television in Spanish, 1946 to 1961

Raoul A. Cortez was born in Xalapa, Mexico, in 1905. He worked as a reporter for *La Prensa*, a Spanish-language newspaper in San Antonio, Texas. In 1946 he opened KCOR in San Antonio, the first all-Spanish radio station owned and run by a Hispanic American.

Federal officials had limited broadcasts in languages other than English during World War II. To get his license, Cortez told officials that part of the station's purpose was to rally Mexican Americans behind the war effort.

Cortez started KCOR-TV in 1955, the first television station aimed only at Hispanic viewers. It broadcast on a kind of channel called UHF, and few television sets could pick it up, so advertisers were hard to find. He sold the station in 1961, and the new owners renamed it KWEX.

### The station that cut the news: WLBT, 1955 to 1971

The managers of WLBT, a television station in Jackson, Mississippi, that carried NBC's programs, cut civil rights news off the air, and a group of citizens fought for years to take away the station's license. The Lamar Life Insurance Company started WLBT in 1953.

**"Cable Trouble."** The lawyer Thurgood Marshall appeared on an NBC program in the fall of 1955 to talk about the Supreme Court's decisions against segregation, keeping Black and white children in separate schools by law. WLBT staff cut him off and showed a sign that read "Sorry, Cable Trouble from New York." The general manager, Fred Beard, said he did it "because the TV networks were overloading the circuits with Negro propaganda," using a word of that time for Black people.

Station staff also cut away from NBC's evening news when it turned to civil rights. WLBT reporters used racial slurs on the air. The White Citizens' Council, a group that fought to keep segregation, ran a bookstore in the station's lobby. About half the people in WLBT's viewing area were Black, and the station's managers refused them time to answer.

**Medgar Evers.** Medgar Evers was the Mississippi organizer for the NAACP, the National Association for the Advancement of Colored People, a civil rights group. In May 1963 he spoke on WLBT to answer the mayor of Jackson, Allen Thompson. Three weeks later Byron De La Beckwith shot Evers in the back in the driveway of his home and killed him.

That year WLBT staff again ran the "Cable Trouble" sign, this time over NBC's report on white people attacking protesters at a lunch counter in Jackson. WLBT's own crew had filmed the attack.

**The complaint.** The Reverend Everett Parker of the United Church of Christ joined Aaron Henry, head of the Mississippi NAACP, and A. D. Beittel, the president of Tougaloo College, in 1963. They gathered complaints from viewers, knowing that they could be attacked for it. In 1964 they asked the Federal Communications Commission not to renew WLBT's license, the government permit a station needs to broadcast. The commissioners gave the station a one-year renewal without a hearing.

Judges on a federal appeals court ruled in 1966, in an opinion by Warren Burger, that viewers had the right to take part in these cases. In 1969 the judges ordered the commission to take away the owners' license. The owners appealed and lost in 1971. A board of Black and white citizens then ran the station, and the board hired some of the first Black television managers in the South.

### Civil rights news on the page and on the screen, 1955 to 1965

Roy Bryant, his half-brother J. W. Milam and at least one other person took 14-year-old Emmett Till by force from his relatives' home in Mississippi in August 1955. Bryant and Milam later described beating him and shooting him in the head.

Three days later Till's body was found in the Tallahatchie River, weighed down with a 75-pound metal fan from a cotton gin, a machine that cleans cotton. The men had fastened the fan to his neck with barbed wire. An all-white jury found Bryant and Milam not guilty of murder. Afterward, both men told the writer William Bradford Huie, for *Look* magazine, that they had kidnapped and murdered Till.

**The photographs.** *Jet*, a weekly news magazine for Black readers published in Chicago by John H. Johnson's company, printed photographs of Till's body on September 15, 1955. *Jet* sold about 425,000 copies a week at the time. The Till issue sold out, and its publishers printed more.

**The University of Mississippi.** A crowd of more than 2,000 white segregationists rioted at the University of Mississippi on the night of September 30, 1962, to stop James Meredith from enrolling as its first Black student. Of the 212 people that marshals and soldiers held afterward, only 24 were students at the university, Justice Department lawyers wrote.

People in the crowd threw a pipe, rocks, bricks and bottles at US marshals. Hundreds of people were hurt, and two men died. One of them was Paul Guihard, a 30-year-old reporter for the French news agency Agence France-Presse, who was covering the story.

Someone shot Guihard in the back at close range, and the bullet hit his heart. No one has ever been charged with killing him. Justice Department lawyers closed the case in 2011 without naming anyone.

**Selma.** Alabama state troopers and other officers led by Major John Cloud attacked civil rights marchers with clubs and tear gas on the Edmund Pettus Bridge in Selma on March 7, 1965. At least 50 marchers went to the hospital. Television cameras filmed the attack, and the film was flown to New York.

The ABC newscaster Frank Reynolds interrupted the network's showing of *Judgment at Nuremberg*, a film about Nazi war crimes, at about 9:30 that night to show the film of the attack. Nearly 50 million people had tuned in to the film.

### Walter Cronkite

> **Who:** The CBS anchor who read the evening news to much of the country for 19 years, and who told viewers in 1968 that the Vietnam War was stuck.
>
> **When and where:** New York, 1962 to 1981.
>
> **Movie:** *Walter Cronkite: Witness to History* (2006), a PBS *American Masters* documentary about him.

**"If I've lost Cronkite, I've lost Middle America."**

Walter Cronkite was the anchor of the *CBS Evening News*, the person who reads the news and introduces the reports. A poll in 1972 named him "the most trusted man in America." He grew up in Houston, Texas, where he wrote for his school newspapers.

**War reporter.** In World War II Cronkite reported for the United Press news service. He flew on bombing raids over Germany and covered the D-Day landings in 1944. Edward R. Murrow hired him for CBS in 1950.

**The anchor desk.** Cronkite became the anchor of the *CBS Evening News* in 1962. Soon after, the program grew from 15 minutes to 30 minutes, the first half-hour nightly news program on network television. In 1963 Cronkite told viewers that President John F. Kennedy had been killed. He covered the Moon landing in 1969 and nearly every American spaceflight with a crew from 1961 to 1981.

**Vietnam.** Cronkite went to Vietnam in 1968, after the Tet Offensive, a large attack by North Vietnamese and Viet Cong forces. On February 27, 1968, he told viewers that the war was "mired in stalemate," stuck in a fight that neither side could win. President Lyndon Johnson told his staff, "If I've lost Cronkite, I've lost Middle America," meaning ordinary American families. Encyclopaedia Britannica records that some people held this to be the reason Johnson decided not to run for president again that year.

Cronkite ended each program with "And that's the way it is." He left the anchor desk in 1981. He died in New York on July 17, 2009.

### Vietnam and the reporters, 1965 to 1971

As late as 1964 fewer than two dozen American reporters were in Indochina, the region that includes Vietnam, Laos and Cambodia. By 1968 about 600 journalists from many countries were in Vietnam. More than 60 journalists were killed during the war, and the record of their deaths does not say who killed them.

US military officers did not censor the reports from Vietnam. The military's daily news briefings in Saigon were nicknamed "the five o'clock follies," after follies, silly shows.

Some Americans later blamed the press for turning people against the war, and Encyclopaedia Britannica records that the argument goes on. Experts who studied the news coverage, Britannica states, found that most of the reporting supported the war until 1968. They found that support at home fell most as more American soldiers were killed.

**My Lai.** American soldiers of Charlie Company killed unarmed villagers at My Lai in South Vietnam on March 16, 1968. The counts run from at least 175, found by the Army's own inquiry, to 504, the number of names on a memorial in the village. The soldiers also raped women and girls. Rape means forcing someone into sex by violence or threat.

Seymour Hersh, a freelance reporter, one who worked for himself rather than for one newspaper, followed a tip in 1969 and found Lieutenant William Calley. Hersh wrote the first public account of the killings, and he won a Pulitzer Prize, a top award for reporting, in 1970. Calley was found guilty in March 1971 of murdering 22 civilians. He was the only soldier convicted, and no one was convicted of rape.

### The Pentagon Papers, 1971

Secretary of Defense Robert McNamara ordered a secret history in 1967 of what American leaders had done in Vietnam since World War II. It filled 47 volumes. Daniel Ellsberg, who had worked on it, gave copies to *The New York Times* without permission. The *Times* began printing stories about it on June 13, 1971.

The papers recorded that President Johnson had planned open war in 1964, a year before the public knew. They also recorded that he ordered the bombing of North Vietnam in 1965, even though intelligence officials had judged that it would not work.

**Prior restraint.** After three days, Justice Department lawyers got a prior restraint, a court order that stops something from being printed before it comes out, against the *Times*. *The Washington Post* also had the papers. The justices of the Supreme Court voted 6 to 3 on June 30, 1971, that the newspapers could keep printing.

Prosecutors charged Ellsberg under the Espionage Act, and he faced up to 115 years in prison. Men working for President Richard Nixon, led in this case by the former CIA officer E. Howard Hunt, broke into the office of Ellsberg's psychiatrist, a doctor who treats mental illness. They were looking for information to damage Ellsberg. In 1973 the judge dismissed all the charges because of this break-in and other wrongdoing by government officials.

The justices of the Supreme Court ruled in 1972, in a case called *Branzburg v. Hayes*, that the Constitution gives reporters no right to refuse to tell a grand jury who their sources are, the people who give them information. That same year two reporters at *The Washington Post* began getting information from a source whose name stayed hidden until 2005.

### Bob Woodward and Carl Bernstein

> **Who:** Two young *Washington Post* reporters who showed that a burglary in 1972 was tied to President Nixon's White House.
>
> **When and where:** Washington, D.C., 1972 to 1974.
>
> **Movie:** *All the President's Men* (1976), about their reporting, with Robert Redford as Woodward.

**Five men were caught inside the Democrats' office at Watergate.**

Bob Woodward and Carl Bernstein, two young reporters at *The Washington Post*, tied a 1972 burglary to President Richard Nixon's White House. Police arrested five men inside the office of the Democratic National Committee, the national leaders of the Democratic Party, in the Watergate building in Washington early on June 17, 1972. One of them, James W. McCord Jr., was the security chief of Nixon's re-election committee.

Woodward had covered minor crimes for the *Post* for nine months. Bernstein covered politics in Virginia. With a third reporter, Alfred E. Lewis, they wrote about the arrests for the next morning's paper.

**Deep Throat.** Nixon's press secretary, Ron Ziegler, called it a "third-rate burglary attempt." Most early news stories said the White House had nothing to do with it. Woodward and Bernstein kept reporting, and a secret source they called "Deep Throat" gave them information.

They reported on October 10, 1972, that the bugging of the Democrats' office, which means hiding microphones there to listen in, came from "a massive campaign of political spying and sabotage," or secret wrecking, run by White House officials for Nixon's re-election.

**CBS cut short.** CBS News aired the first part of a two-part report on the story on October 27, 1972. Nixon's aide Charles Colson then threatened William Paley, the head of CBS, and the second part was cut short. The records do not say who at CBS made the cut. That November Nixon won re-election, carrying every state except Massachusetts. In 1973 the *Post* won the Pulitzer Prize for public service for Woodward and Bernstein's reporting.

**Hearings on television.** The reporting was one step among several that led to Nixon's resignation. Television stations showed a Senate committee's Watergate hearings live for two weeks in May 1973, and more than 150 public television stations showed them again in the evening. A month after the hearings began, 97 of every 100 Americans had heard of Watergate. A White House aide, Alexander Butterfield, told the committee that Nixon kept a voice-activated tape recorder in rooms of the White House.

**The tapes.** The justices of the Supreme Court ordered Nixon to hand over the tapes on July 24, 1974. One tape showed that on June 23, 1972, he had ordered the FBI to hold back its investigation. Members of the House Judiciary Committee approved three articles of impeachment, formal charges that could lead to his removal from office. Nixon resigned on August 9, 1974.

W. Mark Felt, who had been an associate director of the FBI, one of its top officials, said in 2005 that he was Deep Throat.

### Reporters killed in the United States, 1976 to 1990

**A car bomb in Phoenix.** Don Bolles, a 47-year-old reporter for the *Arizona Republic*, went to a Phoenix hotel on June 2, 1976, to meet a man who had promised him information. It was to be about land fraud, cheating people in land deals, and organized crime, crime run by gangs. The man never came. When Bolles started his car, a bomb under it exploded.

Doctors had to cut off both his legs and one arm, and he died on June 13. In 1977 John Harvey Adamson pleaded guilty to building and planting the bomb. A jury later convicted Max Dunlap of murder and of conspiracy to murder, which means planning a murder with others. Dunlap died in prison in 2009.

Reporters from many other papers came to Arizona and spent five months finishing Bolles's reporting.

**Five journalists for refugee papers.** Killers murdered five Vietnamese American journalists between 1981 and 1990. They worked at small papers for refugees from the Vietnam War. Reporters at ProPublica who looked into the killings in 2015 tied them to what the papers printed about Vietnam and its government.

Duong Trong Lam, 27, was shot outside his home in San Francisco in 1981. A gunman chased Nguyen Dam Phong from his house in Houston in 1982 and shot him seven times.

Pham Van Tap was killed by the smoke from a fire that someone set in his office in Garden Grove, California, while he slept. A message sent to the Vietnamese press after his death said he was killed for printing advertisements for companies that did business with Vietnam.

The last two worked for the same magazine in Virginia, *Van Nghe Tien Phong*. A gunman shot and killed Do Trong Nhan, 56, who laid out the magazine's pages, in his car as he got ready to drive to work. Ten months later, on September 22, 1990, killers shot and killed the writer Le Triet and his wife, Dang-Tran Thi Tuyet, in their car in the driveway of their home.

FBI agents suspected a group led by former South Vietnamese military officers, but they never found enough evidence to charge anyone. No one was ever arrested or charged.

### The fairness rule and talk radio, 1949 to 1988

The members of the Federal Communications Commission required stations from 1949 on to follow a rule called the fairness doctrine. Station owners had to cover important public questions fairly and air more than one side, and people attacked on the air had to get a chance to answer. The justices of the Supreme Court upheld the rule in 1969.

Members of Congress passed a bill in June 1987 to make the rule a law. President Ronald Reagan vetoed the bill, refusing to sign it. He wrote that the rule "requires Federal officials to supervise the editorial practices of broadcasters." That year the commissioners, led by their chairman, Dennis Patrick, voted 4 to 0 to end the rule.

**Talk radio.** Rush Limbaugh began a national radio talk show in 1988 on which he gave his conservative political opinions, views that favor keeping old ways and limiting government. Within five years an estimated 20 million people listened each week. His show began the year after the fairness doctrine ended. Whether the end of the rule helped talk shows like his grow is argued and not settled.

### Public broadcasting and cable news, 1967 to 1996

Members of Congress set up the Corporation for Public Broadcasting in the Public Broadcasting Act of 1967, to hand out federal money to public television and radio stations. People at the corporation started PBS in 1969 and NPR, National Public Radio, in 1970.

Ted Turner's company started CNN, the first television channel to show news 24 hours a day, on June 1, 1980. It reached viewers through cable, wires that carried many channels into homes. Rupert Murdoch's company started the Fox News Channel on October 7, 1996. Roger Ailes, a television producer and former Republican political adviser, ran it.

### The internet, 1969 to 1996

Researchers at the University of California, Los Angeles, sent the first message over ARPANET, a computer network paid for by the Defense Department, to the Stanford Research Institute in late 1969.

Tim Berners-Lee, a British scientist working in Switzerland, opened the World Wide Web, the system of linked pages that people open over the internet, to the public in 1991. A team at the University of Illinois released Mosaic in 1993, the first widely used program for viewing web pages with pictures.

President Bill Clinton signed the Telecommunications Act in February 1996. Under it, one company could own more television stations, and many media companies merged after it passed. Under one part of it, sending "indecent" material to children online was a crime. The justices of the Supreme Court struck down that part in 1997. They ruled that the internet has the same protection for free speech as printed words.

**If you remember one thing:** As television brought the news into nearly every home, judges settled fights over keeping news from the public.

- 1969: Federal judges order the FCC to take WLBT's license from the owners who cut civil rights news off the air.
- June 30, 1971: The justices of the Supreme Court vote 6 to 3 that newspapers may keep printing the Pentagon Papers.
- July 24, 1974: The justices order President Nixon to hand over his tapes.

**Next:** After 2000 the news moved to phones and feeds, and thousands of newspapers closed.

## 2000 to Today

**Era 10 of 10 · 2000 to today · about 13 minutes**

Since 2000 the news has moved from paper to phones and feeds, and the men who own the biggest sites have changed what those feeds show. In a 2025 survey by the Pew Research Center, 86 of every 100 American adults said they got news at least sometimes from a phone, computer or tablet, and 64 of every 100 from television. Newspapers lost most of their advertising money. Researchers at Northwestern University counted close to 3,500 newspapers that closed between 2005 and 2025.

People angry at what reporters wrote killed journalists in their newsrooms and outside their homes. Police and federal agents arrested and held reporters at protests. In 2025 members of Congress took back the federal money for public radio and television.

### The news on phones and feeds, 2004 to 2025

Mark Zuckerberg and three other Harvard students started Facebook in February 2004. Three former workers at the PayPal company started YouTube in 2005, and Google bought it in November 2006 for $1.65 billion. Twitter began in 2006.

**The feed.** Zuckerberg announced changes to Facebook's feed, the list of posts the site shows each user, in January 2018. Users would see fewer posts from news outlets and businesses and more posts from their friends and family.

**Section 230.** Under a law of 1996, known as Section 230, a website cannot be treated as the publisher of what its users post. That means the company that runs the site is not legally responsible, as a newspaper publisher would be, for what users write there.

Smartphones spread quickly. In 2011, according to the Pew Research Center, 35 of every 100 American adults owned one, and by 2025, 91 of every 100 did.

In a Pew survey in August 2025, about half of American adults said they got news at least sometimes from social media, most often on Facebook and YouTube. Only 7 of every 100 said they often read news in a printed newspaper or magazine.

### False news, measured, 2018

Three researchers at the Massachusetts Institute of Technology, Soroush Vosoughi, Deb Roy and Sinan Aral, published a study of news on Twitter in 2018. They followed about 126,000 chains of retweets, posts shared again on Twitter, from 2006 to 2017. Each chain began with one news story that people passed along. About 3 million people shared the stories more than 4.5 million times.

**What they found.** Six fact-checking groups had judged which stories were true and which were false. The researchers found that false stories were 70 percent more likely to be shared again than true ones. A true story took about six times as long as a false one to reach 1,500 people. False stories about politics spread fastest.

Some accounts on Twitter were run by computer programs, called bots. When the researchers left out the bots, the result stayed the same. So people, the researchers concluded, spread the false stories.

### Who owns the feed, 2022 to 2026

Elon Musk bought Twitter for $44 billion in October 2022. He laid off about half its workers and cut back content moderation, the work of checking posts and removing those that break a site's rules. He began selling blue check marks for $8 a month.

Musk renamed the site X in 2023. In March 2025 he sold X to his artificial intelligence company, xAI, in a deal that valued X at $33 billion. In 2026 his rocket company, SpaceX, bought xAI.

On Facebook, Mark Zuckerberg made his own change. He announced in January 2025 that the company would end the fact-checking programs it had used for about ten years.

**TikTok.** TikTok belonged to ByteDance, a company in China. President Joe Biden signed a law in April 2024 that required ByteDance to sell TikTok within a year or see the app banned. The justices of the Supreme Court upheld the law in January 2025, and President Donald Trump then delayed the ban several times.

A new company took over TikTok in the United States in January 2026. The software company Oracle, the investment firm Silver Lake and a fund owned by the government of the United Arab Emirates each own 15 percent of it, and ByteDance kept 19.9 percent.

**CBS and CNN.** David Ellison bought Paramount, the company that owns CBS, in 2025, and he hired Bari Weiss to run CBS News. A *60 Minutes* report about a prison in El Salvador was pulled from the air in December 2025, three hours before it was to run. The correspondent, Sharyn Alfonsi, wrote that Weiss "spiked our story," which means stopped it, after CBS lawyers had cleared it.

Ellison's company also agreed to buy Warner Bros. Discovery, which owns CNN, for $111 billion. According to NPR, both deals depend on money from his father, Larry Ellison, a founder of Oracle. The top lawyers of 12 states, all of them Democrats, sued over the deal.

Paramount's owners settled the lawsuit in September 2026 by agreeing to set up a board meant to keep the owners out of news decisions at CBS and CNN. The purchase was not yet complete at the end of September 2026.

### Newspapers close: the news deserts, 2005 to 2025

American newspapers took in less than a fifth as much money from advertising in 2022 as in 2005. Researchers at the Pew Research Center put the figures at about $49.4 billion in 2005 and an estimated $9.8 billion in 2022.

**Where the money went.** Advertisers spent more and more online, and most of that money went to big technology companies that do not report the news, such as Google and Facebook. Pew researchers wrote in 2014 that these companies could reach far more people than any news outlet, and aim their ads better than any one newspaper's website could. In 2014 five companies, including Google and Facebook, took in 61 of every 100 dollars spent on online ads in the United States.

Researchers at the Medill school of journalism at Northwestern University count newspapers every year. In their 2025 report they found that almost 2 of every 5 local newspapers in the country had closed since 2005, close to 3,500 papers in all. Papers were still closing in 2025, at more than two a week. Since 2005 the newspaper business had lost more than three of every four of its jobs.

**News deserts.** The Medill researchers call a county with no local newspaper, news website or station a news desert. The number of news deserts grew from just over 150 counties in 2005 to 212 in 2025, and most of them were in the countryside. Another 1,525 counties had only one local source left. In all, about 50 million people lived in a county with one local source or none.

**Fewer owners.** The number of companies and people who owned American newspapers fell by more than half, from 3,995 in 2005 to just under 1,900 in 2025.

The *Chicago Defender*, the paper that urged Black Southerners to move north in the 1910s, ended its print edition in 2019. Its owners now publish it only online.

### Jeff German

> **Who:** A Las Vegas newspaper reporter who was stabbed to death by an elected official he had written about.
>
> **When and where:** Las Vegas, Nevada, 1980s to 2022.

**The official he wrote about stabbed him outside his home.**

Robert Telles, an elected official in Las Vegas, stabbed the reporter Jeff German to death in 2022 after German reported on Telles's office. German had reported in Las Vegas for four decades, and at the time of his death he worked for the *Las Vegas Review-Journal*. He wrote about organized crime and dishonest officials, and he hosted a *Review-Journal* podcast about the mob called *Mobbed Up*.

**The stories.** That year German wrote about the office of Robert Telles, who had been elected Clark County Public Administrator. When a person in Clark County dies and no family member can step in at once, workers in that office guard the dead person's property and money until they can hand it to the people who should get it.

German's stories described bullying in the office and the punishing of workers who complained. They also described an "inappropriate relationship" between Telles and a staff member. Telles denied it. In June 2022 he lost his election.

**The evidence.** Telles stabbed German to death outside German's home on September 2, 2022. Police found Telles's DNA, the chemical code inside every person's cells that can show who was at a place, on German's hands and fingernails. In Telles's home, police found a straw hat and sneakers, cut into pieces, like the ones the killer wore on a security camera video.

A jury found Telles guilty of murder on August 28, 2024. In October 2024 Judge Michelle Leavitt added more time because German was over 60 and Telles had used a deadly weapon. Telles was sentenced to 28 years to life in prison.

### A newsroom attacked: Annapolis, 2018

Jarrod Ramos walked into the newsroom of the *Capital Gazette* in Annapolis, Maryland, on June 28, 2018, with a shotgun, smoke grenades and extra ammunition. He killed five people who worked there: Gerald Fischman, Rob Hiaasen, John McNamara, Rebecca Smith and Wendi Winters.

Ramos held a grudge because in 2011 the paper's reporters had written that he was convicted of harassing a woman he had gone to high school with. In 2021 a jury found that he was responsible for his crimes, and a judge sentenced him to five life terms in prison with no chance of release.

### Darnella Frazier

> **Who:** A 17-year-old who recorded a Minneapolis police officer killing George Floyd, and whose video became evidence at his trial.
>
> **When and where:** Minneapolis, Minnesota, 2020 to 2021.

**She was 17 and out walking with her nine-year-old cousin.**

Darnella Frazier's phone video of a police officer killing George Floyd reached people around the world. She was walking with her cousin in Minneapolis on May 25, 2020, when she saw the police officer Derek Chauvin kneeling on the neck of George Floyd, a Black man, and she recorded it. Her video showed Chauvin kneeling on Floyd's neck for nine minutes and 29 seconds, and it recorded Floyd's murder.

**The trial.** According to NPR, the video played a major part in starting protests against police violence around the world. At Chauvin's trial in 2021, prosecutors played it again and again, and Frazier testified.

The jury found Chauvin guilty of three different legal grades of killing a person: second-degree murder, third-degree murder and second-degree manslaughter, which means killing a person without meaning to kill. The journalist Ann Marie Lipinski said, "There is no case without her."

The members of the Pulitzer Prize Board gave Frazier a special citation, an honor outside their usual prizes, on June 11, 2021. The citation identifies "the crucial role of citizens in journalists' quests for truth and justice." Frazier called recording the video a "traumatic life-changing experience."

### A small-town paper raided: Marion, Kansas, 2023

Police Chief Gideon Cody of Marion, Kansas, led officers in a raid on the weekly *Marion County Record* and on the home of its publisher, Eric Meyer, on August 11, 2023. The officers took computers and reporters' phones. Cody claimed that Meyer and the reporter Phyllis Zorn had committed identity theft, pretending to be someone else by using that person's private information, or computer crimes. He said they had done it by checking a local business owner's driving record.

**Joan Meyer.** Meyer's mother, Joan Meyer, was 98 and owned part of the paper. A police camera recorded her telling officers, "Get out of my house!" She died of a heart attack the next afternoon.

Special prosecutors, lawyers brought in from outside to handle the case, later found that no one at the paper had committed a crime. They said Cody had reached a wrong conclusion through "a poor investigation." They said they could not charge anyone over Joan Meyer's death. Cody was charged in August 2024 with felony obstruction of justice, a serious crime of getting in the way of an investigation, for asking the business owner to delete text messages.

### Reporters arrested, hit and deported, 2017 to 2026

Staff of the US Press Freedom Tracker, a project of the Freedom of the Press Foundation, have counted attacks on journalists in the United States since 2017. More than half of all the assaults they counted came in two years, 2020 and 2021: nearly 800 of the 1,487 they had counted by September 2026. They also counted 445 arrests or criminal charges.

**Protests against deportation.** The tracker counted at least 32 journalists arrested or held in 2025 and at least 170 assaulted. Most were covering protests against deportation, the sending of immigrants out of the country. Police in Los Angeles surrounded and held at least 10 journalists at one protest on June 9, 2025.

**Minneapolis.** In January 2026 the tracker counted at least nine assaults on journalists in the Minneapolis area. Most of those journalists were hit by pepper balls, small balls fired from a gun that burst into a stinging powder, or by pieces of stun grenades, both of them crowd-control weapons. The tracker's January report does not say who fired each one. Federal agents held the photographer John Abernathy on the ground on January 15, 2026.

**Mario Guevara.** Mario Guevara, a Spanish-language reporter who covered immigration near Atlanta, was arrested on June 14, 2025, while he livestreamed a protest, showing it live on the internet. The Committee to Protect Journalists' account of the case does not name the police who arrested him.

Federal officials held Guevara and argued that his filming of police was a danger to public safety. They deported him on October 3, 2025, sending him out of the country to El Salvador. The Committee to Protect Journalists said it was the first time it had recorded this kind of punishment for reporting.

**WikiLeaks.** Julian Assange published secret documents about the US wars in Afghanistan and Iraq on his WikiLeaks website starting in 2010. Federal prosecutors charged him in 2019 under the Espionage Act of 1917, the law once used against the editor Victor Berger and against Daniel Ellsberg. In June 2024 Assange pleaded guilty under that law.

**The press pool.** White House press secretary Karoline Leavitt told the Associated Press, the AP, on February 11, 2025, that its reporters could no longer come into the Oval Office with the press pool, the small group of reporters that covers the president up close. The ban was to last until the AP agreed to call the Gulf of Mexico the Gulf of America.

A federal judge, Trevor McFadden, ordered the AP's access restored in April. In October 2025 officials at the Pentagon made reporters agree to have their material checked in order to keep their passes.

### Public broadcasting loses its federal money, 2025 to 2026

Republican majorities in both houses of Congress passed the Rescissions Act in July 2025, and President Trump signed it. With the act, members of Congress took back about $1.07 billion already promised to the Corporation for Public Broadcasting for 2026 and 2027, according to the research group USAFacts. That money had gone to NPR, PBS and local public radio and television stations.

Trump had signed an order in May 2025 calling for an end to government money for news outlets that did not meet standards of "fairness, accuracy, and nonpartisanship," which means not taking the side of any political party.

The members of the corporation's board voted in January 2026 to close it after 58 years. Public radio and television stations cut about 550 jobs between July 2025 and May 2026, according to a count reported by Nieman Lab.

Rural stations and stations run by Native nations had gotten a large share of their money from the federal government, and they were hit hardest. By mid-2026 at least one public television station had shut down, and more had announced plans to close. No full count had been published. Stations of every kind saw the number of people giving them money rise between 2024 and 2025.

**Pressure on commercial stations.** Officials also pressed commercial broadcasters, the stations paid for by advertising. The members of the Federal Communications Commission give out the licenses that those stations need to broadcast.

The talk-show host Jimmy Kimmel spoke on his show in 2025 about which political side the man accused of killing the activist Charlie Kirk was on. Brendan Carr, the chair of the FCC, then pressed ABC to take *Jimmy Kimmel Live!* off the air. In 2026 Carr opened an investigation of the talk show *The View* under the rule that stations must give political candidates equal time.

**The three questions, answered**

- Did the First Amendment stop the government from punishing people for what they printed? No. Seven years after it took effect, federal judges jailed editors under the Sedition Act, and during World War I prosecutors won more than 1,000 convictions for words.
- Who was shut out of carrying and printing the news? From 1802 to 1865 federal law let only free white persons carry the mail, and white mobs drove Black editors out of Memphis and Wilmington. Black and Cherokee Americans started papers of their own.
- Why have so many local newspapers closed since 2005? Advertisers moved their money online, where most of it went to technology companies such as Google and Facebook, so newspapers' advertising money fell by more than four-fifths between 2005 and 2022. Readers moved to phones and feeds too, and by 2025, 212 counties had no local news source.

**What changed:** In 1673 a post rider took about two weeks to carry the mail from New York to Boston. By 1920 radio listeners heard election results on election night, and by 2025 most American adults got at least some news on a phone, computer or tablet.

**Five dates to keep**

- September 25, 1690: *Publick Occurrences* appears in Boston and is stopped four days later.
- December 15, 1791: The First Amendment takes effect.
- March 3, 1865: Congress ends the whites-only rule for mail carriers.
- November 2, 1920: KDKA broadcasts the election results.
- June 30, 1971: The Supreme Court lets the Pentagon Papers be printed.

**Not known:** No record survives of what news Native traders passed along with the copper and shells they carried before 1500.

**Where to go:** Part of the Boston Post Road, the first post rider's trail in 1673, is now US Route 1, and you can drive it.

**Next:** Chapter 32, Art. It asks who decided what counted as art, and who got to see it.
