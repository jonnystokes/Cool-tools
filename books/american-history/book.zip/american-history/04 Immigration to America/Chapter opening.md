**Part 2: Coming, Moving, Settling**

# Chapter 4: Immigration to America

**Chapter 4 of 37 · Immigration to America · 10 eras · about 100 minutes**

**People came here to stay from almost every country on earth, and from the 1600s on, the people who had come earlier kept deciding who could join them, by law and sometimes by mob violence.**

The poet Emma Lazarus wrote a poem in 1883 to help raise money for the stone base of the Statue of Liberty. It includes the lines "Give me your tired, your poor, / Your huddled masses yearning to breathe free." Nobody read it aloud when the statue opened in 1886. In 1903 her friend Georgina Schuyler had the poem mounted on a bronze plaque inside the base. One year before Lazarus wrote those lines, President Chester A. Arthur had signed a law that shut Chinese workers out of the country.

This chapter follows the people who came to stay, from a Spanish fort in Florida in 1565 to the record number of people held in immigration detention in 2026. Watch why they came: for land and work, to worship in their own way, and to escape famine, riots against Jews, revolution and war. Watch, too, who decided whether they could stay. Lawmakers wrote the rules, from citizenship for white people only in 1790 to the Chinese Exclusion Act of 1882 and the quotas of 1924. Mobs in Philadelphia, Louisville and Rock Springs used fire and guns. The forced arrival of Africans appears here only where it meets those laws. Chapter 24, Slavery and Freedom, tells it in full.

**Three questions this chapter answers**

- Why did people leave home to come here?
- Who did Americans try to keep out, and how?
- Who could become a citizen, and how did that change?

**Five minutes?** Read "Angel Island" in 1900 to 1950, the Lee Puey You story after it, and the next section, "How the quota laws of 1921 and 1924 worked."

**Can skip:** "The Dutch and the Swedes" in the 1600s, "Jewish communities" in 1700 to 1750, "The Revolution and the Loyalists" in 1750 to 1800. The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 1 minute**

No one from across the ocean came to settle here for good before 1500. Hundreds of Native nations lived in the land that is now the United States, and their people spoke hundreds of different languages. Every group of newcomers who came later arrived on land where people were already living.

Nobody knows how many people lived north of Mexico in 1492. Estimates run from about 1 million to as many as 18 to 20 million. Chapter 2, Native Nations, tells who they were.

### The land bridge and the Norse

The first people to reach this land came on foot from Asia, long ago. They walked across the ice-age land bridge, a stretch of dry ground that joined Asia to North America.

Chapter 1 tells the Norse voyages in full. What matters here is that the Norse did not stay. Around the year 1000, Norse sailors from Greenland, the people often called Vikings, built a camp at L'Anse aux Meadows, in Newfoundland, in what is now Canada. Wood they cut there with metal blades dates to 1021. Before Columbus, it is the only camp that anyone from across the ocean is known to have built in North America.

Native people had lived at that spot long before the Norse came. Five Native groups had lived there, the oldest about 6,000 years earlier. The Norse stayed only a short time, from a few years to about twenty by different estimates, and built no settlement that lasted.

## The 1500s

**Era 2 of 10 · The 1500s · about 3 minutes**

Europeans came to these coasts in the 1500s to conquer and explore, and almost none of them stayed. Most were soldiers, explorers, sailors and Christian missionaries, people sent to bring others into their religion. Native nations held almost all of the land for the whole century. Of three European attempts to settle, only the Spanish town of St. Augustine lasted.

### Which settlement lasted?

St. Augustine, Florida, lasted. It is the oldest town that Europeans founded on the US mainland, and people have lived in it without a break since it began. The Spanish navy commander Pedro Menéndez de Avilés founded it on September 8, 1565. He named it for Saint Augustine because he had first sighted land on that saint's feast day, a day the church sets aside to honor a saint. St. Augustine is 42 years older than Jamestown and 55 years older than Plymouth.

**Seloy.** Menéndez landed at Seloy, a town of the Timucua people. Counts of the people who came with him differ. The National Park Service gives about 600 soldiers and settlers. The Florida Museum of Natural History gives about 800, including 26 women and an unknown number of enslaved Africans.

The newcomers used the council house of the Timucua chief, also named Seloy, as their first fort. It was the building where the town's leaders met. Timucua fighters attacked again and again to drive the Spanish away. In May 1566 Menéndez moved the settlement across the bay to Anastasia Island, and by about 1572 the Spanish had moved back to the place where the town stands today.

**Fort Caroline.** Two other attempts to stay failed. René de Laudonnière founded Fort Caroline, a French settlement near where Jacksonville, Florida, stands today, in 1564. The French there met Timucua people, and one of their leaders was Athore. The French settlers were Huguenots, French Protestants, members of the Christian churches that split away from the Catholic Church led by the pope in Rome. In 1565 Menéndez destroyed Fort Caroline and killed most of the French defenders. The Spanish were Catholics, and the fight was partly over religion.

**Roanoke.** Nobody knows what happened to the 117 English settlers who landed on Roanoke Island in 1587. The island lies off the coast of what is now North Carolina, and it was the land of the Roanoke, Secotan and Croatoan peoples. Sir Walter Raleigh organized the colony, a settlement ruled from a faraway country, and John White led it. On August 18, 1587, a settler named Eleanor Dare gave birth there to a daughter, Virginia Dare, the first English child recorded as born in the Americas.

The settlers sent White back to England for supplies. Before he left, they agreed on a signal. If they moved, they would carve the name of their new place on a tree or a post. If they were in trouble, they would carve a cross above the name. White could not get back for three years. In 1588 Queen Elizabeth I took every English ship for her navy, to fight the Spanish Armada, a fleet of Spanish warships.

**What White found.** White went ashore on August 18, 1590, Virginia Dare's third birthday. He found a wall of upright logs, the houses gone, and no people. Someone had carved CRO on a tree and CROATOAN on a post, with no cross. Croatoan was a nearby island, where a man named Manteo was born, and White wrote that its people were friends of the English. A storm blew his ship out to sea before he could search there. No one found the settlers.

## The 1600s

**Era 3 of 10 · The 1600s · about 9 minutes**

Most English people who went to Virginia and Maryland in the 1600s paid for the voyage with years of their own work. People from Europe began coming to stay in these years. Some came so that they could worship in their own way. Others came to make money by farming, trading or growing tobacco.

The colonists settled along the Atlantic coast, on land where Native nations already lived. English colonists built Jamestown on Powhatan land and Plymouth on the site of a Wampanoag town. Dutch colonists built New Amsterdam on Lenape land, and Quakers under William Penn settled Pennsylvania on Lenape land too.

### Jamestown and indentured servitude

**Jamestown.** English colonists founded Jamestown, Virginia, in 1607, and it was the first English settlement that lasted. The Virginia Company of London paid for it. Many people owned shares in the company, hoping to split a profit. The colonists built their fort inside Tsenacomoco, the land of the Powhatan, a union of Native towns and peoples under one head chief. Jamestown Island was a hunting ground of the Paspahegh, one of those peoples, and Paspahegh fighters attacked the new settlement on May 26, 1607.

Many colonists died of disease and hunger in the first years. In the fall of 1609 the Powhatan leader, also called Powhatan, cut off the food trade with the colonists and surrounded their fort. About 500 colonists were alive at the start of that winter. About 61 were alive by spring.

**Tobacco.** John Rolfe began growing tobacco for sale overseas in the 1610s. Once tobacco sold well, more settlers came to Virginia to grow it, and they took more Powhatan land without paying for it. On March 22, 1622, fighters from an alliance of Virginia Indian nations, led by Opechancanough, attacked the English settlements and killed as many as 347 colonists.

Most early English arrivals in the Chesapeake, the country around the Chesapeake Bay in Virginia and Maryland, came as indentured servants. An indentured servant signed a contract, called an indenture, and gave up four to seven years of work in exchange for the trip across the ocean. The contract often promised food, a place to live, and a payment at the end called freedom dues.

Servants made up about 80 to 90 percent of the European immigrants to the Chesapeake in the 1600s, eight or nine of every ten. Across all the British colonies over the whole colonial period, the share was lower: about one-half to two-thirds of white immigrants came this way.

### Africans brought by force, 1619

An English privateer, a privately owned armed ship whose crew attacked the ships of enemy countries, brought more than twenty Africans to Virginia in late August 1619. The ship was the *White Lion*, and it landed them at Point Comfort, near the mouth of the James River.

**Where they came from.** These Africans had been seized in wars around the kingdoms of Kongo and Ndongo, in West Central Africa, in what is now Angola. In 1618 and 1619 Luis Mendes de Vasconçelos, the Portuguese governor of Angola, led two attacks on the people of Ndongo.

He fought alongside the Imbangala, African fighters paid to fight for others, and together they captured thousands of people. Their captors marched them to the Portuguese port of Luanda and loaded them onto the Portuguese ship *San Juan Bautista*, with about 350 captives bound for Mexico.

Two English privateers, the *White Lion* and the *Treasurer*, attacked that ship in the Gulf of Mexico. Their crews took 50 to 60 of the Africans between them. The *White Lion* carried its share, more than twenty people, to Virginia. They are the first Africans recorded in English Virginia, and their landing began the forced arrival of Africans in the English mainland colonies.

### Richard Frethorne

> **Who:** An English boy who came to Virginia as an indentured servant and wrote home begging for help.
>
> **When and where:** Arrived in December 1622 on the *Abigail*. Martin's Hundred, Virginia. Listed among the dead there by February 1624.

**"I never ate anything but peas and loblollie," he wrote home.**

Richard Frethorne is one of very few ordinary people in the early colonies whose own words survive. He came to Virginia as an indentured servant, landing in December 1622 from a ship called the *Abigail*, and he worked at a place called Martin's Hundred.

In March and April 1623 he wrote letters to his parents in England. He begged them to buy out his indenture, which meant paying to free him from the rest of his years of work. If they could not do that, he asked them to send food. "I never ate anything but peas and loblollie (a thick porridge)," he wrote. In another line he wrote, "there is nothing to comfort us."

His name was on a list of the dead at Martin's Hundred by February 1624. The list does not give the cause of his death.

### Plymouth and the Puritans

Farther north, the *Mayflower* carried about 102 passengers across the Atlantic in 1620. They founded Plymouth, in what is now Massachusetts, on the site of Patuxet, a Wampanoag town. A disease had killed many of Patuxet's people between 1616 and 1619. The Pilgrims among the passengers were English Separatists. They wanted to worship apart from the Church of England, the official church of their country, and before crossing the ocean they had first moved to Leiden, in Holland.

A larger group followed ten years later. In 1630 John Winthrop led a fleet of 11 ships to Massachusetts Bay with about 700 passengers. His flagship, the ship that carried the fleet's leader, was the *Arbella*. These colonists were Puritans, English Protestants who disagreed with how the Church of England was run.

**Laud's courts.** King Charles I made William Laud Archbishop of Canterbury, the head of the Church of England, in 1633. Laud wanted every church to follow the same rules and ceremonies. Judges in a royal court called the Star Chamber and in a church court called the High Commission took church jobs away from many Puritan ministers, the men who led church services, or banned them from preaching.

Three Puritan writers, William Prynne, Henry Burton and John Bastwick, wrote against Laud. In 1637 judges sentenced them to have their ears cut off and their cheeks branded. Branding means burning the skin with a hot iron to leave a mark that never goes away.

About 20,000 Puritans came to New England over the 1630s, in what is called the Great Migration. They were one part of a larger movement. About 80,000 people left England in that decade, and roughly 20,000 went to each of four places: Ireland, the West Indies, the Netherlands and New England. The West Indies are the islands of the Caribbean Sea.

### Anne Hutchinson

> **Who:** An English woman who followed her minister to Boston, was put on trial and banished (ordered to leave and never come back) three years later, and was killed by Siwanoy fighters in 1643.
>
> **When and where:** Crossed on the *Griffin* in the fall of 1634. Boston, then Rhode Island, then land the Dutch claimed.

**She asked the court why she was banished, and got no answer.**

Anne Hutchinson sailed from England on the *Griffin* in the fall of 1634 with her husband, William, and their children. About 200 passengers were on board. She was following her minister, John Cotton, the preacher who led her church, to Boston.

**What she taught.** She held a meeting in her Boston house every week, starting in 1636, to go over the Sunday sermons. Women came at first, and then men came too. She taught that God's grace, his gift of being saved and going to heaven, did not depend on good behavior. She also said she could tell which of the colony's ministers had received that grace and which had not.

**The trial.** Governor John Winthrop and other colony leaders accused her of heresy, which means teaching against the church's beliefs. They counted the meetings against her too. In November 1637 the colony's lawmakers and judges, sitting as the General Court of Massachusetts, tried her at Newtown, now Cambridge, and Winthrop led the questioning.

At the end Winthrop told her, "you are banished from out of our jurisdiction (the land the court ruled) as being a woman not fit for our society." She answered, "I desire to know wherefore (why) I am banished?" Winthrop replied, "Say no more, the court knows wherefore and is satisfied."

She moved to Portsmouth, Rhode Island, in 1638. In 1642 she moved again, to land on Long Island Sound that the Dutch claimed, near what is now New York City. The Siwanoy, a Native people, lived there. The Dutch governor was Willem Kieft. On the night of February 25, 1643, Kieft's men killed at least 80 and perhaps as many as 120 Munsee people. With those killings they started a war with the Native nations nearby. It is now called Kieft's War, and it lasted until 1645.

**Her death.** During that war, in August or September 1643, Siwanoy fighters attacked Anne Hutchinson's household near Pelham Bay. They killed her, her servants, and all but one of the children who were with her.

### The Dutch and the Swedes

Dutch settlement began earlier than the Puritan fleet, in the 1620s, between Virginia and New England. Dutch colonists founded a colony called New Netherland. Its main town was New Amsterdam, on the island of Manhattan, in Lenapehoking, the homeland of the Lenape people. From 1638 to 1655, Swedish and Finnish settlers ran a small colony called New Sweden along the Delaware River, until the Dutch took it over in 1655.

Four English warships arrived at New Amsterdam in 1664. The Dutch governor, Peter Stuyvesant, surrendered without a fight, and the papers of surrender were signed in late August. The English renamed the colony New York, after James, the Duke of York, the younger brother of King Charles II of England.

### The first Jewish refugees, 1654

Twenty-three Jewish refugees, people fleeing danger at home, landed at New Amsterdam in 1654 on a ship called the *Ste. Catherine*. They came from Recife, in Brazil. The Dutch had held that part of Brazil, and the refugees left after Portuguese forces took it back. Another Jewish man, Jacob Barsimson, had arrived earlier that year.

Governor Peter Stuyvesant tried to force the refugees out of the colony. Leaders of the Dutch West India Company, the trading company that ran New Netherland and gave the governor his orders, overruled him.

### Catholics, Quakers and Huguenots

Other groups crossed the ocean for their religion too. Catholics settled in Maryland from 1634. Quakers, members of a Protestant group also called the Society of Friends, settled in Pennsylvania under William Penn from 1681. The Lenape people lived on both sides of the Delaware River there.

**The Huguenots.** King Louis XIV of France canceled the Edict of Nantes in 1685. King Henry IV had made that law in 1598, and under it French Protestants could worship in the towns they held. Huguenots fled France, and most went to other countries in Europe. Only about 1,500 to 2,000 had reached the American colonies by 1700. They settled in places such as New York, Massachusetts, and Charleston, South Carolina.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 6 minutes**

Scots-Irish and German newcomers came by the thousands in these fifty years, and many other arrivals came bound to work for years or for life. The Scots-Irish came from the north of Ireland, and the Germans from the lands along the Rhine River. Small Jewish communities grew in the port towns. The colonists still lived in a thin strip along the Atlantic coast, and the land farther inland was still Native land.

Bound workers could not leave their work until their time was up, and some never could. Indentured servants had signed contracts for years of work. Merchants sold British convicts as laborers. Slave traders brought enslaved Africans by force.

### Why Germans and Scots-Irish left home

German newcomers left to escape war, taxes and failed crops, and they came for cheap land. They came from southwest Germany and from the lands along the Rhine River, including the Palatinate, a region along the Rhine whose people were called Palatines. About 2,100 Palatines reached New York in 1709 and 1710.

A larger number of Germans went to Pennsylvania, mostly between about 1725 and 1775. About 12,000 German speakers had come to Pennsylvania by 1749. By the time of the Revolution, Germans made up about one-third of the people in that colony. The name Pennsylvania Dutch comes from *Deutsch*, the German word for German.

The Scots-Irish were Presbyterians, members of a Protestant church, from Ulster in the north of Ireland. Their ancestors were Scots who had settled in Ulster. Between 1710 and 1775 about 200,000 of them came to the land that later became the United States.

**The Test Act.** They left to escape high rents and a law called the Test Act, which Ireland's lawmakers passed in 1704. Under it, only people who took communion, a church ceremony of bread and wine, in the Church of Ireland could hold a public job. That rule shut Presbyterians out of public jobs. Marriages performed by Presbyterian ministers did not count under the law, so the law said the children of those marriages were born outside a lawful marriage.

Pennsylvania was the main place where the Scots-Irish landed. Many then moved south along the Appalachian backcountry, the land in and near the Appalachian Mountains, far from the coast. That backcountry was Native land.

### John Peter Zenger

> **Who:** A boy from the German Palatinate who grew up to be a New York printer, jailed and tried over what his newspaper printed.
>
> **When and where:** Arrived in New York in June 1710. Died July 28, 1746.

**His paper missed one issue in his almost nine months in jail.**

John Peter Zenger reached New York in June 1710, at the age of 13. His father, Nicolaus, had died on the voyage. The family came from Rumbach, in the Palatinate, and had joined the Palatine migration in late 1709, traveling first to England. John Peter landed with his widowed mother, Johanna, and his two siblings. In 1711 he began work as an apprentice, a young worker who learns a trade from a master, to the New York printer William Bradford.

**The newspaper.** In 1733 Zenger became the printer of the *New-York Weekly Journal*, a newspaper started by men who opposed the governor, William Cosby. Cosby had copies of the paper burned. Two judges on Cosby's side, James De Lancey and Frederick Philipse, ordered Zenger's arrest, and on November 17, 1734, the sheriff took him to jail.

**The charge.** He was charged with seditious libel, the crime of printing words that blame a public official or the government. His bail, money paid to a court so that a person can leave jail until the trial, was set at 400 pounds. Zenger did not have that much money, so he stayed in jail until his trial, almost nine months later. His wife, Anna, and his apprentices kept printing the paper, and only one issue was missed. On August 4, 1735, a jury found Zenger not guilty.

### Jewish communities

Most of the Jews in the colonies were Sephardic Jews, whose families had come from Spain and Portugal. After the first group landed at New Amsterdam in 1654, Jewish communities formed at Newport, Rhode Island, and at Charleston, New York and Savannah, Georgia. On July 11, 1733, 42 Jews landed at Savannah.

### Convicts sent as bound labor

**The Transportation Act.** British lawmakers passed the Transportation Act in 1718. Under it, merchants shipped about 50,000 convicts, people found guilty of crimes, from Britain to the American colonies. Some counts put the number as high as 60,000, and more than 20,000 went to Virginia. Officials of the British treasury, the office that handled the government's money, paid the merchants for each convict. The first merchant to get this contract was Jonathan Forward.

In the colonies the merchants sold the convicts as bound laborers, workers who had to work for a buyer for a set number of years. Most had to work seven years, and some had to work fourteen. Buyers included merchants, tradesmen, shipbuilders and ironworks owners, because a convict cost less than an indentured servant or an enslaved African. The shipping went on until 1775.

Convicts made up roughly a quarter of the people who emigrated from Britain in the 1700s, leaving their own country to live in another. Indentured servants kept coming alongside them.

### Forced arrival through Charleston

The number of enslaved Africans that slave traders brought to the mainland colonies rose sharply in these years. Rice planters in the South Carolina Lowcountry, the low coastal land, bought large numbers of West and Central Africans. Some planters chose Africans who already knew how to grow rice. Charleston, South Carolina, was the main mainland port where enslaved Africans arrived.

**Sullivan's Island.** Many were held first at a quarantine station on Sullivan's Island, at the mouth of Charleston's harbor, where new arrivals were kept apart so that any disease they carried would not spread. They were kept in buildings called pest houses and checked for disease there. The histories of the island do not name the people who kept them. Then slave traders took them to Charleston and sold them at public auction.

The historian Peter Wood wrote in 1974 that Sullivan's Island "might well be described as the Ellis Island of black Americans." Ellis Island was the New York station where millions of European immigrants later arrived. Published estimates put at least 200,000 Africans through Charleston harbor and say that about 40 percent of African Americans today have an ancestor who came that way. Nic Butler, a historian at the Charleston County Public Library, argues that the share credited to Sullivan's Island is too high.

Across the whole slave trade, slave traders forced about 12.5 million Africans onto ships. About 10.7 million lived through the crossing, and about 1.8 million died on the slave traders' ships on the way. Fewer than 4 of every 100 people who lived through the crossing were brought to mainland North America. About 305,000 came straight from Africa, and close to 388,000 came in all, counting those brought by way of the Caribbean.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 5 minutes**

After the Revolution, members of Congress decided who could become a citizen, a full legal member of the new country, and they limited it to free white people. Fewer people crossed the Atlantic to settle during the American Revolution, from 1775 to 1783, than before it. In the 1790s thousands of refugees arrived from a revolution in the Caribbean.

### Alexander Hamilton

> **Who:** An orphaned clerk from the Caribbean who came to New York as a teenager to go to school, and stayed.
>
> **When and where:** Born on Nevis. Sailed from St. Croix in late 1772 or early 1773. King's College, New York.
>
> **Movie:** *Hamilton* (2020), the filmed Broadway stage musical with its original cast, released on Disney+ on July 3, 2020. It is a dramatization, not a documentary.

**A letter about a hurricane paid his way to school.**

Alexander Hamilton was born on the Caribbean island of Nevis on January 11. The year is disputed: accounts of his life give either 1755 or 1757. By 1772 he was working on the nearby island of St. Croix as a clerk, a worker who keeps written records for a business.

A hurricane struck St. Croix on August 31, 1772. Hamilton wrote a letter describing the storm, dated September 6, and a newspaper called the *Royal Danish American Gazette* printed it on October 3. After reading it, men on the island raised money to send him to school in North America.

He sailed in late 1772 or early 1773. Accounts differ on the date. He studied at King's College in New York, and he stayed. Later he worked for the new national government at the Treasury, the department that handles the government's money.

### The Revolution and the Loyalists

Fewer immigrants crossed the Atlantic during the Revolutionary War, from 1775 to 1783, than in the years before it. The shipping of British convicts to the colonies ended in 1775. During and after the war, tens of thousands of Loyalists, colonists who sided with the British king against the Revolution, left the country, many of them for Canada.

Under the peace of 1783, the western border of the United States was the Mississippi River. Spanish and French officials claimed the land beyond the river. Most of the land away from the Atlantic coast was still Native land.

### Who could become a citizen in 1790?

Only "a free white person" of "good character" could. Members of Congress wrote those words into the Naturalization Act of 1790, the national government's first law on naturalization, the legal process by which a person born in another country becomes a citizen. To qualify, a person had to live in the United States for two years, including at least one year in the state where they applied, and swear loyalty to the Constitution. Children born abroad to citizens were included as citizens.

Under this law, an immigrant who was enslaved or was not white could not become a citizen. Members of Congress did not fully remove the limit to white people until 1952, 162 years later.

The men who wrote the Constitution in 1787 also set a date for arrivals by force. In Article I, Section 9, they barred Congress from stopping the bringing in of enslaved people before 1808. So for about twenty more years, slave traders could legally bring captives into the country.

### Pierre Toussaint

> **Who:** A man born enslaved in Saint-Domingue and brought to New York by the family that enslaved him. He became a leading hairdresser and was freed in 1807.
>
> **When and where:** Brought to New York in 1787. Freed July 2, 1807. Died in New York, June 30, 1853.

**He was one of New York's leading hairdressers, and still enslaved.**

Pierre was born enslaved in Saint-Domingue, a French colony in the Caribbean, in about 1766, though some recent accounts give 1781. Until he was freed, he was known simply as Pierre. In 1787 Marie Elisabeth Bérard and her husband, the family that enslaved him, took him to New York. The Bérards were fleeing fighting and disorder in the colony, four years before the revolution there began.

In New York Pierre trained under a hairdresser and became one of the city's leading hairdressers. When Marie Elisabeth Bérard's husband died, Pierre supported her. He was still enslaved by her family at the time. During an outbreak of yellow fever, a deadly disease spread by mosquitoes, in New York in 1798, he nursed sick people who were kept apart from others.

**Freedom.** Marie Elisabeth Bérard married again, to a Mr. Nicolas, and she died in 1807. On her deathbed she made her second husband promise to free Pierre. Mr. Nicolas kept the promise, and Pierre was free on July 2, 1807. If he was born in about 1766, he was about 41, though one account says 45. As a free man he took the surname Toussaint, to honor Toussaint Louverture, a leader of the revolution in Saint-Domingue.

Toussaint used his money to care for orphans and to fund early Catholic charities in New York, groups that helped the poor. In 1811 he married Juliette Noel, an enslaved woman, after he paid for her freedom.

**After his death.** Cardinal John O'Connor, the head of the Catholic Church in New York, had Toussaint's remains moved in 1990 to the crypt of St. Patrick's Cathedral, a burial room beneath the church. Pope John Paul II declared him Venerable in 1996, a title the pope gives to a person whom church leaders are studying as a possible saint.

### Refugees from Saint-Domingue

Enslaved Africans in Saint-Domingue, a French sugar colony, rose up on August 21, 1791, against the French planters who enslaved them and against French rule. The fighting went on until January 1, 1804, when Saint-Domingue became the independent country of Haiti.

Refugees fled to cities in the United States. They included white planters and free people of color, meaning people of African or mixed descent who were not enslaved. They also included enslaved people, whom their owners brought with them. That first year a ship called the *Charming Sally* carried 15 refugees to Philadelphia. By 1794 more than 3,000 refugees had come to that city, and nearly 20,000 refugees from Saint-Domingue came to the United States across the 1790s and the 1800s.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 10 minutes**

The first large wave of people who chose to come here arrived in these years, mostly from Germany and Ireland, and some Protestant Americans met the Irish Catholics with mobs. Germans were the largest group of newcomers from about 1840.

One kind of arrival ended early in these years. Under a national ban that began on January 1, 1808, no one could legally bring an enslaved person into the country from abroad.

Protestants, Christians whose churches had split away from the Catholic Church led by the pope, formed mobs that attacked Catholics near Boston in 1834 and burned Irish Catholic homes in Philadelphia in 1844. Then more than 1.5 million Irish people reached American ports between 1845 and 1855, during and after a famine in Ireland, a time when food ran so short that many people died of hunger. New York was the main port where they landed, and large numbers also came ashore at Boston and at New Orleans.

### The end of legal arrival from Africa

President Thomas Jefferson signed a law on March 2, 1807, that banned bringing enslaved people into the United States from other countries. It is called the Act Prohibiting Importation of Slaves, importation meaning bringing people or goods in from abroad. The ban began on January 1, 1808, the earliest date the Constitution allowed.

No one could legally bring an enslaved African across the ocean after that. Smugglers kept bringing in captives against the law. From then on, the number of enslaved people in the country grew mainly through children born to enslaved mothers. Enslavers held those children as property from birth.

### Germans and the Forty-Eighters

More immigrants came from Germany than from any other country from about 1840 to 1890. Many Germans left home because their crops had failed, and they came for farmland, most of all in the Midwest. Roughly three out of every five German immigrants settled there to farm. About 6 million Germans came to the United States between 1820 and World War I.

**The Forty-Eighters.** Revolutions broke out in Germany in 1848 and 1849. The people who fought in them wanted democratic government, in which the people choose their leaders. Soldiers from Prussia, a kingdom in what is now Germany, crushed the revolutions, and some of the revolutionaries fled abroad.

The ones who came to the United States are called the Forty-Eighters, after the year 1848. There were only about 4,000 to 10,000 of them. Many were journalists or professionals, people trained for skilled work such as law or medicine. Some of them later became leaders in their new country.

### Jette Bruns

> **Who:** A German woman who settled in Missouri with her doctor husband and wrote letters home to her brother for more than fifty years.
>
> **When and where:** Born 1813 in Oelde, Westphalia. Arrived at the Westphalia Settlement, central Missouri, in 1836. Died 1899.

**She wrote home to her brother for more than fifty years.**

Henriette Geisberg Bruns, known as Jette, came from Oelde, a town in Westphalia, a region of Germany. In 1836 she arrived at the Westphalia Settlement in central Missouri with her husband, the doctor Bernhard Bruns. Their baby son came too, along with two of her brothers and a maid.

Bernhard became mayor of Jefferson City, the capital of Missouri, and he died in office during the Civil War. After he died, Jette had almost no money. She ran a boardinghouse, a house where people paid to sleep and eat, across from the Missouri state capitol, the building where the state's lawmakers meet.

**The letters.** Her letters home to her brother Heinrich survive. The University of Missouri Press printed them in 1988, along with a short account of her life that she wrote after the Civil War. Adolf E. Schroeder edited them and translated them into English. The book is called *Hold Dear, As Always: Jette, a German Immigrant Life in Letters*.

### Mobs against Catholics, 1834 and 1844

Some Protestant Americans turned against the Irish newcomers and against Catholics. Before the Irish famine, Protestant mobs attacked Catholics in two cities and burned their buildings.

**Charlestown, 1834.** A mob of mostly Protestant workmen burned a Catholic convent school, a school that nuns ran in their own home, in Charlestown, near Boston, on the night of August 11, 1834. The nuns and 47 girl students were inside, and only six of the girls were Catholic. One Boston newspaper put the mob at 50 to 60 men, and another put it at 150 to 200. About 2,000 people gathered to watch.

The mob broke down the doors and windows, set fire to the buildings and burned them to the ground. The men also broke open the tomb where several dead nuns were buried. The records of the attack list no deaths.

Police arrested 13 men. At trial, juries found 12 of them not guilty, including their leader, John R. Buzzell. He later wrote that the evidence against him was enough "to have convicted (found guilty) twenty men, but somehow I proved an alibi (proof that he was somewhere else)." The one man found guilty was 16 years old, and Governor John Davis pardoned him, forgiving the crime and ending the punishment.

Massachusetts lawmakers at first voted down a request from Catholic church leaders to be paid for the loss. In 1846 they voted the church $10,000. Church leaders put the loss at about $100,000, ten times as much, and refused the money.

**Philadelphia, 1844.** In Philadelphia the fighting began over schools. Teachers in the public schools made Catholic children read the Protestant version of the Bible. Francis Patrick Kenrick, the Catholic bishop of Philadelphia, the leader of the city's Catholic churches, objected. Nativists, people who wanted power kept for native-born Protestants, then claimed that Catholics were trying to throw the Bible out of the schools.

Nativists held a rally on May 6, 1844, in Kensington, a mostly Irish Catholic neighborhood. Shooting and fighting broke out between the nativists and the Irish Catholics. An 18-year-old nativist named George Shiffler was shot dead. The records do not say who fired the shot.

Nativist crowds burned Irish Catholic homes, a fire station and a market on May 7 and 8. They also burned two Catholic churches, St. Michael's and St. Augustine's, and the school of St. Augustine's. They burned a seminary, a school that trains people for church work, run by the Sisters of Charity, a group of Catholic nuns. One count gives about 30 homes burned and about 200 people driven from their homes.

**St. Philip de Neri.** Nativist crowds learned in July that the brother of the priest at a third church, St. Philip de Neri, had stored guns in it to defend it. They gathered there and brought a cannon. Soldiers of the state militia, a force of citizens called up to serve as soldiers, fired on the crowd under General George Cadwalader. The crowd attacked the soldiers with bricks, stones, bottles and guns.

Accounts give different counts of the dead. For the May riots, the counts run from at least 14 dead to 20 dead. One of the Catholics killed was Joseph Rice. The Encyclopedia of Greater Philadelphia lists four soldiers and "probably a dozen rioters" dead in July. EBSCO's reference articles give figures that add up to about 34 dead and at least 126 wounded in both riots together. There is no agreed total.

**Who was blamed.** A grand jury, a group of citizens who decide whether there is enough evidence to put a person on trial, charged 19 of the rioters. Juries found only a handful of the 19 guilty. In June 1844 a grand jury blamed the Catholics who had been attacked. It said the May riots came from efforts "to exclude the Bible from the public schools." Catholics answered that the jury had called no Catholic to testify.

That October, Philadelphia voters elected Lewis Levin to Congress. Levin was a newspaper editor who had founded the nativist group that held the Kensington rally.

### The Irish famine

A plant disease called potato blight rotted Ireland's potatoes from 1845 to 1852. The blight is a water mold, a tiny living thing that grows on the plant and makes it rot. At least two out of every three people in Ireland lived mainly on potatoes. People starved, and at least 1 million people in Ireland died. This is called the Great Famine.

**Food kept leaving.** Ireland had been part of the United Kingdom since 1801, ruled by the government and the lawmakers in London. Ships kept carrying food from Ireland to Britain while people starved. The historian Christine Kinealy counted almost 4,000 ships that carried butter, grain and farm animals from Ireland to British ports in 1847. Soldiers guarded some of those shipments. About 400,000 people in Ireland died that year. Accounts still differ about how much of the need that food could have met.

In an earlier food shortage, in the 1780s, British officials had banned grain from leaving Ireland, and the ban had worked. In 1846 and 1847, Prime Minister Lord John Russell, the head of the British government, and his ministers, the officials who ran its departments, refused to ban grain from leaving Ireland again. They also made Irish taxpayers pay for famine relief, the food and work given to people who were starving.

Charles Trevelyan was the senior official at the Treasury, the government's money department, who ran famine relief. In December 1846, writing to Lord Monteagle about Ireland, he said that the real problem was not the famine. He said it was "the selfish, perverse (stubbornly wrong) and turbulent (unruly) character of the people," meaning the Irish.

**The quarter-acre rule.** In 1847 members of the British Parliament, the lawmakers in London, added a rule to the law on help for the poor. The rule was named for one of them, William H. Gregory. Under it, a family holding more than a quarter of an acre of land could get no relief. To get food, a family had to give up its land.

**Evictions.** Landlords forced tenant families, families who rented the land they farmed, off their land and often pulled their houses down. This is called eviction. Police records list almost 250,000 people evicted from 1849 to 1854.

The historian James S. Donnelly Jr. judged that count too low. He also counted families forced to give up their land in other ways from 1846 to 1854, and he wrote that the total "would almost certainly exceed half a million persons." Lord Palmerston, a minister in the British government, cleared about 2,000 tenants from his land in County Sligo and paid their fares overseas. Major Denis Mahon evicted thousands of tenants in County Roscommon.

Most of the people who died in the famine died of disease, which people then called fever. Officials in Ireland did not record deaths then, so the numbers are estimates. They run from about 1 million to 1.5 million dead.

**The crossing.** At least 2.1 million people left Ireland from 1845 to 1855, and most of them went to the United States. People called the crowded ships of those years "coffin ships." The *Virginius* sailed to Canada in 1847 with 496 passengers, and a report in the Toronto *Globe* said that 158 of them had died, "nearly one third."

More than 1.5 million Irish people arrived at American ports between 1845 and 1855. Most of them were poor when they landed. They settled in cities of the Northeast, such as New York and Boston, and in other cities in Pennsylvania, Massachusetts and beyond.

### Patrick Kennedy and Bridget Murphy

> **Who:** Two people from County Wexford, Ireland, who married in Boston during the famine years. Patrick was the great-grandfather of President John F. Kennedy.
>
> **When and where:** Patrick left Ireland in 1848 or 1849. They married in September 1849. East Boston, Massachusetts.

**He made barrels in East Boston and died of cholera at 35.**

Patrick Kennedy was born in 1823 at Dunganstown, in County Wexford, Ireland. He left during the Great Famine and made a new home in East Boston, Massachusetts. Accounts differ on whether he left in 1848 or in 1849. In East Boston he worked as a cooper, a person who makes barrels.

He married Bridget Murphy in September 1849. She also came from County Wexford, from a place called Owenduff. The couple had five children.

Patrick died of cholera, a disease people catch from dirty water or food, on November 22, 1858, at the age of 35. Cholera causes heavy diarrhea, and a sick person can lose so much water from the body that they die within days.

Patrick's son Patrick Joseph Kennedy, known as P.J., had a son named Joseph P. Kennedy. Joseph's son was John F. Kennedy, who later became president of the United States.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 20 minutes**

Chinese immigrants became the first people that lawmakers barred from the country because of where they came from. Newcomers from Europe kept arriving, about 11 million through the port of New York alone between 1855 and 1890. Germans still came in the largest numbers in the 1850s. Chinese immigrants began arriving on the West Coast in 1849. Toward the end of the century, Italians, Poles, Hungarians, Greeks and Jews from the Russian Empire came in growing numbers.

Mobs in the West killed Chinese immigrants and drove whole Chinese communities out of their towns from 1871 to 1887. The Chinese Exclusion Act of 1882 was the first law in the United States to bar a group of people because of their nationality, meaning the country they came from.

### Germans and the Know-Nothings

More than 950,000 Germans came to the United States in the 1850s. About 220,000 of them arrived in 1854 alone.

Members of secret societies that opposed immigrants and Catholics formed a political party in the 1850s. Its official name was the American Party. Members who were asked about the group answered, "I know nothing," and the party came to be called the Know-Nothings. The Know-Nothings feared that Catholics were a danger to the Protestant faith and to democracy. In the 1854 elections in Massachusetts, Know-Nothing candidates won all but 3 of the 400 seats in the state's lawmaking body.

**Bloody Monday.** Know-Nothing mobs attacked immigrants in Louisville, Kentucky, on Monday, August 6, 1855. It was election day, and people call it Bloody Monday. Irish and German immigrants made up about a third of the city. In the weeks before the vote, George D. Prentice, editor of the *Louisville Journal*, wrote newspaper articles against immigrants.

Know-Nothing gangs stopped immigrants from voting. Mobs led by party members attacked the German neighborhoods east of downtown and the Irish neighborhoods to the west. They set fires and robbed homes and businesses, and they damaged more than 100 homes and businesses.

Accounts written later say the mob burned Quinn's Row, a row of houses owned by an Irishman named Quinn, and shot people as they ran from the flames. A study published in the 2020s in the Kentucky Historical Society's journal uses court statements from the 1850s to challenge many of the stories told about the riot.

The Kentucky Historical Society lists at least 22 dead. Other counts give 19 to 22, and Catholic leaders at the time put the number at well over 100. Most of the dead were Irish and German. A grand jury charged five people, and none was found guilty. No one paid the victims for their losses. The Catholic bishop, Martin John Spalding, asked Catholics to stay calm and not to take revenge.

The party's members then split over slavery. By 1860 the party had broken apart, and many of its members had joined the new Republican Party.

### Carl Schurz

> **Who:** A German revolutionary who fled after the revolutions of 1848 and 1849 failed. In the United States he became a Union general, a senator and Secretary of the Interior.
>
> **When and where:** Born March 2, 1829, in the Rhine Province of Prussia, near Cologne. Settled in Watertown, Wisconsin, in 1852. Died May 14, 1906.

**He fought a revolution in Prussia and became a United States senator.**

Carl Schurz was one of the Forty-Eighters. He grew up near the city of Cologne, in the Rhine Province of Prussia, a kingdom in what is now Germany. Schurz joined the revolutions of 1848 and 1849. When Prussian forces crushed them, he fled to France and then to London. In 1852 he crossed the Atlantic as a refugee and settled in Watertown, Wisconsin.

In the Civil War he served as a general in the Union army, the army of the United States government, which fought the Southern states that had broken away. From 1869 to 1875 he represented Missouri in the United States Senate, as the first senator born in Germany. President Hayes then chose him as Secretary of the Interior, one of the heads of government departments who advise the president. He held that job from 1877 to 1881.

### The last known slave ship

A sailing ship called the *Clotilda* carried about 110 African captives to Mobile, Alabama, around July 8, 1860. Bringing captives into the country had been against the law for 52 years. The businessman Timothy Meaher paid for the voyage, reportedly to win a bet that he could smuggle captives in. The ship's captain, William Foster, set the *Clotilda* on fire near Twelve-Mile Island. It is the last documented slave ship to reach the United States.

**Kossola.** One of the captives was Oluale Kossola, born in about 1841 in what is now Benin, in West Africa. Accounts say soldiers of the kingdom of Dahomey captured him in a raid and took him to the coast. In Alabama, Meaher, his brothers and some friends enslaved the captives for the next five years, until slavery ended in 1865.

**Africatown.** After the end of slavery the survivors could not pay for the trip home. They built their own town near Mobile and called it Africatown. The writer Zora Neale Hurston interviewed Kossola in 1927, and her book about him, *Barracoon*, came out in 2018. The wreck of the *Clotilda* was found in the Mobile River and confirmed in 2019.

### Chinese immigrants in the West

Chinese immigration to the United States began with the California Gold Rush, when crowds of people went to California to look for gold. About 325 Chinese people came in 1849. Three years later, in 1852, some 20,000 came. About 40,400 arrived in all between 1851 and 1860. Most came from Guangdong province, also called Canton, in southern China. By 1880 about 105,465 Chinese people lived in the United States.

**The railroad.** Chinese workers built the western part of the first railroad to cross the country. Managers of the Central Pacific Railroad had about 10,000 to 12,000 Chinese workers on the job at any one time between 1865 and 1869, about nine out of every ten of the railroad's workers. Chinese workers earned about $35 a month and paid for their own food and housing. White workers got about $42 a month plus housing.

**The strike.** Thousands of Chinese workers went on strike in June 1867, which means they stopped work together to press for better terms. They asked for $40 a month, a 10-hour workday instead of 11 hours, and shorter shifts in the tunnels. Charles Crocker was the railroad director in charge of building. He cut off all food and supplies to their camps and brought in the sheriff and his deputies. After about eight days the workers went back to work.

Snow, explosions and disease killed Chinese railroad workers. In the winter of 1866 and 1867, 44 storms hit the Sierra Nevada mountains. At Strong's Canyon an avalanche, a mass of snow sliding down a mountainside, carried away the camp of two work crews of Chinese workers who were building tunnels there. One worker's body was not found until spring.

Workers blasted through solid granite rock with black powder, an early kind of gunpowder. From 1867 they also used nitroglycerin, a liquid explosive that can go off from a jolt. Smallpox, a disease that passes from person to person and covers the body in sores, broke out in 1868 and 1869.

**The count of the dead.** The railroad's managers kept no record of how many workers died. A figure of about 1,200 dead comes from one newspaper report in 1870. A reporter for the *Sacramento Reporter* wrote that a train had brought in "the accumulated bones of perhaps 1,200" Chinese men from along the line. Chinese aid societies paid to send such bones home to China. On the same day, the *Sacramento Union* reported about 50 dead.

**Known:** Chinese workers died of snow, explosions and disease, and the railroad's managers did not count them.

**Not known:** The real number. Researchers at a railroad history museum think about 100 to 150 Chinese workers died building the railroad, and other estimates run from hundreds to thousands.

### The Page Act and the Chinese Exclusion Act

Members of Congress passed the Page Act in 1875, the national government's first law to limit immigration. Under it, contract laborers from China, Japan and other Asian countries could not come in. These were workers brought over without their free consent, already bound to work for someone for a set time. The law called them by an insulting name used then for Asian laborers. A Chinese worker who came freely, with no such contract, could still come in.

**Chinese women.** Under the Page Act, no one could bring in women for prostitution, which means selling sex for money. Immigration officers at the ports decided which women those were. In practice they treated Asian women in general as suspects and kept out most Chinese women. The stated reason, stopping prostitution, was a pretext, meaning a false excuse.

**What changed in 1882.** President Chester A. Arthur signed the Chinese Exclusion Act, a law to shut Chinese workers out, on May 6, 1882. Under it, no Chinese laborer could come in for 10 years, whether he had a contract or not. It was the first law in the United States to bar a group of people because of their nationality or their ethnicity, the group a person is born into, with its own language and customs. Members of Congress later renewed the law and made it wider. They did not cancel it until 1943, 61 years after Arthur signed it.

**By 1882:** Chinese workers had built the western part of the first railroad across the country, and lawmakers had now shut new Chinese workers out for ten years.

### Attacks on Chinese immigrants, 1871 to 1887

Before and after the Exclusion Act, mobs in the West attacked Chinese immigrants. Juries and judges punished almost none of the attackers.

**Los Angeles, 1871.** A gunfight broke out between two groups of Chinese residents of Los Angeles on October 24, 1871. A local rancher, Robert Thompson, fired into a Chinese store. He was hit by return fire and died about an hour later. A mob of about 500 non-Chinese men then spent about two hours pulling Chinese people out of the Chinese part of town. They shot, beat and hanged them, and they robbed Chinese homes and stores.

They killed 18 Chinese men and boys, about one in ten of the city's Chinese people. Only one of the dead is thought to have taken part in the first gunfight. The mob hanged seven men from the wooden crossbar of a porch and three more from the side of a wagon.

The dead included Chee Long Tong, a doctor who healed people with herbs, and a teenager, Ah Loo. Dr. Tong offered the mob money and the diamond ring on his finger if they would spare his life. The geographer Reece Jones writes that a man in the crowd shot him in the mouth and cut off his finger to take the ring. The mob also hanged him.

A grand jury charged 25 men. By one account eight were found guilty of manslaughter, the crime of killing someone without planning to, and by another account nine. A judge sentenced them to two to six years in San Quentin prison. About a year later the judges of the California Supreme Court threw out the guilty verdicts because of a mistake in how the charges were written. None of the men was tried again.

**Rock Springs, 1885.** Between 100 and 150 armed white miners and railroad workers attacked the Chinese miners they worked beside in Rock Springs, in Wyoming Territory, on September 2, 1885. A territory was land the national government ran before it became a state. Managers of the Union Pacific Railroad had hired the Chinese miners at lower pay. Most of the attackers were immigrants themselves, from Britain, Ireland, Wales and Scandinavia.

The attackers shot Chinese miners, struck them with picks, hatchets and clubs, and burned all 79 houses in the Chinese part of town. Some Chinese people burned to death in their cellars. About 600 Chinese people fled. The Wyoming State Historical Society lists 28 Chinese killed and 15 wounded. Other counts put the dead at 40 to 50, because some who fled were never found.

President Grover Cleveland sent army troops, and the railroad's managers brought the Chinese miners back to work under army guard. Officials arrested 16 men, or 22 by some accounts. A grand jury charged none of them. It said that no one had been able to testify to "a single criminal act committed by any known white person that day."

**Eureka, 1885.** Other mobs drove Chinese people out of their towns. In Eureka, California, in February 1885, a stray bullet from a gunfight between two Chinese groups killed a city councilman, David Kendall. That night more than 600 white residents gathered and put up a gallows, a frame for hanging people. City leaders ordered every Chinese resident to leave within 24 hours. A committee of white residents put about 480 Chinese people, nearly all of the town's Chinese residents, on two steamships to San Francisco. No one was killed.

The Chinese families left behind their furniture, goods, shrimp boats and vegetable farms. Chinatown was torn down, and the accounts do not name who did it. A Chinese aid group, the Six Companies, sued the city in 1886, and the case was dropped. Rules keeping Chinese people out stayed in Eureka's city charter, its basic set of laws, until 1959.

**Tacoma and Seattle.** Mayor Jacob Weisbach of Tacoma, in Washington Territory, led a year-long campaign to drive the Chinese out. He called them "a curse." Tacoma's leaders ordered all Chinese residents to leave by November 3, 1885, and about 150 left before that date. On November 3, a mob forced about 200 more Chinese residents out of their homes in the rain and onto trains out of town. The mob then burned their houses. Officials charged 27 Tacoma men, Weisbach among them, and later dropped every charge.

Mobs in Seattle forced more than 300 Chinese residents to the docks in February 1886, and ships carried about 300 of them away. Of 13 men tried for the Seattle riot, none was found guilty.

**Hells Canyon, 1887.** A gang of white horse thieves shot and killed as many as 34 Chinese gold miners in May 1887. The miners were camped in Hells Canyon, on the Snake River in Oregon, and the gang took their gold dust. One of the gang, Frank Vaughan, confessed that they had agreed nearly a year earlier to murder the miners. Vaughan testified for the state and was not tried. Three of the accused men fled before trial. A jury found the three who stood trial not guilty.

A stone marker placed at the site in 2012 states, "No one was held accountable." Its words are in English, in Chinese and in Nez Perce, a Native American language.

### Italians, Poles, Hungarians and Greeks

Italians, Poles, Hungarians and Greeks came in growing numbers late in the century. Many of them were peasants, poor farm workers, who had lost their land as farming in Europe became a business. They came to earn enough money to go home and buy a piece of land. One Slavic steelworker put the plan this way: "A good job, save money, work all time, go home, sleep, no spend." Many did go home.

### Jews from the Russian Empire

Jews from the Russian Empire came running from riots and from laws aimed at them. Unlike many of the peasants who came to earn money, they came as families and planned to stay.

Revolutionaries murdered the ruler of the Russian Empire, Tsar Alexander II, in March 1881. In the towns, many people in the crowds believed a rumor that Jews had killed him. They also believed that a special order from the government allowed them to beat Jews.

Six weeks after the murder, on April 15, 1881, a fight in a tavern in the town of Elisavetgrad, in what is now Ukraine, turned into an attack on the town's Jews. It was the first of about 250 pogroms, violent riots in which a crowd attacks Jewish people and their homes, shops and synagogues, the buildings where Jews worship. The pogroms went on until 1884, in Kiev, Warsaw and many other places. Another count gives 259 pogroms from 1881 to 1883.

**Who attacked.** The historian John Klier describes many of the attackers as laborers who drifted from place to place looking for work. Railroad workers, factory workers and local business rivals of Jews also took part. Peasants joined in mostly to steal. The attackers robbed and wrecked Jewish homes and shops. They beat, raped and killed Jews. Rape means forcing a person into sex.

Counts of the dead differ. One count says at least 40 Jews were killed from April to December 1881. Klier counts about 50 deaths in the whole wave. About half of those dead were Jews, and about half were rioters killed while the tsar's officials put down the riots.

For many years, accounts said that officials of the tsar's government had planned the attacks. Later, the historians Hans Rogger, I. Michael Aronson and John Klier looked for evidence of that and found none. Some local officials helped stir the attacks up. Klier writes that more than a thousand rioters were punished in some way. Another account says the tsar pardoned most of the rioters who were brought to trial. The two accounts do not agree.

**The May Laws.** Nikolai Ignatiev, the tsar's minister in charge of the police and of other matters inside the country, proposed rules called the May Laws in May 1882. Tsar Alexander III approved them. Ignatiev blamed the pogroms on the Jews themselves. The rules were for Jews in the Pale of Settlement, the region of the Russian Empire where Jews were allowed to live.

Under the May Laws, Jews could not move to new homes outside towns. They could not buy or rent land in the countryside, and they could not trade on Sunday mornings or on Christian holidays.

More than 2 million Jews from the Russian Empire came to the United States between 1881 and 1914. Many of them were escaping the pogroms and the May Laws. Over 1.5 million of them had arrived by 1910, most of them from Russia.

### The Statue of Liberty and Emma Lazarus

The Statue of Liberty, a gift from France, was opened with a ceremony in New York Harbor on October 28, 1886. Emma Lazarus wrote the poem quoted at the start of this chapter, "The New Colossus," in 1883, to help raise money for the statue's pedestal, the stone base it stands on. She wrote it one year after lawmakers shut Chinese workers out of the country.

Lazarus was born in New York in 1849, into a Sephardic Jewish family, whose ancestors were Jews of Spain and Portugal. She had worked with Jewish refugees from Russia who arrived in the 1880s. She died in 1887. People mostly forgot her poem until 1903, when her friend Georgina Schuyler had it mounted on a bronze plaque inside the pedestal. After that, people began to link the statue with the idea of America as a refuge, a safe place, for immigrants.

### Castle Garden and Ellis Island

Most immigrants who landed at New York from August 1855 to April 1890 passed through Castle Garden. It stood at Castle Clinton, in Battery Park, at the southern tip of Manhattan. It was the country's first official depot for immigrants, a building where officials received newcomers, checked them and recorded them. New York State and New York City officials ran it together. About 11 million immigrants arrived through New York in those years, and about 8 million of them passed through Castle Garden.

People had complained that officials at Castle Garden were dishonest. When it closed in 1890, officials of the national government took charge of immigration. On January 1, 1892, they opened Ellis Island, the national government's immigration station on an island in New York Harbor, in its place.

### Annie Moore

> **Who:** A 17-year-old from County Cork, Ireland, the first immigrant processed at Ellis Island. For about a century, another woman's life was told as hers.
>
> **When and where:** Arrived January 1, 1892, on the steamship *Nevada*. Lived on the Lower East Side of New York. Died in 1924.

**First through Ellis Island, she received a $10 gold coin.**

Annie Moore sailed from Ireland on the steamship *Nevada* with her two younger brothers, Anthony, who was about 15, and Philip, who was about 12. They reached New York on January 1, 1892, the day Ellis Island opened, and officials processed her before anyone else.

**The wrong Annie.** For about a century, writers described the wrong woman as Annie Moore. That woman went west and died in Texas, and she had been born in Illinois. In 2006 the genealogist Megan Smolenyak, a person who traces family histories through old records, offered $1,000 to anyone who could find the real Annie. Researchers who took up the challenge found her.

The real Annie Moore never left New York. She lived in a tenement, a crowded apartment building, on Monroe Street on the Lower East Side, and she married a clerk at a fish market. She died in 1924, at the age of 50. A headstone was placed on her grave in 2008. Statues of her stand at Ellis Island and at Cobh, in Ireland.

### Irving Berlin

> **Who:** A Jewish boy from the Russian Empire who arrived at Ellis Island at five and grew up to write "White Christmas" and "God Bless America."
>
> **When and where:** Born in 1888 in the Russian Empire (the place is uncertain). Arrived at Ellis Island September 14, 1893. Died September 22, 1989, at 101.

**He remembered his family's house in Russia burning.**

Irving Berlin was born Israel Beilin in 1888 in the Russian Empire. The place of his birth is uncertain. Recent research points to Tyumen, in Siberia, and older accounts give the region around Mogilev. His family used May 11 as his birthday, but one account gives May 23.

His memory of Russia was of his family's house burning during violence against Jews. No record says who set the fire. The family arrived at Ellis Island on September 14, 1893, and in America their surname became Baline.

He wrote his songs, among them "Easter Parade," under the name Irving Berlin. He wrote a first version of "God Bless America" in 1918, and the singer Kate Smith first performed it for the public in 1938. Berlin died on September 22, 1989, at the age of 101.

### Wong Kim Ark

> **Who:** A cook born in San Francisco to Chinese immigrant parents. Officials refused to let him back into the country, and his case went to the Supreme Court.
>
> **When and where:** Born 1873, San Francisco. Refused landing August 1895. Supreme Court decision March 28, 1898.

**Born in San Francisco, he was refused entry to his own country.**

Wong Kim Ark was born in San Francisco in 1873. His parents were Chinese immigrants, and he worked as a cook. In August 1895 he was coming home from a visit to China on the steamship *Coptic*.

John H. Wise, the official in charge of collecting taxes on goods coming into the port of San Francisco, refused to let him land. Wise acted under the Chinese exclusion laws. He said Wong was not a citizen, because his parents had not become citizens, and he held Wong on the ship.

**The court order.** On October 2, 1895, the national government's court in San Francisco issued a writ of habeas corpus for him, an order that the people holding him bring him before a judge and give a lawful reason for holding him. Judge William Morrow ruled that Wong was a citizen and ordered him freed.

Henry Foote, the national government's lawyer in San Francisco, had brought the case against Wong. Lawyers for the national government took it higher. The case, *United States v. Wong Kim Ark*, went on to the Supreme Court. On March 28, 1898, the justices, the judges of the Supreme Court, decided it 6 to 2 in Wong's favor. They ruled that under the Fourteenth Amendment, an addition to the Constitution, everyone born in the United States is a citizen.

**If you remember one thing:** Lawmakers shut Chinese workers out in 1882, the first time a law barred people for the country they came from, and in 1898 the Supreme Court ruled that anyone born here is a citizen.

**One number:** 61 years. Members of Congress kept the Chinese Exclusion Act, renewed and widened, from 1882 until they canceled it in 1943.

**Next:** After 1900 more newcomers came through Ellis Island than ever before, and lawmakers answered with limits on how many could come from each country.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 16 minutes**

The great wave of newcomers peaked in the early 1900s, and then members of Congress cut it down with quota laws, laws that fixed how many people could come from each country. Officials at Ellis Island admitted 1,004,756 people in 1907 alone. Under the 1924 law, no more than about 165,000 immigrants could come each year, and almost no one from Asia could come at all. On the West Coast, officials at Angel Island held Chinese arrivals anywhere from a few days to many months.

Officials pushed somewhere between 500,000 and 2 million people of Mexican descent out of the country from 1929 to 1936. By the two larger counts, about 6 in 10 of them were US citizens. Officials in Cuba, the United States and Canada refused to let a ship full of Jewish refugees land in 1939.

### Ellis Island's busiest years and the melting pot

Ellis Island's busiest year was 1907. Officials there admitted 1,004,756 immigrants that year. On the busiest single day, April 17, 1907, 11,747 people came through. About 12 million immigrants passed through Ellis Island from 1892 to 1954. Older claims of about 17 million are too high.

**The melting pot.** A play by Israel Zangwill called *The Melting Pot* opened in Washington, D.C., on October 5, 1908. Theodore Roosevelt watched the first night from his box and praised it. After that the phrase "melting pot," a pot in which different metals melt together into one, spread. People used the phrase to mean that newcomers from many lands would blend together into one nation.

### Frank Capra

> **Who:** A boy from Sicily who crossed to America in the cheapest part of a ship in 1903. He grew up to win three Academy Awards for directing films.
>
> **When and where:** Born May 18, 1897, in Bisacquino, Sicily. Came through Ellis Island in 1903, then went on to Los Angeles.
>
> **Movie:** *Frank Capra's American Dream* (1997), a documentary made for television. Kenneth Bowser directed it, and Ron Howard hosted it.

**He crossed in steerage and rode a train across the whole country.**

Frank Capra was born Francesco Rosario Capra in the town of Bisacquino, in Sicily, an island that belongs to Italy. His family crossed the Atlantic on the ship *Germania*. They traveled in steerage, the cheapest space on a ship, below the decks. They passed through Ellis Island and then rode a train across the whole country to Los Angeles.

As a grown man he directed films. He won his three Academy Awards as best director in the 1930s, and he made the film *It's a Wonderful Life* in 1946.

### Doukenie Bacos

> **Who:** A Greek girl who reached Ellis Island at 16. She was traveling underage and was afraid officials would send her back.
>
> **When and where:** Born December 18, 1904, to a Greek family in Thrace. Sailed from Piraeus, Greece. Reached Ellis Island January 5, 1921.

**She thought of jumping into the water rather than be sent home.**

Doukenie Bacos was born to a Greek family in Thrace, a region of southeastern Europe now divided among Greece, Turkey and Bulgaria. She was 16 when she sailed from Piraeus, the port city of Athens, on the ship *King Alexander* on December 22, 1920. She was traveling underage, younger than an adult, to join her uncle in America.

**Three days.** She reached Ellis Island on January 5, 1921, and officials held her there for three days. Her uncle was a bachelor, a man who had never married. The officials would not hand a girl her age to a bachelor alone, so he had to find a family for her to live with. She was afraid they would send her back, and she later said she had thought of jumping into the water rather than be sent home.

On the third day the officials let her go. That night her uncle came with a woman from the family he had found. "This is your aunt," he told her, and Doukenie went to live with that family.

Her full name was Doukenie Babayanie Bacos. She told her story to the Ellis Island Oral History Project, which records interviews with people who came through the island, in 1991. Her interview is number 49 in its EI series. Some records give 1919 as the year she left Greece, and National Park Service staff marked that year as a mistake.

### Angel Island

Angel Island Immigration Station opened in 1910 on an island in San Francisco Bay. The officials who worked there mainly enforced the Chinese Exclusion Act, an 1882 law that barred Chinese workers from coming in, and other laws against Asian immigrants. They held many Asian arrivals for days or months. The National Park Service states that some stays lasted several years, while the longest stay in other records is 22 months.

Officials refused entry to about 18 out of every 100 people who arrived at Angel Island. At Ellis Island the figure was 1 to 3 out of every 100.

Station officials kept the detainees, the people being held, locked in crowded dormitories, large rooms full of beds. No detainee could leave without a guard. Officers read every letter the detainees sent or received. No one could visit a detainee until the officials had decided the case.

**The doctors.** Doctors from the Public Health Service examined the arrivals. They turned people's eyelids inside out to look for trachoma, an eye infection that can cause blindness. They took samples of blood, spit, urine or stool, which means bowel movements, and they tested Asian arrivals for worms that live inside the body, such as hookworm. When officials doubted a person's age, doctors made the person strip naked. The doctors then examined the person's hair, skin, teeth, voice and genitals, the private parts of the body.

**Paper sons.** Chinese Americans born in the United States were citizens, as the Supreme Court had ruled in 1898. Under the exclusion laws, most other Chinese people could get in only by showing a family tie to a citizen. Some claimed a tie that was false. They were called "paper sons" and "paper daughters," because the family tie existed only on paper.

To catch them, a group of officials called a Board of Special Inquiry questioned each Chinese applicant about home villages and relatives. The board was made up of two inspectors, a translator and a stenographer, a clerk who wrote down every word. One inspector said in 1934 that "well over ninety percent" of his time went to questioning arriving Chinese people.

A few detainees killed themselves, most of them by hanging themselves in the bathrooms. The historian Judy Yung, who gave this account in 2026, said they were "driven to suicide." She gave no names and no count.

**The poems.** Detainees carved poems into the wooden walls of the barracks where they were held. The poems were almost lost before a park ranger, Alexander Weiss, found them in 1970, and then they were saved.

Counts of the Chinese people who passed through the station differ. One count is about 175,000 between 1910 and 1940, and the National Park Service states 250,000. A fire burned the station's main office building on August 12, 1940, and the station closed soon after.

### Lee Puey You

> **Who:** A Chinese woman who came as a "paper daughter" in 1939. Officials held her on Angel Island for about 20 months and then sent her back to China.
>
> **When and where:** Arrived at Angel Island in 1939. Deported to China in November 1940. Came back in 1947 and settled in San Francisco.

**Inspectors asked her about 170 questions, then sent her back.**

Lee Puey You arrived at Angel Island in 1939 as a "paper daughter," and inspectors asked her about 170 questions. Officials held her there for about 20 months, one of the longest stays known for a Chinese detainee.

In November 1940 they refused to let her in and deported her, which means they forced her to leave the country. She later said she "cried a bowlful of tears."

Members of Congress canceled the Chinese Exclusion Act in 1943. Lee Puey You came back to the United States in 1947 as a war bride, a woman engaged or married to a man who served in the war. She married and settled in San Francisco. Judy Yung later wrote about her in an article called "A Bowlful of Tears Revisited."

### How the quota laws of 1921 and 1924 worked

The Emergency Quota Act of 1921 was the first law to put number limits on immigration. Under it, the yearly quota for each nationality was 3 percent of the people born in that country who lived in the United States in 1910. That count came from the census, the official count of everyone living in the country.

**The 1924 law.** Members of Congress set much lower limits in the Immigration Act of 1924. It is also called the Johnson-Reed Act, after the two lawmakers behind it. Representative Albert Johnson of Washington State was chairman of the House committee on immigration, and David Reed was a senator from Pennsylvania. President Calvin Coolidge signed the law on May 26, 1924.

Under the 1924 law, each country's quota was 2 percent of the people born there who lived in the United States in 1890. Lawmakers picked 1890 because it came before the large wave from southern and eastern Europe. Italy's yearly quota fell from more than 42,000 to fewer than 6,000.

**Asia shut out.** Lawmakers also shut out anyone "ineligible for citizenship," meaning anyone who could not become a citizen under US law. At that time the law let only white people and people of African birth or descent become citizens. Members of Congress had added people of African birth or descent in 1870, five years after the Civil War, and left Asian immigrants out. In 1922 and 1923 the justices, the judges of the Supreme Court, ruled that immigrants from Japan and from India could not count as white. Under that rule, almost no one from Asia could come in.

Lawmakers capped the total at about 165,000 people a year, down from about 355,000 under the 1921 law. About 86 of every 100 quota places went to northern and western Europe, and about 9 went to southern and eastern Europe. Under those limits, the great rush of newcomers from Europe came to an end.

Coolidge had told Congress in his first message to it, in December 1923, "America must be kept American. For this purpose, it is necessary to continue a policy of restricted immigration." The State Department's Office of the Historian states: "The most basic purpose of the 1924 Immigration Act was to preserve the ideal of U.S. homogeneity (sameness)."

### Eugenics and the men behind the 1924 law

The men who shaped the 1924 law argued for it with eugenics. Eugenics was a false belief that a nation could improve its people by controlling who had children and who came into the country. Its believers ranked groups of people as "better" or "worse" by birth.

**Harry Laughlin.** Harry H. Laughlin ran the Eugenics Record Office at Cold Spring Harbor, New York. He testified, meaning he spoke under oath at a hearing, to Johnson's committee three times between 1920 and 1924, and Johnson named him the committee's "expert eugenics agent."

Laughlin claimed that immigrants from southern and eastern Europe, mainly Italians and Jews, had higher rates of "feeblemindedness, insanity, criminality, and dependency." Those were old words for low intelligence, mental illness, crime and needing public charity. He said that too many of the people in mental hospitals came from southern and eastern Europe. His own figures showed high rates for German and Irish immigrants as well.

**Madison Grant.** Madison Grant was a New York lawyer. In 1916 he wrote a book called *The Passing of the Great Race*. In it he claimed that a "Nordic race" from northwestern Europe was better than all other people. Grant helped Johnson write the 1924 law. Adolf Hitler, who later ruled Germany, wrote to Grant and called the book his "Bible."

**At home.** Laughlin also turned eugenics against Americans already living here. In 1922 he wrote a model law, a sample law for lawmakers to copy, for forced sterilization.

Sterilization is an operation after which a person can never have a baby. For a woman, a doctor cut or tied the two tubes that carry eggs from the ovaries to the womb, or cut out a piece of each tube, so that no egg could reach the womb again. For a man, a doctor cut the tubes that carry sperm. The operation could not be undone.

In part because of Laughlin's work, lawmakers in dozens of states passed laws that let officials force people to be sterilized against their will. By the 1960s doctors in the United States had sterilized more than 62,000 people this way, about 60 out of every 100 of them women.

**Carrie Buck.** Carrie Buck grew up with foster parents in Charlottesville, Virginia. In 1923 she became pregnant, by her own account because the foster parents' nephew raped her. The foster parents took the pregnancy as proof that she was "feebleminded" and had her sent to a Virginia state colony for people called feebleminded. The colony's head, Dr. Albert Priddy, picked her for a court case that would test whether Virginia's new sterilization law was allowed.

On May 2, 1927, in the case Buck v. Bell, the justices of the Supreme Court ruled 8 to 1 that Virginia officials could sterilize her against her will. On October 19, 1927, Dr. John H. Bell cut out a piece of each of her tubes.

**In Germany.** In 1933 the Nazis, Hitler's party, which then ruled Germany, passed a forced sterilization law based in part on the American practice. Under it, special courts of a judge and two doctors decided each case, and an approved doctor did the operation. About 400,000 people in Nazi Germany were sterilized this way. In 1936 leaders of the University of Heidelberg, in Germany, gave Laughlin an honorary degree, a degree given as an honor instead of for study.

### Mexican arrivals and the Mexican Repatriation

The Mexican Revolution was a war in Mexico that lasted from 1910 to 1920. During those years about 350,000 people fled north across the border into the United States. More kept coming in the 1920s.

**The Repatriation.** Officials pushed people of Mexican descent out of the United States from 1929 to 1936, in what is called the Mexican Repatriation, from a word for sending people back to their own country. By the larger counts, most of the people sent to Mexico had been born in the United States, so they were being sent out of their own country. It happened during the Great Depression, the years when many people in the United States had no work.

Secretary of Labor William N. Doak, who served under President Herbert Hoover, led a national campaign to remove Mexicans. He claimed they were taking jobs from other workers. In Los Angeles, Charles P. Visel, head of the city's unemployment relief committee, which handled public money for people without work, planned a publicity campaign.

Officials raided Mexican American neighborhoods and public places. County welfare officers, the officials who handed out relief money, told families that their relief money would stop unless they took free train tickets to Mexico. Officials of the Los Angeles County welfare office ran the trains, and the first one left on March 23, 1931.

Hospital staff carried patients on stretchers to trucks bound for the border. Families lost their property. In a 2005 California law, state lawmakers wrote that this property "often was sold by local authorities" as "payment" for the cost of removing the families.

**La Placita.** Immigration agents blocked the exits of La Placita, a park in Los Angeles, on February 26, 1931, while about 400 people were inside. Accounts of what happened next differ. According to the California Migration Museum, the agents arrested about a dozen people and deported a few. According to a History.com article, they rounded up more than 400 people and deported them.

Counts of the people removed run from about 500,000 to about 2 million. The California Migration Museum states about 1 million, following the historians Francisco Balderrama and Raymond Rodríguez. By that count, about 60 of every 100 were citizens born in the United States. The 2005 California law states about 2 million, and about 1.2 million of them had been born in the United States.

Officials pushed about 35,000 people out of Los Angeles, about a third of the Mexican people living there. California lawmakers apologized for the removals in that 2005 law. In February 2012 the members of the Los Angeles County Board of Supervisors, who run the county, apologized and put up a plaque, a metal sign with words on it, at LA Plaza. No apology from the federal government, the national government in Washington, is on record.

**The braceros.** US and Mexican officials started the Bracero Program in August 1942. Under it, Mexican farmworkers came to the United States on contracts to work for a set time and then go home. Bracero is a Spanish word for a man who works with his arms, from *brazo*, the word for arm.

### The St. Louis and the first refugee law

The German ship *St. Louis* left Hamburg for Havana, Cuba, on May 13, 1939, with 937 passengers. Almost all of them were Jewish refugees. Cuba's president, Federico Laredo Brú, canceled their papers to land, and Cuban officials let only 28 passengers off at Havana. The passengers asked President Franklin D. Roosevelt for help, and he never answered them. State Department officials told them they must "await their turns on the waiting list." Canadian officials refused them too.

**Why they fled.** The passengers were fleeing attacks on Jews that had grown worse in 1938. The Nazi government of Germany had taken over Austria in March 1938. On the night of November 9 and 10, 1938, Nazi leaders set off attacks on Jews across Germany. That night is called Kristallnacht, the Night of Broken Glass.

Nazis burned more than 1,400 synagogues, the buildings where Jews worship, wrecked thousands of Jewish-owned shops and broke into Jewish homes. German police locked about 26,000 Jewish men in concentration camps, prison camps for people the Nazis targeted, just because they were Jewish. Afterward Nazi officials seized property that Jews owned.

The ship turned back to Europe on June 6. The passengers went to four countries: 288 to Britain, 224 to France, 214 to Belgium and 181 to the Netherlands.

The German army invaded France, Belgium and the Netherlands in May 1940. Before the invasion, 87 of the passengers in those countries had moved on to other countries. Nazis killed 254 of those who were still there in the Holocaust, their murder of Jews and other people during World War II. The other 278 survived.

**The first refugee law.** Members of Congress passed the Displaced Persons Act in 1948, the first refugee law in the United States. Displaced persons were Europeans who had lost their homes in the war. Under the law, 200,000 people could come at first, counted against the yearly quotas, and in 1950 lawmakers raised the total. About 350,000 to 400,000 European refugees settled in the United States between 1948 and 1952. One count gives 393,542.

**If you remember one thing:** Lawmakers cut the great wave from Europe with quota laws and shut out almost everyone from Asia, and only after World War II did they pass a law for refugees.

In 1907: officials at Ellis Island admitted 1,004,756 immigrants in a single year.

After 1924: no more than about 165,000 could come in a year, and about 86 of every 100 places went to northern and western Europe.

**Next:** After 1950 federal officers rounded up Mexicans in the hundreds of thousands, and lawmakers ended the quotas.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 12 minutes**

Members of Congress threw out the country-by-country quotas in 1965, and after that most newcomers came from Asia, Latin America, Africa and the Caribbean instead of Europe. Federal officers rounded up Mexicans and Mexican Americans in 1954 and sent them to Mexico, and many of the people they sent were US citizens.

Refugees came from Cuba after 1959 and from Vietnam, Laos and Cambodia after 1975. Counts credited to the United Nations refugee agency give at least 200,000 Vietnamese who died at sea while escaping by boat, from storms, hunger, disease and attacks by pirates. About 2.7 million people who had lived in the country for years without legal permission got legal status under a 1986 law.

### The braceros and the 1954 deportations

The Bracero Program lasted until 1964. Over those years, Mexican farmworkers signed about 4.5 million short-term contracts to work in the United States. The workers came for the length of a contract and were expected to go home afterward.

Federal officers carried out a mass deportation of Mexicans in 1954, in a federal operation whose official name used an insult for Mexican people. The insult was aimed at Mexicans who crossed the border without papers, and it suggested that they had swum across the Rio Grande, the river along the border between Texas and Mexico.

**Who ran it.** Attorney General Herbert Brownell Jr., the head of the US Justice Department under President Dwight D. Eisenhower, pushed for the operation. General Joseph M. Swing ran it. He was the commissioner, or head, of the Immigration and Naturalization Service (INS), the federal office in charge of immigration. Swing announced the operation on June 9, 1954. INS officials planned it with officials of the Mexican government. Officers started in California and Arizona and moved into Texas in the middle of July.

**The roundups.** Border Patrol officers, the federal agents who guard the border, ran the roundups in a military style. Newspapers covered them heavily, and officials meant the coverage to scare people into leaving on their own. On the first day in Texas, July 15, 1954, officers caught 4,800 people. That July officers held 42,000 people in Texas, and more than 63,000 left on their own.

Officers sent people south by truck, bus, train and plane. From Port Isabel, Texas, they also put people on two ships, the *Emancipation* and the *Mercurio*, bound for Veracruz, Mexico. About a quarter of the people removed from Texas went by ship. A History.com article states that the ships were later compared to slave ships.

Seven deportees jumped from the *Mercurio*. The *Handbook of Texas* says a mutiny followed, meaning the people on board rose up against the crew. Other accounts say the seven drowned. After protests in Mexico, officials stopped sending people by ship.

**The heat.** The historian Mae M. Ngai reports that in July 1955 officers rounded up workers in 112-degree heat, and as a result 88 braceros, Mexican farm workers hired under contract, died of sunstroke, an illness in which the body gets so hot that it can no longer cool itself. A labor official told Ngai that more would have died without help from the Red Cross.

Ngai also quotes a Mexican labor leader. He reported that deportees were carried into Mexico on trucks "like cows" and unloaded in the desert, fifteen miles down the highway from the border. US immigration officials also left deportees in Mexicali, a Mexican border city where the summer heat averages 108 degrees. Other deportees died of disease and other causes while officers held them.

**Not known:** No record gives a full count of the dead, says whether the 88 were left in the desert, names the officers who ran that roundup, or shows that any official was charged for the deaths.

**The count.** INS officials claimed that as many as 1,300,000 people had left, counting people who, officials said, had fled out of fear. The historian Kelly Lytle Hernández puts the true number deported at "likely closer to 300,000."

The official numbers rested on an INS report of nearly 1.1 million people caught. Katrina Burgess, a professor at Tufts University, wrote in 2024 that this figure covered a whole government year, which ended in June 1954. The operation was announced on June 9, 1954, so most of those people had been caught before it began. Many of the arrests were also the same people caught again, sometimes on the same day, Burgess wrote.

Many of the people deported were US citizens of Mexican descent. No one knows how many.

### Antonio García

> **Who:** A Mexican farmworker who joined the Bracero Program at seventeen, after having his military ID card changed to say he was eighteen.
>
> **When and where:** Born June 13, 1937, in Tepehuanes, Durango, Mexico. Worked on contracts in Texas, California, Colorado and New Mexico into the early 1960s. Told his story in Chicago in 2003.

**At seventeen he had his ID changed to say eighteen.**

Antonio García was born in Tepehuanes, in the Mexican state of Durango. He grew up in Nuevo Ideal and left school after fourth grade. With his changed ID card, he signed up at the contracting centers in Chihuahua and in Empalme, Sonora, where Mexican workers signed contracts to work in the United States.

His first contract was for work in the cotton fields of Texas, and within a week he was seriously ill. He kept working on contracts, on and off, into the early 1960s, in California, Colorado, New Mexico and Texas.

Claudia Morales Haro recorded his life story in Chicago on March 12, 2003. The recording is item 162 in the Bracero History Archive, which contains more than 700 such interviews. His record does not say whether he settled in the United States for good.

### What the 1965 law changed

With the Immigration and Nationality Act of 1965, also called the Hart-Celler Act, members of Congress ended the national-origins quotas, the rules that had limited immigration country by country since the 1920s. Under the new law, people got in mainly through family ties to people already here or through their job skills. Lawmakers also ended the bars against Asians and against southern and eastern Europeans.

For the first time, lawmakers also set a limit on the number of immigrants from the Western Hemisphere, the half of the world that includes North and South America. That limit included Mexico. Over the following decades, the main sources of immigration shifted away from Europe, toward Asia, Latin America, Africa and the Caribbean.

### Cubans and the Mariel boatlift

Fidel Castro led a revolution in Cuba in 1959. Through the 1960s, many Cubans came to the United States, especially to Florida.

**Mariel.** Castro briefly let people leave in 1980. From April to October that year, about 125,000 Cubans crossed by boat from the port of Mariel to Florida. This was the Mariel boatlift.

About a month before the boatlift began, members of Congress passed the Refugee Act of 1980. With it, lawmakers created a permanent system for admitting refugees. They defined a refugee the same way the United Nations does: a person outside their own country who cannot go back because of a real fear of being harmed for their race, religion, nationality, group or political beliefs.

### Reinaldo Arenas

> **Who:** A Cuban novelist whom Castro's officials jailed for his writing and for being gay, and who left Cuba in the Mariel boatlift.
>
> **When and where:** Born July 16, 1943, near Holguín, Cuba. Left through the port of Mariel in May 1980. Lived in New York. Died December 7, 1990.
>
> **Movie:** *Before Night Falls* (2000), a drama based on his life story. Julian Schnabel directed it. Javier Bardem played Arenas, a role that earned an Oscar nomination.

**He tried to escape Cuba floating on a tire inner tube.**

Cuban officials persecuted Reinaldo Arenas, which means they punished him again and again, for what he wrote and for being gay, which means loving people of the same sex. In 1973, according to records at Princeton University Library, they charged him with "ideological deviation," holding ideas that Cuba's rulers banned, and with publishing his books in other countries without permission. A court convicted him on both. Another account says the court also called him "extravagant," which here means living too freely, and "immoral."

**A charge he denied.** The Mexican writer Rafael Lemus writes that in 1973 officials also accused Arenas and a friend of abusing two young people who were not yet adults. Arenas denied it, and none of these accounts says it was ever proved. Lemus says Arenas hid for four months to avoid arrest and was held from January 1974.

Arenas escaped from prison and tried to leave Cuba by floating away on a tire inner tube. Cuban officers caught him and locked him in El Morro, an old fort in Havana used as a prison. Officers of State Security, the political police of Fidel Castro's government, moved him to their headquarters, called Villa Marista.

**Villa Marista.** Lemus writes that at Villa Marista officers sent steam into the prisoners' closed cell until it became a steam room. There officers forced Arenas to sign a paper saying he was sorry for being gay and for his books. He was released in 1976, after he signed a promise not to write again. No record names any of the officers who held him.

In May 1980 he left Cuba through the port of Mariel, one of about 125,000 Cubans in the boatlift. In the United States he lived in New York, and there he wrote the story of his own life, called *Before Night Falls*.

He became sick with AIDS, a disease caused by a virus that destroys the body's defenses against other illnesses. On December 7, 1990, at the age of 47, he killed himself. His life story came out in 1992, two years after his death, and in English in 1993.

### Refugees from Southeast Asia and the boat people

North Vietnamese soldiers took Saigon, the capital of South Vietnam, in 1975, at the end of the Vietnam War. After that, refugees fled Vietnam, Laos and Cambodia. They included the Hmong, an ethnic group from the mountains of Laos. Many Vietnamese escaped in small boats, and they became known as the boat people.

Storms, hunger, disease and pirates killed many of them at sea. Counts credited to the United Nations refugee agency run from 200,000 to 400,000 dead. The journalist Barry Wain estimated 30,000 dead by 1981. No one knows the exact number.

**The pirates.** According to a UN refugee official in 1986 and a later study, the pirates were Thai fishermen in the Gulf of Thailand. Robert C. McCabe, a researcher at Maynooth University in Ireland, writes that some fishermen turned to piracy after big commercial fishing boats had cut the catch in their villages. No record names a single pirate.

Pirates robbed and raped refugees, murdered some and set others adrift. Rape means forcing a person into sex. In 1981 alone, the UN refugee agency counted 452 boats that reached Thailand with 15,479 refugees. Pirates had attacked 349 of those boats, on average three times each. They kidnapped 228 women, and 881 people were dead or missing.

Officials of the UN refugee agency and of the Thai government started a program against the pirates in June 1982. The governments of twelve countries paid for it, and the US government gave $1.2 million of the $3.67 million. By October 1987, 96 suspects had been arrested. No record names the officers who arrested them. Judges gave sentences of two to fifty years in prison, and one pirate was sentenced to death in December 1986.

US officials accepted 402,382 Vietnamese refugees from camps in Southeast Asia and Hong Kong from 1975 to 1997, more than any other country. A different count gives nearly 281,000 Vietnamese refugees settled in the United States from 1981 to 1990 alone. About 500,000 more Vietnamese came to the United States by 1994 through the Orderly Departure Program, a legal way to leave Vietnam without the boat trip.

### Tung Trinh

> **Who:** One of 52 survivors of a refugee boat from Vietnam that drifted at sea for 37 days in 1988.
>
> **When and where:** Left Vietnam by boat in 1988. Brought ashore at Bolinao, in the Philippines. Later settled in Orange County, California.
>
> **Movie:** *Bolinao 52* (2008), a documentary directed by Duc Nguyen. It won two regional Emmy awards in 2009.

**More than 20 ships passed the boat, and one stopped, then left.**

Tung Trinh was one of 110 people on a small boat that left Vietnam in 1988. The boat's engine stopped working, and the boat drifted at sea for 37 days.

More than 20 ships passed the boat during those days. One of them, the USS Dubuque, a ship of the United States Navy, stopped on June 10, 1988. The ship's commanding officer ordered food, water and sea charts given to the people on the boat. The sailors guessed 50 to 70 people were on the boat, not 110. Then the Dubuque left, and the boat stayed adrift.

As many as 58 of the 110 people on board died. An estimated 20 had died before the Dubuque came, and the others died after it left. During the drift, some of the people on the boat ate human flesh to stay alive, which is called cannibalism.

**The captain.** Navy leaders removed the Dubuque's commanding officer from his command on August 11, 1988. At his own request, he was tried by a military court. Its officers found him guilty of breaking orders to help people in danger at sea, and he received a letter of reprimand, a written scolding.

Filipino fishermen found the boat and brought the 52 survivors to Bolinao, in the Philippines. Tung Trinh later came to the United States and settled in Orange County, California.

### Sergey Brin

> **Who:** A Jewish boy from Moscow whose family left the Soviet Union in 1979. In 1998 he started Google with Larry Page.
>
> **When and where:** Born 1973 in Moscow. Arrived in the United States October 25, 1979, at six.

**He left Moscow at six and later started Google with Larry Page.**

Sergey Brin was born in 1973 in Moscow, the capital of the Soviet Union, a communist country where the government owned the businesses and only one party was allowed. His family was Jewish. In the Soviet Union his parents were held back in their careers and harassed because they were Jews. The accounts of his life do not name the people who did it.

The family got permission to leave in 1979. About 51,000 Soviet Jews left that year, the most in any single year. In the United States his father, Michael, taught mathematics at the University of Maryland. His mother, Eugenia, became a researcher at NASA, the US space agency. In 1998 Sergey and Larry Page started the company Google.

### The 1986 law

President Ronald Reagan signed the Immigration Reform and Control Act, called IRCA, on November 6, 1986. About 2.7 million people who had lived in the country for years without legal permission got legal status under it. To qualify, they had to show they had lived in the country without a break since before 1982. Certain farmworkers could also qualify.

Under the same law, officials could for the first time punish employers who knowingly hired workers without legal permission. These punishments are called employer sanctions. After 1986 the number of people living in the country without legal permission grew again.

**If you remember one thing:** After lawmakers ended the quotas in 1965, the main sources of newcomers shifted from Europe to Asia, Latin America, Africa and the Caribbean.

**The question this era leaves open:** Which countries would send the most people once the quotas were gone? The 2023 count in the next era gives the answer.

**Next:** After 2000 the share of people born abroad climbed to its highest since 1910, and new federal agencies took over immigration.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 15 minutes**

The share of people here who were born in another country rose almost to its highest ever, and federal officers held more people in immigration detention than ever before. About 47.8 million people living in the United States in 2023 had been born in another country, by the Census Bureau's count. That was 14.3 percent of the population, the highest share since 1910. More of them came from Mexico than from any other country.

Attorney General Jeff Sessions announced a "zero tolerance" policy in April 2018, during President Donald Trump's first term: every adult who crossed the border illegally was to be charged with a crime. Border Patrol agents then took thousands of children from their parents. The US Border Patrol counted 895 migrant deaths along the border with Mexico in the year ending September 2022, the most on record. In January 2026 immigration officers held more than 71,000 people in detention, the most ever, according to a report by two human rights groups.

### Who comes now

About 11 million of the immigrants living here in 2023 were born in Mexico, 22 of every 100, Pew Research Center researchers found. Immigration from Mexico has slowed since about 2007.

India came next with 3.2 million, then China with 3 million, the Philippines with 2.1 million and Cuba with 1.7 million. Counted by region, about 52 of every 100 immigrants were born in Latin America and 27 of every 100 in Asia.

The number of immigrants from Africa south of the Sahara Desert roughly tripled from 2000 to about 2.5 million in 2024, the Migration Policy Institute found. Communities of people born in Jamaica, Haiti, the Dominican Republic and other Caribbean countries also grew.

The share of people born abroad, 14.3 percent in 2023 by the Census Bureau's count, came close to the record of 14.8 percent, set in 1890. The lowest share was 4.7 percent, in 1970.

Pew and the Department of Homeland Security both publish estimates of how many people live in the country without legal permission. Their estimates reached about 12 million in 2007, then fell to about 11 million, and rose again in the 2020s. The estimates are uncertain.

### Homeland Security and DACA

Hijackers from the group al-Qaeda flew planes into the World Trade Center in New York and the Pentagon near Washington on September 11, 2001, and a fourth plane crashed in Pennsylvania. They killed 2,977 people.

**A new department.** After those attacks, members of Congress passed the Homeland Security Act of 2002. With it, lawmakers created the Department of Homeland Security, called DHS, which began work in 2003. They ended the old Immigration and Naturalization Service and split its work among three new agencies inside DHS.

Officers of Immigration and Customs Enforcement, called ICE, arrest and hold immigrants inside the country. Officers of Customs and Border Protection, called CBP, work at the borders, and the Border Patrol is part of CBP. Staff of the third agency, US Citizenship and Immigration Services, took over the government's other immigration work, such as handling requests to become a citizen.

**DACA.** Janet Napolitano, the Secretary of Homeland Security, created DACA, short for Deferred Action for Childhood Arrivals, on June 15, 2012. President Barack Obama spoke about it at the White House that day. Under DACA, some people who were brought to the country as children can apply to have their removal from the country deferred, or put off, and to work legally.

Lawyers and judges have fought over DACA in court again and again. In September 2017, in President Donald Trump's first term, Sessions advised ending it, and Elaine Duke, the acting Secretary of Homeland Security, ended it. On June 18, 2020, the justices of the Supreme Court ruled that the way officials had ended DACA broke federal law, so DACA stayed.

A federal appeals court ruled on January 17, 2025, that its work permits were unlawful and limited that ruling to Texas. About 455,000 people held DACA status on March 31, 2026, according to the National Immigration Forum, an immigrant rights group, using figures from US Citizenship and Immigration Services.

### Deaths at the border

Every year hundreds of migrants die trying to cross from Mexico into the United States. People die of heat and thirst in the desert, drown in the Rio Grande, or die during or after chases by Border Patrol agents. Some die in custody, meaning while officers are holding them. Investigators inside CBP counted 171 deaths in the 2022 budget year in which CBP officers were involved "in some way," and 52 of those people died in CBP custody.

**Two counts.** Border Patrol officials and the staff of the International Organization for Migration (IOM), a United Nations agency, count these deaths in different ways. For 2022, Border Patrol officials counted 895 deaths along the border in the federal budget year, which runs from October to September. IOM staff counted 686 deaths and disappearances there in 2022. They call their figures minimums, because Texas county coroners, the officials who look into deaths, and Mexican search teams do not report every death to them.

Auditors at the Government Accountability Office, which checks federal agencies for Congress, found in 2022 that Border Patrol officials had left out deaths found by sheriffs, by medical examiners, the doctors who find out why a person died, and by other agencies. The auditors later reported that Border Patrol officials had made the changes they asked for. In a report of April 2025, the same auditors gave 704 deaths and more than 5,800 rescues for 2023.

Border Patrol officials' yearly counts were 281 in 2018, 300 in 2019, 254 in 2020, 568 in 2021 and 895 in 2022. The 2022 count is the highest on record, more than three times the count for 2018.

IOM staff called the US-Mexico border "the world's deadliest migration land route." Of the 686 people they counted there in 2022, 307 died crossing the Sonoran and Chihuahuan deserts, most of them from heat.

For 2025, IOM staff counted 409 migrant deaths in all of North and South America, the lowest count since 2014. They linked the drop to fewer people trying to cross the US-Mexico border and the Darién, a jungle between Colombia and Panama. In February 2026 they said the 2025 figures would not be final until the middle of 2026.

### Children taken from their parents, 2018

**Zero tolerance.** Attorney General Jeff Sessions, the head of the Justice Department, announced a "zero tolerance" policy on April 6, 2018. He told federal prosecutors along the southwest border to charge with a crime every adult whom DHS officers sent to them for crossing the border illegally. That included parents who came with their children. Officers sent the parents to jail to face criminal charges, and Border Patrol agents took their children away from them.

**The memo.** Kirstjen Nielsen, the Secretary of Homeland Security, approved a plan on May 4, 2018, to send every adult caught crossing illegally to be charged with a crime, parents included. Sessions had urged her to approve it. The plan came from a memo of April 23, 2018, signed by the heads of three agencies inside DHS: Kevin K. McAleenan of CBP, Thomas Homan, the acting head of ICE, and L. Francis Cissna of US Citizenship and Immigration Services. It covered adults "initially arriving or apprehended (caught) with minors (children)."

Border Patrol leaders told their commanders along the Mexican border to begin on May 5. McAleenan left out parents with children under five who were crossing illegally for the first time. Agents asked a federal refugee office to take each child, and ICE officers held the parents. In a later court case, government lawyers wrote that there was "no prescribed specific course of action for reunification." That means no one had set a plan for putting the families back together.

Sessions said in a speech on May 7, 2018, "If you are smuggling a child, then we will prosecute you and that child will be separated from you as required by law." Officials had already separated about 280 families in 2017, under a trial program in El Paso, Texas.

**What the inspector general found.** Michael Horowitz, the Justice Department's inspector general, an official who checks the work of a government department, later investigated. In January 2021 Horowitz reported that Sessions and a small number of other Justice Department officials knew, when the policy was issued in April 2018, that DHS "would change its long-standing practice" and separate families. He found that the Attorney General's office "was a driving force" in that change.

He also wrote that the department's "single-minded focus on increasing immigration prosecutions came at the expense of careful and appropriate consideration of the impact of child separations."

**The count of the children.** Officials deported hundreds of parents without their children before a federal judge ordered the government to put the families back together in June 2018. The counts of the children differ because each one includes a different group of children.

**Taken.** President Joe Biden set up the Family Reunification Task Force in February 2021. Its staff counted 3,924 children taken from their parents between January 20, 2017, and January 20, 2021.

**Back together, and still apart.** By February 1, 2023, 2,926 of those children had been reunited with their families. Most were reunited before the task force began, and more than 600 through its work. The other 998 were still apart, and task force staff said the true number still apart was "likely greater than 1,000."

**Covered by the lawsuit.** A federal judge approved a settlement, an agreement that ends a lawsuit, on December 11, 2023, in a lawsuit brought by the American Civil Liberties Union called *Ms. L. v. ICE*. It covers an estimated 4,500 to 5,000 children and their parents. By March 20, 2024, task force staff had confirmed 1,120 separated children as part of that group. No final count of children returned to their parents is on record. As of September 2026, no record shows that any official had been charged for the separations.

### Arrests, detention and deportation, 2025 and 2026

Chief Justice John G. Roberts Jr. swore in Donald Trump as president for a second term on January 20, 2025, in the Rotunda, the round central hall of the US Capitol. A year later, in January 2026, ICE officers held more than 71,000 people in detention, in custody while officials decided whether to deport them. It was a record.

Human Rights Watch and Physicians for Human Rights gave that figure in a report of June 25, 2026. ABC News reported on July 21, 2026, that ICE officers held 65,765 people, citing figures ICE had posted.

**Deaths in custody.** The same report counted 52 people who died in ICE custody from January 20, 2025, to June 4, 2026. Thirty-nine of them died in the first year. Of those 39, seven were apparent suicides, meaning they appeared to have killed themselves, and five died of injuries. The others died of strokes, heart failure, long-term illness and failure to breathe. The yearly death rate reached about 8.4 for every 10,000 people held, which the report describes as "nearly four times" the rate under the previous president, Joe Biden.

The report lists how each of the five died of injuries. One was Silverio Villegas González, whom an ICE officer shot during an arrest near Chicago. His death is told below, with the other shootings. On September 24, 2025, a gunman fired on a van of detainees at the ICE office in Dallas, Texas. Two of the men in the van died of their wounds. Norlan Guzmán-Fuentes of El Salvador died that day, and Miguel Ángel García-Hernández of Mexico died on September 30. The gunman, Joshua Jahn, 29, shot and killed himself, NBC News reported.

José Castro-Rivera of Honduras, 24, ran into traffic in Virginia on October 23 while ICE officers chased him to arrest him. A vehicle hit and killed him, and the report does not name the driver.

**Camp East Montana.** Geraldo Lunas Campos, 55, from Cuba, died on January 3, 2026, inside Camp East Montana, an ICE camp at Fort Bliss in El Paso, Texas. The El Paso County medical examiner ruled his death a homicide, the El Paso TV station KFOX14 reported. On a death record, homicide means that another person caused the death. The ruling is not a finding that anyone broke the law.

The medical examiner found that pressure on his neck and torso, the middle of his body, kept him from breathing. The human rights groups' report states that the pressure came from force that ICE staff used on him. In a later death report of their own, ICE officials said he had tried to harm himself and that staff used force to stop him. The report names none of the staff involved.

**Removals.** Removal is the government's word for deportation. ABC News reported that ICE had posted 356,389 removals in the 2026 budget year through about July 21, 2026. For the 2025 budget year, the immigration researcher Austin Kocher counted about 329,018 ICE removals.

DHS officials claimed on January 20, 2026, "more than 675,000 deportations" and "an estimated 2.2 million self-deportations" in the year since January 20, 2025. Self-deportation means leaving the country on one's own, without being deported by officers. Kocher notes that DHS officials have not published how they count these numbers. He found that ICE's own removals made up only about 54 percent of an earlier DHS claim of 605,000. In the year after January 20, 2025, DHS officials counted 90,084 people caught along the southwest border.

**Shootings.** Federal immigration officers shot and killed at least four people from January 2025 to late January 2026, PBS NewsHour reported. Three of them were Silverio Villegas González, Renée Nicole Good and Alex Pretti.

Villegas González was a citizen of Mexico. ICE officers stopped his car in Franklin Park, a suburb of Chicago, on September 12, 2025, just after he had dropped his children at school. One officer shot him in the neck, and he died.

DHS officials said that Villegas González drove his car at officers and dragged one of them, and that the officer fired "fearing for his own life." In body-camera video, an agent described his own injuries as "nothing major." Federal officials have not released the name of the officer who shot him, and federal prosecutors declined to charge that officer.

Investigators of the Illinois State Police opened their own case in spring 2026, at the request of the Franklin Park police. It was still open in September 2026, the Chicago Sun-Times and WBEZ reported.

ICE officer Jonathan Ross shot Renée Nicole Good, a US citizen, in Minneapolis on January 7, 2026. CBP officers shot Alex Pretti in Minneapolis on January 24, 2026. As of the PBS NewsHour report, no officer had been charged in either death.

### Giannis Antetokounmpo

> **Who:** A basketball player born in Greece to Nigerian parents. He grew up a citizen of no country and came to the United States when a National Basketball Association (NBA) team picked him in 2013.
>
> **When and where:** Born December 6, 1994, in Athens, Greece. Came to the United States in 2013, at 18, to play for the Milwaukee Bucks.
>
> **Movie:** *Rise* (2022), a Disney+ drama about the Antetokounmpo family, made with the family. It is a dramatization, not a documentary.

**As boys in Greece, he and his brothers sold goods on the street.**

Giannis Antetokounmpo's parents, Charles and Veronica, were immigrants from Nigeria with no legal status in Greece. Giannis was born in Athens and grew up stateless, which means no country counted him as its citizen. Under Greek law, a child does not become a citizen just by being born in Greece. In the United States, the 1898 ruling in Wong Kim Ark's case makes any child born in the country a citizen. As boys, Giannis and his brothers sold goods on the street.

Greek officials made him a citizen in 2013. A few weeks later, in June 2013, the managers of the Milwaukee Bucks picked him 15th in the NBA draft, the yearly event in which teams choose new players, and he came to the United States at 18 to play for them. He was named the league's Most Valuable Player in 2019 and in 2020. In 2021 he won the NBA championship with the Bucks and was named the most valuable player of the finals. His parents and brothers joined him in the United States.

### Peter Dut and Santino Chuor, Lost Boys of Sudan

> **Who:** Two Dinka teenagers whose parents were killed when government forces attacked their villages in Sudan's civil war. They lived for years in a refugee camp in Kenya. They were among the "Lost Boys" resettled in the United States.
>
> **When and where:** From Sudan. Kakuma refugee camp, Kenya. Houston, Texas, in their first year in the United States, during the resettlement that began in 2001.
>
> **Movie:** *Lost Boys of Sudan* (2003), a documentary that records the lives of these two young men. Megan Mylan and Jon Shenk made it. It was nominated for an Emmy and won the Truer Than Fiction Award at the Independent Spirit Awards.

**They walked out of Sudan and spent years in a camp in Kenya.**

Peter Nyarol Dut and Santino Majok Chuor were Dinka, an ethnic group of southern Sudan. Sudan's civil war was a war inside one country, between the government in the north and rebels in the south. Military forces of the central government attacked the boys' villages, destroyed them and killed their families, according to the notes for the PBS film about them. Those notes do not state which soldiers or fighters killed each boy's parents.

**The militias.** Researchers at Human Rights Watch report that in these years Sudan's rulers gave modern weapons to militias, armed groups outside the regular army, called the muraheleen. The militia fighters burned Dinka villages, stole cattle and food, and carried off women and children as slaves. Human Rights Watch does not say that these militias attacked the two boys' own villages.

The rebel army of the south, the Sudan People's Liberation Army, also took many of the older Lost Boys as soldiers. The two boys survived a long walk out of Sudan and then spent years in Kakuma, a refugee camp in Kenya.

Starting in 2001, about 4,000 of these young refugees from Sudan were resettled in the United States. People called them the "Lost Boys of Sudan," and Peter and Santino were among them. The documentary records their first year in the United States, which began in Houston. After a time, Peter left Houston for Kansas to go to high school.

**The three questions, answered**

- Why did people leave home to come here? Many came for land and work, like the Germans who farmed the Midwest and the Chinese who built the western railroad, or to worship in their own way, like the Puritans. Others ran from danger: the Irish famine, the pogroms against Jews in the Russian Empire, the Nazis, and wars in Vietnam and Sudan.
- Who did Americans try to keep out, and how? Lawmakers shut out Chinese workers in 1882 and almost everyone from Asia in 1924, and they cut the number of southern and eastern Europeans with quotas. Mobs burned Catholic churches in Philadelphia and drove Chinese people out of Eureka and Tacoma. Officials pushed hundreds of thousands of people of Mexican descent, many of them citizens, across the border in the 1930s and again in 1954. In 2018 agents took thousands of children from their parents at the border, and in January 2026 officers held more than 71,000 people in detention, the most ever.
- Who could become a citizen, and how did that change? In 1790 only "a free white person" could become a citizen. In 1870 members of Congress added people of African birth or descent. In 1898 the Supreme Court ruled in Wong Kim Ark's case that anyone born here is a citizen, and in 1952 members of Congress removed the limit to white people.

**What changed:** In 1500 no one from across the ocean had come to stay, and by 2023 about 47.8 million people living in the United States had been born in another country.

**Five dates to keep**

- September 8, 1565: Menéndez founds St. Augustine, the oldest European town on the US mainland.
- 1790: Members of Congress limit citizenship to free white people.
- May 6, 1882: President Arthur signs the Chinese Exclusion Act.
- May 26, 1924: President Coolidge signs the quota law.
- 1965: lawmakers end the national-origins quotas.

**Not known:** No one knows how many Chinese workers died building the railroad, and the estimates run from about 100 to the thousands.

**Where to go:** Ellis Island, in New York Harbor, where about 12 million immigrants came through from 1892 to 1954 and a statue of Annie Moore stands.

**Next:** Chapter 5, Migration Across America. It asks how people moved, and were moved, across the land once they were here.
