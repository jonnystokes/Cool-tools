# Chapter 23: America and the World

**Chapter 23 of 37 · America and the World · 10 eras · about 90 minutes**

**From 1494 to today, people far away decided who would rule this land and its islands, and the people living there almost never got to choose.**

Native Hawaiians put 21,269 signatures on a petition against letting the United States take their islands. They signed at meetings on all five main islands between September 11 and October 2, 1897. The signers were more than half of the Native Hawaiians counted that year. Four men carried the petition to Washington, and the treaty to take Hawaii failed. In July 1898 members of Congress took the islands anyway, by a method that did not need the votes the Hawaiians had blocked.

This chapter follows America's dealings with other countries, from a line drawn across the Atlantic in 1494 to the five territories of today. For the first four eras there was no United States, and rulers in Europe traded this land among themselves. In 1775 the new country started out weak. Its leaders needed France's help, and for years they could not free American sailors enslaved in Algiers. Then watch American leaders become the ones deciding for others, from the land taken from Mexico to the elected governments they helped overthrow after 1950. In every era, watch who was in the room when a deal was signed, and who was left out.

**Three questions this chapter answers**

- Who got to choose when this land and its islands changed hands?
- How did a weak new country come to rule islands and overthrow governments?
- Are the people of the territories American citizens?

**Five minutes?** Read the Hawaii sections of 1850 to 1900, from "Hawaii: a kingdom overthrown, 1887 to 1893" through "21,269 names against annexation, 1897".

**Can skip:** "Trade laws made in London", "A committee for secret letters, 1775 to 1789", "Perry's warships in Japan, 1853 and 1854", "Trade and the climate agreement". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 2 minutes**

Native nations on this land made alliances, promises to stand together against their enemies, long before any European arrived. Their leaders met in councils and gave gifts to seal an agreement. No Native diplomat, a person sent to speak and bargain for a nation, is known by name from the years before the Europeans came. There was no United States yet. American leaders declared independence in 1776, 276 years after 1500.

Far out in the Pacific Ocean, Polynesian voyagers, people of the many islands of the central and southern Pacific, sailed to the islands now called Hawaii and settled them. Then, in 1494, the rulers of Spain and Portugal signed a treaty, a written agreement between countries, that split the lands across the Atlantic between their two kingdoms.

### When did people first reach Hawaii?

Polynesian voyagers were the first people to live on the islands of Hawaii. Scientists using revised radiocarbon dating, a way of measuring the age of old wood, bone and charcoal, now put their landing at about the years 1000 to 1200.

Older estimates were much earlier. For a long time most archaeologists, scientists who study the past through the things people left behind, put the first landing between about the year 300 and the year 750. Some newer studies put it a little later, between about 1200 and 1290.

Only one early home site in the islands has been dated with confidence, the Bellows Beach site at Waimānalo, on the island of Oʻahu. The argument over the first date is still open.

### A line drawn at Tordesillas, 1494

The rulers of Spain and Portugal divided the lands across the Atlantic between them in a treaty signed in the Spanish town of Tordesillas on June 7, 1494. King Ferdinand II of Aragon and Queen Isabella I of Castile signed for Spain. King John II signed for Portugal.

The treaty described a line running from the North Pole to the South Pole, 370 leagues, or about 1,185 miles, west of the Cape Verde Islands in the Atlantic Ocean. The king of Portugal could claim new lands east of the line. The king and queen of Spain could claim new lands west of it.

Millions of people lived in the Americas, on the land these three rulers had divided. The rulers had never seen it. None of the people who lived there was at Tordesillas, and the rulers did not ask them or tell them.

## The 1500s

**Era 2 of 10 · The 1500s · about 1 minute**

Kings in Spain, Portugal, France and England claimed land on this side of the ocean from their capitals in Europe. French Protestants, Christians who had broken away from the Catholic Church, built a fort in Florida, on land the king of Spain claimed. Spanish soldiers settled the matter in 1565 by killing hundreds of French soldiers and sailors on the Florida coast. Most of the dead had already surrendered or been captured.

### Fort Caroline and Matanzas, 1565

Fort Caroline, the French fort, stood in the homeland of peoples who spoke the Timucua language. No French or Spanish leader asked them about it.

**The king's contract.** King Philip II of Spain made a contract in 1565 with Pedro Menéndez de Avilés, a Spanish commander. Under it, Menéndez was to settle Florida and drive the French out of their fort. Menéndez arrived in August. In his own words, he came "to plant the Gospel in these parts," which meant spreading his Catholic faith there.

**The killings.** Menéndez's soldiers took Fort Caroline on September 20, 1565. By his own count they cut the throats of 132 men there and killed 10 more the next day, and he sent about 50 women and children by ship to Havana. Timucua people told him where shipwrecked French sailors had come ashore. At that inlet, a narrow arm of the sea south of St. Augustine, his soldiers killed about 245 Frenchmen who had surrendered, among them the French commander, Jean Ribault. Chapter 22, War and the Military, tells the killings in full.

Menéndez wrote to King Philip that punishing the French this way was "serving God Our Lord, and Your Majesty," because they were Protestants. The inlet is still called Matanzas, the Spanish word for slaughters.

## The 1600s

**Era 3 of 10 · The 1600s · about 3 minutes**

New Netherland, the Dutch colony on Lenape land, changed hands three times in ten years. English forces took it in 1664, Dutch forces took it back in 1673, and in 1674 Dutch diplomats handed it to England again.

The colonies on this coast belonged to England, the Dutch Republic, France and Spain. Officials in London, Amsterdam, Paris and Madrid set each colony's borders, chose its wars and decided who it could trade with. Colonists had no ambassadors, officials sent to live in another country and speak for their own, and they could not sign treaties in their own names.

### Trade laws made in London

Members of Parliament, England's lawmakers in London, decided what English colonists could buy and sell. They did it through a series of laws called the Navigation Acts.

They aimed the first act, in 1651, mainly at Dutch merchants. It required all trade between England and its colonies to travel in English or colonial ships, and it was one of the causes of a war at sea that English and Dutch sailors began fighting in 1652. The act of 1660 listed goods that colonists could ship only to England or to another English colony: sugar, tobacco, cotton, wool, ginger and indigo, a plant used to make blue dye.

Under the Staple Act of 1663, European goods bound for the colonies had to land in England first. Customs officers there, who collected the taxes on goods coming in, checked them, and then merchants shipped the goods on. Under these laws, merchants in Boston could not legally buy rope from Dutch traders or sell tobacco to French ones.

### Dutch diplomats gave up New Netherland for a nutmeg island

The Dutch colony of New Netherland stood on the homeland of the Lenape people, which they call Lenapehoking. It covered what is now New York City, parts of Long Island and the Hudson Valley, New Jersey, northeastern Delaware and eastern Pennsylvania.

**Mannahatta.** Dutch colonists said they had bought the island of Mannahatta in 1626 for trade goods worth 60 guilders, the Dutch money of the time. The Dutch most likely misread what the Lenape meant by the exchange. Diseases that the colonists brought cut the number of Lenape people by 85 percent by 1700.

An English fleet arrived at New Amsterdam, the colony's main town, in 1664, and the Dutch surrendered the colony without a fight. Accounts give different days for the surrender because the English and the Dutch used different calendars at the time.

**The trade.** English and Dutch diplomats ended their war with the Treaty of Breda, signed on July 21, 1667. No Lenape leader took part. The Dutch had done better in the fighting, but the Dutch men who bargained at Breda let England keep New Netherland. In return the Dutch took Suriname and Run, an island in what is now Indonesia where nutmeg grew. Suriname had sugar plantations, large farms where the planters forced enslaved people to do the work.

Dutch forces sailed in during a third war, in August 1673, took the colony back and renamed its main town New Orange. Under the Treaty of Westminster, signed on February 19, 1674, Dutch diplomats handed the colony back to England, and it stayed English. By then the English called it New York.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 4 minutes**

New England soldiers captured a French fortress in 1745, and three years later British diplomats gave it back without asking them. Colonists lived under the rule of the king of Britain, France or Spain. When their king went to war, they were at war too, and they had no say in the peace terms.

Native nations made treaties with English and French officials in their own names. In the summer of 1701 the Haudenosaunee, a league of five Native nations in what is now New York, made two agreements about two weeks apart, one with the English and one with the French.

### Two agreements in the summer of 1701

**At Albany.** Haudenosaunee representatives met the acting English governor of New York at Albany on July 19, 1701. The English called them the Five Nations. They made a deed, a signed paper that hands over land or rights to land, to King William of England. It was about hunting lands that ran west from what is now western New York toward what is now Chicago.

People still argue over what the Haudenosaunee kept and what they gave up in that deed. Its English text states that they handed the land to the king, and that he would protect their "free hunting" there forever. Haudenosaunee groups read it as protecting their right to hunt there.

**The raccoon case.** In Canada, government lawyers argued against that reading in a court case. In 1987 Ontario officials charged Jesse Ireland and David Jamieson, two men of the Oneida, one of the five Haudenosaunee nations, with hunting raccoons without a license in southern Ontario, inside the area the deed describes.

The government lawyers said the hunting promise counted only if the English and the Haudenosaunee won the land back from the French and their Native allies, and that never happened. In 1990 an Ontario judge rejected that argument and ruled that the two men had a right under the deed to hunt there.

**At Montréal.** About two weeks after the Albany meeting, on August 4, 1701, the governor of New France, the French colony in North America, signed a peace at Montréal with about 1,300 representatives of 39 Native nations. It is called the Great Peace of Montréal, and with it the French and the Native nations ended decades of war.

French officials meant the peace to keep the Five Nations neutral, taking neither side, if the French and the English colonists went to war. The Haudenosaunee kept out of the next war between France and Britain.

### Kondiaronk

> **Who:** A Huron-Wendat chief who argued for the Great Peace of Montréal while he was dying of a fever. The French called him "the Rat."
>
> **When and where:** Montréal, August 1701. Born around 1649.

**He spoke for peace on August 1 and died within hours.**

Kondiaronk was a chief of the Huron-Wendat people. The French nicknamed him "the Rat" for the tricks he used when he bargained.

A disease was spreading through Montréal while the great council met, and Kondiaronk caught it. On August 1, 1701, weak with fever, he spoke to the council and pushed the leaders toward agreement. Afterward he was carried to the Hôtel-Dieu, a hospital in the town, and he died a few hours later. Accounts give his death as August 1 or August 2.

The governor of Montréal, French officers, war chiefs and priests walked in the procession at his large funeral on August 3, and he was buried at the town's Notre-Dame church. The Great Peace of Montréal was signed the next day, August 4, 1701.

### What British diplomats won at Utrecht, 1713

In the Treaty of Utrecht, British diplomats won a contract to ship kidnapped African people across the ocean and sell them as slaves. The treaty was signed on April 11, 1713, at Utrecht in the Netherlands. With it the diplomats ended a war in Europe that the colonists called Queen Anne's War.

Under the contract, called the asiento, British traders had the only right for thirty years to carry enslaved Black people into Spain's colonies in the Americas and sell them there. The diplomats wrote the asiento into the peace as one of Britain's prizes, beside land.

The land came from France. French diplomats signed over three things to Britain: all the land whose rivers drain into Hudson Bay, France's claims to Newfoundland, and Acadia, a French colony on the Atlantic coast of what is now Canada. A New England force had taken Acadia's capital, Port-Royal, in 1710.

### Louisbourg, taken in 1745 and given back in 1748

New England soldiers under Colonel William Pepperrell sailed from Boston on March 24, 1745, to take Louisbourg, a French fortress on Cape Breton Island. With British warships offshore, they laid siege to it, surrounding it and cutting it off, and the French surrendered on June 17, 1745, after 49 days.

**The cost.** Far more of the New Englanders died holding the fortress than taking it. In June 1746 Pepperrell estimated that about 1,200 of his men had died, most of them of disease in the fortress that winter. Chapter 22, War and the Military, tells the siege and that winter in full.

**Given back.** British diplomats gave Louisbourg back to France in 1748, in the Treaty of Aix-la-Chapelle. In exchange French diplomats gave back Madras, a city in India that French forces had taken from Britain. British officials did not ask the colonists, and New Englanders were furious.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 15 minutes**

In the middle of their war for independence, American leaders looked in secret for anyone abroad who would help them fight Britain. They started in November 1775. French and American diplomats signed an alliance in 1778, and in 1783 American diplomats in Paris signed the peace that ended the war.

**Weak after the war.** The new country had almost no navy and little money. Rulers in North Africa seized American ships, and their officials enslaved the crews. When the French and the British went to war with each other in the 1790s, American leaders tried to keep out of it. President Washington accepted a treaty that favored Britain because he judged the country too weak to fight the British. From 1798 to 1800 American sailors fought an undeclared war at sea against France.

### A committee for secret letters, 1775 to 1789

Members of the Second Continental Congress, the meeting of delegates each colony chose to speak for it, set up the Committee of Secret Correspondence on November 29, 1775. The committee's job was to make secret contact with people in other countries who might help. Its first five members included Benjamin Franklin and John Jay.

The delegates renamed it the Committee for Foreign Affairs on April 17, 1777. Later they set up a Department of Foreign Affairs. Accounts disagree on whether that happened on January 10, 1780, or January 10, 1781. On August 10, 1781, they chose Robert R. Livingston of New York as the first Secretary for Foreign Affairs.

Under the new Constitution, members of Congress set up the department again in a law of July 27, 1789. In a second law, on September 15, 1789, they renamed it the Department of State, because they had given it record-keeping work at home on top of foreign affairs. It still has that name.

### Which country recognized the United States first?

Sultan Mohammed III, the ruler of Morocco, was the first ruler of any country to recognize the United States, or accept officially that it existed, in Encyclopaedia Britannica's account. On December 20, 1777, he declared that ships flying the American flag could enter Moroccan ports freely. That was about six weeks before French officials signed their treaties with the Americans.

His declaration named ships of several other nations too. It was part of his plan to trade in peace with Christian countries, and he did not aim it at the Americans alone.

A treaty with Morocco followed nine years later. The American agent Thomas Barclay signed it at Marrakesh on June 28, 1786. Thomas Jefferson and John Adams added their signatures in Paris and London, and delegates to Congress ratified it, giving it final approval, in July 1787.

It was the first treaty American officials made with an African country or a Muslim one. Officials of the two countries rewrote parts of it in 1836 (some accounts say 1837), and it is still in force. No other treaty relationship in United States history has lasted as long without a break.

### What it took to win over France, 1778

France's foreign minister, the Comte de Vergennes, a French nobleman, agreed to an alliance only after the Americans won a major battle. Benjamin Franklin sailed to France in late 1776. His ship reached Auray, in Brittany, on December 3 or 4, 1776, and he was in Paris by December 21. He, Silas Deane and Arthur Lee were the American commissioners, the men sent to bargain for the United States.

**Saratoga.** A British army surrendered to American forces after the Battle of Saratoga, in New York. The State Department's own historians write that Vergennes "finally decided in favor of an alliance" when that news reached him in December 1777.

**Two treaties.** American and French diplomats signed two treaties on February 6, 1778. In the Treaty of Amity and Commerce, a treaty of friendship and trade, the French formally recognized American independence. In the Treaty of Alliance, the two sides promised that neither would make peace with Britain without the other. A secret section stated that other countries in Europe could join.

Spain's leaders took their country into the war against Britain on June 21, 1779, as France's ally. They did not sign a treaty with the United States, and they did not recognize American independence during the war.

### Benjamin Franklin

> **Who:** The American who spoke for his country in France for more than eight years, and one of the three Americans who made the peace with Britain.
>
> **When and where:** Paris, December 1776 to May 1785.
>
> **Movie:** *Franklin* (2024), an eight-part drama series on Apple TV+, with Michael Douglas as Franklin. It is about his time in France and is based on Stacy Schiff's book *A Great Improvisation*. It is a drama, not a documentary.

**In Paris, Franklin wore a fur cap instead of a wig.**

His biographer Walter Isaacson identifies the fur as marten. Franklin wore plain clothes too, and the French took the cap as a sign that he was a plain, rugged American. Augustin de Saint-Aubin made an engraving of Franklin in the cap in 1777, and the print is in the Philadelphia Museum of Art.

Franklin represented the United States in France from December 1776 to May 1785, first as one of the commissioners and then as minister. Delegates to Congress named him Minister Plenipotentiary to France in 1778, a title meaning he had full power to act for his country there. He presented his credentials, the letters that proved his position, to the French government the next spring.

The delegates also named him minister to Sweden, in 1782. Franklin never went to Sweden, but he worked out a treaty with it from Paris and signed it in April 1783. In the same years he was one of the three Americans who made the peace with Britain. His mission in France ended in May 1785.

### What British diplomats signed away in 1783

In the Treaty of Paris, British diplomats accepted that the United States was independent. They also handed the United States Britain's claim to land that Native nations lived on.

Benjamin Franklin, John Adams and John Jay bargained for the United States, and they signed the Treaty of Paris on September 3, 1783.

Under the treaty, the British accepted a western border for the United States at the Mississippi River. Americans could fish off Newfoundland, and British lenders could still collect the debts Americans had owed them since before the war. The American side promised Loyalists, colonists who had sided with Britain, payment for property that Americans had taken from them. British troops had to leave the thirteen states. Franklin asked the British to hand over Canada as well, and they refused.

The treaty took effect in 1784, after delegates to the Confederation Congress, meeting at Annapolis, Maryland, and British officials had both approved it.

**Not invited.** No Native nation was invited to Paris, though the land inside that western border was their home. Among them were the Haudenosaunee in what is now New York and Pennsylvania. The Tuscarora had joined their league in about 1722, and after that it was called the Six Nations: the Mohawk, Oneida, Onondaga, Cayuga, Seneca and Tuscarora.

The British king had set aside much of that land for Native nations in 1763, in a royal order called the Royal Proclamation. In 1783 British diplomats handed it to the United States, and they ignored many earlier British treaties with Native nations.

At Fort Stanwix in 1784, American officials backed by a strong force of soldiers treated the Six Nations as nations they had beaten in war, and they took huge parts of Six Nations land.

### John Adams

> **Who:** The first American minister to Great Britain, sent to the king he had rebelled against.
>
> **When and where:** London. Presented to King George III on June 1, 1785.

**In 1785 Adams met the king who had called the colonies rebels.**

Adams met the king as the representative of the United States on June 1, 1785. Nearly ten years earlier, in August 1775, the same king had declared the colonies to be in open rebellion against him, and the next year Adams signed the Declaration of Independence.

Two days after the meeting, on June 3, 1785, Adams wrote to Thomas Jefferson that the king had received him with more kindness than he had expected. The Library of Congress holds that letter.

**By 1786:** British diplomats had accepted American independence, and John Adams was the first American minister in London. The alliance with France, signed in 1778, was still in force.

### Americans enslaved in Algiers, 1785 to 1796

Officials of the ruler of Algiers held American sailors as slaves from 1785 to 1796, and American leaders could not free them. Algiers, Tunis, Tripoli and Morocco, called the Barbary states, were states on the coast of North Africa. Many of their rulers sent armed ships to seize the ships of weaker countries, to make those countries pay them for safe passage, and they held the captured sailors for ransom.

Moroccan ships seized an American merchant ship in 1784, and a treaty with Morocco followed in 1786. In 1785 Muhammad, the Dey, or ruler, of Algiers, declared war on the United States, and his ships captured several American ships.

**A Boston ship.** An Algerian warship took the Boston ship *Maria* about three miles off Cape St. Vincent, in Portugal, on July 25, 1785. The *Maria* reached Algiers on August 4, and the Dey's officials enslaved its crew. More American crews followed.

American leaders had almost no navy and very little money. They could not free the sailors by force, and for years they could not pay what the Dey asked for them. In 1795 they sent Joel Barlow, Joseph Donaldson and Richard O'Brien to North Africa, and the three men made treaties with Algiers, Tunis and Tripoli. The treaty with Algiers was signed on September 5, 1795, and the American ratification is dated March 7, 1796.

**The price.** The treaty freed 83 American sailors, by the count of the State Department's historians. Counts of the captives differ with the year, from 83 freed in 1796 to 115 held in 1793.

In all, the treaty cost the United States about $1 million, by the Treasury's estimate. The money for the first payment reached Algiers late, and the Dey demanded more, which roughly doubled the price. Other accounts give a smaller sum paid at once, plus supplies for the Dey's ships every year.

The Dey's officials released the surviving sailors on July 8, 1796. Six captives had died shortly before. Several others carried lasting injuries from their years of captivity.

### James Leander Cathcart

> **Who:** An American sailor enslaved in Algiers for eleven years, who rose to be the Dey's chief Christian clerk and put the 1795 treaty into English.
>
> **When and where:** Born June 1, 1767, in County Westmeath, Ireland. Captured July 25, 1785, off Cape St. Vincent, Portugal. Held in Algiers until May 1796. Died October 6, 1843.

**Captured at 18, Cathcart spent eleven years as a slave in Algiers.**

He had come to America from Ireland as a boy. During the Revolution the British had already captured him once and held him on prison ships at New York, until he escaped.

**The capture.** Cathcart was one of six crewmen on the Boston ship *Maria* when an Algerian warship with 14 guns took it on July 25, 1785. He later explained why Algerian warships were out in the Atlantic that summer. Spain's war with Algiers had kept them out until the two made peace in 1785.

Then Charles Logie, the British consul in Algiers, spoke to the Dey's government. A consul is an official who looks after his country's trade and citizens in another country. Logie told them that American ships were no longer under the British king's protection, so the Algerians could take them.

The Algerian crew drove the six Americans into a boat and took their hats, handkerchiefs and shoes. On the voyage the captors locked all 42 of their prisoners every night in the sail room in the ship's hold. The drinking water was so foul, Cathcart wrote, that "we were, literally, obliged to strain through our teeth." The *Maria* reached Algiers on August 4. On August 12 the *Dauphin* of Philadelphia arrived with 15 more American captives, which made 21 in all.

Dey Muhammad chose some of the captives to work in his palace and garden. His officials sent others to the slave prisons and to hard labor at the harbor. A man at hard labor got one suit of clothes, worth about a dollar and a half, and two rough blankets meant to last his whole captivity.

**The beating.** About four months after he arrived, officials who ran the Dey's household ordered Cathcart beaten with the bastinado, blows with sticks on the soles of the bare feet. Four men threw him down and tied his arms and legs. In the usual method, Cathcart wrote, the man lay face down with his ankles tied to a pole that two men held up, and a guard sat on his shoulders. Cathcart took 28 blows and lost four toenails.

He wrote that all fourteen slaves in the garden got the same beating, "old men of sixty and children of ten years of age" among them.

**The clerk.** Cathcart rose step by step. He served coffee to the minister of the harbor, then became clerk of the harbor, then clerk of a slave prison, and at last chief Christian clerk to the Dey. Foreign ambassadors who could not get a meeting with the Dey went through him. He helped Joseph Donaldson, who bargained for the Americans, and he translated the Turkish text of the 1795 treaty into English.

By Cathcart's own list, 9 of the 21 Americans taken in 1785 died in Algiers, most of them of plague, a disease that spread quickly and killed many people. The other 12 went home at different times. Family or friends bought some of them free before 1796, and the rest were freed in 1796. Cathcart left Algiers on May 8, 1796, carrying dispatches, official letters for the American government.

In January 1799 he sailed from Philadelphia as the American consul for Tunis and Tripoli. His daughter, J. B. Newkirk, published his account, *The Captives: Eleven Years a Prisoner in Algiers*, in 1899.

### Staying out of Europe's war, 1793 to 1796

President George Washington decided in 1793 to keep the United States out of the new war between France and Britain.

**The French minister.** France's new minister, Edmond-Charles Genêt, landed at Charleston, South Carolina, on April 8, 1793. Two weeks later, on April 22, Washington issued the Proclamation of Neutrality, which stated that the United States would take neither side.

Genêt hired American privateers, privately owned armed ships with a government's permission to attack enemy ships, to go after British ships. When Washington would not do as Genêt wished, Genêt threatened to go over the President's head to the American people. Washington demanded that the French government replace him.

**The treaty with Britain.** John Jay signed a treaty with Britain on November 19, 1794, and senators approved it on June 24, 1795, by 20 votes to 10. Under it, British troops were to leave the forts in the Northwest that British diplomats had promised to give up in 1783. British officials agreed to give American traders terms as good as those of any other country, and they put heavy limits on trade with the British islands in the Caribbean.

The two sides sent several quarrels to arbitration, a way of settling a dispute by letting a neutral panel decide: the border between Maine and Canada, the old debts, and British seizures of American ships. British officials kept the right to seize American cargo bound for France, with payment, and to take French goods off American ships without paying.

The State Department's historians sum it up this way: the treaty "addressed few U.S. interests, and ultimately granted Britain additional rights." It was very unpopular with Americans. Washington signed it anyway, because he judged that the country was too weak to fight Britain.

**The treaty with Spain.** Thomas Pinckney signed a treaty with Spain on October 27, 1795, after bargaining with a Spanish minister, Manuel de Godoy. Senators approved it on March 7, 1796. Under it, the border with Spanish West Florida was set at the 31st parallel, an east-west line on the map, and Americans got free use of the Mississippi River and of the port of New Orleans without paying tax.

That mattered to farmers in Kentucky and Tennessee. They could not haul their crops over the mountains to sell them, so they floated the crops down the rivers to New Orleans, which Spanish officials controlled. Under Pinckney's Treaty they could sell them there.

**The Farewell Address.** Washington's Farewell Address was printed in the *American Daily Advertiser*, a Philadelphia newspaper, on September 19, 1796. Alexander Hamilton had helped him write it. In it Washington said he would not run for a third term, and he argued that American leaders should not make permanent alliances with any foreign country.

### The XYZ Affair and a war at sea, 1798 to 1800

American navy crews fought French ships in the Caribbean from 1798 to 1800, in a war that neither government declared. It followed a failed attempt at talks. President John Adams had sent three commissioners to France: Elbridge Gerry, Charles Cotesworth Pinckney and John Marshall.

French agents told the three Americans that talks could not begin until the United States met their demands. The agents asked for a low-interest loan to France, and they wanted the United States government itself to pay what American merchants said France owed them. On top of that, they wanted "a substantial bribe" for the French foreign minister, Talleyrand.

**W, X, Y and Z.** Adams made the Americans' reports public, with the four agents' names replaced by the letters W, X, Y and Z. The agents were Nicholas Hubbard, Jean Hottinguer, Pierre Bellamy and Lucien Hauteval.

The fighting at sea that followed is called the Quasi-War, from a word meaning "almost." The State Department's historians call it "a limited, undeclared war." American and French diplomats ended it with an agreement called the Convention of 1800, also called the Treaty of Mortefontaine, and in the same agreement they ended the alliance of 1778 between France and the United States. Senators did not ratify it until December 18, 1801.

**If you remember one thing:** For its first twenty-five years the United States was too weak to free its sailors by force or to fight Britain, so its leaders made treaties and paid ransom instead.

- In 1775: The colonies were at war with Britain, and their leaders were looking in secret for help abroad.
- In 1800: American diplomats had signed treaties with France, Britain, Spain, Morocco and Algiers, and American navy crews had just fought French ships at sea.

**Next:** In the next fifty years American leaders doubled the size of the country with one purchase and pushed its border to the Pacific.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 10 minutes**

With one purchase in 1803, American diplomats roughly doubled the size of the United States, and by 1848 the country's border reached the Pacific Ocean. American leaders bought land from France, took Florida from Spain, split the Oregon country with Britain and took the Southwest from Mexico in a war. Native nations lived across all that land, and none of them signed the sales and treaties.

American sailors fought two wars against rulers on the coast of North Africa in the same years. In 1823 President James Monroe told Europe's rulers to start no new colonies in the Americas.

### Tribute and the Barbary wars, 1801 to 1815

American leaders had been paying tribute, protection money, to the rulers of the Barbary states, the four states on the coast of North Africa: Algiers, Tunis, Tripoli and Morocco. American officials paid the rulers so that their ships would not seize American ships and hold the crews for ransom.

When American officials would not raise the payments, the pasha, or ruler, of Tripoli declared war on the United States on May 14, 1801. The fighting ended with a treaty signed on June 10, 1805. Under it, American officials paid no more yearly tribute to Tripoli, but they did pay a ransom to free the crew of the *Philadelphia*, an American warship that Tripoli's forces had captured. A second Barbary war followed in 1815.

### The Louisiana Purchase, 1803

American envoys, men sent to bargain for their government, signed a treaty on April 30, 1803, to buy about 828,000 square miles of land west of the Mississippi from France. The price was $15 million, and the purchase roughly doubled the size of the United States.

The envoys had been sent to buy only the port of New Orleans, and French officials offered them all of Louisiana instead.

**Why Napoleon sold.** The people enslaved in the French colony of Saint-Domingue, now called Haiti, had risen against French rule. Napoleon, the ruler of France, had sent an army to put them down. The attempt failed, and he lost the army he sent. With a war against Britain coming, Napoleon sold Louisiana to raise money and to keep the British from taking it.

**A written promise.** Article III of the treaty states that the people living in the territory would be "incorporated in the Union of the United States," made part of the country. It also states that they would be admitted to "all the rights, advantages and immunities of citizens of the United States" (immunities are the protections the law gives every citizen).

So in 1803, the land the United States bought came with a written promise that its people would become full citizens. A century later, judges on the Supreme Court ruled that no such promise covered Puerto Rico, Guam or the Philippines.

Native nations lived across those 828,000 square miles, but they were not part of the sale and no one asked them. The promise of citizenship in Article III did not include them.

### How Florida changed hands, 1818 and 1819

General Andrew Jackson led American troops into Spanish Florida in 1818. They attacked the Seminole people and people who had escaped slavery, whom the American officials who approved the raid saw as a threat to Georgia. Jackson's troops seized the Spanish forts at Pensacola and St. Marks, and Jackson had two British citizens put to death, on charges of stirring up the Seminoles and the escaped slaves.

President James Monroe and his advisers seriously thought about speaking out against Jackson. John Quincy Adams defended him. As Secretary of State, Adams ran the country's dealings with other countries, and he used Jackson's raid to put a choice to Spain: control the people of East Florida, or hand it over to the United States.

**The treaty.** Adams and the Spanish minister, Luis de Onís, signed the Adams-Onís Treaty in 1819. Under it, Spain's leaders handed East Florida to the United States and gave up their claim to West Florida. Spanish officials received no payment. Instead, American officials agreed to pay American citizens, up to $5 million in all, the money those citizens said Spain owed them, so Spain would not have to pay it.

The treaty also fixed the western edge of the Louisiana Purchase. Spain's leaders gave up their claims to the Pacific Northwest, and American officials accepted Spanish rule over Texas. Leaders in both countries ratified the treaty in 1821.

### John Quincy Adams

> **Who:** The Secretary of State who got Florida from Spain and wrote the warning now called the Monroe Doctrine.
>
> **When and where:** Washington, D.C., 1817 to 1825.

**Adams talked President Monroe out of sharing his warning with Britain.**

Monroe had thought of making his 1823 warning to Europe's rulers jointly with Britain. Adams talked him out of it, so Monroe made it alone. The State Department's historians credit Adams with writing the statement.

Adams was Secretary of State from 1817 to 1825, under President James Monroe. He had already used Jackson's raid to press Spain to give up Florida, and he negotiated the 1819 treaty with Spain's minister, Luis de Onís, which carries both their names.

### The Monroe Doctrine, 1823

President James Monroe told Europe's rulers to start no new colonies in North or South America in his yearly message to Congress, on December 2, 1823. In his words, the American continents "are henceforth," meaning from now on, "not to be considered as subjects for future colonization by any European powers."

**Who enforced it.** The United States Navy was too small to enforce the warning in 1823. British leaders wanted other European powers kept out of Latin America too. Spanish officials had blocked British merchants from trading there under Spain's colonial trade rules, and British leaders wanted the new Latin American countries open to British trade. British warships kept those powers' fleets away.

### Texas, Oregon and the land taken from Mexico, 1845 to 1848

American leaders took Texas and the Southwest in the 1840s, and they split the Oregon country with Britain.

**Texas.** Texans had won a war of independence from Mexico in 1836 and set up their own republic. President John Tyler made a treaty with the Republic of Texas in April 1844 to bring it into the United States, but senators voted the treaty down that June. A treaty needs the votes of two thirds of the senators.

So members of the House and the Senate passed a joint resolution instead, on March 1, 1845, to annex Texas, which means to take it and make it part of the country. A joint resolution needs only more than half of the votes in each house. Texas joined the United States on December 29. In 1898 members of Congress took Hawaii the same way.

**Oregon.** The Oregon country stretched from the Pacific coast to the Rocky Mountains, covering what is now Oregon, Washington and most of the Canadian province of British Columbia. American and British officials set the border there at the 49th parallel, an east-west line on the map, on June 15, 1846. The United States got the part south of that line, and the two sides settled it by treaty, without a war.

**Mexico.** The land in the Southwest came from a war with Mexico, fought from 1846 to 1848. American and Mexican officials signed the Treaty of Guadalupe Hidalgo on February 2, 1848, at Guadalupe Hidalgo, a city north of Mexico City where Mexico's leaders had fled. Mexican officials, whose army had lost the war, signed over more than 525,000 square miles, and American officials agreed to pay $15,000,000. The land became all or part of California, Nevada, Utah, Arizona, New Mexico, Colorado and Wyoming.

Between about 80,000 and 100,000 Mexican citizens lived on that land, depending on the count, and without moving they found themselves living in the United States. Senators changed the treaty's promises to them before they approved it on March 10, 1848.

**Rights.** The treaty promised that Mexicans who became American citizens would keep "the free enjoyment of their liberty and property" and the free practice of their religion. Senators rewrote that part of the treaty. In the version that took effect, members of Congress would decide the "proper time" for these new Americans to get all the rights of citizens.

**Land titles.** Senators cut out completely the part of the treaty that kept Spanish and Mexican land grants valid under American law. Land grants were legal titles to land given by Spanish or Mexican officials. American officials then wrote a side agreement, the Protocol of Querétaro, telling Mexican officials that the cut had not canceled those titles. American judges did not treat the side agreement as equal to the treaty.

Under a new law of 1851, Mexican landowners in California had to prove their deeds, the papers showing they owned their land, before officials of the United States government. The cases took an average of 17 years. Many families sold most of their land during those years to pay English-speaking lawyers and land taxes. The Peralta family of San José and the East Bay kept only 700 of their 49,000 acres.

English-speaking American squatters, newcomers who settled on land that was not theirs, took more. In some cases, as with the Suñol and Berryessa families, squatters lynched the Mexican landowners, killing them without any trial, and stayed on the land. Many Mexican American families lost their land or fell into debt. The historians William Carrigan and Clive Webb counted at least 597 Mexicans whom mobs in the United States lynched between 1848 and 1928.

**The miners' tax.** California's new lawmakers passed the Foreign Miners' Tax in 1850, $20 a month for each miner born outside the country. They aimed it at Chinese and Latino miners, and officials collected it mostly from them. Thousands of foreign-born miners left the mining towns, and lawmakers ended the tax the next year.

**Village land.** In northern New Mexico and southern Colorado, some land grants belonged to whole villages together. The families of a village shared its common land, including forest on the nearby mountains. In the late 1800s American officials and judges broke up these shared grants, and the villages lost most of their common land.

A special Court of Private Land Claims judged these grants from 1891. Its judges, and United States land officials before them, often recognized a grant only up to the foot of the mountains, leaving out the forests.

The judges of the Supreme Court decided a case called *United States v. Sandoval* in 1897. They agreed with government lawyers that a village's common lands belonged to the United States government, and seven grants lost between 95 and 99 percent of their land under that ruling. Other villages lost their common land in lawsuits that split it into private pieces, or because they could not pay the taxes on it.

Another part of the treaty describes the Native nations who lived on the land as "savage tribes," an insulting name. It states that "a great part" of the land was "now occupied" by them, and that from then on they would "be under the exclusive control of the Government of the United States." The article also states that the United States government would "forcibly restrain" their raids into Mexico. Among the nations on that land were the Tohono O'odham. No Native nation signed the treaty.

### Nicholas Trist

> **Who:** The American diplomat who made peace with Mexico after President James K. Polk ordered him home.
>
> **When and where:** Mexico, 1847 and 1848.

**Polk fired the diplomat who made his peace with Mexico.**

President James K. Polk sent Trist to Mexico to bargain for an end to the war, then recalled him in October 1847. Trist ignored the order and kept bargaining with no authority to do so. In February 1848 he signed the Treaty of Guadalupe Hidalgo.

Polk sent the treaty to the Senate anyway, because under it he got what he wanted, including California. Then he fired Trist, and he refused to pay Trist's expenses or his salary for his last months of work.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 14 minutes**

Americans claimed their first land overseas in 1856, small islands covered in seabird droppings, which make crops grow. American officials bought Alaska from Russia in 1867, and in 1898 they took Hawaii and, after a war with Spain, Puerto Rico, Guam and the Philippines. No one asked the people who lived in these places. They became territories, lands that belonged to the United States but were not states.

**How it grew.** In the 1790s the United States could not free its sailors from Algiers. By 1900 it reached from the Atlantic to the Pacific, its railroad track had grown from about 9,000 miles in 1850 to 193,346 miles, and its mills made 11.4 million tons of steel a year, more than Britain and Germany together.

**Hawaii.** A group of mostly American businessmen overthrew Hawaii's queen in 1893 with the help of American Marines. More than half of the Native Hawaiian people signed a petition against annexation, and members of Congress annexed the islands anyway.

### Perry's warships in Japan, 1853 and 1854

Commodore Matthew Perry opened two Japanese ports to American ships by bringing warships to Japan. Perry, the navy officer in command of the group, sailed into Edo Bay, beside the city of Edo, now called Tokyo, in July 1853, and he came back in 1854. Japanese and American officials signed the Convention of Kanagawa, a written agreement that opened the two ports, on March 31, 1854. The Japanese officials signed it under the threat of Perry's warships.

### Islands claimed for bird droppings, 1856

Americans first claimed land overseas for the United States in 1856, forty-two years before the war with Spain. They wanted guano, the droppings of seabirds, because it makes crops grow.

Members of Congress passed the Guano Islands Act on August 18, 1856. Under it, an American citizen who found an island with guano on it could take the island for the United States, unless another country already claimed it. Americans claimed about a hundred islands under this law.

The judges of the Supreme Court ruled that the law was valid in 1890, in a case called *Jones v. United States*. Lawmakers have never ended it, and it is still part of United States law.

### Who was left out of the Alaska sale?

American officials bought Alaska from Russia in 1867, and the diplomats who wrote the treaty left Alaska's Native peoples out of American citizenship by name. American and Russian diplomats signed the treaty on March 30, 1867, for a price of $7,200,000. Russian officials formally handed over the territory at a ceremony on Castle Hill in Sitka on October 18, 1867, and then the United States flag went up.

**Tlingit land.** Russian officials sold land that they did not really control. Alaska Native nations lived on it, and they had no part in the sale. Castle Hill itself was Tlingit land. Alexander Baranov, the first Russian governor, had attacked the hill in 1804 to take it from the Kiksadi clan of the Tlingit people, and after a six-day battle the Russians seized the Kiksadi fort and burned it. In 1867 a Tlingit village still stood beside the Russian town of Sitka.

Article III of the treaty states who would become an American citizen. People living in Alaska who stayed would be admitted to "the enjoyment of all the rights, advantages, and immunities of citizens of the United States." The article then leaves out "uncivilized native tribes," an insulting name for Alaska's Native peoples. They would instead be "subject to such laws and regulations as the United States may from time to time adopt."

Alaska had no civil government, one run by elected or appointed officials outside the armed forces, until 1884. For 17 years American officers ruled it, first from the Army, then from the Treasury Department, then from the Navy. The historian Rebecca Poulson, writing for the Alaska Historical Society, says that American officials considered Native people "savages," an insulting word, and did not allow them to be citizens.

**Kake.** Under Russian rule, officials of the Russian company that ran Alaska had paid compensation, a payment to the dead person's family, when a Tlingit person was killed. Under Tlingit law, a death was settled with a payment, not with punishment. American officers refused to pay. In early 1869 an army guard at Sitka killed two men from the village of Kake, deaths Poulson calls accidental. Army officers at Sitka refused to pay compensation for them, and relatives of the dead men then killed two white men.

General Jefferson C. Davis ordered the American warship USS *Saginaw* to attack Kake. It was winter. The crew fired exploding shells from the ship's guns at the Kake villages and burned 28 of the villages' 29 clan houses, the houses of the Kake clans, which are large family groups. They also burned the villagers' canoes, totem poles and stored food.

**Not known:** No one has worked out how many people died after the attack, reporters at KTOO, a public radio station in Juneau, wrote in 2024. Kake oral history, the accounts the Tlingit of Kake passed down by word of mouth, records many deaths, especially among elders and children.

### Hawaii: a kingdom overthrown, 1887 to 1893

A group of mostly American businessmen overthrew Queen Liliʻuokalani of Hawaii in January 1893, and American Marines and sailors helped them. Two of their leaders had already used armed men to force a Hawaiian king to do what they wanted.

**The Bayonet Constitution.** A group of lawyers and sugar planters who were haole, the Hawaiian word for white people who are not Native Hawaiian, forced King Kalākaua to sign a new constitution on June 30, 1887. An armed militia, a force of armed citizens, backed them, and their leaders were two lawyers, Sanford B. Dole and Lorrin Thurston. The document became known as the Bayonet Constitution, after the blade fixed to the end of a rifle.

**The overthrow.** Early in 1893 members of the Annexation Club, Thurston among them, contacted John L. Stevens, the United States Minister to Hawaii and the top American diplomat there. They wanted to know whether the Americans would back them. The group, calling itself the Committee of Safety, began to move against the queen on January 15, 1893.

Stevens had 162 American sailors and Marines landed from the warship USS *Boston* on January 16. The queen's government had several hundred soldiers and police, and they did not fight. Dole became president of the new provisional government, a government set up for a short time until a lasting one is formed.

Queen Liliʻuokalani gave up her throne under protest. She addressed her protest to the United States, not to the men who had taken power. She wrote that she yielded "to the superior force of the United States of America," whose minister, John L. Stevens, "has caused United States troops to be landed at Honolulu."

### Two American reports that disagree, 1893 and 1894

Two American investigations of the overthrow reached opposite findings. President Grover Cleveland sent James H. Blount to Hawaii to find out what had happened, and Blount reported that Stevens had landed the Marines on a false excuse to help the plotters.

**What Cleveland said.** Cleveland sent Congress a message about it on December 18, 1893. He said that the show of armed force, the "military demonstration on the soil of Honolulu," was "of itself an act of war." He also said that "the provisional government owes its existence to an armed invasion by the United States."

Albert S. Willis, the new American minister in Hawaii, apologized for what Stevens had done, which he called "the reprehensible conduct of the American minister," reprehensible meaning deserving blame. He also apologized for "the unauthorized presence on land of a military force."

**What the Senate said.** Cleveland could not get the queen put back on her throne. Members of a Senate committee made their own investigation in 1894, called the Morgan Report, and they cleared everyone involved. On July 4, 1894, the men who had taken power declared the Republic of Hawaii.

### Queen Liliʻuokalani

> **Who:** The last queen of Hawaii, overthrown with American help and then tried in her own palace. She wrote the song "Aloha ʻOe."
>
> **When and where:** Honolulu. Overthrown January 17, 1893. Held prisoner in ʻIolani Palace in 1895.

**The queen was put on trial in her own throne room.**

**The rising of 1895.** Two years after the overthrow, Hawaiians loyal to the queen, among them Robert Wilcox and Prince Kūhiō, tried to restore her by force in January 1895. Within 36 hours officials of the Republic of Hawaii had caught the rebels and jailed them. Then they arrested the queen, and on January 24, 1895, they forced her to sign a paper giving up her throne for good.

**The trial.** They tried her before a military court in the throne room of ʻIolani Palace, where she had ruled. The charge was misprision of treason, knowing about a plot against the government and not reporting it. The officers who sat on the court found her guilty, fined her $5,000, and sentenced her to five years in prison at hard labor, forced heavy work.

The Republic's officials later reduced the sentence. For nearly eight months they held her prisoner in an upstairs bedroom of the palace, and they allowed her no visitors except one woman companion. She spent her days praying, reading, writing music, crocheting and quilting.

### 21,269 names against annexation, 1897

Native Hawaiians defeated a treaty to annex their islands by signing their names against it. Two Hawaiian groups held meetings on the five main islands between September 11 and October 2, 1897: Hui Aloha ʻĀina, which had separate branches for men and for women, and Hui Kālaiʻāina. They gathered 21,269 signatures of Native Hawaiians against annexation. That year about 39,000 Native Hawaiian and part-Hawaiian people were counted, so more than half of them signed.

Four men carried the petition to Washington: James Kaulia, David Kalauokalani, John Richardson and William Auld. They arrived on December 6 and presented it to the Senate on December 9, 1897. A treaty needs the votes of two-thirds of the senators. When the four men left Washington on February 27, 1898, only 46 senators were still willing to vote for the annexation treaty, short of the two-thirds it needed. The treaty failed.

**Taken anyway.** Supporters of annexation in Congress then used a method that did not need the Senate votes the Hawaiians had blocked: a joint resolution, which passes when more than half of the House and more than half of the Senate vote for it. Members of the House voted for theirs, the Newlands Resolution, on June 15, 1898, and senators on July 6. President William McKinley signed it on July 7, 1898, and under it American officials took over Hawaii.

### 1898: Puerto Rico, Guam and the Philippines

After a war with Spain in 1898, American officials ruled Puerto Rico, Guam and the Philippines. The American battleship USS *Maine* blew up in the harbor of Havana, in Cuba, on February 15, 1898, and in April members of Congress declared war on Spain.

**Guam and Puerto Rico.** Juan Marina, the Spanish governor of Guam, surrendered the island to officers of the American warship USS *Charleston* on June 21, 1898. American troops landed in Puerto Rico at Guánica on July 25.

Spanish and American diplomats signed the Treaty of Paris on December 10, 1898. Spanish diplomats gave up Cuba and signed Puerto Rico and Guam over to the United States. They sold the Philippines to the United States for $20 million.

No one from Puerto Rico, Guam or the Philippines took part in the talks in Paris. Several million people in those places got new rulers without being asked. Among them on Guam were the CHamoru, the island's Native people. In the Philippines, Filipinos had already declared their own independence.

### Why Americans and Filipinos went to war, 1899

War between American troops and the Philippine Republic began on February 4, 1899, because American officials had decided to keep the islands. Filipinos had been fighting Spain before the Americans arrived. On June 12, 1898, they declared their independence. American officials kept the islands instead of recognizing the new republic, and the two sides went to war.

**The dead.** The war lasted until 1902. About 4,200 Americans and about 20,000 Filipino soldiers were killed.

**Disputed:** Counts of the Filipino civilians, people who were not soldiers, who died run from about 200,000 to as many as 1,000,000. The State Department's historians give the lowest count: as many as 200,000 dead "from violence, famine, and disease." Other estimates run much higher, and historians disagree about them.

Much of the dying came from hunger and from a cholera epidemic in 1902, an outbreak of a gut disease spread by dirty water. The epidemic was worse because the fighting had broken up daily life in the islands, and it killed more than 200,000 people in all.

**What American troops did.** The State Department's historians also record what American troops did. In their words, "U.S. forces at times burned villages, implemented civilian reconcentration policies, and employed torture on suspected guerrillas." Reconcentration meant forcing civilians out of their homes into camps or zones that soldiers guarded, and the guerrillas were fighters in small bands who hid among the people and attacked by surprise.

One kind of torture American soldiers used was the water cure, in which they forced water into a prisoner until his stomach swelled and then pressed it out of him. Chapter 22, War and the Military, tells where they used it and on whom.

### Emilio Aguinaldo

> **Who:** The Filipino leader who declared the Philippines independent from Spain and then led the war against the United States.
>
> **When and where:** Born March 22 or 23, 1869, near Cavite, on the island of Luzon. President of the Philippine Republic from January 1899. Captured at Palanan on March 23, 1901. Died February 6, 1964.

**American officers captured him by pretending to be prisoners.**

Aguinaldo was the mayor of his town, Cavite Viejo, in 1896, and a local leader of the Katipunan, a secret society fighting Spanish rule.

**Two deals.** Aguinaldo made a deal with the Spanish governor in December 1897: he would leave the islands in return for money and a promise of reforms. From Hong Kong and Singapore he then made plans with American consuls, officials who looked after American trade and citizens there, and with officers of Commodore George Dewey's fleet. He would come back and help the Americans fight Spain. He landed in the Philippines again on May 19, 1898.

Filipinos declared independence on June 12, 1898, with Aguinaldo at the head of their government. Six months later Spanish diplomats sold the islands to the United States in the Treaty of Paris. Filipinos proclaimed a constitution on January 23, 1899, and elected Aguinaldo president of the Philippine Republic. The fighting with American troops began on February 4, and from November 1899 his forces fought as guerrillas.

**The trick.** General Frederick Funston captured him at Palanan, in northern Luzon, on March 23, 1901. Macabebe scouts, Filipinos who served the United States Army, dressed as rebel soldiers, and Funston and a few other American officers went along, pretending to be their prisoners. Fake letters sent ahead to Aguinaldo said that more of his own soldiers were coming and were bringing American prisoners to him. At Palanan the scouts opened fire on his guards, killed two and seized him.

Aguinaldo swore loyalty to the United States. On April 19, 1901, he called on his fighters to lay down their weapons and accept American rule. He lived until 1964 and saw the Philippines become independent in 1946.

### Samoa divided, 1899

Diplomats divided the Samoan islands between the United States and Germany on December 2, 1899, in an agreement called the Tripartite Convention, from a word meaning three-sided. The three sides that signed it were the United States, Germany and Great Britain.

By signing it, the German and British ambassadors gave up their countries' claims to Tutuila and every other Samoan island east of a north-south map line, 171 degrees west. John Hay, the American secretary of state, gave up American claims to Upolu, Savaiʻi and the other islands west of that line, leaving them to Germany.

**The chiefs' papers.** The chiefs of the island of Tutuila signed a paper handing their island to the United States on April 17, 1900. Tui Manuʻa Elisala, the ruler of the Manuʻa islands, signed his islands over on July 16, 1904.

**If you remember one thing:** In the second half of the 1800s American leaders took lands across two oceans, and most of the people who lived in them were never asked.

**One question this era leaves open:** Were the people of Puerto Rico, Guam and the Philippines now American citizens, with all the rights in the Constitution? The next era answers it.

**Next:** After 1900 American officials ruled the new islands, and the judges of the Supreme Court decided how much of the Constitution reached the people there.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 17 minutes**

Puerto Rico "belongs to, but is not a part of, the United States," the judges of the Supreme Court ruled in 1901. In a set of cases between 1901 and 1922 they held the same for the other islands taken in 1898, and the people living there did not get the whole Constitution. American troops finished a war in the Philippines and occupied Haiti, the Dominican Republic and Nicaragua.

Workers, most of them from islands in the Caribbean, built the Panama Canal for the United States, on a strip of land that American officials held forever under a treaty. Americans fought in two world wars. After the first, senators refused to join the League of Nations that President Woodrow Wilson had proposed, and after the second, American leaders helped found the United Nations and the NATO military alliance.

### Finishing the war in the Philippines, 1900 to 1902

American soldiers in the Philippines tortured Filipino prisoners and killed civilians. Chapter 22, War and the Military, tells what they did at Igbaras and on Samar in full. Here is what happened in Washington, and to the officers who gave the orders.

**Igbaras and Samar.** At Igbaras, on November 27, 1900, Captain Edwin F. Glenn, an Army lawyer, and a doctor working for the Army directed the water cure of the town's mayor, Tobeniano Ealdama, until Ealdama said he was a captain among the Filipino fighters. That night Glenn had the town burned. On Samar, townspeople and Filipino fighters at Balangiga killed about 48 American soldiers on September 28, 1901, the Army's worst loss in a single fight since the Little Bighorn. General Jacob H. Smith then ordered, "I want no prisoners. I wish you to kill and burn."

**Disputed:** Counts of the people American troops killed on Samar are far apart. Most estimates fall between 2,000 and 2,500, and a British researcher, Bob Couttie, who studied it for ten years, put it at about 2,500. An American soldier who was there said 39, and other counts reach 5,000. An old figure of 50,000 is now traced to misread documents.

### What happened to the officers

The torture came out in the Senate. Senator George Frisbie Hoar asked for an investigation, and Senator Henry Cabot Lodge kept it inside his own Committee on the Philippines. On April 14, 1902, Charles S. Riley, a former sergeant, told the committee what he had seen at Igbaras.

**Glenn.** Secretary of War Elihu Root ordered Glenn court-martialed, tried in a military court. Army officials moved the trial from San Francisco to Catbalogan, in the Philippines, far from the witnesses. The officers on the court found Glenn guilty, suspended him for one month and fined him fifty dollars. Ealdama, the mayor he had tortured, was then serving a prison sentence as a "war traitor."

**Waller and Smith.** On Samar, Marine Major Littleton Waller had eleven Filipino guides and carriers shot without a trial. He told his court-martial that he had followed Smith's orders, and the officers on the court found him not guilty.

Officers at another court-martial found Smith guilty of "conduct to the prejudice of good order and military discipline," behaving in a way that harmed order and discipline in the armed forces. They asked only that he be formally scolded. President Theodore Roosevelt went further and forced Smith to retire, two years before he was due to leave the Army. Smith was not sent to prison.

**Roosevelt's letter.** In a private letter, Roosevelt called the water cure "the old Filipino method of mild torture" and wrote that "nobody was seriously damaged." In the same letter he also wrote, "torture is not a thing that we can tolerate."

Roosevelt declared the war over on July 4, 1902. American troops kept fighting in the Moro provinces of the southern Philippines until 1913.

### The Insular Cases, 1901 to 1922

The justices, the judges of the Supreme Court, decided between 1901 and 1922 that the islands taken in 1898 belonged to the United States but were not fully part of it. Their decisions are called the Insular Cases, from a word meaning having to do with islands.

The justices decided *Downes v. Bidwell* on May 27, 1901, holding that Puerto Rico "belongs to, but is not a part of, the United States." From these cases came the idea of the "unincorporated territory," a place the United States owns and rules, where the people do not get the whole Constitution unless Congress chooses to give it to them.

**A trial by jury.** In *Balzac v. Porto Rico* in 1922, the justices held that Puerto Ricans had no constitutional right to a trial by jury at home. By then Puerto Ricans were American citizens.

The justices who decided these cases believed the people of the islands were not fit for full constitutional government. In 2022 Justice Neil Gorsuch wrote that the Insular Cases "have no foundation in the Constitution and rest instead on racial stereotypes," and he added, "They deserve no place in our law."

The justices of the Supreme Court have never overturned them. In 2026 they are still the law for the people of Puerto Rico, Guam, the U.S. Virgin Islands, American Samoa and the Northern Mariana Islands.

### Who became a citizen, and when

Members of Congress decided, island by island, whether the people of each territory would be American citizens. The answers came at different times. People born in American Samoa are still not citizens at birth.

**Puerto Rico.** Members of Congress set up a government for Puerto Rico under the Foraker Act, signed on April 12, 1900. The law identified the island's people as "citizens of Porto Rico," under the protection of the United States but not citizens of it. President Wilson signed the Jones-Shafroth Act on March 2, 1917, and under it Puerto Ricans became American citizens. Their citizenship came from a law passed by Congress, not from the Constitution, and it did not come with a vote for president.

One month later Americans entered the First World War. Two months after that, Wilson signed the law for the draft, which required young men to serve in the military. Accounts disagree on how many Puerto Ricans were drafted: the figure usually given is about 18,000, and History.com gives 20,000.

**Hawaii and the Virgin Islands.** Hawaii's territorial government was set up under the Hawaiian Organic Act, signed on April 30, 1900. Under the same law, the people who had been citizens of the Republic of Hawaii in August 1898 became American citizens. Danish officials agreed in a treaty signed on August 4, 1916, to sell the Danish West Indies to the United States for $25 million in gold. The islands changed hands on March 31, 1917, and became the U.S. Virgin Islands, but members of Congress did not make their people American citizens until 1927.

**Guam.** Officers of the United States Navy governed Guam from 1899. Its people did not become citizens until President Harry Truman signed the Organic Act of Guam on August 1, 1950, fifty-two years after Navy officers took the island. Under the act, Guam got a government run by civilians and stayed an unincorporated territory.

**American Samoa.** Members of Congress did not approve the Samoan chiefs' deeds of 1900 and 1904 until 1929, and Navy officers governed American Samoa until 1951. Under federal law its people are still American nationals, people who can live in the United States and carry an American passport but are not citizens. American Samoa is the only territory with people living on it where they do not become citizens at birth.

**The Philippines.** Under laws members of Congress passed in 1902 and 1916, American officials ran a colonial government in the Philippines, with a promise of independence someday. Under the Tydings-McDuffie Act, signed on March 24, 1934, the Philippines would become independent on July 4, 1946, after ten years of self-rule. In the same act, members of Congress put Filipinos in a different group under immigration law, so far fewer could move to the United States. The Philippines became independent on July 4, 1946.

Filipinos served in the American armed forces in the Second World War, at the call of the United States. Members of Congress then passed the Rescission Act in 1946, which stated that their service "shall not be deemed," or counted, "to have been active military, naval, or air service" for most veterans' benefits. Under it, they could not get benefits that other veterans of the same war received.

### The Frenchman who signed for Panama, 1903 to 1914

American officials backed Panama's break from Colombia in 1903. President Theodore Roosevelt sent American warships to Panama, and Panama's leaders declared independence on November 3. They at once named Philippe-Jean Bunau-Varilla, a French engineer who had worked on France's failed attempt to dig a canal there, to bargain for them in Washington.

Bunau-Varilla signed the Hay-Bunau-Varilla Treaty for Panama on November 18, 1903, and no Panamanian signed it. Under the treaty American officials got a strip of land 10 miles wide across Panama, forever. Panama got $10,000,000 at once and $250,000 a year, starting nine years later.

**The cost in lives.** The canal opened on August 15, 1914. The official count of the dead during the American building of the canal is 5,609, out of about 56,000 workers, about one worker in ten. Most of the workers came from Barbados, Jamaica and other islands of the Caribbean. The historian Caroline Lieffers, writing for The Conversation, says many historians think the real number was several times higher.

### Marines in Haiti, the Dominican Republic and Nicaragua

American presidents sent the Marines to occupy three nearby countries, holding them with troops and controlling their governments, for years at a time.

**Haiti.** American Marines took $500,000 from Haiti's national bank in December 1914 and moved it to New York. Haitian President Jean Vilbrun Guillaume Sam was killed in July 1915, and the State Department's historians do not name who killed him. President Woodrow Wilson then sent the Marines into Haiti, and they stayed for nineteen years, until 1934.

Under a treaty of 1915, American officials took full control of Haiti's money and set up a Haitian police force, the Gendarmerie, commanded by Marines. They forced the election of Philippe Sudré Dartiguenave as Haiti's president in August 1915.

American officials wanted a new Haitian constitution that let foreigners own land in Haiti. When Haiti's lawmakers resisted it, American officials forced President Dartiguenave to send the lawmakers home, and they did not meet again until 1929. The new constitution, written under American direction, went to a public vote on June 12, 1918. The official count recorded it as approved by 99 percent of the votes, with fewer than 5 percent of Haitians voting.

Marines and the Gendarmerie brought back the corvée, a system of forced labor, and made Haitians build roads without pay.

**The killing.** Haitian fighters called cacos rose against the occupation. The Marines and the Gendarmerie killed more than 2,000 cacos, by estimates in a report by the Congressional Research Service, and American forces lost 10 killed and 26 wounded. The report gives no count of other Haitians killed.

General George Barnett, a former head of the Marine Corps, spoke in October 1920 to a navy court of inquiry, a panel of officers looking into what Marines had done in Haiti. He said the Marines had recorded 2,250 Haitians killed from 1915 to 1920, 1,861 of them in 1919.

Marines fired on about 1,500 protesters at Les Cayes on December 6, 1929, and killed at least 12 Haitians. President Franklin D. Roosevelt pulled the Marines out in 1934.

**Charlemagne Péralte.** Péralte, born in 1885 or 1886 by different accounts, led the armed resistance from 1917, and Marine officers ordered their men to "get Charlemagne." Sergeant Herman H. Hanneken went into Péralte's camp in disguise and shot him dead near Sainte-Suzanne on November 1, 1919. The Marines photographed the body and passed the picture around.

**The Dominican Republic.** Marines landed in the Dominican Republic in May 1916, and American officers declared a military government that November. From 1917 to 1921 they fought guerrillas in the east, called gavilleros. The Library of Congress's country study describes the Americans' methods as "often brutal" but gives no count of the Dominicans killed. Dominicans took back control when President Horacio Vásquez took office on July 13, 1924.

**Nicaragua.** American officials encouraged a revolt against President José Santos Zelaya in 1909, and Marines landed at Bluefields. Marines came again in 1912 to support President Adolfo Díaz, and a guard of 100 Marines stayed at the American embassy until 1925. About 2,000 more Marines arrived in 1927.

Augusto César Sandino fought them for as long as they stayed. The Marines trained a Nicaraguan National Guard and left in January 1933, with Anastasio Somoza García in command of the Guard.

Somoza and other high officers agreed in 1934 to kill Sandino. On February 23, 1934, Sandino came to what looked like a peace meeting, and National Guardsmen seized him and murdered him. Somoza became president on January 1, 1937, and ruled for about twenty years.

**Not known:** No reliable count exists of the Nicaraguans killed in the fighting with the Marines.

### Woodrow Wilson

> **Who:** The president who proposed the League of Nations and sent the Marines into Haiti.
>
> **When and where:** Washington, D.C., 1915 to 1920.

**Senators voted twice against the League of Nations Wilson proposed.**

Wilson was president when Americans entered the First World War on April 6, 1917. He set out his terms for peace, called the Fourteen Points, on January 8, 1918. One of them was a League of Nations, a group of countries that would settle quarrels by talking instead of fighting. Senators voted against the peace treaty and the League in November 1919 and again in March 1920, and the United States never joined it.

Wilson also sent the Marines into Haiti in 1915, and they stayed until 1934. In 1917 he signed both the law that made Puerto Ricans American citizens and the draft law that followed it.

**By 1935:** The Marines had left Nicaragua and Haiti, and members of Congress had promised the Philippines independence on July 4, 1946. Puerto Ricans had been American citizens since 1917, but they could not vote for president.

### Puerto Rico under an appointed governor, 1937

Police in Puerto Rico shot marchers at Ponce in 1937, under Governor Blanton Winship, and the same year officials began using public money to sterilize Puerto Rican women, which means operating on them so they could never become pregnant again. Winship was an American general whom the President of the United States appointed to govern the island. Puerto Ricans did not elect him.

**Ponce.** Members of the Nationalist Party marched in Ponce on Palm Sunday, March 21, 1937. They marked the end of slavery in Puerto Rico and protested the jailing of their leader, Pedro Albizu Campos. The Insular Police, who were under Winship's direct military command, opened fire on the marchers.

Accounts give the dead as between 19 and 21 and the wounded as between about 150 and 235. A human rights commission that looked into it found that police had shot all the dead. The killings are known as the Ponce Massacre.

**Law 116.** Law 116 took effect the same year, under Winship. Under it, officials set up a Eugenics Board, and public money paid for sterilizations. The board took its name from eugenics, a set of beliefs, now rejected, that some groups of people should be kept from having children.

In Puerto Rico the usual method of sterilization was tubal ligation, which Puerto Ricans called *la operación*. In it a doctor cut or tied the two tubes that carry eggs from the ovaries to the womb. Some women instead had a hysterectomy, in which a surgeon removed the womb.

**Forced and pressured.** Members of the Eugenics Board forced 97 sterilizations from 1937 until the law was repealed in 1960. Many thousands more women had the operation under pressure. Some women were told, falsely, that the operation could be undone. Others were told that they would not be hired unless they were sterilized, and employers did favor hiring sterilized women. The accounts do not name who told them these things. Hospital staff turned away some pregnant women unless they agreed to be sterilized after giving birth.

Clarence Gamble, an heir to the Procter and Gamble fortune who believed in eugenics, set up clinics on the island. By 1968 about one Puerto Rican woman in three of childbearing age had been sterilized, and a 1982 study found 41 percent of married women in Puerto Rico sterilized.

The record on consent is mixed. Some women chose the operation because it was the only birth control offered to them. The doctor Helen Rodríguez-Trías said, "Women make choices based on alternatives, and there haven't been many alternatives in Puerto Rico."

### Pedro Albizu Campos

> **Who:** A United States Army officer in the First World War who became the leader of the movement for Puerto Rican independence.
>
> **When and where:** Born in Ponce, Puerto Rico, on September 12, 1891.

**Albizu Campos could be drafted but could not vote for president.**

Under the 1917 law he was an American citizen, so officials could draft him into the army, but no one living in Puerto Rico could vote for president. He was also the first Puerto Rican to graduate from Harvard Law School.

In the First World War he served in the United States Army and rose to second lieutenant. Army officers assigned him to the 375th Infantry Regiment, which was all Black, because Army leaders kept Black and white soldiers in separate units, a practice called segregation. The segregation he met there shaped his politics.

He became president of the Puerto Rican Nationalist Party, whose members wanted independence from the United States, in 1930. He was later convicted of sedition, the crime of urging people to rise against the government, and sent to prison. Nationalists marched in Ponce in 1937 partly to protest his imprisonment, and police shot them.

### The ship American officials turned away, 1939

American officials refused to let a ship full of Jewish refugees land in 1939. The *St. Louis* sailed from Hamburg, in Germany, on May 13, 1939, with 937 passengers, almost all of them Jews escaping Nazi Germany.

Cuban officials let 28 of them land, and American and Canadian officials refused the rest. The ship carried them back to Europe, where officials in Great Britain let in 288 of them, in the Netherlands 181, in Belgium 214 and in France 224.

Nazis later killed 254 of the passengers in the Holocaust, their mass murder of the Jews of Europe, according to the United States Holocaust Memorial Museum.

### Guam under Japanese occupation, 1941 to 1944

The people of Guam lived through two and a half years of Japanese occupation as people of the United States who were not American citizens. Japanese forces invaded Guam on December 8, 1941, hours after the attack on Pearl Harbor. Japanese soldiers beat CHamoru people, forced them to work without pay and put some of them to death.

Japanese officers had put every able-bodied man into a labor battalion, working without pay, by the spring of 1944. In the last weeks, Japanese troops force-marched the people to concentration camps, where soldiers held civilians under guard. The largest camp was at Manenggon. American forces landed on July 21, 1944, and people on Guam mark that day as Liberation Day.

### The United Nations, the Marshall Plan and NATO, 1945 to 1949

After the Second World War, American leaders helped build the kind of world organization that senators had refused in 1920. Delegates from many countries signed the United Nations Charter in San Francisco on June 26, 1945, and it took effect on October 24, 1945.

**The Marshall Plan and NATO.** Members of Congress passed the law for the Marshall Plan in March 1948, under which American officials sent money to rebuild Western Europe after the war. The money eventually rose to more than $12 billion. Diplomats of twelve countries signed the treaty that created NATO, the North Atlantic Treaty Organization, a military alliance, on April 4, 1949. The State Department's historians call it "the first peacetime military alliance the United States entered into outside of the Western Hemisphere."

**If you remember one thing:** In these fifty years American officials ruled islands whose people did not get the whole Constitution, and American troops held three nearby countries for years at a time.

- 1915: President Wilson sends the Marines into Haiti. They stay nineteen years.
- 1917: Puerto Ricans become American citizens by a law of Congress, without a vote for president.
- 1950: The people of Guam become citizens, fifty-two years after Navy officers took the island.

**Next:** Two territories became states after 1950, and American presidents sent aid, weapons and troops abroad with one rival in mind, the Soviet Union.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 12 minutes**

Three elected governments, in Iran, Guatemala and Chile, were overthrown with secret American help in these years. For forty years after 1950, American presidents chose where aid, weapons and troops went with one rival in mind, the Soviet Union. That rivalry is called the Cold War, and American troops fought in Korea and Vietnam as part of it.

**The territories.** Alaska and Hawaii became states, and Puerto Rico got a new name but stayed a territory. On Pacific islands that American officials governed for the United Nations, with a duty to look after the people, they set off nuclear bombs.

### What was the Cold War?

The Cold War was a long rivalry between the United States and its allies on one side and the Soviet Union and its allies on the other. The Soviet Union was a large country ruled from Moscow, in Russia, from 1922 to 1991. It was a communist country, which meant that one party ruled it and the government owned the businesses. From 1947 on, American leaders' plan, which they called containment, was to block the spread of Soviet power wherever they saw a risk of it growing.

**The end.** The Berlin Wall, which had divided the city of Berlin, was opened on November 9, 1989. The Soviet Union broke apart on December 26, 1991, and the Cold War was over.

### The Cuban Missile Crisis, October 1962

American and Soviet leaders came closer to nuclear war in October 1962 than at any other time. Soviet leader Nikita Khrushchev and Cuban leader Fidel Castro had secretly agreed in July 1962 to put Soviet nuclear missiles in Cuba. Before that, a force backed by the United States had tried and failed to overthrow Castro in the Bay of Pigs invasion.

**The pictures.** An American U-2 spy plane took pictures of missile sites being built in Cuba on October 14, 1962. On October 22 President John F. Kennedy ordered American warships to stop ships carrying weapons to Cuba. He called it a quarantine, and he told the country about it on television. American forces went on alert for war, and on October 27 a U-2 was shot down over Cuba.

**A secret promise.** Kennedy then offered to promise not to attack Cuba if the missiles were removed. His brother Robert Kennedy secretly told the Soviet ambassador, Anatoly Dobrynin, that American missiles in Turkey would also be taken out, though not as part of any public deal. Khrushchev announced on October 28 that the Soviet missiles would leave Cuba, and the American Jupiter missiles left Turkey in April 1963.

### The Peace Corps, 1961

President Kennedy created the Peace Corps, a program for American volunteers to serve in other countries, by an order he signed on March 1, 1961. Sargent Shriver was its first director, and the first volunteers went to Ghana, in Africa, that same year.

### Lillian Carter

> **Who:** A nurse from Plains, Georgia, who joined the Peace Corps at 68. Mother of President Jimmy Carter.
>
> **When and where:** India, 1966 to 1968.
>
> **Movie:** *Miss Lillian: More Than a President's Mother* (2021), a documentary film about her directed by Vivian Winther.

**She joined the Peace Corps at 68 and turned 70 in India.**

Lillian Carter, a nurse, worked in India for the Peace Corps from 1966 to 1968. She told the recruiter she wanted to go "where it's warm, people have dark skins and need a nurse's service."

She was sent to the Godrej Colony, about 30 miles from Mumbai. After she came home, her son Jimmy Carter became president. She died in 1983, and in 1986 Peace Corps officials created the Lillian Carter Award for volunteers who serve at the age of 50 or older.

### Governments overthrown with American help

American officials secretly helped overthrow elected governments in Iran, Guatemala and Chile, in coups, sudden takeovers of a government by a small group, often the army.

**Iran, 1953.** Prime Minister Mohammad Mosaddegh had taken control of Iran's oil industry away from British companies. In June 1953 President Dwight Eisenhower approved a secret American and British plan to overthrow him. Officers of the Central Intelligence Agency, or CIA, the American government's spy service, carried it out. The CIA's director, Allen Dulles, oversaw the planning, and Kermit Roosevelt, a CIA officer, ran the plan in Iran. CIA officers paid journalists, religious leaders and politicians to attack Mosaddegh as corrupt and power-hungry.

General Fazlollah Zahedi replaced Mosaddegh on August 19, 1953, and the Shah, Iran's king, took back power. The Shah had Mosaddegh convicted of treason. Mosaddegh served three years in prison and lived the rest of his life under house arrest, and officials of the Shah's government put to death one of his advisers and more than a dozen military officers and student leaders on his side. In 2013 CIA officials released the agency's own history, which states that the agency "planned and helped implement the coup."

**Guatemala, 1954.** President Jacobo Árbenz began a land reform, a plan to share out farmland, with a law called Decree 900 on June 27, 1952. Under it his officials took land from owners and gave about 1.5 million acres to about 100,000 families, and the owners were paid more than $8 million in all. The United Fruit Company was one of the landowners. Árbenz's officials offered United Fruit $2.99 an acre for its land, and State Department officials demanded $75 an acre.

Eisenhower approved a CIA operation to overthrow Árbenz in August 1953. CIA officers ran what they called "psychological warfare and political action" against Árbenz's government, using fear, rumors and false stories to turn people against their leaders. The officers also drew up lists of Guatemalan officials to be killed, and one list had 58 names.

A force under Carlos Castillo Armas invaded from Honduras on June 18, 1954, after planes had harassed the capital, and on June 27 Árbenz resigned. Castillo Armas became president, and his officials gave the land back to the companies and broke up the labor unions. Human rights groups estimate that between 1954 and 1990, the forces of Guatemala's military governments murdered more than 100,000 civilians.

**Chile, 1970 to 1973.** Salvador Allende was elected president of Chile in September 1970. On September 15, President Richard Nixon met CIA Director Richard Helms and ordered him to stop Allende. Helms wrote down Nixon's words in his notes, among them "make the economy scream" and "$10,000,000 available, more if necessary."

CIA officers then ran a plan they called Track II, whose stated aim was "a firm and continuing policy that Allende be overthrown by a coup." They gave weapons to men who planned to kidnap the head of Chile's army, General René Schneider. A different group of plotters killed Schneider on October 22, 1970.

General Augusto Pinochet led the army coup that overthrew Allende on September 11, 1973. An American military attaché, an officer posted to the American embassy, called the coup "close to perfect." Pinochet ruled Chile until 1990.

Chile's official commissions count 3,216 people whom Pinochet's forces killed or "disappeared" between 1973 and 1990. The disappeared were people his forces took who were never seen again. The commissions also count 38,254 people who survived political imprisonment, torture or both.

### Two new states and a ballot with two answers, 1959

Alaska became the 49th state on January 3, 1959, and Hawaii became the 50th on August 21, 1959. Hawaii's voters could only say Yes or No to becoming a state right away. Their ballot of June 27, 1959, asked: "Shall Hawaii immediately be admitted into the Union as a State?"

**Not on the ballot.** Independence was not one of the choices. Members of the United Nations General Assembly had passed Resolution 742 in 1953, which stated that votes like this one should offer a free choice among several futures, including independence. A large majority of Hawaii's voters chose statehood. Hawaii and Alaska were then taken off the United Nations list of territories that did not govern themselves.

### Puerto Rico: a new name, and armed revolt, 1950 to 1954

Puerto Ricans got the right to write their own constitution in 1950, but the island stayed a territory under the Insular Cases. Members of Congress passed Public Law 600 that year, and Puerto Rico's voters approved the law in 1951 and the constitution in 1952.

**A new name.** Governor Luis Muñoz Marín proclaimed the Commonwealth, the *Estado Libre Asociado*, on July 25, 1952, the anniversary of the American landing at Guánica in 1898. Under that new name, the island was still a territory of the United States. Members of the United Nations General Assembly voted on November 27, 1953, to take Puerto Rico off the list of territories that did not govern themselves, and American officials then stopped sending the United Nations reports about the island.

**The revolt of 1950.** Some Puerto Ricans fought the new arrangement with guns. Nationalists rose up in several towns on October 30, 1950, and *Time* magazine reported that about 70 of them took Jayuya and killed four policemen there. Soldiers and pilots of the Puerto Rico National Guard, under Major General Luis R. Esteves, attacked the towns of Jayuya and Utuado with P-47 Thunderbolt warplanes, artillery, mortars and grenades. Pilots in American military aircraft fired on and bombed towns full of American citizens.

Governor Muñoz Marín counted 31 Puerto Ricans dead across the island in the revolt, *Time* reported. *Time*'s report does not state how many people the Guard killed in Jayuya and Utuado.

**Blair House.** Two Nationalists, Griselio Torresola and Oscar Collazo, attacked Blair House in Washington, where President Harry Truman was living, on November 1, 1950. Torresola shot a White House guard, Leslie Coffelt, three times. Coffelt was dying, but he got up and shot Torresola dead, and then Coffelt died of his wounds. Collazo was sentenced to death, and in 1952 Truman changed the sentence to life in prison.

**The House, 1954.** Four Puerto Rican Nationalists went into the visitors' gallery of the House of Representatives on March 1, 1954: Lolita Lebrón, Rafael Cancel Miranda, Andrés Figueroa Cordero and Irvin Flores Rodríguez. They unrolled a Puerto Rican flag and fired down onto the floor, wounding five members of the House, and all five recovered. All four Nationalists were convicted and sent to prison.

### The Pacific: a trust, nuclear tests and one vote to join

After the Second World War, members of the United Nations placed more than 2,000 Pacific islands under American rule: the Marianas, the Carolines and the Marshalls. American officials governed them for the United Nations from 1947 to 1986, with a duty to look after the people. The arrangement was called the Trust Territory of the Pacific Islands.

American officials set off 67 nuclear tests between 1946 and 1958 at Bikini and Enewetak, two atolls, rings of small coral islands around a lagoon, in the Marshall Islands. They moved the people off those atolls before the tests.

**Castle Bravo.** The largest test was Castle Bravo, on March 1, 1954. It was two and a half times as powerful as its planners expected, and its fallout, the radioactive dust from the blast, came down on islands where people lived. All 64 people on Rongelap, about 110 miles away, took in radiation from it. American officials moved the people of Rongelap and Utirik away about three days after the blast, and Rongelap could no longer be lived on. Chapter 22, War and the Military, tells what the fallout did to them and to a Japanese fishing crew.

**The study.** Officials of the Atomic Energy Commission, the government agency in charge of nuclear weapons, then ran a study of the exposed people, called Project 4.1. The people in the study lived on islands that the United States governed for the United Nations, with a duty to look after them. Radioactive iodine from fallout collects in the thyroid, a gland in the neck, and in later years thyroid disease, including thyroid cancer, was the most common lasting harm among the people exposed.

**One vote to join.** The people of the Northern Mariana Islands voted to join the United States. Of today's five territories with people living in them, it is the only one whose people voted to come in. A Covenant, a formal agreement, between the islands and the United States was signed on February 15, 1975, and 78.8 percent of the people who voted approved it on June 17, 1975. The Commonwealth of the Northern Mariana Islands began in 1978, and its people became American citizens in 1986.

The Marshall Islands and the Federated States of Micronesia became independent countries in 1986, tied to the United States by agreements called Compacts of Free Association. Palau's compact took effect in 1994.

### Washington, D.C., and the vote

Washington, D.C. is not a state either. Until 1961 the people living there could not vote for president at all, just as the people of the territories still cannot. That year lawmakers in enough states ratified, or approved, the Twenty-third Amendment to the Constitution, and it took effect on March 29, 1961.

The city got back a delegate in the House in 1971, one who can speak there but cannot vote on bills. Under the Home Rule Act of 1973, its people elected their own mayor from 1975. Members of Congress passed an amendment in 1978 to give the city full seats in Congress, but lawmakers in too few states approved it, and it ran out of time in 1985.

### The Panama Canal and an apology to Native Hawaiians

American and Panamanian leaders signed the Torrijos-Carter Treaties on September 7, 1977. Under them, American officials handed the Panama Canal to Panama on December 31, 1999.

**An apology.** Members of Congress passed, and President Bill Clinton signed, the Apology Resolution, Public Law 103-150, in 1993. It is about the overthrow of the Kingdom of Hawaii a hundred years earlier. On January 17, 1893, a group of mostly American businessmen had overthrown Queen Liliʻuokalani, and John L. Stevens, the top American diplomat in Hawaii, had landed 162 American sailors and Marines to back them.

The resolution states that Stevens "conspired," or plotted in secret, with "a small group of non-Hawaiian residents of the Kingdom of Hawaii, including citizens of the United States." It names the men who took power as a Committee of Safety that "represented the American and European sugar planters, descendents of missionaries, and financiers."

The resolution states that the overthrow was illegal. In it, members of Congress apologized to Native Hawaiians "on behalf of the people of the United States" for the overthrow, carried out "with the participation of agents and citizens of the United States." It also states that the Native Hawaiian people never directly gave up their claims to sovereignty, the right to govern themselves. Its last section states that it does not settle any claims against the United States.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 8 minutes**

More than 3.6 million people live in the five American territories with people on them, and none of them can vote for president while living at home. They still live under the Insular Cases. Since 2001 American leaders have sent troops to wars in Afghanistan, Iraq and, in 2026, Iran, and they have argued over trade and over the Paris agreement on climate.

### September 11, 2001, and the wars after it

Nineteen hijackers attacked the United States on September 11, 2001, and killed 2,977 people, not counting the hijackers. The next day, representatives of NATO's member countries called on Article 5 of their treaty, the promise that an attack on one member is an attack on all of them, for the first and only time.

American forces went into Afghanistan on October 7, 2001, and the last American troops left on August 30, 2021. American forces invaded Iraq on March 20, 2003. American leaders said Iraq had weapons of mass destruction, meaning nuclear, chemical or biological weapons. None were found.

**The dead.** Chapter 22, War and the Military, gives the counts of the people killed in these wars.

**Disputed:** For Iraq, counts built from deaths recorded one by one come out much lower than estimates built from surveys of households. Workers at Iraq Body Count, a group that records deaths one at a time, had counted more than 187,000 civilians killed from 2003 to 2024.

A survey published in the medical journal *The Lancet* in 2006 estimated about 600,000 violent deaths in Iraq in just the first three years of the war, and American and Iraqi officials disputed it at the time. A survey by the World Health Organization and Iraq's health ministry estimated about 151,000 violent deaths over the same three years.

**Guantánamo.** American officials began holding prisoners at the navy base at Guantánamo Bay, in Cuba, on January 11, 2002. Most of them were never tried in court. According to the journalist Andy Worthington, who tracks the prison, 779 men had been held there by January 2025, and 15 were still held.

### Trade and the climate agreement

Members of the World Trade Organization, a group of countries that agree on rules for trade between them, approved China's entry on November 10, 2001, and China joined at the end of that year. A new agreement among the United States, Mexico and Canada took effect on July 1, 2020, according to the Office of the United States Trade Representative. It replaced the North American Free Trade Agreement, called NAFTA.

The United States has joined and left the Paris climate agreement twice. The governments that join it promise to cut the gases that are warming the earth. American presidents took the country out of it in November 2020 and brought it back in February 2021. President Donald Trump signed an order to leave again on January 20, 2025, and researchers at the Congressional Research Service, which studies issues for Congress, report that the United States was out of the agreement as of January 27, 2026.

### Strikes at sea, Venezuela and Iran, 2025 and 2026

**Strikes at sea.** From September 2, 2025, American forces fired on boats in the Caribbean Sea and the eastern Pacific Ocean that President Trump's officials said were carrying drugs. By September 19, 2026, they had killed at least 231 people, the Associated Press reported. Chapter 22, War and the Military, tells the strikes in full, with the families who went to court over two of the dead.

**Venezuela.** American troops captured Venezuela's president, Nicolás Maduro, and his wife in Caracas, Venezuela's capital, on January 3, 2026, and took them to New York to face charges tied to drugs. According to the Brookings Institution, a research group, the raid went ahead without approval from Congress beforehand.

**Iran.** American and Israeli forces began a war with Iran by bombing it on February 28, 2026. Workers at the Human Rights Activists News Agency, a rights group that tracks Iran, counted 3,636 people killed in Iran by April 7, 2026, and 1,701 of them were civilians. Chapter 22 gives the count of American service members killed.

### The territories today

The 2020 census, the government's count of everyone who lives in the country and its territories, recorded more than 3.6 million people in the five American territories with people on them. Census Bureau workers counted 3,285,874 people in Puerto Rico, 11.8 percent fewer than in 2010.

They counted 153,836 in Guam, about 87,146 in the U.S. Virgin Islands, 49,710 in American Samoa and 47,329 in the Northern Mariana Islands. Every one of the five lost people between 2010 and 2020.

**Citizens and nationals.** People born in Puerto Rico, Guam, the U.S. Virgin Islands and the Northern Mariana Islands are American citizens. People born in American Samoa are American nationals. Their passports say so, and to vote they must go through naturalization, the process a person from another country uses to become a citizen.

No one living in a territory can vote for president. Voters in each territory elect one delegate to the House of Representatives, who can speak and work on committees but cannot vote on whether a bill passes. Puerto Rico's delegate is called the Resident Commissioner.

**La junta.** Puerto Rico's government owed more than $72 billion by 2016, and more than $55 billion in pensions, the money its officials had promised to pay its workers after they retired. Puerto Rico's leaders had no legal way to change the terms of the debt. Members of Congress passed a law called PROMESA on June 30, 2016. Under it, a board of seven members, appointed in Washington, has power over Puerto Rico's budget, and Puerto Ricans call it *la junta*.

The people whose budget the board controls did not elect its members. By the board's own account, its members have changed the terms of about 80 percent of the debt, cutting it from more than $70 billion to about $37 billion.

President Trump fired several members of the board on August 5, 2025, and CBS News named five of them. Under PROMESA a president may remove a member "only for cause," which means for a real reason such as wrongdoing.

Three of the fired members, Arthur J. González, Andrew G. Biggs and Betty A. Rosa, went to court. Judge María Antongiorgi-Jordán of the federal court in Puerto Rico put them back on the board on October 3, 2025. In 2026 she made that order permanent and called the firings "plainly contrary to law," according to the Democracy Defenders Fund, a group that campaigns on political causes.

**The status votes.** Puerto Ricans have voted on their island's status several times, and members of Congress have not acted on any of the results. Statehood won 52.52 percent in 2020. On November 5, 2024, statehood won 58.61 percent, free association 29.57 percent and independence 11.82 percent, according to the island's certified results. Free association would make the island a separate country tied to the United States by a formal agreement, as the Marshall Islands are.

Some voters stayed away from these votes in protest. Members of Congress do not have to follow the results, and only Congress can change Puerto Rico's status.

**Washington, D.C.** The capital had about 690,000 people in the 2020 census, more than the state of Wyoming, which had 576,851, or Vermont. It has one delegate in the House who cannot vote on bills, and no senators. Members of the House of Representatives voted 216 to 208 to make it a state on April 22, 2021, but senators did not take up the bill.

### John Fitisemanu

> **Who:** A man born in American Samoa and living in Utah who sued to be counted an American citizen from birth.
>
> **When and where:** Utah. His case was decided by a federal appeals court in 2021.

**Fitisemanu sued for citizenship, and his home territory's leaders opposed him.**

Because he was born in American Samoa, Fitisemanu is an American national, not a citizen, and a national must become a citizen before he can vote. He sued the United States to be recognized as a citizen by birth, and a federal judge in Utah agreed with him.

**The appeal.** In 2021 judges of a higher federal court, the Court of Appeals for the Tenth Circuit, overturned that decision, holding that the Insular Cases were still the law. On October 17, 2022, the justices of the Supreme Court refused to take his case.

American Samoa's own elected leaders opposed his lawsuit. They argued that citizenship ordered by a court could put at legal risk *faʻa Sāmoa*, the Samoan way of life, which includes land held in common by families and the matai system of chiefs. Fitisemanu wants to be a citizen. The leaders of his home territory did not want citizenship granted to Samoans that way.

### José Luis Vaello Madero

> **Who:** A man the United States government sued for $28,081 after he moved to Puerto Rico.
>
> **When and where:** New York, then Puerto Rico. His case was decided by the Supreme Court on April 21, 2022.

**Moving to Puerto Rico ended his right to a federal payment.**

While Vaello Madero lived in New York, he lawfully received Supplemental Security Income, a federal payment for people with very low incomes who are elderly, blind or disabled. Members of Congress have not made that benefit available to people living in Puerto Rico. After he moved, the payments kept coming, and he did not know he was no longer allowed to get them. Lawyers for the United States government sued him to get back $28,081.

**At the Supreme Court.** His case reached the justices, and on April 21, 2022, they ruled 8 to 1 that the Constitution does not require Congress to pay that benefit to people in Puerto Rico. Justice Neil Gorsuch agreed with the result, but he also wrote a separate statement of his own, and in it he called for the Insular Cases to be overturned.

**The three questions, answered**

- Who got to choose when this land and its islands changed hands? Almost never the people who lived there: no Native nation was at Paris in 1783, and no one from Puerto Rico, Guam or the Philippines was at Paris in 1898. Of today's five territories, only the Northern Mariana Islands voted to join, and Hawaii's voters chose statehood in 1959 from a ballot that left out independence.
- How did a weak new country come to rule islands and overthrow governments? First it grew: by 1848 it reached the Pacific, and by 1900 its mills made more steel than Britain's and Germany's together. Then its leaders used force. Marines helped overthrow Hawaii's queen in 1893, American leaders took Puerto Rico, Guam and the Philippines after a war with Spain in 1898, and after 1950 CIA officers secretly helped overthrow governments in Iran, Guatemala and Chile.
- Are the people of the territories American citizens? Most are, but people born in American Samoa are nationals, not citizens, and no one living in a territory can vote for president.

**What changed:** The chapter begins with rulers dividing land they had never seen and ends with a country that began as colonies holding five island territories whose people cannot vote for president.

**Five dates to keep**

- June 7, 1494: The rulers of Spain and Portugal split the lands across the Atlantic.
- September 3, 1783: British diplomats accept American independence in Paris.
- February 2, 1848: Mexican officials sign over the Southwest.
- December 10, 1898: Spanish diplomats sign over Puerto Rico, Guam and the Philippines.
- May 27, 1901: The justices rule that Puerto Rico belongs to the United States without being part of it.

**Not known:** No one has worked out how many people died at Kake after the crew of the USS *Saginaw* burned the villages in 1869.

**Where to go:** ʻIolani Palace, in Honolulu, where Queen Liliʻuokalani was tried and held prisoner in 1895.

**Next:** Chapter 24, Slavery and Freedom. It asks how slavery was built here one law at a time, and what happened to the freedom enslaved people won in 1865.
