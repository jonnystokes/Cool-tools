# Chapter 7: Home and Family Life

**Chapter 7 of 37 · Home and Family Life · 10 eras · about 60 minutes**

**The American home changed shape in every era, and again and again people with power decided which families could have one, and which could stay together.**

A Hidatsa woman named Buffalo Bird Woman told the story of her girlhood to a scientist, who published it in 1921. Home was her mothers' earth lodge on the Missouri River, with a floor more than forty feet across and a fire in the center. The women of the family owned it. Her father had four wives, all sisters, and she was taught to call all four her mothers. By 1921, she said, "We no longer live in an earth lodge, but in a house with chimneys."

This chapter describes American homes from the earth lodges and longhouses of the Native nations to the houses where parents worked and children went to school online in 2020. From era to era the houses change: the one-room colonial house, the log cabin, the city tenement, the sod house cut from the prairie, the bungalow and the suburban ranch house. As you read, watch four things: who lived together under one roof, who did the work of the house, whose land it stood on, and who decided which families could live there.

**Three questions this chapter answers**

- Who lived together under one roof, from the longhouse to today?
- Who did the work of keeping house, and did stoves, pipes and wires make it lighter?
- How did lenders and builders keep Black families out of new neighborhoods, and what did those families do?

**Five minutes?** Read "New home loans, and the red lines" in 1900 to 1950, then the story of Clyde Ross in 1950 to 2000.

**Can skip:** "Where the log cabin came from", "Bungalows, and houses sold by catalog", "The TV in the living room". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 3 minutes**

A Native household was built around kin, a person's relatives by birth or by marriage, and in many nations several related families lived under one roof. Each nation built the kind of house that suited its climate and the way its families got their food. Children learned to work by working beside adults, and old people lived in the same household as the young.

### Who was in charge of a longhouse?

Women ran the longhouse among the Haudenosaunee, several Native nations joined together in one union. The head of each house was the clan mother. She was the eldest or most respected woman of her clan, a large group of families who come down from the same ancestor. Women owned the house's everyday goods. The women of a longhouse and their children all came down from one woman who lived long ago, and every family traced itself back through the mothers' side.

The longhouse was a long building with a frame of wooden posts, covered with bark, and it held many related families. Two families lived in each section of the house, one on each side of an aisle, and they shared one fire in the middle. By different counts, one house held 30 to 60 people, or 20 families or more.

A woman's daughters and granddaughters lived in the longhouse all their lives. When they married, their husbands came to live with them. A son moved out when he married, into his wife's longhouse, but he still belonged to his mother's.

### The earth lodge

Among the Mandan, Hidatsa and Arikara nations on the upper Missouri River, women built the houses and owned them. Their house was the earth lodge, a dome made of timber and packed over with earth. An older woman directed the building, and women kept the lodge in repair.

One earth lodge held about 10 to 20 people, most often sisters and their families. Markers put up by the State Historical Society of North Dakota state that most lodges were 35 to 45 feet across, and that one lodge took about 150 trees to build. A lodge lasted about ten years, and then the women built it again. The large villages had more than 100 lodges each.

### Pueblos, wigwams and tipis

Taos Pueblo is a town of many homes joined together and stacked on top of one another, the kind of Native town called a pueblo. It is the northernmost of the nineteen Pueblos of what is now New Mexico. Its people built their homes of adobe, earth mixed with water and straw. They poured the adobe into molds or shaped it into bricks and dried them in the sun.

The two main buildings, the North House and the South House, rise five stories high. By the Pueblo's own estimate, people built them between about 1000 and 1450, and families have lived in them ever since. People have lived at Taos Pueblo without a break for more than 1,000 years.

In the Eastern Woodlands, the forests of the eastern part of the continent, many families lived in wigwams. A wigwam had a frame of saplings, thin young trees, covered with bark or with woven mats. On the Plains, the grasslands in the middle of the continent, families lived in tipis covered with animal hides. A family could take a tipi down and pack it up, so the household could move with the hunt.

## The 1500s

**Era 2 of 10 · The 1500s · about 2 minutes**

Most of the Europeans who came to this land in the 1500s were soldiers, priests and sailors, so European families were few, and Native households went on living in their own towns.

The newcomers carried diseases that Native people had never had before, and those diseases made Native people sick and killed many of them. About 200,000 Timucua people lived in what is now northern Florida and southern Georgia before the Spanish came. After one outbreak of disease after another, only about 2,000 were left by the 1650s, 1 for every 100 who had lived there. No record counts how many died in the 1500s alone.

### St. Augustine, built in Seloy's town

Chapter 6 tells how Pedro Menéndez de Avilés founded St. Augustine in September 1565, inside Seloy, a town of the Timucua people. The town's chief, also named Seloy, at first offered Menéndez his council house, the building where the town held its meetings, and the Spanish used it as their first fort. Within months the Timucua were attacking the newcomers to drive them away. Seloy's town covered more than 12 acres, and its remains lie under what is now the Fountain of Youth Park in St. Augustine.

Few of the newcomers came as families. Of the 800 or so colonists, 26 were women, and an unknown number were enslaved Africans, people the Spanish owned as property and forced to work without pay.

Most Spanish men in St. Augustine had no wife. Most of the men who did marry had wives who were not Spanish, and from 1565 on, many Spanish soldiers married Native women. The Timucua traced their families and their inheritance through the mother's line.

Church officials in the town wrote down the names of the church's members. Their lists are called the Cathedral Parish records, after the parish, the group of people who belong to one church. The records begin on January 24, 1594, and they are the oldest church records that survive in the United States. The first marriage in them is dated February 2, 1594. The first baptism, the church ceremony that welcomes a person, often a baby, into the church, is dated June 25.

### Teresa and Francisco Camacho

> **Who:** One of the mixed Spanish and Native households of early St. Augustine.
>
> **When and where:** St. Augustine, Florida, 1580.

**A Spanish soldier, his Native wife, her sister and her son.**

One household in St. Augustine in 1580 held four people: Francisco Camacho, his wife Teresa, Teresa's sister Catalina and Catalina's son Juan. Teresa was a Native woman.

Francisco had come to Florida in the 1560s from San Lúcar de Barrameda, a town near Cádiz in Spain. He was a soldier in a regiment, a unit of the army, and he also worked as a fisherman.

**Not known:** Teresa's nation. The account of this household does not name it.

## The 1600s

**Era 3 of 10 · The 1600s · about 5 minutes**

At Plymouth in 1620, English colonists built their houses on the site of Patuxet, a Wampanoag village. The usual English house in Massachusetts had one room, where the family lived and worked, and many households also held servants, enslaved people and boys from other families learning a trade.

### Why Patuxet's houses stood empty

An English sea captain named Thomas Hunt kidnapped 20 Native people from Patuxet, a village of the Wampanoag nation on Plymouth harbor, in 1614. He also took 7 from Nauset, another Native community, and carried them all to Spain to sell them as slaves.

Then, between 1616 and 1619, a disease killed most of the Native people on the southeast coast of what is now Massachusetts. Estimates of the deaths run from one-third of the people to as many as 90 percent.

One of the kidnapped Patuxet men was Tisquantum, also known as Squanto. He made his way home in 1619 and found the houses empty and the cornfields grown over. The English who founded Plymouth Colony arrived the next year and built their houses at Patuxet. By then he was one of the last of the Patuxet people.

**Not known:** what the disease was. Researchers have proposed several deadly diseases, among them plague, yellow fever and smallpox.

### One room, then two

The basic English house in Massachusetts had a single room, called the hall. Next to it stood the chimney bay, the part of the house that held the chimney, the front door and the stairs. The family cooked, kept warm, had light and did its work at the hearth, the open fireplace in the hall that gave the room its heat and light.

The next step up was the hall-and-parlor house, with a second room called the parlor. The hall was still for cooking and work. The parlor was the best room, and it usually held a bed. Colonists went on building one-room houses well into the 1700s.

### Births, deaths, servants and apprentices

A New England mother had about 8 babies, on average, and about 6 of them lived to grow up. People in New England lived long lives for the time. In the Chesapeake, the colonies around Chesapeake Bay, about half of all children died before the age of 20. About 1 baby in 4 died as an infant, and about another 1 in 4 before 20. Most children in the Chesapeake lost a mother, a father or both before they reached their teens.

A household also held people who were not family. Indentured servants, who had signed a contract to work for a master for a set number of years, lived and worked in the house as members of the household. Through the 1600s, colonists owned more and more enslaved people, and they forced them to work in their households without pay.

**Apprentices.** At about 14, and sometimes younger, a boy could leave home for good. His parents and a master signed a written contract called an indenture, and under it the boy had to live with the master and work for him. He served until the age of 21, for as long as 7 years, and learned the master's trade.

The master took the place of a parent. In the indenture he promised to feed the boy, give him a place to sleep, train him in the trade and give him some schooling. About two-thirds of these contracts required the master to teach the boy reading or writing. At the end, the young man got freedom dues, a payment of clothes, tools or money.

### Mary Ring

> **Who:** A widow in Plymouth Colony whose will and list of belongings record what one household owned.
>
> **When and where:** Plymouth Colony, from 1629 or 1630. She died in July 1631.

**Governor Bradford owed her 2 pounds, and Winslow owed her beaver.**

After Mary Ring died in July 1631, her belongings were written down one by one, in a list called an inventory. It survives, and it records what one Plymouth household owned.

The inventory lists her books: a Bible, a psalm book with the songs from the Bible's Book of Psalms, and books called *A Plea for Infants* and *Garland of Virtuous Dames*. Her clothes came in violet, red, blue, grey, white and black, and in a mixed color. Her will lists green cloth "to make a coat."

The inventory also lists money owed to her. Governor William Bradford owed her 2 pounds in English money, written in the record as "Due from Gov." Edward Winslow owed her beaver fur, which the record spells the old way: "Bever due from mr Wynslow."

She wrote her own will, the paper that says who gets a person's belongings after death, and signed her name to it. The colony's court officials proved the will on October 28, 1633, more than two years after she died, which means they agreed it was real, so it could be carried out. By then both of the men she had named to oversee the will had died, and her son Andrew was still a child. Another colonist, Thomas Prence, took on the job of looking after Andrew's share.

Her husband, William Ring, died in the city of Leiden, in the Netherlands, sometime between 1620 and 1629. The Rings belonged to a church of English Separatists, people who wanted to worship apart from the Church of England. The church had moved to Leiden, and in 1620 some of its members sailed to America and founded Plymouth.

The Rings had planned to go too, but they were among 20 people who could not sail when their ship, the Speedwell, turned back. Mary Ring came to Plymouth as a widow in 1629 or 1630 with her three children, Elizabeth, Susanna and Andrew. All three married in the colony.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 2 minutes**

Each room had its own use in the new houses that wealthy colonists built in the early 1700s, but most families still lived in one or two rooms. In every kind of house, women and children made much of what the household used, from cloth to candles, and much of that work went on at the hearth.

### A room for every use: the Georgian house

Wealthy colonists built a style of house now called Georgian, with both sides built to match. Its builders took its balanced look from ancient Greek and Roman buildings. A central hall ran through the middle of the house, with rooms opening off it. The formal rooms, the parlors and the dining room, were at the front, and the rooms for work were farther back. Some Georgian houses had four chimneys, one to heat each of the four main rooms.

In a house with separate rooms, the people in a family could be apart from one another and have some privacy. Houses like this belonged to wealthy families.

### What a household made at the fire

Around the open fire in the hearth, a household spun and wove cloth and made candles, soap, butter and cheese. Its members preserved food so it would keep, and the cooks worked over the same fire. Women and children did most of this work. The historian Laurel Thatcher Ulrich described it in northern New England in her 1982 book *Good Wives*.

### Sarah Kemble Knight

> **Who:** A Boston businesswoman whose journal of a ride to New York records the households where she stayed.
>
> **When and where:** On the road from Boston to New Haven and New York and back, October 1704 to early 1705.

**A bed "as hard as it was high," warmed with a hot stone.**

Sarah Kemble Knight lived in Boston, where she ran a business and taught. In October 1704 she set out on horseback for New Haven and New York on legal business, and she kept a journal of the trip. In it she wrote about the road, the inns and the households where she stayed the night.

She stayed in New York for about two weeks and started home on December 21. Near Eastchester, New York, her party got lost in a great storm of wind and snow. One woman would hardly let them through her door, but the woman's son invited them in.

He showed Knight a bed "as hard as it was high," and he warmed it with a hot stone at her feet. The family had nothing in the house but milk. They boiled it and sweetened it with molasses for her.

Her journal stayed unprinted for about 120 years, until Theodore Dwight printed it in 1825.

**Why this story is here:** Few pieces of writing by American women survive from that time, and her journal is one of them.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 4 minutes**

When men left home during the Revolutionary War, women ran the households. A household still made most of what it used, and women and children still did most of that work. On the frontier, the edge of the colonists' settlements on land where Native nations lived, families made their homes in log cabins. Families in the older settlements lived in farmhouses.

### Where the log cabin came from

The log cabin was the usual first house of a frontier family by the second half of the 1700s. Settlers from Sweden and Finland had brought it to America more than a hundred years earlier. To build one, they cut notches near the ends of the logs so that the logs locked together at the corners.

These settlers came to the colony of New Sweden on the Delaware River from 1638. Among them were the Forest Finns, who were skilled at building with logs. The Nothnagle Log House in Greenwich Township, New Jersey, built in about 1638 to 1643, still stands. A common story says the first English colonists lived in log cabins, but the English at Plymouth and at Jamestown did not build them.

**Whose land.** New Sweden was built on Lenape land. Peter Minuit's Swedish and Dutch crew sailed up the Delaware River in the spring of 1638 and made agreements with several sachems, or leaders, of the Lenape and Susquehannock nations. With the sachems' permission, the crew built Fort Christina.

Several thousand Lenape lived in separate communities along the river, and people at the time counted them as the owners of the land beside it. The Lenape welcomed the colony because its people brought goods to trade. New Sweden lasted 17 years before the Dutch took control of it.

### Abigail Adams

> **Who:** Ran her family's farm, its money and her children's education through the Revolutionary War while her husband, John Adams, was away.
>
> **When and where:** Braintree, Massachusetts, in the part that is now the city of Quincy, 1774 to 1784.
>
> **Movie:** *John Adams* (2008), a miniseries made for HBO. It is about John Adams and his family, and Abigail Adams is one of its main characters.

**Charles, who was 6, was given smallpox on purpose three times.**

Abigail Adams ran the family farm at Braintree, Massachusetts, and managed its money from 1774, while her husband, John Adams, was away for years at a time. He served first in the Continental Congress, the meeting of leaders from the colonies, and then in Europe as a diplomat, a person who represents a country to other governments. Abigail taught the children herself, and she and John wrote each other more than 1,100 letters.

**The inoculation.** She took all four children to Boston in July 1776 to be inoculated, which meant giving a healthy person smallpox on purpose so that the person got a milder case. A doctor cut the skin with a small blade called a lancet. Then he put in a thread soaked in pus from a smallpox sore.

Caught the natural way, smallpox killed about 30 of every 100 people who got it. Of every 100 people inoculated, about 2 or 3 died. People who lived through smallpox usually did not catch it again, so inoculation gave them that protection at far less risk.

Abigail wrote to John from Boston on July 13, 1776: "I yesterday arrived and was with all 4 of our Little ones innoculated for the small pox." Their doctor was Dr. Bulfinch. She wrote that the children "stood the opperation Manfully," which meant they were brave about it.

Nabby, who was 10, broke out in many painful sores, while 9-year-old Johnny had a light case. Charles was 6, and he had to be inoculated three times before he caught the smallpox. Thomas, the fourth child, showed no sickness at first and had to be inoculated again.

Her years of running the farm alone ended in 1784, when she and Nabby sailed to Europe to join John.

### Martha Ballard

> **Who:** A midwife in Maine whose daily diary, kept for 27 years, records the work of an ordinary American household.
>
> **When and where:** Hallowell, Maine. The diary runs from January 1785 to 1812.
>
> **Movie:** *A Midwife's Tale* (1997), a documentary made for the PBS series *American Experience*. It is about Martha Ballard.

**She wrote down 816 births, each one with a name.**

Martha Ballard was a midwife, a woman who helps other women give birth, in Hallowell, Maine. She wrote in her diary nearly every day for 27 years, from January 1785 to 1812: about 10,000 entries over 9,965 days. The diary records 816 births that she helped with.

Around those births, the diary records the daily work of her own household: her garden, spinning, weaving, quilting and brewing, the work her daughters did, the visitors who came and the weather each day.

The historian Laurel Thatcher Ulrich, who wrote *Good Wives*, published a book about the diary, *A Midwife's Tale*, in 1990. Ulrich won the Pulitzer Prize, a yearly American prize for writing, for the book. The whole diary can be read online at DoHistory.org.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 8 minutes**

Middle-class families in towns and cities, the families in between the rich and the poor, began in the early 1800s to treat the home as a place set apart from paid work. From the 1830s, cooks began to trade the open hearth, the fireplace where food cooked over the fire, for the iron stove. On farms, children's chores came first, and school fitted around them. In the South, enslavers could sell any member of an enslaved family at any time.

### The parlor and the home apart from work

In these families the home was the mother's to run, and paid work happened somewhere else. The parlor, the front room where the family received visitors, became the room for showing off the family's best things.

The historian Aileen Kraditor gave these ideas a name in 1968: the cult of domesticity, the strongly held belief that the home was a place set apart from paid work and that it was the mother's to run. Catharine Beecher's 1841 book, *A Treatise on Domestic Economy*, a title that means a long book about running a home, described how to run a home of this kind. Readers used it as a guide.

### Was the iron stove better than the fire?

For the woman who did the cooking, the stove was better in some ways and worse in others. It meant less bending and lifting, less smoke, and no ash in the food. But it took hard work to clean, and stoves were drafty and hard to control.

Iron cookstoves spread through American kitchens from the 1830s. Foundries, the workshops where iron was melted and poured into molds, made stoves of many designs. By 1850 most middle-class kitchens in the cities had a stove in place of the open hearth, and poorer families and families far from towns changed over later.

Some writers disliked the change. Henry David Thoreau complained in 1846 that the stove "concealed the fire." He wrote that cooking had become "merely a chemic process," by which he meant a kind of chemistry.

### A child's day, and where school fit in

On a farm, a child's chores came first. Country schools, called district schools, usually held two terms a year. The summer term ran from about May to August, for the younger children, and women usually taught it. The winter term ran from about November to April, when older boys were not needed for work on the farm, and men were often hired to teach it.

Children missed school when the weather was bad or when there was work to do at home. The teacher often lived with the students' families, staying with one family and then the next, which people called boarding around.

**The rod.** At home, parents expected children to obey, and many parents hit their children with a rod, a stick or switch used for punishment. They pointed to a verse in the Bible's book of Proverbs: "He that spareth his rod hateth his son: but he that loveth him chasteneth him betimes."

The verse means that a father who does not use the rod hates his son, and a father who loves his son punishes him early. Some writers of advice books in the 1800s began to tell parents to punish children calmly and firmly instead. One of them told parents never to punish a child in anger.

### Home under slavery

Enslavers could break up an enslaved family on any day. They sold enslaved people, and slave traders bought them and moved them. Lawmakers and courts in the slave states did not count the marriages of enslaved people as legal marriages, and enslavers sold husbands and wives apart.

Traders forced more than 1 million enslaved people to move from the Upper South to the Deep South, the states farther south, between about 1790 and 1860. From 1820 they moved about 200,000 people every ten years. They marched them overland in chained lines called coffles, or shipped them by sea to New Orleans, which had the largest slave market in the country.

By the count of the Equal Justice Initiative, an American organization, the traders separated nearly half of the people they moved from a husband, a wife or a parent.

### Catharine Beecher

> **Who:** Wrote a book of instructions for running an American home, and argued that keeping house was a skill to be studied and taught in schools.
>
> **When and where:** Hartford, Connecticut, from 1823. Her *Treatise on Domestic Economy* came out in 1841.

**One book on running a home went through about 15 editions.**

Catharine Beecher's *A Treatise on Domestic Economy*, published in 1841, was the first American book to describe every part of running a home. Printers issued it in about 15 editions and put out new copies nearly every year for years.

Beecher argued that housekeeping was a profession, a skilled job that people should study and that schools should teach. She had founded the Hartford Female Seminary, a school for girls and young women in Connecticut, in 1823. In 1869 she and her sister Harriet Beecher Stowe wrote another book about the home, *The American Woman's Home*.

### Buffalo Bird Woman (Waheenee)

> **Who:** A Hidatsa woman who grew up in her mothers' earth lodge and later told the story of her life to the anthropologist Gilbert Wilson.
>
> **When and where:** About 1839 to 1932. Born by the Knife River and raised at Like-a-Fishhook village on the Missouri River, in what is now North Dakota.

**Her family believed that "an earth lodge was alive and had a spirit."**

Buffalo Bird Woman grew up in the 1840s in an earth lodge, a large round house with a frame of timber, covered over with packed earth. Her household held her father, his four wives, her grandmother and her great-grandmother.

Late in her life she told the story of that household to Gilbert Wilson, an anthropologist, a scientist who studies how groups of people live. He interviewed her every summer from 1906 or 1907 to 1918. She spoke Hidatsa and never learned English. Wilson published her story in 1921 as *Waheenee: An Indian Girl's Story*, and her son, Edward Goodbird, drew the pictures for Wilson's books.

She was born in an earth lodge near where the Knife River meets the Missouri, about 1839.

When she was ten days old, an old man named Nothing-but-Water gave her the name Good Way. Later her father gave her the name Waheenee-wea, Buffalo Bird Woman, because she was a sickly child, and people believed a new name could move the gods to help her.

Her father, Small Ankle, was a Hidatsa chief. He had four wives, and they were sisters: her mother, Weahtee, and Red Blossom, Stalk-of-Corn and Strikes-Many Woman. "I was taught to call all these my mothers," she said. "Such was our Indian custom." Her great-grandmother White Corn and her grandmother Turtle lived with the family too.

**The smallpox winter.** Smallpox, a deadly disease that spreads from person to person, came up the Missouri River in June 1837, before she was born. The American Fur Company's steamboat *St. Peters* carried passengers sick with it. Francis A. Chardon ran Fort Clark, a trading post near the Mandan and Hidatsa villages, where traders swapped goods for furs. He met the boat 30 miles downstream and heard that people on it were sick.

The boat landed at Fort Clark on June 18 or 19. In less than a day, workers from the boat and the fort unloaded goods and loaded furs, and villagers came and went from the boat.

About 2,000 Mandan people were alive in the spring of 1837. By October, smallpox had killed all but 138 of them. Buffalo Bird Woman's great-grandmother told her: "More than half of my tribe died in the smallpox winter. Of the Mandans only a few families were left alive. All the old people and little children died."

**The move.** When she was four, the Mandan and Hidatsa chiefs moved their people together to one new village at Like-a-Fishhook Point on the Missouri, to protect them from attacks by the Dakota and the Yanktonai. The village stood by 1845. Women and dogs carried the family goods there, some loads on their backs and some on travois, frames of two poles that the dogs dragged along the ground.

The people built about seventy summer earth lodges at the new village, most of them in the second summer. For the winter, families built small huts in the woods, and the June flood often swept them away.

In the first hard winter at the new village, when she was about six, the family camped at Many-Frogs Brook, three miles away. Smallpox broke out again with the first snow. "My brother, my mother Weahtee, and her sister Stalk-of-Corn, died," she said. Her grandmother Turtle made her a doll of deerskin with eyes of bone beads.

**Inside the lodge.** The women of a household owned its earth lodge. Her mothers' lodge had a floor more than forty feet across, with the fire in the center. A screen of upright split logs stood between the fire and the door and kept out drafts and dogs. Her father's bed, of cottonwood planks and buffalo robes, stood in front of the fire, where the oldest person in the family usually slept, because it was the warmest place.

The rest of the family slept in covered beds against the back wall. The buffalo-skin bedding could not be washed, so her mothers aired it on the stage, the raised platform where they dried their corn. The family believed that "an earth lodge was alive and had a spirit."

**Later years.** Her first husband was Magpie, and her son Goodbird was born in 1869. Federal officials, the officials of the national government, carried out a law of 1887 called the Dawes Act in the late 1880s. They divided reservation land, the land set aside for a Native nation to live on, into allotments, plots that they assigned to one family each, and they sold the land left over.

Native nations held about 138 million acres in 1887 and about 48 million in 1934. Once the reservation was divided, the families of Like-a-Fishhook left the village to live on the plots assigned to them, and by the late 1880s the village was gone. In 1921 she said: "We no longer live in an earth lodge, but in a house with chimneys." She added that "my son's wife cooks by a stove." She still got up at daybreak to hoe her corn and sing to it. She died in 1932.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 7 minutes**

Where an American family made its home in these years depended on how much money it had and what part of the country it was in. In New York, a working family might rent a tenement flat of small rooms, with shared toilets out in the yard. A middle-class family might have a house with a parlor for guests, a dining room for meals and a paid servant to help run it. On the plains, where few trees grew, settler families cut their houses out of the ground.

Lawmakers and officials also began to decide where children spent their days. State lawmakers required children to go to school, and federal officials took Native children away from their homes to distant schools.

### The tenement flat

The tenement at 97 Orchard Street in New York, which Chapter 6 describes, was a building of small apartments, called flats, rented to working families. Families lived in small rooms, and some took in boarders, people who paid to sleep in the family's rooms. They carried water into the flat by hand and shared privies, outdoor toilets, in the yard.

Lawmakers in New York began to change what a tenement had to include. Under the Tenement House Act of 1879, builders added air shafts, narrow gaps between buildings meant to let in air and light. Governor Theodore Roosevelt appointed a commission, a group of people chosen to study the housing laws, in 1900. Lawrence Veiller, its secretary, did most of the investigating and helped write a new law.

New York's state lawmakers passed that law on April 12, 1901. It required a window in every room and a toilet in every new apartment. Owners of old tenements had to give them better light and add one toilet for every two families.

### Bigger houses and paid help

Families who could pay for them built houses with a parlor for guests and a separate dining room. City homes got running water inside the house first, and farm families waited decades longer. In 1890, 24 of every 100 American households had running water, and 8 of every 100 had electricity.

Some middle-class homes also had paid help. The census of 1870, the count of the country's people taken every ten years, was the first to record the jobs of working women in full, by a set method. The census takers counted 867,354 women in domestic service, paid work in another family's home. That was about 47 of every 100 women who worked for pay, by far the most common paid job for women.

### Sod houses, dugouts and the Dakota land under them

The plains had few trees, so settler families there built with sod, the top layer of prairie soil, held together by the roots of the grass. Settlers used a plow to cut about an acre of ground into strips 12 inches wide and 4 inches thick, and they cut the strips into pieces about three feet long.

Builders laid these sod bricks grass side down, turning each layer lengthwise and then crosswise, to make walls two feet thick. Most early sod houses had dirt floors. Women who lived in them complained about the dirt, the bugs, the snakes, the leaking roofs and the poor light.

Some families dug their home, called a dugout, into the side of a hill or a creek bank. A dugout took less work to build than other kinds of house. Charles and Caroline Ingalls settled in a dugout on Plum Creek, near Walnut Grove, Minnesota, in May 1874. Their crops failed three years in a row, and in 1876 they left. The hollow in the creek bank where the dugout stood is still there, on what was once the Gordon farm.

**Whose land.** Walnut Grove lies on land the Dakota signed away in 1851 under treaties, written agreements between nations. At Traverse des Sioux on July 23, 1851, three men bargained with the Sisseton and Wahpeton Dakota for about 24 million acres. Luke Lea spoke for the US government. With him were Alexander Ramsey, the governor of Minnesota Territory, which was not yet a state, and Henry Sibley.

The three men agreed to pay about 7.5 cents an acre. The Dakota believed US officials would take the land by force if they refused. After the treaty was signed, the fur trader Joseph R. Brown had Dakota leaders sign another paper, and no one read it aloud to them or translated it.

Under that paper, traders could take the annuity money, the yearly payments promised to the Dakota, for debts the traders claimed the Dakota owed them. Within ten years, more than 100,000 white settlers moved onto the land.

### School laws and the boarding schools

Massachusetts lawmakers passed a law in 1852 that required children aged 8 to 14 to go to school for twelve weeks a year. By 1900, 32 states had such a law, and by 1918 every state had one, Mississippi last. Under these laws, families had to send their children to school for part of the year.

Federal officials took Native children from their families to boarding schools far away. Richard Henry Pratt, an Army officer, opened the Carlisle Indian Industrial School, a boarding school for Native children, on November 1, 1879.

**Forced attendance.** Members of Congress passed a law in 1891 that gave the Commissioner of Indian Affairs, the federal official in charge of Native affairs, a new power. He could make and enforce rules forcing Native children to attend school. Two years later they allowed officials to hold back food rations, clothing and payments owed to parents who refused to send their children.

At the schools, staff cut the children's hair, took away their clothes and gave them English names. Staff beat children who spoke their own language, locked them up alone, held back their food or washed their mouths out with soap. Survivors and a federal investigation later reported these punishments.

Officials of the US Department of the Interior reported on these schools in 2022 and 2024. They counted 417 federal boarding schools for Native children in 37 states or territories, open between 1819 and 1969, and at least 973 children who died at those schools. Their report states that this count is low.

### Nathalie Gumpertz

> **Who:** A tenement mother of four who became a dressmaker after her husband disappeared.
>
> **When and where:** 97 Orchard Street, New York. Her husband Julius disappeared in 1874. A judge declared him dead in 1883.

**Three dresses a week, sewn in the front room of a tenement flat.**

Nathalie and Julius Gumpertz were immigrants from East Prussia who lived at 97 Orchard Street. They were living there during the Panic of 1873, a money crash in which many people lost their jobs. One morning in 1874, Julius left for work and never came back, and Nathalie was left with four young children.

She became a dressmaker and worked in the front room of the flat, the parlor. She made about three dresses a week and earned 8 to 9 dollars.

A judge declared Julius legally dead in 1883, which meant that under the law he counted as dead. Because of that, Nathalie could claim 600 dollars that he was due from his father's estate, the money and property his father left when he died. She then moved the family to upper Manhattan.

Later, researchers who trace family histories for the Tenement Museum in New York found that Julius had gone to Cincinnati.

### Rachel Calof

> **Who:** A young woman from Russia who came to North Dakota for an arranged marriage and later wrote down what keeping a homestead house was like.
>
> **When and where:** Near Devils Lake, North Dakota, 1894 to 1904. She wrote her memoir in 1936, and it was published in 1995.

**In winter, in-laws and chickens shared their one 12-by-14-foot room.**

Rachel Calof was 18 when she traveled from Russia to marry Abraham Calof in 1894. It was an arranged marriage, planned by other people rather than by the couple. Abraham was a homesteader, a settler who claimed land from the US government to live on and farm.

The couple lived in a shanty, a small, roughly built house, 12 feet by 14 feet with a dirt floor. In the winters, Abraham's parents and brothers, and the chickens, shared the one room with the couple to save fuel. Of all the hardships, she wrote, "the lack of privacy was the hardest to bear."

She wrote a memoir, a book about her own life, in 1936, in Yiddish, a language spoken by many Jews in Eastern Europe. It records her years on the homestead from 1894 to 1904. Indiana University Press published it in English in 1995 as *Rachel Calof's Story*.

**Whose land.** The land around Devils Lake was Dakota land. Under a treaty of 1867, the land south of the lake became a reservation for the Sisseton and Wahpeton Dakota and the Cut Head band of Yanktonai Dakota. The Dakota name for the lake is Mni Wakan, Spirit Water.

Settlers who were not Native illegally claimed 64,000 acres of the reservation, and the Dakota bargained with the US government and accepted 345,000 dollars for that land. Federal officials opened 100,000 more acres of the reservation to settlers in 1904, at about 4 dollars and 50 cents an acre. By 1934 the Dakota owned a little more than 50,000 acres of it.

**Not known:** whether the Calofs' own claim lay on land taken from the reservation. The State Historical Society of North Dakota's history of the reservation does not say.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 12 minutes**

Running water and electric power reached most American homes between 1900 and 1950, city homes first and many farm homes decades later. After the Great Depression, the hard times of the 1930s, federal officials made home loans easier to pay off, but they usually refused to back loans in the neighborhoods where Black families lived.

### Why washday took more than a day

Without running water or electric power, washing a family's clothes by hand took more than one day. The person doing the wash first sorted the clothes and treated the stains, and then the clothes soaked in warm soapy water for one or two days. Next the washer scrubbed them on a washboard, a ridged board set in a tub of warm water and soap.

Then the washer boiled the clothes in a pot with soap and soda to kill lice, stirring them with a wooden stick called a dolly. After rinsing the clothes, the washer hung them out to dry, with the whites in the sun to bleach them. Last came the ironing, with flatirons, solid metal irons heated over the coals and held with a rag around the handle.

**Pipes and wires.** Water pipes and electric wires reached city homes first and farm homes decades later. In 1940, 74 of every 100 American homes had running water, and by 1950, 83 did. Officials of the Census Bureau, the federal office that counts the country's people and homes, found that more than one home in three had no flush toilet in 1940. Most of the homes without running water were in the country.

Electric power spread the same way. By 1950, 94 of every 100 households had it, but farms came last: fewer than 11 of every 100 farms had electric power in 1935, and about 9 in 10 had it by 1950.

**From icebox to refrigerator.** In 1930, 14 of every 100 households had a modern refrigerator, and by 1950, 80 did. A family without one used an icebox, a cabinet cooled by a block of ice, and relied on the iceman's deliveries, on milk brought each day and on canned food. The refrigerator ended the iceman's rounds and the daily trip to buy fresh food.

**Cowan's argument.** The historian Ruth Schwartz Cowan studied what the new machines did to a housewife's work. In her 1983 book *More Work for Mother*, she argued that washing machines, vacuum cleaners and other new conveniences mostly replaced work that servants, children and men had done before. She wrote that a housewife of 1950 kept a middle-class home clean and comfortable by herself, work that a household of 1850 had needed three or four workers to do.

At the same time, families expected clothes washed more often, houses kept cleaner and more cooking done. So, in Cowan's argument, the housewife's own hours of work did not fall. Census counts record one part of the change: the number of domestic servants fell by 32 percent between 1940 and 1950.

**Mokyr's answer.** Another scholar, Joel Mokyr, agreed that the hours did not fall, and in 2000 he gave a reason. In the late 1800s, scientists showed that germs cause many diseases. Doctors and nurses then told housewives that keeping germs out of the house would keep their families healthy, so, Mokyr wrote, housewives cleaned more.

### Bungalows, and houses sold by catalog

The small family house of this era was the bungalow, a house of one main floor with a low roof and a front porch, and sometimes rooms tucked under the roof. In Chicago, more than 80,000 brick bungalows built between 1910 and the mid-1930s still stand.

Sears, Roebuck and Company sold whole houses by catalog from 1908 to 1940. A buyer chose a design, and the house came by railroad in boxcars, as a kit. The average kit held about 25 tons of materials and more than 30,000 parts. Many buyers put the house together themselves with relatives, friends and neighbors, and others hired local carpenters. The first Sears house catalog, in 1908, offered 44 designs priced from 360 dollars to 2,890 dollars.

**Not known:** how many kit houses Sears sold. Nobody kept an official count, and the usual estimate is 70,000 to 75,000, with some estimates as high as 100,000.

### The Rogarshevskys and the tailor's disease

When Abraham Rogarshevsky died of tuberculosis on July 17, 1918, his widow kept the family in its tenement home by working for the building and renting out space. The Rogarshevskys were a Jewish family from Lithuania who had lived since about 1908 at 97 Orchard Street in New York.

Tuberculosis, a disease caused by a germ, usually infects the lungs, and it spreads through the air when a sick person coughs or talks. People then called it "the tailor's disease." After Abraham died, his widow, Fanny, became the building's janitor, the worker who cleaned the building and kept it in repair. She also took in boarders, people who paid to live in the family's rooms.

### New home loans, and the red lines

A home loan was hard to pay off before the 1930s. Under a mortgage, a loan to buy a house, the lender can take the house if the borrower does not repay it. The usual mortgage ran for 5 to 10 years, and each month the borrower paid only the interest, the fee for borrowing the money.

At the end, the borrower owed the whole amount at once. Buyers usually had to pay about half the price up front, as a down payment. In the Great Depression many borrowers could not pay, and lenders foreclosed, which means they took the houses back.

**The 1933 law.** Members of Congress passed the Home Owners' Loan Act in June 1933, and under it federal officials set up the Home Owners' Loan Corporation, or HOLC. HOLC officials replaced families' old loans with new loans that ran for 15 years at a fixed rate, which means the interest charge never changed. The family paid the same amount every month, and each payment paid off part of the loan itself.

Members of Congress set up the Federal Housing Administration, or FHA, in 1934. FHA officials insured home loans, which means they promised to repay the lender if the family could not. Those loans ran 20 to 25 years and needed only a small down payment. After the Second World War the 30-year loan became the usual kind.

**Graded by color.** Chapter 6 tells the story of the HOLC maps. Between 1935 and 1940, HOLC staff graded city neighborhoods with help from local bank loan officers, real estate agents and appraisers, the people whose job is to judge what a property is worth. Each neighborhood got a grade from A, "Best," down to D, "Hazardous," and the staff shaded the D neighborhoods red. Refusing loans in a neighborhood came to be called redlining, after those red areas.

FHA officials used a rating system of their own. They too rated neighborhoods where Black people lived "D," and they usually refused to insure loans there. The story of Clyde Ross, in 1950 to 2000, shows what that meant for one family.

### Depression households

Families changed who lived together under one roof during the Great Depression. Couples waited to marry: there were 10.1 marriages each year for every 1,000 Americans in 1929, and 7.9 by 1932. For the first time in US history, parents had too few babies to replace their own generation.

Families doubled up in one home. Young married couples moved back in with their parents, and old parents moved in with their grown children. By 1940, 1.5 million married women lived apart from their husbands.

**One room in Bronzeville.** In Chicago, Black families who had moved north from the South settled in a South Side neighborhood called Bronzeville. Chapter 6 describes the restrictive covenants, written agreements not to sell or rent to Black people, that white owners signed on many other blocks. Because of those agreements, Black Chicagoans were limited mostly to the Black Belt, an area between 12th and 79th streets on the South Side that took in Bronzeville.

Landlords there split apartments into one-room units called kitchenettes and charged very high rents for them, and Bronzeville held more than 80,000 of them. A whole family lived in one room and shared a bathroom down the hall with everyone else on the floor.

Some buildings had no proper heat. Families lit kerosene lamps, and the stoves they rigged up often overheated and started fires. In one year, about 751 fires broke out in the Black Belt. The writer Richard Wright recorded this life in his 1941 book *12 Million Black Voices*.

### Expert advice, and parents' letters about hitting

Many parents of the 1920s and 1930s began to take advice from experts on child development and psychology, the study of the mind and of how people behave. John B. Watson's 1928 book, *Psychological Care of Infant and Child*, sold 100,000 copies within months.

Watson told parents: "Never hug and kiss them. Never let them sit in your lap." He went on: "If you must, kiss them once on the forehead when they say goodnight." He advised them to "shake hands with them in the morning."

**Letters about hitting.** Parents wrote to Angelo Patri, a popular expert on raising children, for advice from 1924 to 1939. In 2004 three researchers published a study of 147 of these letters that mentioned corporal punishment, hitting a child as a punishment. Most came from middle-class parents.

The parents wrote more about how useful hitting was than about a child's right to be kept safe from harm. The reasons they gave most often were that the child had disobeyed or been rude. One letter in four described an argument about hitting with another adult close to the family.

### The teenager, and the war at home

A new word for a stage of life came into use in these years: teenager. More children stayed in high school instead of going to work, and that is part of why people began to see the teenage years as a stage of their own.

Writers had printed "teen ager," as two words, as early as 1913. A 1941 article in *Popular Science* printed it with a hyphen, as "teen-agers," and this is usually named as the first time it appeared in print as one word rather than two. The word spread in the late 1940s, when advertisers used it to sell goods to young people.

**The war at home.** During the Second World War, individuals and families moved to cities with war factories to take well-paid jobs, and more Americans moved from one part of the country to another than in any earlier period. Richmond, California, grew from fewer than 24,000 people to more than 100,000 during the war.

Six million women worked in war-industry jobs that women had not held before. At home, federal officials limited how much of twenty kinds of goods each family could buy, and families shopped with ration books.

### The Baldizzi family

> **Who:** A Sicilian immigrant family who lived through the Great Depression in a tenement flat. Museum staff later rebuilt their apartment from the daughter's memories.
>
> **When and where:** 97 Orchard Street, New York, 1928 to 1935.

**Their apartment was rebuilt from what one daughter remembered.**

Adolfo and Rosaria Baldizzi raised their children, Josephine and Johnny, in a flat at 97 Orchard Street from 1928 until 1935. Adolfo had come to the United States from Palermo, in Sicily, in 1923. He was a trained woodworker who made fine furniture, but during the Depression he could find only odd jobs.

Rosaria sewed the linings into coats in a garment factory. In the evenings the family sat at the kitchen table to play cards and listen to the radio. Adolfo built a corner cabinet himself.

**Forced out.** New York City officials required owners of old tenements to make costly repairs, such as fireproofing, in 1934 and 1935. The owner of 97 Orchard Street chose to empty the apartments rather than pay for the work. The owner evicted the families who still lived there, which means the owner forced them to leave.

Next the owner boarded up the upper windows and sealed off the floors where people had lived, and the Baldizzis had to move. The museum's accounts of the family do not name the owner.

After the Tenement Museum was founded in 1988, Josephine Baldizzi came back to 97 Orchard Street and recorded hours of memories of her childhood there. Museum staff rebuilt the family's apartment from what she remembered.

### Theodore and Patricia Bladykas

> **Who:** The first family to move into Levittown, with their 14-month-old twin daughters, Patricia Ann and Betty Ann.
>
> **When and where:** October 1, 1947, 67 Bellmore Road, Levittown, Long Island, New York.

**Levittown's lease allowed only white families, and servants of any race.**

Theodore and Patricia Bladykas were the first family to move into a house in Levittown. They moved in on October 1, 1947, with their twin daughters, Patricia Ann and Betty Ann, who were 14 months old. A photographer from the newspaper *Newsday* took their picture that day, when the first 300 families moved into Levittown.

Chapter 6 tells how the company Levitt and Sons, run by William Levitt, built Levittown. The first houses rented for 60 dollars a month, and a renter could buy the house for 7,500 dollars after a year. From 1949 the company sold ranch houses, long, low houses of one story, for 7,990 dollars. Many of the fathers who moved in were veterans just back from the Second World War.

**Clause 25.** William Levitt and his company rented and sold these houses to white families only. Clause 25 of the Levittown lease, the paper that set the rules for renting, stated that no "person other than members of the Caucasian race," meaning no one who was not white, could live in the house. The one exception was for servants: a white family could employ servants who were not white, and those servants could live with the family in the house.

The justices of the US Supreme Court ruled in 1948, in the case *Shelley v. Kraemer*, that courts could not enforce rules like this. William Levitt dropped the written clause and kept refusing to sell to Black families. His sales contracts forbade buyers to resell their houses to African Americans.

He said that if a Black family bought a house in Levittown, white families would stop buying there. He told the *Saturday Evening Post* in 1954: "We can solve a housing problem, or we can solve a racial problem. But we cannot combine the two."

**If you remember one thing:** Running water, electric wires and long home loans reached most American families between 1900 and 1950, and FHA officials usually refused to back loans in the neighborhoods where Black families lived.

- In 1890, 24 of every 100 households had running water and 8 had electricity.
- In 1950, 83 of every 100 had running water and 94 had electricity.

**Next:** The suburbs grow after 1950, and a crowd attacks the house of the first Black family in Levittown, Pennsylvania.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 8 minutes**

A house in the suburbs became the common picture of American family life after 1950. The share of households that owned their home rose from 43.6 of every 100 in 1940 to 61.9 in 1960. Lenders and sellers kept Black families out of many of the new suburbs, and in Levittown, Pennsylvania, a mob attacked the house of the first Black family to move in.

Inside the house, families planned their evenings around the new television set. Later in the century, more mothers took paid jobs, the divorce rate more than doubled and some parents began to teach their children at home.

### Who got to move to the suburbs

Some 76 million babies were born in the United States between 1946 and 1964, the years people call the baby boom. Builders put up more towns like Levittown, including a second Levittown in Pennsylvania from 1952.

Builders, sellers and lenders went on with redlining and whites-only sales for many years after the 1948 Supreme Court ruling. Activists campaigned against these practices. In 1968 members of Congress passed the Fair Housing Act, which made it against the law to refuse to sell or rent a home to someone because of race.

### The TV in the living room

Most American families bought their first television set in the 1950s. About 9 of every 100 households had a set in 1950, 64.5 had one by 1955, and 87 by 1960.

### The household changes shape

The divorce rate more than doubled between 1960 and 1980, from 9.2 divorces each year for every 1,000 married women to 22.6. The rate reached its peak in 1981 and then began to fall.

More mothers took paid jobs. In 1948, about 17 of every 100 married mothers were in the labor force, which means they worked for pay or were looking for paid work. By 1985 the figure was 61 of every 100, and by 1995 about 70. With both parents at work, more families paid for day care.

**Latchkey children.** Some children went home after school to an empty house. People called them latchkey children, because they carried their own key to the house.

The counts of them differed widely. Census Bureau researchers found about 2.1 million children aged 5 to 13 regularly home alone in a 1987 study, while advocacy groups, which campaign for a cause, estimated 6 to 7 million. In the fall of 1995 Census Bureau workers counted 6.9 million children aged 5 to 14, or 18 of every 100, who regularly looked after themselves, on average six hours a week.

### School comes home

Some parents began to teach their children at home in the 1970s and 1980s instead of sending them to school. Homeschooling had two separate starting points. John Holt wanted to change how schools taught, and he started a newsletter called *Growing Without Schooling* in August 1977. On the religious side, Raymond Moore argued for keeping young children at home in his 1981 book *Home Grown Kids*.

**Taught in secret.** In many states, homeschooling was against the law, or nearly impossible to do legally, into the 1980s. Most state laws of the 1970s did not say whether it was allowed, and many families taught their children in secret.

A judge in a Massachusetts court ruled in 1978 that homeschooling was legal if the parents were able to teach, covered the required subjects and showed that the children were learning. Over the next fifteen years, judges in other states ruled that homeschooling was legal, each state with its own rules.

In most homeschooling families the mother did the teaching, and many mothers stayed home to do it. Families also met in homeschool groups.

### Daisy and William Myers

> **Who:** The first Black family in Levittown, Pennsylvania: a war veteran, a teacher and their three small children, who stayed in their house while crowds attacked it.
>
> **When and where:** 43 Deepgreen Lane, Levittown, Pennsylvania, from August 13, 1957, to 1961.
>
> **Movie:** *Crisis in Levittown* (1957), a documentary by Lee Bobker and Lester Becker, filmed while the events were happening.

**Crowds of up to 1,000 people stood outside their new house.**

William and Daisy Myers and their three small children moved into 43 Deepgreen Lane in Levittown, Pennsylvania, on August 13, 1957. They were the first Black family to live in Levittown. William had served in the Army in the Second World War, and Daisy was a teacher. Lewis Wechsler, a white Jewish friend, helped them arrange to buy the house.

**The crowds.** Crowds of 200 to 1,000 people gathered on Deepgreen Lane for more than a week. People in the crowds threw rocks through the windows of the house and threw Molotov cocktails, bottles filled with fuel and set on fire. They burned crosses, one of them at the Wechsler house.

Members of the Ku Klux Klan, a group whose members bombed and attacked Black Americans, had used burning crosses as a threat for decades, to make the people who saw them fear they would be attacked. The account of the attacks on Deepgreen Lane does not say who in the crowds burned the crosses there.

Callers threatened the family by telephone. Milk, bread and oil stopped coming to the house, and the family's fire insurance was canceled. On the seventh night more than 500 people gathered before state troopers, the state police, broke up the crowd.

**Who organized it.** Members of the Levittown Betterment Committee passed around a petition, a paper that many people sign to ask for something, against letting Black families live in Levittown. The committee's members also organized the harassment of the family, the steady stream of acts meant to frighten them. A judge ordered the Betterment group to stop.

Pennsylvania Governor George Leader sent the state police, and after about six weeks the troopers had ended the open violence. A court found two people guilty of burning the cross on the Wechsler lawn.

Neighbors, church members and Quaker families, members of the Christian church called the Society of Friends, brought the Myers family food and flowers. The family stayed in the house until 1961, when they moved to York, Pennsylvania. Daisy Myers told the story in her memoir *Sticks 'n Stones*, a book about her own life published in 2005.

**Not known:** who stopped the deliveries, which company canceled the insurance, and who the two people found guilty were. The Baltimore Sun's 1997 account names none of them.

### Clyde Ross

> **Who:** A Second World War veteran and soup-factory worker who could not get a mortgage and bought his Chicago house on contract.
>
> **When and where:** North Lawndale, on Chicago's West Side, from 1961.

**Miss one payment, and he would lose the house and every dollar.**

Clyde Ross was born in 1923 near Clarksdale, Mississippi. In the Second World War he was drafted, ordered into the armed forces, and he served on Guam. He moved to Chicago in 1947 and took a job as a taster at Campbell's Soup.

**No loan.** Ross tried to get an ordinary mortgage for a house in another neighborhood. A loan officer told him there was no money to lend, and the records do not name the officer or the bank. FHA officials, using a rating system of their own, rated neighborhoods where Black people lived "D" and usually refused to back loans there.

**The contract.** Ross bought a house in North Lawndale in 1961 for 27,500 dollars. The seller was a speculator, a person who buys property to sell it again at a profit, and had paid 12,000 dollars for the house. Ross bought on contract: the seller kept the deed, the paper that shows who owns a house, until Ross made the last payment.

If Ross missed a single payment, he would lose his 1,000-dollar down payment, every monthly payment he had made, and the house. The journalist Ta-Nehisi Coates cited one estimate that 85 of every 100 Black families who bought homes in Chicago bought them on contract.

**The strike.** Ross joined the Contract Buyers League, a group of Black homeowners on Chicago's South and West Sides, in 1968, and became its vice president. About 500 families in the league stopped making their payments together, as a strike against the contracts. By July 1971 the league and the sellers had worked out new terms for 155 contracts, saving each family an average of 14,000 dollars.

About 70 league families lost their homes to eviction, and the Chicago Reporter's account does not name who had each family put out. The league also took its fight to court and lost. Coates wrote that the league lost a jury trial in 1976. The Chicago Reporter says its last appeal, its last request for a higher court to change the ruling, was turned down in 1983.

Coates told Ross's story in *The Atlantic* magazine in 2014. Ross was 91, and he still lived in the house and owned it.

**Disputed:** the year and the price. Coates gives 1961 and 27,500 dollars, and a 2014 account on BillMoyers.com gives 1958 and 27,000 dollars.

### David and Micki Colfax and their sons

> **Who:** Parents who built their own house on a ranch in California and taught their four sons at home.
>
> **When and where:** Near Boonville, Mendocino County, California, from 1973.

**Three sons taught at home on a California ranch went to Harvard.**

David and Micki Colfax taught their four sons at home on a ranch in California, where the family built its own house. Their eldest son, Grant, started public school in St. Louis, but after six weeks his parents took him out, because they found the lessons "very rote and uncreative," rote meaning learned by repeating things over and over.

The family moved to land near Boonville, in Mendocino County, California, in 1973. The land, 40 acres by the Harvard Crimson's count or 50 by the Anderson Valley Advertiser's, had no house, no electricity and no running water. Everyone, the young sons included, helped build the house, the barns and the sheds. The family raised goats, sheep, chickens and pigs and sold them to restaurants in San Francisco.

Lessons fit around the work of the ranch. "Some days we did a lot of homework, some days we had none," Reed Colfax said later. "It depended on the weather and what had to be done on the ranch." The boys studied four or five days a week, summers included.

Grant, Drew and Reed went on to Harvard University and graduated in 1987, 1990 and 1992. The youngest son, Garth, was still being taught at home in 1989, a year when about 500,000 American children were taught at home by their parents, by a count reported in *The Harvard Crimson*. David and Micki Colfax wrote a book about their method, *Homeschooling for Excellence*.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 6 minutes**

The median new American house grew to 2,467 square feet by 2015, while the average household shrank to 2.50 people by 2025. In the crash that began in 2007, lenders took back millions of homes from families who could not pay their loans. During the pandemic of 2020, many homes became an office and a school at the same time.

### More house, fewer people

The median new house built for one family, the one in the middle when all are ranked by size, grew from 983 square feet in 1950 to a peak of 2,467 square feet in 2015, by Census Bureau figures. That is about two and a half times as large. Over many of the same years, households shrank: the average household held 3.67 people in 1940 and 2.50 people in 2025.

The kinds of households changed too. In 2025, 29 of every 100 households were one person living alone, up from 20 in 1975, and married couples made up 47, down from 66. That year 58 of every 100 young adults aged 18 to 24 lived in their parents' home.

The Census Bureau counted 65 of every 100 households as owning their home in the second quarter of 2026, the months of April, May and June.

### How millions of families lost their homes, 2007 to 2010

Lenders foreclosed on about 3.8 million homes between 2007 and 2010. Estimates for the whole crisis run from about 7.7 million to 10 million homes lost, because researchers counted in different ways. Federal Reserve History, a website of the country's central bank, and the Federal Reserve Bank of Chicago list these figures.

**The loans.** In the years before the crash, lenders made many subprime loans, which cost more and went to borrowers with weaker credit, a weaker record of paying back debts. Because the loans cost more, the monthly payments were bigger.

While house prices kept rising, a borrower who fell behind could sell the house and pay off the loan, or borrow more against the higher price. When prices stopped rising, neither way out worked. Borrowers who could not pay fell further behind, and lenders foreclosed on their homes.

Reporters at the Center for Public Integrity, a news organization, ranked Countrywide Financial the largest subprime lender of 2005 to 2007 in a 2009 report. They found that Countrywide made at least 97.2 billion dollars in high-interest loans in those years. Angelo Mozilo founded the company and ran it for 39 years.

Foreclosure filings, the papers a lender files to start taking back a home, reached their peak in 2010, at nearly 2.9 million homes. In 2025 there were 367,460, according to ATTOM, a private company that collects property records.

More Americans came to live in households of several generations, such as grandparents, parents and children together. Researchers at the Pew Research Center, which studies American life, counted 7 of every 100 Americans in such households in 1971, and 18 of every 100, or 59.7 million people, in 2021. The number grew faster during the years of the crash than in the years before. When Pew asked people in these households why they lived that way, money was the reason they gave most often.

### How many people have no home?

Each January, local volunteers count the people who are homeless on a single night, and officials of the US Department of Housing and Urban Development (HUD), the federal housing department, report the count. The volunteers counted 771,480 people in January 2024, the highest number on record and 18 percent more than a year before.

HUD's report named several likely causes: a shortage of homes people could afford, rising prices, pay that did not keep up for families with middle and low incomes, and the lasting effects of racism. Homeless people in families with children rose 39 percent that year. In 13 communities where many newly arrived immigrants had gone into shelters, family homelessness more than doubled. The next count, in January 2025, was a little lower, at 745,652 people.

### 2020: office and school at once

Many homes became a workplace and a classroom at once in 2020. The share of workers who worked mainly from home tripled, from 5.7 percent in 2019 to 17.9 percent in 2021, by the Census Bureau's count.

Homeschooling rose too, meaning that the family taught the children, not that teachers at a school taught them online. By the fall of 2020, 11.1 percent of households with school-age children were homeschooling, about twice the share that spring.

Many children did their schoolwork online, and some homes had no broadband, the fast home internet used for online classes. Pew researchers reported that 35 percent of households with children and incomes under 30,000 dollars a year had no broadband, against 6 percent of households with incomes over 75,000 dollars.

**Not known:** how much of the rise in learning at home lasted. In a later federal survey, parents reported that about 5 of every 100 children learned at home in 2022-23, against about 4 before the pandemic, but that survey asked different questions from the one in 2020.

### Pierre Solon and Katty Familia

> **Who:** Immigrant parents, from Haiti and the Dominican Republic, who lost their Boston house to foreclosure.
>
> **When and where:** Hyde Park, Boston, Massachusetts, about 2006 to 2010.

**Bought for 584,000 dollars, sold at auction for 115,000.**

Pierre Solon, from Haiti, and Katty Familia, from the Dominican Republic, bought a green wooden house in Boston's Hyde Park neighborhood in about 2006 for 584,000 dollars. They borrowed the whole price from Fremont Investment and Loan, a subprime lender, as two mortgages, two separate loans on the same house. Their lawyer, Nadine Cohen of Greater Boston Legal Services, said the payments on the two loans were almost 5,000 dollars a month more than the couple earned.

Each parent worked two jobs, and then each lost one. "Sometimes we don't even have food," Katty Familia said. The couple fell more than 150,000 dollars behind.

Staff at Wells Fargo, the bank that collected their payments, offered lower monthly payments. The couple turned the offer down, because the change would have raised what they owed to more than 600,000 dollars. Wells Fargo's staff then foreclosed, and late in 2009 the family moved out with their children.

**The sale.** Wells Fargo sold the house at auction, a sale where the highest bidder wins, in November 2010. The buyer was an investor, a buyer who hopes to sell later for more, and the price was 115,000 dollars. Two weeks later that investor sold it to another investor for 270,000 dollars.

The Massachusetts Attorney General, the state's top lawyer, sued Fremont for deceptive lending, lending by misleading borrowers. Fremont sold its loans to investors, then went bankrupt, unable to pay its debts, and closed.

The couple ran a day care center in Boston in 2010. "I worked 20 years in this country for this," Katty Familia said. The reporter Anthony Brooks told their story on the radio program *Morning Edition*, on NPR, in December 2010.

### The Munoz family

> **Who:** A Las Vegas family whose four school-age children did school online at the dining room table while both parents went out to work.
>
> **When and where:** Las Vegas, Nevada, August 2020.

**"It was a challenge because we couldn't log in."**

Four of the five Munoz children in Las Vegas, Nevada, started the school year in August 2020 on laptops at the dining room table. Both parents worked in the food industry, away from home. While they were at work, the family's 10th-grade son helped the younger children: a fourth-grader with reading and a new middle-schooler with writing. When he had trouble, he emailed the teachers.

The father, Johnathan Munoz, recorded the family's first week as an audio diary for NPR's radio program *Weekend Edition Sunday*. On the second day he said, "it was a challenge because we couldn't log in." The middle-schooler said that one teacher kept marking her absent, and another teacher did not allow a brother or sister to be seen in the background.

**The three questions, answered**

- Who lived together under one roof, from the longhouse to today? A longhouse held 30 to 60 relatives, and colonial households held servants, apprentices and enslaved people too. By 2025 the average household held 2.50 people.
- Who did the work of keeping house, and did stoves, pipes and wires make it lighter? Women and children did most of it. In Ruth Schwartz Cowan's argument, the machines did not cut a housewife's hours, because families expected more.
- How did lenders and builders keep Black families out of new neighborhoods, and what did those families do? FHA officials usually refused to back loans where Black families lived, and William Levitt sold only to white families. The Myers family stayed through weeks of attacks, and about 500 families in the league Clyde Ross helped lead stopped paying together.

**What changed:** Households shrank from longhouses of relatives to 2.50 people, and owning a home came to depend on long loans that lenders gave some families and refused others.

**Whose land:** The colonists' and settlers' houses in this chapter went up on Native land, from Plymouth, built on the Wampanoag village of Patuxet, to the Ingalls family's dugout on land the Dakota signed away in 1851.

**Five dates to keep**

- September 1565: Spanish colonists settle inside Seloy's town.
- 1841: Catharine Beecher's book on running a home.
- November 1, 1879: Richard Henry Pratt opens the Carlisle school.
- October 1, 1947: the first families move into Levittown.
- 1968: members of Congress pass the Fair Housing Act.

**Not known:** No record counts how many Timucua died of disease in the 1500s alone.

**Where to go:** The Tenement Museum, 97 Orchard Street, New York, where staff rebuilt the Baldizzis' apartment from Josephine's memories.

**Next:** Chapter 8, Technology. It asks whose names went on American inventions and who did the hard work around them.
