# Chapter 35: Styles

**Chapter 35 of 37 · Styles · 10 eras · about 100 minutes**

**From the first colonial dress laws to the CROWN Acts, laws against punishing people for their natural hair, Americans with power made rules about who could wear what, and much of the cloth came from people who were enslaved, held captive or paid by the piece.**

Hannah Lyman was about 16 when the judges of the Hampshire County court in Northampton, Massachusetts, fined her 10 shillings for wearing silk. The year was 1676. Massachusetts lawmakers had passed laws saying who was allowed to wear silk, lace and "great boots." The charge against Hannah said she wore her silk "in a flaunting manner," and that she wore it "not only before, but when she stood presented." She wore silk even while she stood charged before the court.

This chapter follows what Americans wore, and what it was made from, through all ten eras, from turkey-feather blankets to sneakers. It also looks at furniture in two eras, because styles changed in American homes too. As you go, watch who made the rules, such as the Massachusetts judges who fined people for wearing silk. Watch, too, who made the cloth: enslaved people in the cotton fields and indigo vats, and women sewing in Bangladesh and Los Angeles.

**Three questions this chapter answers**

- Why did lawmakers and officials make rules about other people's clothes and hair?
- Who made the cloth Americans wore?
- Which new materials changed what Americans wore?

**Five minutes?** Read "Cotton picked in the South, woven in the North" in 1800 to 1850, and the section after it.

**Can skip:** "Wigs in Williamsburg, 1769 to 1775", "The Federal style, 1780 to 1820", "Shirtwaists and the Gibson Girl, 1890s". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 5 minutes**

The people of North America before 1500 dressed in what they could grow, hunt or get by trade. They wore deer hide, rabbit fur and turkey feathers, and cloth woven from cotton and from the fiber of the yucca, a desert plant. Their ornaments were sea shells from the Gulf of Mexico and copper from the country around Lake Superior. Their colors came from plants and from a mineral called red ochre.

No written record names anyone who wove this cloth or wore these beads. Archaeologists, scientists who dig up and study the things people left behind, have found the cloth, the feathers, the beads and the copper. What is known comes from those objects.

### How many feathers went into one blanket?

A blanket made in the 1200s used about 11,550 turkey feathers, pulled from 4 to 10 turkeys. Its makers wrapped the feathers around more than 590 feet (180 meters) of cord twisted from yucca fiber. The blanket is kept at the Edge of the Cedars State Park Museum in southeastern Utah.

Its makers were Ancestral Puebloan people, the ancestors of today's Pueblo peoples. They lived in the Four Corners, the place in the Southwest where Utah, Colorado, Arizona and New Mexico meet. Most of their clothing was deer hide, rabbit skin and yucca fiber.

Bill Lipe and Shannon Tushingham, researchers at Washington State University, studied the blanket. In 2020 they reported that the makers probably pulled most of the feathers from live birds. In this region, feather blankets had replaced blankets made from strips of rabbit fur many centuries earlier.

**Cotton.** Cotton came north by trade from Mexico. The oldest farmed cotton found in the Tonto Basin of Arizona dates to about the year 250, and cotton reached the Four Corners around 600. By about 900, Ancestral Puebloan men were growing cotton, spinning it into thread and weaving large cloths and blankets on upright looms, frames that hold threads tight so a weaver can pass other threads over and under them.

The Salado people lived in the Tonto Basin from about 1250 to 1450, and by about 1300 their basin was one of the leading cotton-growing areas of the Southwest. They wove plain cotton cloth and openwork cloth, with small openings left in the weave as a pattern. They made blankets from strips of worn-out cotton cloth. One brightly dyed strap they wove is a tumpline, a band worn across the forehead to carry a load on the back. Their sandals were woven from agave and yucca, two desert plants.

### Shell and copper along the Mississippi

Cahokia was a city of earth mounds in Illinois, a few miles east of the Mississippi River and today's St. Louis. Its people traded for copper from the Lake Superior region and for sea shells from the Gulf of Mexico. Archaeologists call the way of life of Cahokia and the towns like it the Mississippian culture.

Mississippian metalworkers heated copper, hammered it while the heat kept it soft, let it cool, and did the same again and again, a way of working metal called annealing. They made hair ornaments, pieces for headdresses and flat plates.

**The bird-man.** Some plates show a figure that is part bird and part man, pushed out by hammering from the back of the sheet. Artists at Cahokia began making pictures of this bird-man between 1100 and 1300. Mississippian copper plates were made from about 800 to 1600, and they have been found from Florida and Georgia to Oklahoma and Wisconsin.

At Cahokia, archaeologists found a copper workshop with raw copper nuggets, scraps of worked copper and stone tools for working it.

**A bed of shell beads.** People at Cahokia buried a man and a woman in the 1000s on a bed of shell disc beads laid out in the shape of a bird. The beads were made from sea shells. The magazine *Archaeology* gives the count as 20,000 beads, and another published count gives about 10,000.

Melvin Fowler dug up this burial in a mound called Mound 72 between 1967 and 1971, and he described both bodies at the center as men. In 2016 a team led by Thomas Emerson of the Illinois State Archaeological Survey studied the bones again. They found that the two were a man and a woman, with other pairs of a man and a woman buried around them.

Mound 72 holds about 272 people, buried at different times over about a century. Archaeologists judge that almost 62 percent of them were sacrifices, people whom others at Cahokia killed on purpose as part of the burial ceremonies. No written record names them or the people who killed them.

### Colors from plants and earth

Ochre is a mineral made of iron and oxygen, and it can be brown, red or yellow. Red ochre is the red kind. Accounts written after Europeans arrived say that the Karankawa people of the Texas coast painted symbols on their faces with ochre, using their fingers or the stalks of plants. The Karankawa got their ochre by trade from inland. At a burial site called Mitchell Ridge, red ochre stains the bones of 18 people.

Native people of North America decorated clothing with porcupine quills, the stiff, hollow spines that cover a porcupine, before Europeans arrived. The Huron, Cheyenne, Arapaho, Cree and Gwich'in were among the nations that did quillwork. Men hunted the porcupines, and women did the work. They flattened the quills with an awl, a pointed tool, or with a piece of bone, then dyed them and sewed them onto moccasins, pouches, baby carriers and clothing.

**The dyes.** Red came from the bark of the tamarack tree, from spruce cones and from berries, and black from walnuts and wild grapes. For yellow, quillworkers used wild sunflower, pine bark or willow root. Blueberries and larkspur, a flower, made blue. Writers at the Penn Museum in Philadelphia list these dye plants. The museum's own quilled pieces date from the 1830s and later, and among the oldest are pieces that George Catlin collected between 1832 and 1839. Quillwork itself is much older, from before Europeans arrived.

## The 1500s

**Era 2 of 10 · The 1500s · about 5 minutes**

The first written descriptions of what Native people wore come from the Spanish, French and English explorers and soldiers who arrived in the 1500s. They wrote down deerskin, cloth of bark fiber and feathers, and ornaments of pearls. Some of them took what they found. Hernando de Soto's soldiers dug up Native graves at the town of Cofitachequi in 1540 to take the pearls buried there.

Spanish colonists drove churro sheep into New Mexico in 1598, onto the land of the Pueblo peoples. Wool from those sheep went into Native, Spanish and Mexican weaving for about 300 years.

### Cloth and pearls at Cofitachequi, 1540

Hernando de Soto's army reached Cofitachequi, a Native town beside a river in the Southeast, in May 1540. A Portuguese man who marched with the army wrote an account of the march, printed in Portugal in 1557. His name is not known, so he is called the Gentleman of Elvas, after the Portuguese town of Elvas. He described what the people of the town wore and what they kept.

A woman ruled the town. No record gives her own name, and the Spanish called her the Lady of Cofitachequi. She crossed the river by canoe to meet de Soto and gave him mantles, or cloaks, and deerskins. Then she took a long string of pearls from her own neck and put it around his. He gave her a gold ring set with a ruby.

Elvas wrote that the town's storehouses held mantles woven from yarn made of tree bark. Other mantles were made of feathers colored white, green, red and yellow, and people wore them in winter. The storehouses also held deerskins with many panels drawn on them, and some of the deerskins had been made into leggings, stockings and shoes. Elvas wrote that everyone in the town wore shoes and clothes.

**The graves.** De Soto was looking for treasure. According to Elvas, the ruler told him to search the town's graves for pearls, because she had seen how much the Spaniards valued them. De Soto's men dug up the graves. They took the pearls, and small figures of babies and birds made from pearls.

The accounts disagree on how many pearls the men took. They give weights from about 200 pounds, about the weight of a large man, to 392 pounds.

In the same town, de Soto's men found a dagger and beads. They came from a colony that Lucas Vázquez de Ayllón had started in 1526 on the coast of today's South Carolina or Georgia. Ayllón died there, and the surviving colonists left within about two months.

De Soto then took the ruler with him as a prisoner, guarded by enslaved women. On the march she told her guards she needed to relieve herself. She walked into the woods and escaped, carrying off a cane box full of pearls that had not yet been drilled.

### What an Algonquian leader wore, 1585

The English painter John White painted Native people who spoke Algonquian languages, a large family of related languages, in 1585. Thomas Hariot wrote the words that went with the pictures. One painting shows a leader of one of these peoples, dressed for a great hunt or a feast. He wears an apron of animal skin with a fringe, and a tail hangs down behind it. His quiver, the case that holds his arrows, is tied to the tail.

Feathers decorate his hair. One side of his head is shaved. Hariot wrote that the shaving kept the hair from tangling in the bowstring.

### Spanish clothes in St. Augustine, 1565 to 1600

Spanish soldiers and settlers founded St. Augustine, in Florida, in 1565, on land where the Timucua people lived. Archaeologists from the Florida Museum have dug up many of the things the colonists wore. Rich residents wore costly cloth trimmed with metal lace, buttons, beads and metal ornaments. Buttons were worn mostly by soldiers and the rich.

Most people tied their plain clothes shut with laces. Each lace had a small metal tip, called an aglet, so it could pass through a hole. Many soldiers in the town married Native women.

**A widow's bed.** Juan de Cevadilla was the official in Mexico who collected the pay for the soldiers of St. Augustine. He died suddenly in 1590 and left his widow, Doña Petronilla (Doña is a Spanish title of respect for a woman), a carved bed covered with a thin layer of gold. Over the bed hung a cloth roof, called a canopy, made of taffeta, a smooth silk cloth, from China, with designs stitched into it. He also left her a large amount of costly cloth and clothing.

### Churro sheep and red from Mexico

Juan de Oñate led Spanish colonists north from Mexico onto the land of the Pueblo peoples in New Mexico in 1598. They came on the road called El Camino Real de Tierra Adentro, the Royal Road of the Inland Country, and they brought churro sheep, a Spanish breed. By the 1700s the churros in New Mexico numbered in the hundreds of thousands. For the next 300 years their wool was the base of Native, Spanish and Mexican weaving there.

Before the sheep came, Pueblo weavers worked in cotton on upright looms. The Spanish brought a loom that lay flat on the floor. Weavers in New Mexico later used it to make Rio Grande blankets and serapes, blankets that can be worn as a cloak. After the Spanish brought churro wool and new dyes, wool became the main thread for weaving there, and the old Pueblo cotton weaving declined.

**Cochineal.** Far to the south, in Oaxaca, Puebla and Tlaxcala in Mexico, Native people had long bred a small insect called cochineal to make red dye. As early as the 100s BC they used it to dye cloth and feathers and to color books painted by hand. After Spanish soldiers conquered Mexico, traders carried cochineal around the world. Native Mexicans still did all the skilled work and all the labor of making it. Writers at Harvard's science museums note that they were never given credit for it.

## The 1600s

**Era 3 of 10 · The 1600s · about 10 minutes**

Lawmakers in the English colonies of the 1600s wanted clothes to show who ranked above whom, and in Virginia and Massachusetts they wrote laws to keep it that way. In Massachusetts, a person whose property was worth less than 200 pounds was not allowed to wear silk hoods, gold or silver lace, or boots called "great boots." Judges in the county courts fined people who did. Lists of belongings made after New England colonists died record clothes in red, blue, violet, grey and green, as well as black.

In New Mexico, Spanish soldiers and colonists demanded a woven cotton blanket from each Pueblo household every year. This was tribute, a payment that conquerors force a conquered people to make.

### Virginia taxes clothing, 1619

The General Assembly of Virginia, the colony's lawmaking body, met for the first time on July 30, 1619. At that meeting its members passed a law "against excesse in apparel," meaning too much spending on clothes. They voted that each man's share of all public costs, collected through the church, would be set by his clothes. An unmarried man paid according to his own clothes. A married man paid according to his own clothes and his wife's.

A Virginia resolution of 1621 states the aim to "supress excess in cloaths." Under it, men who held no office in the colony could not wear gold in their clothes.

### Mary Ring

> **Who:** A widow of Plymouth Colony whose list of belongings shows the colonists there dressed in red, violet and blue.
>
> **When and where:** Leiden in Holland, then Plymouth Colony, 1629 to 1631.

**Her red petticoat was worth 16 shillings.**

Mary Ring owned two petticoats, the skirts women wore, one red and one violet. She also owned two violet waistcoats, which were vests or short jackets, and three blue aprons. When she died, everything she owned was listed and given a value, in a list called a probate inventory. Hers gives values in pounds, shillings and pence, the English money of the time. Only one piece of her clothing was worth more than the red petticoat: a hooded cloak called a huke.

The inventory also lists a black kirtle, a kind of gown, and a waistcoat of "mingled coloured" cloth. It lists an apron in murrey, a dark purplish red, and pieces of blue cloth and red cloth. She owned blue stockings, white Irish stockings and a piece of grey kersey, a rough wool.

She also owned six ruffs, stiff pleated collars, and seven smocks, long linen shirts worn under the other clothes. She had three linen caps, two hats and two pairs of shoes. Her will left green cloth "to make a coat." Caleb Johnson wrote notes on her list for the Plymouth Colony Archive Project. He points out that it shows the English colonists of Plymouth wore violet, red, blue and grey as well as black and white.

**Who she was.** Mary Ring was the widow of William Ring, who died in Leiden, in Holland, in the 1620s. She came to Plymouth in 1629 or 1630 with her children Elizabeth, Susanna and Andrew. The English had built Plymouth in 1620 on the site of Patuxet, a town of the Wampanoag people. About 2,000 Wampanoag had lived in the area. Before 1620 a wave of sickness, now called the Great Dying, killed most of the people of Patuxet, and the few who lived left to join other Wampanoag towns.

She died on July 15 or 19, 1631. She signed her own will, and she owned books. Governor William Bradford and Edward Winslow owed her money when she died.

### Did the Puritans dress only in black?

The Puritan colonists of Massachusetts wore many colors, which they called "sad" colors, meaning serious rather than unhappy. A list from 1638 names some of them: liver color, tawny, russet, purple, French green, orange and "deer colour." The Puritans were English Protestants who wanted their leaders to strip the Church of England of the customs it still shared with the Catholic Church.

The historian David Hackett Fischer writes that black cloth was kept for the ruling elders, the men who led the church, and for the families who governed the colony. A portrait of Governor John Winthrop, painted in about 1629, shows him in black velvet with slashed sleeves, cut so that the cloth underneath showed through.

Lists of belongings and bills from the colony record "pinck hose," or pink stockings, "green sleeves," and "a Scarlet petticoat with Silver Lace." Fischer writes that Winthrop's own niece, Mary Downing, was scolded for wearing a little lace. His sentence about her does not say who scolded her.

### Massachusetts dress laws, 1634 to 1682

The General Court of Massachusetts Bay was the colony's body of lawmakers and magistrates, its chief officials and judges. Its members passed their first sumptuary law, a law that limits what people may wear according to their rank, in 1634. It banned "new fashions, or long hair," silver and gold hatbands and belts, cloth woven with gold thread, and lace.

It also limited the slashes in a sleeve. The magazine *Atlas Obscura* gives the limit as two slashes in a sleeve, and the historian David Hackett Fischer gives it as one. A person caught wearing these things had to give them up. A law of 1639 banned more kinds of lace and banned short sleeves.

**"Utter detestation."** The members of the General Court wrote in 1651 that they felt "utter detestation," or hatred, when "men or weomen of meane condition," meaning people of low rank, dressed like gentlemen. They named gold or silver lace, gold or silver buttons, laces tied at the knees and "great boots." For women of that rank they named silk hoods and silk scarves. Anyone whose property was worth less than 200 pounds owed a fine of 10 shillings each time he or she wore them.

Magistrates, officers, soldiers and their families did not have to obey this law. Neither did people who had once been rich and had lost their money. The lawmakers gave the selectmen, the elected men who ran each town, the power to tax people who dressed above their rank.

**In court.** Judges in the county courts enforced the law. Judges in Essex County heard 18 cases in 1653, and they let 12 of the people go because they were worth more than 200 pounds. Ten years later, in 1663, the lawmakers made the law cover children and servants too, and barred tailors from making the forbidden clothes. A first offense brought a warning, a second a fine of 20 shillings, and later offenses up to 40 shillings.

The judges of the Hampshire County court charged 35 married women from five towns with wearing silk at one session in 1673. They found all but one of the seven from Northampton not guilty, and they warned, fined or let go the women from the other towns.

**Whose land.** Northampton stood on the land of the Nonotuck people. John Pynchon got a deed, a paper that hands over land, from seven Nonotuck men, including Chickwalloppe, on September 24, 1653. He paid 100 fathoms of wampum, strings of shell beads, and 10 wool coats. A fathom is 6 feet. The historian Margaret Bruchac writes that the Nonotuck signers probably understood the deed as an agreement to share the land, and that they probably expected to keep their own right to hunt, fish and plant there.

**The war.** King Philip's War was fought in 1675 and 1676. Metacom, a leader of the Wampanoag whom the English called King Philip, led several Native nations against the New England colonies. About 9,000 people died in the war, and by some counts about half of all the Native people of New England died. A Native man fighting for the colonists shot Metacom dead on August 12, 1676. The colonists sold hundreds of Native captives into slavery.

During the war the Northampton minister Solomon Stoddard asked the colony's leaders to act against "that intolerable pride in clothes and hair." In November 1675 the members of the General Court passed a law listing the sins they said were common in the colony. A law of 1675 also lowered the fine for a second or later offense to 10 shillings.

**March 1676.** The Hampshire County judges heard charges against 23 people of Northampton, women and young men, on March 27, 1676, "for wearing silk in a flaunting manner and for long hair and other extravagances" (flaunting means showing off, and extravagances meant spending too much on show). They warned them all and made each one pay court fees of 2 shillings 6 pence, except the wife of Samuel Holton. She had offended before, so they fined her 10 shillings. That March the same judges fined 45 more people from four other towns for silk and long hair.

The five towns of Northampton, Hadley, Hatfield, Westfield and Springfield were themselves charged at the county court between about 1680 and 1682. Their selectmen had failed to tax residents who wore silk "beyond their ranks." James Russell Trumbull, who wrote the history of Northampton, reports that nothing more was heard of these charges.

### Hannah Lyman

> **Who:** A Northampton girl of about 16 who was fined for wearing silk, and who wore it even while she stood charged before the court.
>
> **When and where:** Northampton, Massachusetts, 1676.

**Her charge said she wore silk even on days set apart for prayer.**

Hannah Lyman of Northampton was about 16, and her father, Richard Lyman, had died. The charge against her said she wore silk "not only in ordinary times, but in extraordinary times, when the people of God were falling before the Lord in public humiliation." A day of public humiliation was a day when the people of the town prayed together and humbled themselves before God, because of "the heavy judgments and calamities that were threatening to come upon us."

Her case came to a later session of the county court than the one in March 1676. The judges fined her 10 shillings. The charge also said she wore silk "not only before, but when she stood presented," which means she kept wearing it even while she stood charged before the court.

Counts of the people charged in Northampton that year differ. The town's historian, James Russell Trumbull, who quoted the court records, gives 23 at the March session and Hannah at a later one. The magazine *American Heritage* and the historian David Hackett Fischer write that she was one of 36 young women of Northampton charged that year.

### Blankets taken as tribute in New Mexico

Some Spanish colonists in New Mexico, called encomenderos, held the right to collect tribute from Pueblo households after 1598. Researchers for the Beyond Origins of New Mexico Families project report that by the 1660s each household owed one fanega of corn in the spring, a fanega being a Spanish measure of grain. In the fall each household owed one woven cotton blanket, called a manta, or one hide. The Spanish king allowed no more than 35 encomenderos at a time.

Ginés de Herrera Horta was a Spanish legal officer in Oñate's colony. In 1601 he testified that soldiers demanded a blanket each year from each household. When people said they had no blankets to give, the soldiers took the blankets off the women who were wearing them and left the women naked. The Spanish records of these seizures give no names for the women whose blankets were taken.

Most of the Pueblo peoples rose up against the Spanish colonists in 1680, in the Pueblo Revolt, led by Po'pay of San Juan Pueblo. They killed about 400 Spaniards and forced about 2,000 settlers to flee New Mexico for about 12 years. Among the Pueblo people's complaints was the tribute of labor, ground corn and cloth that the colonists had forced them to hand over.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 7 minutes**

In the English colonies between 1700 and 1750, a wig showed that a man ranked near the top, and coarse cloth showed that a person was enslaved. The historian Thomas Ford calls the wig a badge of rank. A traveler in Maryland in the 1740s wrote that only a few men of the highest rank wore wigs, and that other men wore caps.

South Carolina's lawmakers wrote the coarse cloth into law in 1740. They named cheap fabrics and barred enslaved people from wearing anything finer. They ordered constables, local officers who kept order, and anyone else who found finer clothes on an enslaved person to take them away and keep them. In the 1740s South Carolina planters began growing indigo, a plant that gives a blue dye, in large amounts and shipping the dye to England. Enslaved people did the work of turning the leaves into dye.

### Who wore a wig?

Only a few men of "the very elevated Sort" wore wigs, a traveler in Maryland wrote in the 1740s. Ordinary men wore caps of wool or yarn. Better-off men wore caps of white linen or cotton, even on journeys of 50 miles.

A wig of this time was called a peruke. A wigmaker built it from rows of hair sewn onto a cap of net and ribbon, using human hair and also hair from horses, cows and goats. The historian Thomas Ford writes that a wigmaker preferred to measure a customer whose head was shaved, so the wig would fit. He calls the wig "an important badge of social rank."

Some rich men, including Councillor Robert Carter, a member of the governor's council, and Dr. John Sequeira, had enslaved men trained to shave them and to dress their hair. Ford writes that rich planters may sometimes have dressed their enslaved coachmen and house servants in white wigs.

### The 1740 clothing law in South Carolina

Enslaved people in South Carolina rose up against their enslavers in the Stono Rebellion in September 1739. On May 10, 1740, the lawmakers of the South Carolina assembly passed the Negro Act. Its full name was An Act for the Better Ordering and Governing Negroes and Other Slaves in this Province, and it used "Negroes," the lawmakers' word for Black people. Section 40 of the act was about clothes.

**What Section 40 said.** It began by claiming that "many of the slaves in this Province wear clothes much above the condition of slaves." The lawmakers said enslaved people got those clothes by "sinister and evil methods," meaning wrong and wicked ones. The section barred any owner from letting an enslaved person "have or wear any sort of apparel whatsoever, finer, other, or greater value" than the cloths it named. Servants in livery, a uniform the master chose, did not fall under this rule.

The list read: "Negro cloth, duffels, kerseys, osnabrigs, blue linen, check linen or coarse garlix, or calicoes, checked cottons, or Scotch plaids." All of them were cheap cloths, and many were coarse, which means rough and thick. Negro cloth was a coarse cloth made for enslaved people's clothes. Osnaburg, which the law spells "osnabrigs," was a plain cloth first woven from flax in the German city of Osnabrück. An earlier South Carolina act, passed in 1735, had already named cheap cloth for enslaved people's clothing.

**Who took the clothes.** The law required "all and every constable and other persons" to seize finer clothes from any enslaved person wearing them. The person who seized the clothes could keep them "to his or their own use." An owner who thought the clothes had been taken wrongly could take the matter to a justice of the peace, a local judge. The surviving records do not show how often anyone seized clothes under this law.

### Jack

> **Who:** A man taken from Gambia and enslaved in Virginia, who ran away within five weeks of his sale.
>
> **When and where:** Hanover County, Virginia, 1745.

**Within five weeks of his sale, Jack ran away.**

Slave traders brought Jack and another man from Gambia, in West Africa, on the ship *Ranger*. They sold the two men at Newcastle, Virginia, on September 5, 1745. Neither man spoke English, and both were nearly 6 feet tall.

Almost everything known about Jack comes from an advertisement that his owner, Margaret Arbuthnott of Hanover County, placed in the *Virginia Gazette* in October 1745 to get him back. The advertisement does not name the traders. Arbuthnott described Jack as having a scar over his right eyebrow. The other man, whose name she did not give, had what she described as "3 small Strokes on each Side of his Face."

The two men ran away in new jackets and in breeches, short pants that ended at the knee. Both were made of napped cotton, brushed so that its surface was soft and fuzzy, with no buttons and no buttonholes. The men also wore shirts of osnaburg and felt hats.

Arbuthnott accused the two men of taking a damask tablecloth, its pattern woven into the cloth, along with fine Scottish linen, checked cloth, a white linen shirt and a silk handkerchief. She offered a reward to anyone who caught them and brought them back.

The record does not say whether Jack was caught.

### Indigo blue, 1739 to 1750

Indigo seeds came to South Carolina with the first English settlers in 1670. In the late 1730s and early 1740s, hundreds of South Carolina planters tried out new crops, and indigo was one of them.

**Eliza Lucas.** Eliza Lucas began trying to grow indigo in 1739 at Wappoo Plantation, on Wappoo Creek west of the Ashley River, near Charleston. She was 17 and managed the plantation and the 20 people enslaved on it. She worked first with an indigo maker from the island of Montserrat. She had the most success with an indigo maker of African descent whom her father hired from the French West Indies. In 1744 she used her crop to make seed and shared it with other planters.

The historian Nic Butler of the Charleston County Public Library writes that her part has been greatly exaggerated in recent times. Many of her neighbors were following the same steps. Her husband, Charles Pinckney, whom she married in 1744, published her methods in articles in 1744 and 1745 under the name "Agricola."

**The bounty.** South Carolina's lawmakers voted in 1744 to pay planters a bounty, a reward from the government, of 1 shilling for each pound of indigo. They canceled it in 1746. Members of the British Parliament, the lawmakers in London, voted a bounty of 6 pence a pound in 1748, starting in 1749.

Planters began shipping large amounts of indigo to England in 1747. Exports rose from about 5,000 pounds in 1745 and 1746 to about 130,000 pounds in 1748, about 26 times as much.

**Who did the work.** Enslaved people of African descent did almost all of the work. They planted and tended the indigo. They built the vats, big tubs for making dye, and filled them with water and cut leaves. After the leaves soaked, the workers beat the liquid with paddles or with buckets that had no bottoms. They added lime, made from burnt oyster shells, so that the blue settled out. Then workers scooped the blue mud into bags, dried it and cut it into cubes.

Charles Woodmason wrote in 1755 that 15 enslaved workers could plant and tend 50 acres of indigo, and that it took 25 skilled workers to turn that crop into dye. The accounts of indigo making from these years do not name the enslaved workers who made the dye.

One enslaved man who built the vats is named. He was Quash, a carpenter whom the Lucas family held in slavery at Wappoo. In 1744 George Lucas, Eliza's father, wrote that "Quashe" should build a wooden indigo works at the family's Garden Hill plantation. Eliza told her father that Quash had spent 33 days building indigo vats at other Lucas plantations. The minister Alexander Garden baptized him on April 16, 1746. The historian Tiffany Momon, who wrote about his life, calls him John "Quash" Williams.

South Carolina's indigo was shipped to England for British cloth makers. South Carolinians bought most of their own cloth from England, already dyed.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 7 minutes**

Colonists who opposed British taxes turned their clothes into a protest. From the Stamp Act tax of 1765 until the Revolution, they agreed again and again to boycott, or refuse to buy, British goods, including cloth. Delegates at the First Continental Congress, a meeting of leaders from the colonies, voted in 1774 to ban British goods in every colony from December 1.

During the boycott of 1768 and 1769, a colonist who wore homespun, cloth spun and woven in America, often at home, showed that he or she backed the boycott. Women held public spinning meetings. Harvard's graduating class of 1768 voted not to wear imported British clothes at their graduation.

George Washington took the oath as the first president in 1789 in a suit of brown wool woven in Connecticut. Furniture makers in the new country copied a style of sharp edges, legs that grew thinner toward the floor, and inlaid eagles, now called the Federal style. In Spanish New Orleans in 1786, the governor ordered Black women and women of mixed race to stop wearing feathers and jewels in their hair and to wear it plain or covered with a cloth.

### Homespun as a protest, 1765 to 1776

During the boycotts of British goods in the 1760s, Boston merchants opened spinning schools again. In Hartford, members of a society offered a prize of 12 pounds to whoever made the most yards of wool cloth in a year. Newspaper printers ran reports of spinning meetings in Massachusetts, Connecticut and Rhode Island. In Newport one spinner was a woman of 70 who had never spun a thread before. Only six of the newspaper stories called the spinners "Daughters of Liberty."

**A day at the wheel.** Women met at their minister's house in Brookfield, Massachusetts, at 5 in the morning one day in August 1769. A report of the meeting said the best young spinner at the linen wheel, a spinning wheel for linen thread, spun 70 knots of yarn, a knot being a measured length.

One married woman did her morning housework and made cheese first. Then she rode more than 2 miles carrying her own spinning wheel, spun 53 knots between 9 and 7, and went home to milk the cows.

The seniors at Harvard College voted in the autumn of 1767 not to drink tea or wear imported British clothes at their commencement, the ceremony at which students graduate. They did it to protest the Townshend taxes on goods from Britain. The printed sheets for the 1768 commencement, which listed the statements the graduates would argue for, were on paper made in New England. The next year's seniors did the same.

### Charity Clarke

> **Who:** A young New Yorker who wrote to her cousin in London that American women would spin, weave and dress in their own cloth rather than buy British clothes.
>
> **When and where:** Her father's estate called Chelsea, on Manhattan, 1768 to 1774.

**She promised "a fighting army of Amazons" armed with spinning wheels.**

Charity Clarke was 21 or 22 when she wrote to her cousin in London in 1769. If the English did not give Americans the liberty they asked for, she told him, she would lead "a fighting army of Amazons," the women warriors of old Greek stories. She would gather "a number of ladies armed with spinning wheels." The historian Alan Singer dates the letter June 1769, and other accounts date it December 8, 1769.

Her ladies would have helpers "who shall all learn to weave and keep sheep," and they would all be "clothed with the work of our hands." They would be "no more slave to fashion and ceremony."

Her cousin was Joseph Jekyll, a lawyer in London, and she wrote to him between 1768 and 1774. Columbia University holds the letters today. She wrote to him again in 1774: "Though this body is not clad with silken garments, these limbs are armed with strength."

She was born in New York on June 28, 1747, and grew up on her father's estate, called Chelsea, on the island of Manhattan. She married the Rev. Benjamin Moore of Trinity Church in 1778. Their son, Clement Clarke Moore, wrote the poem "A Visit from St. Nicholas."

### Wigs in Williamsburg, 1769 to 1775

Edward Charlton came to Williamsburg, Virginia, from London and became the town's leading barber and wigmaker. In 1769 eight barbers and wigmakers worked in the town. Charlton's account book for 1769 to about 1775 shows that in one year he sold sixty brown wigs of a style called the "dress bob." They cost 43 shillings each.

For shaving a man and dressing his wig for a year, Charlton usually charged 2 pounds 3 shillings. Peter Pelham paid 1 pound 5 shillings, and Speaker Randolph, the leader of the colony's lawmakers, paid 4 pounds.

Wigmakers needed hair. George Long of Petersburg, another Virginia town, advertised that he would pay one shilling an ounce for human hair.

Wigs were going out of fashion in England, and Charlton retired shortly before the Revolution.

### Indigo's peak and end

South Carolina planters shipped more than one million pounds of indigo to England in 1775, more than seven times the 130,000 pounds of 1748. Enslaved workers did almost all of the work of making it. The British bounty on indigo ran out in 1777, during the war with Britain. Some planters grew indigo again after the war ended in 1783. In the 1790s most of them gave up indigo, and many turned to cotton.

### Why did a governor ban feathers in women's hair?

Governor Esteban Rodríguez Miró of Spanish New Orleans ordered Black women and women of mixed race to stop wearing feathers and jewels in their hair in 1786. The historian Virginia Meacham Gould writes that he aimed the rule at women who dressed "too elegantly" or "competed too freely with white women for status."

The rule was part of a set of rules Miró issued on June 2, 1786, called the *bando de buen gobierno*, the order of good government. It said the women could "no longer have feathers nor jewelry in their hair." They had to wear their hair plain or cover it with a *pañuelo*, a head cloth. People later called such a cloth a tignon.

Gould found little written evidence that officials enforced the rule, and no record that anyone was punished under it. Portraits painted in New Orleans in the early 1800s show free Black women and women of mixed race wearing head wraps tied in many different styles. Gould reads the head wraps in these portraits as a mark of distinction.

### George Washington

> **Who:** The first president, who took the oath of office in a suit made from American wool.
>
> **When and where:** Mount Vernon, Virginia, and New York City, January to April 1789.

**He took the oath in brown wool woven in Connecticut.**

George Washington wrote on April 8, 1789, three weeks before he took the oath as the first president of the United States: "I shall allways take a peculiar pleasure in giving every proper encouragement in my power to the manufactures of my Country" (manufactures meant goods made by hand or by machine). He took the oath on April 30, in New York.

**Finding the cloth.** In January 1789 a writer in *The Federal Gazette* had urged American leaders to wear clothing made in America. He signed himself "a Philadelphia mechanic," meaning a skilled worker who made things. The Hartford Woolen Manufactory in Connecticut had just begun making cloth. A merchant in Philadelphia could not get the cloth for Washington, so Henry Knox, then the secretary of war, dealt with the Hartford factory himself. The cloth reached Alexandria, Virginia, in early April. Washington left Mount Vernon for New York on April 16.

The staff at Mount Vernon believe that Cavan Boa made the coat, waistcoat and breeches. Boa was Washington's indentured tailor, a servant bound to work for him for a set number of years. Kathrin Breitt Brown makes copies of old clothes for Mount Vernon. She calls the coat "well-made but hastily finished," and she thinks Boa probably had help. Washington asked for six large engraved buttons.

In England the color of the cloth was called London brown. Americans called it Congress brown. The coat came to the collection at Mount Vernon in 1933.

Washington did not wear a wig. He powdered his own hair.

### The Federal style, 1780 to 1820

Styles changed in American homes as well as in clothes. From about 1780 to 1820, American cabinetmakers, the skilled makers of fine furniture, worked in a style now called Federal. They copied many of its designs from English pattern books by George Hepplewhite and Thomas Sheraton. Federal pieces had legs that grew thinner toward the floor, and sharp edges. Makers covered them with veneers, thin sheets of fine wood laid over the surface. They inlaid pictures of eagles, urns and bellflowers, setting small pieces of different wood into the surface.

The main wood was mahogany, and makers also used satinwood, maple and birch. Makers of Federal furniture included John and Thomas Seymour in Boston and Duncan Phyfe in New York.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 10 minutes**

Enslaved people in the South grew and picked the cotton that American mills spun between 1800 and 1850. Workers in New England mills spun and wove that cotton into cloth. In some mills in Rhode Island and in Lowell, Massachusetts, workers also wove a rough, cheap cloth that planters bought to dress the people they enslaved.

Fashionable women wore high-waisted white cotton dresses in the early 1800s. Later they wore corsets, stiff garments laced tight around the body, and wide skirts held out by layers of petticoats, the skirts worn under the outer skirt. Men stopped powdering their hair and cut it short. Some still wore knee breeches, pants that ended at the knee, and by the 1840s men wore narrow trousers.

**Who made the clothes.** A government report in 1811 stated that two-thirds of all the clothes Americans wore were made at home. People who could pay for it had a tailor or a seamstress, a woman who sewed for pay, make their clothes. The first shops that sold clothes already made stood near the docks, and their customers were sailors and other working men.

### What fashionable people wore, 1800 to 1850

The fashionable dress for a woman in the first ten years of the 1800s had its waistline just under the breasts. It was made of muslin, a thin cotton cloth, and white was the most fashionable color. White dresses were hard to keep clean, and cleaning them cost money. For every day, women wore printed cottons and patterned silks, and wool in cold weather.

Men in the same years stopped powdering their hair and cut it short. They gave up embroidered silk and lace for plain wool coats in dark colors. Some still wore knee breeches. Others wore pantaloons, tight pants that reached the calf or the ankle. By the 1840s the frock coat was the standard coat for men. It was a fitted coat with a skirt that reached to just above the knee, worn with narrow trousers and vests of brightly patterned silk.

Women's sleeves puffed out wide from the shoulder in the early 1830s. This shape was called the gigot, or leg-of-mutton, sleeve, mutton being sheep meat. Skirts became very wide, and women wore more and more petticoats under them. Under the dress, a woman wore a corset laced tight from the chest to the hips.

**The corset.** A fashionable corset of the 1840s ran from a woman's breasts down over her hips. Heavy cords and strips of whalebone, a stiff, bendable material from the mouths of some whales, stiffened it. A long, flat piece of steel, wood or whalebone, called a busk, ran down the front. Sleeves were cut so tight that a woman often could not lift her arms higher than her shoulders. By the end of the decade some women wore six or seven petticoats.

*Godey's Lady's Book*, a magazine for women published in Philadelphia from 1830, showed its readers pictures of the latest dresses. Each issue opened with a fashion plate, a picture of the newest styles colored by hand. Sarah Josepha Hale edited the magazine from 1837 to 1877. The number of copies of each issue grew from about 10,000 in 1837 to about 150,000 by 1860.

### Cotton picked in the South, woven in the North

The owners and workers of the cotton mills in Lowell, Massachusetts, depended on cotton grown in the South by enslaved people. US Senator Charles Sumner called the tie between Southern planters and New England mill owners an "unholy union." On one side, he said, stood "the cotton planters and fleshmongers of Louisiana and Mississippi." On the other stood "the cotton spinners and traffickers of New England" (a fleshmonger traded in human beings, and a trafficker was a trader).

In Lowell, workers at the Merrimack Company printed calico, cotton cloth printed with colored patterns. The company's owners hired skilled printers from England. The head printer they hired in 1825 was paid more than the company's treasurer, the officer in charge of its money.

**Solomon Northup.** Solomon Northup described how the cotton was picked. He was a free Black man, born in Minerva, New York. In 1841 two white men who called themselves Merrill Brown and Abram Hamilton offered him work with a circus. They took him to Washington and gave him a drink that drugged him.

He woke up alone in the dark, in chains, in a slave pen, a building where traders locked up enslaved people until they were sold. The pen stood near the US Capitol. The slave trader James H. Burch beat him for saying he was free. In New Orleans, Burch's partner Theophilus Freeman sold him, and enslavers in Louisiana held him until January 1853. For almost ten years he picked cotton on the plantation of Edwin Epps, on Bayou Boeuf.

**The day's weight.** Northup wrote that the pickers had to be in the field as soon as it was light. They stayed until it was too dark to see, with 10 or 15 minutes at noon to eat cold bacon. At night each picker's basket was weighed. An ordinary day's work was 200 pounds of cotton.

Epps and his drivers, the men who ran the work in the field, whipped anyone who brought in less. The more a picker came up short, the more lashes, or blows of the whip, he or she got. Epps set each picker's daily amount by what that person had shown he or she could pick.

Northup called a woman named Patsey "the most remarkable cotton picker on Bayou Boeuf." He wrote that 500 pounds a day was not unusual for her. In his words, she "would surely have been beaten if she failed to produce twice as much" as the 200 pounds of an ordinary day's work.

### Cloth made for enslaved people's clothes

Planters called the rough fabric they bought for enslaved people's clothes "negro cloth" or "slave cloth." The names covered several coarse fabrics. Two of them were osnaburg, a coarse plain cloth, and kersey. Both were on the list in South Carolina's 1740 law, which barred enslaved people from wearing anything finer. Another was linsey-woolsey, a cheap cloth of wool mixed with cotton or linen. Jeans was a cotton and wool cloth woven in a twill, a weave that makes thin diagonal lines.

The Hazard family owned a woolen mill in Peace Dale, Rhode Island, where workers made this rough cloth for Southern planters to clothe the people they enslaved. In the 1820s Isaac Peace Hazard traveled through the South taking orders from plantation owners. By 1845 the owners of 17 of Rhode Island's 40 textile mills had made this cloth their main product. Workers in the Lowell mills made it too.

Southern buyers told the Hazards what they wanted. One wrote in 1824 that the cloth "would not suit servants unless it was blue." By "servants" he meant enslaved people. A complaint of the time described clothes "as thin as baize, threads not beat close together, others split all to pieces" (baize was a thin wool cloth).

**Handing it out.** Enslavers handed out clothing on set days. On Colonel Edward Lloyd's plantation in Maryland it came once a year. In Charleston, the people Mary Pringle enslaved as house servants got a summer share and a winter share.

Stephen Duncan owned the Carlisle plantation in Mississippi in the 1850s. There each man got enough cloth for three shirts, two pairs of summer pants and one pair of winter pants, along with a coat and two pairs of shoes. Each child got four slips, short loose dresses. John Potter's rice plantation in South Carolina used 1,800 yards of cloth a year for the 400 people he enslaved, about 4.5 yards for each person.

Harriet Jacobs was enslaved in Edenton, North Carolina, in the household of Dr. James Norcom, whom she calls Dr. Flint in her book. She wrote: "I have a vivid recollection of the linsey-woolsey dress given me every winter by Mrs. Flint. How I hated it! It was one of the badges of slavery." Her grandmother's work, she wrote, "supplied my scanty wardrobe" (scanty means too little).

The slave trader Theophilus Freeman held Solomon Northup and other captives in his slave pen in New Orleans in 1841. Northup wrote that the traders made the captives wash and made the men shave. Then they gave each person "a new suit each, cheap, but clean." The men got a hat, a coat, a shirt, pants and shoes, and the women a calico dress and a handkerchief to tie around the head.

### Frederick Douglass

> **Who:** A man enslaved in Maryland who described the clothes he was given as a child, and who escaped to freedom dressed as a sailor.
>
> **When and where:** Talbot County and Baltimore, Maryland, the 1820s to 1838.

**As a child, his only clothing was one linen shirt.**

As a child, Frederick Douglass had nothing to wear but one coarse linen shirt that reached to his knees. It came from the clothing that Colonel Edward Lloyd and his overseers, the men who ran the work for him, handed out each year. He had no shoes, stockings, jacket or trousers, "in hottest summer and coldest winter."

He had no bed. On the coldest nights he took a bag used for carrying corn to the mill, crawled into it and slept on the cold, damp clay floor. He wrote: "My feet have been so cracked with the frost, that the pen with which I am writing might be laid in the gashes."

**Allowance-day.** Douglass was born enslaved in Talbot County, Maryland, and as a child he lived on Lloyd's home plantation. Lloyd enslaved people on several farms, and they came to the home plantation for their food and their yearly clothing. Each enslaved adult got two coarse linen shirts, one pair of linen trousers, one jacket, one pair of winter trousers "made of coarse negro cloth," one pair of stockings and one pair of shoes a year. Douglass wrote that all of it "could not have cost more than seven dollars."

Children too young to work in the fields got only two coarse linen shirts a year. "When these failed them," he wrote, "they went naked until the next allowance-day."

When he was about seven or eight, his owners sent him to Baltimore. Before he left, Lucretia Auld, the daughter of his old master, told him he could have a pair of trousers if he scrubbed the dirt off his skin first. He wrote: "The thought of owning a pair of trousers was great indeed!"

**The escape.** Douglass escaped from Baltimore by train on September 3, 1838. He wrote: "I had on a red shirt and a tarpaulin hat, and a black cravat tied in sailor fashion carelessly and loosely about my neck" (a tarpaulin hat was a sailor's waterproof hat, and a cravat was a cloth tied around the neck). He carried a paper called a sailor's protection, borrowed from a friend who was a sailor. It described a free American sailor, and Douglass used it in place of papers showing he was free.

Anna Murray, a free Black woman who washed other people's clothes for pay, helped him. She married him in New York that same month. According to *The Frederick Douglass Encyclopedia*, her laundry work gave her access to sailors' clothing, and she got some of it for him. Other accounts say she sewed the sailor's outfit herself. She also gave him part of her savings, and she sold one of her feather beds to add to it.

### Who bought the first ready-made clothes?

Sailors and other working men bought the first clothes sold ready to wear in America, in the early 1800s. They bought them at shops called slop shops, on the streets next to the docks of Boston, New York, Philadelphia and Baltimore, and of smaller whaling and fishing towns. The clothes came in one size, and a sailor heading out to sea made them fit as best he could.

More and more clothing makers sewed cheap clothes for planters to give to enslaved people between 1840 and 1860. Many New York firms made what they called "Negro clothing." A planter who bought these clothes did not have to use the time of enslaved workers to sew them.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 12 minutes**

Sewing machines and chemists' new dyes changed how Americans' clothes were made and colored after 1850. Isaac Singer began making sewing machines in 1851, and from 1856 his partner, Edward Clark, let families pay for one a few dollars a month. A chemistry student in London made the first man-made dye to be sold in 1856, a purple, from chemicals in coal tar.

A tailor in Reno and a merchant in San Francisco got a patent in 1873 for work pants with metal rivets, small metal pins that hold cloth together. The patent, a government paper, gave them the right to be the only ones to make the pants that way for a set number of years. The riveted pants were later called blue jeans.

**Mockery and rules.** A few leaders of the fight for women's rights wore short skirts over trousers in 1851, and men mocked them for it. Members of San Francisco's Board of Supervisors, the men who made the city's laws, ordered in 1876 that every man in the county jail have his hair cut to one inch.

Sheriff Matthew Nunan used the order to cut off Chinese prisoners' long braids, and a federal judge later found that the order was meant only for the Chinese. From 1879, the staff at the Carlisle Indian School in Pennsylvania cut Native children's hair and took away their clothes.

### The Bloomer costume, 1851 to 1854

Elizabeth Smith Miller visited Amelia Bloomer in Seneca Falls, New York, in February 1851, wearing a dress that reached the knee, over trousers. It was sometimes called the Turkish dress. Bloomer began wearing it too, and she printed articles and pictures of it in her newspaper, *The Lily*. Elizabeth Cady Stanton, a leader of the fight for women's rights, also wore it. People named the outfit bloomers, after Amelia Bloomer, the woman best known for wearing it and speaking up for it.

Bloomer wrote that "letters came pouring in upon me by the hundreds from women all over the country" asking about the dress. The number of copies of *The Lily* sent out each month rose from 500 to 4,000, by the count of the National Park Service. Another count gives 3,000.

Men mocked the women who wore it and called them "Amazons," after the women warriors of old Greek stories. Some young women who wore it were turned away when they asked to join a church. By about 1854, Stanton and other leaders had gone back to long skirts and corsets. They feared that wearing the dress took attention away from their fight for the right to vote.

### Hoops, sewing machines and paper patterns

Women began to wear the cage crinoline, a frame of steel hoops that held a skirt out wide, in 1856. With it, women no longer needed the heavy stacks of petticoats, sometimes as many as seven, that they had worn to get the same shape.

**The sewing machine.** Isaac Singer began making sewing machines in 1851. He used the lockstitch, a stitch that locks two threads together, which Elias Howe had invented. Sewing a man's frock coat, a fitted coat with a skirt to the knee, by hand took almost 17 hours. By machine it took two and a half.

A Singer machine cost about $100 in 1856. That September, Edward Clark, Singer's partner, began to sell machines on installments, which means a buyer paid a little each month. The magazine *American Heritage* gives the terms as $5 a month. Earlier in 1856 Clark had offered $50 off a new Singer for any old sewing machine, even a worthless one.

**Paper patterns.** Ebenezer Butterick and his wife, Ellen Augusta Pollard Butterick, of Sterling, Massachusetts, began selling sewing patterns, paper shapes that a person who sews pins to cloth and cuts around, in 1863. They cut the patterns from tissue paper. By one report, the idea came from Ellen Butterick, who was tired of patterns that came in only one size.

The Buttericks' patterns came in a range of standard sizes. Members of the family cut and folded the first ones at home. They sold patterns for men's and boys' clothes first, and added women's dresses in 1866.

### Elizabeth Keckley

> **Who:** A dressmaker, born enslaved, who bought her freedom with money from her sewing and made Mary Todd Lincoln's dresses.
>
> **When and where:** Virginia, St. Louis and Washington, D.C., 1818 to 1868.

**"With my needle I kept bread in the mouths of seventeen persons."**

Elizabeth Keckley wrote those words about St. Louis, where the Garland family who owned her lived on the money her sewing brought in. She kept them fed that way "for two years and five months." She wrote that "the best ladies in St. Louis" were her customers, and in the end those customers lent her the price of her freedom. Later she made the dresses of Mary Todd Lincoln, the wife of President Abraham Lincoln.

**Growing up.** Keckley was born enslaved in February 1818 at Dinwiddie Court House, Virginia. The Burwell family enslaved her and her mother, Agnes. Her father was Armistead Burwell, of the family that enslaved her. Agnes made clothes for 82 people: the 12 members of the Burwell family and the 70 people they enslaved. As Keckley grew up, she helped her mother make the clothes.

Her old master sent her to work for his eldest son, Robert Burwell, a minister, and his wife. When she was nearly 18, she moved with them to Hillsboro, North Carolina, where Robert Burwell led a church. A schoolmaster named Bingham had promised Mrs. Burwell that he would "subdue," or crush, what he called Keckley's "stubborn pride." He whipped her. When she asked him why, he hit her with a chair and knocked her to the floor.

While she lived in Hillsboro, a white man raped her again and again for four years, forcing her to have sex with him. Keckley wrote that the man "had base designs upon me" and "persecuted me for four years." She refused to name him. "I spare the world his name," she wrote. She gave birth to his son, George, the only child she ever had.

**Freedom.** Her owner agreed to free her and George for $1,200. One of her customers, Mrs. Le Bourgeois, raised the money among Keckley's other customers. Keckley and her son were freed on November 15, 1855. She took the money only as a loan, and she paid back every cent from her sewing.

**The White House.** She moved to Washington in 1860 and later employed 20 seamstresses. Abraham Lincoln took office on March 4, 1861. At eight o'clock the next morning, Tuesday, she went to the White House. Three other dressmakers were already waiting, and Mary Todd Lincoln chose Keckley. She wrote that she made "fifteen or sixteen dresses" for Mrs. Lincoln that spring and summer. Her customers also included Varina Davis, the wife of Jefferson Davis.

People freed from slavery were coming to Washington from Maryland and Virginia in the summer of 1862. In August 1862 Keckley and other Black residents of Washington started the Contraband Relief Association to help them. During the Civil War, Union soldiers used the word "contraband" for people who had escaped slavery. The association's members gave out food, shelter, clothing and medical care, and in the first year they handed out 5,150 pieces of clothing.

She published a book about her life in 1868, *Behind the Scenes, or, Thirty Years a Slave, and Four Years in the White House*. The Smithsonian holds a purple velvet gown she made for Mrs. Lincoln. She died in Washington in May 1907.

### Where did the first man-made dye come from?

The first man-made dye came from coal tar, a thick black liquid made from coal. William Henry Perkin, an 18-year-old student at the Royal College of Chemistry in London, made it in 1856, while he was trying to make quinine, a drug for the disease malaria. He was on his Easter break.

Every dye before then came from plants, insects, shellfish or minerals: indigo blue from a plant, cochineal red from an insect and red ochre from a mineral. Perkin was working with chemicals that come from coal tar. Instead of quinine he made a purple dye, now called mauve or mauveine. It was the first man-made dye sold for use, and in 1857 he opened a factory near London.

Chemists were making other new colors from coal tar by 1859, such as fuchsine, a deep crimson red. These are called aniline dyes, after aniline, one of the coal-tar chemicals used to make them.

### Levi Strauss and Jacob Davis

> **Who:** A tailor in Reno who put metal rivets on work pants, and the San Francisco merchant who shared the patent with him.
>
> **When and where:** Reno, Nevada, and San Francisco, California, 1870 to 1875.

**A woodcutter's wife asked for strong work pants.**

A woman asked Jacob Davis, a tailor in Reno, Nevada, to make strong work pants for her husband, a woodcutter. Davis had been using copper rivets on horse blankets. He put rivets at the weak points in the seams and pockets, so that the seams would not tear. In a court statement, Davis dated this to January 1871. Other accounts date it to December 1870.

**The patent.** Davis and Levi Strauss's company got a patent for the idea on May 20, 1873. The patent, number 139,121, covered "a metal rivet or eyelet at each edge of the pocket opening to prevent the ripping of the seam." The riveted pants were later called blue jeans.

Davis and Levi Strauss & Co. took A. B. Elfelt and others to court in January 1874, saying that they had used the patented rivets without permission. On February 10, 1875, the judge decided for Davis and Strauss. They had asked for $20,000 and were awarded $2,000.

**The two men.** Davis was born Jacob Youphes in the city of Riga on May 14, 1831. He came to New York in 1854, changed his name, and by 1869 ran a tailor shop in Reno. Levi Strauss was born in Buttenheim, Bavaria, on February 26, 1829. He came to the United States in 1847 and reached San Francisco in 1854, where he sold cloth and clothing to stores as Levi Strauss & Co.

Davis ran the San Francisco factory that made the riveted pants. Strauss died on September 26, 1902, and Davis died in 1908.

### Cutting Chinese men's braids in San Francisco, 1876 to 1879

Chinese men in the 1800s shaved the front of the head and wore the rest of their hair in one long braid called a queue. Stephen Field, a federal judge, later wrote that Chinese men saw the loss of the queue as a disgrace that brought "misfortune and suffering after death."

Members of San Francisco's Board of Supervisors voted for an order to cut prisoners' hair in 1873. Mayor William Alvord vetoed, or rejected, the hair-cutting part.

**The lodging law.** California's lawmakers passed a law about lodging houses, buildings that rent out rooms, in April 1876. It made it a crime to sleep in a room with less than 500 cubic feet of air for each person. That is about the space of a room 8 feet long, 8 feet wide and 8 feet high. A history of the case by the Federal Judicial Center, the research office of the federal courts, states that the law was aimed at Chinese residents.

**The hair order.** Members of the Board of Supervisors voted on June 14, 1876, that every man jailed in the county have his hair cut to one inch from the scalp. Field later wrote: "The ordinance was intended only for the Chinese in San Francisco" (an ordinance is a city law).

Ho Ah Kow was found guilty under the lodging law in April 1878 and fined $10. Field's opinion in his case does not name the judge who sentenced him. His sentence was five days in the county jail if he did not pay. He did not pay, and he went to jail. Sheriff Matthew Nunan cut off his queue. Nunan and his deputies, the officers who worked under him, cut off other men's queues too. The records do not say how many.

Ho Ah Kow sued Nunan. On July 7, 1879, Justice Field ruled that the hair order went against the Fourteenth Amendment to the Constitution. That amendment states that no state may deny any person the equal protection of the laws, which means the same treatment under the law. Field wrote that the order was not meant to stop prisoners from escaping. Its purpose, he wrote, was "merely to aggravate the severity of his confinement," which means to make the prisoner's time in jail harder to bear.

### Uniforms and short hair at Carlisle, 1879 on

Richard Henry Pratt, an Army officer, opened the Carlisle Indian Industrial School in Pennsylvania in 1879 for Native children. In 1892 Pratt said his aim was to "Kill the Indian in him and save the man." In a proclamation of December 2024, President Joe Biden stated that federal officials had tried to make Native children give up their own ways of life "by stripping them of their languages, religions, and cultures."

**Hair and clothes.** At Carlisle the staff cut the children's hair and took away their clothes. They dressed the boys in military uniforms and the girls in Victorian dresses, the long dresses of the time. Chapter 2, Native Nations, tells the full story of the boarding schools.

Carlisle's photographer, John N. Choate, took pictures of students when they arrived. He photographed the same students again after they had been at the school for a while. His "before and after" pictures show a student in the Native clothes he or she arrived in, then the same student in a school uniform. One pair has the caption "Tom Torlino, Navajo. As he entered the school in 1882. As he appeared three years later."

### Shirtwaists and the Gibson Girl, 1890s

Women in the 1890s wore a separate skirt and a shirtwaist, a blouse cut like a man's shirt. Women who worked for pay wore it every day. Sleeves puffed out wide again and were biggest around 1895. Most working men wore the sack suit, a loose jacket with pants.

About 50,000 people rode bicycles in 1885, and about 10 million in 1896, by one estimate. Some women rode in bloomers, but most wore shorter skirts.

Charles Dana Gibson lived from 1867 to 1944. He drew for *Life*, *Collier's Weekly*, *Harper's Weekly* and other magazines. In the 1890s he drew a young woman whom people called the Gibson Girl. The Library of Congress showed his drawings in an exhibition. Its writers say she "pursued higher education, romance, marriage, physical well-being, and individuality" (pursued means went after) with more freedom than young women had had before. They also write that from the 1890s until World War I she "set the standard for beauty, fashion, and manners."

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 12 minutes**

Chemists made the new materials that Americans wore and handled every day in the first half of the 1900s. Leo Baekeland made Bakelite, a hard plastic, in 1907, and chemists at the DuPont company made nylon in 1935. Nylon went on sale as women's stockings in 1939. Many women in the 1920s cut their hair short and wore shorter, looser dresses. Black women built companies that sold hair products to Black customers, and Madam C. J. Walker and Annie Turnbo Malone each grew rich from that work.

Government officials also used clothes and hair to control people. The US commissioner of Indian affairs, the head of the federal office for Native affairs, told officials on the reservations, the lands the government had set aside for Native nations, to make Native men cut their hair in 1902.

Officials in Washington limited how much cloth a dress or a suit could use in 1942. In June 1943, servicemen in Los Angeles beat Mexican American young men and tore off their zoot suits, outfits with very wide pants and long coats. Police officers then arrested many of the bloodied young men.

### The order to cut Native men's hair, 1902

William A. Jones was the US commissioner of Indian affairs. On January 11, 1902, he sent a letter to the superintendents, the officials who ran the federal reservations and the offices on them, telling them to make Native men cut their hair. He wrote that long hair on the men was "not in keeping with the advancement they are making, or will soon be expected to make, in civilization." He called short hair "a great step in advance."

Jones wrote that "Indian costume and blanket" should be discouraged, and that "Indian dances and so-called Indian feasts should be prohibited." He claimed that the paint Native people wore caused "the majority of blindness among the Indians of the United States." He told the superintendents they could force men to obey by holding back their jobs and their rations, the food and supplies that officials handed out on reservations. Each superintendent had to report his progress by June 30, 1902.

Charles Burton was the superintendent for the Hopi and the Navajo. The historian Tisa Wenger writes that he reportedly used "whips, guns, and sheep shears" to enforce the order. The surviving accounts do not say how many men were forced to cut their hair.

The letter drew an outcry, and writers at *Harper's Weekly* criticized it in February 1902. Jones backed down. Officials then received new instructions to use "persuasion and example, rather than force."

### Shirtwaists, short hair and short skirts

The shirtwaist, the blouse cut like a man's shirt, stayed the everyday top for working women in the early 1900s. Young immigrant women sewed shirtwaists in New York factories.

**The Triangle fire.** The Triangle Waist Company made shirtwaists on the top floors of a building in New York. A fire there killed 146 workers on March 25, 1911. Most of them were young immigrant women, and some were only 14. A stairwell door on the ninth floor was locked, and dozens of workers jumped from the windows.

The owners, Max Blanck and Isaac Harris, were tried for manslaughter, a killing the law treats as less serious than murder. The jury found them not guilty on December 27, 1911, because the prosecutors could not prove that the owners knew the doors were locked.

**The flapper look.** Many women cut their hair into a short style called a bob in the 1920s. Dresses hung straight from the shoulders, with the waistline low on the hips. This slim, straight shape is often called the flapper look. Hemlines, the bottom edges of skirts, rose until 1926 and then began to fall.

Many women gave up stiff, formal layers for lighter, looser clothes. With new fabrics such as jersey, a soft knitted cloth, and "artificial silk," a man-made cloth that looked like silk, more women could dress in the new styles. Fashion historians at the Fashion Institute of Technology call this change a "democratization of fashion," which means that fashion spread to ordinary people.

### Hair care built by Black women

Annie Turnbo, later known as Annie Turnbo Malone, made a hair product she called Wonderful Hair Grower and sold it door to door. She was born on August 9, 1877, in Metropolis, Illinois, and her parents had been enslaved in Kentucky. She moved to St. Louis in 1902 and opened a shop. She later named her company Poro.

She opened Poro College in St. Louis in 1918, a building that held a factory, a store, rooms where students slept, a gym, a chapel and an auditorium. Nearly 200 people worked there. About 75,000 women, in several parts of the world, trained in her Poro system. In 1924 she paid nearly $40,000 in taxes.

### Madam C. J. Walker

> **Who:** A Black businesswoman, born to parents who had been enslaved, who built a hair-care company and trained thousands of women to sell her products.
>
> **When and where:** St. Louis, Denver and Indianapolis, 1889 to 1919.
>
> **Movie:** *Two Dollars and a Dream* (1987), a documentary about her life by Stanley Nelson.

**Her own hair falling out led her into the hair business.**

Sarah Breedlove, the woman who later became Madam C. J. Walker, was washing clothes for pay and working as a cook in St. Louis when her hair began to fall out. A skin disease, harsh hair products, poor food and a home without running water all played a part. In 1904 she began using Annie Turnbo's hair product, and she became one of Turnbo's sales agents in St. Louis.

She was born on December 23, 1867, in Delta, Louisiana, and her parents had been enslaved. Her parents died when she was 7, and she married at 14. She moved to St. Louis in 1889.

**Her own company.** She moved to Denver in July 1905 and began selling her own product, "Madam Walker's Wonderful Hair Grower," almost the same name as Turnbo's Wonderful Hair Grower, which she had sold in St. Louis. She married Charles Joseph Walker in 1906 and took his name. In 1910 she moved her company to Indianapolis and built a factory there. The company made hair products for Black women, and she trained thousands of women to sell them.

Her company said that by 1917 nearly 20,000 women had trained with it. According to the National Women's History Museum, she employed 40,000 people. She gave money to the YWCA, the Young Women's Christian Association. She also gave $5,000 to the NAACP, the National Association for the Advancement of Colored People, for its work against lynching, the killing of a person by a mob without a trial.

She died on May 25, 1919. Accounts of her wealth differ. One account puts it between half a million and a million dollars. According to the National Women's History Museum, it was more than $1 million.

### Plastics and nylon

The chemist Leo Baekeland made Bakelite in 1907 by heating two chemicals, phenol and formaldehyde, under pressure. Bakelite was the first plastic made entirely from chemicals, rather than from plants or animals. He got a patent for his method, the right to be the only one to use it for a set number of years, on December 7, 1909. Makers used Bakelite for jewelry, telephones, radios and billiard balls, and in cars.

**Nylon stockings.** Nylon went on sale as women's stockings. On October 24, 1939, the DuPont company sold its first 4,000 pairs to the wives of its employees in Wilmington, Delaware. They sold out in three hours. On May 16, 1940, called Nylon Day, four million pairs went on sale in stores across the country at about $1.15 a pair. They sold out in two days. Some sources give the date as May 15.

Japanese forces attacked Pearl Harbor, in Hawaii, on December 7, 1941. For the rest of World War II, DuPont's nylon went into parachutes, tire cords, ropes and other war goods instead of stockings. Stockings came back in 1945. In Pittsburgh, 40,000 people stood in a line more than a mile long for 13,000 pairs.

### Wallace Carothers

> **Who:** The chemist who led the DuPont laboratory where nylon was made.
>
> **When and where:** DuPont's research station, called the Experimental Station, 1928 to 1937.

**Half an ounce of nylon, made on February 28, 1935.**

Gerard Berchet, a chemist working under Wallace Carothers at DuPont, made half an ounce of the nylon later used in stockings on February 28, 1935. Carothers led the team at DuPont that made two of the most widely used man-made materials of the 1900s, neoprene and nylon. In April 1930 his team made neoprene, a man-made rubber.

Carothers was born on April 27, 1896, in Burlington, Iowa. He started work at DuPont's Experimental Station on February 6, 1928.

**His illness.** Carothers had depression, an illness that brings long periods of deep sadness and makes it hard to think and to work. He wrote: "I suffer from neurotic spells of diminished capacity." He meant that at times his mind could not work as well as usual. In the summer of 1936 he was treated in a psychiatric hospital, a hospital for illnesses of the mind. His sister Isobel died in January 1937.

Carothers killed himself in Philadelphia on April 29, 1937, at age 41, by taking cyanide, a poison. His daughter, Jane, was born in November 1937, seven months after his death. DuPont officials announced nylon to the public on October 27, 1938.

### Ann Lowe

> **Who:** A Black dressmaker from Alabama who made gowns for rich families in Tampa and New York, while the wider public hardly knew her name.
>
> **When and where:** Alabama, New York and Tampa, 1898 to 1950.

**Her gown went to the Academy Awards under another name.**

The actress Olivia de Havilland wore a gown Ann Lowe made when she accepted her Academy Award in 1946. The credit for that dress went to the name "Sonia Rosenberg," not to Lowe. The record does not say who gave that credit. Lowe also made gowns for Jacqueline Kennedy and the heiress Marjorie Merriweather Post, but she stayed almost unknown to the wider public.

**A family of dressmakers.** She was born about 1898 in Clayton, Alabama, into a family of Black dressmakers. Her great-grandmother was enslaved on an Alabama plantation, and the man who owned that plantation was Ann's great-grandfather. He held her as his property, and by law she could not refuse him. He was the father of her daughter, Georgia, who was Ann's grandmother.

Her mother, Jane, and her grandmother, Georgia, made dresses for well-known families in Montgomery, and Ann learned the trade from them. Her mother died in 1914, when Ann was 16, and Ann took over the business.

She went to the S. T. Taylor Design School in New York in 1917. She was taught in a classroom by herself, apart from the white students. The accounts of her life do not name who ordered it. She was ready to graduate after six months. She then made gowns in Tampa, Florida, and opened her own dress shop there in 1920.

She moved to New York in 1928 with $20,000. For years she made gowns to order for stores such as Henri Bendel, Neiman Marcus and Saks Fifth Avenue. The Winterthur Museum showed 40 of her gowns in 2023. The museum's description of the show describes her work as part of "a legacy of Black women's knowledge and skills that began as enslaved labor."

### Cloth rules in World War II, 1942 to 1946

Officials of the War Production Board issued General Limitation Order L-85 on April 8, 1942, to save cloth and workers' time for the war. The War Production Board was the federal agency whose officials controlled materials during the war, and its chairman was Donald M. Nelson. The order set how long and how wide women's coats, dresses, suits and skirts could be.

**What it banned.** To save cloth, the order banned hoods and capes attached to coats. It banned belts and hems, the folded-up bottom edges of clothes, more than 2 inches wide, and it banned cuffs, turned-back bands of cloth, on slacks, or loose pants.

Wedding gowns, dresses for pregnant women, children's clothes, burial gowns and religious robes did not fall under the rules. The rules lasted until 1946.

Stanley Marcus, a co-owner of the Neiman-Marcus department stores, was asked on December 27, 1941, to head the board's section for women's and children's clothing. Makers and stores that broke the rules could be fined or jailed. In April 1942 the board's officials also limited the elastic used in bras and in girdles, tight underwear that shaped the waist and hips. Nylon and rubber went to the military.

### The zoot suit attacks in Los Angeles, June 1943

A zoot suit had high-waisted, very wide pants that narrowed at the ankle and a long coat with wide lapels, the folded-back flaps at the front of a coat below the collar. It began among Black men in Harlem, in New York. In Los Angeles in the early 1940s young Mexican American men wore it. So did some Filipino American and Japanese American young men, and some Mexican American young women. The War Production Board's officials had stopped the making of zoot suits because they used so much cloth.

**The attacks.** Sailors, soldiers and Marines, joined by civilians, went through the Mexican American neighborhoods of Los Angeles from June 3 to June 8, 1943. They hunted young men in zoot suits, beat them, tore off their clothes and burned the suits in street fires. The National WWII Museum says the attacks began on June 3 with about 50 sailors. Another account says about 11 sailors started them, and about 200 joined the next day. By the later days, thousands of servicemen had joined.

More than 150 people were injured. Los Angeles police officers stood by while the attackers claimed they were defending themselves. The officers arrested bloodied and bruised Mexican American men for "disturbing the peace." They arrested nearly 600 Mexican Americans, by the National WWII Museum's count, or more than 500 by another count. The police arrested far fewer servicemen, and no soldiers were arrested for the beatings.

Navy and Marine Corps commanders ordered their men to stay out of Los Angeles on June 8, 1943, and the attacks stopped. Members of the Los Angeles City Council voted for a resolution, a statement of what they wanted, to make wearing a zoot suit in the city a crime. No such law was ever passed.

Governor Earl Warren of California chose a committee to study the attacks. Its members reported that most of the people attacked were Mexican Americans or Black people. On the cause of the attacks, they wrote that "the existence of race prejudice cannot be ignored," race prejudice meaning hating or looking down on people because of their race.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 16 minutes**

After the mid-1950s, the people who designed American clothes began to take their ideas from teenagers, and plastics went into everyday clothes and furniture. In the 1950s young men copied the jeans, white T-shirts and leather jackets that film stars wore. The first suits made partly of polyester, a plastic made into thread, went on sale in 1951. From 1950 the furniture company Herman Miller sold chairs that the designers Charles and Ray Eames had shaped from plastic and glass fiber.

**In court.** People also went to court over clothes and hair. Seven of the nine justices of the Supreme Court, the highest court in the country, ruled in 1969 that students could wear black armbands to school to protest a war. Judges disagreed about boys' long hair, and in 1981 a federal judge allowed an airline to ban a Black woman's braids.

State and federal officers found 72 Thai workers held behind razor wire in El Monte, California, in 1995, sewing clothes that were sold in American chain stores.

### Jeans, T-shirts and teenagers in the 1950s

The leading women's style of the early 1950s was still the "New Look" that Christian Dior showed in 1947. It had a tight waist and a full skirt. By the middle of the decade, dressmakers cut dresses straighter and slimmer, and designers began to take ideas from teenagers.

Young men took up a working-class look: jeans, a white T-shirt and a leather jacket, with the hair greased back. Marlon Brando wore it in the film *The Wild One* in 1953, and James Dean wore it in *Rebel Without a Cause* in 1955. Fashion historians at the Fashion Institute of Technology describe the look as young people turning away from their parents' generation. Young men who wore it got a reputation as rebels and troublemakers. By the end of the decade, boys wore jeans to most places.

### Polyester and wash-and-wear

Two British chemists, John Rex Whinfield and James Tennant Dickson, patented polyester in 1941. The DuPont company bought the right to make it in the United States in 1946, and DuPont named its polyester fiber Dacron.

Hart, Schaffner & Marx of New York began selling men's suits made of cloth that was 55 percent Dacron and 45 percent wool on May 8, 1951. According to the Hagley Museum and Library, it was the first polyester fiber sold to the public anywhere in the world. The makers of the cloth liked it because it did not crease or wear through easily and was easy to clean. In 1953 DuPont opened a Dacron plant in Kinston, North Carolina.

Clothes made with Dacron could be washed and worn without ironing, so they were sold as "wash and wear." Most of the ironing time they saved was women's time.

**The Polyester Decade.** People in the 1970s could buy fashionable styles at any price, because of man-made cloth. Polyester and other man-made fabrics were so common that people called the decade the "Polyester Decade." Men wore leisure suits, a casual kind of suit often made of man-made cloth, as a cheap stand-in for a regular suit.

People dancing at disco clubs wore satin, sequins (tiny shiny disks sewn onto cloth) and Lycra, a stretchy man-made cloth. By the late 1970s people wore sweatshirt cloth and leggings, once clothes for the gym, every day.

### Charles and Ray Eames

> **Who:** A husband and wife who designed furniture of molded plywood and plastic, meant to be sold cheaply to families in small homes after World War II.
>
> **When and where:** Los Angeles, 1941 to 1978.
>
> **Movie:** *Eames: The Architect and the Painter* (2011), a documentary about them in the PBS series American Masters.

**Their first molded plywood was leg splints for wounded servicemen.**

During World War II, Charles and Ray Eames made leg splints of molded plywood for wounded servicemen, with money from the Navy. Plywood is made of thin sheets of wood glued together, and a splint holds a broken bone still. In 1945 and 1946 they used the same method to make plywood chairs. They wanted chairs that could be made from a few parts, so that good chairs could be sold at low prices.

**The contest.** The Museum of Modern Art in New York held a contest in 1948 for low-cost furniture for the small homes being built after the war. The Eameses entered a chair seat made in one piece of stamped steel, and they won second place. Managers at Herman Miller would not pay $80,000 for a machine to press the steel. So the Eameses used fiberglass instead, a plastic that hardens around threads of glass. The military had used it in the war.

Herman Miller sold their chairs from 1950, with seats molded in one piece from fiberglass. Workers at Zenith Plastics of Los Angeles shaped the seats in metal molds on hydraulic presses, machines that press with the force of liquid under pressure. The first colors were greige, a gray-beige, elephant-hide gray and parchment. Buyers could put the same seat on metal legs, wooden legs or rockers. The Eameses described their aim as "getting the most of the best to the greatest number of people for the least."

**Who got the credit.** The Eameses designed a costly lounge chair of leather and molded rosewood plywood in 1956. Ray called it "comfortable and un-designy." Its first label said "designed by Charles Eames." While she was alive, Ray got less credit than writers, museums and filmmakers have given her since her death.

Charles Eames was born on June 17, 1907, in St. Louis, Missouri, and studied architecture. Ray Kaiser was born on December 15, 1912, in Sacramento, California, and trained as a painter. They married in June 1941 and moved to Los Angeles. Charles died on August 21, 1978. Ray died on August 21, 1988, ten years later to the day.

### Who made Jacqueline Kennedy's wedding dress?

Ann Lowe, the Black dressmaker in New York, made it. Janet Auchincloss hired her in 1953 to make the wedding dress for her daughter, Jacqueline Bouvier, and Lowe also made the bridesmaids' dresses. Jacqueline Bouvier married Senator John F. Kennedy that September. The wedding dress used 50 yards of ivory silk taffeta, a smooth, crisp silk cloth, and cost $500.

Ten days before the wedding, water flooded Lowe's workroom. She and her workers made the ruined dresses again. Lowe paid the extra cost herself and did not tell the family. She got no public credit for the dress until after Lee Harvey Oswald shot and killed President Kennedy in Dallas on November 22, 1963.

**Money troubles.** Her rich customers often talked her out of charging hundreds of dollars for her gowns. After she paid her workers, she often lost money, and at the height of her career she was almost broke. She lost her New York shop in 1962 because she had not paid her taxes.

The same year doctors removed her right eye because of glaucoma, a disease in which pressure inside the eye destroys the nerve that carries sight. She declared bankruptcy, a step in court for a person who cannot pay what he or she owes, in 1963. She opened a new shop on Madison Avenue in 1968, and she retired in 1972. She died on February 25, 1981.

### Mary Beth Tinker

> **Who:** A 13-year-old junior high student who wore a black armband to school to protest the Vietnam War. She was suspended, and her case led to a Supreme Court ruling on students' rights.
>
> **When and where:** Des Moines, Iowa, December 1965 to February 1969.

**She was 13, and she wore a black armband to school.**

Mary Beth Tinker wore a black armband to Warren Harding Junior High School in Des Moines, Iowa, on December 16, 1965. She wore it to protest the Vietnam War. School officials sent her home and suspended her.

That December a group of adults and students had met at the home of Christopher Eckhardt's family in Des Moines. They decided to wear black armbands through the holidays to object to the war and to call for a truce, an agreement to stop fighting. On December 14 the principals of the Des Moines schools agreed that any student who wore an armband would be told to take it off. A student who refused would be suspended.

Christopher Eckhardt, 16, wore an armband to his high school on the same day as Mary Beth. Her brother John, 15, wore his the next day. School officials suspended all three. They did not go back to school until after New Year's Day. Her younger brother Paul, 8, and her sister Hope, 11, also wore armbands, but the rule did not cover elementary schools.

The three students' fathers sued the school district for them, with help from the Iowa Civil Liberties Union. The Tinker family received hate mail and threats to kill them. No surviving record names who sent them. A federal judge ruled for the school district, and the judges of the appeals court, a higher court that checks the rulings of lower courts, split evenly.

**The ruling.** Seven of the nine Supreme Court justices ruled for the students on February 24, 1969. Justice Abe Fortas wrote that students do not "shed their constitutional rights to freedom of speech or expression at the schoolhouse gate." He meant that students keep the right to free speech that the Constitution gives every American. He called the armbands "a silent, passive expression of opinion, unaccompanied by any disorder or disturbance," meaning that the students stated their opinion quietly and caused no trouble. Justices Hugo Black and John Harlan disagreed.

### Long hair and braids at school

In the Tinker case, seven justices protected the armbands as a way of speaking. They did not decide what students could wear or how they could cut their hair. Justice Fortas wrote that the case did not concern "the length of skirts or the type of clothing, to hair style." Boys with long hair lost some court cases and won others.

Three Dallas boys tried to enroll at W. W. Samuell High School in September 1966. They were Phillip Ferrell, Stephen Webb and Paul Jarvis, and they played in a band called Sounds Unlimited. School officials turned them away because of their "Beatle" haircuts. In 1968 the judges of a federal appeals court sided with the school.

Chesley Karr of El Paso, Texas, challenged his school's rule in 1970 that a boy's hair could not hang over his ears or his collar. He lost. In 1972, in a case called Arnold v. Carpenter, judges on a different federal appeals court ruled for long-haired students.

The Supreme Court justices never agreed to hear a school hair case. In 1971 Justice Hugo Black wrote that he could not see why "anyone should think the Federal Constitution imposes on the United States courts the burden of supervising the length of hair that public school students should wear." Justice William O. Douglas disagreed when the other justices turned such cases away.

**The Pawnee boys.** One of those cases came from Pawnee boys in Oklahoma. The boys wore their hair parted in the middle with a long braid on each side, to follow "the old traditional ways." One of them said it was "one way of telling people that I am proud [to be an Indian]."

Officials at Pawnee Junior High School suspended the boys with no end date on April 24, 1972, under a rule that a boy's hair could not reach his collar or his ears. The first name on their case is Norman New Rider. Federal appeals judges ruled that the school could keep its rule. On December 10, 1973, the Supreme Court justices refused to hear the case. Justices Douglas and Thurgood Marshall disagreed. Douglas wrote that the boys were telling other students of "their pride in being Indian."

**From Nebraska to Oklahoma.** The Pawnee Nation once lived in Nebraska and northern Kansas, and the Sioux attacked the Pawnee there for four decades. In 1874 the Pawnee began a two-year removal, a move of the whole nation away from its homeland, to Indian Territory, which later became Oklahoma. Some accounts say the Pawnee were forced to go. The US government's agent for the Pawnee chose their new reservation, on land that had belonged to the Cherokee.

### The Afro, braids and a court ruling

Many Black Americans straightened their hair before the 1960s. The creams they used to straighten it, called relaxers, often held lye, a chemical that could burn the scalp and the ears. In the 1960s many Black men and women in the "Black is beautiful" movement began wearing their hair natural. The Afro, hair combed out into a round shape, became a sign of Black pride. Angela Davis wore one in 1969. A person could keep up an Afro at home without paying a hairdresser.

Renee Rogers was an airport operations agent for American Airlines. The airline's managers had a rule against an all-braided hairstyle for workers in her job, and they told her to wear a hairpiece over her braids at work. She sued. On December 1, 1981, federal Judge Abraham Sofaer ruled for the airline.

Judge Sofaer ruled that a person can change a hairstyle but cannot change the texture of his or her hair. So, he ruled, the braid rule was not race or sex discrimination, treating people worse because of who they are, under the Civil Rights Act of 1964. The airline's lawyers said the style had been made popular by the actress Bo Derek, in the 1979 film *10*. Rogers said braids had a long history for Black women.

### Sneakers and hip-hop in the 1980s

In New York in the 1980s, hip-hop groups such as Run DMC wore white Adidas sneakers, jeans, hooded sweatshirts, gold chains and baseball caps.

Nike began selling its Air Jordan basketball shoe, made for the player Michael Jordan, on April 1, 1985. NBA officials fined Jordan $5,000 a game for wearing shoes in colors that broke the league's rules. Reports of the shoe's sales in its first year range from $126 million to more than $150 million.

**A killing for shoes.** Costly sneakers could make the young person wearing them a target. James David Martin, 17, killed Michael Eugene Thomas, 15, on May 2, 1989, to take his Air Jordans. Thomas was a ninth grader at Meade Senior High School in Anne Arundel County, Maryland, and he had bought the shoes for $115.50. Martin led him into the woods near the school, raped him, forcing him into a sexual act, and strangled him to death. Then Martin took the shoes and ran.

Martin pleaded guilty to voluntary manslaughter, killing a person on purpose but without planning it ahead, a crime the law treats as less serious than murder. He was sentenced to seven years in prison.

In May 1990 the writer Rick Telander published a cover story in the magazine *Sports Illustrated*, "Your Sneakers or Your Life," about young people robbed for their sneakers and jackets, some of them killed. Police in a few cities counted such robberies. Atlanta police reported more than 50 muggings for sports clothes in four months, and a Chicago police sergeant counted about 50 jacket crimes and a dozen shoe crimes a month. Each count covered only one city. Richard Lapchick of Northeastern University called the news reports of these crimes "grossly exaggerated."

### Slavery in a California sewing shop, 1995

State and federal officers and El Monte police raided a group of seven apartments in El Monte, California, near Los Angeles, on August 2, 1995. Inside they found 72 garment workers, people who sew clothes for a living, from Thailand. They had been held there and forced to sew.

Suni Manasurangkun, whom the workers called "Auntie," ran the shop with her sons. Recruiters in Thailand had promised the workers jobs, given them false passports and brought them to Los Angeles. The bosses took the passports and told each worker that he or she owed about $5,000 for the trip.

**Behind the wire.** A high fence topped with razor wire surrounded the apartments, and armed guards watched the workers. The guards showed them a picture of a man who had been beaten after he tried to escape. The records do not name who beat him. The workers sewed about 84 hours a week, from early morning to midnight, for about $1.60 an hour. Some of them had not been outside the fence for as long as seven years.

The officers learned of the shop after a woman escaped through a second-floor window. A letter written in pencil, with a map drawn by hand, reached the authorities. It said: "Very Dangerous. Please bring much manpower."

**Who paid.** The clothes carried "Made in the USA" labels and were sold in chain stores including Mervyn's, Montgomery Ward and Miller's Outpost. In February 1996 Suni Manasurangkun, three of her sons and three other people pleaded guilty to federal crimes. They were sentenced to up to seven years in prison. Two of her sons escaped the country and were never caught.

The workers sued the stores and clothing companies that had sold the clothes. In 1997 those companies agreed to pay the workers wages they were owed, and the lawsuits ended. The amount was $4 million by one account and more than $4.5 million by another.

### Rotchana Cheunchujit

> **Who:** A garment worker from Thailand who was held in the El Monte sewing shop until officers freed her in 1995.
>
> **When and where:** El Monte, California, the early 1990s to 1995.

**She was paid five to seven cents a piece.**

Rotchana Cheunchujit sewed blouses and other clothes in the El Monte shop for five to seven cents a piece. That came to about $300 to $500 a month. The owners took half her pay first. Then they made the workers buy food and supplies from the owners' own store, at high prices. The bosses told her she owed about $5,000.

She came from Thailand, where she had heard that jobs in Los Angeles paid three times as much. She left her two young children with her mother there, hoping the job would help her family. The smugglers who brought her said that for about $4,800 they would get her to the United States and set her up with a job. She could pay them back from her wages. She arrived in 1994.

**The raid.** She was 24 and in bed when federal agents broke down the door in the early hours of August 2, 1995. Someone called out in Thai: "We're here to help you." "We were in shock," she said. "We didn't know what was going on." Immigration officers then held her and the other workers for nine days, until Asian American groups paid their bail, money paid to a court so that a person can go free while a case goes on.

Later she became a US citizen, learned English and was reunited with her children. She married Steve Sussman, a professor at the University of Southern California, and took his name. She spoke up for other garment workers and opened a vegetarian Thai restaurant in Arcadia, California.

**If you remember one thing:** Between 1950 and 2000, plastics such as polyester and fiberglass went into everyday clothes and chairs, and students and workers went to court over armbands, long hair and braids.

- 1951: Hart, Schaffner & Marx begins selling suits made partly of polyester.
- 1969: Seven Supreme Court justices rule that students may wear black armbands to school.
- 1995: Officers free 72 Thai garment workers held behind razor wire in El Monte, California.

**Next:** After 2000, almost all the clothes Americans bought were sewn in other countries, and in Bangladesh more than 1,100 people were killed when a building full of garment factories collapsed.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 12 minutes**

Today almost all the clothes sold in the United States are sewn in other countries, and Americans throw away far more cloth than they did in 2000. They threw away 17 million tons of cloth in 2018, most of it clothing, by the count of the US Environmental Protection Agency. That was almost twice the 9.5 million tons they threw away in 2000.

Around the world, clothing sales more than doubled between 2000 and 2015, and people wore each piece fewer times, according to a 2017 report by the Ellen MacArthur Foundation.

**Who sews them.** Some of the clothes are sewn in Bangladesh, where a factory fire in 2012 and a building collapse in 2013 killed more than 1,200 people, most of them garment workers. Some of them had been sewing clothes for American stores.

In Los Angeles, garment workers were paid by the piece, often a few cents for each piece they sewed. Starting in 2022, a California law required pay by the hour, at least the minimum wage, the lowest hourly pay the law allows. After that, piece pay was allowed only as a bonus.

California lawmakers passed the first law against punishing workers or students for the natural texture of their hair in 2019. It also covers braids, twists and locs, long ropes of hair also called dreadlocks. Lawmakers in about 30 states have passed such laws since. Members of the CROWN Coalition, the group that worked for the first of those laws, counted the states.

### Where do Americans' clothes come from?

About 97 percent of the clothes and shoes bought in the United States are made in other countries, most of them in Asia. The American Apparel & Footwear Association, a group of clothing and shoe companies, gave that figure in April 2025, from its latest data.

Workers in Bangladesh are among those who sew clothes for American stores. In the year from 2021 to 2022, the country's garment factories earned $42.6 billion, about 82 percent of the money Bangladesh earned from goods sold to other countries. About 4 million people worked in them. According to a 2023 report by the International Labour Organization, which studies work and workers around the world, the typical garment worker in Bangladesh was a woman of 23 who had moved to the city from a farming area.

### The Tazreen fire and the Rana Plaza collapse

**Tazreen.** A fire started in a ground-floor warehouse of the Tazreen Fashions factory, on the edge of Dhaka, Bangladesh, on November 24, 2012. The building had nine floors. All three of its staircases led down through the ground floor, where the fire was. The fire killed at least 112 people, by the first count reported by the Associated Press. Later counts run from 117 to 124. Twelve people died jumping from windows.

Police arrested three supervisors and accused them of padlocking the exits. One survivor, Mohammad Ripu, said a manager told the workers: "The fire alarm had just gone out of order. Go back to work."

Workers at Tazreen had been sewing clothes sold by Walmart and other companies. In May 2011, inspectors checking the factory for Walmart had rated it high-risk. That same year Sridevi Kalavakolanu, Walmart's director of ethical sourcing, said that fire and electrical upgrades in factories were "not financially feasible for the brands." She meant they cost too much. Her job was checking how the companies that made goods for Walmart treated their workers.

After the fire, Walmart officials said a supplier, one of the companies that made clothes for Walmart, had sent work to the factory without permission, and they stopped doing business with that supplier.

**Rana Plaza.** Rana Plaza was a nine-story building in Savar, near Dhaka, with five garment factories on its upper floors. About 5,000 people worked in them. The building stood on a pond that had been filled in, and it was built in 2006 without proper permits, the government's written permission to build. Its owner, Sohel Rana, had the upper floors added without a permit. They were not built to hold the weight of factory machines and generators.

A Bangladeshi television channel showed cracks in the building on April 23, 2013. The shops and the bank on the lower floors closed. Sohel Rana told reporters that the building was safe. Factory managers ordered the garment workers back the next morning. Managers at the Ether Tex factory threatened to hold back a month's pay from any worker who stayed away.

The building fell at about 9 in the morning on April 24, 2013. It killed more than 1,100 people, 1,134 by the count of the Clean Clothes Campaign, a group that works for garment workers' rights. Counts of the injured run from about 1,500 to nearly 2,600. Some trapped workers could be freed only by amputating an arm or a leg, which means cutting it off.

Researchers for the Clean Clothes Campaign found at least 29 brands with recent orders at the factories in Rana Plaza. They included two American companies, Cato Fashions and The Children's Place. News reports also linked Walmart. Officials of J.C. Penney said that one factory there had made a small amount of clothing for another brand that Penney stores sold.

### After Rana Plaza

After the collapse, officials of more than 200 clothing companies, most of them European, signed a safety agreement that bound them by law. Officials of Walmart and other North American companies did not sign it. In July 2013 leaders of 17 North American store chains, including Walmart, Gap, Target and Macy's, announced a safety plan of their own. It had no promise, binding by law, to pay for repairs to the factories.

Clothing brands paid into a fund for the families of the dead and for injured workers. The fund reached its target only after more than two years, when the last brands, such as Benetton, paid in. By October 2015, more than $34 million had been paid out, according to the International Labour Organization. According to the Clean Clothes Campaign, some of the brands linked to the building never paid.

**In court.** The husband of a worker who died and a worker who was injured sued J.C. Penney, The Children's Place and Walmart in a Delaware court. On May 4, 2016, the judge threw out the case, ending it without a trial, for two reasons. The law of Bangladesh allowed one year to bring such a case, and that year had passed.

The judge also ruled that the companies were not the workers' employers. So under Delaware law the companies were not required to keep those workers safe. No court has found an American company responsible for the deaths at Tazreen or Rana Plaza.

Sohel Rana was arrested near the border with India on April 28 or 29, 2013. He was still held in custody in April 2026. In 2017 a judge sentenced him to three years in prison for hiding his wealth. As of April 2026, judges in his murder trial had heard 145 of the 594 listed witnesses. The trial had not ended, *The Business Standard*, a newspaper in Dhaka, reported.

### Paid by the piece in Los Angeles

Clothes are still sewn in Los Angeles, often in small shops that open and close quickly. In 2020 workers there were paid about 5 to 12 cents for each piece they sewed, according to the news site *CalMatters*. They worked about 10 hours a day, five and a half days a week, for about $300 a week in cash. That came to about $5.50 an hour, when the city's minimum wage was $15.

That year, at least 375 workers at the Los Angeles Apparel factory caught COVID-19, and four of them died.

**The new law.** Governor Gavin Newsom signed the Garment Worker Protection Act, which State Senator María Elena Durazo wrote, on September 27, 2021. From January 1, 2022, garment shops in California had to pay at least the minimum wage by the hour. They could pay by the piece only as a bonus on top. Workers could also claim unpaid wages from the brands and stores that sold the clothes.

Marissa Nuncio, director of the Garment Worker Center in Los Angeles, said in 2021 that the law applied to more than 45,000 garment workers in California. Most of them were immigrant women. In 2023 Remake, a group that works for garment workers, reported that a year after the law took effect some workers were earning the minimum wage, and others still reported wages they were owed and never paid.

### Francisco Tzul

> **Who:** A garment worker from Guatemala who sewed clothes in Los Angeles for decades, often for a few cents a piece, and told lawmakers about his work.
>
> **When and where:** Los Angeles and Sacramento, the 1990s to 2021.

**He sewed clothes that carried a TV star's name.**

Francisco Tzul watched Kathie Lee Gifford's television talk show in the 1990s and recognized her name. It was on the labels of clothes he sewed in Los Angeles. He was paid a few cents for each piece of the sewing work, about a dollar for each finished item. He shared a one-bedroom apartment with three friends.

He came from Guatemala, and by 2020 he had sewn clothes in Los Angeles for decades. That year he was 56 and was living in the United States without legal papers. He has told his story in interviews with the news sites *CalMatters* in 2020 and Knock LA in 2021.

**COVID-19.** He sewed face masks at the Los Angeles Apparel factory in 2020, and the factory paid him by the hour: $15, the city's minimum wage, plus overtime. That was far more than the $5.50 an hour that piece pay came to in the small shops. He caught COVID-19 there. "My respiratory system was completely blocked and I wasn't able to breathe at all," he said. He spent 10 days in the hospital. When he came out, his roommates told him to leave. Staff at the Garment Worker Center found him a hotel room for two weeks.

He went to Sacramento in 2021 to tell California's lawmakers about his work. He called the day the Garment Worker Protection Act was signed the best day of his life.

### What does the CROWN Act ban?

Under California's CROWN Act, employers and public schools may not treat people worse because of the texture of their hair, or because of styles such as braids, locs and twists. California became the first state with a CROWN Act on July 3, 2019. The name stands for "Creating a Respectful and Open World for Natural Hair." State Senator Holly Mitchell wrote the law with a group of supporters that included civil rights organizations and the company Dove.

New Jersey's governor, Phil Murphy, signed a CROWN Act on December 19, 2019. By July 2025, 27 states and Washington, D.C., had such laws, according to a list that GovDocs published. Pennsylvania's governor, Josh Shapiro, signed one on November 25, 2025. In September 2026 the CROWN Coalition, the group that worked for the first law, counted 30 states.

Members of the US House of Representatives passed a national CROWN Act in 2020 and again in 2022. Senators never voted on it. In September 2026 the United States had no national law against hair discrimination.

**Damon Landor.** Damon Landor's case over his hair went to court under a religious-freedom law, not a CROWN Act. Guards at a prison in Louisiana handcuffed him to a chair in 2020 and shaved off his dreadlocks. He had grown them for decades because of a promise he made as part of his Rastafarian religion, and he had three weeks left in his sentence. He showed the guards a court decision, and they threw it in the trash.

Six of the nine Supreme Court justices ruled on June 23, 2026, that he could not sue the guards for money under a federal law that protects the religious freedom of people in prison.

### Andrew Johnson

> **Who:** A high school wrestler in New Jersey whose locs were cut beside the mat so he could compete. His case led to a state law against hair discrimination.
>
> **When and where:** Buena, New Jersey, December 2018 to December 2019.

**The referee gave him 90 seconds: cut his hair or lose.**

The team's athletic trainer cut off Andrew Johnson's locs beside the wrestling mat on December 19, 2018, while the crowd watched, so that Johnson could wrestle. The referee, Alan Maloney, had told Johnson that his hair broke the rules. Maloney rejected the cover Johnson wore over his locs and gave him 90 seconds to cut his hair or lose the match. Johnson was a junior at Buena Regional High School, and this was a home match.

The trainer who cut his hair was a white staff member. Johnson won the match in overtime. A local sports reporter, Mike Frankel, posted a video of the haircut. NBC News reported that the video had been viewed more than 14.5 million times.

Johnson's family said that Maloney had arrived late. The family said he had missed the weigh-ins, where referees check each wrestler before a match, and had raised no problem with the hair there. In 2016 Maloney had been accused of calling a Black referee an insulting name for Black people at a party. He was suspended for it, and then allowed back after an appeal.

**What changed.** In September 2019 officials of the New Jersey Division on Civil Rights and of the state's school sports association agreed that Maloney would be suspended for two seasons. They also agreed that all wrestling officials in the state would be trained that the rule is about the length of hair, not its style. On December 19, 2019, one year after the match, Governor Phil Murphy signed New Jersey's CROWN Act.

### Where old clothes go

Americans threw away about 1.8 million tons of cloth in 1960. In 2018, the latest year the US Environmental Protection Agency has counted, they threw away 17 million tons, more than nine times as much. About 13 percent of old clothes and shoes were recycled that year. Another 3.2 million tons of cloth were burned to make power, and 11.3 million tons went to landfills.

The Ellen MacArthur Foundation reported in 2017 that, around the world, one garbage truck's worth of cloth is dumped or burned every second.

In April 2026 ThredUp, a company that sells used clothing online, published a report with the research firm GlobalData. It stated that in 2025, sales of used clothes in the United States grew nearly four times as fast as sales of clothes in general. ThredUp's researchers expect sales of used clothes to reach $78.8 billion a year by 2030. Nearly half of the shoppers they surveyed said they find used items through social media.

**The three questions, answered**

- Why did lawmakers and officials make rules about other people's clothes and hair? To keep rank where everyone could see it, and to control the people below them: Massachusetts fined people worth less than 200 pounds for wearing silk, South Carolina held enslaved people to coarse cloth in 1740, and a federal official ordered Native men's hair cut in 1902. Since 2019, CROWN Acts in about 30 states have turned the rule around and forbidden punishing people for natural hair, braids, locs or twists.
- Who made the cloth Americans wore? Native weavers first, then enslaved people who grew the cotton and made the indigo, and mill workers in New England. Today almost all of it is sewn in other countries, by workers in places like Bangladesh, and in small Los Angeles shops where workers were paid by the piece until a California law required hourly pay in 2022.
- Which new materials changed what Americans wore? Churro wool, brought in 1598, became the main thread for weaving in New Mexico. Dyes made from coal tar, from 1856, gave clothes new colors such as mauve. In the 1920s "artificial silk" let more women dress in the new styles. Nylon made stockings from 1939, and polyester suits from 1951 could be washed and worn without ironing.

**What changed:** Before 1500 people here made blankets from turkey feathers and yucca cord, and today about 97 percent of the clothes and shoes Americans buy are made in other countries.

**Five dates to keep**

- 1651: Massachusetts lawmakers fine people worth less than 200 pounds for dressing like gentlemen.
- 1740: South Carolina's Negro Act holds enslaved people to coarse cloth.
- 1856: William Henry Perkin makes the first man-made dye, a purple, from coal tar.
- 1939: DuPont sells its first nylon stockings.
- 2013: Rana Plaza collapses in Bangladesh, and more than 1,100 people are killed.

**Not known:** The surviving records do not show how often anyone took an enslaved person's clothes under South Carolina's 1740 law.

**Where to go:** George Washington's Mount Vernon, in Virginia, holds the brown wool coat he wore when he took the oath as president in 1789.

**Next:** Chapter 36, Sports and Play. It asks who was allowed to play, from chunkey at Cahokia to the leagues and screens of today.
