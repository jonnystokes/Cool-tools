# Before You Start

This book is long. It contains about 830,000 words, which take about 69 hours to read at 200 words a minute.

The order does not matter. Start with any chapter, or with any era inside one. A hard word is explained the first time it appears in a chapter, so if you start in the middle and meet a word you do not know, look it up in the glossary at the back.

Skipping is fine. The card at the top of each chapter lists the sections you can skip, and the chapter still makes sense without them. Read the boxes with a person's name at the top, because they contain many of the main stories.

When a page feels heavy, stop at the next bold line. The end of each long era states the one thing to remember from it. Read that line, then come back later or go to another chapter.
