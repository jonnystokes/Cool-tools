# Four Ways to Read This Book

The times below are at 200 words a minute. That is a quick reader's pace, and many readers take longer, which is fine. Each chapter's card states that chapter's time, and the first bold line of each era states the era's.

### 1. Straight through

Read the 37 chapters in order, from Exploration and Discovery to Holidays. That takes about 69 hours. The shortest chapter, Home and Family Life, takes about 1 hour. The longest, Rights and Movements, takes about 4 hours 40 minutes. Most take between 1 hour 15 minutes and 2 hours 20 minutes.

### 2. One subject

Pick one chapter from the contents and read it start to finish. Every chapter includes all ten eras, so you follow one subject from before 1500 to today. In some chapters the first era starts thousands of years ago.

### 3. One era, every subject

Pick one of the ten eras and read that era in every chapter, in the order of the contents. That gives you the whole country in one stretch of time: what people were eating, building, singing and fighting over in the same years.

- Before 1500: about 2 hours 15 minutes
- The 1500s: about 2 hours 30 minutes
- The 1600s: about 5 hours
- 1700 to 1750: about 3 hours 30 minutes
- 1750 to 1800: about 5 hours 30 minutes
- 1800 to 1850: about 7 hours 30 minutes
- 1850 to 1900: about 10 hours 30 minutes
- 1900 to 1950: about 11 hours 30 minutes
- 1950 to 2000: about 10 hours
- 2000 to today: about 8 hours 45 minutes

### 4. The short road

Read "The History in Ten Paragraphs," which comes next. Then read the card at the top of each chapter and the closing at its end. The 37 cards take about 1 hour, and the 37 closings take about 1 hour 5 minutes. Reading the sections listed under "Five minutes?" on the cards adds about 1 hour 30 minutes. The whole short road takes about 3 hours 45 minutes, and it reaches every subject in the book.
