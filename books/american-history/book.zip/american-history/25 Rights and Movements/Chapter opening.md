# Chapter 25: Rights and Movements

**Chapter 25 of 37 · Rights and Movements · 10 eras · about 280 minutes**

**Most of the rights Americans have today were won by people who were first refused them and kept asking for years. Organizing often cost them their jobs, their freedom or their lives. Some of those rights were later taken away again.**

Four men at Germantown, in Pennsylvania, signed a paper against owning enslaved people on April 18, 1688, and sent it to their Quaker church. The members of four church meetings read it, one after another, and passed it on without doing anything. Then the Quakers forgot it. People working to end slavery found it again in 1844, and it went missing a second time. In March 2005 it turned up in a vault in a Philadelphia meetinghouse. Haverford College, in Pennsylvania, keeps it now.

This chapter follows people who were told no: women, Black Americans, Native nations, Chinese and Mexican Americans, Japanese Americans, gay and transgender Americans, and disabled Americans. It goes era by era, from the clan mothers of the Haudenosaunee to the courtrooms of 2026. Watch how the methods grow. The first tools are a petition and a printed booklet. Later come the planned arrest, the boycott, the march, the sit-in, and the lawsuit brought on purpose to test a law. Watch, too, what each step costs, and how often a right that was won had to be won a second time.

**Three questions this chapter answers**

- How did people without power get the people in power to listen?
- What did organizing cost the people who did it?
- Can a right that has been won be taken away again?

**Five minutes?** Read "Selma and the Voting Rights Act, 1965" in 1950 to 2000.

**Can skip:** "Two men climb the Gateway Arch, 1964", "Suffragists remember the clan mothers, 1891 and 1893", "Equal pay for the women's soccer team, 2016 to 2022". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 3 minutes**

No record shows a rights movement in this land before 1500, but in at least one Native nation women held real power in government. A rights movement is a group of people who organize together to change a rule that denies them something.

About six hundred Native nations lived north of the Rio Grande, the river along part of today's border with Mexico, in 1492. Each one governed itself in its own way. The clearest record of women's power comes from the Haudenosaunee, a union of five nations in what is now New York, where women chose the chiefs and could remove them.

### The clan mothers of the Haudenosaunee

The Haudenosaunee Confederacy has five founding nations: the Seneca, the Cayuga, the Onondaga, the Oneida and the Mohawk. The Onondaga Nation's own account places the founding on the shores of Onondaga Lake, in what is now central New York. The Onondaga still describe how their women choose leaders.

Each clan, a group of related families, has a clan mother. She chooses the man who speaks for her clan in council, the meeting where the chiefs talk and decide together. His title is Hoyane, which means chief. In the Onondaga account, a figure called the Peacemaker placed deer antlers on the headdress of every Hoyane to show that the man was a chief.

**Taking the antlers.** The clan mother can also start the removal of a chief. If he stops speaking for his clan, she warns him that he is not following the ways of the Great Peace, the laws the five nations agreed to live by when they joined together. If he still does not change, the clan removes him in council and takes his antlers off. The Onondaga say he has been "de-horned."

Haudenosaunee women held other powers too. An article by the National Park Service, the federal office that runs the national parks and historic sites, states that the women grew the food and shared it out, and through that work "controlled the economy" of their nations. They also held "the final authority over land transfers and decisions about engaging in war." They had the last word on giving land to anyone else and on going to war.

When a husband and wife separated, the wife took with her all the property she had brought into the home. The children went with her too.

**When the union began.** No one can prove when the five nations agreed to the Great Law of Peace. The Haudenosaunee keep their own account in spoken history and in wampum, belts and strings of shell beads that record agreements. By that account the date falls between about the year 1000 and 1400. Scholars working from written records mostly date it around 1450, the encyclopedia Britannica reports, and some date it to the late 1100s.

### What the records can and cannot show

Almost everything written down about how these nations governed themselves was written after Europeans arrived, by Europeans. The nations kept their own records in spoken accounts and in wampum, cut from the white and purple parts of clam shells and woven into strings and belts.

The Onondaga Nation describes how a belt works. A speaker puts the words of an agreement into the wampum while the belt is woven. Every speaker after that uses the belt to remember the agreement and what has happened since. The Onondaga have kept the Confederacy's wampum since its founding.

**Not known:** No record from before 1500 in this land names a single person who claimed a right that others denied.

## The 1500s

**Era 2 of 10 · The 1500s · about 5 minutes**

Under Spanish law in the 1500s, settlers forced Native people to work for them. Nobody here organized to change that law. The loudest objection came from a Spanish priest, Bartolomé de Las Casas, who argued in Spain that Native people had rights.

People also fought back. Enslaved Africans at San Miguel de Gualdape, a Spanish settlement on the coast of what is now Georgia or the Carolinas, rose up and escaped in October 1526. It is the first rebellion of enslaved Africans on record in what became the United States.

### What was the encomienda?

The encomienda was a grant from the Spanish king that gave a settler the labor of a named group of Native people. It was one of the Spanish systems for forcing Native people to work.

On paper, the settler had to protect the people and teach them Christianity. In practice, he forced them to work for him and took the food and goods they produced. The historians who wrote the open textbook *The American Yawp* call it "an exploitive feudal arrangement in which Spain tied Indigenous laborers to vast estates." It used Native workers for the settlers' gain and bound them to huge farms, the way farm workers in old Europe were bound to a lord's land.

The same historians write that the settlers who held these grants "brutalized their laborers," beating and hurting the people who worked for them. Las Casas reached the Caribbean in 1502. He later wrote that he saw Spaniards "cut off the Hands, Noses, and Ears, both of Indians and Indianesses," meaning Native men and women. They did it, he wrote, "for no other reason, but only to gratify their bloody mindedness," for the pleasure of hurting people.

**Hispaniola.** On the Caribbean island of Hispaniola, Spaniards enslaved the Taíno, the Native people of the islands, and made them dig for gold. When the gold ran out, the Spaniards forced them to work on the encomienda farms. The Native population of Hispaniola fell from 60,000 in 1508 to fewer than 20,000 ten years later. Fewer than one person in three was left.

The authors of *The American Yawp* write of the Spaniards' "casual violence and dehumanizing exploitation," treating people as if they were not human. Within a few generations, the same authors write, the whole island had been emptied of its Native people.

King Charles I of Spain ended the encomienda in 1542 with a set of rules called the New Laws. Spanish officials replaced it with another forced-labor system, the repartimiento, and Spanish settlers went on forcing Native people to work for them.

### Bartolomé de Las Casas

Las Casas was a priest with the Spanish soldiers who killed the Taíno gathered in a Cuban town in 1513. He spent the rest of his life arguing for Native people. At first he also asked for enslaved Africans to take their place.

He went to Cuba in 1513 as a chaplain, a priest who travels with soldiers, with the Spanish forces who were taking the island from the Taíno. At the town of Caonao, the Taíno had made cassava bread and fish for the soldiers under Captain Narváez. About two thousand people sat in the town square, and more than five hundred were in a large house nearby.

In his *History of the Indies*, Las Casas wrote what happened next. One Spaniard drew his sword, and then the whole hundred soldiers drew theirs. They began "to rip open the bellies, to cut and kill" the men, women, children and old people, who were all sitting down. They went into the large house and killed the people there too. Some escaped by climbing to the top of the house. Las Casas was in the town, but he had stepped away to another square shortly before the killing began.

**Giving up his grant.** For serving with the soldiers, Las Casas received land and an encomienda. In 1514 he told the people of his church that the whole encomienda system was wrong. He freed the Native people he held and began arguing for them to the Spanish officials on the island.

**The request he later regretted.** Two years later, in 1516, Las Casas asked the Spanish king to bring enslaved Africans to the Indies, Spain's islands and lands across the Atlantic, to take the place of Native workers. He believed Africans were better suited to hard physical labor. Slave traders had already been carrying enslaved Africans across the Atlantic for about sixteen years.

King Charles I of Spain, later Emperor Charles V, gave a man named Lorenzo de Gorrevod a charter, a written permission, to ship enslaved Africans across the Atlantic. The date was August 18, 1518.

Las Casas also wrote a short book about what Spanish settlers did to Native people, *A Brief Account of the Devastation of the Indies*. Its Spanish title is *Brevísima relación de la destrucción de las Indias*. Soon after he wrote it, King Charles issued the New Laws of 1542.

**The debate at Valladolid.** Charles V called Las Casas and a scholar named Juan Ginés de Sepúlveda to the town of Valladolid, in Spain, in 1550. The question was whether the Spanish had the right to make war on Native people and rule them by force. Sepúlveda argued that they did. Las Casas argued that they did not.

The two men spoke in front of a panel of churchmen and royal officials, among them the church scholars Domingo Soto and Melchor Cano. On the first day Sepúlveda spoke for three hours. The panel held its final meeting in 1551. Andrea Daher, a scholar writing for an encyclopedia of Sorbonne University in Paris, records no ruling by the panel.

Later in life, Las Casas changed his mind about enslaving Africans. In his *History of the Indies* he wrote at length against the African slave trade and the slave markets of Spain and Portugal. He did not publish that book while he was alive, so his change of mind was not public while the trade grew.

## The 1600s

**Era 3 of 10 · The 1600s · about 10 minutes**

In the English colonies of the 1600s, the men in charge punished people who spoke against them. The records name the people they punished. English colonists also brought English law with them, and under one of its rules a married woman did not count in law as a person separate from her husband. Nobody organized against that rule in this century.

The colony's leaders banished Anne Hutchinson from Massachusetts in November 1637 for what she taught in her own house. Massachusetts officials hanged Mary Dyer on Boston Common in 1660 for coming back to the colony as a Quaker, a member of a new religion that the colony's leaders had outlawed. In 1688 four men in Pennsylvania signed a protest against slavery and sent it to their church.

### Coverture: what marriage did to a woman in law

The rule was called coverture. In law, a married woman was "covered" by her husband. The legal name for her was *feme covert*, a covered woman, and she had no legal standing of her own.

She did not control property, even property she had brought into the marriage. Her husband had full rights to any money or wages she earned. She could not sign a contract, a written deal that a court can make people keep. Nobody could take her to court, and she could not bring a case to court in her own name.

An adult woman who had never married, or whose husband had died, was a *feme sole*, a woman on her own. She could buy and sell property, sign contracts and go to court in her own name. Under English law, a woman lost those rights on the day she married.

**Daily life.** Wives ran businesses beside their husbands, and for husbands who were away. Some married women traded in their own names under a legal exception, and the people of their town held everyone to the deal. Under the law, whatever a wife held, she held because her husband allowed it.

### Anne Hutchinson

> **Who:** A Boston woman whom the colony's leaders tried and banished for what she taught at religious meetings in her own house.
>
> **When and where:** Boston and Newtown, Massachusetts Bay Colony. Meetings from 1636, trial in November 1637, put out of her church in March 1638.

**"You have power over my body," she told the men judging her.**

Anne Hutchinson came to Boston, an English town built on Massachusett land, with her husband, William, and their children in 1634. From 1636 she held a weekly meeting in her house to go over the Sunday sermons. At first only women came. Then men came too, including some of the most important men in the colony.

Like the colony's leaders, she was a Puritan, one of the English Protestants who had come to Massachusetts to worship God in their own way. Puritans used the word grace for God's gift of being saved, of going to heaven after death. Hutchinson taught that God saved people by grace alone, and not because they behaved well. She also said she could tell which ministers and which neighbors had received it.

**The trial.** In November 1637 the colony's lawmakers, called the General Court, tried her for heresy, teaching against the church's beliefs. They sat as judges at Newtown, the town now called Cambridge, and the trial lasted two days. Governor John Winthrop told her she was "called here as one of those that have troubled the peace of the commonwealth," meaning the colony. He called her meetings "a thing not tolerable nor comely in the sight of God nor fitting for your sex."

She answered his Bible verses with Bible verses of her own. At the end she said God had spoken to her directly, by "an immediate revelation," and that God would curse the Puritans and their families for generations if they harmed her. The judges called that blasphemy, speaking against God. She told them, "You have power over my body, but the Lord Jesus hath power over my body and soul."

The trial record states the sentence: "Mrs. Hutchinson, the sentence of the court you hear is that you are banished from out of our jurisdiction as being a woman not fit for our society." A jurisdiction is the area a government rules, and banished meant forced out of it and forbidden to return. She asked, "I desire to know wherefore," or why, "I am banished?"

**The second trial.** Colony officials held her through the winter. In March 1638 the leaders of the Boston church tried her again and put her out of the church. Their charge said she had "rather been a Husband than a Wife and a preacher than a Hearer." It went on, "and a Magistrate than a Subject." A magistrate was an official with the power to judge cases.

That spring the family moved to Aquidneck Island, in what became Rhode Island, on land the minister Roger Williams helped them buy from the Narragansett. One of the first written rules of their new town, Portsmouth, said no person should be punished or "called into question on matter of religion ... so long as he keeps the peace."

**Her death.** After her husband died, she moved in 1642 to Dutch-held land on Long Island Sound, the country of the Siwanoy, a Native people. The next winter the Dutch governor, Willem Kieft, and his council approved attacks by Dutch soldiers and armed settlers on the Native people of the region. On the night of February 25, 1643, those men murdered at least eighty Munsee people, and perhaps as many as 120.

The war that followed lasted until 1645. In August or September 1643, during that war, Siwanoy warriors killed Anne Hutchinson, her servants and all but one of the children who were with her. One daughter survived.

### Massachusetts leaders outlaw Quakers, then hang four of them

Massachusetts officials hanged a woman named Mary Dyer in 1660 because she kept coming back to the colony as a Quaker. The Quakers followed George Fox, an Englishman who taught that men and women were equal in God's eyes. Quakers refused to take their hats off to people of higher rank, because they believed all people were equal. They also refused to swear oaths, solemn promises made in God's name, to any government. Massachusetts Governor John Endecott called them a "pernicious sect," a harmful religious group.

**The laws.** The men of the General Court passed a series of laws against Quakers. In late 1656 and 1657 they outlawed "the cursed sect of heretics commonly called Quakers." They fined ship captains who brought Quakers to the colony and people who owned Quaker books.

In October 1657 they set punishments for Quakers who came back after being sent away. A man who came back once was to have one ear cut off with a blade, and a man who came back a second time was to lose the other ear. For a third return, the law stated, "they shall have their tongues bored through with a hot iron," a hole burned through the tongue with a heated iron rod. For women who came back, the law set whipping on the bare back.

**Three men's ears.** The colony's leaders used that law in 1658 against a Quaker named Christopher Holder and two other Quaker men. One of the two was John Rous. Governor Endecott sent Rous to prison, and on September 7, 1658, Rous was sentenced to have his right ear cut off. A British reference book, the *Dictionary of National Biography*, states that the cutting was done inside the prison, although the law called for it to be done in public.

A chronology by the law professor Douglas Linder gives a different date for the cutting of the three men's ears, June 3, 1658. Linder adds that the men were also whipped, and then beaten twice a week for nine weeks. Neither account names the judges or the men who did the cutting, the whipping and the beating.

On October 19, 1658, the men of the General Court voted 12 to 11 to banish Quakers "upon pain of death." Under that law, a Quaker who came back after being sent away could be hanged.

**Mary Dyer.** Dyer had lived in Boston in the 1630s and was a close friend of Anne Hutchinson. When church leaders put Hutchinson out in March 1638, Dyer walked out of the church beside her. Around 1650 she met George Fox in England, and she came back to Boston as a Quaker in 1657. Officials jailed her as soon as she landed. She spent two and a half months in a dark cell with its windows boarded up.

Her husband got her out by promising she would not preach, and the family moved to Rhode Island. She kept going back to Massachusetts to stand by Quakers who were in prison there.

Governor Endecott sentenced Mary Dyer and two Quaker men to death on October 20, 1659. The men were William Robinson, a merchant from London, and Marmaduke Stephenson, a farm worker from Yorkshire. Dyer's son, William Dyer, asked the governor to spare her.

On October 26 Endecott signed an order giving her 48 hours to leave the colony. First, the order said, she must be taken to the gallows, the wooden frame used for hangings, and stand there with a rope around her neck while the two men were hanged. Officials hanged Robinson and Stephenson in front of her on October 27, 1659. Then they took her back to prison and sent her out of the colony.

She came back to Massachusetts in 1660. Her husband asked for her life, and she refused to say she was sorry. On June 1 officials hanged Mary Dyer near the Frog Pond on Boston Common, on the sentence of Governor Endecott and the General Court. About 200 soldiers stood around the gallows with guns, swords, long spears called pikes, and flags.

**The count.** Officials hanged a fourth Quaker in Boston in 1661, William Leddra, a cloth maker and Quaker minister from Cornwall, in England. An English Quaker named Edward Burrough counted what had been done to Quakers in Massachusetts between 1656 and 1660. His count lists 64 jailings and 25 banishments. King Charles II of England ordered the punishments stopped on September 9, 1661, and said accused Quakers must be sent to England instead. By 1677, Quakers could meet openly in Massachusetts.

### Four men sign a protest against slavery, 1688

Four men at Germantown, in Pennsylvania, signed a paper against owning enslaved people on April 18, 1688. Their names were Garret Hendericks, Francis Daniel Pastorius, Derick op de Graeff and Abraham op de Graeff. They sent it up through the meetings of their Quaker church. A National Park Service page calls it the first protest against African slavery made by a religious body in the English colonies.

Germantown stood on the land of the Lenape, the Native people of the Philadelphia region. Pastorius had bought the land in 1683 from William Penn, a Quaker to whom King Charles II had given a charter for Pennsylvania in 1681. The surviving records of that sale do not name the Lenape families who lived on it.

The protest rested on the Golden Rule, the teaching that people should treat others as they want to be treated. In the paper's own spelling, the rule was "that we shall doe to all men licke as we will be done ourselves."

**Up through the meetings.** A Quaker meeting is a group of Quakers who worship and make decisions together. A monthly meeting is a local group, a quarterly meeting joins several local groups, and a yearly meeting joins the Quakers of a whole region. The members of four meetings, one after another, read the paper and passed it on without acting. The first three were Germantown Monthly Meeting, Dublin Monthly Meeting and Philadelphia Quarterly Meeting.

The last was Burlington Yearly Meeting, in New Jersey, and its members voted to take no stand either way. Nothing changed because of the protest.

**Lost and found.** The Quakers put the paper aside and forgot it. Abolitionists, people working to end slavery, found it again in 1844.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 5 minutes**

Single men, each writing on his own, printed the arguments against slavery in these fifty years. No organized group yet worked for anyone's rights, and the Quakers began to argue about slavery among themselves. Quaker leaders punished the members who raised the question first. By 1776 the Quakers of Philadelphia had changed their own rules anyway and banned slaveholding among their members. The era's last section runs past 1750, to 1778, to finish that story.

### A Boston merchant writes a pamphlet against slavery, 1700

Samuel Sewall, a Boston merchant and magistrate, wrote a three-page pamphlet called *The Selling of Joseph* in 1700. A pamphlet is a short printed booklet. A Massachusetts Historical Society page calls it the first antislavery pamphlet published in America. Bartholomew Green and John Allen printed it in Boston.

Sewall argued that taking people and selling them is the crime the Bible calls man stealing, and he pointed to the verse Exodus 21:16. Then he went through the usual arguments in favor of slavery and answered each one.

**Adam's case.** Sewall wrote it because of a case in Boston. That year a petition, a written request signed by many people, went around Boston asking for the freedom of an enslaved man named Adam and his wife. The petition said they were "unjustly held in Bondage" by a merchant named John Saffin. Saffin had promised Adam his freedom after seven years of good behavior, and when the seven years were up, he would not free him.

Saffin printed an answer to Sewall in 1701, defending slavery and his own treatment of Adam. Adam went to court, and in 1703 he won his freedom. Sewall answered Saffin again in 1705 by reprinting an English attack on the slave trade.

### Quakers who spoke first, and what their church did to them

Among the Quakers, an argument about slavery kept going in these years, and their own church leaders spoke out against the first Quakers who pressed it. Ralph Sandiford published *A Brief Examination of the Practice of the Times* in Philadelphia in 1729. It argued against owning slaves, and Quaker leaders spoke out against it in public.

**Benjamin Lay in Barbados.** Benjamin Lay was born in Essex, in England, in 1682. From 1718 he and his wife spent about eighteen months in Barbados, an island in the Caribbean where enslaved Africans already outnumbered the white settlers by 1660, about 27,000 to 26,000. He later wrote that there he "saw and heard of such very great Barbarity," or cruelty, "used toward the Slaves, Night and Day."

A man named Richard Parrot whipped the people he enslaved "very severely" every Monday morning. One of them, a barrel maker, told Lay he would not be whipped on Monday morning, and he killed himself on a Sunday. Hungry enslaved workers came into the Lays' shop to buy, to beg, and sometimes to steal food. Lay wrote that when he caught them he sometimes whipped them, "but I have been sorry for it many times."

**Near Philadelphia.** Lay then settled near Philadelphia. He was just over 4 feet tall, with a hunched back and thin arms and legs. For a time he lived in a cave with a library of about 200 books. His wife, Sarah Lay, was also small and had a curved spine. She was a recorded Quaker minister, a speaker her meeting officially recognized.

Lay published a book against slaveholding in 1737 with a long title: *All Slave-Keepers That Keep the Innocent in Bondage, Apostates*. An apostate is a person who has abandoned their faith. Benjamin Franklin printed it and left his own name off it.

Quaker leaders spoke out against the book, and the Quakers of Philadelphia Yearly Meeting disowned Lay. Disowning was a formal statement that a member no longer shared an essential part of the faith. The member's name came off the list, and he could no longer hold certain offices, though he could still come to worship. Sarah Lay stayed a member all her life.

**The sword and the book.** At the yearly meeting's gathering in Burlington, New Jersey, in 1738, Lay stood up in front of the Quakers there. His words began, "Oh, all you negro masters, who are contentedly holding your fellow-creatures in a state of slavery during life," using the word of the time for Black people. He threw off his plain Quaker cloak. Underneath he wore a soldier's uniform, in front of people who were committed to peace.

Holding people as slaves, he said, was as right, or "as justifiable," as "if you should thrust a sword through their hearts, as I do through this." Then he drove a sword into a hollowed-out book. Inside it he had hidden an animal bladder filled with pokeberry juice, and the red juice sprayed the people near him.

The Quakers carried him out and laid him on the doorstep. He lay there for the rest of the day, so everyone leaving had to step over him. Lay died in 1759.

### The Quaker meetings change their rules, 1754 to 1778

Quakers changed their rules about slavery step by step after 1750. The Quakers of Philadelphia Yearly Meeting published a paper in 1754 that called slavery a sin, and sent it to other meetings. Four years later the members of the yearly meeting spoke out against buying and selling people, but still allowed members to keep the people they already held.

**The ban.** Philadelphia Yearly Meeting's members banned slaveholding among themselves in 1776, 88 years after the four men at Germantown signed their protest. A Quaker who held people in slavery could now be disowned, and Philadelphia Quakers disowned the first members for it in 1778.

Quakers in other regions made the same change in those years. The members of New England Yearly Meeting made slaveholding a reason to disown a member in 1773. New York Quakers spoke out against slaveholding in 1774, and North Carolina Quakers made it a reason to disown a member in 1776.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 11 minutes**

People left out of the Revolution's promises answered with the Revolution's own words. The delegates to the Continental Congress voted on July 4, 1776, to adopt the Declaration of Independence, which states that "all men are created equal." The men who wrote the new state constitutions of 1776 kept women from voting, except in New Jersey.

Black taxpayers in Massachusetts asked why they paid taxes without a vote. In New Jersey, some women and some free Black men voted for thirty-one years, until the state's lawmakers took the vote away in 1807. In Philadelphia, a group of men formed a society in 1775 to help free people who had been seized and held as slaves against the law.

### Dinah Nevil and the first antislavery society, 1775

The Philadelphia antislavery society of 1775 started because one woman said she was free. Her name was Dinah Nevil, and the records call her an Indian woman, meaning a Native American. A Virginia man named Benjamin Bannarman bought Nevil and her four children from Nathaniel Lowry of New Jersey in 1773. When they were delivered in Philadelphia, Nevil said in public that she and her children were "free people."

The mayor of Philadelphia sent Nevil and her children to the city's Work House, a building where the city held people, to wait for a hearing. A group of Quakers led by Israel Pemberton brought a lawsuit for her. The case ran for two years. At the end, the judges ruled that Dinah Nevil and her children were slaves. The society's records do not name the judges.

**The society.** After that ruling and others like it, a group of men met at the Rising Sun Tavern in Philadelphia on April 14, 1775. They formed the Society for the Relief of Free Negroes Unlawfully Held in Bondage. Sixteen of the 24 first members were Quakers. Thomas Harrison was the secretary, and Anthony Benezet was a member.

A Historical Society of Pennsylvania page calls it the first abolition society in the western world. Its first work was helping free people of color, people who were not white, who had been seized and held as slaves. The members stopped meeting in November 1775. Most of them were Quakers, who refused to fight in the war with Britain, and they believed that refusal would turn people against the society.

**How Nevil got free.** Dinah Nevil never won her case. Thomas Harrison, who had been caring for her and her children, used his own money in 1781 to buy the family from the man who claimed them. Then he freed them. Judges had kept rejecting her claim, and buying her was the only way left. Eight years had passed since she first said she was free.

**The society grows.** The society began meeting again on April 23, 1787, and let in members who were not Quakers. Its members elected Benjamin Franklin president. Later members included Benjamin Rush, Thomas Paine and John Jay. People in other states set up societies like it. New York had one by 1785, two years before the Philadelphia society met again. In 1787 Richard Allen, Absalom Jones and other Black Philadelphians formed their own group, the Free African Society.

The Philadelphia members got a charter in 1789, an official paper from the Pennsylvania government that recognized the society. They also took a longer name: the Pennsylvania Society for Promoting the Abolition of Slavery, for the Relief of Free Negroes Unlawfully Held in Bondage, and for Improving the Condition of the African Race. By 1790 Delaware, Maryland and Connecticut had societies too.

### Abigail Adams

> **Who:** A Massachusetts woman who asked her husband, while he helped lead a new country, to "Remember the Ladies" in its laws.
>
> **When and where:** Braintree, Massachusetts. Letters of March 31, April 14 and May 7, 1776.
>
> **Movie:** John Adams (2008 HBO miniseries). The series is about John Adams and his family. Abigail is a lead character, not the subject.

**"Remember the Ladies," she wrote. "I cannot but laugh," he answered.**

John Adams had been away at the Continental Congress in Philadelphia since 1774, and that summer he helped draft the Declaration of Independence. Abigail Adams stayed at home in Braintree, the town now called Quincy, Massachusetts, and ran the family farm and its money. The couple wrote to each other often. The Massachusetts Historical Society keeps their letters.

On March 31, 1776, she wrote, in her own spelling, "I long to hear that you have declared an independency." She went on: "and by the way in the new Code of Laws which I suppose it will be necessary for you to make I desire you would Remember the Ladies, and be more generous and favourable to them than your ancestors."

"Do not put such unlimited power into the hands of the Husbands," she wrote. "Remember all Men would be tyrants if they could." Tyrants are rulers who use their power cruelly. "If perticuliar care and attention is not paid to the Laidies we are determined to foment a Rebelion, and will not hold ourselves bound by any Laws in which we have no voice, or Representation." To foment a rebellion is to stir one up.

**What she was asking about.** In 1776 coverture still governed marriage in the colonies, and a husband controlled everything his wife owned and earned. The rule was centuries old. An English lawyer, William Blackstone, had written it down a few years earlier in his *Commentaries on the Laws of England*, published from 1765 to 1769.

"By marriage, the husband and wife are one person in law," Blackstone wrote, "that is, the very being or legal existence of the woman is suspended during the marriage." While she was married, a wife did not exist in law as her own person.

**The colonists' own words.** In her March letter, Abigail Adams warned that women would not obey laws in which they had "no voice, or Representation." She was using the colonists' own complaint against Britain. That July the delegates accused the British king of "imposing Taxes on us without our Consent." They called "the right of Representation in the Legislature," a say in the body that makes the laws, "a right inestimable to them," too precious to measure.

**His answer.** John Adams wrote back on April 14, 1776: "As to your extraordinary Code of Laws, I cannot but laugh." He wrote that the war had "loosened the bands of Government every where," He listed who had grown bold: "That Children and Apprentices were disobedient," "that schools and Colledges were grown turbulent," meaning rowdy, and "that Indians slighted their Guardians and Negroes grew insolent to their Masters."

Slighted means treated without respect, and insolent means rude to someone in charge. By "Negroes" and "their Masters" he meant enslaved Black people and the men who enslaved them. He would not give up the men's power, he wrote, because that "would compleatly subject Us to the Despotism of the Peticoat." Despotism is rule by a tyrant, and a petticoat was a woman's underskirt. He meant rule by women.

**Her reply.** She wrote back on May 7, 1776: "I can not say that I think you very generous to the Ladies, for whilst you are proclaiming peace and good will to Men, Emancipating all Nations, you insist upon retaining an absolute power over Wives," emancipating meaning setting free. She added that "Arbitary power is like most other things which are very hard, very liable to be broken," arbitrary power being power used however the ruler likes, with no rules to limit it.

No lawmakers in any state changed a law for women because of these letters, which were private. Her grandson Charles Francis Adams published a book of her letters, *Letters of Mrs. Adams, the Wife of John Adams*, in 1840, more than twenty years after she died.

### Some women and free Black men vote in New Jersey, 1776 to 1807

Unmarried women and free Black men who owned enough property could vote in New Jersey from 1776 to 1807. The state's constitution of 1776 gave the vote to "all inhabitants of this colony, of full age, who are worth fifty pounds ... and have resided within the county ... for twelve months." It did not say male, and it did not say white. The other states' constitutions of 1776 limited the vote to a "freeman," a "man" or a white man, and every one of them left women out.

**Who could pass the test.** Because of coverture, only unmarried women and widows could meet New Jersey's property test. A married woman could not own fifty pounds of anything, because in law everything she had belonged to her husband. Members of the state assembly said so in 1800: "Our Constitution gives this right to maids or widows black or white," maids meaning unmarried women. Some losing candidates later complained that married women had voted anyway.

**The names on the lists.** The state's election laws of 1790 and 1797 described the voter as "he or she." Researchers at the Museum of the American Revolution have found 163 women's names on nine lists of voters from 1800 to 1807. That count is the lowest possible number, because only nine lists survive.

Sarah Eoff, Margaret McDonald and Eleanor Boylan are on the 1800 list for Bedminster Township. Eleanor Boylan was a widow of about 51 when she voted. Four women of one family, Rebecca, Ann, Catherine and Sarah VanDike, voted together in October 1801. The 1801 list for Montgomery Township holds at least 46 women and at least four free Black men, among them Caesar Trent of Princeton.

**The vote taken away.** The men who made New Jersey's laws took the vote away in November 1807. Earlier that year, in February, Essex County held a vote on whether to build a new courthouse in Newark or in Elizabeth. People on both sides broke the rules and brought in voters who had no right to vote. In Elizabeth the votes counted came to 279 percent of the people allowed to vote, nearly three votes for every voter.

The new law limited the vote to "free, white, male citizens." It took the vote from women, from free Black men and from recent immigrants. In its opening paragraph the lawmakers wrote of "doubts" about letting "aliens, persons of color, or negroes" vote.

Aliens meant people from other countries who were not citizens. An exhibit by the Museum of the American Revolution says the lawmakers blamed women, people of color and newcomers for all the cheating, which the museum calls scapegoating, putting the blame on people who were not at fault.

**Why they did it.** Writers for the National Park Service, the New Jersey Historical Commission and the Museum of the American Revolution all say the lawmakers acted for party reasons, not out of a debate about women's rights. The museum's historians also link the law to the cheating in the courthouse vote. The two parties of the time were the Federalists and the Democratic-Republicans.

The three disagree about which party women's votes had helped. A National Park Service page says women often voted for the Federalists, and that the law helped the rival Democratic-Republicans before the 1808 presidential election. A New Jersey Historical Commission teaching sheet says Federalists had come to believe that women's votes helped the Democratic-Republicans.

### No vote, no taxes: Paul and John Cuffe, 1780

Seven free Black men of Dartmouth, Massachusetts, told the state's lawmakers in February 1780 that they should not be taxed if they could not vote. They were John Cuffe, Adventur Child, Paul Cuffe, Samuel Gray, Pero Howland, Pero Russell and Pero Coggeshall. John and Paul Cuffe were brothers. Gray, Howland and Russell signed with a mark instead of a written name.

The petition said that "by reason of long bondage and hard slavery, we have been deprived of enjoying the profits of our labor or the advantage of inheriting estates from our parents." They were taxed all the same, although "we are not allowed the privilege of freemen of the State, having no vote or influence in the election of those that tax us." It also said that "many of our colour (as is well known) have cheerfully entered the field of battle in the defence of the common cause," meaning they had fought in the Revolution.

The new Massachusetts constitution of March 1780 contained nothing that answered their complaint. The Cuffe brothers wrote to the county court and to the town's leaders, calling themselves both "Indian men" and "free Negroes." They refused to pay their taxes, and Dartmouth's town officials put them in jail for it.

### Prince Hall asks for schools, 1787

Prince Hall and other Black Bostonians asked the Massachusetts lawmakers for schools for their children in 1787. No law barred Black children from Boston's free schools, but the National Park Service records that Black students there "found themselves at the mercy of hostile teachers and fellow students." The petition said they "receive no benefit from the free schools in the town of Boston, which we think is a great grievance," a wrong worth complaining about, "as by woful experience we now feel the want of a common education."

The lawmakers turned the petition down. They turned down a second petition in 1796. In 1798 the families opened their own school, the African School. It met in the home of Primus Hall, Prince Hall's son.

### Judith Sargent Murray argues that women's minds are equal, 1790

Judith Sargent Murray published an essay called "On the Equality of the Sexes" in 1790. She was born on May 1, 1751, in Gloucester, Massachusetts. The essay ran in the *Massachusetts Magazine* under the pen name "Constantia," a made-up name for signing her writing.

She argued that men and women have equal minds, and that women fell behind only because girls did not get the education that boys got. One line of the essay asks "in what the minds of females are so notoriously deficient, or unequal." Unlike Abigail Adams's private letters, the essay was printed where anyone could read it.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 24 minutes**

Women who organized against slavery in these fifty years learned to gather signatures, print their arguments and speak to crowds, and then some of them turned the same methods to their own rights. Ministers, lawmakers and mobs attacked them for it. Black families in Boston campaigned to get their children into the city's schools.

Teachers in Hartford, Connecticut, began teaching deaf children together in sign language in 1817. At Seneca Falls, New York, in July 1848, more than 300 people met. One hundred of them signed a declaration that listed the wrongs men had done to women, and the people at the meeting voted to demand the vote.

### Deaf children taught together, 1817

The American School for the Deaf opened at Hartford, Connecticut, on April 15, 1817, in a building called Bennett's City Hotel. Seven pupils came full time in the first classes. Teachers taught them in sign language, using a method from France.

Thomas Hopkins Gallaudet founded the school with Laurent Clerc, a deaf French teacher whom Gallaudet brought back from Paris. A Hartford doctor, Mason Fitch Cogswell, and ten other Hartford men backed them. Cogswell's deaf daughter, Alice Cogswell, was one of the first pupils.

**Public money.** Connecticut's lawmakers voted the school $5,000 in October 1816, before it opened. An essay by John Crowley for the Disability History Museum calls that grant the first public money for educating Americans with disabilities. In 1819 members of Congress voted the school 23,000 acres of public land in Alabama, after a motion by Henry Clay.

It was land the United States had taken from Native nations, and the surviving accounts do not say which nation's land it had been. The school's leaders sold the land to build up an endowment, a sum of money kept and invested so that its earnings pay for the school's work.

### Girls ask for the same lessons as boys

Some of the first organized demands for women in these years were about schooling. Girls' schools usually taught manners and fine arts, and a few women opened schools that taught girls the subjects boys learned.

Emma Willard wrote *A Plan for Improving Female Education* in 1819 and addressed it to New York's lawmakers. She argued that young women needed the same subjects young men were taught. With the support of Governor DeWitt Clinton, she opened the Troy Female Seminary in Troy, New York, in 1821. A seminary was a school for older girls or young women.

Catharine Beecher and her sister Mary opened the Hartford Female Seminary in Connecticut on May 20, 1823. Their pupils studied geography, world history, Latin, rhetoric (the art of speaking and writing well), philosophy and the natural sciences. Within three years the school had 100 full-time pupils.

**Mount Holyoke.** Mary Lyon began raising money for a school for women in 1834. Gifts ran from six cents to $1,000. Women's sewing circles sent quilts and bedding, and the school's trustees, the people in charge of its money and buildings, gave stoves and furniture. She opened Mount Holyoke Female Seminary at South Hadley, Massachusetts, in 1837. Tuition was $60 a year.

A history page by Mount Holyoke College says Lyon "endured ridicule from those who felt her ambitious undertaking would be 'wasted' on women." It adds that "The idea of a college for women was horrifying to many people in the 1830s."

**Oberlin.** At Oberlin, in Ohio, women won the chance to earn a college degree in two steps. Oberlin stands on land that the college's own art museum calls "unceded ancestral lands" of the Erie, Wyandotte, Mingo and other Native nations, unceded meaning never given up by treaty or agreement.

Women studied beside men at Oberlin from its opening in 1833, but in a Ladies Course that ended with a diploma, not a degree. Four women entered the course that led to a bachelor's degree in 1837: Mary Kellogg, Mary Caroline Rudd, Mary Hosford and Elizabeth Prall. Rudd, Hosford and Prall graduated in 1841. Kellogg ran out of money, left, and came back later.

Oberlin was the first college to give bachelor's degrees to women in classes with men. It also became, in 1835, the first college with a rule of admitting Black students.

### Boston's Black families and the city's schools

Boston's Black families opened the African School in Primus Hall's house in 1798. They moved it into the basement of the African Meeting House in 1808, and in the mid-1830s it moved into the Abiel Smith School. The Smith School became the segregated school where most of Boston's Black pupils were taught, kept apart from white pupils by race. The members of Boston's Primary School Committee kept separate schools for Black and white children.

**The boycott.** William Cooper Nell and others organized a boycott of the Smith School in the late 1840s, which means families kept their children out of it in protest. They also gathered signatures against it.

**Sarah Roberts.** A father, Benjamin Roberts, asked the Primary School Committee four times to let his five-year-old daughter, Sarah, into the school nearest their home. To reach the Smith School she had to walk past five schools for white children. The committee's members refused each time, and in 1848 he sued the city of Boston. The Roberts family lost the case, and the committee's members kept the schools separate.

### Women petition Congress, 1829 to 1830

A petition is a written request to people in power, signed by the people who are asking. Women had no vote, and petitions were the way they first spoke to Congress about national questions. The House of Representatives' own historian says women first petitioned on political issues in 1829 and 1830.

The question was Indian removal, the plan to force the Cherokee and other Native nations off their land. Catharine Beecher wrote a *Circular Addressed to Benevolent Ladies of the United States* on December 31, 1829. "It may be, that female petitioners can lawfully be heard, even by the highest rulers of our land," she wrote. More than 1,500 women signed petitions to Congress against removal. The women of Steubenville, Ohio, called themselves "the feeblest of the feeble" in theirs, on February 15, 1830.

Members of Congress mocked the women in public. Senator Thomas Hart Benton of Missouri told "these ladies" to "sit down on the way side, and wait for the coming of the conquerors." In 1830 a majority in Congress voted for the Indian Removal Act.

### Maria W. Stewart speaks in Boston, 1832

Maria W. Stewart, a free Black woman, spoke at Franklin Hall in Boston in September 1832, to an audience that included men. A National Park Service page calls it one of the first recorded times an American woman of any race spoke in public.

Stewart was born in 1803 in Hartford, Connecticut. In her own words she "was left an orphan at five years of age" and "was bound out in a clergyman's family," sent to work as a servant in a minister's house. In Boston she and her husband, James W. Stewart, lived among the city's free Black families. William Lloyd Garrison printed her essay "Religion and the Pure Principles of Morality" in 1831 in his antislavery newspaper, *The Liberator*.

**Her words.** "How long shall the fair daughters of Africa be compelled to bury their minds and talents beneath a load of iron pots and kettles?" she asked in her speeches. She urged her listeners, "Sue for your rights and privileges."

Audiences turned against her. She scolded Black men in public for drinking too much, and some people objected that it was improper for a woman to speak in front of men. She gave a farewell speech on September 21, 1833. She asked, "What if I am a woman," and said it was "no use for me as an individual, to try to make myself useful among my color in this city."

She moved to New York in 1834 and taught school. She later worked as matron, the woman in charge of housekeeping and care, at the Freedmen's Hospital in Washington, where she died on December 17, 1879.

### Prudence Crandall and Sarah Harris

> **Who:** A young Black woman who asked to be taught, and the white teacher who was arrested, tried and attacked for teaching her and other Black girls.
>
> **When and where:** Canterbury, Connecticut, 1832 to 1834.

**"I want to get a little more learning," Sarah Harris told her teacher.**

Sarah Harris had finished primary school, and she wanted enough schooling to teach Black children in the town of Norwich. Her father handed out *The Liberator*, Garrison's antislavery newspaper. In 1832 she asked Prudence Crandall to let her into Crandall's school for girls in Canterbury, Connecticut. "I want to get a little more learning, if possible enough to teach colored children," she said, using the word of the time for Black people. "If you think it will be the means of injuring you, I will not insist on the favor."

Crandall admitted her. The white families took their daughters out of the school.

**A school for Black girls.** In the spring of 1833 Crandall went to Boston to see Garrison. Then she traveled around New England asking Black families to send their daughters. Her advertisements said the school would reopen on April 1, 1833, for "young ladies and little misses of color." About 24 pupils came, and most of them boarded in the house.

The man who led the fight against the school was Andrew T. Judson, a lawyer and politician who lived next door. "We mean there shall not be such a school set up anywhere in our State," he told the minister Samuel J. May. He also said, "They are an inferior race of beings, and never can or ought to be recognized as the equals of whites."

**The Black Law.** The lawmakers of the Connecticut General Assembly passed what people called the Black Law on May 24, 1833. Under it, a school in the state that took Black pupils from outside Connecticut without the town's permission was breaking the law. They wrote it to close Crandall's school.

Connecticut officials arrested Crandall on June 27, 1833, and she spent a night in jail. Judson led the case against her. At her first trial the jury could not agree. At the second, in October 1833, Judge David Daggett told the jury that Black Americans were not citizens, so the protections her lawyers pointed to did not cover her pupils. The jury found her guilty.

The judges of the Connecticut Supreme Court threw out the guilty verdict, the jury's decision, on a technical point on July 26, 1834. They did not rule on the law itself, so the Black Law still stood.

**The town against the pupils.** Canterbury's town officials went after the pupils too. Ann Eliza Hammond was a 16-year-old pupil from Providence, Rhode Island, who arrived in April 1833. Town officials used the state's vagrancy law against her, a law against people with no home or work in the town. Its punishment was whipping "on the naked body not exceeding ten stripes," up to ten lashes of a whip on bare skin. Crandall paid so that no one whipped her.

Shopkeepers would not sell to the school, and people threw stones and eggs at the pupils. Someone hung a dead cat at the school door. In January 1834 a fire set by an unknown person damaged the building.

**The last night.** A mob of armed men broke the windows of the house on the night of September 9, 1834, and went through it with weapons while Crandall and her pupils were inside. A National Park Service page states that the mob broke more than ninety windows. An account in the Online Review of Rhode Island History says five main windows on the first floor. No one was ever charged, and no record names the attackers. Crandall closed the school the next morning.

Crandall married a Baptist minister, Calvin Philleo, and moved west to Illinois and then Kansas. Connecticut's lawmakers voted her a pension of $400 a year in 1886, and she died in Kansas in 1890, aged 87. Sarah Harris became an abolitionist and a conductor on the Underground Railroad, helping people escape from slavery. In 1877 she traveled to Kansas to visit Crandall, and the two women wrote to each other about their old pupils.

**By 1834:** Women had petitioned Congress for the first time, a free Black woman had spoken to men and women in Boston, and a mob had closed a school for Black girls in Connecticut.

### Mobs attack the organizers, 1835 to 1838

White mobs in Boston, Alton and Philadelphia attacked people who organized against slavery between 1835 and 1838. The mobs broke up meetings, destroyed printing presses, burned a hall and killed a newspaper editor. No one was convicted for any of the three attacks.

**Boston.** A mob of about 5,000 men surrounded a meeting of the Boston Female Anti-Slavery Society at its room on Washington Street on October 21, 1835. Maria Weston Chapman, her sisters Caroline, Anne and Deborah Weston, and eight other women had founded the society in 1834. Deborah Weston called it "the day when 5,000 men mobbed 45 women." A report in the *Hampshire Gazette* of October 28, 1835, described the crowd as citizens "calling themselves 'respectable.'"

When Mayor Theodore Lyman asked the women to leave, Maria Weston Chapman answered, "If this is the last bulwark of freedom, we may as well die here as anywhere." A bulwark is a strong wall that protects. The women walked out through the hissing crowd and finished their meeting at the Chapman house.

The mob caught William Lloyd Garrison and dragged him through the streets at the end of a rope. Mayor Lyman and other men took him to the Leverett Street Jail and kept him there overnight so the mob could not reach him. No record names a man in the mob or shows that anyone was charged.

**Alton.** A mob in Alton, Illinois, shot and killed Elijah Lovejoy on November 7, 1837. He was a Presbyterian minister who printed an antislavery newspaper. After threats to hurt him, he had moved from St. Louis to Alton, 25 miles away, for safety. Mobs in Alton smashed three of his printing presses.

That night Lovejoy and a group of men guarded a fourth press in a warehouse. About 20 or 30 men of the town surrounded the building. Men in the armed mob shot Lovejoy five times as he stood in an open doorway. He died within the hour, two days before his 35th birthday.

Judge William Martin and a jury in Alton's city court tried the men who had defended the press, for riot, in January 1838. A riot is a violent disturbance by a crowd. The jury found the warehouse owner, Winthrop Gilman, not guilty in about fifteen minutes, and the prosecutor dropped the charges against the other eleven defenders.

Then eleven men of the mob, among them John Solomon, Levi Palmer and James M. Rock, were tried for riot for breaking in and destroying the press. The jury found them not guilty on January 20, 1838. No one was charged with killing Lovejoy, and the court record does not name who fired the shots.

**Philadelphia.** A mob in Philadelphia burned down Pennsylvania Hall, a new meeting hall where antislavery groups met, on May 17, 1838. The Pennsylvania Hall Association had raised about $40,000 to build it, and the Philadelphia Female Anti-Slavery Society raised much of that money. The hall opened on May 14, and that week the Anti-Slavery Convention of American Women met in it. A convention is a large organized meeting.

Three days after the hall opened, the mob set it on fire, using its own gas lights. Between 10,000 and 15,000 people watched, and 200 to 300 of them took part in the attack.

Mayor John Swift made what one history of the city calls "half-hearted efforts" to clear the crowd. Sheriff John G. Watmough arrested about a dozen men that night, and the crowd took them away from him. In all, officials arrested dozens of men and investigated five, and no court found any of them guilty. The same history records the rioters only as "dock workers and white rioters," and names none of them. The judges of the Pennsylvania Supreme Court ordered the county to pay $27,942.27 for the damage in 1847.

### Sarah and Angelina Grimké

> **Who:** Two sisters from a South Carolina slaveholding family who spoke against slavery to crowds of men and women, and were condemned from the pulpit for speaking at all.
>
> **When and where:** Charleston, then Philadelphia and New England. Their speaking tour ran in 1837 and 1838.

**In 23 weeks they spoke to more than 40,000 people.**

Sarah and Angelina Grimké grew up in Charleston, South Carolina. Their father, John Faucheraud Grimké, was a judge and cotton planter who held people in slavery. Both sisters became Quakers, and Angelina left Charleston for Philadelphia in November 1829. In 1835 the sisters joined the American Anti-Slavery Society, and they became its first women agents, or organizers.

That July a mob in Charleston broke into the post office and burned antislavery papers. Angelina wrote a letter to William Lloyd Garrison about it, and he printed it in *The Liberator*. After that the sisters were not welcome in South Carolina.

**The tour.** At Poughkeepsie, New York, they spoke to a crowd of men and women together. In 23 weeks across 1837 and 1838 they spoke at 88 or more meetings in 67 towns, to more than 40,000 people.

**The ministers' letter.** In July 1837 the Congregational ministers of Massachusetts, leaders of a Protestant church, issued a Pastoral Letter to their churches, and ministers read it aloud from their pulpits. The letter states that women like the sisters put "the female character" in danger of "wide spread and permanent injury." It criticizes "females" who take "an obtrusive and ostentatious part in measures of reform," pushing forward to be seen. The ministers were attacking the sisters for being women who spoke in public.

Sarah Grimké answered the same month. The first of her "Letters on the Equality of the Sexes" ran in the *New England Spectator*. At a convention of antislavery women in 1837, Angelina proposed that "the right of petition is natural and inalienable," a right that nobody can take away.

**The gag rule.** Since 1836 the House of Representatives had a rule that set aside every antislavery petition without reading it, and people called it the gag rule. Women of Brookline, Massachusetts, petitioned the House to end it on February 14, 1838. They called it "an assumption of authority, at once dangerous and destructive to the fundamental principles of republican government, to the rights of minorities, to the sovereignty of the People."

They meant that the rule went against the idea that the people hold the final power in their government, and against the rights of the smaller side in a vote. The first two names on the petition were Sarah M. Grimké and Angelina E. Grimké. Members of the House voted to renew the gag rule each time a new Congress met, every two years, until 1844.

**At the State House.** On February 21, 1838, Angelina Grimké gave a committee of the Massachusetts lawmakers antislavery petitions signed by about 20,000 Massachusetts women. She spoke to the committee in front of an overflowing crowd. The House of Representatives' historian calls her "the first woman in the United States to speak before a legislative body," a group of lawmakers.

"I stand before you as a southerner, exiled from the land of my birth by the sound of the lash and the piteous cry of the slave," she told them, exiled meaning driven from home and piteous meaning full of pain. She also said, "We are citizens of this republic and as such our honor, happiness, and well-being are bound up in its politics, government, and laws."

Both sisters lived to see the end of slavery in the United States. Sarah died in 1873 and Angelina in 1879, before American women won the vote.

### Dorothea Dix

> **Who:** A Massachusetts woman who visited every jail and poorhouse in her state, wrote down how the people who ran them held people with mental illness, and handed the record to the state's lawmakers.
>
> **When and where:** Massachusetts, 1841 to 1843. Born 1802, died 1887.

**At Medford she found one person in a stall for seventeen years.**

Dorothea Dix went to teach a Sunday school class at the jail at East Cambridge, Massachusetts, on March 28, 1841. She found women with mental illness, called *insane* at the time, locked in with convicted criminals in "a bare, foul-smelling, unheated jail room." The word *insane* then meant a person whose mind worked in ways that their family or their town could not manage. The jail officials denied her account. Then they improved the women's conditions.

**Every jail in the state.** Between 1841 and 1843 Dix visited every jail, poorhouse and house of correction in Massachusetts. A poorhouse was a building where a town kept people who had no money. A house of correction was a kind of jail for people found guilty of small crimes. She wrote down what she saw in each one.

In January 1843 she gave the Massachusetts lawmakers a memorial, a formal written statement, of what she had found. "I come as the advocate of the helpless, forgotten, insane men and women held in cages, closets, cellars, stalls, pens!" she wrote. "Chained, naked, beaten with rods, and lashed into obedience!" A stall and a pen are enclosures built for animals, a rod is a stick used for beating, and lashed means whipped.

Her notes named places. At Lincoln she found a woman in a cage. At Medford she found one person "chained, and one in a close stall for seventeen years."

Printers reprinted the memorial as a pamphlet, and newspapers printed parts of it. The lawmakers voted money to make the state hospital at Worcester bigger. The United States had 13 hospitals for people with mental illness in 1843. By 1880 it had 123, and Dix had helped found 32 of them.

**By 1843:** Mobs had killed an antislavery editor and burned a hall, women speakers had answered the ministers who told them to keep quiet, and a woman had put the treatment of people with mental illness before a state's lawmakers.

### Coverture begins to break, 1837 to 1848

Coverture, the old English rule that a married woman had no legal existence apart from her husband, was still in force in 1848. The first law in any state that let a married woman own property in her own name passed in Mississippi in 1839. It came out of a court case about a Chickasaw woman, and the property in that case was an enslaved man.

**Betsy Love's case.** Betsy Love was Chickasaw, through her mother, Sally Colbert. She had inherited an enslaved man named Toney from her father, Thomas Love, and had given him to her daughter, Susan. Betsy Love's husband owed money to a man named John Fisher, and Fisher went to court to have Toney sold at auction to pay the husband's debt.

The judges of the Mississippi Supreme Court ruled in 1837 that Betsy Love was the legal owner, and that her husband had no rights over her property. They gave three reasons. Chickasaw families trace their family lines and pass on property through the mother. Since 1830, contracts made under Chickasaw law, including marriage contracts, had counted as binding in Mississippi. The third, in the words of the National Park Service's account, was that "Property in the Chickasaw Nation was owned by the women of the tribe."

**The new laws.** Mississippi's lawmakers passed the Married Women's Property Act in 1839. A married woman could now own property she got by gift, will, purchase or inheritance, as long as it did not come from her husband.

New York's lawmakers passed their own Married Women's Property Act in 1848, months before the Seneca Falls convention. The property a woman owned when she married now stayed hers. Her husband could not sell it, and the people he owed money to could not take it to pay his debts. Lawmakers in other states copied New York's law. One part of coverture, the part about property a wife brought into a marriage, no longer applied in New York. The rest of coverture stayed the law.

### Sojourner Truth takes her name, 1843

The woman born Isabella Bomfree in Ulster County, New York, in 1797 changed her name in 1843. She said the Spirit had called her to preach the truth, and she named herself Sojourner Truth. A sojourner is a traveler who stays in a place for a while. She traveled through Long Island, Connecticut and Massachusetts, speaking and singing.

She joined the Northampton Association of Education and Industry in Massachusetts in 1844. Abolitionists had founded it as a community. Its members supported women's rights and religious tolerance and opposed war, and the community was a stop on the Underground Railroad. It broke up in 1850, and her formal lecture tour began the next year.

### Elizabeth Cady Stanton and Lucretia Mott

> **Who:** Two women who were refused seats as delegates at an antislavery meeting in London because they were women, and who called the first women's rights convention eight years later.
>
> **When and where:** London, 1840. Waterloo and Seneca Falls, New York, July 1848.

**A New York publisher printed their declaration to make fun of it.**

Elizabeth Cady Stanton and Lucretia Mott met in London in 1840, at the World Anti-Slavery Convention. Mott was a Quaker who had helped found the Philadelphia Female Anti-Slavery Society in 1833. American antislavery groups had elected women as delegates, and in the words of a National Park Service account, the women "were refused admission because of their sex." That account does not name the men who refused them.

After an argument, the men at the convention decided that the women "would sit at the rear of the hall, but not participate." Stanton was in London on her honeymoon. She found Mott in the women's section, and the two agreed to hold a women's rights convention when they got home.

**Seneca Falls.** Stanton moved to Seneca Falls in 1847. The town is on Cayuga land. The Cayuga Nation kept a 64,000-acre reservation there by a 1789 treaty, a written agreement, with New York. New York officials bought almost all of it in 1795 and the last three square miles in 1807. A federal judge in western New York ruled in 2017 that Congress had never approved those purchases, as a law of 1790 required.

Stanton later wrote about what pushed her to act: "The general discontent I felt with women's portion as wife, mother, housekeeper ... impressed me with a strange feeling that some active measures should be taken."

**Tea at Waterloo.** Five women met for tea at Waterloo, New York, on July 9, 1848, and decided to hold the convention. They were Stanton, Mott, Mary Ann M'Clintock, Martha Coffin Wright and Jane Hunt. They put a notice in the local paper calling people to "a Convention to discuss the social, civil and religious rights and condition of woman."

The convention met on July 19 and 20, 1848, at the Wesleyan Chapel in Seneca Falls, three miles east of Waterloo. More than 300 people came. The first day was meant for women only, and men took part on the second. Lucretia Mott's husband, James Mott, chaired the convention, which means he ran the meeting. Mary M'Clintock was the secretary.

**The declaration.** Stanton wrote a Declaration of Sentiments with the M'Clintock family, modeled on the Declaration of Independence. It listed, one by one, the wrongs men had done to women. "He has never permitted her to exercise her inalienable right to the elective franchise," meaning the right to vote. "He has taken from her all right in property, even to the wages she earns." That was coverture. "He has denied her the facilities for obtaining a thorough education," it went on, "all colleges being closed against her."

**The vote on the vote.** The people at the convention voted on a set of resolutions, written statements of what they wanted. Eleven passed with no one against them. The resolution demanding the vote met opposition and passed only narrowly. Frederick Douglass stood with Stanton and argued for it. He had escaped from slavery in Maryland ten years before and now published an antislavery newspaper, the *North Star*.

One hundred people signed the Declaration of Sentiments, 68 women and 32 men. A Library of Congress exhibition states that seventy-two years of organized campaigning for women's votes followed that resolution, up to the 19th Amendment in 1920.

The signers had written that they expected "misconception, misrepresentation, and ridicule," and it came. James Gordon Bennett, publisher of the *New York Herald*, printed the whole declaration in his paper to make fun of it. Some signers later took their names off after people criticized them harshly for signing. The records do not say how many.

**If you remember one thing:** Women who learned to organize against slavery used the same petitions, speeches and meetings to demand rights of their own, ending with a vote at Seneca Falls to demand the vote.

- February 21, 1838: Angelina Grimké speaks to a committee of Massachusetts lawmakers, with petitions from about 20,000 women.
- 1839: Mississippi's lawmakers pass the first law in any state that lets a married woman own property in her own name.
- July 19 and 20, 1848: More than 300 people meet at Seneca Falls, and 100 sign the Declaration of Sentiments.

**Next:** After 1850, people who were denied their rights began to plan court cases on purpose.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 50 minutes**

Americans who were denied rights in the second half of the 1800s learned to plan court cases on purpose. They chose a law to challenge, raised money, hired a lawyer and found a person willing to be arrested or refused. Susan B. Anthony voted in 1872, the Tape family sued a school board in 1884, and Black men on a committee in New Orleans arranged an arrest on a train in 1892.

The judge at Anthony's trial told the jury to find her guilty. The Tapes won in court, and school officials still kept their daughter out of the white school. Homer Plessy, the man the committee chose, lost in the Supreme Court.

**Around the cases.** After the Civil War, members of Congress and state lawmakers added three amendments, or changes, to the Constitution, and in 1869 the leaders of the women's movement split over whether Black men or women should get the vote first. Women first voted under territorial law in Wyoming and Utah.

Members of Congress voted for laws that shut Chinese immigrants out, and Chinese Americans fought those laws in court. In Memphis, the newspaper editor Ida B. Wells began counting the people killed by lynch mobs, crowds that killed people outside the law, with no trial.

### Sojourner Truth

> **Who:** A woman born into slavery in New York who spoke in public for more than thirty years for the rights of Black people and of women.
>
> **When and where:** Akron, Ohio, May 1851. Washington, D.C., 1864. Died at Battle Creek, Michigan, November 26, 1883.

**The famous "Ain't I a woman?" version was written by someone else.**

Sojourner Truth published *The Narrative of Sojourner Truth: a Northern Slave* in 1850 and bought a house in Northampton, Massachusetts. She paid for part of it by selling photographs of herself. On them she printed the words "I sell the shadow to support the substance."

**Akron, 1851.** She spoke at the Ohio Women's Rights Convention in the Old Stone Church at Akron, Ohio, on May 28, 1851. She had not been invited. (One account gives the date as May 29. The convention ran for two days.)

Marius Robinson, one of the convention's secretaries, printed a report of her speech in the *Anti-Slavery Bugle* on June 21, 1851, about three weeks later. Truth was staying with Robinson and his wife, Emily, at the time, and a National Park Service page says it is believed he went over the text with her.

His version begins, "May I say a few words? I want to say a few words about this matter. I am a woman's rights. I have as much muscle as any man, and can do as much work as any man." She went on, "I have plowed and reaped and husked and chopped and mowed, and can any man do more than that?"

Later she said, "You need not be afraid to give us our rights for fear we will take too much, for we can't take more than our pint will hold." She ended, "But man is in a tight place, the poor slave is on him, woman is coming on him, and he is surely between a hawk and a buzzard." Robinson wrote that it was "impossible to transfer it to paper, or convey any adequate idea of the effect it produced upon the audience."

**The other version.** Frances Dana Gage, who had run the convention, wrote the famous version, with the question "And ain't I a woman?" repeated through it. Gage published it in 1863, twelve years after the speech, while she was in South Carolina, in land held by the Union Army during the war. She did not check it with Truth, and she called it "but a faint sketch of her speech."

Gage's version gives Truth a Southern way of speaking. Truth grew up in Ulster County, New York, nearly 100 miles north of New York City. She spoke only Dutch until she was nine, and she was never enslaved in the South. Gage's version also has her say she bore thirteen children. She had five. A National Women's History Museum exhibit says Gage "fabricated" her version, which means she made it up. Robinson's version is the one written down that summer.

**Fighting the rules.** After 1857 Truth lived in Michigan. During the Civil War she recruited Black men for the Union Army, among them her grandson James Caldwell, who joined the 54th Massachusetts regiment in April 1863. That year officials in Indiana arrested her under a state law that barred Black people from entering the state, and held her for ten days.

She worked in Washington, D.C., in 1864 for the National Freedmen's Relief Association, which helped people who had just been freed from slavery. She rode the city's streetcars to force the companies to carry Black passengers. When a streetcar conductor tried to stop her from riding by force, she had him arrested and won her case. On October 29, 1864, she met President Abraham Lincoln at the White House.

From 1870 she campaigned for the federal government to give land in the West to people freed from slavery, and the campaign failed. She went to the polls in Battle Creek, Michigan, to vote in 1872, and election officials turned her away. That same year, Susan B. Anthony voted in Rochester, New York, and was arrested for it. Sojourner Truth died at Battle Creek on November 26, 1883. Her exact age is not known: counting from 1797, she was about 86, and she herself believed she was 105.

### Massachusetts lawmakers outlaw segregated schools, 1855

After the Roberts family lost in court, William Cooper Nell and other Black Bostonians kept up their boycott of the segregated Smith School and their petition drives. Prince Hall and other Black Bostonians had first asked the state's lawmakers for schools for their children in 1787. In 1855, 68 years after that first petition, Massachusetts lawmakers voted to outlaw segregated public schools. A National Park Service page records that race-based segregation continued in Boston's public schools for decades afterward, even though state and federal laws forbade it.

### A wife's wages, New York, 1860

A married woman in New York did not own the money she earned until 1860. Under coverture, her wages belonged to her husband. Women's rights campaigners carried petitions to every county in the state. They held conventions in 40 of its 60 counties and gave talks in 150 towns. Frances D. Gage, Antoinette Brown Blackwell and Susan B. Anthony were among the speakers.

**The bill.** Anthony gave a draft bill, a proposed law, to a state senator, Andrew J. Colvin, and he brought it to the state's lawmakers. State senators passed it on February 28, 1860, and members of the assembly on March 20, and Governor Edwin D. Morgan signed it.

One newspaper of the time printed the date of passage as March 30. The law states that "the earnings of any married woman, from her trade, business, labor or services, shall be her sole and separate property, and may be used or invested by her in her own name."

### Three amendments, and the violence around them

Members of Congress and state lawmakers added three amendments to the Constitution after the Civil War. An amendment becomes part of the Constitution when lawmakers in enough states vote to approve it, which is called ratifying it. The 13th, ratified on December 6, 1865, bans slavery.

The 14th, part of the Constitution from July 9, 1868, states that "All persons born or naturalized in the United States" are citizens, naturalized meaning made a citizen after coming from another country.

It also says no state may "deny to any person within its jurisdiction the equal protection of the laws," so a state must apply its laws the same way to everyone. The 15th, ratified on February 3, 1870, states that the right to vote cannot be denied "on account of race, color, or previous condition of servitude," servitude meaning slavery.

**The violence.** In these same years white men attacked Black Americans who were living as free people. In May 1866, mobs that included Memphis police officers, firemen and businessmen killed 46 Black residents of the city. By the count of a committee of Congress, the mobs also burned 91 homes, 4 churches and 8 schools and raped five women. Rape means forcing a person into sex.

More than 150 armed white men led by Christopher Columbus Nash killed between 62 and 153 Black men at Colfax, Louisiana, on April 13, 1873.

**The soldiers leave.** After the war, federal soldiers stayed in the South, and some of them guarded its state houses. These were the years called Reconstruction, when members of Congress wrote Black Americans' rights into the three amendments and into new federal laws. President Rutherford B. Hayes ordered the soldiers out of the Louisiana state house in April 1877, the last state house in the South that they guarded. Reconstruction ended when they left. Chapter 24, Slavery and Freedom, tells that story in full.

**A law struck down.** Members of Congress voted for a Civil Rights Act in 1875. Under it, no one could lawfully deny anyone "the full and equal enjoyment of any of the accommodations, advantages, facilities, and privileges of inns, public conveyances on land or water, theaters and other places of public amusement." Public conveyances are trains, boats and coaches for hire.

The justices of the Supreme Court struck the law down in 1883. They held that the 14th Amendment did not let Congress stop private individuals from treating people unfairly because of race.

### Why the women's movement split in 1869

The people who had worked together against slavery split in 1869 over who should get the vote next. The 15th Amendment, which members of Congress passed on February 26, 1869, bars denying the vote because of race and says nothing about sex. The 14th Amendment had already become the first place the Constitution used the word "male." Under its second section, the number of seats a state got in Congress depended on the number of its "male inhabitants" who could vote.

**The meeting.** The break came on May 12, 1869, at the third annual meeting of the American Equal Rights Association. People working to end slavery and women's rights campaigners had formed that group together in 1866. At the 1866 meeting, the Black campaigner Frances Ellen Watkins Harper had told the white women there, "You white women speak here of rights. I speak of wrongs."

At the 1869 meeting, Frederick Douglass argued that Black men needed the vote first. "I do not see how any one can pretend that there is the same urgency in giving the ballot to woman as to the negro," he said, using the word of the time for Black people. "With us, the question is a matter of life and death, at least, in fifteen States of the Union." He described Black families "in danger of having their homes burnt down over their heads," and children "not allowed to enter schools."

Susan B. Anthony answered, "If you will not give the whole loaf of suffrage to the entire people, give it to the most intelligent first," suffrage meaning the right to vote. Elizabeth Cady Stanton said, "If intelligence, justice, and morality are to have precedence in the government, let the question of women brought up first and that of the negro last."

**Stanton's words.** A National Park Service page records that Stanton used racist language in this fight. She called Black Americans "ignorant of the laws and customs" of the country. Stanton and Anthony argued that educated white women should vote before Black men, and their words angered Black campaigners, among them Douglass and Harper.

**Two groups.** Stanton and Anthony started the National Woman Suffrage Association in 1869, which worked for a change to the Constitution. Lucy Stone, Henry Blackwell and Julia Ward Howe started the American Woman Suffrage Association, which worked state by state and supported the 15th Amendment. The two groups stayed apart until 1890, when they joined as the National American Woman Suffrage Association. Two daughters of the founders, Alice Stone Blackwell and Harriot Stanton Blatch, helped bring them together.

**By 1870:** Three new amendments had ended slavery, made people born in the country citizens and barred the states from denying the vote by race. White mobs were killing Black Americans who lived as free people, and the women's movement had split in two.

### Women vote first in the West, 1869 and 1870

The lawmakers of Wyoming Territory passed the first law in United States history that openly gave women the vote, and they had mixed reasons for it. William H. Bright, a Democrat from South Pass City, brought the bill to the territory's first group of lawmakers. Governor John Allen Campbell approved it on December 10, 1869. Women could now vote and hold office. A National Park Service page records that some of the lawmakers also wanted to draw more women to a territory that had very few.

**Shoshone country.** South Pass City was a gold-mining camp that grew up after gold was found in 1867. It stood in country that United States officials had recognized as the Eastern Shoshone's in an 1863 treaty, a homeland of about 44 million acres. White prospectors, men searching for gold, had been slipping into that country since the 1850s, in spite of the treaties. In the 1868 treaty of Fort Bridger, United States officials left the Shoshone only a reservation of about 3.2 million acres on the Wind River.

**Utah.** The lawmakers of Utah Territory passed a women's vote law two months later, and the acting governor signed it on February 12, 1870. Two days after that, a Salt Lake City schoolteacher named Seraph Young voted in the city election. She was the first woman in the United States to vote under a law that gave women the vote on the same terms as men.

**The first offices.** Esther Hobart Morris became justice of the peace at South Pass City, a local judge for small cases, on February 17, 1870. She was the first woman in the country to hold that office. That spring, women in Laramie were called to serve on juries, the first women in the country to do so. Later, the jury rule was read to cover only "male citizens over 21 years of age."

The Wyoming State Museum, which records this, does not say who read it that way. Under that reading, no women sat on Wyoming juries until 1949. Louisa Swain of Laramie voted on the morning of September 6, 1870.

**Taken and given back.** Members of Congress voted to take Utah women's vote away in the Edmunds-Tucker Act of 1887, as part of a federal campaign against the Mormon church. Utah women got the vote back in the state constitution when Utah became a state on January 4, 1896. When Wyoming became a state in 1890, its women kept the vote, so Wyoming was the first state where women could vote.

### Susan B. Anthony

> **Who:** One of fifteen women who voted in Rochester, New York, in 1872, and the only one put on trial for it.
>
> **When and where:** Rochester, New York, November 5, 1872. Trial at Canandaigua, New York, June 17 to 19, 1873.

**"I shall never pay a dollar of your unjust penalty."**

The leaders of the National Woman Suffrage Association decided in 1871 that women should try to register to vote, be refused, and then sue in federal court. Their argument was that the 14th Amendment made voting one of the rights of every citizen. Anthony went to register in Rochester, and the officials let her. On election day she went back, and the officials let her vote.

**Election day.** Anthony and fourteen other women voted in the national election in the first district of Rochester's Eighth Ward on November 5, 1872. A poll watcher for one party, Sylvester Lewis, challenged her. The three election inspectors did what New York law required. They put her under oath and asked whether she was a citizen, whether she lived in the district and whether anyone had paid her. Her answers satisfied them, and they put her ballots in the boxes.

**The arrest.** Nine days later, a federal official, Commissioner William Storrs, issued warrants, papers ordering an arrest, for all fifteen women. A deputy marshal, a federal officer who makes arrests, came to Anthony's house on November 18. She told the story many times. "'What for?' I asked. 'To arrest you,' he said. 'Is that the way you arrest men?' 'No.' Then I demanded that I should be arrested properly." He took her downtown on the streetcar, and the government paid her fare.

All fifteen women were arrested, and only Anthony was tried. The charge stated that she had voted "without having a lawful right to vote," being "then and there a person of the female sex." At a hearing on November 29, 1872, the assistant prosecutor, John Pound, asked the election inspectors, "Was Miss Anthony dressed in the apparel of a woman and had she the appearance of a woman?" Her lawyer objected. The inspectors answering had been arrested themselves for letting the women vote.

**Talking to the jurors' towns.** Federal courts at that time did not let a person on trial for a crime speak to the jury. So in March and April 1873 Anthony spoke to the people the jurors would come from. She gave a lecture, "Is It a Crime for a U.S. Citizen to Vote?", in twenty-nine villages and towns of Monroe County. The federal prosecutor, Richard Crowley, had the trial moved to Ontario County, and Anthony scheduled a speech in every village there too.

**The ordered verdict.** The trial opened at Canandaigua on June 17, 1873, before a jury of twelve men. The judge was Ward Hunt, a justice of the Supreme Court who was also hearing cases in that part of New York. When the prosecution finished, Hunt read out an opinion he had already written. He said voting was not one of the rights the 14th Amendment protected, and that Anthony had known New York let only men vote.

Then he told the jury to bring in a verdict of guilty. Her lawyer, Henry Selden, asked for each juror to be asked one by one for his own verdict. The clerk refused. The jury never talked the case over.

Selden asked for a new trial on June 19, because Hunt had taken the decision away from the jury, and Hunt refused. Then the judge asked the question a court asks before it sets a punishment. Three reports of what Anthony said next survive, and none comes from the court's own record. The words below are from the version she published herself.

**What she said.** "Has the prisoner anything to say why sentence shall not be pronounced?" Hunt asked. Anthony answered, "Yes, your honor, I have many things to say, for in your ordered verdict of guilty, you have trampled under foot every vital principle of our government." She went on, "Robbed of the fundamental privilege of citizenship, I am degraded from the status of a citizen to that of a subject."

"The Court cannot allow the prisoner to go on," Hunt said. She kept going: "since the day of my arrest last November, this is the first time that either myself or any person of my disfranchised class has been allowed a word of defense before judge or jury," disfranchised meaning denied the vote. "The prisoner must sit down," said Hunt. "The Court cannot allow it."

She said that every man who had judged her was her "political superior," whether "native or foreign born, white or black, rich or poor, educated or ignorant, awake or asleep, sober or drunk." Hunt said she had been tried "according to the established forms of law." She replied, "Yes, your honor, but by forms of law all made by men, interpreted by men, administered by men, in favor of men, and against women."

**The fine.** Hunt fined her $100 and the costs of the trial. "May it please your honor, I shall never pay a dollar of your unjust penalty," she said. Hunt answered, "Madam, the Court will not order you committed until the fine is paid." If he had jailed her for not paying, she could have appealed to the Supreme Court.

The deputy marshal sent to collect reported in July 1873 that he could "find no goods or chattles land or tenements" to take, no belongings and no buildings. Federal officials dropped the matter, and she never paid.

The three election inspectors were tried after her, found guilty and fined $25 each. They refused to pay too, and the marshal put them in jail on February 25, 1874. Anthony sent telegrams to Representative Benjamin Butler and Senator Aaron Sargent. President Ulysses S. Grant pardoned the inspectors on March 3, 1874, canceling their punishment. The same day, the voters of the Eighth Ward elected all three to their posts again.

### The Comstock Act, 1873

Members of Congress voted on March 3, 1873, for "An Act for the Suppression of, trade in, and circulation of obscene literature and articles of immoral use," known as the Comstock Act. Sending certain things by mail became a federal crime. They included anatomy books, some novels, photographs of boxing matches and information about contraception, ways to prevent pregnancy. Under the act, it was a crime to mail a woman the information she needed about her own body.

**One man's word.** Obscene means indecent or shocking, but the act never said what counted as obscene. Anthony Comstock had pushed members of Congress to pass it, and he was appointed a special agent of the Post Office. In practice, he decided what the word meant. In court he often refused to let jurors see the item he had seized, saying it was too vile to show them. He claimed that over his life he seized 150 tons of books, made 4,000 arrests and drove 15 people to suicide.

### A Harvard doctor says school will harm girls, 1873

Edward H. Clarke, a professor at Harvard Medical School, published a book in 1873 that said studying would damage girls' bodies. The book was *Sex in Education*, with the subtitle *A Fair Chance for the Girls*. Clarke argued that a girl's body spends the teenage years building the organs used to carry a pregnancy, and that studying the way boys studied would take the energy that work needed.

"Unless the work is accomplished at that period, unless the reproductive mechanism is built and put in good working order at that time, it will never be perfectly accomplished afterwards," he wrote. He warned that the result would be "monstrous brains and puny bodies."

**The harms he listed.** A Smith College history page lists the harms Clarke said would follow. They were atrophy of the uterus and ovaries, meaning those organs shrinking and stopping working, and masculinization, a girl's body taking on a man's traits. They also included sterility, being unable to have children, and insanity and death.

He said women should study no more than four hours a day, and not at all during their monthly bleeding. He described a patient he called Miss A: "She graduated at nineteen, the first scholar, and an invalid," a person too sick to live a normal life.

Leaders of the new women's colleges answered him. Smith College opened in 1875, and its first president, Laurenus Clark Seelye, said, "It is to preserve her womanliness that this College has been founded." Smith's leaders built supervised houses for its students in answer to worries like Clarke's.

**Mary Putnam Jacobi's evidence.** Mary Putnam Jacobi answered with evidence. She had earned a pharmacy degree, a degree in preparing medicines, in 1863, the first woman in the country to do so. She earned a medical degree in 1864 and a second medical degree in Paris in 1871.

Jacobi sent out a thousand printed lists of questions through women's rights groups and collected answers from hundreds of women, rich and poor, in towns and on farms. Her essay *The Question of Rest During Menstruation* won Harvard's Boylston Prize in 1876, and she was the first woman to win it. She found no evidence that monthly bleeding made women unfit to study or work.

### Supreme Court justices rule that the Constitution gives no one the vote

Virginia Minor, a woman in St. Louis, Missouri, used the same argument Anthony had used. The registrar, Reese Happersett, refused to register her to vote, and she sued him, arguing that she was a citizen and that citizens have the right to vote.

All the justices of the Supreme Court ruled against her in *Minor v. Happersett*, decided in the court term that began in October 1874. They held that "the Constitution of the United States does not confer the right of suffrage upon any one," and that a state could give the vote to men only.

Women were citizens, but in the justices' reading, being a citizen did not include a right to vote. After that ruling, the only way left to win the vote everywhere at once was a new amendment to the Constitution.

**By 1875:** Women voted in Wyoming and Utah, Anthony had been found guilty for voting in New York, and the Supreme Court's justices had ruled that the Constitution gave no one the vote.

### Getting into college, and into court as a lawyer

Women won their first places in colleges, in medicine and in law in these years. A woman who got in could still be kept from staying, or from working.

**Colleges.** Vassar College, a college for women at Poughkeepsie, New York, opened on September 26, 1865, with 353 students. Smith, Wellesley and Bryn Mawr opened within the next twenty years. Two teachers from New England started Spelman in the basement of a Baptist church in Atlanta, Georgia, on April 11, 1881. Its first class was eleven students: ten women, some of them formerly enslaved, and one girl.

**Universities.** Some universities that had taken only men began to take women. The first woman to enter Cornell, Jennie Spencer of Cortland, came in 1870. She had won a state scholarship, and she left because there was nowhere near the campus for a woman to live. Women entered Cornell regularly from 1872.

**Doctors and lawyers.** Rebecca Lee Crumpler received the degree "Doctress of Medicine" from the New England Female Medical College on March 1, 1864. She was the first African American woman in the United States to earn a medical degree. After the war she moved to Richmond, Virginia, and worked with the Freedmen's Bureau, the federal office that helped people freed from slavery, treating patients who had no other doctor.

Arabella Mansfield passed the Iowa bar examination on June 15, 1869, and became the first woman admitted to a state bar, the body of lawyers allowed to practice in a court. Iowa's law described "any white male citizen" as eligible, and she argued that nothing in it forbade a woman.

Charlotte E. Ray graduated from Howard University School of Law in 1872 and was admitted to the District of Columbia bar, the first Black woman lawyer in the country. A page by the District of Columbia attorney general's office says she later had to close her law office because, as a woman of color, she could not get enough clients.

**Myra Bradwell.** Other women passed the law examination and were still refused a license. Myra Bradwell passed the Illinois bar examination in 1869, and the judges of the Illinois Supreme Court refused her a license because she was married.

She took her case to the Supreme Court of the United States and lost, eight to one, in *Bradwell v. The State*, in the term that began in October 1872. Justice Samuel F. Miller wrote for the Court that each state decides who may practice law, and that the 14th Amendment does not protect that right.

Justice Joseph Bradley wrote separately, "The paramount destiny and mission of woman are to fulfil the noble and benign offices of wife and mother. This is the law of the Creator," paramount meaning most important and benign offices meaning kind duties. He meant that a woman's place was in the home. He also wrote, "A married woman is incapable, without her husband's consent, of making contracts which shall be binding on her or him." That sentence states the rule of coverture.

**Belva Lockwood.** The justices of the Supreme Court refused to let Belva Lockwood argue cases before them in 1876. They said "none but men are permitted to practice before [us] as attorneys and counselors." Lockwood lobbied Congress, pressing its members in person, until they voted for "An Act to relieve certain legal disabilities of women." On March 3, 1879, she became the first woman admitted to the bar of the Supreme Court.

### Laws that shut Chinese immigrants out, 1875 and 1882

While Americans argued about who should be added to the voters, members of Congress voted for laws to keep Chinese immigrants out. President Ulysses S. Grant signed the Page Act on March 3, 1875. A National Park Service page calls it the first federal law to restrict immigration. Agents at the ports could stop and question "any subject of China, Japan, or any Oriental country," using an old word for Asian, to find out whether the person had come "without their free and voluntary consent."

**Who the agents stopped.** Under the act, no one could bring in women "for the purposes of prostitution," which means to be paid for sex, and officials decided which women those were. The officers applied it to Asian women in general, and in practice almost no Chinese women could enter the country.

**The Exclusion Act.** President Chester A. Arthur signed the Chinese Exclusion Act on May 6, 1882. Chinese laborers could not enter the country for ten years. Section 14 states that "no State court or court of the United States shall admit Chinese to citizenship." Members of Congress extended the law in 1892, made it permanent in 1902 and repealed it, or canceled it, in 1943. Britannica calls it "the first and only major federal legislation to explicitly suspend immigration for a specific nationality."

### Frances Thompson arrested for living as a woman, 1876

Memphis police arrested a Black woman named Frances Thompson for wearing women's clothing on July 10, 1876. Writers today, among them reporters at CNN, describe her as a transgender woman, a woman whose body was counted as male at birth. She told police and reporters she had lived her whole life as a woman.

Ten years earlier, in 1866, Thompson had told a committee of Congress that seven white men had raped her and another woman, Lucy Smith, during the Memphis massacre.

**What the city did to her.** After the 1876 arrest, four doctors, among them Dr. Joseph Nuttall, a doctor working for the city, examined her body against her will at the central police station on Adams Street and declared her a man. Modern reports on her case by MLK50 and CNN do not say how the doctors examined her. The city's recorder, an official who judged small cases, fined her $50.

She could not pay, so the recorder sentenced her to 100 days on the city chain gang, a group of prisoners chained together and made to work outdoors. She cleaned the streets for 50 cents a day toward her fine. Crowds gathered to stare at her. Officials made her pose for photographs in men's and women's clothing, and newspapers printed them. After harassment from other prisoners and the public, city officials took her off the chain gang and held her at the police station for the rest of her sentence.

Memphis newspapers printed the doctors' finding, and writers for several of the papers used it to try to show that her 1866 testimony about the rape was false. Her neighbors later found her sick and took her to the city hospital. She died there of dysentery, a disease of the gut, on November 1, 1876.

### Sarah Winnemucca

> **Who:** A Northern Paiute woman who worked as an interpreter for the United States government and the Army, saw what United States officials and soldiers did to her people, and spent the rest of her life saying so in public.
>
> **When and where:** Nevada and Oregon, 1844 to 1891. The removal to the Yakama Reservation, 1878 to 1879.

**"My people were only given one week to get ready in."**

Sarah Winnemucca's Paiute name was Thocmetony, which means Shell Flower. She was the daughter of Chief Winnemucca and the granddaughter of Chief Truckee, and both men had guided white travelers across Paiute country. A National Park Service page lists what she saw growing up: "the murder of two uncles, the attempted rape of her sister, the Pyramid Lake War and Bannock War, and the burning of Paiute food supplies."

**Working for the government.** She spoke several languages. In the 1870s she worked as an interpreter for the Indian Office and as a go-between for the Paiute and the United States Army. Part of that work was persuading Paiute bands to move onto reservations. During the Bannock War of 1878, she found her father's band, who were being held by Bannock fighters, and led them out to the Army's protection. She traveled 230 miles in three days.

**The removal.** Army soldiers then removed Paiute people who had not fought in the war at all. The House of Representatives' historian writes that the Paiute were punished for the part a small number of them had taken in the fighting. Winnemucca wrote that "just a little before Christmas" in 1878 she learned that President Rutherford B. Hayes had ordered it. "My people were only given one week to get ready in," she wrote.

Soldiers took them off the Malheur Reservation, which lay inside their own homeland, and sent them 350 miles north to the Yakama Reservation, the Yakama Nation's land. About 550 Paiute men, women and children made the journey. It took nearly a month, through snow and over two mountain ranges. The women and children rode in wagons.

Some of the men walked in leg irons, metal rings locked around the ankles and chained together. The records do not say which soldiers or officials put the irons on them. Five children, one woman and an old man died on the road. Their bodies were left beside it, because the ground was too frozen to dig graves.

**At Yakama.** The historian Sally Zanjani estimated that more than a fifth of the group died at Yakama afterward, most of them from hunger and disease. W. V. Rinehart, the government agent at Malheur, wrote a report in August 1879. In it he complained about what the removal had cost. He also wrote that officials had sent the Paiute off without enough supplies, even though supplies were on the way.

**The campaign.** After the removal, Winnemucca stopped working as an interpreter and became a campaigner. In the early 1880s she gave more than 300 speeches. She met President Hayes and the Secretary of the Interior, Carl Schurz, in Washington in 1880. Hayes did not change his decision. Schurz gave her a written promise that her people could go back to Malheur, and then he did not keep it. President Chester Arthur opened the Malheur land to white settlers in 1882 and 1883.

She petitioned Congress in 1884 to give Malheur back to her people. She asked the government to "sweep away the [Indian] agency system" and "give us homes to live in, for God's sake and for humanity's sake." She published *Life Among the Piutes: Their Wrongs and Claims* in 1883, with help from the reformers Elizabeth Peabody and Mary Peabody Mann. A page by the Oregon Historical Society calls it the first autobiography published by a Native American woman.

**Her school.** She also started a school for Paiute children and taught them in Paiute and in English. It closed after three years, when the money ran out. In the same years, United States officials were opening boarding schools, where Native children lived far from their families. An Army officer, Richard Henry Pratt, opened the first of them, Carlisle, in Pennsylvania in 1879.

Staff at these schools cut the children's hair, gave them English names and forbade their languages, and punished children who spoke them with beatings, solitary confinement and withheld food. A federal count published in 2024 found that at least 973 children died at the schools.

Sarah Winnemucca died in 1891. Her statue stands in the United States Capitol for the state of Nevada. It shows her at 35, holding up a shell flower in her right hand, with a book at her side.

**By 1879:** Women were entering colleges and courtrooms, members of Congress had passed the first federal law to keep immigrants out, and soldiers had marched the Paiute away from their reservation in winter.

### Standing Bear goes to court, 1879

A Ponca leader named Standing Bear went to federal court in 1879 and won a ruling that a Native American is a person under the law. Then he toured the country arguing his case in public.

**The Ponca land.** The Ponca lived at the mouth of the Niobrara River in Nebraska. They had never fought the United States and had never sold that land. But in 1868 United States officials made a treaty with the Sioux that created the Great Sioux Reservation, and the Ponca land lay inside its lines.

Members of Congress set aside $25,000 in 1876 to move the Ponca to Indian Territory "if they consented to go." Indian Territory was the land where United States officials sent Native nations they forced from their homes.

Officials took eight Ponca chiefs south to choose new land. The chiefs turned down every place they saw and asked to go home. When officials refused, the chiefs walked more than 500 miles back to Nebraska in winter, in 40 days, "with only a few dollars and one blanket each."

**The forced move.** Federal officials ordered the move anyway, "using Army troops if necessary." An Indian Office inspector, E. C. Kemble, led the first 170 people south on April 30, 1877. He ordered the agent, E. A. Howard, to move the rest of the Ponca. They left on May 16, 1877, with 25 soldiers guarding them, and left behind their homes, crops and burial grounds. Standing Bear's daughter died on the way.

In July they crossed into Indian Territory onto Quapaw land. Later they chose 101,894 acres that had been the Cherokee Nation's land. A third of the Ponca died after they arrived.

**Carrying his son home.** Standing Bear's son, Bear Shield, died of a fever at sixteen in late December 1878. In early January 1879 Standing Bear set out on foot for Nebraska with a small group of his people, mostly women and children, carrying his son's bones to bury at home. The walk took about two months. Soldiers arrested the group and held them at Fort Omaha, an Army post, under General George Crook.

**The court.** Two Omaha lawyers, John L. Webster and Andrew J. Poppleton, took his case. They asked for a writ of habeas corpus, an old legal rule under which a person being held can make the government show its legal reason for holding him.

Judge Elmer S. Dundy of the United States District Court in Omaha heard the case on May 1 and 2, 1879. Standing Bear told the court, "That hand is not the color of yours. But if I pierce it, I shall feel pain ... I am a man. The same god made us both."

Dundy ruled on May 12, 1879, that "an Indian is a person within the meaning of the laws of the United States," and ordered the Ponca released. From June 1879 Standing Bear toured the country. He spoke in Chicago, Pittsburgh, Philadelphia, Boston, New York, Washington and Baltimore. The journalist Thomas Tibbles went with him, and so did Susette La Flesche of the Omaha Nation, called Bright Eyes, who interpreted, and her brother Frank.

**What the ruling did not do.** The ruling covered Standing Bear and the people held with him. Native people did not become citizens because of it. John Elk, a Native man who had left his nation and lived in Omaha, tried to register to vote in April 1880. Charles Wilkins, the registrar of his ward, refused him because he was Native.

The justices of the Supreme Court ruled against Elk, seven to two, in *Elk v. Wilkins* on November 3, 1884. Justice Horace Gray wrote that a Native person born into a Native nation did not become a citizen by being born in the United States. Justices John Marshall Harlan and William B. Woods dissented, which means they disagreed with the ruling.

### Reformers who asked for allotment

Standing Bear's speeches reached white reformers in the East. They organized, lobbied and petitioned, and what they won was a law under which Native nations lost about two-thirds of the land they still held.

Helen Hunt Jackson heard Standing Bear speak in Boston in 1879. Two years later she published *A Century of Dishonor*, a book about how the United States government had treated Native nations. She sent a copy to every member of Congress with a note: "Look upon your hands: they are stained with the blood of your relations."

**The reform groups.** Two Philadelphia women, Mary Lucinda Bonney and Amelia Stone Quinton, founded the Women's National Indian Association in 1879. A group of wealthy Philadelphia men founded the Indian Rights Association on December 15, 1882, after Herbert Welsh and Henry S. Pancoast came back from a visit to the Sioux in Dakota Territory. They said their aim was to secure for Native people "the political and civil rights already guaranteed to them by treaty and statutes."

Its members believed that Native people would survive only by becoming Protestant Christians and living like white Americans. From 1883 a Quaker hotel owner, Albert K. Smiley, gathered these reformers every year at his resort at Lake Mohonk, New York. Mark S. Joy, writing about the conferences in 2019, names no Native people taking part. The reformers asked members of Congress to break reservation land into plots owned by single families, which was called allotment.

**The Dawes Act.** Members of Congress did it in the Dawes Act, signed on February 8, 1887, and named for Senator Henry Dawes of Massachusetts. The head of each family got 160 acres, and each person who took a plot became a citizen. Federal officials could buy the land that was "not allotted" from the Native nations and sell it to settlers.

Under the Dawes Act and the laws that followed it, the land held by Native nations went from about 138 million acres in 1887 to about 48 million by 1934. That is about 90 million acres gone, two acres out of every three. Another count gives about 137 million and 47 million.

### Mary and Joseph Tape

> **Who:** Two Chinese American parents who took San Francisco's school leaders to court because they would not let their eight-year-old daughter into the school near their home. They won, and school officials still kept her out.
>
> **When and where:** San Francisco, 1884 and 1885.

**"Is it a disgrace to be Born a Chinese?" Mary Tape wrote.**

San Francisco's schools had been separated by race from the start. The first public schools, opened in 1851, were for white children only. A school for Black children opened in 1854, and one for Chinese children in 1859. The city's school officials closed the Chinese school in 1870, which left Chinese American children with no public school at all.

**The Ward case.** A Black mother, Harriet A. Ward, had taken the same question to court in January 1874 for her daughter, Mary Frances, who was eleven. Noah F. Flood, the principal of the Broadway Grammar School, had refused to take her.

California law said, "The education of children of African descent, and Indian children, shall be provided for in separate schools." The judges of the California Supreme Court ruled against the Wards. A Black child could be kept out of a white school, they held, wherever a separate school existed, and San Francisco had one.

**The family.** Mary Tape was born near Shanghai, China, in 1857 and came to the United States alone in 1868, when she was eleven. Women of the Ladies' Protection and Relief Society took her in. She learned English there and took the name Mary McGladery, after one of the women who cared for her.

Joseph Tape, born Jeu Dip, arrived in 1864. He worked as a servant, ran a milk delivery business, and worked as a broker, a go-between in business deals, and as an interpreter for the Imperial Consulate of China. They had four children, Mamie, Frank, Emily and Gertrude, and lived in the Cow Hollow part of San Francisco.

**The lawsuit.** They took Mamie to Spring Valley Primary School, the all-white school near their home, in 1884. The principal, Jennie Hurley, refused her because her family came from China. Joseph Tape sued the San Francisco Board of Education, the school superintendent Andrew Jackson Moulder, and Hurley herself.

The judge of the Superior Court of California ruled for the Tapes on January 9, 1885. He held that keeping out "children of Chinese parents" broke California law and the 14th Amendment's promise of equal protection. The members of the Board of Education appealed, and the judges of the California Supreme Court agreed with the lower court.

**Shut out again.** Moulder sent a telegram to the state's lawmakers as soon as the decision came down. The lawmakers passed a law that let school officials set up "separate schools for children of Mongolian or Chinese descent," using a word white Americans then used for people from East Asia. On April 8, 1885, officials at Spring Valley refused Mamie again. This time they said she had no vaccination certificate and the classes were full.

**Her letter.** That day Mary Tape wrote to the Board of Education, in English, her second language. The *Daily Alta California* printed her letter, with her own spelling, on its front page on April 16, 1885.

"I see that you are going to make all sorts of excuses to keep my child out of the Public schools. Dear sirs, Will you please to tell me! Is it a disgrace to be Born a Chinese? Didn't God make us all!!! What right have you to bar my children out of the school because she is a chinese Decend."

"It seems no matter how a Chinese may live and dress so long as you know they Chinese. Then they are hated as one. There is not any right or justice for them. ... Mamie Tape will never attend any of the Chinese schools of your making! Never!!! I will let the world see sir What justice there is When it is govern by the Race prejudice men! ... I guess she is more of a American then a good many of you that is going to prevent her being Educated." She signed it "Mrs. M. Tape."

Mamie and her brother Frank became the first two pupils at the new Chinese Primary School in Chinatown on April 13, 1885. A history page by the San Francisco Unified School District states that the district's officials reopened the separate Chinese school "as a way to avoid integrating white schools," to keep Chinese children out of white children's schools.

**By 1887:** A federal judge had ruled that a Native American is a person under the law, reformers had won the Dawes Act, and the Tapes had won their case and still lost their daughter's place in the school.

### Chinese Americans take the law to court, 1886 to 1898

Chinese Americans used the 14th Amendment to challenge laws aimed at them, and sometimes they won. The members of San Francisco's Board of Supervisors, the officials who made the city's laws, voted in 1885 to require a permit to run a laundry in a wooden building. About 200 Chinese laundry owners applied, and the supervisors refused every one. About 80 owners who were not Chinese applied, and all but one got a permit.

**Yick Wo.** Officials arrested more than 150 Chinese men for working without a permit. One of them was Yick Wo, who had run a laundry at 349 Third Street for 22 years, and the sheriff, Peter Hopkins, held him in jail. All the justices of the Supreme Court ruled for Yick Wo in *Yick Wo v. Hopkins* on May 10, 1886. Justice Stanley Matthews wrote that a law "applied and administered by public authority with an evil eye and an unequal hand" denied people the equal protection of the laws.

**The Geary Act.** Members of Congress voted for the Geary Act in 1892. It kept Chinese exclusion going, and every Chinese laborer had to register and carry a certificate of residence at all times. A man caught without one could be sentenced to up to a year of hard labor and then deported, sent out of the country by force.

To prove he had lived in the country, he needed a white witness. The act, as the Supreme Court quoted it, asked for "at least one credible white witness." A KQED news report says two.

The leaders of the Chinese Six Companies, a Chinese American association, told people not to register. They collected a dollar from each Chinese resident to pay lawyers and put out leaflets that said, "The Geary Act is an unjust law." About 100,000 Chinese people lived in the United States, and only about 13,000 registered in the first period. A 2026 KQED news report, drawing on the historians Kelly Lytle Hernández, Alexander Jin and Russell Jeung, calls the refusal the first mass resistance to deportation in the United States.

**The test case.** Three men became the test case: Fong Yue Ting, Wong Quan and Lee Joe. Lee Joe had lived in the country since about 1874. He had tried to get a certificate in April 1893 and was refused, because his only witnesses were Chinese. The justices of the Supreme Court upheld the law, five to three, in *Fong Yue Ting v. United States* on May 15, 1893. Justice David Brewer wrote in dissent that deportation meant "removal from home, from family, from business, from property."

**Wong Kim Ark.** Wong Kim Ark was born at 751 Sacramento Street in San Francisco in 1873, to Chinese parents. When he came home from a visit to China in August 1895, officials at the port of San Francisco refused to let him back in.

The justices of the Supreme Court ruled six to two on March 28, 1898, that he was a citizen under the 14th Amendment, because he was born in the United States. Justice Horace Gray wrote for the Court. Chief Justice Melville Fuller dissented, and Justice John Marshall Harlan joined him.

### Black men in New Orleans plan an arrest, 1891 to 1896

A group of Black men in New Orleans formed a committee in 1891 to fight a new law in court, and they planned the arrest that started the case. Louisiana's lawmakers had passed Act 111, the Separate Car Act, on June 10, 1890.

Railroads had to give "equal but separate" seats to Black and white passengers. A passenger who sat in the wrong car could be fined $25 or jailed for 20 days. Black New Orleanians protested, and 16 of the state's lawmakers at the time were Black. The majority passed it anyway.

**The committee.** French-speaking men of African descent in New Orleans formed the Comité des Citoyens, the Citizens' Committee, in September 1891. Its full name was the Citizens' Committee to Test the Constitutionality of the Separate Car Law, which means whether the law fit the Constitution. The members raised money and hired a lawyer, Albion W. Tourgée.

**The arrest.** Homer Plessy volunteered to be arrested. He was born Homère Patris Plessy in New Orleans on March 17, 1863, to free parents of color, and he worked as a shoemaker. On June 7, 1892, he bought a ticket to Covington, Louisiana, on the East Louisiana Railroad and sat in the car for white passengers. Railroad officials were in on the plan, because the company did not want to pay the cost of running extra cars.

As planned, a private detective hired for the job arrested him, so that he would be charged with exactly the offense the committee wanted to fight. Judge John H. Ferguson of the Orleans Parish criminal court ruled against Plessy. The case is called Plessy v. Ferguson after the two men.

**The ruling.** The justices of the Supreme Court ruled against Plessy, seven to one, on May 18, 1896. Under their ruling, a state could make Black and white passengers ride in separate cars, as long as the cars were equal.

Justice Henry Billings Brown, who wrote the decision, said such laws did not mark either race as lower than the other. If Black Americans felt marked as lower, he wrote, that was "solely because the colored race chooses to put that construction upon it," because they chose to read the law that way.

Justice John Marshall Harlan disagreed, alone. "In view of the constitution, in the eye of the law, there is in this country no superior, dominant, ruling class of citizens," he wrote. "Our constitution is color-blind, and neither knows nor tolerates classes among citizens." The ruling stood for nearly sixty years, until *Brown v. Board of Education* in 1954. Homer Plessy died in New Orleans in 1925.

### Ida B. Wells

> **Who:** A Memphis newspaper editor who counted the people killed by lynch mobs, published the count, showed that the reason given for the killings was false, and was driven out of the South for it.
>
> **When and where:** Born at Holly Springs, Mississippi, July 16, 1862. Memphis, Tennessee, 1884 to 1892.

**She counted 728 lynchings in eight years and printed the number.**

Ida B. Wells was born into slavery and freed in 1865. In 1884 she bought a first-class railroad ticket, and the train crew ordered her into the car for Black passengers. She refused, and they removed her from the train by force. She sued the railroad and won $500 in the circuit court, and the judges of the Tennessee Supreme Court overturned the award.

She taught in a segregated public school in Memphis. In 1891 she wrote a newspaper article showing that the board of education gave the Black schools less money, and she lost her teaching job for it. Neither the National Park Service nor the Mississippi Department of Archives and History, in their accounts of her life, names the official who fired her.

**The People's Grocery.** Her friend Thomas Moss was part owner of the People's Grocery, a store run by Black owners in a mostly Black part of Memphis. It was taking business from a white-owned store nearby. William Barrett, one of the rival owners, got a judge to declare the People's Grocery a public nuisance, a place that harms the people around it, and to make him a deputy.

Barrett and a group of deputies in ordinary clothes marched on the store. Shots were fired, and three deputies were wounded. "Thirty-one men were arrested and thrown in jail as 'conspirators,'" Wells wrote. Moss and two others from the store were among them.

**The lynching.** In the early hours of March 9, 1892, a mob took Thomas Moss, Calvin McDowell and a third man out of their cells in the Memphis jail. The men of the mob took them to the rail yards and shot them to death. Calvin McDowell was shot with a shotgun at close range. The third man was shot in the neck, and records give his name two ways, as Will Stewart and as Henry Steward.

Moss's last words were reported as "Tell my people to go west. There is no justice for them here." Black Memphis "urged and waited for the authorities to act in the matter and bring the lynchers to justice. No attempt was made to do so," Wells wrote. No one was ever arrested for the killings.

**Black Memphis answers.** Black Memphians organized in answer. "The black men left the city by thousands," Wells wrote. The people who stayed stopped riding the streetcars. The streetcar company's superintendent, manager and treasurer came to the office of Wells's newspaper, the *Free Speech*, and asked its editors to tell people to ride again.

**The editorial.** Wells printed an editorial in the *Free Speech* on May 21, 1892: "Nobody in this section of the country believes the old thread-bare lie that Negro men rape white women." The excuse given in public for lynching was that Black men had raped white women. Wells wrote that white men were killing Black men over relationships that white women had chosen.

She described what happened next in a pamphlet later that year. After editorials in the Memphis daily papers, men of the city held a meeting at the Cotton Exchange Building on May 24, 1892. "A committee was sent for the editors of the Free Speech," she wrote, "and the only reason the open threats of lynching that were not carried out was because they could not be found." Her business partner, J. L. Fleming, "had to leave town to escape the mob, and was afterwards ordered not to return."

Wells was on vacation in New York. Letters and telegrams warned her "that bodily harm awaited my return." Then "Creditors took possession of the office and sold the outfit, and the Free Speech was as if it had never been." She did not go back. Her return home, she wrote, was "forbidden under penalty of death."

**The count.** Her pamphlet *Southern Horrors: Lynch Law in All Its Phases* came out in 1892. "The dark and bloody record of the South shows 728 Afro-Americans lynched during the past eight years," she wrote. "Only one-third of the 728 victims to mobs have been charged with rape, to say nothing of those of that one-third who were innocent." Two out of three had never been accused of the crime that lynching was said to punish. Using the *Chicago Tribune*'s yearly lists, she later counted 241 people lynched in 1892.

She wrote *The Reason Why the Colored American Is Not in the World's Columbian Exposition* for the world's fair in Chicago in 1893, printed in three languages. In 1894 she toured Britain speaking about lynching, and people there formed a London Anti-Lynching Committee. She married Ferdinand Barnett in 1895, and they had four children. The same year she published *A Red Record*, 100 pages of lynching figures and history.

**Frances Willard.** One white reformer fought her in public. Frances Willard was president of the Woman's Christian Temperance Union, a women's group that campaigned against alcohol. Willard had told a newspaper, the *New York Voice*, in 1890 that "The colored race multiplies like the locusts of Egypt," and that "The safety of woman, of childhood, the home, is menaced," or threatened, "in a thousand localities."

Wells printed those words in Britain in 1894. At her group's convention in Cleveland on November 5, 1894, Willard said Wells had "put an imputation upon half the white race in this country that is unjust." An imputation is an accusation. Wells answered her in *A Red Record*.

### Suffragists remember the clan mothers, 1891 and 1893

A National Park Service page records that the power of Haudenosaunee women inspired leaders of the women's rights movement. Elizabeth Cady Stanton told the National Council of Women in 1891 that Haudenosaunee women "did not hesitate, when occasion required, 'to knock off the horns,' as it was technically called, from the head of a chief." She meant the clan mothers' power to remove a chief.

Matilda Joslyn Gage wrote in the *New York Evening Post* that among the Haudenosaunee, "In the home the wife was absolute." The Wolf Clan of the Mohawk Nation adopted Gage as an honorary member in 1893 and gave her the name Ka-ron-ien-ha-wi, "She who holds the sky."

### A city government overthrown, Wilmington, 1898

Armed white men overthrew the elected government of Wilmington, North Carolina, on November 10, 1898. Black and white Republicans held the city's offices, and Alex Manly edited the *Daily Record*, the city's Black newspaper. Manly had printed an editorial that challenged white beliefs about relationships between Black and white people, and Democratic Party leaders used it to stir up white voters. Before the election two days earlier, the Red Shirts, a group of Democratic Party supporters, had frightened Black people and forced white voters to vote for Democrats.

**The attack.** Alfred Moore Waddell, a former Confederate officer and congressman, led the attack. About 500 white men gathered at the armory, a building where weapons were stored, and the crowd grew to perhaps 2,000. They broke into the *Daily Record* office and set the building on fire. Violence broke out across the town.

**Known:** The white men murdered at least 14 men, and every one of the dead who was reported was Black. The coroner, the county official who looks into deaths, counted 14.

**Disputed:** The state's commission report of 2006 gives as many as sixty. The records do not give an exact count.

**The new government.** That afternoon Waddell's men forced the Republican mayor, Silas P. Wright, the aldermen, the members of the city council, and other city officers to resign. The new aldermen made Waddell mayor. The new city leaders banished Black leaders and white Republicans, forcing them to leave the city for good. Manly escaped.

Governor Daniel Russell did not ask for federal help, and President William McKinley sent no troops. Lawyers in the United States Attorney General's office investigated and closed the case in 1900 without charging anyone. The records do not name the men who fired.

**If you remember one thing:** People who were denied their rights learned to bring test cases on purpose, and judges ruled against many of them, from Anthony's vote to Plessy's train seat.

**One number:** 728. That is how many Black Americans Ida B. Wells counted as lynched in the eight years before 1892, about 91 a year, or nearly two every week.

**Next:** In the new century, organizers took their cause to the White House gates and to the courts, one law school at a time.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 63 minutes**

The people who organized for their rights between 1900 and 1950 worked out the methods that organizers in the 1960s later used. Alice Paul put women on a picket line at the White House gates in 1917. Disabled New Yorkers sat down in a city relief office in 1935 and would not leave.

Charles Hamilton Houston planned a chain of court cases, one law school at a time. A. Philip Randolph planned marches on Washington in 1941 and 1948, and both times a president signed an order, first against unfair hiring by race in defense factories, then against unequal treatment in the armed forces.

**What they were up against.** Women won the vote in 1920, and white officials in the South kept many Black women from voting with the same rules and violence they used against Black men. White mobs attacked Black Americans in Springfield in 1908 and in 25 cities in 1919. White Tulsans burned the Black district of Greenwood in 1921 and killed as many as 300 people.

Officials in 30 states had at least 60,000 people operated on so that they could never have children. After President Franklin D. Roosevelt signed an order in 1942, Army officers forced about 120,000 people whose families came from Japan out of their homes and into camps, without charging them with any crime. Those who disobeyed, such as Fred Korematsu, were charged with breaking the orders themselves. The justices of the Supreme Court ruled in 1927 that the operations were allowed, and in 1944 that the removal was allowed.

Two sections run past 1950 to finish their stories: the Tulsa survivors' fight to be paid goes on to 2026, and Native Americans' fight for the vote goes on to 1957.

### A mob in Lincoln's town, and the NAACP, 1908 and 1909

A group of Black and white reformers founded the National Association for the Advancement of Colored People, the NAACP, after a white mob attacked Black residents of Springfield, Illinois, in August 1908. Colored was a common word for Black people at the time. Springfield was Abraham Lincoln's home town.

**Springfield.** Reporters for Springfield's newspapers wrote on August 14, 1908, that a Black man had tried to attack a white woman in her home the night before. Then they wrote about a second attack. A white mob went looking for the men accused, and when the men in it could not find them, they turned on the city's Black neighborhoods.

The violence lasted nearly three days. The mob lynched two men, Scott Burton and William Donegan, killing them without any trial. Neither man had anything to do with any crime. The rioters destroyed dozens of homes. Part-time soldiers of the state militia, the state's own army, stopped the violence. Officials arrested about 150 people, and few of them were ever found guilty of anything. Nearly 2,000 Black residents left Springfield and never came back.

**The founding.** The NAACP's founders started it on February 12, 1909, a hundred years after Lincoln was born. Its white founders included Mary White Ovington, Oswald Garrison Villard, William English Walling and Dr. Henry Moscowitz. About 60 people signed the call for its first conference, and seven of them were Black. They included the scholar W. E. B. Du Bois, Mary Church Terrell and Ida B. Wells-Barnett. The founders said their aim was to "secure for all people the rights guaranteed in the 13th, 14th, and 15th Amendments."

### Women march in Washington, 1913

Women marched down Pennsylvania Avenue in Washington to demand the vote on March 3, 1913, the day before Woodrow Wilson became president. Alice Paul and Lucy Burns organized the march. They ran the Congressional Committee of the National American Woman Suffrage Association. They chose the same route the president's parade would take the next day, and at least 250,000 people came to watch.

**The crowd.** The crowd pushed off the sidewalks and blocked the street. Men shoved the marchers, spat on them and shouted insults and crude requests for sex at them. The police did little to stop it. United States Army troops arrived about an hour later and cleared the street. Afterward, members of Congress investigated why the police had done so little.

**Ida B. Wells-Barnett steps in.** More than forty Black women marched, in their state groups or with women of their professions. Ida B. Wells-Barnett came with the Illinois group. As the march was forming, the parade's national organizers told the Illinois women that their group was to be "entirely white" and that Black women were to march at the tail end of the parade. The leader of the Illinois group went along with it.

Wells-Barnett refused and left. She waited at the side of the avenue until the Illinois women came past. Then she stepped into the line between two white marchers, Belle Squire and Virginia Brooks. The same year, Black women in Chicago formed the Alpha Suffrage Club, the first Black women's suffrage club in Illinois. Ida B. Wells-Barnett died in Chicago on March 25, 1931.

### The Silent Sentinels and the Occoquan Workhouse, 1917

Women stood at the gates of the White House six days a week from January 10, 1917, holding banners that asked President Wilson to support their vote. A National Park Service article states that Alice Paul invented picketing the White House, standing outside it with signs as a public protest. One banner read "Mr President What Will You Do For Woman Suffrage?" Another read "How Long, Mr President, Must Women Wait For Liberty?" The women became known as the Silent Sentinels.

**The arrests.** Police began arresting the women in 1917 on a charge of "obstructing traffic," blocking the road. Over the whole campaign, judges found more than 150 women guilty of it. In November 1917 alone, 41 women were arrested, among them Lucy Burns, Dorothy Day, Dora Lewis and Mary Nolan. Their sentences ran from six days to six months.

**The Night of Terror.** Many of them were sent to the Occoquan Workhouse, a prison in Virginia. On the night of November 14, 1917, on the orders of the superintendent, W. H. Whittaker, the guards attacked them. The guards threw the women around, hung some of them by their arms and refused them food and medical care. Lucy Burns kept a daily log on scraps of paper and got it smuggled out of the workhouse.

Her entry for that night reads: "Seized by guards from behind, flung off my feet, and shot out of the room. All of us were seized by men guards and dragged to cells in men's part. Dorothy Day was roughly used-back twisted. Mrs. Mary A. Nolan (73-year-old picket from Jacksonville, Florida) flung into cell."

The guards handcuffed Burns all night, and for part of the time they chained her hands to the bars of her cell. By her own account, they did it because she had asked the other women how they were. That night is known as the Night of Terror.

**Fed by force.** Many of the prisoners went on hunger strike, refusing to eat as a protest. The prison doctor, Dr. Gannon, answered by feeding them by force. Forcible feeding meant holding a woman down and pushing a tube through her nose or mouth, down her throat and into her stomach. Then the doctor poured liquid food through the tube. Burns wrote in her log what was done to her:

"I was held down by five people at legs, arms, and head. I refused to open mouth. Gannon pushed tube up left nostril. I turned and twisted my head all I could, but he managed to push it up. It hurts nose and throat very much and makes nose bleed freely. Tube drawn out covered with blood. Operation leaves one very sick. Food dumped directly into stomach feels like a ball of lead. Left nostril, throat and muscles of neck very sore all night."

Dora Lewis was held down by five people while Gannon forced the tube through her lips. "I didn't know where to breathe from and everything turned black when the fluid began pouring in," she wrote. Alice Paul and Rose Winslow were fed this way three times a day for three weeks, until they were let out. Winslow got a note out of the prison: "We think of the coming feeding all day. It is horrible."

### Alice Paul

> **Who:** The organizer who put the first picket line outside the White House, and who served six prison terms for women's right to vote.
>
> **When and where:** Born at Mount Laurel, New Jersey, January 11, 1885. Washington, D.C., 1913 to 1920.

**A nurse shone a light on her face every hour all night.**

Alice Paul grew up in a Quaker family and earned a doctorate, the highest university degree, in economics from the University of Pennsylvania in 1912. She also studied in London and Birmingham. In England she joined Emmeline Pankhurst's campaign for the vote and was arrested for it more than once.

Back home, she became chairman of the National American Woman Suffrage Association's Congressional Committee in 1913. She then founded the Congressional Union and, in 1916, the National Woman's Party. She organized the 1913 march in Washington, and she started the picket line at the White House gates on January 10, 1917.

**Seven months.** In October 1917 she was arrested for picketing and sentenced to seven months for obstructing traffic. On her way to serve it, she told reporters, "We are being imprisoned, not because we obstructed traffic, but because we pointed out to the President the fact that he was obstructing the cause of democracy at home, while Americans were fighting for it abroad." The United States was then fighting in the First World War.

**The psychopathic ward.** In the District of Columbia jail she went on hunger strike. Commissioner Gardner, one of the officials who governed the District of Columbia, told Dr. Gannon, "Go ahead, take her and feed her." She was carried on a stretcher to the jail's psychopathic ward, the part of the hospital for people thought to be insane. Gannon ordered one of her windows nailed shut and her door replaced with a barred cell door. A prisoner on a ladder nailed heavy boards across the other window from outside.

A nurse was ordered to check on her every hour through the night by turning an electric light onto her face. Under the rules of the time, the signatures of two doctors were enough to send a person to St. Elizabeth's, the government asylum, a hospital where such people were locked up. "No trial, no counsel, no protest from the outside world!" she wrote later, counsel meaning a lawyer.

**The doctor who said no.** The psychiatrist sent to examine her, Dr. William A. White, ran St. Elizabeth's, and he did not find her insane. A psychiatrist is a doctor who treats illnesses of the mind. "I felt myself in the presence of an unusually gifted personality," he wrote, and he praised the "most admirable, coherent, logical and forceful way" in which she argued her case. A lawyer, Dudley Field Malone, forced his way in and got her out of the ward.

She was released after five weeks of her seven-month sentence. She served six prison terms for the vote in all, three in England and three in the United States.

**After the vote.** She earned a law degree in 1922 and wrote the Equal Rights Amendment, which said that men and women must have equal rights under the law.

She had it introduced at Seneca Falls on July 20, 1923, where it was called the Lucretia Mott Amendment. In 1945 she worked on the words about women in the United Nations Charter, and later on the part about sex in the Civil Rights Act of 1964. The amendment she wrote was still not part of the Constitution when she died at Moorestown, New Jersey, on July 9, 1977, aged 92.

### Margaret Sanger and the Comstock laws, 1914 to 1936

Margaret Sanger went to jail for giving women information about birth control, ways to keep from becoming pregnant. The Comstock Act of 1873 made it a crime to send that information by mail. Sanger was charged under the Comstock laws in 1914 for publishing *The Woman Rebel*, a paper about birth control, and she left for England.

**The clinic.** She opened a birth control clinic in Brooklyn, New York, on October 16, 1916. Police arrested her about a week later, and she spent 30 days in jail. Judges ruled in 1918 that doctors could give women birth control for medical reasons. Sanger founded the American Birth Control League in 1921.

The judges of a federal court ruled in 1936 that doctors could give their patients birth control. A National Women's History Museum biography states that Sanger also supported parts of the eugenics movement, whose members wanted to stop people they judged unfit from having children.

**By 1918:** The NAACP had been working for nine years, and women who picketed the White House had been jailed and fed by force.

### Attacks in 25 cities, and a court case out of Elaine, 1919 to 1925

White mobs attacked Black Americans in 25 major cities in 1919, and the NAACP's lawyers turned one of those attacks into a Supreme Court ruling. The year's violence is called the Red Summer. Writers at the Equal Justice Initiative, a group that records racial violence, state that white mobs and police especially targeted Black veterans coming home from the First World War.

**Chicago.** A 17-year-old Black boy named Eugene Williams was swimming off a raft near the 29th Street beach in Chicago on July 27, 1919. A 24-year-old white man, George Stauber, threw stones at the Black boys, and Eugene Williams drowned. A police officer, Daniel Callahan, refused to arrest Stauber.

White youth gangs and neighborhood "athletic clubs" then attacked Black neighborhoods, and the fighting went on until August 3. Thirty-eight people were killed, 23 Black and 15 white. About 537 were hurt, and two out of three of them were Black. Two out of three of the 138 people charged with crimes afterward were Black too.

**Elaine.** In Elaine, Arkansas, Black sharecroppers had joined a union. A sharecropper farmed land owned by someone else and paid for it with a share of the crop, and a union is a group of workers who bargain together. This one, the Progressive Farmers and Household Union of America, was led by Robert Lee Hill. Its members wanted a better price for their cotton from the white landowners.

About 100 of them met in a church at Hoop Spur on the night of September 30, 1919. Men in a car outside and the union's armed guards exchanged shots. A white security officer, W. A. Adkins, was killed, and a deputy sheriff, Charles Pratt, was wounded.

**The killing.** Between 500 and 1,000 armed white men came to Elaine from the surrounding Arkansas counties and from across the river in Mississippi. A white witness, H. F. Smiddy, swore in 1921 that "several hundred of them" began "to hunt negroes" and shoot them as they found them. Governor Charles Hillman Brough sent more than 500 soldiers from Camp Pike, and they arrived on October 2. Some accounts say the soldiers also killed Black people at random.

Four brothers, David, Gibson, Lewis and Leroy Johnston, were killed on October 2 on their way home from a hunting trip. The Encyclopedia of Arkansas does not say who killed them. Five white people were killed.

**Disputed:** The count of Black dead. The Encyclopedia of Arkansas gives a count that "ranged into the hundreds," and a National Archives page gives more than 100. The Army commander, Colonel Isaac Jenks, reported that his soldiers had killed two.

**The trials.** Phillips County officials charged 122 Black people with crimes. By November 5, 1919, twelve men had been tried in Phillips County and sentenced to death. One of their white defense lawyers admitted he "had not interviewed any witnesses." Walter White of the NAACP went to Arkansas to investigate, and a Black lawyer from Little Rock, Scipio Africanus Jones, defended the twelve.

The justices of the Supreme Court ruled on February 19, 1923, in *Moore v. Dempsey*, that the trials had been unfair. Justice Oliver Wendell Holmes wrote that one trial "lasted about three-quarters of an hour and in less than five minutes the jury brought in a verdict of guilty of murder in the first degree." An angry crowd had filled the courthouse and the streets around it.

Sworn statements in the case said Black witnesses had been "whipped, placed in the electric chair and strangled by something put in their noses to make them testify." Governor Thomas McRae freed the last of the twelve in January 1925.

### Anti-lynching bills in Congress, 1900 to 1924

NAACP leaders pushed Congress for a federal law against lynching, and in the whole of this era members of Congress never passed one. Under such a law, federal judges could have tried the members of a lynch mob when state officials would not.

Representative George Henry White of North Carolina brought the first federal anti-lynching bill to Congress on January 20, 1900. He was the last Black member of Congress of his generation. Members of Congress did not pass his bill.

**The Dyer bill.** Representative Leonidas Dyer of Missouri introduced a bill on April 8, 1918, "to protect citizens of the United States against lynching in default of protection by the States," wherever the states failed to protect them. Members of a lynch mob would have been tried in federal court for murder, and the county where a lynching happened would have been fined.

Any sheriff or jailer who handed a prisoner to a mob, or failed to stop one, could have been jailed and fined up to $5,000. People who had been part of a mob could not sit on the jury.

NAACP leaders published a report in April 1919, *Thirty Years of Lynching in the United States, 1889-1918*. It recorded 3,224 people killed by lynch mobs in those thirty years, about two every week. Of them, 2,522 were Black, and 50 of the Black victims were women.

They sent James Weldon Johnson to Washington to press members of Congress in person. "I tramped the corridors of the Capitol and the two office buildings so constantly that toward the end, I could, I think, have been able to find my way about blindfolded," he wrote.

**The vote that never came.** Members of the House of Representatives passed the bill on January 26, 1922, by 230 votes to 119, with several hundred Black visitors crowded into the public gallery. NAACP organizers held a silent march in Washington for it on June 14, 1922, with more than 5,000 Black marchers. Senators never voted on it. Southern Democratic senators filibustered it, which means they kept talking so that no vote could be held. They did the same in 1923 and 1924, and Republican senators let the bill drop.

### The 19th Amendment, 1920, and the women it did not reach

The 19th Amendment to the Constitution was ratified in August 1920. After it, no official of the United States or of any state could refuse citizens the vote because of their sex. Its first section is one sentence: "The right of citizens of the United States to vote shall not be denied or abridged by the United States or by any State on account of sex," abridged meaning cut down.

**Forty-two years.** The same words had been in front of Congress for 42 years. Senator Aaron Sargent of California introduced them on January 10, 1878. Senators voted them down in 1887, 1914, 1918 and February 1919. Susan B. Anthony died in Rochester, New York, on March 13, 1906, and suffragists named the measure the Anthony Amendment in her memory.

Representatives passed it on May 21, 1919, and senators passed it on June 4, 1919, by 56 votes to 25. Then lawmakers in three-fourths of the states had to ratify it. Tennessee's lawmakers made it the 36th state to do so on August 18, 1920, the last one needed. Secretary of State Bainbridge Colby signed the paper declaring it part of the Constitution on August 26, 1920, 72 years after the meeting at Seneca Falls.

**Who still could not vote.** State officials could no longer refuse a woman the vote because she was a woman, but they could still refuse her for other reasons. In the South, white officials already kept Black men from voting, by rules and by violence.

A National Park Service article states that Black women in the South "encountered the very same disfranchisement strategies and anti-Black violence that led to the disfranchisement of Black men." A National Archives page states that many women "remained unable to vote long into the 20th century because of discriminatory state voting laws," laws unfair to people because of who they were.

**By 1920:** Women had won the vote in the Constitution, white officials in the South still kept many Black women and men from using it, and senators had blocked every federal bill against lynching.

### Tulsa, June 1, 1921: white Tulsans burn Greenwood

Thousands of armed white Tulsans went into Greenwood, the Black district of Tulsa, Oklahoma, on June 1, 1921, and burned it to the ground. They killed as many as 300 people. The attackers threw bodies into the Arkansas River, carried them off on railroad flatcars and buried them in unmarked graves, so the true count may never be known. Red Cross workers counted about 700 people hurt.

**Disputed:** The number of dead. The historian Scott Ellsworth writes that "credible estimates of deaths range from fifty to three hundred." In 2025 lawyers at the United States Department of Justice wrote that the attack "killed as many as 300 Tulsans, perhaps even more."

**Greenwood.** About 10,000 Black people lived in Greenwood. It had two newspapers, more than a dozen churches, a library, two "fine hotels," four drug stores and many grocery stores. Loula Williams owned the Dreamland Theater, and J. B. Stradford owned a hotel of 54 rooms. Doctors, lawyers and teachers lived on Detroit Avenue, and families owned pianos and good furniture.

Black Tulsans spent their money in Greenwood because most white business owners in Tulsa would not serve them or treated them with contempt. Under city laws, Black families could not live in white blocks unless they worked there as servants. White officials controlled the city's tax money and spent none of it in Greenwood on running water or on carrying away sewage and garbage, and they paved fewer of its streets. All of Tulsa, Greenwood included, stood on land in the Muscogee (Creek) Nation's reservation.

**How it began.** Police arrested Dick Rowland, a 19-year-old Black man, on May 31. A white woman, Sarah Page, ran the elevator he used, and a white man had accused him of attacking her. She did not press charges. That evening a white crowd gathered at the courthouse to lynch Rowland, and armed Black men went there to stop it. Shooting broke out.

Tulsa police then deputized hundreds of white men, swearing them in as temporary police officers. Many of those men had been calling for a lynching and had been drinking.

**The night.** White men set the first fires in Greenwood at about 1 in the morning. When firemen came, armed white men threatened them and told them to let the Black homes burn. A little after 5 in the morning, a whistle blew. White men who had been organized into companies during the night gathered at three railroad stations and went into Greenwood.

**How many.** Counts of the white men who went in run from 8,000 to 10,000, and the state commission of 2001 gave about 10,000. The head of Oklahoma's National Guard, the state's own army of part-time soldiers, gave the *New York Times* a figure of 25,000. The Justice Department's review says many take that to be a misprint for 2,500.

**House by house.** The attackers went from house to house. They took what they wanted, piled bedding and furniture in the middle of a room, poured kerosene over it and lit it. They backed trucks up to houses and loaded "everything moveable and of value." White women came with shopping bags and took clothes, silverware and jewelry. The attackers opened safes and destroyed people's legal papers before burning the buildings.

They burned more than 1,200 houses and 35 city blocks. Among the buildings they burned were a dozen churches, five hotels, 31 restaurants, four drug stores, eight doctors' offices, more than two dozen grocery stores and the library.

**The killing.** They killed people who ran and people who gave up. The Justice Department's review describes a grandfather shot in front of his family in a wagon, and an old man who could not walk, shot in his home when he said he could not "march." Four white men tied a blind man who had lost both legs to the back of a car and dragged him through the streets until he died.

An old couple on Greenwood Avenue were shot in the back of the head while they prayed. A man was shot as he came out of a burning building and thrown back into the fire. Survivors could not name the men who did these things. The Red Cross's relief director in Tulsa, Maurice Willows, who was white, wrote: "This was NOT a RIOT."

**Fighting back.** Some Black men fought back. A group fired from the bell tower of the new Mount Zion Baptist Church until National Guard soldiers turned a machine gun on it. J. B. Stradford shot from the second floor of his hotel. He gave up when the attackers promised not to burn it, and then they burned it.

**The Guard.** Three Guard units were in Tulsa, and before the governor took control the guardsmen took orders from Police Chief John Gustafson. By their own reports, they helped the police organize white men into companies and went into Greenwood to round up Black residents. The Justice Department's review states that the guardsmen's main work was capturing Black men. That left Black homes empty, and other white men looted and burned them.

Some guardsmen tried to hold back white attackers. Governor James Robertson declared martial law, which put the Guard in charge of the city, at 11:30 that morning.

**The airplanes.** Airplanes flew over Greenwood during the attack. The Justice Department's review calls it "undisputed" that the men in them watched where Black residents ran and told the police. Many survivors said men in the planes also dropped firebombs or shot at people fleeing. The lawyer B. C. Franklin, who saw it, described turpentine bombs. The review calls that part "hotly disputed."

### The camps, the passes and the grand jury, June 1921

Police, deputies and guardsmen arrested Black people all over Tulsa after the burning, whether or not they were suspected of anything. The Justice Department's review states that the arrests were not based on "probable cause or even reasonable suspicion," the legal words for a good reason to believe a person has done something wrong. Guardsmen also arrested Black servants in the servants' rooms of white homes.

They held the people they arrested under armed guard in three places: Convention Hall, McNulty Park, which was a baseball park, and the stalls of the fairgrounds. At the fullest, between 4,000 and 6,000 people were held, some for a few days and some for up to two weeks. Guardsmen arrested some white men for looting, but they held no white person in the camps.

**The cards.** To leave a camp, a Black person needed an identification card, and a white person had to vouch for it. People who worked in white homes and businesses got green cards that did not run out. People without jobs got red cards that were good for one day.

Anyone found without a card was arrested again. By June 7, officials had given out 7,500 of these cards, and the rule lasted at least a month. People forced to live under it said they were treated "as though they [were] dogs."

**Forced labor.** The day after the burning, the Guard commander ordered "all able bodied [N]egro men" in the camps to "render such service and perform such labor as is required." The men cleared the ruins and buried the dead. Red Cross officials paid up to 25 cents an hour, and a meal cost 20 cents.

For several weeks officials did not allow Black Tulsans to own or buy guns. Most of Greenwood's people had no home left. Many lived in Red Cross tents for more than a year, and many of the tents had no floor.

**The grand jury.** A state grand jury, a group of citizens who decide whether there is enough evidence to charge someone with a crime, heard almost 200 witnesses. It charged about 70 men, many of them Black leaders of Greenwood, with starting the "riot." The *Tulsa Daily World* printed its report on June 26, 1921, under the headline "Grand Jury Blames Negroes for Inciting Race Rioting: Whites Clearly Exonerated," exonerated meaning cleared of blame.

Most of the cases were later dropped, including the case against Dick Rowland. Some white men were charged with looting. No white man went to prison for the killings or the burning. The grand jury also charged Police Chief Gustafson with neglect of duty, failing to do the job he was paid to do, and with dishonest dealings from before the massacre. He was found guilty in court and removed from his post.

### Building Greenwood again, against the city

Greenwood's people rebuilt their district with no rebuilding money from the city, the state or the federal government, after winning a court fight against city leaders who tried to stop them. Tulsa's city commissioners passed Fire Ordinance No. 2156, a city law, on June 7, 1921. It put most of Greenwood inside the city's fire limits, an area with strict building rules meant to stop fires spreading. Every new building there had to be "of concrete, brick, or steel and ... at least two stories high."

The first newspaper story about the rule said the land would "never again be a [N]egro quarter but will become a wholesale and industrial center." The Justice Department's review stated in 2025 that "those who drafted the ordinance planned to drive Black people out of Greenwood."

**The lawyers in a tent.** B. C. Franklin, a Black lawyer, set up an office in a tent on Archer Street with two partners, I. H. Spears and T. O. Chappelle. Before they could get to court, police had arrested many people for trying to rebuild. The lawyers won a court order that stopped the rule for a time, and then, in September 1921, an order that stopped it for good.

**The claims.** Greenwood's people filed more than $1.8 million in damage claims with the city between June 1921 and June 1922. City officials turned down all but one, and the one they paid went to a white shop owner for guns taken from his store. Franklin's firm filed about $4 million in claims against the city and against insurance companies.

Officials of the insurance companies refused to pay, because their policies did not cover damage done in a "riot." The justices of the Oklahoma Supreme Court ruled in 1926 that no one could sue the insurance companies over it. Judges threw out the lawsuits against the city, Mayor T. D. Evans, the police and the airplane company.

**Greenwood again.** The National Negro Business League held its national meeting in Greenwood by 1925, and by the 1940s Greenwood had 242 Black-owned businesses. From the 1950s, city officials took land along its edges for highways. The Inner Dispersal Loop and the Cherokee Expressway, finished in the 1970s, run along Greenwood's south and east sides.

### The survivors ask to be paid, 1997 to 2026

Greenwood's survivors began asking to be paid for what was taken from them in June 1921, and in more than a hundred years neither the city nor the state paid them. Oklahoma's lawmakers set up an 11-member commission to study the massacre in 1997. Its members handed in their report on February 28, 2001. They asked the state to pay the survivors and their descendants directly, and to fund scholarships, business growth in the area and a memorial.

The lawmakers passed the 1921 Tulsa Race Riot Reconciliation Act on June 1, 2001. They voted no money for the survivors in it.

**The lawsuits.** Survivors and descendants sued the state and the city in 2003. Federal judges threw the case out in 2004, ruling that they had waited too long to sue. The last three known survivors sued again in 2020: Viola Fletcher, her brother Hughes Van Ellis and Lessie Benningfield Randle. They sued the City of Tulsa, the Tulsa Regional Chamber, the county's commissioners, Sheriff Vic Regalado and the Oklahoma Military Department. On May 19, 2021, the three spoke to a committee of Congress.

**A president's visit.** President Joe Biden met the three survivors and spoke at the Greenwood Cultural Center on June 1, 2021. He was the first president in office to visit Greenwood about the massacre. "It wasn't a riot, it was a massacre," he said. He did not call for the survivors to be paid.

**The end of the case.** The justices of the Oklahoma Supreme Court ended the survivors' lawsuit on June 12, 2024, by eight votes to one. They wrote that the harm the massacre left behind "can only be resolved by policymakers, not the courts." Hughes Van Ellis had died on October 9, 2023, aged 102. Viola Fletcher died on November 24, 2025, aged 111. Lessie Benningfield Randle, born on November 10, 1914, was the last known survivor in 2026, and neither the city nor the state had ever paid her.

**The graves.** Tulsa's mayor, G. T. Bynum, started a search for the massacre's unmarked graves in 2018. By September 2026 the searchers had dug up the remains of 55 people in Oaklawn Cemetery, and they have named two victims of the massacre. C. L. Daniel was identified by DNA in July 2024. James Goings was identified from Veterans Administration records in June 2025, and his grave has not been found. Both men had served in the Army in the First World War.

### Viola Fletcher

> **Who:** A seven-year-old girl whose family fled Greenwood in 1921, who never went to school past the fourth grade, and who at 107 asked Congress for justice.
>
> **When and where:** Tulsa, Oklahoma, 1921. Washington, D.C., May 19, 2021.

**"I am 107 years old and have never seen justice."**

Viola Fletcher was born Viola Ford on May 10, 1914, the daughter of Lucinda Ellis and John Wesley Ford of Tulsa. She grew up in Greenwood with her parents and five brothers and sisters. "The neighborhood I fell asleep in that night was rich," she told Congress in 2021, "not just in terms of wealth, but in culture, community, and heritage." "My family had a beautiful home. We had great neighbors and I had friends to play with. I felt safe."

**The night they left.** On the night of May 31, 1921, her family woke her and told her they had to leave. "I will never forget the violence of the white mob when we left our house," she said. "I still hear airplanes flying overhead. I hear the screams. I live through the Massacre every day."

"When my family was forced to leave Tulsa, I lost my chance at an education," she said. "I never finished school past the fourth grade." During the Second World War she worked in the shipyards in California. "For most of my life, I was a domestic worker serving white families," she said, cleaning and cooking in other people's homes.

**Before Congress.** At 106, in 2020, she joined her brother and Lessie Benningfield Randle in suing the City of Tulsa and others. She spoke to the House of Representatives' subcommittee on civil rights on May 19, 2021. "Today, I am in Washington, D.C. for the first time in my life. I am here seeking justice," she told them. "I am 107 years old and have never seen justice." She asked them to "open the courtroom doors to us."

She and her grandson, Ike Howard, published a book about her life in 2023, *Don't Let Them Bury My Story*. The justices of the Oklahoma Supreme Court ended the survivors' lawsuit in June 2024. Viola Fletcher died on November 24, 2025, aged 111, and she never saw the survivors paid.

### Grace Fryer

> **Who:** A watch-dial painter who sued the company whose paint had poisoned her, and who had to fight a state time limit that ran out before she knew she was ill.
>
> **When and where:** Orange, New Jersey, 1917 to 1928.
>
> **Movie:** Radium Girls (2018)

**The painters shaped each radium brush between their lips.**

Grace Fryer painted numbers on watch dials at the U.S. Radium Corporation's plant in Orange, New Jersey, from 1917 to 1920. The paint glowed in the dark because it had radium in it. Radium is a radioactive metal, which gives off radiation, energy that can damage the body's cells.

To keep a fine point on the brush, the painters put the tip between their lips. The physicist Robley Evans wrote down why: a cloth or their fingers "were too harsh, but by wiping the brush clean between their lips the proper erasing point could be obtained."

**What radium did.** The body takes up radium as if it were calcium and builds it into the bones and teeth. Once there, it stays and keeps giving off radiation from the inside. When doctors examined the bodies of dial painters after death, they found 99 percent of the radiation in the skeleton. Radium in the bones stopped the marrow from making blood properly, killed the jaw bone so that it broke apart, and caused bone cancers.

Fryer left the plant in 1920. In 1924 she went to a dentist, Theodor Blum, who found that her jaw bone was wasting away. He had never seen anything like it. Doctors came to call it radium jaw.

**The time limit.** A lawyer, Raymond Berry, filed suit against the company in May 1927 for Fryer and four women she had worked with: Katherine Schaub, Quinta Maggia Macdonald, Albina Maggia Larice and Edna Hussman.

The company's lawyers argued that New Jersey's statute of limitations, the time limit after which a person can no longer sue, meant the company could not be blamed. New Jersey's limit for injuries at work was two years. Radium poisoning took longer than two years to show itself, and Fryer had left the plant seven years before.

**The settlement.** A federal judge, William Clark, brought the two sides to a settlement outside court on June 4, 1928, and they signed it on June 8. Each woman got $10,000, though some sources give as much as $15,000. Each also got $600 a year for as long as she lived, and her doctors' bills paid. The settlement papers contain no admission that the company was to blame.

**Ottawa, Illinois.** Ten years later, women who had painted dials for the Radium Dial Company in Ottawa, Illinois, fought the same fight. One of them, Catherine Wolfe Donohue, collapsed at a hearing on February 10, 1938, and was carried out of the room.

The officer hearing her case ruled on April 5, 1938, that her work had made her ill and awarded her $5,661, plus $277 a year for life. On July 6 the members of the Illinois Industrial Commission, the state board that heard workers' claims, threw out the company's appeal and added $730.

She died on July 27, 1938, aged 35. The last ruling in her case came that October, after her death, and her family received a small payment.

**By 1925:** White Tulsans had burned Greenwood, its people were rebuilding it without help from the city, and a dentist had found a watch-dial painter's jaw bone wasting away from radium.

### Native Americans become citizens and fight for the vote, 1911 to 1957

Native Americans organized their own national rights groups in these years, and it took them 33 years after they became citizens to win the vote in every state. Native people founded the Society of American Indians at Columbus, Ohio, on October 12, 1911, the first national rights organization run by Native people.

Charles Eastman and Carlos Montezuma were among its leaders, and Zitkala-Ša edited its journal. She founded the National Council of American Indians in 1926. Eighty delegates from more than 50 tribes met in Denver on November 16, 1944, and founded the National Congress of American Indians.

**Citizens without the vote.** Members of Congress passed the Indian Citizenship Act on June 2, 1924, and President Calvin Coolidge signed it. American Indians became citizens. That did not put them on the voter rolls, the lists of people allowed to vote, because officials in each state set their own rules about who could vote.

**Arizona and New Mexico.** Under Arizona's law, no one could vote who was an "idiot, insane person, person non compos mentis, or under guardianship." Non compos mentis is Latin for "not of sound mind," and a person under guardianship has been placed in someone else's care by law.

The justices of the Arizona Supreme Court ruled in 1928 that Native people living on reservations were under the guardianship of the federal government, and so could not vote. New Mexico officials used the state constitution's phrase "Indians not taxed." People on reservations paid no state taxes, they argued, and so could not vote.

**1948.** Judges threw out both rules in 1948. The justices of the Arizona Supreme Court threw out their own court's 1928 ruling in *Harrison v. Laveen* on July 15, 1948. Justice Levi Udall wrote that a Native person who met the other requirements could not be kept off the rolls for living on a reservation.

Three federal judges in New Mexico ruled in August 1948, in *Trujillo v. Garley*, that the "Indians not taxed" rule broke the Constitution. Utah's officials were the last in any state to let Native people vote, in 1957.

### A society for gay rights in Chicago, 1924

Henry Gerber founded the Society for Human Rights in Chicago on December 10, 1924. A National Park Service article calls it the first organization in the United States set up only to work for the civil rights of gay people. A gay person is a man who loves men or a woman who loves women.

Gerber was born Josef Heinrich Dittmar in Bavaria, in Germany, on June 29, 1892. He came through Ellis Island in October 1913, served in the United States Army and worked for the Post Office. He got a charter for the society from the State of Illinois, a paper that made it a legal group, by describing its members as people "abused and hindered in the legal pursuit of happiness." Its members printed two issues of a newsletter, *Friendship and Freedom*. No copy survives.

**The arrests.** Chicago police arrested Gerber and other members without a warrant, a court paper that allows an arrest. They took his typewriter, his writings and his diaries, and they gave back only the typewriter. Post Office officials fired him "for conduct unbecoming a postal employee." The society ended in 1925. Gerber died in 1972. His house in Chicago became a National Historic Landmark in June 2015.

### Eugenics: operating on people so they could not have children

Eugenics was the belief that a country could improve its people by deciding who was fit to have children and stopping the rest. Francis Galton, an English scientist who studied numbers about people, made up the word in 1883. A fact sheet from the National Human Genome Research Institute calls eugenics "the scientifically erroneous and immoral theory of 'racial improvement' and 'planned breeding,'" erroneous meaning wrong. The idea became popular in the early 1900s.

**Sterilization.** American eugenicists pushed for laws under which officials could force people to be sterilized. To sterilize a person is to operate on them so that they can never have a child, and the operation cannot be undone. When Dr. John H. Bell operated on Carrie Buck in Virginia in 1927, he cut out a piece of each of the two tubes that carry eggs to her womb.

**The model law.** Harry H. Laughlin of the Eugenics Record Office wrote a model sterilization law for lawmakers in each state to copy. A page from the United States Holocaust Memorial Museum states that "in part due to Laughlin's efforts, dozens of American states enacted laws that forced certain people to be sterilized against their will." The same page states that "more than 62,000 sterilizations had been performed in the United States by the 1960s," and that about six in ten of the people operated on were women.

The National Human Genome Research Institute's fact sheet counts at least 60,000 people sterilized under the laws of 30 states by the 1970s. The people targeted included Latinos, Native Americans, African Americans, poor white people and disabled people.

**Germany.** Germany's Nazi rulers passed the Law for the Prevention of Offspring with Hereditary Diseases in 1933, a law about children and illnesses passed from parents to children. The Holocaust Museum's page states that the law was "based in part on the practice of forced sterilization in the US." Doctors in Nazi Germany sterilized about 400,000 people under it.

Leaders of the University of Heidelberg in Germany gave Harry Laughlin an honorary degree in 1936, a degree given as an honor without study. He wrote back on May 28, 1936, that "To me this honor will be doubly valued because it will come from a nation which for many centuries nurtured the human seed-stock which later founded my own country." Seed-stock means the animals or plants that farmers keep for breeding. Laughlin used the word for people.

### Carrie Buck

> **Who:** A young Virginia woman chosen as a test case by the man who wanted to sterilize her, and defended by a lawyer who wanted the same thing.
>
> **When and where:** Virginia, 1924 to 1927. Died at Waynesboro, Virginia, January 28, 1983.

**Her own lawyer wanted her sterilized too.**

Carrie Buck's case was arranged so that Virginia's officials would win it. Virginia's lawmakers passed the state's sterilization law on March 20, 1924, and a lawyer, Aubrey Strode, wrote it. Albert Priddy ran the Virginia State Colony for Epileptics and Feeble-Minded, a place where Virginia's officials held people they had ordered locked up. Epileptics are people with epilepsy, an illness that causes seizures. Feeble-minded was a label then given to people who scored low on intelligence tests.

**How she came to the Colony.** Carrie Buck was born in Charlottesville on July 2, 1906, and raised by foster parents. Encyclopedia Virginia states that she was "allegedly raped" by their nephew and became pregnant. Rape means forcing a person to have sex. Her foster parents said the pregnancy showed that she was feeble-minded, and on January 23, 1924, they asked a court in Charlottesville to have her sent to the Colony.

Priddy wanted to know whether the new law would hold up in court. So he picked one of the people held there, Carrie Buck, and had a case brought over her. Priddy died on January 13, 1925, and Dr. John H. Bell took his place at the Colony and in the case. That is why it is called *Buck v. Bell*.

**Two lawyers on one side.** Strode, who had written the law, argued for the Colony in court. Carrie Buck's lawyer was Irving P. Whitehead, who had sat on the Colony's own board and supported sterilization. The historian Paul Lombardo found that Whitehead did not seriously question any of the witnesses against her and did not call one witness for her. Both lawyers wanted the judges to rule that the law was allowed.

A eugenics researcher, Arthur Estabrook, interviewed the family for one day. Then he testified that Carrie, her mother Emma and her baby daughter Vivian were "a defective strain." Officials had committed Emma Buck to the Colony in April 1920, ordering her held there. Vivian was born on March 28, 1924. A social worker said of the baby that she had "a look about it that is not quite normal."

**Three courts.** Judge Bennett T. Gordon of the trial court ruled for the Colony on November 18, 1924. The judges of the Virginia Supreme Court of Appeals agreed with him on November 12, 1925. The justices of the Supreme Court of the United States heard the case on April 22, 1927, and ruled for the Colony, eight to one, on May 2, 1927.

**The operation.** Dr. Bell performed a salpingectomy on Carrie Buck on October 19, 1927. He cut out a section of each of her two tubes that carry an egg from an ovary to the womb. After that, no egg could reach her womb, so she could never become pregnant. The operation could not be undone. The staff released her from the Colony the next month.

Officials had brought her sister, Doris Buck, to the Colony in June 1926. Colony officials signed an order to sterilize Doris in December 1927, and doctors operated on her in January 1928.

**Afterward.** Virginia doctors sterilized about 8,300 people under the law between 1927 and 1972. Virginia's lawmakers ended the law in 1974. Lawyers for the American Civil Liberties Union sued for the survivors in 1980, and the two sides settled the case out of court. On May 2, 2002, 75 years to the day after the ruling, Governor Mark Warner apologized for what he called "a shameful effort in which state government never should have been involved."

Carrie Buck married twice. She died in a nursing home in Waynesboro, Virginia, on January 28, 1983. The justices of the Supreme Court have never overturned *Buck v. Bell*, which means they have never ruled that it was wrong.

**By 1929:** Native Americans were citizens who still could not vote in Arizona or New Mexico, and the Supreme Court's justices had allowed Virginia doctors to sterilize Carrie Buck.

### Citizens sent to Mexico, 1929 to 1936

Federal, state and county officials sent or forced hundreds of thousands of people whose families came from Mexico out of the United States during the Great Depression, the years of hard times after 1929. Many of them were American citizens. Counts run from about 500,000 to about 2 million. In a 2005 law, California's lawmakers found that about 1.2 million of the 2 million people they counted had been born in the United States, which made them citizens.

**Los Angeles.** William N. Doak, President Herbert Hoover's Secretary of Labor, led a national campaign to remove Mexicans, saying they were taking jobs. In Los Angeles, Charles P. Visel, head of the city's unemployment relief committee, planned the publicity. Immigration agents closed the exits of La Placita park in Los Angeles on February 26, 1931, with about 400 people inside.

Los Angeles County welfare officers told families their relief money, the public money that poor families lived on during the Depression, would stop unless they took free train tickets to Mexico. The first county train left on March 23, 1931. Hospital staff carried patients on stretchers to trucks bound for the border. Local officials often sold the property that families left behind.

**The apologies.** California's governor signed a law on October 7, 2005, in which the state's lawmakers apologized "for the fundamental violations of their basic civil liberties and constitutional rights committed during the period of illegal deportation and coerced emigration." That means people were sent out of the country against the law, or forced to leave it. The Los Angeles County supervisors, who run the county, apologized in 2012. Representative Hilda Solis called on the federal government to apologize in 2006. No president and no Congress has apologized.

### Two California school cases, 1931 and 1946

Mexican American parents in California won two school desegregation cases, fifteen years apart, and the first, in 1931, was the first school desegregation case won in the United States, desegregation meaning an end to keeping children of different races apart.

**Lemon Grove.** The principal of Lemon Grove Grammar School, near San Diego, Jerome T. Green, stood in the doorway on January 5, 1931. He let in every child except the Mexican American ones and told them to go to a separate two-room building. Members of the school board had planned this the summer before. The school had 169 pupils: 87 counted as European American, about 75 Mexican American and 7 Japanese American.

The parents formed a committee, the Comité de Vecinos de Lemon Grove, the Lemon Grove Neighbors Committee. They kept their children out of the separate building and hired two lawyers, Fred Noon and A. C. Brinkley, and they sued in the name of one of the pupils, Roberto Alvarez.

Judge Claude Chambers of the San Diego County Superior Court ruled on March 30, 1931. He ordered the district to admit the children "on a basis of equality with other children of said school district, and without separation or segregation in a separate school because of race or nationality." Putting "all the Mexicans in one group can only be done by infringing," or breaking, "the laws of the State of California," he said. Some accounts date the ruling March 31.

**Mendez.** Fifteen years later, five families in Orange County, among them the Mendez family, sued four school districts there. Their lawyer had won a case in 1944 against segregated pools and parks in San Bernardino.

Judge Paul J. McCormick ruled for the families on February 18, 1946. "A paramount requisite in the American system of public education is social equality," he wrote. He meant that treating all children as equals came first in American public schools.

When the districts' officials appealed, asking a higher court to change the ruling, other groups joined the fight. NAACP lawyers, among them Thurgood Marshall, filed a friend-of-the-court brief, an argument from people who are not part of a case. Four other groups filed briefs too, among them a Japanese American group and a Latin American group.

The judges of the federal appeals court ruled for the families on April 14, 1947. Governor Earl Warren signed the Anderson Bill in June 1947, and with it California's lawmakers took segregated schools out of the state's school laws, the first lawmakers in any state to do so. Warren became Chief Justice of the United States in 1953.

**The Munemitsu farm.** While the Mendez family fought school segregation, they were farming land whose Japanese American owners federal officials had locked up. The farm was 40 acres in Westminster that belonged to Seima Munemitsu and his family. Federal officials held the Munemitsus at the Poston camp in Arizona from May 1942 to September 1945.

### Could a school turn a disabled child away?

Yes. School officials could turn a disabled child away in these years, because no law required them to teach one. The rule came from a Massachusetts case decided on January 4, 1893.

Members of the Cambridge school committee had put a boy named John A. Watson out of the public schools in 1885. Their record states that he was excluded "because he was too weak-minded to derive profit from instruction," and that he was "troublesome to other children, making uncouth noises, pinching others," uncouth meaning rude and rough. The judges of the Massachusetts Supreme Judicial Court ruled that the committee's decision was final and that no court could review it. That rule held through the whole of this era.

**Parents organize.** Parents in Cleveland, Ohio, founded the Cuyahoga County Council for the Retarded Child in 1933. "Retarded" was the word then used for children with intellectual disabilities. The county's own history describes it as a group led by parents and "founded to assist children of the region who had been excluded from their public schools."

### A sit-in for jobs, New York, 1935

Six disabled New Yorkers sat down in the city's Home Relief Bureau in May 1935 and refused to leave until they were given a fair chance at government jobs. During the Depression, federal officials gave out jobs to people who were out of work through the Works Progress Administration, the WPA. Workers at the city's Home Relief Bureau stamped disabled people's applications "PH," for "physically handicapped." Officials treated anyone with the stamp as unable to work, and gave them no WPA jobs.

**The league.** About 300 disabled people formed the League of the Physically Handicapped. Most of them lived with the effects of polio, a disease that can paralyze muscles, or of cerebral palsy, a condition from birth that affects movement. After the bureau's director refused to see them, six of them began the sit-in while others picketed outside. Later they sat in at WPA headquarters too.

One member said afterward that "everybody was getting jobs." The militant members, the same member said, "just refused to accept the fact that we were the only people who were looked upon as not worthy, not capable of work," militant meaning ready to fight hard for a cause.

Officials had made about 1,500 jobs for disabled people in New York City by 1936, and the league had ended by 1938. Lawmakers in Congress passed the Social Security Act in August 1935. It defined disability as "inability to engage in substantial gainful work," so a person who received disability insurance could not easily take a job.

**By 1935:** Officials had forced hundreds of thousands of people of Mexican descent, many of them citizens, out of the country, and disabled New Yorkers had sat in to demand a fair chance at jobs.

### Charles Hamilton Houston's plan: law schools first, 1935 to 1949

Charles Hamilton Houston planned the NAACP's attack on segregated schools as a series of court cases, starting with law schools. He was born in Washington, D.C., on September 3, 1895, and he was the first Black editor of the *Harvard Law Review*. He became dean, the head, of Howard University's law school in 1929, where he trained Black lawyers to fight segregation in court. One of his students was Thurgood Marshall.

**The plan.** Houston became the NAACP's first special counsel, its chief lawyer, in the 1930s. His plan, in his words, was to "start with the law schools and higher education, and integrate schools from the top down." To integrate schools is to let Black and white students learn in the same schools.

**Donald Murray.** The first case was Donald Gaines Murray's. He applied to the University of Maryland School of Law on January 24, 1935, and was refused because he was Black. Houston, Marshall and a Baltimore lawyer, Nicholas Gosnell, took his case to the Baltimore City Court.

Judge Eugene O'Dunne ordered the university's president, Raymond A. Pearson, to admit him. The judges of the Maryland Court of Appeals agreed on January 15, 1936, and Murray graduated in 1938. The second case, Lloyd Gaines's in Missouri, went to the Supreme Court in 1938.

**Ada Lois Sipuel.** Ada Lois Sipuel was born in Chickasha, Oklahoma, on February 8, 1924. She applied to the University of Oklahoma College of Law on January 14, 1946. The university's president, George Lynn Cross, put in writing that there was no academic reason to reject her. He refused her because state law forbade teaching Black and white students in the same room.

Thurgood Marshall took her case, and the justices of the Supreme Court decided it on January 12, 1948. Oklahoma's leaders answered by setting up a separate law school for Black students in five days, in rooms at the State Capitol. She was admitted to the University of Oklahoma on June 18, 1949, three years and five months after she applied, and graduated in August 1952. Houston died on April 22, 1950.

### Lloyd Gaines

> **Who:** A history graduate who sued to study law in his own state, won the NAACP's first school case at the Supreme Court, and then disappeared.
>
> **When and where:** Missouri, 1935 to 1938. Last seen in Chicago, March 1939.

**He won his case and then disappeared.**

Lloyd Gaines graduated with honors from Lincoln University, Missouri's college for Black students, with a degree in history, in August 1935. His father, Henry Richard Gaines, was a tenant farmer, a farmer who rents the land he works, and had been a teacher. Lloyd was one of eleven children.

**Sent out of state.** He applied to the University of Missouri School of Law. The registrar, the official in charge of signing up students, was S. W. Canada, and he sent Gaines to the president of Lincoln University. Lincoln's president pointed him to a Missouri law that paid a Black student's fees to study law in a neighboring state. Missouri's officials offered to pay for him to attend law school in Kansas, Nebraska, Iowa or Illinois rather than let him into its own.

He refused the offer and sued. Charles Hamilton Houston of the NAACP and a St. Louis lawyer, Sidney Redmond, filed his case in the circuit court, a state court in Missouri, on January 24, 1936. The circuit judge ruled against him in July 1936, and the judges of the Missouri Supreme Court ruled against him on December 9, 1937.

**The ruling.** The justices of the Supreme Court of the United States heard the case on November 9, 1938, and decided it on December 12, 1938, six to two, for Gaines. "The State was bound to furnish him within its borders facilities for legal education substantially equal to those which the State there afforded for persons of the white race," Chief Justice Charles Evans Hughes wrote.

A state had to give a Black student a law school as good as the white one, inside the state itself. Justice James McReynolds dissented, and Justice Pierce Butler joined him.

**Gone.** Missouri's lawmakers did not let Gaines into the university. They created a separate law school for Black students at Lincoln University in 1939. Gaines never attended either school. He was last seen in Chicago in March 1939, at a fraternity house, and he left a bag of his belongings behind. No one formally reported him missing until October 1939.

**Known:** FBI agents reopened the case in 2007 as part of their work on unsolved civil rights crimes.

**Not known:** What happened to Lloyd Gaines. He has never been found.

### Marian Anderson sings at the Lincoln Memorial, 1939

Leaders of the Daughters of the American Revolution, a women's group, barred the Black singer Marian Anderson from singing in their hall in Washington, Constitution Hall, in 1939. Under the hall's rules, only white performers could appear there. Interior Secretary Harold Ickes arranged for her to sing on the steps of the Lincoln Memorial instead.

About 75,000 people came on Easter Sunday, April 9, 1939. Ickes introduced her with the words "Genius draws no color line." She opened with "My Country 'Tis of Thee." At the memorial's opening ceremony in 1922, the organizers had seated the crowd by race, and they had checked the speech of the one Black speaker, Robert Russa Moton, in advance.

### A. Philip Randolph

> **Who:** A union leader who twice got a president to sign an order against discrimination by threatening to bring a march to Washington.
>
> **When and where:** Washington, D.C., 1941 and 1948.

**"Ten, twenty, fifty thousand Negroes on the White House lawn."**

A. Philip Randolph founded the Brotherhood of Sleeping Car Porters in 1925, a union of the Black Pullman porters who worked on railroad sleeping cars. In 1935 the Brotherhood became the first African American union admitted to the American Federation of Labor, a national group of unions.

**The first march.** Americans were building weapons for the Second World War in 1941, and defense factories were hiring. Randolph and Bayard Rustin began organizing a march on Washington against discrimination in the defense industries, which means treating people worse because of their race. Randolph and other Black leaders met Eleanor Roosevelt and members of the president's cabinet. Randolph told them he would bring "ten, twenty, fifty thousand Negroes on the White House lawn," using the word of the time for Black people.

**The order.** President Roosevelt signed Executive Order 8802 on June 25, 1941. An executive order is a written order from the president to the people who work for the federal government. "There shall be no discrimination in the employment of workers in defense industries and in Government, because of race, creed, color, or national origin," it said, creed meaning religion.

With the order, Roosevelt set up a Committee on Fair Employment Practice to take complaints and look into them. Federal agencies, companies with defense contracts and the unions working on them all had to follow the order, and Randolph called off the march. A National Archives page states that most historians judge that the committee did little, especially in the South. After the war, members of Congress refused to make it permanent.

**The second march.** Randolph planned another march in 1948, this time against segregation in the armed forces, where officers still kept Black and white troops apart. President Truman signed Executive Order 9981 on July 26, 1948: "There shall be equality of treatment and opportunity for all persons in the armed forces without regard to race, color, religion or national origin." Military leaders resisted the order. By about 1953, the end of the Korean War, Black and white troops served together in nearly all of the armed services.

Randolph was the chief organizer of the March on Washington in 1963. He received the Presidential Medal of Freedom in 1964 and died at his home in New York City on May 16, 1979, aged 90.

**By 1941:** NAACP lawyers had won their first school case at the Supreme Court, and A. Philip Randolph's threat of a march had won a president's order against unfair hiring in defense factories.

### About 120,000 people held without charges, 1942 to 1945

Army officers, acting on President Roosevelt's order, forced about 120,000 people of Japanese ancestry out of their homes on the west coast in 1942, and federal officials held them in camps. People of Japanese ancestry are people whose families came from Japan. Officials locked them up without charging them with any crime or giving them a trial. Fred Korematsu and others who disobeyed the orders were charged with breaking them. Japan had attacked Pearl Harbor, Hawaii, on December 7, 1941.

**The order.** President Franklin D. Roosevelt signed Executive Order 9066 on February 19, 1942. Army commanders could now mark off "military areas," as large as they decided, and order "any or all persons" out of them. Lieutenant General John L. DeWitt, who commanded the Army on the west coast, used it against people of Japanese ancestry. He set curfews, orders to stay indoors during set hours, that applied only to Japanese Americans, and he gave families as little as 48 hours' notice to leave their homes.

Members of Congress passed a law on March 21, 1942, making it a crime to disobey his orders, punishable by up to a year in prison and a $5,000 fine. A page from the federal courts counts more than 120,000 people removed, two out of three of them American citizens. A National Archives page counts about 122,000, of whom nearly 70,000 were citizens.

**Topaz.** Officials held them first in temporary centers such as the Tanforan racetrack near San Francisco, and then in ten camps built inland, in Wyoming, California, Utah, Arizona, Colorado, Idaho and Arkansas. One of the ten was Topaz, the Central Utah Relocation Center, 15 miles northwest of Delta, Utah. It opened on September 11, 1942, and closed on October 31, 1945. More than 11,000 people passed through it, most of them from around San Francisco, and at its fullest more than 8,000 lived there at once.

The camp had 42 blocks, each with 12 barracks and 250 to 300 people. The barracks were built of pine boards covered with tarpaper. The furniture handed out was pot-bellied stoves, army cots, blankets and mattress covers. The people of each block shared one dining hall and one building of washrooms, toilets and laundry. A fence with seven watchtowers surrounded the camp.

**James Wakasa.** James Hatsuki Wakasa, a 63-year-old man born in Japan, was walking his dog inside the fence at Topaz on April 11, 1943. Private First Class Gerald Philpott, the military policeman in Guard Tower 8, shot him dead. Philpott said Wakasa had been too close to the fence and had not turned back when warned. Witnesses believed Wakasa was hard of hearing.

Investigators found that his body lay several feet inside the fence and that he had been facing the guard when he was shot. Army officers tried Philpott at a court-martial, a military trial, for manslaughter, killing a person without planning to, and found him not guilty.

### Four cases at the Supreme Court, and the one that won, 1943 and 1944

Four Japanese Americans took the government's orders to the Supreme Court. Three of them lost, and one, Mitsuye Endo, won.

**Breaking the curfew on purpose.** Gordon Hirabayashi and Minoru Yasui each broke the curfew on purpose so that they could challenge it in court. Yasui, a lawyer in Portland, Oregon, walked the streets after curfew on March 28, 1942, asked police officers to arrest him, and then turned himself in at the police station.

Hirabayashi, a student at the University of Washington, stayed out past curfew, refused to report for removal, and went to the FBI himself on May 16, 1942. The justices ruled in both cases in 1943 that the curfew was allowed, and they put off the question of whether the removal itself was lawful.

**Korematsu's case.** They answered that question in Fred Korematsu's case on December 18, 1944, and they ruled by six votes to three that the removal was allowed. Justice Hugo Black wrote for the majority that "all legal restrictions which curtail the civil rights of a single racial group are immediately suspect" and needed "the most rigid scrutiny," the closest possible look. Then he allowed this one.

Justice Frank Murphy dissented. He called the removal "the legalization of racism." He compared it to the "abhorrent and despicable treatment of minority groups by the dictatorial tyrannies which this nation is now pledged to destroy," meaning the countries the United States was fighting, which were ruled by dictators. Justice Robert Jackson also dissented. Korematsu, he wrote, had been found guilty for "being present in the state whereof he is a citizen."

**Mitsuye Endo.** On the same day, the justices ruled in Mitsuye Endo's case, and the government lost. Endo was born in Sacramento, California, on May 10, 1920, and worked as a clerk for the state of California. A lawyer, James Purcell, chose her to bring the case because a judge would find it hard to call her disloyal. She worked for the state, she was a Christian, she spoke only English, she had never been to Japan, and her brother was in the United States Army.

Purcell filed a petition for habeas corpus for her in the federal court in San Francisco on July 12, 1942. That petition asks a judge to order that a person held prisoner be brought to court, and freed if no one can show a lawful reason to hold her.

**Staying in the camps.** While the case went on, officials of the War Relocation Authority, the agency that ran the camps, offered to let her out if she dropped it. She refused and stayed in the camps, because leaving would have ended the case for everyone else. Officials moved her from the Sacramento assembly center to Tule Lake and then to Topaz.

"Mitsuye Endo should be given her liberty," Justice William O. Douglas wrote for the Court. The government, he wrote, "has no authority to subject citizens who are concededly loyal to its leave procedure." He meant that officials could not keep holding citizens whom they themselves agreed were loyal.

**The end of the camps.** Army commanders had issued Public Proclamation No. 21 the day before the rulings, December 17, 1944. It ended the exclusion, the order keeping people of Japanese ancestry away from the west coast, on January 2, 1945. The last camp, Tule Lake, closed on March 20, 1946. Endo moved to Chicago in May 1945 and worked as a secretary for the Mayor's Committee on Race Relations. She married Kenneth Tsutsumi, raised three children and died in Chicago on April 14, 2006.

### Fred Korematsu

> **Who:** A welder who refused to leave his home when Japanese Americans were ordered out, lost at the Supreme Court, and had his conviction thrown out in 1983.
>
> **When and where:** Oakland, California, 1942. San Francisco, 1983.

**"If anything, I should be pardoning the government."**

Fred Korematsu was born in Oakland, California, on January 30, 1919, and named Toyosaburo. A teacher suggested he call himself Fred. His parents, Kakusaburo and Kotsui, ran the Stonehurst Flower Nursery in East Oakland.

**Staying behind.** When the orders came in 1942, his family went to the camps and he did not. He was 23. He had a girlfriend, Ida Boitano, and a job as a welder. He got identification papers in a false name, Clyde Sarah, and kept working. Police stopped him and his girlfriend on a street in San Leandro, California, on May 30, 1942, and arrested him. The charge was breaking Civilian Exclusion Order No. 34, the Army's order for people of Japanese ancestry to leave his area.

**The case.** Ernest Besig, a lawyer with the American Civil Liberties Union, visited him in the Army stockade, a military jail, at the Presidio in San Francisco and asked to take his case to the higher courts. Korematsu agreed. A federal judge found him guilty and gave him five years' probation, which meant he stayed free under a court's watch. Then Army officers sent him to the Tanforan racetrack on June 28, 1942, and to the Topaz camp with his family that September.

The justices of the Supreme Court heard his case on October 11, 1944, and ruled against him on December 18, 1944. After he left the camp, he moved to Detroit and married Kathryn Pearson. They came back to California and raised two children.

**The hidden reports.** In the early 1980s, a team of lawyers who worked without pay found that the government's own lawyers had hidden evidence from the Supreme Court. Intelligence reports had told them that Japanese Americans were no military threat, and they had kept those reports out of the case. The team reopened his case.

Judge Marilyn Hall Patel ruled on November 10, 1983, in the same San Francisco courthouse where he had been found guilty, 39 years after the Supreme Court's ruling. She wrote that "the conviction that was handed down in this court and affirmed by the Supreme Court in *Korematsu v. United States* is ... vacated," or cancelled, "and the underlying indictment," the criminal charge against him, "dismissed."

About a pardon, a president's official forgiveness of a crime, he said, "I don't want a pardon. If anything, I should be pardoning the government." He received the Presidential Medal of Freedom in 1998 and died at Larkspur, California, on March 30, 2005, aged 86. In California, January 30 is Fred Korematsu Day.

### Elizabeth Peratrovich and the Alaska law, 1945

Alaska's lawmakers approved the Alaska Anti-Discrimination Act on February 16, 1945, after the Tlingit leader Elizabeth Peratrovich spoke for it before them. Alaska was then a territory, land ruled by the United States that was not yet a state. The act was the first law against discrimination in the United States or its territories. Signs such as "No Natives Allowed" hung in Alaska, and the lawmakers wrote the act against them.

Peratrovich belonged to the Lukaax.ádi clan of the Tlingit. For half a century the Alaska Native Brotherhood, founded at Sitka in 1912, and the Alaska Native Sisterhood, founded in 1915, were the only civil rights groups for Alaska Natives. In Alaska, February 16 is Elizabeth Peratrovich Day every year.

### A soldier blinded on his way home, and the president's committee, 1946

Sergeant Isaac Woodard was discharged from the Army after four years on February 12, 1946, and took a bus home to South Carolina. After he argued with the bus driver, police at Batesburg, South Carolina, took him off the bus. Police Chief Lynwood Shull and Officer Elliot Long beat him with blackjacks, short heavy clubs. Woodard said they tried to gouge out his eyes, to dig them out. A local judge fined Woodard himself $50.

**Blind.** At the veterans' hospital in Aiken, doctors found bleeding inside both of his eyeballs and a torn cornea, the clear front of the eye, in his right eye. He was blind for the rest of his life. Justice Department lawyers charged Shull with breaking Woodard's civil rights. In November 1946 an all-white federal jury took thirty minutes to find Shull not guilty.

**The president.** Walter White of the NAACP led a group to see President Harry Truman on September 19, 1946, and told him what had been done to Woodard. "My God! I had no idea that it was as terrible as that! We've got to do something!" Truman said. He signed Executive Order 9808 on December 5, 1946, which set up the President's Committee on Civil Rights. The committee's report, *To Secure These Rights*, came out in 1947.

**If you remember one thing:** Organizers in these fifty years invented the picket line, the sit-in, the threatened march and the planned chain of court cases, while mobs and officials burned, jailed, sterilized and removed the people they targeted.

**In 1900:** Representative George Henry White brought the first federal bill against lynching to Congress, and it failed.

**In 1950:** Women had the vote under the Constitution, Native Americans could vote in every state but Utah, and NAACP lawyers had won their first law school cases. Congress had still passed no law against lynching.

**Next:** After 1950, the court cases reached the public schools, and the marches filled the streets.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 55 minutes**

Five groups of Americans ran organized campaigns after 1950: Black Americans, women, Mexican Americans, gay Americans and disabled Americans. Each group won changes in the country's laws. The justices of the Supreme Court ruled in 1954 that segregated public schools broke the Constitution, and in 1956 they struck down segregation on Montgomery's buses. Members of Congress then passed new laws.

In the Civil Rights Act of 1964 they made segregation in businesses and public places illegal. Later they banned literacy tests for voting in 1965, sex discrimination in schools that took federal money in 1972, and refusing a disabled person a job or a way into a public building in 1990. A literacy test was a reading and writing test that officials used to keep Black citizens from voting.

**The cost.** Each of those changes followed years of organizing, and the organizers paid for it. People who signed lawsuits lost their jobs, police beat marchers with nightsticks, and firemen turned high-pressure hoses on children. Members of the Ku Klux Klan, a secret white group that used terror against Black Americans, killed four girls with a bomb in a Birmingham church in 1963.

The next year, white men in Mississippi killed three civil rights workers, and a Neshoba County deputy sheriff was among the men later found guilty over it. Civil rights are the rights every citizen has to equal treatment under the law and to vote.

An Alabama state trooper shot Jimmie Lee Jackson in 1965. Doctors operated on Black women such as Fannie Lou Hamer, and on poor girls, without asking them, so that they could never have children. Federal officials fired thousands of gay people from government jobs.

### The law school cases, 1950

NAACP lawyers following the plan Charles Hamilton Houston made in the 1930s won two more cases in June 1950, six weeks after he died. The justices of the Supreme Court decided both cases on June 5, 1950, and all of them agreed on both.

**Heman Sweatt.** Heman Marion Sweatt had applied to the University of Texas Law School in February 1946, and university officials turned him away because he was Black. Texas officials then opened a separate law school for Black students in Austin in February 1947. Its four teachers were part-timers borrowed from the university, and it had no full-time librarian. About 10,000 books were on order, and few had arrived. No body of lawyers had approved it as a real law school.

Chief Justice Fred Vinson wrote that the education it offered was not "substantially equal" to what Sweatt would get at the university. "Equal protection of the laws is not achieved through indiscriminate imposition of inequalities," he wrote. A state could not call it equal treatment to give Black students something worse. The justices ordered Texas officials to admit Sweatt.

**George McLaurin.** George W. McLaurin already had a master's degree and wanted a doctorate in education. University of Oklahoma officials let him in and then made rules for him alone, and the justices' written opinion lists them.

He "was required to sit apart at a designated desk in an anteroom adjoining the classroom," a desk set aside for him in a small room next to the classroom. He had to sit at an assigned desk on the library's upper floor, "but not to use the desks in the regular reading room."

In the cafeteria he had "to sit at a designated table and to eat at a different time from the other students." Before the case was argued, university officials eased the rules a little. McLaurin could sit in a marked row in the classroom and eat at the usual hours, still at a table of his own. The justices struck down the whole arrangement.

### What signing cost in Clarendon County, 1949 and 1950

In Clarendon County, South Carolina, 107 Black parents and children signed a petition against the county's schools. For it, employers fired them, merchants refused to sell to them and lenders turned them down for loans.

**One bus.** School District 22 ran more than 30 school buses for white children and none for Black children, and the parents began by asking for one bus. The court record describes the all-white Summerton High School as "modern, safe, sanitary, well equipped, lighted and healthy." It describes the Black schools as "inadequate…unhealthy…old and overcrowded and in a dilapidated condition," falling apart.

The Reverend Joseph A. DeLaine, a minister and teacher, brought the NAACP together with the Pearson brothers to start the case. Six white men later attacked DeLaine. He got away by pretending he had a gun in his pocket and jumping into the passing truck of another man who had signed.

**The signers.** The petition went round for signatures on November 11, 1949, and the parents' lawyers filed the lawsuit on May 16, 1950. It is named for Harry Briggs, whose name was first on the list. A National Park Service page records what happened to the signers. They were "fired from their jobs, denied service when trying to purchase supplies for their farms, or being turned down for loans on their properties."

### Barbara Rose Johns

> **Who:** A sixteen-year-old who led her whole school out on strike, three years before *Brown*.
>
> **When and where:** Farmville, Prince Edward County, Virginia, April 23, 1951.

**A fake phone call got the principal out of the building.**

Barbara Rose Johns was a student at Robert Russa Moton High School in Farmville, the high school for Black students in Prince Edward County, Virginia. The building had been made for 180 students, and it held between 360 and 450.

Classes met in the auditorium, in school buses and in three wooden sheds wrapped in tar paper, which people compared to chicken coops. The school had no cafeteria, no science laboratory and no gym. One day a half-empty school bus for white children passed her without stopping, and she decided to act.

**The strike.** A student named John Watson telephoned the principal's office on April 23, 1951, and disguised his voice. He said Moton students were making trouble at the bus station downtown. The principal, M. Boyd Jones, left to see. While he was gone, the strike Johns led began, and the students stayed out of class for two weeks.

**The lawyers' condition.** She wrote to two NAACP lawyers in Richmond, Oliver W. Hill and Spottswood William Robinson III. They agreed to take the case on one condition: the parents had to sue to end segregation itself, rather than ask for a better Black school. The Reverend L. Francis Griffin called the parents to a meeting at the First Baptist Church in Farmville on May 3, 1951, to hear the offer, and they agreed.

On May 23, 1951, 74 parents filed the lawsuit, *Davis v. County School Board of Prince Edward County*, for 118 Moton students. It became one of the five cases the justices of the Supreme Court decided as *Brown v. Board of Education*.

Her parents sent her out of the county. She finished her last year of high school in Montgomery, Alabama, living with her uncle, the Reverend Vernon Johns, and his wife, Altona. Her family's house in Prince Edward County later burned down, and the family believed someone had set the fire. Barbara Rose Johns died of bone cancer in Philadelphia on September 25, 1991, aged 56.

### Brown v. Board of Education, May 17, 1954

All nine justices of the Supreme Court ruled on May 17, 1954, in *Brown v. Board of Education of Topeka*, that separating children by race in public schools broke the 14th Amendment and its promise of "the equal protection of the laws." Chief Justice Earl Warren wrote, "Separate educational facilities are inherently," or by their very nature, "unequal."

With that ruling, the justices rejected the reasoning of *Plessy v. Ferguson* for public schools, 58 years after that case. In *Plessy*, in 1896, the justices had allowed a Louisiana law that kept Black and white train passengers apart in "equal but separate" cars.

*Brown* was five lawsuits that the justices bundled together. They were *Brown v. Board of Education* from Topeka, Kansas, *Briggs v. Elliott* from Clarendon County, South Carolina, *Davis v. County School Board* from Prince Edward County, Virginia, *Belton v. Gebhart* from Delaware, and *Bolling v. Sharpe* from Washington, D.C.

### Rosa Parks and Martin Luther King Jr.

> **Who:** The NAACP branch secretary whose arrest set off the Montgomery bus boycott, and the 26-year-old minister the boycotters chose to lead it.
>
> **When and where:** Montgomery, Alabama, December 1955 to December 1956.

**The Women's Political Council printed 50,000 leaflets after her arrest.**

Rosa Parks had been the secretary of the Montgomery NAACP for twelve years on the day she was arrested for keeping her bus seat. In the early 1940s she started the branch's Youth Council. As secretary of the NAACP's Alabama State Conference, she traveled the state interviewing victims of discrimination and witnesses to lynchings. She had broken the bus seating rules many times before, and a driver had once put her off a bus for it.

**Claudette Colvin.** Nine months before Parks's arrest, on March 2, 1955, a fifteen-year-old student named Claudette Colvin refused to give up her seat on a Montgomery bus when white passengers got on. She told police she had a right under the Constitution to sit anywhere on the bus, as white passengers did. The officers swore at her, hit her with a nightstick and dragged her off the bus.

E. D. Nixon, a Montgomery organizer, and others decided not to build a campaign around her case. Nixon thought she was too young. When she became pregnant later that year, he looked for someone who fit the strict customs of the time. Colvin believed the choice also had to do with her family's standing outside Montgomery's Black middle class.

**The boycott.** Police arrested Rosa Parks on December 1, 1955, for refusing to give up her bus seat. The Women's Political Council, a group of Black professional women formed in 1949, had already been pressing white city officials about the buses. Jo Ann Robinson of the council had proposed a boycott, a refusal to use or buy something as a protest, more than a year before. After Parks's arrest, council members printed 50,000 leaflets calling for a one-day boycott on Monday, December 5.

After that Monday, Black riders stayed off the buses. The same day, Montgomery's Black ministers and organizers formed the Montgomery Improvement Association and elected Martin Luther King Jr. as its president. He was 26, the pastor of Dexter Avenue Baptist Church, and still finishing his doctorate at Boston University. About 40,000 Black people lived in Montgomery, and for a year most of them walked to work or school, shared cars, took taxis or hitchhiked.

**The bombs.** City leaders had nearly 100 of the boycott's leaders charged with conspiracy, the crime of planning together to break the law. Someone bombed King's house on January 30, 1956, while his wife, Coretta Scott King, their seven-week-old daughter, Yolanda, and a neighbor were inside. No one was hurt, and no one was ever charged with a crime for the bombing. On February 1 a bomb went off in E. D. Nixon's yard.

**Four other women.** Four other women brought the lawsuit that ended bus segregation in Montgomery. The lawyer Fred Gray filed *Browder v. Gayle* on February 1, 1956, for Aurelia Browder, Susie McDonald, Mary Louise Smith and Claudette Colvin, then sixteen. Federal judges in Montgomery struck down Alabama's bus segregation laws in June 1956, and in November the justices of the Supreme Court agreed. Black riders went back on the buses on December 21, 1956.

Colvin later worked as a nurse's aide in New York for fifty years. A judge erased her 1955 arrest record on December 16, 2022, and she died on January 13, 2026, aged 86. Rosa Parks lost her job as a tailor and received death threats. She and Raymond Parks moved to Detroit in 1957. She worked in the office of Representative John Conyers from 1965 to 1988, and she died in Detroit on October 24, 2005.

**Memphis.** King led the movement for twelve more years and won the Nobel Peace Prize in 1964, at 35. He went to Memphis, Tennessee, twice in 1968 to support 1,300 Black sanitation workers on strike. On February 1, 1968, two of them, Echol Cole and Robert Walker, had been crushed to death in the compactor of their garbage truck. The strikers carried signs that read "I AM A MAN."

King was shot in Memphis on April 4, 1968, and died at 7:05 that evening at St. Joseph's Hospital. He was 39. After his death, city officials recognized the workers' union.

**Disputed:** Who was behind the killing. James Earl Ray pleaded guilty to King's murder in March 1969, and a judge sentenced him to 99 years. For the rest of his life Ray tried to take back his plea, until he died in April 1998. In 1999 the King family brought a civil case, a lawsuit rather than a criminal trial, against a Memphis man named Jowers.

The jury found that Jowers and "others, including government agencies" had plotted the killing. In 2000 Justice Department investigators reported that they found those claims not believable.

**By 1956:** The Supreme Court's justices had ruled segregated public schools unconstitutional, and Black riders in Montgomery had stayed off the buses for more than a year until the justices struck down bus segregation there too.

### After Brown: Little Rock, Prince Edward County and New Orleans, 1957 to 1964

After *Brown*, Black families still had to force their way into white schools one district at a time, and white officials fought them with new city rules and by shutting down public schools.

**Little Rock.** Nine Black students entered Central High School in Little Rock, Arkansas, in 1957. Daisy Bates organized them. She was president of the Arkansas State Conference of the NAACP, and with her husband, L. C. Bates, she published a newspaper, the *Arkansas State Press*. The nine students met at her house every school day and left for Central High from there.

A rock came through her living room window in August 1957 with a note tied to it: "STONE THIS TIME. DYNAMITE NEXT." Twice, people burned crosses in her front yard, and someone fired shots into the house from a passing car. The National Park Service's page on the Bates home does not name the people who did it.

**The membership lists.** Members of the city councils of Little Rock and North Little Rock then passed rules that made every organization hand its list of members to the city clerk, to be made public. Daisy Bates kept the records of the Little Rock branch of the NAACP. She refused to hand over the list, and she was found guilty in court for refusing.

The justices of the Supreme Court threw out that verdict on February 23, 1960. Justice Potter Stewart wrote that keeping a group's members private "may in many circumstances be indispensable to preservation of freedom of association, particularly where a group espouses dissident beliefs." People have a right to join a group without officials forcing the group to name its members. Dissident beliefs go against those of the people in power.

**Prince Edward County.** Prince Edward County, Virginia, was home to the Moton students' case. Members of the county's board of supervisors voted on June 26, 1959, to stop paying for public schools, and the county had no public schools until September 8, 1964. White children went to a private school, Prince Edward Academy. About 2,000 Black children went without formal schooling for five years.

Attorney General Robert F. Kennedy said in 1963 that "the only places on earth not to provide free public education are Communist China, North Vietnam, Sarawak, Singapore, British Honduras." Then he added, "and Prince Edward County, Virginia."

The justices of the Supreme Court decided a case brought by Black schoolchildren of the county, the first of them named Cocheyse J. Griffin, on May 25, 1964. Closing the county's schools, while every other county in Virginia kept its schools open, denied the children "the equal protection of the laws," they ruled. A federal judge could make the supervisors raise taxes to reopen the schools.

**New Orleans.** A federal judge, J. Skelly Wright, ordered New Orleans school officials to start letting Black children into white schools in the spring of 1960. Four Black six-year-old girls went into two white schools on November 14, 1960. Ruby Bridges went alone into William Frantz Elementary. Leona Tate, Tessie Prevost and Gail Etienne went together into McDonogh 19, in the Lower Ninth Ward, with federal marshals, officers who work for the federal courts, walking them in.

White parents took their children out. By the end of the month, fewer than ten white children attended the two schools combined. From January to May 1961, Ruby Bridges was the only pupil at William Frantz.

### Levittown, 1957: a family moves in

Levittown, Pennsylvania, was a town of houses built and sold by one builder, William Levitt. Daisy and William Myers became the first Black family to live there in August 1957, and white mobs gathered outside their home for nearly three months. William Myers was an Army veteran of the Second World War, and Daisy Myers was a teacher. They had three young children.

**The lease.** In the first Levittown, in New York, the standard lease had barred anyone "other than members of the Caucasian race," meaning anyone who was not white, from living in a house. The lease included one exception: servants who were not white could live in a house if they worked for the white family there.

The justices of the Supreme Court ruled in *Shelley v. Kraemer* in 1948 that no court could enforce clauses like that, so no judge could order anyone to obey them. Levitt dropped the written clause and kept selling only to white buyers.

**The mobs.** When the Myers family moved in, mobs gathered outside the house. People threw rocks through the windows, burned crosses and made death threats by telephone. Delivery men stopped bringing milk, bread and heating oil, and state police guarded the house. A documentary, *Crisis in Levittown*, was filmed while it was happening, in 1957. Daisy Myers later wrote a book about it, *Sticks 'n Stones*, published in 2005.

### Sit-ins and Freedom Rides, 1960 and 1961

Black and white students used their own bodies to test segregation in 1960 and 1961, first at lunch counters and then on buses.

**Greensboro.** Four freshmen from the Agricultural and Technical College of North Carolina walked into the Woolworth store in Greensboro on February 1, 1960. Franklin McCain, Joseph McNeil, David Richmond and Ezell Blair Jr. sat at the lunch counter, which was for white customers only, ordered coffee and waited. The waitress and the manager ignored them. A police officer walked up and down behind them. Some white customers shouted at them, and others encouraged them.

The next day 19 students came. The day after that 85 came, from several colleges. Before the week was out there were 400, taking turns so they could still go to class. Students started sit-ins in seven other North Carolina cities and in Hampton, Virginia, and Nashville, Tennessee.

Woolworth's managers opened the Greensboro counter to Black customers on July 25, 1960. By that summer, restaurants and lunch counters in 33 Southern cities served Black customers, and a year later those in 126 cities did.

**The Freedom Riders.** The justices of the Supreme Court struck down Virginia laws that required segregation in travel between states in *Boynton v. Virginia* in 1960. Leaders of the Congress of Racial Equality, known as CORE, organized riders to find out whether the people running bus stations in the South would obey.

The first thirteen Freedom Riders, Black and white, left Washington, D.C., on May 4, 1961, in two groups, one on a Greyhound bus and one on a Trailways bus. A National Park Service page gives the number as eleven.

**Anniston.** A white mob that included members of the Ku Klux Klan attacked the Greyhound bus at Anniston, Alabama, on May 14, 1961. They slashed its tires, followed it out of town and firebombed it. The riders were trapped on the burning bus. They got out after an explosion, and then the mob beat them. The Reverend Fred Shuttlesworth organized a line of cars and got them to Birmingham within a few hours.

A photographer, Joe Postiglione, took pictures of the bus as it burned. Charles Person, one of the Freedom Riders, later wrote that the photograph appeared "on front pages of newspapers across the country and the world." Accounts name different men as the mob's leaders. No record shows that anyone went to prison for burning the bus.

The same day, young white men climbed onto the second bus, the Trailways bus, at Anniston and beat the riders until they moved into segregated seats. One of the riders they beat was Walter Bergman, a white man. The Encyclopedia of Alabama states that he suffered permanent brain damage.

**Birmingham.** When that bus reached Birmingham, a crowd armed with pipes, chains and baseball bats met it, and many of the men in it belonged to the Klan. Bull Connor, Birmingham's public safety commissioner, had told Klan leaders that his police would hold back from the station for 15 minutes, and he encouraged the Klan to attack the riders.

With no police there, Klansmen beat the riders in the waiting room and in a dark hallway. They beat James Peck, a white rider, until he was unconscious, with heavy wounds to his face and head. Staff at a hospital for white people only refused to treat him, and doctors at Jefferson Hillman Hospital closed his wounds with 53 stitches. In the historian Raymond Arsenault's account, Bergman was beaten for the second time that day. Over the summer of 1961 the number of Freedom Riders grew to more than 400.

### Fannie Lou Hamer

> **Who:** A plantation timekeeper in Mississippi who tried to register to vote, lost her job the same day, was beaten in a jail for her organizing, and told the country about it on national television.
>
> **When and where:** Ruleville, Sunflower County, Mississippi, 1962 and 1963. Atlantic City, New Jersey, August 22, 1964.

**"I question America," she told the country on television.**

Fannie Lou Hamer was the youngest of the twenty children of Ella and James Lee Townsend. She began working in the cotton fields at six, weeding first and then picking. In 1944 she married Perry Hamer, whom people called Pap. For eighteen years she worked on the W. D. Marlow plantation outside Ruleville, keeping the time records for the other workers.

**The operation.** She went into a hospital in 1961, and a doctor performed a hysterectomy on her without asking her or telling her. A hysterectomy is an operation that cuts out the womb, the organ in which a baby grows. After it, a woman can never become pregnant, and it cannot be undone.

Hamer called operations like hers a "Mississippi appendectomy," after the ordinary operation that takes out the appendix, a small part of the gut, and her name for them came into use. The Mississippi Department of Archives and History's account of her life does not name the surgeon.

**Registering.** She and seventeen others went 26 miles to the Sunflower County courthouse in Indianola to register to vote on August 31, 1962. Police let only two of them in to take the literacy test. Registrars, the officials who signed people up to vote, used that test to turn Black voters away.

That evening the plantation owner told her, "If you don't go down and withdraw your registration, you will have to leave." She answered, "I didn't try to register for you. I tried to register for myself." She lost her job that day. On September 10 someone fired sixteen bullets into the Tucker family's house in Ruleville, and other houses were shot at the same night.

**Winona.** She was one of ten people coming home by Continental Trailways bus from a voter registration workshop on June 9, 1963. At the bus station in Winona, Mississippi, some of the group tried to use the restaurant and the washroom. Winona's police chief, Thomas Herrod, ordered them arrested.

In the jail, state highway patrolmen made two Black prisoners, Roosevelt Knox and Sol Poe, beat her with a blackjack. The patrolmen ordered her to lie face down on a bunk. The first prisoner beat her until he was exhausted. Then the patrolman gave the blackjack to the second prisoner and made the first one sit on her feet so she could not move them.

"I began to scream and one white man got up and began to beat me in my head and tell me to hush," she said. The officers also had June Johnson, who was fifteen, and Annell Ponder beaten. Hamer lost the sight of one eye and had kidney damage for the rest of her life. "After I got out of jail, half dead, I found that Medgar Evers had been shot down in his own yard," she said.

Federal prosecutors tried five white Winona and Montgomery County officers, among them Chief Herrod, in December 1963 for violating the prisoners' civil rights. An all-white, all-male jury found them not guilty on every count.

**Atlantic City.** Mississippi's delegation to the 1964 Democratic National Convention, the group of people the state party sent to vote at the national party's meeting, was all white. Hamer and others founded the Mississippi Freedom Democratic Party, and in August 1964 they went to the convention in Atlantic City to ask to be seated in its place. She was the group's vice chair.

On August 22 she told the convention's credentials committee, the group that decided which delegates could take their seats, what had been done to her. Television carried it across the country. A National Archives page records that her testimony "was interrupted by President Lyndon Johnson, in an effort to suppress the truth and stabilize the Democratic Party."

She ended, "All of this is on account of we want to register, to become first-class citizens. And if the Freedom Democratic Party is not seated now, I question America. Is this America, the land of the free and the home of the brave, where we have to sleep with our telephones off the hooks because our lives be threatened daily, because we want to live as decent human beings, in America?"

She started the Freedom Farm in 1969 to grow food and give families in Sunflower County a living. She used to say, "Nobody's free until everybody's free." She died on March 14, 1977, at 59, of heart failure brought on by cancer, diabetes and high blood pressure. Writers at the Equal Justice Initiative state that the kidney damage from the beating helped cause her death.

**By 1962:** Students had sat in at lunch counters across the South, Klansmen had burned a Freedom Riders' bus and beaten the riders, and Fannie Lou Hamer had lost her job for trying to register to vote.

### Birmingham, 1963: the children and the church

Birmingham, Alabama, police arrested hundreds of Black children for marching against segregation in May 1963, and firemen turned hoses on them. That September, members of the Ku Klux Klan killed four girls with a bomb at the church the marches had started from.

**The children's march.** Students aged eight to eighteen gathered at the 16th Street Baptist Church on May 2, 1963, and marched downtown to ask the mayor to end segregation. On the orders of Bull Connor, the public safety commissioner, police arrested them. National Park Service pages give two counts for that day. One says 600 children were arrested, some as young as six, and another says 1,200. By the next day at least 1,000 children were in jail, and over the following days Connor's police jailed more than 3,000 demonstrators.

**Hoses and dogs.** Connor ordered fire hoses and police dogs turned on the marchers on May 3. A National Park Service page describes it: "Firemen blasted the protestors, including children, with high-pressure fire hoses, and police used their nightsticks indiscriminately," without caring whom they hit. "Police K-9 units loosed their dogs into crowds of peaceful demonstrators, pinning down one woman and severely wounding three teenagers." These were the hoses firemen used on burning buildings, and the water came out hard enough to knock people off their feet.

**The bomb.** A bomb went off under the steps of the 16th Street Baptist Church just before 11 in the morning on Sunday, September 15, 1963. It killed four girls: Addie Mae Collins, Carole Robertson and Cynthia Wesley, who were fourteen, and Denise McNair, who was eleven.

A few minutes before, they had been together in the basement women's room in their Sunday clothes, ready to sing and to show people to their seats at the adult service, talking about the new school year. Addie Mae's sister, Sarah, survived and lost her right eye.

**The bombers.** The bombers were members of the Ku Klux Klan. FBI agents named Robert Chambliss as their main suspect. FBI Director J. Edgar Hoover closed the investigation in 1968 without charging anyone and ordered the evidence sealed. Investigators reopened the case after Hoover died in 1972.

Juries later found three of the bombers guilty: Chambliss on November 14, 1977, fourteen years after the bombing, Thomas Blanton on May 1, 2001, and Bobby Frank Cherry in 2002, 39 years after it. Chambliss died in prison in 1985. Blanton was given four life sentences and died in prison in 2020. A fourth Klansman, Herman Cash, died in 1994 without being tried.

### Organizers killed in Mississippi, 1963 and 1964

White men in Mississippi killed civil rights organizers in 1963 and 1964, and for decades no jury in the state found anyone guilty of murder for it.

**Medgar Evers.** Medgar Evers was born at Decatur, Mississippi, on July 2, 1925, and fought in Germany and France in the Second World War. From 1954 he was the NAACP's field secretary for the state of Mississippi. He led marches, prayer vigils, boycotts and drives to register voters, and he worked to get James Meredith admitted to the University of Mississippi in 1962.

Byron De La Beckwith, a member of the White Citizens' Council, shot Evers in the back in the driveway of his home in Jackson in the early hours of June 12, 1963. The Citizens' Council was a group founded in Mississippi in 1954, after *Brown*, to keep segregation in place. Evers's wife, Myrlie, and their children had waited up for him and were watching television. When they heard the shot, the children did what they had practiced: they dropped to the floor and crawled to the bathroom.

Myrlie found her husband collapsed and bleeding, still holding the T-shirts he had carried in from the car. He died at University Hospital from his wounds and loss of blood. Beckwith was tried twice in 1964, and both juries failed to agree on whether he was guilty. A jury found him guilty on February 5, 1994, 31 years and three trials after the killing, and the judge sentenced him to life in prison. He died on January 21, 2001, aged 80.

**Freedom Summer.** Volunteers came to Mississippi in the summer of 1964 to register Black voters and run summer schools of their own, called Freedom Schools. It was called Freedom Summer. On June 21, 1964, three of the workers went to look at a Black church that had been burned after a civil rights meeting was held there.

James Chaney, 21, was a Black college student from Mississippi. Andrew Goodman, 20, and Michael Schwerner, 24, were white New Yorkers working with CORE. Local police arrested the three for "speeding" and held them in jail. The National Archives records that they were "released after dark into the hands of the Ku Klux Klan."

Searchers found their bodies near Old Jolly Farm in Neshoba County on August 4, 1964. Goodman and Schwerner had each been shot once in the head. Chaney had two broken arms, a broken jaw, a crushed right shoulder and injuries to his groin.

**The trials.** Twenty-one men were arrested. A federal jury found seven of the eighteen men on trial guilty of violating the three workers' civil rights on October 20, 1967. They included Cecil Price, the Neshoba County deputy sheriff, and Samuel Bowers, the imperial wizard, or top leader, of the White Knights of the Ku Klux Klan of Mississippi. Their sentences ran from three to ten years.

One juror would not vote to find Edgar Ray Killen guilty. Killen was a former preacher and Klan leader who had organized the killings. A Mississippi jury found Killen guilty of manslaughter on June 21, 2005, 41 years to the day after the killings. He was sentenced to 60 years and died in the state prison at Parchman on January 11, 2018.

### The March on Washington, August 28, 1963

About 250,000 people came to Washington on August 28, 1963, for the March on Washington for Jobs and Freedom. A National Park Service page counts about 190,000 of them as Black and about 60,000 as white. A. Philip Randolph, who had threatened a march on Washington in 1941 and called it off, led this one. Bayard Rustin organized it in less than three months.

**All men.** All ten of the march's sponsors were men. Besides Randolph, they included Martin Luther King Jr., John Lewis of the Student Nonviolent Coordinating Committee, the heads of three other civil rights groups and four other men, among them the union leader Walter Reuther. Dorothy Height of the National Council of Negro Women helped plan the march, and the Park Service page states that she "operated in the background of this male dominated, leadership group." No woman gave a formal speech.

**The day.** The marchers walked the mile-long National Mall to the Lincoln Memorial, where civil rights and religious leaders spoke for three hours. The sponsors issued ten demands, among them fair wages, fair hiring and desegregated schools. The Park Service page records that John Lewis's speech was "toned down...at the request of white liberals and moderate black allies," people on his own side who asked him to say it more softly. What he said included, "we do not want our freedom gradually but we want to be free now."

**King's speech.** The National Archives calls King's speech, known as "I Have a Dream," the high point of the march. He told the crowd that he dreamed his four little children would one day live in a nation where they "will not be judged by the color of their skin but by the content of their character."

**The law that followed.** In 1964, Southern senators kept talking for 60 working days so that no vote could be held on a civil rights bill. On June 10, enough senators voted to end the talking, the first time that had happened on a civil rights bill, and nine days later they passed it, 73 to 27. President Lyndon Johnson signed the Civil Rights Act on July 2, 1964.

Under the act, segregation became illegal in businesses such as theaters, restaurants and hotels, and in public places such as swimming pools, libraries and public schools. Job discrimination became illegal too. A Government Publishing Office page states that this act and the Voting Rights Act of 1965 "reflected the demands of the march."

### Bayard Rustin

> **Who:** The organizer who planned the March on Washington in under three months, and who was found guilty in a California court in 1953 for having sex with men.
>
> **When and where:** Born at West Chester, Pennsylvania, March 17, 1912. Los Angeles, 1953. Washington, D.C., 1963.

**California's governor pardoned him 33 years after he died.**

Bayard Rustin was raised a Quaker in a family already doing civil rights work, and he was a pacifist all his life, a person who refuses to take part in war or violence. In 1942, in California, he visited Japanese Americans held at the Manzanar camp and reported on the conditions there.

**The first Freedom Ride.** He and George Houser organized the Journey of Reconciliation in 1947, a bus trip to test a Supreme Court ruling against racial discrimination in travel between states. A National Park Service page calls it the first of the Freedom Rides. Police arrested Rustin for breaking a state law on segregated seating, and he served 22 days on a chain gang.

**Los Angeles, 1953.** He was found guilty of vagrancy in the Los Angeles County Superior Court on January 22, 1953. Vagrancy is a crime that means wandering with no job or home. What he had done was have sex with other men who agreed to it. The judge sentenced him to 60 days in jail and ordered him to register as a sex offender, which put his name on California's list of people found guilty of sex crimes.

California's governor wrote in 2020 that "Mr. Rustin was sentenced pursuant to a charge commonly used to punish gay men for engaging in consensual adult sexual conduct," sex that both adults agreed to. The same document says his conviction caused "an injustice that was compounded by his political opponents' use of the record of this case to try to undermine him, his associates, and the civil rights movement."

**The march.** He taught Martin Luther King Jr. how to practice nonviolent resistance, and he worked for years with A. Philip Randolph. Randolph made him deputy director of the March on Washington, and Rustin planned the whole of it.

He died in New York City on August 24, 1987, of a burst appendix, aged 75. President Barack Obama awarded him the Presidential Medal of Freedom on August 8, 2013, and called him "an unyielding activist for civil rights, dignity, and equality for all." Governor Gavin Newsom of California pardoned him on February 4, 2020, an official forgiveness of the crime. In the same order, Newsom told his office to find and pardon other people who had been arrested and charged for sex between adults who agreed to it.

### Two men climb the Gateway Arch, 1964

Percy Green and Richard Daly climbed 125 feet up the unfinished north leg of the Gateway Arch in St. Louis, Missouri, on July 14, 1964. They were protesting the fact that Black workers were kept out of the jobs building it. Green belonged to CORE and later founded a group called ACTION.

**By 1964:** About 250,000 people had marched on Washington, Klansmen had killed four girls in a Birmingham church and three civil rights workers in Mississippi, and Fannie Lou Hamer had told her story on national television.

### Selma and the Voting Rights Act, 1965

Marchers in Selma, Alabama, campaigned for the right to vote in 1965, and state troopers, other officers and Klansmen attacked them. The 15th Amendment had barred states from denying the vote because of race since 1870, and yet in much of the South officials still used literacy tests to keep Black citizens from registering.

**Jimmie Lee Jackson.** State Trooper James Bonard Fowler shot Jimmie Lee Jackson in the stomach inside a cafe in Marion, Alabama, during a march for voting rights on February 18, 1965. Jackson was 26 and had been protecting his mother and grandfather. He died of an infection from the wound on February 26. Fowler was charged with murder in May 2007. In 2010 he pleaded guilty to misdemeanor manslaughter, a minor charge, and served five months of a six-month sentence.

**Bloody Sunday.** About 600 people, most of them Black, walked out of Brown Chapel in Selma on Sunday, March 7, 1965, to march to Montgomery, the state capital. At the Edmund Pettus Bridge, Major John Cloud of the Alabama State Troopers gave them two minutes to turn back. Then state troopers and other officers attacked them "with nightsticks and teargas," in the National Park Service's words. At least 50 marchers needed hospital care. The day is called Bloody Sunday.

**James Reeb.** About 2,000 people marched again on March 9, led by King. The marchers turned back at the bridge, and the day is called Turnaround Tuesday. That evening four men attacked three ministers outside a restaurant in Selma. One of the attackers hit the Reverend James Reeb of Boston in the head with a club, and Reeb died two days later.

Elmer L. Cook, William Stanley Hoggle and Namon O'Neil Hoggle were tried for his murder, and the jury found all three not guilty on December 10, 1965. The prosecutor had allowed a man whose brother was a suspect in the attack to sit on the jury.

**Viola Liuzzo.** The march set out again on March 21, 1965, with more than 8,000 people, and by the time it reached the capitol in Montgomery on March 25 the crowd had grown to nearly 25,000. That night, Viola Liuzzo was driving on Highway 80 between Selma and Montgomery. She was a 39-year-old white mother of five from Detroit who had come to help. In Lowndes County, four members of the Ku Klux Klan fired into her car and killed her. Her passenger, Leroy Moton, a 19-year-old Black volunteer, survived.

The four men were Collie Leroy Wilkins Jr., William Orville Eaton, Eugene Thomas and Gary Thomas Rowe. Rowe was a paid FBI informant, a person who secretly passed information to the FBI, and prosecutors promised not to charge him. Alabama juries did not find the other three guilty. A federal jury found them guilty of violating her civil rights, and the judge sentenced each to ten years.

FBI Director J. Edgar Hoover called Liuzzo an "outside agitator" and spread rumors about her to the press. Her family sued the FBI in 1979, and a federal judge dismissed the suit in 1983.

**The Voting Rights Act.** President Lyndon Johnson signed the Voting Rights Act on August 6, 1965. It banned literacy tests, and federal officials sent examiners into the places that had used them, with the power to sign up voters themselves. States and counties on the act's list had to get approval from federal officials in Washington before changing any voting rule.

By the end of 1965, a quarter of a million new Black voters had registered, a third of them through the federal examiners. By the end of 1966, only four of the thirteen Southern states still had fewer than half of their Black citizens registered.

### The Chicano movement, 1954 to 1970

Mexican Americans ran their own rights campaigns from the 1950s. Many called themselves Chicanos, and their campaigns the Chicano movement.

**Hernandez v. Texas.** They won a case at the Supreme Court in 1954. A jury in Jackson County, Texas, found a Mexican American man, Pete Hernandez, guilty of murder, and he was sentenced to life in prison. About 14 of every 100 people in the county had Mexican or Latin American last names. In 25 years, no one with such a name had served on a jury commission, the board that chose jurors. More than 6,000 jurors had been called in that time, and none had such a name.

On the courthouse grounds, one of the two men's toilets was marked "Colored Men" and "Hombres Aqui," which means "Men Here." All nine justices ruled on May 3, 1954, in *Hernandez v. Texas*, that shutting Mexican Americans out of juries broke the 14th Amendment and its promise of equal protection. The ruling came two weeks before *Brown*.

**The walkouts.** About 15,000 students walked out of seven schools in East Los Angeles from March 1 to 8, 1968. About 60 of every 100 Mexican American students there left high school without finishing. Staff forbade students to speak Spanish and steered them into trade classes instead of classes that prepared them for college. The students asked for teaching in both languages, changes to what they were taught, and Mexican American principals.

Members of the Board of Education turned them down, saying the changes would cost too much. Police arrested thirteen organizers on March 31 on charges of felony conspiracy, planning together to commit a serious crime. One of them, the teacher Sal Castro, was fired. He got his job back after months of sit-ins at the board's offices, and on October 2 police arrested 35 people there.

**The Moratorium.** Between 20,000 and 30,000 people marched through East Los Angeles in the National Chicano Moratorium on August 29, 1970. They were protesting how many Mexican Americans were being drafted, wounded and killed in the Vietnam War. About 1,500 police officers came to Laguna Park, fired tear gas into the crowd and beat protesters. Three or four people were killed that day, and 150 were arrested.

Los Angeles County Sheriff's Deputy Thomas Wilson fired a tear gas projectile into the Silver Dollar Bar on Whittier Boulevard. It hit Rubén Salazar, a reporter for the *Los Angeles Times*, in the head and killed him. The coroner, the county official who decides how a person died, ruled his death a homicide, a killing by another person. District Attorney Evelle Younger decided not to charge Wilson. City officials later renamed Laguna Park for Salazar.

**Two more dead.** Two young members of the Brown Berets, a Chicano youth group, were also killed that day. Police said that Angel Gilberto Díaz drove through a police barricade and that officers shot him. Raúl Ruiz, a reporter who was at the march, said Díaz was sitting in the passenger seat when he was shot in the back of the head. Neither account names the officers who shot him.

Witnesses said Lyn Ward died when a tear gas canister exploded, and police said a bomb planted by protesters killed him.

**Disputed:** The art historian Ruben C. Cordova counts three dead that day, because the fourth man often named, Gustav Montag, was killed at a later protest, on January 31, 1971, when a pellet from a police shotgun bounced and struck him in the heart. PBS SoCal counts four dead on August 29.

**The farmworkers.** In the same years, farmworkers organized under Larry Itliong, Cesar Chavez and Dolores Huerta. About 1,500 mostly Filipino American grape workers led by Itliong walked out at Delano, California, on September 8, 1965. Eight days later, members of the union of Chavez and Huerta, the National Farm Workers Association, voted to join them.

**What the strike won.** The two unions joined together and became the union now called the United Farm Workers. People across the country stopped buying California table grapes to back the strikers. On July 29, 1970, 26 grape growers in Delano signed the farmworkers' first union contracts. Chapter 14, Work and Workers, tells the strike in full.

**What was reported about Chavez.** The *New York Times* reported in March 2026 that Chavez had sexually abused two girls in the 1970s. The two women, Debra Rojas and Ana Murguia, are daughters of union organizers. They said the abuse began when they were 12 and 13, and Rojas said Chavez raped her in a motel room when she was 15.

Dolores Huerta then said publicly that Chavez had pressured her into sex once and had raped her in a car in 1966, and that she became pregnant both times. She said she had kept the secret for 60 years because she believed the truth would hurt the farmworker movement.

Chavez died in 1993, so no court has ever heard these accusations. The United Farm Workers canceled its events for Cesar Chavez Day. California's lawmakers voted on March 26, 2026, to rename the state holiday Farmworkers Day, and Governor Gavin Newsom signed the change into law.

### The women's movement and the Equal Rights Amendment, 1966 to 1982

Women organized in the late 1960s for equal treatment at work and under the law, and they won some laws and lost a constitutional amendment by three states.

**NOW.** Federal law had banned sex discrimination at work since 1964. At a government conference on women in Washington on June 30, 1966, some delegates wanted the conference to demand that a federal office, the Equal Employment Opportunity Commission, enforce that ban. Conference officials ruled the demand out of order, against the meeting's rules, saying a government commission could not act against another government office.

That night 28 people met in the hotel room of Betty Friedan, whose 1963 book *The Feminine Mystique* had been a best-seller, and founded the National Organization for Women, known as NOW. They set it up "to take action to bring women into full participation in the mainstream of American society NOW."

**The amendment.** Alice Paul wrote the first version of the Equal Rights Amendment, and it was first brought before Congress in 1923. The first section of the version members of Congress voted on in the 1970s reads: "Equality of rights under the law shall not be denied or abridged by the United States or by any State on account of sex." Representative Martha Griffiths of Michigan pushed it through the House in 1971. Senators passed it on March 22, 1972, by 84 votes to 8.

Three-fourths of the states, 38 of them, had to ratify it within seven years. Hawaii ratified first, and 35 states had ratified by 1977.

**STOP ERA.** Phyllis Schlafly led the campaign against it, called STOP ERA, from 1972. She argued that under the amendment women could be drafted into the military. She also argued that widows would lose Social Security money paid to them as wives, and that mothers would lose their edge in court fights over who keeps the children. Lawmakers in Nebraska, Tennessee, Idaho, Kentucky and South Dakota voted to take back their states' approval.

Members of Congress extended the deadline to 1982, and no more states ratified before it ran out. When the deadline passed, the amendment was three states short of the 38 it needed.

**Credit.** Members of Congress passed the Equal Credit Opportunity Act in October 1974. No lender could now legally refuse a woman credit, a loan or the right to buy now and pay later, because of her sex or because she was married or single.

### What did Title IX change?

Title IX barred schools and colleges that take federal money from shutting anyone out of a program because of sex, and school sports teams are among those programs. It became law on June 23, 1972. Its main sentence reads: "No person in the United States shall, on the basis of sex, be excluded from participation in, be denied the benefits of, or be subjected to discrimination under any education program or activity receiving Federal financial assistance."

**Who passed it.** Representative Patsy Takemoto Mink of Hawaii, Representative Edith Green of Oregon and Senator Birch Bayh of Indiana worked together to pass it. Green, who had taught school for 11 years, led the hearings in the House in 1970. After Mink died on September 28, 2002, members of Congress renamed the law the Patsy T. Mink Equal Opportunity in Education Act.

**The numbers.** Fewer than 300,000 girls played high school sports before Title IX, and more than 3 million did by 2012, more than ten times as many. That year the White House reported that American high schools still offered girls 1.3 million fewer chances to play sports than boys. In the 2013-14 school year, the Government Accountability Office found that girls were 49 of every 100 students at public high schools that offered sports, and 43 of every 100 players.

### Gay Americans organize, 1953 to 1979

Gay Americans organized openly from the 1950s against being fired, arrested and photographed for who they were.

**Fired.** President Dwight Eisenhower signed Executive Order 10450 on April 27, 1953. The order listed "sexual perversion," the government's term then for being gay, among the reasons to remove a person from a federal job. The historian David K. Johnson estimates that "somewhere between 5,000 and 10,000 people lost their jobs" under it. Frank Kameny, who worked at the Army Map Service, was fired in 1957 and fought his firing as a civil rights case.

Protesters picketed the White House against the firings on May 21, 1965. The members of the Civil Service Commission, which set the rules for federal jobs, announced in 1975 that federal workers would no longer be fired for being gay.

**Stonewall.** State rules in New York in the 1960s forbade bars to serve alcohol to gay people. Police raided gay bars, arrested the customers and photographed them. In the early hours of June 28, 1969, police led by Deputy Inspector Seymour Pine raided the Stonewall Inn, a gay bar in Greenwich Village. This time the crowd outside fought back. People threw coins, bottles, bricks, garbage cans and burning trash.

The police shut themselves inside the bar until the Tactical Patrol Force, a police unit trained to break up riots, arrived. The protests went on for six nights, and police arrested 13 people the first night. A National Park Service page counts fifty to sixty gay groups in the country before Stonewall and at least 1,500 a year later.

Thousands of people marched from Greenwich Village to Central Park in the Christopher Street Liberation Day March on June 28, 1970, the first anniversary of the raid. Craig Rodwell led the organizing.

**Harvey Milk.** Harvey Milk was one of the first openly gay people elected to public office in the United States, as a member of San Francisco's Board of Supervisors. Dan White, a former supervisor, shot Mayor George Moscone and then shot Milk five times at City Hall on November 27, 1978. A jury found White guilty of voluntary manslaughter, a lesser crime than murder, in May 1979, and he was sentenced to seven years and eight months. He served about five. Crowds rioted at City Hall after the verdict.

### Native activists hold their ground, 1969 to 1974

Native activists occupied land, and some broke fishing laws on purpose to be arrested. They held Alcatraz Island in San Francisco Bay from November 20, 1969, to June 11, 1971. In 1973 they held the village of Wounded Knee, on the Pine Ridge Reservation in South Dakota, the Oglala Lakota's land, from February 27 to May 8.

**Fishing.** Native fishermen in Washington State fished where their treaties said they could, and got arrested for it on purpose. Billy Frank Jr. of the Nisqually Nation was arrested more than 50 times, starting at age fourteen, at Frank's Landing.

Judge Boldt ruled on February 12, 1974, in *United States v. Washington*, that the tribes were entitled to half of the salmon that could be caught. The justices of the Supreme Court agreed with the ruling in 1979. President Barack Obama awarded Frank the Presidential Medal of Freedom in 2015, after his death.

**By 1974:** Mexican American students had walked out of their schools, women had won Title IX, gay New Yorkers had fought back at the Stonewall Inn, and Native activists had held Alcatraz and Wounded Knee.

### Done to children without asking them, 1965 to 1973

Between 1965 and 1973, surgeons sterilized two poor girls in Alabama after nurses told their mother they would get shots, and staff at a New York state school beat and sexually abused disabled children.

**The Relf sisters.** Nurses in Montgomery, Alabama, told Minnie Relf in June 1973 that her daughters would get birth control "shots." The nurses worked at the family planning clinic of Montgomery Community Action, which was paid for with federal money.

Minnie Relf could not read or write, and she signed the form with an "X." Surgeons then sterilized the two girls, who were 12 and 14, by tubal ligation. In that operation a surgeon cuts or ties the two tubes that carry eggs to the womb, so that the girls could never become pregnant.

Their father, Lonnie Relf, saw the surgical scars when they came home from three days in the hospital. The records do not name the surgeons. Lawyers for the Southern Poverty Law Center sued for the family. The judge in the case found that an estimated 100,000 to 150,000 poor people were being sterilized each year under programs paid for with federal money, and barred federal money for sterilizations done against people's will.

**Willowbrook.** Willowbrook State School, on Staten Island in New York City, was a place run by the state for children with intellectual disabilities. It was built for 4,000 people and held 6,000 by 1965. Senator Robert F. Kennedy toured it that year and said the residents were "living in filth and dirt, their clothing in rags." The television reporter Geraldo Rivera showed crowded wards, filthy bathrooms, and staff beating and sexually abusing residents in 1972.

Parents of 5,000 residents sued the State of New York on March 17, 1972. New York officials agreed to a court order in 1975, and the last children left Willowbrook on September 17, 1987.

### Parents sue to get their children into school, 1971 to 1975

Parents of disabled children sued in 1971 and 1972 to get their children into public schools, and they won.

**The Pennsylvania law.** Pennsylvania's school law let a school board "refuse to accept or retain beginners who have not attained," or reached, "a mental age of five years." A child's mental age was a test score given as the age of an ordinary child who would score the same.

The law also allowed the "temporary or permanent exclusion from the public school of children who are found to be uneducable and untrainable," judged unable to be taught. A child who scored under 30 on an intelligence test was called uneducable, and officials handed the child to the state welfare department for placement and perhaps training, instead of school.

**The lawsuit.** The parents' organization was the Pennsylvania Association for Retarded Children, using the word of the time, in laws and in the case, for people with intellectual disabilities. The association's lawyer, Thomas K. Gilhool of Philadelphia, sued the state for fourteen children on January 7, 1971. The association's leaders estimated that about 100,000 children in Pennsylvania were being denied a free education.

The two sides had reached an agreement by October 1971, and three federal judges issued orders on October 8, 1971, and May 5, 1972. Pennsylvania officials agreed to give every such child from 6 to 21 a free public education. Schools had to offer a hearing before labeling a child retarded, and had to test each labeled child again at least every two years. A federal judge ruled the same way for seven children in Washington, D.C., in *Mills v. Board of Education*, on August 1, 1972.

**A national law.** Parents were bringing cases like these in twenty states. The federal Bureau of Education for the Handicapped estimated that in 1975 about a million disabled children were still shut out of school completely. At least 300,000 more were getting schooling that did not meet their needs. President Gerald Ford signed the Education for All Handicapped Children Act on November 29, 1975. It promised a free public education suited to each disabled child, in every state.

### Section 504, Gallaudet and the Americans with Disabilities Act, 1973 to 1990

Disabled Americans occupied federal offices in 1977 and forced officials to enforce a law that had been passed four years before. Section 504 of the Rehabilitation Act of 1973 was the first federal law protecting the civil rights of disabled people. It says that no qualified person with a disability "shall, solely by reason of his or her disability, be excluded from the participation in, be denied the benefits of, or be subjected to discrimination under any program or activity receiving Federal financial assistance."

No one who ran a school, hospital or office paid with federal money could legally turn a person away only because of a disability. But federal officials could not enforce the law until someone signed the rules for carrying it out, and for four years no one did. Joseph A. Califano Jr., the Secretary of Health, Education, and Welfare, refused to sign them after leaders of schools and hospitals objected to what the rules would cost.

**The sit-in.** Disabled people demonstrated at federal offices in eleven cities on April 5, 1977: San Francisco, Washington, Seattle, Los Angeles, Denver, Chicago, Dallas, Atlanta, New York, Boston and Philadelphia. In San Francisco, about 100 of them occupied the department's offices at 50 UN Plaza and stayed. National Park Service pages give the length of the sit-in as 26 days in one account and 24 days in another. The sit-in worked: Califano signed the rules.

**Who fed them.** Members of the Black Panther Party, a Black political group, brought in one hot meal a day and food for two more. Leaders of a union, the International Association of Machinists, paid bills and paid to fly a group to Washington. The Brick Hut, a business owned and run together by a group of lesbian women, women who love women, and Glide Memorial Church also helped. Judy Heumann, Kitty Cone and Dennis Billups led the occupation from inside.

### Judy Heumann

> **Who:** A woman refused a place at school as a child and a teaching license as an adult, who sued, won, and then helped lead the 1977 sit-in that won the Section 504 rules.
>
> **When and where:** New York City, 1949 to 1970. San Francisco, April 1977.

**"I was willing to make a fuss about it."**

Judy Heumann got polio at eighteen months old, which paralyzed her, and she used a wheelchair from early childhood. New York City school officials refused to take her. Her mother, Ilse, spent years pressing them. Judy got in at about fourth grade, into a separate program for disabled students called Health Conservation 21.

**The license.** She finished college and applied for a license to teach. New York Board of Education officials turned her down in 1970 because she used a wheelchair. She asked the American Civil Liberties Union for help, and its lawyers refused, saying that turning someone down for a medical reason was not discrimination.

That year the *New York Times* put her story on its front page, and a lawyer, Roy Lucas, offered to represent her. She sued the Board of Education at 22, before Judge Constance Baker Motley. Board officials settled before trial and gave her the license. She and her supporters then started a group called Disabled in Action.

**50 UN Plaza.** In April 1977 she was one of the three leaders inside the occupied federal offices at 50 UN Plaza in San Francisco. During the sit-in she and Dennis Billups flew to Washington.

She spent the rest of her life on the same work. From 1993 to 2001 she was the federal official in charge of special education and rehabilitation. She advised the World Bank on disability from 2001 to 2005, and from 2010 to 2017 she was the federal government's special adviser on international disability rights. She died in Washington on March 4, 2023.

"Some people say that what I did changed the world," she once said. "But really, I simply refused to accept what I was told about who I could be. And I was willing to make a fuss about it."

### Deaf President Now, 1988, and the Capitol Crawl

Gallaudet University, in Washington, D.C., is the country's university for deaf students. In March 1988 members of its board of trustees, the group that runs the university, chose a hearing candidate, Elisabeth Zinser, as president over deaf candidates. Students marched, stopped going to classes and let the air out of the tires of school buses in front of the university's gates.

**Four demands.** Zinser had to go and a deaf president be chosen. The board's chair, Jane Spilman, had to resign. At least 51 of every 100 board members had to be deaf. No one who protested could be punished. After eight days the trustees gave in. I. King Jordan became Gallaudet's first deaf president. "A Deaf person can do anything a hearing person can, except hear," he said.

**The Capitol Crawl.** While members of Congress were considering the Americans with Disabilities Act, disabled protesters left their wheelchairs, walkers and crutches at the bottom of the steps of the Capitol and climbed the steps without them. The protest is called the Capitol Crawl. President George H. W. Bush signed the Americans with Disabilities Act on July 26, 1990. Employers, state and city governments, businesses open to the public and public bus and train systems all had to give disabled people an equal chance at their jobs, services and goods.

### Busing, Detroit and Boston, 1974

When Black parents in the North sued over segregated schools in the 1970s, they won in Boston and lost at the Supreme Court over Detroit's suburbs.

**Detroit.** The justices ruled five to four against busing children across school district lines on July 25, 1974, in *Milliken v. Bradley*. A judge could not send city children to suburban schools, or suburban children to city schools, unless someone proved that one district had caused segregation in the other. A judge's plan that would have covered Detroit and 53 suburban districts could not go ahead. Justice Thurgood Marshall, who had argued *Brown* before the Supreme Court as the NAACP's lawyer, was one of the four who dissented.

**Boston.** Tallulah Morgan, a Black mother of three, and thirteen other families sued the Boston School Committee, the city's elected school board, in 1972. Judge W. Arthur Garrity ruled on June 21, 1974, that "the entire school system of Boston was unconstitutionally segregated," kept apart by race in a way the Constitution forbids. School officials, he found, "had knowingly carried out a systematic program of segregation affecting all of the city's students, teachers and school facilities."

Busing, carrying children by bus to schools outside their neighborhoods, began on September 9, 1974, and paired South Boston with Roxbury. Protesters threw rocks and bottles at the buses, broke the windows and shouted racial insults. Of the 800 Black students assigned to South Boston High that first day, 56 came. Garrity handed the job of watching over the schools to state officials in 1982 and issued his final order in 1985.

### Warren County residents lie down in the road, 1982

Residents of mostly Black Warren County, North Carolina, lay down in front of dump trucks in September 1982 to stop a landfill for poisoned soil. Someone had illegally dumped chemicals called PCBs along North Carolina's roadsides in 1978, poisoning the soil. State officials chose Afton, in mostly Black, rural Warren County, as the place to bury it.

After the courts failed them, residents and civil rights leaders, among them the Reverend Benjamin Chavis of the United Church of Christ's Commission for Racial Justice, blocked the trucks. Police arrested about 500 people over six weeks, and state officials had the landfill built anyway. The protest is widely named as the start of the environmental justice movement, the campaign against placing pollution where poor and nonwhite people live. Members of the church's commission published a report, *Toxic Wastes and Race*, in 1987.

### An apology and $20,000, 1980 to 1990

Japanese Americans who had been held in the camps of the Second World War campaigned for an apology and payment, and in 1988 they won both. The Japanese American Citizens League and the National Council for Japanese American Redress led the campaign.

**The commission.** President Jimmy Carter signed a law creating a commission to study the camps on July 31, 1980. Its members held 20 days of hearings in 11 places in 1981 and heard more than 750 witnesses. Their report, in February 1983, found that the causes were "race prejudice, war hysteria and a failure of political leadership." A federal judge also threw out the finding that Fred Korematsu had been guilty in 1983.

**The law.** Senators Daniel Inouye and Spark Matsunaga and Representatives Norman Mineta and Robert Matsui led the bill through Congress. President Ronald Reagan signed the Civil Liberties Act on August 10, 1988. Each person still living who had been held received an apology and $20,000. The first letters and checks went out on October 1, 1990.

**If you remember one thing:** Marchers, students, parents and disabled protesters won court rulings against segregated schools and buses, and new laws against segregation in public places, literacy tests, sex discrimination in schools and shutting disabled people out. Many of them were beaten, jailed or killed for it.

**Left open:** Would the justices of the Supreme Court keep the Voting Rights Act as members of Congress wrote it in 1965?

**Next:** After 2000, judges and lawmakers widened some of these rights and narrowed others.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 50 minutes**

Judges and lawmakers since 2000 have widened some of the rights earlier movements won and taken back others. Same-sex couples, two men or two women, won the right to marry in every state in 2015, twelve years after police in some states could still arrest two men or two women for having sex at home. Members of Congress passed the first federal law against lynching in 2022, after about 200 earlier bills had failed.

**Rights narrowed.** The justices of the Supreme Court cut back the Voting Rights Act of 1965 in 2013 and again in 2026. They overruled the 1973 ruling that protected abortion in 2022, declaring it wrong and ending it, and a year later they stopped colleges from considering an applicant's race.

Their rulings of 2025 and 2026 allowed states to ban some medical care for transgender young people and to keep transgender girls off girls' school teams. A transgender person is someone whose own sense of being male or female, called gender identity, differs from the sex recorded at birth.

**New tools.** Organizers used phones and social media alongside the old tools of meetings, lawsuits and marches. A seventeen-year-old recorded a Minneapolis police officer kneeling on George Floyd in 2020, and after people saw her video they protested in cities around the world. Two words posted on Twitter in October 2017, "me too," were used more than 19 million times within a year.

Police officers and federal agents also killed people in these years, among them George Floyd in 2020, and Renée Good and Alex Pretti, two American citizens shot by federal immigration agents in Minneapolis in 2026. As of September 2026 no one had been charged with killing Good or Pretti, and the fights over voting maps, DACA and the Equal Rights Amendment were still going on.

### The justices strike down the Voting Rights Act's list, 2013

The justices of the Supreme Court struck down the list of places that had to get federal permission before changing a voting rule on June 25, 2013. That permission is called preclearance. Since 1965, officials in the listed states and counties had needed it from federal officials in Washington.

**The list.** Nine states were on the list in full. Alabama, Georgia, Louisiana, Mississippi, South Carolina and Virginia were covered from November 1, 1964. Alaska, Arizona and Texas were covered from November 1, 1972. Named counties in California, Florida, New York, North Carolina and South Dakota were covered too, and so were two townships in Michigan.

**Shelby County v. Holder.** The justices split five to four. Chief Justice John Roberts wrote for the majority that "the Act imposes current burdens and must be justified by current needs." The majority struck down Section 4(b), the formula that decided which places went on the list, and left the preclearance rule itself standing with no list of places it applied to.

"We issue no holding on §5 itself, only on the coverage formula," Roberts wrote, and "Congress may draft another formula based on current conditions." Justice Ruth Bader Ginsburg wrote the dissent, joined by Justices Stephen Breyer, Sonia Sotomayor and Elena Kagan. A Justice Department web page states the result. The places that had been on the list "no longer need to seek preclearance for the new voting changes," unless a separate court order covers them.

**No new list.** Members of Congress tried to write a new list in the John R. Lewis Voting Rights Advancement Act, named for John Lewis of the Student Nonviolent Coordinating Committee, one of the speakers at the 1963 March on Washington. Under one version, a state with 15 or more voting rights violations in the previous 25 years would be covered for 10 years.

Senators voted 49 to 51 on ending debate over the bill on January 19, 2022. Ending debate needed 60 votes, so the bill never came to a final vote. Later that night senators voted 52 to 48 to keep the 60-vote rule in place. By September 2026 members of Congress had passed no new list.

### Proving intent: Louisiana v. Callais, 2026

Anyone suing under Section 2 of the Voting Rights Act must now show that state officials meant to discriminate by race, under a ruling of April 29, 2026. Section 2 lets people go to court over a voting rule or a map of election districts that gives a racial group less chance to elect the candidates it wants. Members of Congress had rewritten Section 2 in 1982 so that a person suing would not have to prove what the officials intended.

**The Louisiana map.** Louisiana's lawmakers drew a map of six congressional districts with one majority-Black district after the 2020 census. A federal judge held that the map likely broke Section 2. The lawmakers then drew a second majority-Black district. Other voters sued, saying the new map was a racial gerrymander, a set of districts drawn by race in a way the Constitution forbids.

**The new rule.** Justice Samuel Alito wrote for six justices that the Voting Rights Act had not required the second district, so the map broke the Constitution. He set a new rule for every future case. Section 2 "imposes liability only when the evidence supports a strong inference that the State intentionally drew its districts to afford minority voters less opportunity because of their race." A person suing must now show that officials meant to treat voters unfairly because of race.

The Congressional Research Service, which writes explanations of the law for members of Congress, put it this way on May 14, 2026. A person suing "now must show that a state drew a redistricting map based on racial, and not political, considerations." That person must also "present evidence of current-day, intentional voting discrimination that is based on race."

**The dissent.** Justice Elena Kagan dissented, joined by Justices Sonia Sotomayor and Ketanji Brown Jackson. To show how lawmakers can draw districts so that some people's votes count for less, she asked readers to imagine a round district that was 90 percent Black, in a state that was otherwise 90 percent white.

Lawmakers could slice that district "into six pie pieces," she wrote, and spread its Black voters across six mostly white districts. In that imagined state, "Election after election, Black citizens' votes are, by every practical measure, wasted." "'Cracked' is the usual term," she said, and the majority had made "a nullity of Section 2," a rule with no force left in it.

**The new map.** Louisiana's Republican lawmakers passed a new map in May 2026. It removed one of the state's two majority-Black districts and was expected to elect five Republicans and one Democrat. About a third of Louisiana's people are Black. State Senator Jay Morris wrote the bill. "We focused on the Democrat numbers, not the racial numbers when drawing," said State Representative Beau Beaullieu, a Republican. State Representative Kyle Green Jr., a Democrat, said the map took Black Louisianians "from 33% of the population to 16% of the representation."

Louisiana officials put off the House primary elections set for May 16, 2026. To use the new map, they threw out about 40,000 votes that people had already cast.

**Other states.** The justices let Alabama keep using a 2023 congressional map with one majority-Black district on June 2, 2026. They stopped a lower court's order against it, saying Alabama was "likely to succeed on the merits as to both claims," likely to win.

The Congressional Research Service reported in May 2026 that "some state legislatures are considering or have already enacted modifications to their redistricting maps that eliminate majority-minority districts for the upcoming 2026 congressional elections." Lawmakers in some states were drawing new maps without districts where most voters were Black or Latino. In September 2026 members of Congress had passed no new rule for Section 2.

### Separate schools, counted in 2021 and 2022

School officials have been forbidden by law since 1954 to send children to separate schools because of their race. In the 2020s, federal and university researchers still found many schools where three-quarters or more of the students were of one race.

**The federal count.** The federal Government Accountability Office, which checks on government work for Congress, published a report on June 16, 2022, about the school year 2020-21. Its researchers found that about 18.5 million children, more than a third of American public school students, "attended schools where 75 percent or more students were of a single race or ethnicity," ethnicity meaning a group's shared background, such as Hispanic. Fourteen percent of students attended schools where 90 percent or more were of one race or ethnicity.

**The longer count.** Researchers at the Civil Rights Project at UCLA, a university research center, count a longer stretch using the federal government's school data. In a report of April 2024, Gary Orfield and Ryan Pfleger gave the share of public schools that were 90 to 100 percent non-white. It was 7.4 percent in 1988 and 19.8 percent in 2021, or about one school in five. In those schools in 2021, 78 of every 100 students were poor.

The same report follows Black students in the South. The share who attended a school where most students were white reached a peak of about 43 percent in the mid-1980s, and it was about 16 percent in 2021. The authors tie the turn to a 1991 Supreme Court ruling, *Board of Education of Oklahoma City v. Dowell*, which let judges end court orders to desegregate. After it, the share fell for nearly 30 years in a row.

### Race in college admissions, 2014 to 2023

The justices of the Supreme Court ruled in 2023 that colleges may not give applicants a boost because of their race. In Justice Sonia Sotomayor's count, the justices had let colleges consider race "in a limited way" for 45 years before that, to gain the benefits of racial diversity. The practice is often called affirmative action.

**The lawsuits.** Students for Fair Admissions, a nonprofit group founded in 2014, sued Harvard College and the University of North Carolina in November 2014. Its first board had three members, Edward Blum, Abigail Fisher and Richard Fisher. At Harvard, readers and committees considered race at several steps of the process, and for a significant share of the Black and Hispanic students admitted, race tipped the decision. At the University of North Carolina, readers could give an applicant a "plus" because of race.

**The ruling.** Chief Justice John Roberts wrote for six justices on June 29, 2023, that both programs broke the 14th Amendment's promise of equal protection. "The guarantee of equal protection cannot mean one thing when applied to one individual and something else when applied to a person of another color," he wrote. A college may still read an applicant's own account of "how race affected the applicant's life," he added, if it is tied to the applicant's character or abilities. The justices left open the question for the military academies.

**The dissent.** Sotomayor dissented, joined by Justice Elena Kagan, and by Justice Ketanji Brown Jackson in the North Carolina case. Jackson took no part in the Harvard case. "The Court long ago concluded that this guarantee can be enforced through race-conscious means in a society that is not, and has never been, colorblind," Sotomayor wrote, colorblind meaning taking no notice of race at all. "Today, this Court stands in the way and rolls back decades of precedent," the Court's own earlier rulings, "and momentous progress."

### From arrest to marriage, 2003 to 2015

Two men or two women in some states could still be arrested in 2003 for having sex at home. Twelve years later the justices of the Supreme Court ruled that same-sex couples could marry in every state.

**Lawrence v. Texas.** The justices voted six to three on June 26, 2003, to strike down a Texas law that made it a crime for two people of the same sex to have sex in private. Justice Anthony Kennedy wrote the opinion. The justices overruled a 1986 ruling that had allowed such a law: "*Bowers* was not correct when it was decided, is not correct today, and is hereby overruled."

**Massachusetts.** The Supreme Judicial Court of Massachusetts, the state's highest court, ruled on November 18, 2003, that the state constitution guaranteed same-sex couples the right to marry. The judges held back their own order for 180 days "to permit the Legislature to take such action" as it chose, the Legislature meaning the state's lawmakers. Massachusetts became the first state where same-sex couples could marry on May 17, 2004.

**Edith Windsor.** Edith Windsor and Thea Spyer married in Ontario, Canada, in 2007 and lived in New York. Spyer died in February 2009 and left everything she owned to Windsor. The federal Defense of Marriage Act defined marriage as one man and one woman for more than 1,000 federal laws and rules.

So federal officials counted Windsor as unmarried, and she paid $363,053 in estate taxes, a tax on what a person leaves at death. She sued for the money back, and the justices struck down that part of the law, five to four, in *United States v. Windsor* on June 26, 2013.

**Obergefell.** By 2015 voters and lawmakers had changed their marriage laws to include same-sex couples in eleven states and the District of Columbia, by the justices' count. The justices ruled five to four on June 26, 2015, in *Obergefell v. Hodges*, that same-sex couples may marry in every state. Kennedy wrote the opinion. Chief Justice John Roberts and Justices Antonin Scalia, Clarence Thomas and Samuel Alito each wrote a dissent.

Within moments of the ruling, LGBT people gathered in Christopher Park in New York. LGBT is short for lesbian, gay, bisexual and transgender. President Barack Obama made that park, a triangle of about 0.12 acres, the Stonewall National Monument on June 24, 2016, in memory of the 1969 uprising at the Stonewall Inn.

### Jim Obergefell

> **Who:** A widower who sued Ohio to have his name put on his husband's death certificate, and won the case that made same-sex marriage legal in every state.
>
> **When and where:** Ohio, and Baltimore, Maryland, 2011 to 2015.

**The couple married inside a medical plane on a Baltimore runway.**

Jim Obergefell sued the state of Ohio over a death certificate. He wanted to be named on it as the husband of John Arthur, and Ohio law would not allow it.

**In the justices' words.** The justices set out his story in their written opinion, where "petitioner" and "plaintiff" both mean a person who brought the case. "Petitioner James Obergefell, a plaintiff in the Ohio case, met John Arthur over two decades ago. They fell in love and started a life together, establishing a lasting, committed relation. In 2011, however, Arthur was diagnosed with amyotrophic lateral sclerosis, or ALS."

ALS destroys the nerve cells that carry orders from the brain to the muscles. The muscles stop getting those orders, waste away and stop working. It takes the hands and legs first, then swallowing, then breathing. The Court called the disease "progressive, with no known cure."

**The wedding.** The two men decided to marry before Arthur died. Ohio did not allow same-sex couples to marry, and Maryland did. The Court went on: "It was difficult for Arthur to move, and so the couple were wed inside a medical transport plane as it remained on the tarmac in Baltimore. Three months later, Arthur died. Ohio law does not permit Obergefell to be listed as the surviving spouse on Arthur's death certificate." The wedding was on July 11, 2013, and Arthur died on October 22, 2013.

**The case.** Obergefell sued. His case was joined with cases from Michigan, Kentucky and Tennessee, brought together by 14 same-sex couples and two men whose partners had died. The justices decided them together on June 26, 2015. The last lines of Justice Kennedy's opinion read: "They ask for equal dignity in the eyes of the law. The Constitution grants them that right."

**By 2015:** The justices had struck down the Voting Rights Act's list of places that needed federal permission, and same-sex couples could marry in every state.

### The Respect for Marriage Act, 2022, and Kim Davis

Members of Congress wrote the protection for same-sex marriages into federal law in 2022, and the Respect for Marriage Act became law on December 13, 2022. It does not require any state to issue marriage licenses. It forbids any state official to refuse to recognize a marriage from another state because of the couple's sex, race, ethnicity or national origin. The Attorney General, or the person harmed, may sue anyone who breaks it.

**The votes.** Senators passed it on November 29, 2022, by 61 votes to 36, with twelve Republican senators voting yes. The House passed it on December 8, 2022, by 258 votes to 169, with 39 Republicans voting yes. The law opens with a sentence from Kennedy's *Obergefell* opinion: "No union is more profound than marriage, for it embodies the highest ideals of love, fidelity, devotion, sacrifice, and family."

**Kim Davis.** Kim Davis was a county clerk in Kentucky. After the 2015 ruling she refused, on religious grounds, to issue a marriage license to a gay couple, David Ermold and David Moore, and she spent six days in jail.

A jury later ordered her to pay the couple $100,000 for the harm done to them and $260,000 for their lawyers' fees. In 2025 she asked the justices of the Supreme Court to overturn *Obergefell*, the first such request since 2015. The justices refused to hear it on November 10, 2025.

### Black Lives Matter and Ferguson, 2012 to 2016

Black Lives Matter began in 2013, after a Florida jury found the man who killed Trayvon Martin not guilty.

**Trayvon Martin.** George Zimmerman, a neighborhood-watch volunteer, shot and killed Martin, a 17-year-old Black teenager who was walking back from a convenience store, in Sanford, Florida, on February 26, 2012. Martin was unarmed. The Sanford police chief said on March 12, 2012, that no charge could be filed. After demonstrations across the country, Governor Rick Scott appointed a special prosecutor, a lawyer chosen to handle this one case, in April 2012.

The special prosecutor charged Zimmerman with second-degree murder, a murder that was not planned ahead. The jury found him not guilty on July 13, 2013. Justice Department officials announced in 2015 that they would not bring federal hate-crime charges.

After the verdict, three Black organizers, Alicia Garza, Patrisse Cullors and Opal Tometi, started a project to build a movement and called it #BlackLivesMatter. The mark # turns a phrase into a hashtag, a label that people can search for on social media.

**Michael Brown.** Officer Darren Wilson of the Ferguson Police Department in Missouri shot and killed Michael Brown, an unarmed 18-year-old, at about noon on August 9, 2014. Justice Department officials announced on March 4, 2015, that the evidence did not support charging Wilson with a federal crime. Their report states that Wilson did not willfully, knowingly and on purpose, violate Brown's right to be free from unreasonable force.

**The Ferguson report.** The same day, lawyers in the Justice Department's Civil Rights Division published a report on the whole Ferguson police department. Its investigators had interviewed half the department's officers and read more than 35,000 pages of police records, and spent about 100 days of work in the town.

They found "a pattern or practice of unlawful conduct within the Ferguson Police Department that violates the First, Fourth, and Fourteenth Amendments to the United States Constitution." Ferguson's police broke the Constitution again and again, as a regular way of working.

**Who the police stopped.** The police department's own numbers for 2012 to 2014 showed who the police stopped. Black people were 67 percent of Ferguson's population. They were 85 percent of the drivers stopped, 90 percent of the people given tickets and 93 percent of the people arrested. Police searched Black drivers more than twice as often as white drivers, and found something illegal on them 26 percent less often.

The investigators found that "nearly 90% of documented force used by FPD officers was used against African Americans." In every dog-bite case where the race was recorded, the person bitten was Black. The report states that "Ferguson's law enforcement practices are shaped by the City's focus on revenue rather than by public safety needs." The city's finance director wrote to the police chief in March 2010 that "unless ticket writing ramps up significantly before the end of the year, it will be hard to significantly raise collections next year."

**Recording the police.** The investigators also found that officers punished people for recording them and for protesting. One officer saw a couple filming him. He arrested the father, then pulled the mother over and arrested her too, saying "no more mercy, since she wanted to videotape," and "nobody videotapes me." He took the phone from their daughter. When the parents got out of jail on bond, money paid so a person can wait for trial at home, the video had been deleted.

A federal judge ordered Ferguson officers in November 2014 to stop interfering with people "lawfully and peacefully" recording the police. On February 9, 2015, six months after Michael Brown's death, people protested outside the police station. Officers pushed a man who was recording the arrests to the ground and handcuffed him. The report states that his video shows he "was neither interfering nor resisting." Officers also arrested a protester in a wheelchair who was streaming the protest live. The report names none of these people.

**Colin Kaepernick.** Some athletes joined the protests against police killings. Colin Kaepernick, the quarterback of the San Francisco 49ers football team, sat and then knelt during the national anthem in the 2016 preseason, "in protest of police brutality and racial inequality." He chose to leave his contract in March 2017, and no team signed him. He accused the owners of the National Football League in October 2017 of secretly agreeing to keep him out. He settled with the league on February 15, 2019, and the terms were kept secret.

### Minneapolis, May 25, 2020

A Minneapolis police officer, Derek Chauvin, knelt on George Floyd for about ten minutes on May 25, 2020, while Floyd lay handcuffed and face down in the street. Floyd died, and a jury later found Chauvin guilty of murdering him. Chauvin later admitted these facts in writing, in a plea agreement he signed in federal court on December 15, 2021, a statement in which a person accused of a crime admits to it under a deal with prosecutors.

**What the officers did.** Chauvin and his partner, Officer Tou Thao, answered a call about a counterfeit bill, a fake banknote. Officers J. Alexander Kueng and Thomas Lane were already there. They tried to put Floyd in a squad car. Then Chauvin, Kueng and Lane moved Floyd, who was handcuffed, out of the car and face down on the street.

He "remained restrained, prone and handcuffed on the ground for approximately ten minutes," prone meaning lying face down. Chauvin "held his left knee on Mr. Floyd's neck, back, and shoulder area and his right knee on Mr. Floyd's left arm and upper back" the whole time.

Floyd stopped resisting soon after the officers first held him down, and Chauvin went on kneeling on him. He admitted that he knew he had no legal reason to continue, "because he was aware that Mr. Floyd not only stopped resisting, but also stopped talking, stopped moving, stopped breathing, and lost consciousness and a pulse." By his own account he "heard Mr. Floyd repeatedly explain that he could not breathe, was in pain, and wanted help."

Bystanders asked him again and again to check for a pulse and to get off Floyd. Kueng checked for a pulse at least twice and said twice that he could not find one. Chauvin admitted he did not see Thao or Kueng do or say anything to get him off Floyd. Lane twice asked whether Floyd should be rolled onto his side.

**Darnella Frazier.** Darnella Frazier was seventeen. She was walking with her nine-year-old cousin, and she recorded what the officers did on her phone. The Pulitzer Prize Board gave her a special citation in 2021. News reports of the announcement quote it: "for courageously recording the murder of George Floyd, a video that spurred protests against police brutality around the world." She testified at Chauvin's state trial.

**The verdicts.** A Hennepin County jury found Chauvin guilty on April 20, 2021, of two kinds of murder, second-degree and third-degree, and of second-degree manslaughter. Judge Peter Cahill sentenced him to 22 and a half years. In federal court Judge Paul Magnuson sentenced him to 21 years, to be served at the same time. Thao, Kueng and Lane got federal sentences of between two and a half and three and a half years.

**The boy in 2017.** In the same plea agreement, Chauvin admitted to an attack four years earlier. He answered a call on September 4, 2017, from a mother who said her 14-year-old son had hit her. Chauvin held the boy by the throat and hit him in the head with a flashlight, cutting him near the left ear.

Then he knelt on the boy's neck, shoulders and upper back "for between fifteen and sixteen minutes" while the boy lay face down, handcuffed and not resisting, and "at times, cried from pain." Chauvin left all of it out of his report that night. The plea agreement does not name the boy.

**The protests.** People protested in cities and towns across the country that summer. Researchers at the Pew Research Center, an organization that runs surveys, asked 9,654 American adults about the protests between June 4 and 10, 2020. Six of every 100 said they had gone to a rally or protest on these issues in the past month. Two-thirds said they supported the Black Lives Matter movement, and 38 of every 100 said they strongly supported it.

The Crowd Counting Consortium, a project run by researchers at Harvard and the University of Connecticut, counts protests. Its data supported a *New York Times* analysis that the 2020 protests were the largest and broadest in American history up to then. The same data showed the protests were "overwhelmingly peaceful, especially relative to the heavy-handed police response," in the words of Harvard's Ash Center.

**What Congress and the Justice Department did.** Members of the House of Representatives passed the George Floyd Justice in Policing Act on March 3, 2021, by 220 votes to 212, and senators never voted on it. Under President Joe Biden, Justice Department lawyers sued Minneapolis and Louisville to force changes in how their police worked, through consent decrees, agreements that a judge enforces.

On May 21, 2025, under President Donald Trump, Harmeet Dhillon, the head of the Justice Department's Civil Rights Division, dropped both lawsuits. She said she was ending "the Biden Civil Rights Division's failed experiment of handcuffing local leaders and police departments with factually unjustified consent decrees."

**By 2021:** Protests after police killings had filled streets across the country, and a jury had found Derek Chauvin guilty of murdering George Floyd.

### The Emmett Till Antilynching Act, 2022

The Emmett Till Antilynching Act became law on March 29, 2022, the first federal law against lynching. Members of the House passed it on February 28, 2022, and senators passed it on March 7.

**About 200 bills.** Members of Congress had introduced about 200 anti-lynching bills before it, and none had become law. The House Judiciary Committee's own 2022 report on the bill gives two different starting dates.

One section says the first bill came from Congressman George Henry White in 1900, when he was the only Black member of Congress. Another says the first came from Congressman Leonidas Dyer of Missouri in 1918. Both sections agree that the House passed three anti-lynching bills between 1920 and 1940, and that none of them became law.

**What the law covers.** The law is named for Emmett Till, whom the report describes as "a 14-year-old African American youth from Chicago who was lynched in 1955 while visiting an uncle in Mississippi." Under federal law, a hate crime is hurting a person on purpose because of their race, color, religion or national origin, and in some cases their gender, sexual orientation, gender identity or disability.

The new law covers a person who conspires, or plans with others, to commit a hate crime. When the crime kills someone or badly injures them, that person can be sent to prison for up to 30 years.

### Me too, 2017 to 2026

The actress Alyssa Milano wrote on Twitter on October 15, 2017, "If you've been sexually harassed or assaulted write 'me too' as a reply to this tweet," harassment meaning unwanted sexual words or touching and assault meaning a sexual attack.

**The count.** Researchers at the Pew Research Center later counted public English-language posts on Twitter. They found the hashtag #MeToo used more than 19 million times between that day and September 30, 2018, an average of 55,319 times a day. The researchers counted posts on one website in one language, so the figure is a count of posts and not of people.

**Harvey Weinstein.** Milano posted the words during the reporting about the film producer Harvey Weinstein. *The New York Times* and *The New Yorker* reported in October 2017 that more than a dozen women accused him of sexual harassment, assault or rape. He denied "any nonconsensual sex," sex the other person did not agree to. He was dismissed from his company that month.

A New York jury found him guilty of rape and of a criminal sexual act in 2020, and he was sentenced to 23 years. Under New York law, a criminal sexual act means forcing a person into sex acts such as oral sex. Judges of the New York Court of Appeals, the state's highest court, threw out those verdicts in 2024 because of "egregious errors," very serious mistakes, by the trial judge. A Los Angeles jury found him guilty of rape and two other charges in 2022.

At a new trial in New York, on June 11, 2025, a jury found him guilty of forcing oral sex on Miriam Haley, a former production assistant, in his Manhattan apartment in 2006. Justice Curtis Farber sentenced him to 15 years in prison on September 23, 2026. "You took what you wanted by force, and you have never accepted responsibility," Farber told him.

The words "me too" were already in use. A youth worker in Selma, Alabama, named Tarana Burke had been using them with girls and young women for years before 2017.

### Tarana Burke

> **Who:** A youth organizer who used the words "me too" with survivors of sexual violence for years before the words became a hashtag.
>
> **When and where:** The Bronx, New York, and Selma, Alabama, 1973 to 2018.

**She was saying "me too" to girls years before the hashtag.**

Tarana Burke is herself a survivor of sexual abuse. She grew up in the Bronx, in New York City, and at fourteen she joined a group called the 21st Century Youth Leadership Movement. After Alabama State University and Auburn University, she moved to Selma, Alabama, and kept working for the same group there.

**The girl at the camp.** A National Women's History Museum biography dates the start of her work to 1996, when a girl at a youth camp told Burke that she had been sexually abused. The same biography states that years later Burke "began using the phrase 'me too' to promote the idea of 'empowerment through empathy.'" Burke's own account says her work turned toward survivors of sexual violence while she lived in Selma.

**Just Be.** She started an organization for Black girls called Just Be.

**Disputed:** When Just Be and her use of the name "Me Too" began. Her own website says she created Just Be in 2005, and the museum's biography gives 2007. A Colorado State University page states that she made a "Me Too" page on MySpace, a social network of that time, in 2006.

**2017.** The words spread across Twitter in October 2017, during the Harvey Weinstein reporting, and Burke became a leader of the movement around the world. *Time* magazine named "the Silence Breakers," Burke among them, its Person of the Year for 2017. In 2018 she started an organization called "me too." International.

### Equal pay for the women's soccer team, 2016 to 2022

Five players on the United States women's national soccer team, Hope Solo, Carli Lloyd, Alex Morgan, Megan Rapinoe and Becky Sauerbrunn, filed a complaint in April 2016 that they were paid less because they were women. They filed it with the Equal Employment Opportunity Commission, the federal office that enforces the law against job discrimination.

The players and US Soccer's leaders settled the case on February 22, 2022, for $24 million, and $22 million of it went to the players. Under new contracts signed on May 18, 2022, the women's and men's teams get equal pay and bonuses through 2028.

### The Women's March, 2017, and No Kings, 2025

Women marched in cities across the country on January 21, 2017, the day after Donald Trump became president. Teresa Shook, a grandmother in Hawaii, had proposed a march on Washington in a Facebook post the day after the November 2016 election. Between 3.2 million and 5.3 million people marched in the United States, about 500,000 of them in Washington, by the count in Encyclopaedia Britannica.

Erica Chenoweth of Harvard and Jeremy Pressman of the University of Connecticut founded the Crowd Counting Consortium to count this march. Their data showed it was the largest one-day demonstration in American history up to that time. Britannica records that the "No Kings" protests of June 14, 2025, in which about five million people marched, passed that record.

### The end of Roe v. Wade, 2022

The justices of the Supreme Court ended the right to an abortion in 2022, when they overruled an earlier decision of their own court. An abortion is a medical procedure that ends a pregnancy. In *Roe v. Wade*, in 1973, the justices had decided that the Constitution protected that right, and the ruling stood for 49 years.

**Dobbs.** Mississippi's lawmakers banned abortion after fifteen weeks of pregnancy, except in a medical emergency or when the fetus, the medical word for the unborn offspring growing in the womb after the first weeks of pregnancy, had a serious defect.

Justice Samuel Alito wrote for five justices on June 24, 2022, in *Dobbs v. Jackson Women's Health Organization*: "We therefore hold that the Constitution does not confer a right to abortion. Roe and Casey must be overruled, and the authority to regulate abortion must be returned to the people and their elected representatives."

*Casey* was a 1992 ruling, *Planned Parenthood v. Casey*, that had kept *Roe* in place. Chief Justice John Roberts agreed that the Mississippi law could stand but did not join in overruling *Roe*. Justices Stephen Breyer, Sonia Sotomayor and Elena Kagan dissented together.

**The states.** After *Dobbs*, lawmakers in each state set their own rules. KFF, a health research group, counted them on August 10, 2026. Thirteen states banned abortion in almost every case. Seven more banned it after six to twelve weeks of pregnancy. Nine states and the District of Columbia set no limit by stage of pregnancy.

### The Equal Rights Amendment, 2017 to 2026

Lawmakers in three more states ratified the Equal Rights Amendment after 2000, and in September 2026 it was still not part of the Constitution. The amendment reads: "equality of rights under the law shall not be denied or abridged by the United States or any State on account of sex." When the 1982 deadline ran out, 35 states had ratified it, and 38 were needed.

**Three more states.** Nevada's lawmakers ratified it in 2017, treating the deadline as one they could ignore. Illinois followed in 2018 and Virginia in 2020. The three states asked the Archivist of the United States, the federal official who certifies and publishes amendments, to add it, and the Archivist did not. Officials of the three states sued in January 2020. A federal judge threw out the suit, and the judges of a federal appeals court agreed in February 2023.

**The deadline.** Lawyers in the Justice Department's Office of Legal Counsel, which writes legal opinions for the department, wrote in 2020 and 2022 that the deadline "is valid and enforceable." In December 2024 the Archivist, Colleen Shogan, and her deputy, William J. Bosanko, wrote that the amendment "cannot be certified as part of the Constitution due to established legal, judicial, and procedural decisions." Earlier court rulings and rules, they meant, stopped them from declaring it part of the Constitution.

President Joe Biden said on January 17, 2025, three days before he left office: "I affirm what I believe and what three-fourths of the states have ratified: the 28th Amendment is the law of the land." His statement ordered no one to do anything, and Shogan did not publish the amendment.

### Hair, 2018 to 2026

Lawmakers in about 30 states passed laws between 2019 and 2026 against punishing people at work or at school for their natural hair, or for styles such as braids, locs and twists. The count of about 30 states comes from the CROWN Coalition, the group of organizations that campaigned for the laws. Dove, a soap and beauty brand, founded it with Color of Change, the National Urban League and the Western Center on Law and Poverty.

**Andrew Johnson.** The referee Alan Maloney told Andrew Johnson, a junior wrestler at Buena Regional High School, to cut his dreadlocks or forfeit, lose the match without wrestling, at a home match in Buena, New Jersey, on December 19, 2018. Maloney gave him 90 seconds. The team's athletic trainer cut Johnson's hair beside the mat. The New Jersey Division on Civil Rights and the state's school sports association agreed on September 18, 2019, that Maloney would be suspended for two seasons.

**The CROWN Act.** California's CROWN Act, for Creating a Respectful and Open World for Natural Hair, was written by State Senator Holly J. Mitchell. California's governor signed it on July 3, 2019, the first state law of its kind. It added hair texture and styles such as braids, locs and twists to the state's law against discrimination at work and in schools.

Governor Phil Murphy signed New Jersey's version on December 19, 2019, a year to the day after Johnson's match. Members of the House passed a federal CROWN Act on September 21, 2020, and again on March 18, 2022. Senators never voted on it.

**By 2022:** Members of Congress had passed the first federal law against lynching, and the justices had ended the right to an abortion that the Court had protected since 1973.

### Disability: narrowed by judges, restored by Congress, dropped in 2026

Disabled Americans fought after 1990 over who the Americans with Disabilities Act covered and whether they could live outside institutions. On a single day in 1999 the justices of the Supreme Court narrowed who counted as disabled and ruled that keeping disabled people in institutions without need was discrimination. Members of Congress restored the wider meaning of disability in 2008. A federal judge struck down the federal rule that carried out the 1999 ruling on institutions in 2026.

**Who counted as disabled.** The first fight was over who counted as disabled. Twin sisters applied to fly for United Air Lines. Without glasses their eyesight was 20/200 or worse, and with glasses it was 20/20 or better. Perfect ordinary eyesight is called 20/20, and a bigger second number means worse sight. United's hiring rule required 20/100 or better without glasses and turned the sisters down.

The justices ruled on June 22, 1999, in *Sutton v. United Air Lines*, that whether a person is disabled must be judged with glasses or other aids in use. So the airline could refuse the sisters because of their eyes, and they could not sue, because with their glasses on they did not count as disabled.

A second ruling in 2002 narrowed the definition again. Members of Congress later wrote that lower courts had then "incorrectly found in individual cases that people with a range of substantially limiting impairments are not people with disabilities."

**The 2008 law.** President George W. Bush signed a law to reverse those rulings on September 25, 2008. Its title reads: "To restore the intent and protections of the Americans with Disabilities Act of 1990." In its text, members of Congress named the rulings and said they had "narrowed the broad scope of protection intended to be afforded by the ADA." An illness that comes and goes now counts as a disability.

Whether a person is disabled is decided without counting the help of aids. The aids include medicine, artificial limbs, hearing aids, cochlear implants (devices placed in the ear that help deaf people hear), wheelchairs and other aids for getting around, or oxygen equipment. Ordinary glasses and contact lenses are the one kind of aid the law leaves off that list.

**Where disabled people live.** The second fight was over where disabled people live. Lois Curtis and Elaine Wilson were two Georgia women with mental illness and developmental disabilities. They agreed to go into the psychiatric unit, the ward for mental illness, of Georgia Regional Hospital, a state hospital. Mental health workers said each of them was ready to move to a program in the community, and yet each of them remained locked in the state hospital for several years more.

They sued under the ADA. The justices ruled on June 22, 1999, in *Olmstead v. L.C.*, that keeping a disabled person in an institution when the person could live in the community is discrimination. They wrote that "confinement in an institution severely diminishes the everyday life activities of individuals, including family relations, social contacts, work options, economic independence, educational advancement, and cultural enrichment."

**Colorado.** Justice Department lawyers went on enforcing that ruling. They wrote to Governor Jared Polis on March 3, 2022, that Colorado was breaking the ADA by keeping people with physical disabilities in nursing homes "unnecessarily." More than 15,000 Coloradans received care in the state's 200-plus nursing facilities in a year, and "some individuals have remained in nursing facilities for many years with no movement toward discharge."

**The rule struck down.** Justice Department lawyers changed sides in 2026. Officials of seventeen states, Texas first among them, sued over the federal rules for Section 504 in September 2024. By 2026 five states were left in the case: Texas, Alaska, Louisiana, Montana and Florida. They asked the judge to strike the rule that disabled people get services in "the most integrated setting," at home or in their community rather than in an institution.

The Justice Department's Office of Legal Counsel wrote on June 18, 2026, that federal law "does not include an integration mandate." In the lawyers' reading, the law does not require officials to offer disabled people services at home or in their community instead of in an institution. Justice Department lawyers joined the five states on August 31, 2026, in asking the judge to strike the rule. The judge struck it for the whole country on September 23, 2026. The Supreme Court's 1999 ruling and the laws Congress passed still stand.

**Today.** Census Bureau officials reported on July 22, 2026, that 45.8 million Americans, 13.7 percent, had a disability in 2024, about one person in seven. That figure counts the "civilian noninstitutionalized population," everyone except people who live in institutions. The people the *Olmstead* fight is about are left out of it.

### Alice Wong

> **Who:** A disabled organizer who collected disabled people's own accounts of their lives, and who served on the federal council that advises the President on disability.
>
> **When and where:** San Francisco, California, 2002 to 2025.

**She went to the White House by robot.**

Alice Wong founded the Disability Visibility Project in 2014 to collect disabled people's accounts of their own lives, in their own words. She used a wheelchair and breathed through a tracheostomy, a hole cut through the front of the neck into the windpipe, with a short tube held in it.

Her tube was connected to a ventilator, a machine that pushed air through the tube into her lungs so that she kept breathing. Neither the University of California, San Francisco, where she studied and worked, nor the National Council on Disability names the condition behind it.

**At the university.** As a student there she founded the university's Disability Interest Group in 2002. She earned a master's degree in medical sociology, the study of health and illness in society, there in 2004. She worked at three of its research centers: the National Center for Personal Assistance, the Disability Statistics Center and the Community Living Policy Center.

**The robot.** President Barack Obama appointed her to the National Council on Disability, a federal body whose members advise the President and Congress, on January 25, 2013, and she served until 2015. The White House held a reception in the Blue Room on July 20, 2015, for the 25th anniversary of the Americans with Disabilities Act. Wong could not travel to it, so she took part through a robot, a screen on wheels that carried her face and voice into the room.

The White House photographer Pete Souza took a picture of it. Its caption reads: "President Barack Obama greets Alice Wong, Disability Visibility Project Founder and Project Coordinator via robot."

She edited *Disability Visibility: First-Person Stories from the Twenty-First Century* (2020), a collection of essays by disabled writers, and wrote her own life story, *Year of the Tiger: An Activist's Life* (2022). "Disability is part of the greater continuum of diversity, and we need to allow for variation and not get so focused on what is the norm," she said. She died on November 14, 2025, aged 51.

### Transgender Americans and the law, 2020 to 2026

Transgender Americans won one Supreme Court case over jobs between 2020 and 2026 and lost cases over medical care and school sports. The justices also let a military ban and a passport rule take effect while the lawsuits over them went on.

**Bostock.** The justices ruled six to three on June 15, 2020, in *Bostock v. Clayton County*, that "an employer who fires an individual merely for being gay or transgender violates Title VII." Title VII is the part of the Civil Rights Act of 1964 that bans job discrimination because of sex. Justice Neil Gorsuch wrote the opinion. Three fired workers had brought the cases.

Gerald Bostock had worked for Clayton County, Georgia, for ten years and was fired soon after he joined a gay softball league. Donald Zarda, a skydiving instructor in New York, was fired days after he told his employer he was gay. Aimee Stephens worked at a funeral home in Michigan. She had been hired presenting as a man, and six years later she told her employer she meant to "live and work full-time as a woman." Her employer fired her, saying the arrangement "is not going to work out."

**Skrmetti.** Tennessee's lawmakers passed a law that stops doctors from giving puberty blockers or hormones to anyone under 18 for two purposes. One is to help the young person live as a gender other than their sex at birth. The other is to treat distress about the mismatch between the two.

A puberty blocker is a drug that pauses the hormones that start puberty, so the body's changes do not begin while the drug is taken. Hormone treatment gives a person the hormone of the sex they identify as, which changes the body in that direction.

Doctors in Tennessee may still give the same drugs to young people for other reasons, such as puberty that starts very early. The justices ruled that the law could stand on June 18, 2025, in *United States v. Skrmetti*. Chief Justice John Roberts wrote the Court's opinion. Justice Sonia Sotomayor dissented, joined by Justice Ketanji Brown Jackson and in part by Justice Elena Kagan, and Kagan also wrote her own dissent.

**School sports.** Idaho's lawmakers passed the Fairness in Women's Sports Act in 2020, and West Virginia's passed the Save Women's Sports Act in 2021. Both laws say that girls' and women's teams are for students the laws define as female by biology.

Justice Brett Kavanaugh wrote for six justices on June 30, 2026, that Title IX "allows schools to provide separate women's and men's sports teams defined by biological sex." The two laws did not break the promise of equal protection, he wrote. The majority gave "the inherent physical differences between the sexes" as a reason, along with the safety and fairness of the competition. It also wrote that "27 States and various sports-governing bodies have all drawn the same line."

**B.P.J.** The West Virginia student is named in the record only as B.P.J., and the case was brought by her mother, Heather Jackson. Justice Sotomayor described her in dissent as "a transgender girl who wants to live her life consistent with her gender identity." When B.P.J. was 11, Sotomayor wrote, "she sought the opportunity to do what she and so many other children love to do: play sports." She wanted to run on the cross-country and track teams.

Sotomayor wrote that "B. P. J. is the only transgender girl publicly identified in the State who has sought to play sports with other girls" in the five years the ban had been in place. She agreed that the Title IX claim failed. On the equal protection question, she wrote that the trial court should have been allowed to find the facts first.

**Executive orders.** President Donald Trump acted on his first day back in office. He signed an executive order on January 20, 2025, titled "Defending Women From Gender Ideology Extremism and Restoring Biological Truth to the Federal Government." On January 27 he signed an order on the military, and on February 5, 2025, he signed one titled "Keeping Men Out of Women's Sports." National Park Service officials took the words "transgender" and "queer" off the Stonewall National Monument's website in February 2025.

**The military ban.** Defense Department officials issued a military ban on February 26, 2025. It disqualifies "anyone who either has gender dysphoria or has undergone medical interventions to treat gender dysphoria." Gender dysphoria is the medical term for the distress a person feels when the sex recorded at their birth does not match their own sense of their gender.

Commander Emily Shilling, a Navy pilot for nearly twenty years, led a lawsuit by transgender service members, and District Judge Benjamin Settle blocked the ban. The justices let the ban take effect while the case went on, on May 6, 2025. Justices Sotomayor, Kagan and Jackson would have kept it blocked.

**Passports.** The justices let the government's new passport rule take effect on November 6, 2025. Every new passport now shows the holder's sex at birth. "Displaying passport holders' sex at birth no more offends equal protection principles than displaying their country of birth," the order reads. Justice Jackson dissented, joined by Sotomayor and Kagan.

**Chiles v. Salazar.** The justices ruled for Kaley Chiles, a licensed counselor in Colorado who uses only talk therapy, on March 31, 2026. A 2019 Colorado law barred licensed counselors from "conversion therapy" with young people, meaning any practice that tries to change a person's sexual orientation or gender identity. Justice Gorsuch wrote for eight justices that the law, as used against her talk therapy, regulated her speech based on her point of view. The case went back to the lower courts. Justice Jackson dissented alone.

**By September 2026:** The justices had let states ban some medical care for transgender young people and keep transgender girls off girls' teams, and a federal judge had struck down the rule that disabled people get services at home or in their community.

### Standing Rock: the right to protest, 2016 to 2026

Members of the Standing Rock Sioux Tribe and their supporters protested the Dakota Access oil pipeline in 2016, and police officers answered with tear gas, rubber bullets and a fire hose. The route chosen by Energy Transfer, the company building the pipeline, ran under Lake Oahe, less than a mile north of the Standing Rock Reservation. In treaties signed in the 1800s, officials of the United States agreed that the land the route crosses belonged to the Sioux Nation, and the Sioux never gave that land up.

**The police command.** North Dakota's governor, Jack Dalrymple, declared an emergency on August 19, 2016, when about 1,500 people were at the protest and 28 had been arrested. He organized a joint police command. Three police forces took part: the Morton County Sheriff's Office under Sheriff Kyle Kirchmeier, the Stutsman County Sheriff's Office under Sheriff Chad Kaiser, and the Mandan police under Chief Jason Ziegler. Each chief left decisions about using force to his individual officers.

**The bridge.** Officers had blocked the Highway 1806 bridge with two dump trucks chained to concrete barriers and barbed wire. On the night of November 20, 2016, protesters used a semi-trailer truck to drag one dump truck away, and the crowd grew to several hundred. The officers fired tear gas canisters, rubber bullets and bags filled with lead into the crowd. They sprayed protesters with a fire hose from a Mandan fire truck. A lawsuit for the protesters says more than 200 people were hurt.

**Sophia Wilansky.** Sophia Wilansky was hit that night. In 2026 the judges of a federal appeals court set out her account, which they accepted as true for the appeal. Officers Dvorak, Arndt and Hanson fired rounds at her as she ducked behind a metal sheet near the remaining truck, and one hit her arm.

She ran. About 30 yards away, as she bent to pick up a piece of plywood, Officer Jonathan Moll fired a round called an aerial warning munition. "It tore the flesh off her arm, and she fell to the ground," the judges wrote.

A footnote in their ruling describes that round as "a flashbang embedded in a less-lethal bullet," a bullet made to hurt rather than kill. A flash-bang is an explosive device that makes a loud noise and a bright flash of light, and aerial ones are made to be fired above a crowd. Protesters carried her away. Her account says officers laughed and congratulated Moll, and the officers dispute that. "Her left hand and forearm are permanently and severely injured," the judges wrote.

**No one held responsible.** No officer or police agency was held responsible for the injuries that night. Judges of the federal appeals court ruled against the injured protesters in 2023, and again on June 24, 2026, in Wilansky's case. They said that in 2016 the law had not yet made it clear that firing at a crowd to drive it off was a "seizure" under the Constitution, a way of stopping or holding a person by force.

That mattered because of a rule called qualified immunity. It shields government officials from being sued unless the right they broke was already clearly established, meaning already made clear in the law.

Police made hundreds of arrests at the protests. A Morton County judge, Allan Schmalenberger, threw out many trespass cases, charges of going onto private land without permission, because no one had told the protesters to leave.

**The pipeline.** Federal officials changed their decision more than once. The Army's Assistant Secretary for Civil Works refused permission to cross under the lake on December 4, 2016. President Donald Trump ordered the Army on January 24, 2017, to approve the pipeline "in an expedited manner," quickly. Army officials gave permission on February 8, 2017, and oil has flowed since June 2017.

A federal judge, James Boasberg, ruled in 2020 that Army officials had broken the law by approving the crossing without a full study of its effects. The pipeline kept running for about five years while the Army Corps of Engineers did the study. Corps officials finished it in December 2025, and in May 2026 Brigadier General William C. Hannan signed a decision to grant permission again.

Tribal leaders asked the judges of a federal appeals court to drop the tribe's own appeal in June 2026, and the judges did. "We will continue to fight for our homelands and the promises the United States made to our Tribe in Treaty," Standing Rock Chairman Steve Sitting Bear said in December 2025.

**Greenpeace.** Energy Transfer's lawyers sued the environmental group Greenpeace over the protests. A jury in Morton County ordered Greenpeace to pay about $667 million on March 19, 2025, and Judge James Gion cut the amount to $345 million. Greenpeace officials said the group had six employees at the camps and called the lawsuit an attempt to punish the group for supporting the protests. "The oil is still flowing. The pipeline hasn't been shut down," Nola Taken Alive, a member of the Standing Rock tribal council, said in September 2026.

### The DREAM Act and DACA, 2001 to 2026

Young people who had been brought into the United States as children, without legal permission to live there, organized from 2010 for a way to become citizens, and members of Congress never passed one. Senator Richard Durbin of Illinois and Representative Howard Berman of California first introduced the DREAM Act in 2001. It would have let these young people become citizens after two years of college or military service.

**The walk.** Four students from Miami Dade College, Gaby Pacheco, Carlos Roa, Felipe Matos and Juan Rodriguez, set out on January 1, 2010, to walk 1,500 miles from Miami to Washington. Three of them were in the country without legal permission. They said so in public all along the way, which put them at risk of arrest and deportation. They gathered 30,000 signatures.

A Secret Service agent refused to take their petition on April 28, 2010, and White House officials refused them a meeting with President Barack Obama. They walked the last four miles to the White House on May 1, 2010. The DREAM Act came up in the Senate on December 18, 2010. Fifty-five senators voted to end debate and 41 voted against. Sixty votes were needed, so the bill failed.

**DACA.** Janet Napolitano, the Secretary of Homeland Security, announced a program called Deferred Action for Childhood Arrivals, or DACA, on June 15, 2012. It made no one a citizen. People who had arrived as children could apply if they met rules about age, schooling and criminal records. Those accepted could ask the government to put off deporting them for two years at a time, and could get permission to work. About 700,000 people signed up, by the Supreme Court's count.

Attorney General Jeff Sessions wrote in September 2017 that the program should end, and the acting Secretary of Homeland Security, Elaine Duke, ended it. DACA holders, universities and states sued. The justices of the Supreme Court ruled five to four on June 18, 2020, that federal officials had ended the program unlawfully, so DACA stayed.

**Texas.** Officials of Texas and other states also sued. A federal appeals court ruled in January 2025 that DACA's work permits were unlawful in Texas. By July 2026 the judge in Texas, Andrew Hanen, had not issued the order that would carry that out.

**The numbers.** Agents of ICE, a federal immigration agency, arrested 261 DACA holders and deported 86 of them in the first year of President Donald Trump's second term, by the count of FWD.us, an immigration advocacy group. About 455,000 people held DACA on March 31, 2026, by government figures reported by the National Immigration Forum, another immigration advocacy group. Federal immigration officials were renewing permits and not approving new ones.

### Federal agents kill two citizens in Minneapolis, 2026

Federal officials ran a large immigration operation in Minneapolis in early 2026, called Operation Metro Surge. During it, federal immigration agents shot and killed two American citizens, Renée Macklin Good on January 7 and Alex Pretti on January 24. The *Star Tribune* named ICE officer Jonathan Ross as the man who shot Good. ProPublica named Border Patrol agent Jesus Ochoa and Customs and Border Protection officer Raymundo Gutierrez as the agents who shot Pretti.

Federal officials said Good had used her car as a weapon, and local officials said video contradicted that. Federal officials called Pretti a domestic terrorist, and NPR reported that video contradicted their account of his death.

At the Pretti shooting, federal officials physically blocked state investigators from the scene. Hennepin County Attorney Mary Moriarty and Minnesota Attorney General Keith Ellison sued for the evidence in March 2026 and received it in June and July. Acting Attorney General Todd Blanche said there would be no civil rights investigation into Good's killing. As of September 2026 no one had been charged in either death.

**The three questions, answered**

- How did people without power get the people in power to listen? They signed petitions, printed pamphlets and spoke to crowds, and later they planned test cases, boycotted, marched, sat in and filmed the police, from the Germantown protest of 1688 to Darnella Frazier's video in 2020.
- What did organizing cost the people who did it? Their jobs, their homes and their freedom, and sometimes their bodies and their lives. A prison doctor fed Lucy Burns by force through a tube, state highway patrolmen had Fannie Lou Hamer beaten in a Mississippi jail, Byron De La Beckwith shot Medgar Evers in his driveway, and Klansmen killed four girls with a bomb in a Birmingham church.
- Can a right that has been won be taken away again? Yes. New Jersey's lawmakers took the vote from women and free Black men in 1807, members of Congress took Utah women's vote in 1887, and the justices of the Supreme Court cut back the Voting Rights Act in 2013 and 2026 and ended the right to an abortion in 2022.

**What changed:** In 1688 four men's protest against slavery went nowhere, and by 2026 the laws that once shut women, Black Americans, gay Americans and disabled Americans out of voting, schools, marriage and public buildings had been struck down or rewritten, while the fights over several of them went on.

**Five dates to keep**

- April 18, 1688: Four men at Germantown sign a protest against slavery.
- July 19 and 20, 1848: The Seneca Falls convention votes to demand the vote for women.
- August 26, 1920: The 19th Amendment becomes part of the Constitution.
- May 17, 1954: The justices rule in *Brown v. Board of Education*.
- August 6, 1965: President Lyndon Johnson signs the Voting Rights Act.

**Not known:** How many people white Tulsans killed in Greenwood in 1921, because the attackers hid the bodies, and credible estimates run from fifty to three hundred.

**Where to go:** Haverford College, in Pennsylvania, keeps the 1688 Germantown protest, the paper this chapter began with.

**Next:** Chapter 26, Health, Disease, and Medicine. It follows illness and healing in America: epidemics, doctors, hospitals and the fight over public health.
