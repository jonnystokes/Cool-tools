# Chapter 37: Holidays

**Chapter 37 of 37 · Holidays · 10 eras · about 95 minutes**

**Many American holidays exist because someone asked for a day and kept asking, and the arguing over some of them is not over.**

In May 1877 a woman of 88 in Philadelphia had a helper write a letter for her, because her eyes were too weak. Her name was Sarah Josepha Hale. For about thirty years she had been asking governors and presidents to make Thanksgiving one day for the whole country. President Lincoln had proclaimed it in 1863. She was still asking Congress for a law that made the last Thursday in November a legal holiday. She died two years later. Congress passed that law in 1941.

Most of the days in this chapter were made that way. Someone asked for a day, and someone else said no, often for years. The chapter starts with the ceremonies the Native nations keep for corn, salmon and the winter sun, and with the Spanish, French and English colonists who each held a "first Thanksgiving" of their own. It follows the days Black Americans made for themselves when white Americans' holidays left them out, from election days in Connecticut to Juneteenth in Texas. It ends with the fights still going on over Columbus Day, King's day and Juneteenth. Watch for two things as you read: who had the power to name a day, and who kept a day without anyone's permission.

**Three questions this chapter answers**

- Who decided when Americans would give thanks, and why did it take until 1941 to fix the date?
- Which days did Black Americans make their own, from election days to Juneteenth?
- Why did President Harrison proclaim the first Columbus Day in 1892, and why do some states no longer keep it?

**Five minutes?** Read "Juneteenth, 1865" in 1850 to 1900. The Jack Yates story follows it.

**Can skip:** "Places named for holy days", "Washington's birthday", "Pinkster banned in Albany, 1811", "Columbus Day, 1905 to 1937". The chapter still makes sense without them.

## Before 1500

**Era 1 of 10 · Before 1500 · about 6 minutes**

The Native nations marked their year with ceremonies, and each one came at its own time. Some came when a group of stars rose, or when the sun reached the end of its path along the horizon. Others came when the corn ripened or when the salmon swam back up the river. At many of them, people gave thanks for food as it came in: maple sap, strawberries, the first ripe corn, the first salmon.

The oldest written descriptions of the Green Corn Ceremony date from the 1700s, and outsiders wrote them. The nations have written their own since, and they still hold many of these ceremonies today. The Wampanoag writer Nancy Eldredge says that her people and other Native peoples of the Northeast have given thanks this way "from time immemorial," which means since before anyone can remember. The five ceremonies below come from five parts of the land, the Northeast first and Hawaii last.

### Who sets the dates in the Northeast

**The Faith Keepers.** On the Onondaga Nation's land just south of Syracuse, New York, men and women called Faith Keepers decide when each ceremony takes place. The Onondaga are one of the Haudenosaunee nations. They list seven ceremonies in their year: Midwinter, Maple Sap, Planting, Bean, Strawberry, Green Corn and Harvest. The Faith Keepers go by the seasons and the moon, so the dates change from year to year. Midwinter lasts 21 days, and on each day people give thanks for different things.

Haudenosaunee people often start and end their meetings with the Thanksgiving Address. They also call it the Words That Come Before All Else. The speaker gives thanks to the people, the earth, the waters, the fish and the plants, one at a time. Then come the food plants and the medicine plants, and the thanks go on from there. Each part ends with the words "Now our minds are one." An English translation of the Mohawk version was published in 1993.

Farther east lived the Wampanoag. Nancy Eldredge, a Nauset Wampanoag writer, wrote about her people's thanksgiving ceremonies in 1998. They held one in early spring, for a good growing season, and one in the fall, for the harvest. They also gave thanks for strawberries and cranberries as each one ripened, through the thirteen moons of their year. The Wampanoag Tribe of Gay Head (Aquinnah), on the island of Martha's Vineyard, still holds Cranberry Day each October. The day opens with a greeting at sunrise. People pick cranberries, share a meal and set aside a share for the elders.

### Why every fire in a Creek town went out

Once a year, every fire in a Muscogee (Creek) town went out. The Muscogee and other nations of the Southeast held the Green Corn Ceremony in midsummer, when the first corn was ripe. It lasted four or eight days. Men fasted, which means they went without food, and women, children and old people could eat certain foods. During the ceremony, people forgave every crime except murder.

**What Bartram saw.** William Bartram, a Philadelphia man who studied plants and animals, traveled through Creek towns in the 1770s. In a book printed in 1791, he wrote that the Creek had a feast for almost every month of the year. He called the Green Corn Ceremony the busk and said it was the most important one. Each town held its own busk in August, when its own corn was ripe.

Families made new clothes, pots and pans, and swept their houses and the whole town. Then everyone piled the worn-out clothes and the old grain in one heap and set it on fire. On the fourth morning, the high priest made a new fire by rubbing dry wood together, and every house took its fire from it. Then the women brought in the new corn, and people danced in the square at night.

Accounts differ on how long the men fasted. Bartram gives three days. Eric Bowne, writing for the Encyclopedia of Alabama, gives one and a half to two days. Three men who saw the ceremony in the 1700s wrote early accounts of it: James Adair in the middle of the century, Bartram in the 1770s, and Benjamin Hawkins, who wrote about the Creek country in 1798 and 1799. Creek and Yuchi towns in Oklahoma still hold the ceremony at their stomp grounds, the grounds each town keeps for it.

### How a Sun-priest sets the calendar

In Pueblo towns today, a man called the Sun-priest watches where the sun comes up over the horizon. He usually watches at sunrise, from a quiet spot not far from the town. (*Pueblo* is the Spanish word for a town, and the Pueblo peoples of the Southwest get their name from the towns they live in.) The point where the sun rises moves along the horizon through the year, so from his sightings he can tell the time of year. From them he sets the planting calendar and the dates of the ceremonies.

The Hopi of northeastern Arizona begin their year of ceremonies with the Soyal ceremony at the winter solstice in December. The winter solstice is the shortest day of the year. After Soyal, each village holds a ceremony about once a month until the Niman, or Home Dance, in late July.

### The First Salmon Feast on the Columbia River

The Yakama, Umatilla, Warm Springs and Nez Perce peoples say that when the Creator was about to bring people onto the earth, Salmon offered his body to feed them. These peoples fish for salmon in the Columbia River and its branches in the Northwest. Each spring, before the fishing season opens, they hold a First Salmon Feast.

At the feast, drummers sing, and a bell rings for everyone to stand for a prayer song. People bless water and drink it first. Then they eat the salmon and the other foods. At Celilo, on the Oregon bank of the Columbia, people hold the feast in the longhouse, a long building where the community gathers for ceremonies. There the feast usually falls on the second weekend of April.

### Makahiki, the season when chiefs could not make war

Hawaiians kept their own calendar long before the islands became American land. Their new year began when the Pleiades, a small group of stars they call Makaliʻi, rose at sunset in late October or early November. The season that followed was called Makahiki. Kaʻanoʻi Walk of the Kamehameha Schools gives mid-November as the usual start of Makahiki and late January or February as its end. (The islands became American land in July 1898, when members of the US Congress voted to take them over and President William McKinley signed their resolution on July 7.)

The Hawaiian historian David Malo was born in about 1793. He wrote that Makahiki lasted four months. Priests carried an image of the god Lono around the island. At the edge of each district, the local chief handed over the taxes the people owed to the king. They paid in goods: pigs, taro, sweet potatoes, feathers, kapa cloth and mats.

Taro is a plant with a starchy root that Hawaiians cooked and ate, and kapa is cloth made by beating tree bark thin. Chiefs could not make war on each other during the season. People held races, boxing and wrestling matches, and games of skill.

## The 1500s

**Era 2 of 10 · The 1500s · about 5 minutes**

Spanish and French colonists brought the Christian church year to a few places on the coast of Florida and along the Rio Grande. The church year is a calendar of holy days: Sundays, Easter, Christmas and the feast days of saints, the days kept each year to honor holy people. The colonists named places after those days. When they landed, they held church services to give thanks.

Today people in St. Augustine, in Jacksonville and in Texas each call a different one of those services the "first Thanksgiving." The national holiday came from English days of thanksgiving instead, as the National Park Service's own page on St. Augustine says. Across the rest of the land, the Native nations kept their own ceremonies.

### Places named for holy days

Juan Ponce de León claimed the coast of what is now Florida for Spain on April 2, 1513. It was the Easter season, which Spanish speakers called *Pascua Florida*. He named the land *La Florida* after it.

Pedro Menéndez de Avilés sighted the same coast on August 28, 1565, the feast day of Saint Augustine. Menéndez named the town he founded St. Augustine.

### Two services of thanks on the Florida coast, and the killings that followed

French Protestants, Christians whose churches had broken away from the Catholic Church, built Fort Caroline in June 1564, near what is now Jacksonville. The French called these Protestants Huguenots. The land belonged to the Timucua people. The Huguenots' leader, René de Laudonnière, wrote that on June 30, 1564, he had his people gather on the beach. There he ordered them to sing aloud and give thanks to God for their safe arrival.

Menéndez and about 800 Spanish settlers came ashore at Seloy, a Timucua town, on September 8, 1565. A priest, Father Francisco López de Mendoza Grajales, said a Mass of thanksgiving, the main church service of the Catholic Church. Afterward, the priest wrote, Menéndez "had the Indians fed and dined himself."

The historian Michael Gannon called this Mass and meal "the first community act of religion and thanksgiving in the first permanent European settlement" in North America, and the National Park Service repeats his words. The Mass came 56 years before the English colonists' harvest meal at Plymouth, in New England. The same Park Service page states that the day "did not become the origin of a national annual tradition."

**What the Spanish did next.** Within five weeks of the Mass, Menéndez's soldiers killed hundreds of French men, many of them after they had surrendered. They captured Fort Caroline on September 20, 1565, twelve days after the Mass, and killed most of the men there. They spared the women and children and shipped them to Havana, in Cuba.

Shipwrecked French survivors then surrendered at an inlet south of St. Augustine, in two groups. Menéndez wrote that his men tied the hands of the first group behind their backs and "put them to the knife," which means they stabbed them to death. The second group came in with the French commander, Jean Ribault. By the Park Service's count, the soldiers killed 111 men from the first group, in late September, and 134 from the second, in October. The Spanish named the inlet Matanzas, which means "slaughters."

**Two counts.** Menéndez's own letter to King Philip II of Spain records different numbers, and Chapter 22 tells the killings in full. He wrote that his men cut the throats of 132 men at Fort Caroline, and of 10 more the next day. He wrote that Ribault came in with up to 70 men, and that he spared only five of them: two young men of about 18, and three musicians who played the fife (a small flute), the drum and the trumpet. He killed Ribault and all the rest.

In the same letter, dated October 15, 1565, Menéndez told the king why he had killed them. He wrote that they "spread the Lutheran sect," which meant the Protestant faith. He also wrote that they had built their fort "without permission of Your Majesty."

### The thanksgiving Texans claim, 1598

Juan de Oñate led about 500 people north across the Chihuahuan Desert to start a Spanish colony in New Mexico. They were soldiers, colonists, wives and children. They brought about 7,000 farm animals. The crossing took about 50 days. They reached the Rio Grande near what is now San Elizario, Texas.

Oñate ordered a day of thanksgiving after ten days of rest, on April 30, 1598. Franciscan friars, men who had promised their lives to prayer and service in the Catholic Church, said Mass. The colonists ate game they had hunted and fish that Manso people, who lived nearby, brought them. One of the colonists wrote, "We built a great bonfire and roasted the meat and fish." Then Oñate read out a claim to the land for King Philip II. The claim is called La Toma, "the taking."

Some Texans call this day the first Thanksgiving. Others have made the same claim for a celebration held by Francisco Vázquez de Coronado's men in Palo Duro Canyon in 1541. The *Texas Almanac* states that this claim was later questioned.

### What John White painted at Secotan, 1585

The English artist John White visited Secotan, a town in what is now North Carolina, in July 1585. Its people spoke an Algonquian language, one of a family of related Native languages. White painted a large ceremony there. Men and women sang and danced around a circle of wooden posts. Some shook gourd rattles, and some carried leafy branches.

Thomas Hariot, an Englishman on the same voyage, wrote a description of the scene. He wrote that the posts were carved with heads like the faces of nuns in their veils. He wrote that the dancers dressed in "the most strange fashion they can devise" and had marks on their backs to show which place they came from.

Encyclopedia Virginia describes the ceremony as "perhaps connected to the corn harvest." The records that survive do not say what the ceremony was called or what it meant to the people of Secotan.

## The 1600s

**Era 3 of 10 · The 1600s · about 9 minutes**

John Smith and his men kept Christmas in a Native town in Virginia in the winter of 1608 to 1609. Fifty years later, in 1659, the lawmakers of Massachusetts Bay made keeping Christmas a crime. English colonists did not agree about holidays. The Puritans, English Protestants whose leaders ran the New England colonies, kept Sundays as holy days but did not keep Christmas, because nothing in the Bible told Christians to keep it.

When a drought threatened the crops, Puritan leaders called a day of fasting and prayer. After rain, a good harvest, the safe arrival of ships or a victory, they called a day of thanksgiving, spent in church.

In the fall of 1621, the colonists at Plymouth held a harvest meal. About ninety Wampanoag men joined them, and the meal went on for three days. Americans now call it the first Thanksgiving. Nobody in print gave it that name until 1841.

### Christmas and thanksgiving in Virginia

John Smith and his men were caught by bad weather at Kecoughtan, a Native town in Virginia, in the winter of 1608 to 1609. They stayed six or seven days, over Christmas. Smith wrote that they "were never more merry." He wrote that they had never eaten more good oysters, fish, meat, wild birds and bread. He also wrote that he had never had better fires in England than in the dry, smoky houses of Kecoughtan.

**Berkeley Hundred.** The ship *Margaret* landed 35 settlers and their captain, John Woodlief, at Berkeley Hundred on the James River on December 4, 1619. The land there was home to Native nations, among them the Chickahominy, the Paspahegh and the Weyanock.

Before the settlers left England, a group of men there called the Berkeley Company had given them ten written orders. The first order said the day of arrival "shall be yearly and perpetually kept holy as a day of Thanksgiving to Almighty God," and perpetually meant forever. The settlers held a service of thanks that day. The records do not show whether they held it again in the next two years.

Powhatan men attacked the English settlements along the James River on March 22, 1622. Their leader, Opechancanough, meant to stop the English from taking more Powhatan land, as Chapter 22 describes. Powhatan fighters killed eleven people at Berkeley. In 1958 Senator John Wicker, the Jamieson family and descendants of John Woodlief began holding the Berkeley thanksgiving again.

### The harvest meal at Plymouth, 1621

The Plymouth colonists built their town in 1620 on the site of Patuxet, a Wampanoag town. An epidemic, a disease that spread through many people at once, had killed most of the people of Patuxet between 1616 and 1619. Of the 102 people who came on the *Mayflower*, 53 were still alive by the fall of 1621: 24 men, 5 women and 24 children and teenagers.

Only two people who were there wrote about that fall's harvest. One was Edward Winslow, in a letter of December 1621 that was printed in London in 1622. The book it was printed in is now called *Mourt's Relation*. The other was William Bradford, the governor, who later wrote a history of the colony that runs to the year 1650.

Winslow wrote that after the harvest, the governor sent four men to hunt birds "so we might after a special manner rejoice together." Massasoit, the leader the English called the Wampanoag's "greatest king," came "with some ninety men." The English "entertained and feasted" them for three days. The Wampanoag men went out, killed five deer, and gave them to the governor and other leaders.

Massasoit's own name was Ousamequin. The two sides had made an alliance earlier that year. To the Wampanoag, an alliance was a spoken agreement sealed by giving gifts. Historians at Plimoth Patuxet Museums think Ousamequin's visit was probably a show of strength, and that the two sides needed to renew such agreements, perhaps regularly, to keep the terms alive in memory.

Neither Winslow nor Bradford called the meal a thanksgiving. To the colonists, a thanksgiving was a day of prayer in church.

Later Americans called the Plymouth colonists the Pilgrims. By 1816 New Englanders already credited the Pilgrims with starting their yearly thanksgiving. That year a writer in the *Salem Gazette* called it the festival that "our Pilgrim forefathers" began. In 1841 a Boston minister, Alexander Young, printed Winslow's letter. His note read: "This was the first Thanksgiving, the harvest festival of New England." The Plimoth Patuxet Museums page identifies that note as the first time anyone called the 1621 meal the first Thanksgiving.

### William Bradford

> **Who:** Governor of Plymouth Colony, who wrote the colony's history, *Of Plimoth Plantation*.
>
> **When and where:** Plymouth, in what is now Massachusetts, 1621 to 1623.

**Christmas Day 1621: the governor took away the bat and the ball.**

On Christmas Day 1621, Bradford called the men of Plymouth out to work. Most of the men who had just arrived on the ship *Fortune* said that working on Christmas went against what they believed was right. Bradford let them stay behind. At noon he came back and found them playing games in the street. Some were "pitching the bar," a contest to see who could throw a heavy bar or pole the farthest. Others were playing stool-ball, a game played with a ball, a bat and a stool.

Bradford took their equipment away. He told them that if keeping the day was a matter of faith, they could keep it by praying in their houses. He said there would be no games or noisy fun in the streets.

In 1623 no rain fell on Plymouth from the third week of May until the middle of July. Bradford wrote that the corn began to wither. The colonists held what Bradford called "a solemn day of humiliation," a day set aside for "humble and fervent prayer." Rain came, and the harvest was good. Then they held a day of thanksgiving.

### Fast days and thanksgiving days in New England

The Puritan leaders of New England called a fast or a thanksgiving when something happened. Each one was a day of church services, so the dates changed from year to year. In Massachusetts Bay, the members of the General Court, the colony's lawmakers, set these days together with the elders who led the churches.

**One example.** The lawmakers asked the elders in September 1638 to keep a thanksgiving on the last Thursday of the eighth month. The colony's lawmakers counted the months from March, so their records call August "the 6th Month." So the eighth month was October. The thanks were for the many ships that had arrived safely that year, for the good weather in the spring and for the ripening harvest.

### A thanksgiving for a massacre, 1637

The Massachusetts Bay colonists held a day of thanksgiving in 1637 for a victory in which colonists killed hundreds of Pequot people. Before dawn on May 26, 1637, Connecticut colonists under Captain John Mason, with Mohegan and Narragansett allies, attacked the Pequot town at Mystic. The town had a wall of wooden posts around it. Mason's men set it on fire and shot the people who tried to escape. They killed between 400 and 700 Pequot, most of them old men, women and children, by the count in the Mashantucket Pequot Tribal Nation's own history.

**The order.** That August the lawmakers asked the magistrates, the colony's judges and officials, to talk with the church elders about a day of thanksgiving for the soldiers' return. They also asked each town to hold a feast for its soldiers. Later that year they ordered that October 12, 1637, be kept as a day of thanksgiving to God.

The order lists the reasons for the thanks: "subdewing the Pecoits," meaning defeating the Pequot, and "bringing the soldiers in safety." It also lists "the successe of the conference" and good news from Germany. "The conference" was most likely the meeting of ministers at Newtown, now Cambridge, from August 30 to September 22, 1637. The ministers met to settle a quarrel over church teachings.

**A claim that spread.** William B. Newell, a Penobscot scholar, said that "the first official Thanksgiving Day commemorated (marked the memory of) the massacre of 700 Indian men, women and children during one of their religious ceremonies." A massacre is the killing of many people who cannot defend themselves. Newell was described as a former head of anthropology, the study of human peoples and their ways of life, at the University of Connecticut. Jeremy Bangs, writing for the History News Network in 2005, answered that Newell never headed that department and that Plymouth Colony took no part in the attack.

**Known:** The court records show that the lawmakers set October 12, 1637, as a day of thanksgiving for the victory over the Pequot, and set other days for other reasons, such as the 1638 day for the ships, the spring weather and the harvest.

**Not known:** No record of the attack mentions a ceremony at Mystic that morning.

### Christmas made a crime, 1659 to 1681

**The law.** The lawmakers of Massachusetts Bay passed a law against Christmas on May 11, 1659. Anyone found "observing any such day as Christmas or the like, either by forbearing of labor, feasting, or any other way" had to pay a fine of five shillings. Forbearing of labor meant not working, and twenty shillings made an English pound.

The Puritans saw Christmas as a season of too much eating and drinking, with nothing in the Bible behind it. The minister Increase Mather called Christmas "a profane and superstitious custom," meaning one that was not holy and rested on false beliefs about magic and luck.

In 1681, under pressure from King Charles II's government in London, the lawmakers canceled the Christmas law. People in Massachusetts went back to keeping Christmas slowly. By the 1750s some hymn books in Massachusetts had Christmas songs in them. By 1760 most almanacs, small books printed each year with a calendar, marked December 25 as Christmas. Families there began to make it a home holiday in the early 1800s.

### Ceremonies banned in New Mexico

In New Mexico, Spanish church leaders and governors tried to end the Pueblo people's own ceremonies. From 1656 to 1665, the head of the Franciscan friars there, Alonso de Posada, forbade those ceremonies. He ordered the friars to break into the kivas, the underground rooms where the Pueblo people worship. There the friars were to burn the masks and take or destroy the sacred objects.

**Treviño's arrests.** Governor Juan Francisco Treviño had 47 Pueblo religious leaders arrested in 1675 for practicing sorcery, which means using magic to do harm. Spanish officials sentenced four of them to be hanged. They hanged three, and the fourth killed himself. The officials shamed the rest, whipped them in public and sent them to prison.

Then a force of Pueblo men went to Santa Fe, and Treviño freed the prisoners. One of the men freed was Po'pay, who had been whipped in public. Cliff Fragua's statue of Po'pay shows the scars of the whipping on his back. In August 1680 he led the Pueblo Revolt, and the Pueblo people drove the Spanish out of New Mexico for twelve years.

## 1700 to 1750

**Era 4 of 10 · 1700 to 1750 · about 4 minutes**

Boston boys paraded every November 5 with figures of the Pope, and New York's enslaved and free Black people gathered each spring for Pinkster, a holiday the Dutch had brought. Between 1700 and 1750, people in different colonies kept different days, and many of those days came from Britain. New England governors ordered days of thanksgiving and days of fasting by printed order. In 1746 a Massachusetts governor banned ordinary work on a day of thanksgiving. In New England, Black communities began choosing their own governors and kings.

### Thanksgiving and fast days by the governor's printed order

In Connecticut and Massachusetts, the governor named the days of thanksgiving and the days of fasting. Printers published his order on a large single sheet of paper called a broadside.

Governor Gurdon Saltonstall of Connecticut set Wednesday, November 8, 1721, as a day of thanksgiving, in an order dated October 14. Smallpox, a disease that passes from person to person and can kill, was then spreading in Boston. In his order, Saltonstall gave thanks that the sickness had not reached Connecticut. He also gave thanks for the peace, for that year's harvest and for the birth of a prince in the royal family, Prince William Augustus.

Governor William Shirley of Massachusetts ordered a thanksgiving for Thursday, August 14, 1746. Soldiers under the Duke of Cumberland had defeated rebels in Scotland. Shirley called on people to go to worship that day. His order said, "all servile Labour is prohibited on said Day." Servile labor meant ordinary work. Massachusetts governors also ordered fast days. Jonathan Belcher ordered one in 1734, and Spencer Phips ordered another in 1745.

### Why Boston boys burned the Pope every November 5

Pope's Night began with a plot in England. In the early hours of November 5, 1605, men loyal to King James I searched the cellars under Parliament, England's lawmaking body, in London. They found a man named Guy Fawkes there, in a cloak and hat, with boots and spurs, carrying fuses and matches. He and a group of other English Catholics had planned to kill the king when Parliament opened.

The members of Parliament then passed a law for a public thanksgiving every November 5. In New England the day became Pope's Night, and crowds burned figures of the Pope, the head of the Catholic Church.

In Boston, young men and older boys built wagons that carried moving figures of the Pope, devils and political enemies. One figure was the Stuart Pretender, a man who claimed he should be king of Britain. Some of the young men dressed as devils in tall pointed caps, and some dressed as women. They paraded through town and asked homeowners for money. The night ended with a meal outdoors and a bonfire.

Boston had two gangs, one from the North End and one from the South End. Each gang built its own Pope wagon, and on Pope's Night the two gangs fought each other. The winners burned the losing gang's figures on Copp's Hill or on the Common, a large open field in the middle of Boston.

The printer Isaiah Thomas, born in 1749, remembered the crowds as a boy. They blew on conch shells, beat on the sides of houses with clubs and shouted "North end forever" or "South end forever." Thomas was once knocked out by a brick. Another Boston boy, Henry Knox, once held up a corner of a Pope wagon. Knox later became a general in the Revolution.

### Pinkster in New York

Pinkster is the Dutch name for Pentecost, a Christian feast held seven weeks after Easter. Dutch settlers brought it to their colony of New Netherland in the 1620s. That colony later became New York. The oldest known written account of Pinkster appeared in the *New-York Weekly Journal* in March 1737. It describes a Pinkster gathering in the fields outside New York City, with African-style musical instruments.

The celebration lasted several days. Enslavers gave enslaved men and women time off at Pinkster. Many traveled from farms into the city to see family members who lived some distance away. They sold berries, herbs, drinks, oysters and sassafras bark, which people boiled to make tea.

### Black governors and kings in New England

Black communities in New England held elections of their own. Where white men elected their governor, as in Connecticut and Rhode Island, Black communities elected a Black governor. Where the king of England appointed the governor, as in Massachusetts and New Hampshire, they elected a king.

The earliest Black governor whose name survives is Hercules, of New London, Connecticut, from about 1749. He is known from the gravestone of his wife, Florio. The elections in Connecticut may have begun that year.

In Connecticut the Black election came the day after the white men's election, and the celebration went on for a week. Some people borrowed clothes from the men and women who enslaved them. The enslaver of the man who won was expected to help provide the food, the decorations and the liquor. People ate gingerbread and thick election cakes full of fruit, and drank rum. The parades had gunshots, tambourines, banjos, fiddles and drums, and some marchers spoke African languages.

## 1750 to 1800

**Era 5 of 10 · 1750 to 1800 · about 10 minutes**

Americans held the first planned Fourth of July celebrations on July 4, 1777, the first anniversary of independence. Within a few years they also celebrated George Washington's birthday. Neither day was a national holiday yet. The Continental Congress was the meeting of men sent by each state to lead the Revolution. Its members asked Americans to keep days of thanksgiving on dates they chose. Later President Washington did the same. None of them set a yearly date.

Older customs changed during the Revolution. Boston's crowds turned Pope's Night into a protest against British taxes, and General Washington banned it in his army. At Washington's own plantation, the evidence points to four days off at Christmas for most enslaved workers. The Washingtons made the enslaved people who worked in the house do extra work, serving their guests.

### Pope's Night turns into protest, 1764 to 1775

A Pope wagon in Boston ran over and killed a boy named Brown on Pope's Night, November 5, 1764. Accounts give his age as five to nine. The records that survive do not give his first name or say who was driving. The boy died early in the day. The parades and the fight between the gangs went on that night.

**The Stamp Act crowds.** Crowds in Boston protested the Stamp Act, a British tax on printed paper, in August 1765. They used the customs of Pope's Night: they hanged and burned figures, marched through town and lit bonfires. They broke into three or four large houses and smashed the furniture. Ebenezer Mackintosh, a shoemaker and the captain of the South End gang, led the crowd on August 14. On August 26 a crowd attacked the house of Lieutenant Governor Thomas Hutchinson. Afterward Sheriff Stephen Greenleaf arrested Mackintosh, then let him go.

That fall Mackintosh made a deal with Henry Swift, the captain of the North End gang. A Boston printer, John Boyle, wrote it down: "A Union established between the South and North End Popes." On Pope's Night the two gangs joined as one, and they sat down to a dinner that wealthy merchants paid for.

**Washington's order.** General George Washington ordered his soldiers on November 5, 1775, not to keep "that ridiculous and childish Custom of burning the Effigy of the pope." An effigy is a figure made to look like a person. He wrote that the custom was improper "at a time when we are soliciting (asking for), and have really obtained the friendship and alliance of the people of Canada."

Pope's Night ended in Boston during the Revolution. By one account it ended in the mid-1770s. By another, Boston crowds kept it again in 1776 and 1777 and stopped when soldiers from France, a Catholic country, arrived to fight on the American side.

### The first Fourth of July, 1777

The members of the Continental Congress voted for independence on July 2, 1776. The next day John Adams wrote to his wife, Abigail. He wrote that July 2 would be celebrated as "the great anniversary Festival" and that the day "ought to be solemnized with Pomp and Parade, with Shews, Games, Sports, Guns, Bells, Bonfires and Illuminations from one End of this Continent to the other." By solemnized he meant marked with ceremony, shews were shows, and illuminations were candles lit in the windows. The members of Congress formally approved the Declaration of Independence on July 4, and that is the date Americans celebrate.

Crowds greeted the public readings of the Declaration in July 1776 with parades, bonfires and gunfire. The first planned Fourth of July celebrations came a year later, in Philadelphia and in Boston.

**The first planned Fourth.** In Philadelphia on July 4, 1777, the armed ships in the Delaware River were hung with flags. At one o'clock each ship fired thirteen cannon, one for each state. That night bells rang and fireworks went up over the city's common, and people lit candles in their windows. A Philadelphia newspaper, the *Pennsylvania Evening Post* of July 5, 1777, describes the day. In 1781 Massachusetts lawmakers made the Fourth of July an official state holiday, the first state to do so.

### Henry Wight

> **Who:** A minister and Revolutionary War veteran who started the Fourth of July celebration in Bristol, which the town still holds.
>
> **When and where:** Bristol, Rhode Island, from 1785.

**The oldest Fourth of July that never stopped: Bristol, since 1785.**

Henry Wight began the yearly Fourth of July ceremony in Bristol, Rhode Island, in 1785, when he led the town's first Patriotic Exercises. In a speech that day he honored the veterans of the war and celebrated the new country's freedoms. The town has held the ceremony every year since, and the town government calls it the oldest Fourth of July celebration in the United States that has never stopped.

Wight had left his studies at Harvard to serve in the Revolutionary War. One account says he served as a soldier. Another says he served as a surgeon, a doctor who operates on the body. In January 1785 the 36 members of the First Congregational Church of Bristol hired him as their minister.

**Whose land Bristol stands on.** Bristol stands on Mount Hope, called Montaup in the Pokanoket language, in the homeland of the Pokanoket Wampanoag. The Wampanoag leader Metacom, whom the English called King Philip, had his base there and led a war against the New England colonies in 1675 and 1676, called King Philip's War. On August 12, 1676, in an ambush at Mount Hope led by the English captain Benjamin Church, a Native man serving with the English shot Metacom dead.

The English put his head on display at Plymouth and sold his wife and nine-year-old son into slavery. In 1680 Plymouth Colony's leaders sold Mount Hope to four Boston merchants for 1,100 pounds, and the town of Bristol was founded there.

**Before Wight.** The people of Bristol had already marked the Fourth with cannon. In 1777, one account says, "they ushered in the morning by firing 13 cannons, one for each colony." What began in 1785 was the yearly ceremony. The town's Fourth of July committee gives the early 1800s as the likely start of Bristol's parade. Wight died in 1837.

### Thanksgiving days for the new country

The British general John Burgoyne and his army surrendered to American soldiers at Saratoga, New York, on October 17, 1777. The members of the Continental Congress then set December 18, 1777, as a day of thanksgiving for the whole country. Over the war years they named at least one day of fasting or of thanksgiving in every year from 1775 to 1783.

Elias Boudinot of New Jersey was a member of the new House of Representatives. In 1789 he asked the other members of Congress to request a day of thanksgiving. The members of both houses agreed. They asked the president to name a day of thanks for the chance "peaceably to establish a form of government." On October 3, 1789, President George Washington named Thursday, November 26, 1789, as a day of thanksgiving.

Washington sent his order to the state governors. On the day, he went to church at St. Paul's Chapel in New York City. He sent beer and food to men held in prison because they owed money.

**A second day, 1795.** Thousands of farmers in western Pennsylvania took up arms in 1794 against a federal tax on whiskey. This uprising is called the Whiskey Rebellion. Washington led an army of militia, citizen soldiers, against it, and the rebel leaders fled. On January 1, 1795, Washington named February 19 as a day of thanksgiving. One of the reasons he gave was the end of the uprising. None of these days became a yearly holiday.

### Washington's birthday

Soldiers at the army's winter camp at Valley Forge, Pennsylvania, gathered on George Washington's birthday in 1778 to wish him well. In 1779 people in Milton, Massachusetts, held a public celebration of the day.

Washington was not born on February 22 by the calendar used in his time. When he was born, the date was February 11, 1731. In 1751 the members of Parliament passed a law that moved Britain and its colonies to the calendar used today.

To catch up with that calendar, they took eleven days out of September 1752. In Britain and the colonies, the day after September 2, 1752, was September 14. The same law moved the start of the year from March 25 to January 1. Under the old count, a February birthday fell near the end of the year 1731. Under the new calendar, Washington's birth date became February 22, 1732.

### Four days off at Christmas, and who got none

Mount Vernon was George Washington's plantation in Virginia. Mary V. Thompson, writing for Mount Vernon, says the evidence shows that most enslaved workers there had four days off at Christmas. They used the days to rest and to visit family, at Mount Vernon and on nearby plantations. For the enslaved cooks, housemaids, waiters and others who worked in the house, Christmas brought no rest. The Washingtons had extra guests over the holiday, and they made these workers do extra work.

Philip Vickers Fithian was a tutor from New Jersey, in his twenties, a teacher who lived with a family and taught its children. He spent Christmas 1773 at Nomini Hall, the Virginia plantation of Robert Carter. His journal records that the workers who served him kept working that Christmas morning, and he gave five of them small tips in bits, small silver coins. He wrote that guns fired all around the house woke him.

Nelson, a boy Fithian counted among the "Servants," came in early, dressed only in his shirt and breeches, short pants that ended at the knee. He built a big fire, blacked Fithian's shoes, tidied the room and wished him a joyful Christmas. Fithian gave him half a bit.

Before Fithian was dressed, the man who made the fire in the schoolroom came in. He was dressed neatly in green and was almost drunk, and he bowed three or four times. Fithian did not write his name.

Then an enslaved worker sent in Fithian's clean clothes with a message asking for a "Christmas Box," a small gift of money. Fithian gave a bit to each of these two men. He gave two bits to Tom the coachman, who was caring for his lame horse, and half a bit to Dennis, a boy who waited at table. In all he gave five bits, a little over three shillings.

### Black governors in wartime Hartford, 1776

Black communities in Connecticut kept electing Black governors through these years. In Hartford, London was governor in 1755, while Thomas Seymour held him enslaved. Quaw, governor in 1760, was enslaved by George Wyllys, the secretary of the colony. Cuff was governor from 1766 to 1776.

These governors had little power of their own. A Black governor had no power to punish a white person who wronged a Black person.

### John Anderson

> **Who:** An enslaved man who became Hartford's Black governor in 1776, in a dispute that white officials investigated as a possible plot.
>
> **When and where:** Hartford, Connecticut, 1776 to 1780.

**A Black governor named without an election, two months before independence.**

John Anderson became the Black governor of Hartford in May 1776, two months before the Declaration of Independence. White officials investigated his choice as a possible British plot.

That May, white men in Connecticut elected Jonathan Trumbull governor again. He had been governor since 1769. Soon after, Cuff, the Black governor of Hartford, resigned. He named John Anderson as governor in his place, without an election. Major French recorded it in his journal on May 11, 1776.

Anderson was enslaved by Philip Skene, who had been a major in the British army. The Americans held Skene as a prisoner, because they suspected he was loyal to Britain. White people in Hartford feared that Skene planned to use Anderson to bring Black people over to the British side. Members of a committee of Connecticut officials investigated.

**Who paid.** The committee found that money had been offered to win Black people's support for Anderson. Two accounts disagree about who offered it: Skene, or Anderson himself. Chris Menapace writes that Skene tried to pay Black people to back Anderson, and that many refused to back an enslaved man owned by a Loyalist, a colonist who stayed on the king's side. Skene told the committee he had offered the money "for amusement." Andy Piascik writes that Anderson himself paid some Black people to support him, and that the committee cleared Anderson of any plot. By Piascik's account, Connecticut officials approved a four-year term for Anderson. He served as governor until 1780.

## 1800 to 1850

**Era 6 of 10 · 1800 to 1850 · about 9 minutes**

Wealthier families and newspaper editors in American towns worked, in the first half of the 1800s, to turn Christmas from a noisy street holiday into a day for families and children. In a poem printed in 1823, St. Nicholas comes down the chimney to fill the children's stockings. Thanksgiving was still mostly a New England day. Sarah Josepha Hale, a magazine editor, began asking governors and presidents to make it one day for the whole country.

Enslavers in the South gave enslaved people three to six days off at Christmas. In Harriet Jacobs's town in North Carolina, New Year's Day then brought the hiring out and selling of enslaved people. Free Black Americans chose days of their own to celebrate, such as July 5, 1827, in New York.

### Christmas becomes a children's day

In the early 1800s, Christmas in American towns still meant heavy drinking, begging from door to door and rowdy parades. Wealthier families and newspaper editors feared that these crowds threatened public order. They worked to turn Christmas into a quiet day at home, centered on children.

**The poem.** The *Troy Sentinel*, a newspaper in Troy, New York, printed a poem called "Account of a Visit from St. Nicholas" on December 23, 1823. It carried no author's name. It begins "'Twas the night before Christmas," and it describes stockings hung by the chimney for St. Nicholas to fill. "Down the chimney St. Nicholas came with a bound," the poem says. Eight reindeer pull his sleigh, and in the 1823 printing two of them are named Dunder and Blixem.

**Who wrote it.** A book called the *New York Book of Poetry* listed Clement Clarke Moore, a professor at a school for ministers in New York City, as the author in 1837. Moore put the poem in his own book of poems in 1844. The descendants of Henry Livingston Jr., a New York farmer and poet, say he wrote it as early as 1808. Accounts still differ about who wrote it.

A few years after the poem appeared, Catharine Maria Sedgwick of Stockbridge, Massachusetts, published a story about children who found a Christmas tree with gifts around it. Shopkeepers began to advertise gifts for children.

By the 1840s lawmakers in many states had begun to make Christmas a legal holiday, a holiday set by law. Alabama is often called the first state, in 1836, but Alabama's state archivists searched and found no law from that year. In 1848 Alabama's lawmakers made Christmas a bank holiday, a day when payments on loans were not due.

### Christmas under slavery, three days in the year

Enslavers in the South gave enslaved workers three to six days off at Christmas. Edwin Epps, who held Solomon Northup in the 1840s on a plantation on Bayou Boeuf, a slow swampy stream in Louisiana, gave three days. Northup wrote that other enslavers gave four, five or six.

Northup wrote that the planters on Bayou Boeuf took turns holding a "Christmas supper" for enslaved people from nearby plantations. Three to five hundred people came, and white people came to watch them eat. The supper and the days off were, Northup wrote, "southern life as it is, three days in the year." The other 362 days, he wrote, were "days of weariness, and fear, and suffering, and unremitting labor." Unremitting means without a break.

Frederick Douglass was enslaved in Maryland. In 1845 he wrote that enslavers gave the days from Christmas to New Year's as holidays. He wrote that they did it because they knew it "would be unsafe to deprive them of it," that is, to take it away. Douglass called the holidays "safety-valves." By that he meant that enslavers used the days off to drain away the anger that could lead enslaved people to rebel.

In Edenton, North Carolina, enslaved men from the plantations went from door to door in costume on Christmas Day, until noon. Harriet Jacobs, who was enslaved in Edenton, called these groups the "Johnkannaus." Each group had about a hundred men. Two of them wore calico, a cheap printed cotton cloth, covered with a net of bright stripes, with cows' tails and horns.

The men beat a drum made from a box covered in sheepskin, and others played triangles and jawbones. They sang songs they had made up during the month before. At every door they asked for a penny or a glass of rum, and a group could collect twenty or thirty dollars.

**Hiring day.** In Jacobs's town, January 1 was hiring day. On that day enslavers rented enslaved people to other white men for the coming year. The next day, each person had to go to the new master. Jacobs wrote that anyone who refused "is whipped, or locked up in jail, until he consents to go." She did not name who did the whipping. After the hiring, enslavers sold people.

**The sale days.** Jacobs wrote that on one of these sale days she watched a mother lead her seven children to the auction block, the platform where people were sold. The mother knew some of them would be taken from her, but the buyers took all seven. A slave trader bought the children. A man from the town bought the mother. Jacobs did not give the mother's name.

On another New Year's Day, Jacobs's friend Fanny was sold at auction to pay her enslaver's debts. Jacobs does not say who ordered the sale. One master bought Fanny, and another master, far away, bought her four daughters. Fanny later escaped.

### Why Black Americans celebrated on January 1, July 5 and August 1

The members of Congress had voted to ban bringing enslaved people into the United States from other countries. The ban took effect on January 1, 1808. That day Absalom Jones preached a sermon of thanks at St. Thomas's African Episcopal Church in Philadelphia. He asked Black Americans to keep January 1 every year as a day of thanks. On that day they would teach their children "the history of the sufferings of our brethren (brothers and sisters), and of their deliverance (being set free)." Enslavers inside the country kept buying and selling people after the law.

**July 5, not July 4.** New York's lawmakers voted on March 31, 1817, to end slavery in the state on July 4, 1827. On that day about 4,600 people were freed. Some of them still had to work for their former enslavers for a set number of years under written contracts called indentures. Black New Yorkers held church services on July 4, 1827, and held their public celebration on July 5. Nathaniel Paul had led a meeting in Albany that voted to celebrate on the fifth, because the fourth was the day white citizens celebrated.

The people at the July 4 church services went home quietly. They feared that white men celebrating Independence Day would pick fights with them. In New York City on July 5, between 2,000 and 4,000 people gathered in St. John's Park. Samuel Hardenburgh led them as the marshal of the day, the man in charge of the celebration.

**August 1.** The members of Parliament, Britain's lawmakers, set August 1, 1834, as the day slavery would begin to end in the British colonies of the West Indies. The West Indies are the islands of the Caribbean Sea. On that day enslaved people in Antigua, Montserrat and Bermuda went free. In the other colonies they became "apprentices." Apprentices still had to work about 40 hours a week for their former enslavers, without pay. Their protests helped end that system in 1838.

Black Americans in New York City held a celebration on August 1, 1834. After freedom was complete in 1838, the editors of *The Emancipator*, Arthur Tappan's antislavery newspaper, called for a yearly holiday. In Oberlin, Ohio, Sabram Cox, who had escaped slavery, led the town's first August 1 celebration in 1842. The historian Jeffrey Kerr-Ritchie writes that for about thirty years, August 1 was the most important yearly celebration of freedom among Black people in the northern United States.

### Pinkster banned in Albany, 1811

By the late 1700s, large crowds of enslaved and free Black people gathered in Albany, New York, for Pinkster. City leaders worried about so many Black people gathering in one place. In 1811 the members of the Albany Common Council, the city's governing board, banned the celebration.

### Thanksgiving, Washington's birthday and the Fourth

Thanksgiving in these years was a New England custom. People in other parts of the country did not keep it.

People in New York, Philadelphia and Richmond held balls, dinners and parades on Washington's birthday, February 22. The balls and dinners were for rich families, and the parades filled the streets for everyone else.

**The fiftieth Fourth.** The Fourth of July in 1826 was the fiftieth anniversary of the day the members of the Continental Congress approved the Declaration of Independence. John Adams and Thomas Jefferson both died that day.

### Sarah Josepha Hale

> **Who:** A magazine editor who asked governors and presidents for years to make Thanksgiving one national holiday.
>
> **When and where:** New England and Philadelphia, 1827 to 1879.

**Thirty years of letters, and the law came after her death.**

Sarah Josepha Hale spent decades asking governors and presidents to make Thanksgiving one holiday for the whole country, on the same Thursday in every state. Her husband, David Hale, died after nine years of marriage and left her with five children. She wrote poems and books to support them. One of her poems for children was "Mary Had a Little Lamb."

In her 1827 novel *Northwood*, she described a New England Thanksgiving dinner. Roast turkey sat at the head of the table. Of all the pies, "the pumpkin pie occupied the most distinguished niche," which means the place of honor.

**The magazine.** She became the editor of *Godey's Lady's Book*, a women's magazine read across the country, in 1837, and held the job until 1877. She used the magazine and her letters to ask for a national Thanksgiving. She sent her articles to the governors of every state and every territory, a part of the country that was not yet a state.

Accounts disagree about when she began. Plimoth Patuxet Museums gives the 1830s. The National Women's History Museum gives 1846. In 1863 Hale herself wrote that she had asked "for the last fifteen years," which points to about 1848.

Some Southern leaders saw Thanksgiving as a Northern holiday. Governor Henry Wise of Virginia wrote back to Hale that he wanted nothing to do with "this theatrical national claptrap of Thanksgiving." Claptrap means silly talk meant to win cheers. Northern ministers preached against slavery on the day, and that was what Wise objected to.

Hale supported ending slavery, and later she backed a plan to send freed Black Americans to Africa. She did not support the movement to give women the vote.

**Still asking.** She got her national day in 1863. After that, each president proclaimed it each year. To proclaim a day is to name it in a public order. No law yet set Thanksgiving as a holiday for the whole country. From 1870, under a federal law, national government workers in Washington, D.C., had the day off on any thanksgiving day the president named.

In May 1877, when she was 88, her eyes were so weak that a helper wrote a letter for her to George Washington Warren. In it she was still asking for "a Resolution of Congress making the last Thursday in November a legal holiday." She died in 1879.

## 1850 to 1900

**Era 7 of 10 · 1850 to 1900 · about 18 minutes**

President Abraham Lincoln proclaimed the first national Thanksgiving in 1863, and the first national holidays followed between 1870 and 1894. In 1870 the members of Congress made New Year's Day, the Fourth of July, Christmas and any thanksgiving day the president named holidays for federal workers, the people who work for the national government, in Washington, D.C. The members of Congress added Washington's birthday in 1879, Decoration Day in 1888 and Labor Day in 1894. Decoration Day was a day for putting flowers on soldiers' graves.

Freed Black Americans made days of their own after the Civil War. Freed people in Texas celebrated June 19, the day in 1865 when a Union general announced that slavery had ended there, and in Charleston, South Carolina, freed people reburied Union prisoners of war and decorated their graves. In Norfolk, Virginia, in 1866, white men attacked a march held to celebrate a new civil rights law.

The Commissioner of Indian Affairs, the official who ran the government's office for Native affairs, ordered the government's boarding schools for Native children in 1890 to celebrate the anniversary of the Dawes Act. Under that law, federal officials broke up the land set aside for Native nations.

A mob in New Orleans killed eleven Italian American men in 1891. The next year, President Benjamin Harrison proclaimed the first national Columbus Day, and some writers say he meant it partly to calm Italy and Italian Americans after the killings.

### How Thanksgiving became national, 1863

Some Southern leaders in the 1850s called Thanksgiving a Northern holiday. In 1856 the Richmond *Whig*, a Virginia newspaper, printed an attack on the thanksgiving day in the District of Columbia. The editors wrote that the day cost working men a day's pay and led to drunkenness. They called New England a "crazy society."

**Hale's letter.** Sarah Josepha Hale wrote to President Abraham Lincoln on September 28, 1863, in the middle of the Civil War. She asked him to proclaim the last Thursday in November as a national day of thanksgiving. Getting every state to pass a law, she wrote, "would require years."

Lincoln issued the proclamation on October 3, 1863. Secretary of State William Seward, the head of the government's dealings with other countries, wrote it. In it Lincoln invited Americans everywhere, even those at sea and in other countries, to keep the last Thursday in November as a day of thanks. He also asked them to pray for "all those who have become widows, orphans, mourners or sufferers" in the war.

After 1863 every president proclaimed a Thanksgiving Day each year. Most chose the last Thursday in November. Two presidents chose other days: Andrew Johnson the first Thursday in December in 1865, and Ulysses S. Grant the third Thursday in November in 1869. In Texas, Governor Oran Roberts, who had been a Confederate officer, still refused to proclaim Thanksgiving in the 1880s.

### The first federal holidays, 1870 to 1888

**Santa in the army camp.** During the Civil War, a magazine called *Harper's Weekly* printed a drawing by Thomas Nast on January 3, 1863. Nast had come to America from Bavaria, in Germany. The drawing showed Santa Claus visiting a Union army camp. Santa wore a coat covered in stars and striped trousers. In his hands was a toy of the Confederate president, Jefferson Davis, with a rope around its neck.

A writer in Smithsonian Magazine calls the drawing Union propaganda, a picture made to win people to the Union side. Seven years later, Christmas Day became one of the first federal holidays.

**The 1870 law.** The members of Congress passed the first law that gave federal workers in Washington, D.C., holidays on June 28, 1870. The days were New Year's Day, the Fourth of July, Christmas Day and any day the president named for fasting (going without food, as a way to pray) or thanksgiving. Researchers at the Congressional Research Service, the office that writes studies for Congress, write that the law was apparently an answer to a written request from bankers and businessmen in the city. Representative Burton Cook of Illinois said it would match the holidays of the states around the city.

**Washington's birthday, 1879.** The members of Congress added Washington's birthday, February 22, in January 1879. The main purpose was to make it a bank holiday. Lawmakers in Massachusetts had already made Christmas, Washington's birthday and the Fourth of July state holidays in 1856. Irish Catholic voters in the state helped pass that law. A law of January 6, 1885, gave paid holidays to federal workers paid by the day, all over the country.

**Decoration Day, 1888.** The members of Congress made Decoration Day, May 30, a holiday for federal workers in the city in 1888. Many of those workers belonged to the Grand Army of the Republic, the organization of Union veterans. Before the law, they lost a day's pay when they went to the Decoration Day ceremonies.

### Juneteenth, 1865

The Union general Gordon Granger announced in Galveston, Texas, on June 19, 1865, that slavery had ended there. The Confederate general Robert E. Lee had surrendered his army in Virginia on April 9, 1865, ten weeks earlier. Granger arrived with about 1,800 soldiers, according to the historian Henry Louis Gates Jr. Other accounts give about 2,000.

Granger issued General Orders No. 3. It stated that "all slaves are free," and that former masters and the people they had enslaved now stood as "employer and hired labor." The order stated that the freed people were advised "to remain quietly at their present homes and work for wages." It also stated that they would not be allowed to gather at army posts, and that they would not be "supported in idleness," which meant fed without working.

About 250,000 people were enslaved in Texas. After 1862, enslavers from other Southern states who were fleeing the Union army had forced more than 150,000 of them to move there.

Many enslavers in Texas did not tell the people they held that they were free until after the harvest was in. One formerly enslaved Texan said an enslaver "didn't tell us we were free til a whole year after we were." In Galveston, the mayor, a former Confederate, forced freed people back to work.

Susan Merritt had been enslaved in Texas. She said that right after freedom, she saw many Black people hanging from trees in the Sabine River bottom, the low land along the river. She said white men caught them swimming across the river and shot them. She did not name the people who were killed, and no record names the killers. Katie Darling kept working for her former mistress for six more years. Darling said the woman whipped her after the war just as she had before.

The Freedmen's Bureau was the federal office set up to help freed people. Its officials did not reach Texas until September 1865. In 1868 Texans met to write a new state constitution, the state's basic set of laws. A committee of that meeting counted 939 murders in the state between 1865 and 1868. In 379 of them, white people killed Black people. The figures, as the Handbook of Texas reports them, do not say who killed the other 560 people. Outlaw gangs and armed groups such as the Ku Klux Klan, a secret group of white men who used terror against Black people, attacked freed people and Union soldiers.

**The first Juneteenth.** Freed people in Texas celebrated the day a year later, on June 19, 1866. People began to call the day Juneteenth, a word made from June and nineteenth. Some early celebrations were political meetings, where freed people learned about their new right to vote. In some towns, city officials made Black people hold their celebrations outside the town. Black Texans raised money to buy land of their own for the day.

### Jack Yates

> **Who:** A Baptist minister, born enslaved, who led Black Houstonians in buying land for their Juneteenth celebrations.
>
> **When and where:** Virginia, then Houston, Texas, 1828 to 1897.

**Eight hundred dollars for ten acres, so Juneteenth had a home.**

Jack Yates and three other men paid $800 in 1872 for ten acres in Houston, Texas, so that the city's Black people had a place of their own for Juneteenth. The other three men were Richard Allen, Richard Brock and Elias Dibble. The members of two churches bought the land for the Black people of Houston. One was Antioch Missionary Baptist Church, where Yates was the pastor. The other was Trinity Methodist Episcopal Church.

The land became Emancipation Park, named for the freeing of enslaved people. It is the oldest park in Houston. For parts of the years of legal segregation, the system of laws that kept Black people and white people apart, it was the only public park in the area that Black people were allowed to use. Juneteenth celebrations are still held there.

Yates was born enslaved in Gloucester County, Virginia, in 1828, as John Henry Yates. His enslaver's child taught him to read, which was against the law. He married Harriet Willis, who was enslaved on a nearby farm, and they had eleven children.

In about 1863, Harriet's enslaver moved to Matagorda County, Texas. Yates could not bear to be separated from his wife and children, so he begged to go along. The Emancipation Park Conservancy, a group that works to keep up the park, says he had already gained his freedom. By its account, he went back into slavery to stay with his family.

When freedom came in June 1865, the family moved to Houston. Yates hauled goods by day and preached at night. In January 1866 freed people organized Antioch Missionary Baptist Church, the first Black Baptist church in Houston. Yates became its first pastor, in 1868 by one account. He bought land for his own house in 1869. In 1885 he started Houston Academy, a school that taught formerly enslaved people reading, writing, arithmetic and trades. He died on December 22, 1897.

### Freedom celebrations, and the attack at Norfolk, 1866

Black Americans marked freedom on days of their own, and in Norfolk, Virginia, white men attacked one of those celebrations. Before the war, on July 5, 1852, Frederick Douglass spoke in Rochester, New York. He asked, "What, to the American slave, is your 4th of July?" He answered that the day showed an enslaved person "the gross injustice and cruelty to which he is the constant victim."

**Midnight, 1863.** The Emancipation Proclamation, President Lincoln's order freeing the enslaved people in the states fighting against the Union, took effect on January 1, 1863. On the night it took effect, Douglass and other Black leaders in the North led large celebrations that began at midnight.

**Norfolk.** The members of Congress passed a Civil Rights Act in April 1866 over President Andrew Johnson's veto, his refusal to sign it. The members of Congress can still make a bill law if two-thirds of each house vote for it again. On April 16, Black residents of Norfolk, Virginia, marched to celebrate the law. Black Union soldiers marched with them in uniform, carrying their guns.

Someone fired a shot. In the chase that followed, a white Confederate veteran was shot and killed. The records do not say who fired either shot. White men then attacked Black people. They killed at least two Black people, badly wounded six, and destroyed property that belonged to Black people. The attacks went on through the night until United States Army soldiers stopped them. The records do not give the names of the dead.

Joseph T. Wilson was a Black Union veteran who published a newspaper in Norfolk, the *True Southerner*. He printed his side of the story in it. After that issue came out, white men attacked his printing office and destroyed his press.

### Who started Decoration Day?

The first national Decoration Day was May 30, 1868, and the man who ordered it was General John A. Logan, the head of the Grand Army of the Republic, the organization of Union veterans. On May 5, 1868, he ordered its members to decorate the graves of Union soldiers on that day. The first ceremony was held at Arlington National Cemetery in Virginia, on land that had been the home of the Confederate general Robert E. Lee. Americans now call the day Memorial Day.

The veterans' organization itself credited the idea to a member who had written to it about a German custom of decorating graves. Logan's wife, Mary Logan, said the idea came from her visit to a Confederate cemetery in Virginia.

People in several towns say their town did it first, and people in at least three places had decorated soldiers' graves before Logan's order. A page of the National Cemetery Administration, the federal office that runs the national military cemeteries, lists the claims.

**Boalsburg, 1864.** In October 1864, three women in Boalsburg, Pennsylvania, decorated the graves of soldiers who had died.

**Charleston, 1865.** In Charleston, South Carolina, Confederate soldiers had held Union prisoners of war at the Washington Race Course, a track for horse racing. The prisoners were kept outdoors in the middle of the track. According to the historian David Blight, at least 257 of them died of disease and of exposure, which means being left outside with no shelter from cold and weather. They were buried quickly in a mass grave, one pit for many bodies, behind the stands.

In April 1865 freed people and Black workmen dug up the bodies and buried each man in his own grave. They built a fence and an arch over the gate that read "Martyrs of the Race Course" (a martyr is a person who dies for a cause).

On May 1, 1865, freed people and white allies from the North held a ceremony there. Blight found the account of it in old papers at Harvard and in Charleston. An account from the College of Charleston says the parade may have included as many as 10,000 people. Among them were 3,000 Black schoolchildren, who sang the song "John Brown's Body."

**Columbus, 1866.** On April 25 and 26, 1866, women in Columbus, Mississippi, and Columbus, Georgia, held days to put flowers on the graves of Confederate soldiers. In Columbus, Mississippi, they put flowers on Union soldiers' graves too. Mary Ann Williams of the Ladies Memorial Association in Columbus, Georgia, had asked for the day in a letter to the newspaper. Supporters of the Confederacy in the South kept a separate day of their own for the Confederate dead.

**Known:** Logan's order of May 5, 1868, started the national day. The three earlier days are each documented, Charleston's most fully, in the newspapers Blight found.

**Disputed:** Whether Logan copied any of them. The College of Charleston says historians debate whether the Charleston ceremony and the 1868 day are connected. The National Cemetery Administration says recent scholarship points to the women of Columbus, Georgia.

### Labor Day, 1882 to 1894

Union workers in New York City held the first Labor Day parade on Tuesday, September 5, 1882. A union is a group of workers who join together to bargain for better pay and conditions. The city's Central Labor Union, a group of unions, planned the parade. People have credited two men with the idea: Peter J. McGuire of the carpenters' union and Matthew Maguire, a machinist, a worker who made and repaired machines. The US Department of Labor states that recent research favors Maguire.

Oregon's lawmakers made Labor Day a state holiday on February 21, 1887. By 1894 Labor Day was a holiday in 23 or 24 states, counting Oregon. A senator brought a bill for a national Labor Day to Congress in August 1893. Senators passed it in June 1894, and members of the House passed it on June 26. President Grover Cleveland signed it on June 28, 1894. It gave federal workers the first Monday in September off.

Cleveland signed it in the first days of a national railroad strike. On June 26, members of the American Railway Union, led by Eugene Debs, had begun refusing to run trains that pulled Pullman sleeping cars. They did it to support the workers at the Pullman factory, who were on strike. On July 3, five days after he signed the bill, Cleveland sent federal soldiers to Chicago to break the strike. Cleveland left no letter or statement that explains why he signed the Labor Day bill.

### Columbus Day, 1892, and the New Orleans lynching

The first national Columbus Day came a year and a half after a mob in New Orleans lynched eleven Italian American men, that is, killed them without a trial. The writer Richard Gambino is among those who say President Benjamin Harrison meant the holiday partly to calm Italy and Italian Americans after the killings.

**The police chief.** Someone shot and killed David Hennessy, the police chief of New Orleans, in October 1890. Police arrested Italian Americans, and 19 were charged, among them a 14-year-old boy. Nine were tried. The jury found six of them not guilty and could not agree about the other three. No solid evidence had been shown against them.

**The mob.** Thousands of people gathered in the city on March 14, 1891, after the verdicts. A lawyer, William S. Parkerson, told the crowd to "set aside the verdict," the jury's decision. Parkerson led an armed group into the city jail with three other men: Walter Denegre, James D. Houston and John C. Wickliffe.

The armed men killed eleven Italian American men. They shot and clubbed nine of them to death inside the jail. Outside, they hanged Emmanuele Polizzi from a lamppost and Antonio Bagnetto from a tree, and shot both men. Among the mob were John M. Parker, who later became governor of Louisiana, and Walter C. Flower, who later became mayor of New Orleans.

The eleven men were Antonio Bagnetto, James Caruso, Loreto Comitis, Rocco Geraci, Joseph Macheca, Antonio Marchesi, Pietro Monasterio, Emmanuele Polizzi, Frank Romero, Antonio Scaffidi and Charles Traina. Three had been found not guilty. Three had had a mistrial, which means the jury could not agree. Five had never been tried.

**No one charged.** The grand jury, a group of citizens who decide whether someone should be charged with a crime, worked under Judge Robert H. Marr, a friend of several men in the mob. Its members said they could not identify the killers. They called the mob "several thousands of the first, best, and even the most law-abiding, of the citizens," and they charged no one. Italy's leaders called home their ambassador, the official who spoke for Italy in the United States. President Harrison agreed to pay $25,000 to the dead men's families. Members of Congress objected, and federal officials paid $2,211.90 to each family.

**The proclamation.** Harrison proclaimed Friday, October 21, 1892, a general holiday for the people of the United States, in an order dated July 21. It was the 400th anniversary of Columbus's landing in the Americas. He asked schools to lead the celebrations and to fly the flag over every schoolhouse. The proclamation does not mention Italy or New Orleans.

### Dances made crimes, boarding schools and a holiday for losing land

**Dances made crimes.** Commissioner of Indian Affairs Hiram Price issued rules in 1883 that made the Sun Dance and other Native ceremonies "Indian offenses" on the reservations. He wrote them after a letter from Henry Teller, the Secretary of the Interior, the head of the federal department in charge of Native affairs, who had called the ceremonies "old heathenish dances." Heathen was an insulting word for people who were not Christian.

Under the rules, government agents punished a person who held one of these dances by taking away the person's food rations for up to ten days. For later offenses they could take the rations for 15 to 30 days or put the person in the agency jail for up to thirty days. US officials had promised those rations in treaties, in return for the nations' land, which US officials had taken.

**The boarding schools.** Commissioner Thomas J. Morgan ordered a new holiday for the government's boarding schools for Native children in 1890. From 1879 on, federal officials took Native children from their families and put them in those schools. Federal officials meant the schools to make the children give up their nations' languages and ways. Richard Henry Pratt, the Army officer who opened the Carlisle school in Pennsylvania in 1879, described its aim in 1892: "Kill the Indian in him, and save the man."

In 1891 the members of Congress let officials make rules to force Native children to attend. In 1893 they let officials take away food rations, clothing and payments from parents who refused. Some government agents sent reservation police to seize children.

At the schools, staff cut the children's hair, took their clothes and gave them English names. Staff beat children for speaking their own languages, shut them alone in rooms, kept food from them and washed their mouths out with soap. Interior Department investigators later counted at least 973 children who died at the schools, and their 2024 report says the true number is higher.

**A holiday for losing land.** Morgan's holiday marked the anniversary of the Dawes Act of 1887. Under that law, federal officials broke up reservation land, the land set aside for Native nations, into farms for single families, and sold the land left over. Native nations held about 138 million acres in 1887. By 1934 they held about 48 million. They had lost about 90 million acres, two-thirds of their land.

**If you remember one thing:** The first national holidays came between 1863 and 1894, and three of them began as somebody's campaign: Hale's Thanksgiving, the Union veterans' Decoration Day and the New York unions' Labor Day. Juneteenth began in the same years, and no one in Washington made it a holiday for another 155 years.

- 1863: Lincoln proclaims a national Thanksgiving on the last Thursday in November.
- 1865: Granger's order at Galveston, June 19, and the first Juneteenth a year later.
- 1892: the first national Columbus Day, a year and a half after the New Orleans lynching.

**Next:** The 1900s add Mother's Day and Armistice Day, and a president moves Thanksgiving to help stores.

## 1900 to 1950

**Era 8 of 10 · 1900 to 1950 · about 8 minutes**

Presidents and members of Congress added new national days between 1914 and 1941 and fixed the dates of old ones. After a campaign by Anna Jarvis, Mother's Day became a national day in 1914. She spent the rest of her life fighting the businesses that sold flowers and cards for it.

After the First World War, Americans marked November 11, the day the fighting stopped, as Armistice Day. In 1938 lawmakers in Congress made it a holiday set by law, dedicated to world peace. In 1934 President Franklin Roosevelt proclaimed, that is, named in a public order, October 12 of each year as Columbus Day.

Store owners used the holidays to sell. Workers at Macy's department store in New York City marched in the store's first Thanksgiving parade in 1924. In 1939 Roosevelt moved Thanksgiving a week earlier to give stores more shopping days before Christmas. Governors in sixteen states refused to follow him, by the National Archives' count, and in 1941 the members of Congress fixed the date by law.

### Who thought of Mother's Day first?

Julia Ward Howe, who wrote "The Battle Hymn of the Republic," came first. In 1872 she started a Mothers' Peace Day, a day for peace held each June 2, and people kept it with services until about 1913. Two more proposals came before Anna Jarvis's. In 1887 Mary Towles Sasseen of Henderson, Kentucky, made a plan for schools to honor mothers. In February 1904 Frank Hering of the Fraternal Order of Eagles, a men's club, gave a speech about a day for mothers. The Eagles still call themselves the "true founders" of Mother's Day.

**The law.** President Woodrow Wilson approved a joint resolution, a measure that both houses of Congress pass together, on May 8, 1914. It named the second Sunday in May as Mother's Day. The next day, Wilson asked Americans to fly the flag on that day "as a public expression of our love and reverence for the mothers of our country." He asked for nothing more, and since Mother's Day fell on a Sunday, no one got a day off for it.

### Anna Jarvis

> **Who:** The woman who campaigned to create Mother's Day and then fought the businesses that made money from it.
>
> **When and where:** West Virginia and Philadelphia, 1905 to 1948.

**She made Mother's Day, then got arrested fighting it.**

Anna Jarvis campaigned for years to create Mother's Day, and then spent her money and the rest of her life fighting the people who sold things for it. She was born in Webster, West Virginia, in 1864, during the Civil War. Her mother, Ann Reeves Jarvis, ran Mothers' Day Work Clubs, which cared for sick and wounded soldiers from both armies.

Her mother died in 1905. To honor her, Anna Jarvis began asking for a national day for mothers. She chose the second Sunday in May, because her mother had died near that date.

The first formal Mother's Day church service was held on May 10, 1908, at Andrews Methodist Episcopal Church in Grafton, West Virginia. Jarvis sent 500 white carnations to it. She chose white, she wrote, for the "truth, purity and broad-charity of mother love." That day she was in Philadelphia, at a Mother's Day gathering in the department store of John Wanamaker. National Geographic reports that 15,000 people came, and each one was given a carnation.

Jarvis wrote letters to business owners, politicians, ministers and newspaper editors across the country. In 1914 the members of Congress and President Wilson made the second Sunday in May a national Mother's Day.

**The fight.** Florists raised the price of carnations before Mother's Day, and card companies sold printed Mother's Day cards. Jarvis wrote, "A printed card means nothing except that you are too lazy to write to the woman who has done more for you than anyone in the world." In the 1920s she wrote that she did not want Mother's Day to become a "burdensome, wasteful, expensive gift day."

**Arrested.** Police in Philadelphia arrested her in 1925, when she was 61, for disturbing the peace, which means making a public disturbance. She had burst into a meeting of the American War Mothers, a group that sold carnations to raise money on Mother's Day. She brought many lawsuits against groups that used the name "Mother's Day," and she spent much of her money on lawyers.

She started a petition, a list of signatures, in 1943, asking to end the holiday. Later she was placed in the Marshall Square Sanitarium, a hospital in West Chester, Pennsylvania. She stayed there until she died. The National Park Service's account of her life does not say who had her placed there or why. The historian Katharine Antolini found that people connected with the flower and greeting-card businesses paid her bills there. Jarvis died on November 24, 1948, at 84, with no money left. She never had children.

### Armistice Day, 1919 and 1938

The fighting in the First World War stopped at 11 o'clock in the morning on November 11, 1918. It stopped under an armistice, an agreement to stop fighting. In November 1919 President Wilson asked Americans to mark the first anniversary as Armistice Day. He asked for parades, public meetings and a short stop in work at 11 a.m.

By 1926 the lawmakers of 27 states had made November 11 a holiday. That year senators and representatives asked the president to call for flags and for ceremonies of "friendly relations with all other peoples."

**The 1938 law.** The members of Congress made Armistice Day a holiday set by law on May 13, 1938, "dedicated to the cause of world peace." By then all 48 states kept the day. Groups of First World War veterans backed the law.

### Why Thanksgiving is the fourth Thursday, not the last

**The date fight.** Thanksgiving falls on the fourth Thursday of November because of a fight over the date that began in 1939. That year November had five Thursdays, and the last one fell on November 30. President Franklin Roosevelt was worried that a short shopping season before Christmas would slow the country's recovery from the Great Depression. The Great Depression was the long period of hard times in the 1930s, when many Americans had no work. Roosevelt moved Thanksgiving a week earlier, to November 23, to help stores.

The governors of 32 states followed him. The governors of 16 states kept the last Thursday, by the National Archives' count, and a history website called Ghosts of DC counts 23 states that refused. For two years, Americans kept two different Thanksgivings.

The members of Congress ended the confusion in 1941. They set Thanksgiving by law as the fourth Thursday in November. In a year when November has five Thursdays, that is a week before the last one. Roosevelt signed the law on December 26, 1941.

**The parade.** Workers at Macy's department store in New York City marched to the store in costume on November 27, 1924. They brought floats and animals from the Central Park Zoo. At the end of the parade, Santa Claus arrived at the store. The parade was held again in later years, and in 1933 more than a million people watched it.

New York children had their own Thanksgiving custom before the parade. From about 1870 into the 1920s, on Ragamuffin Day, they dressed in costumes and begged from door to door. Fewer children kept the custom over the years, and the last ragamuffin parade in New York City was held in 1956.

### Columbus Day, 1905 to 1937

Angelo Noce, an Italian immigrant in Denver, asked Colorado's leaders to honor Columbus. In 1905 Colorado's governor, Jesse McDonald, proclaimed the first state Columbus Day.

The Knights of Columbus, a Catholic men's organization, and Generoso Pope, an Italian American leader in New York City, asked Congress for a national day. On April 30, 1934, the members of Congress asked the president to proclaim October 12 each year as Columbus Day. They asked for flags and ceremonies. President Roosevelt did so that September, and again in 1937.

Federal workers, the people who work for the national government, did not get the day off until a law passed in 1968 took effect in 1971.

### Christmas, Labor Day, Juneteenth and Memorial Day, 1921 to 1937

**The first National Christmas Tree.** Grace Coolidge, the president's wife, gave the public schools of Washington, D.C., permission in November 1923 to put up a tree near the White House. On Christmas Eve 1923 President Calvin Coolidge lit it. It was the first National Christmas Tree, a fir 48 feet tall from Vermont. About 3,000 people watched.

**Labor Day.** The 1894 Labor Day law covered only federal workers. As late as the 1930s, unions encouraged workers to strike to make sure they got the day off.

**Juneteenth grows smaller.** Juneteenth, June 19, marks the day in 1865 when a Union general announced in Galveston that slavery had ended in Texas. A Boston Public Library history says Juneteenth celebrations began to grow smaller in the early 1900s. One reason, it says, is that teachers taught that the Emancipation Proclamation, President Lincoln's 1863 order freeing enslaved people in the states fighting the Union, had ended slavery. During the Great Depression, the same history says, many people were forced to work in cities, and employers there did not want to give workers the day off.

**Memorial Day 1937.** Decoration Day was by then also called Memorial Day. On that holiday, May 30, 1937, Chicago police shot and killed ten people who were marching in support of striking steelworkers at the Republic Steel plant. Chapter 14 describes the march and the killings.

**The dances.** Commissioner Hiram Price's 1883 rules, which made the Sun Dance and other ceremonies "Indian offenses" punished by taking away food rations, were still in force. Charles Burke, the Commissioner of Indian Affairs, the official who ran the government's office for Native affairs, sent out an order in 1921 that let the officials in charge of reservations shut down Native dances. He added to it in 1923.

## 1950 to 2000

**Era 9 of 10 · 1950 to 2000 · about 15 minutes**

After 1950, Americans argued over whose days the country should mark. In 1968 the members of Congress moved three holidays to Mondays, so that workers got more three-day weekends, and made Columbus Day a federal holiday, a paid day off for the national government's workers. Maulana Karenga and his group, called Us, started Kwanzaa in 1966. Students and marchers in the civil rights movement brought Juneteenth back.

Coretta Scott King, the Southern Christian Leadership Conference, Stevie Wonder and millions of people who signed petitions campaigned for 15 years for a holiday for Martin Luther King Jr. President Ronald Reagan signed that law in 1983. Some state leaders refused the King holiday for years. The last state named a day for King in 1999.

Native people began to mark Thanksgiving as a National Day of Mourning in 1970. In 1992 the members of the city council of Berkeley, California, renamed Columbus Day for Indigenous peoples. Indigenous peoples are the first peoples of a place and their descendants.

### Veterans Day and the Monday holidays, 1954 to 1975

On June 1, 1954, the members of Congress renamed Armistice Day as Veterans Day. By then Americans had also fought in the Second World War and the Korean War. The members of Congress chose the new name so that one day would honor the veterans of every war.

Memorial Day, the old Decoration Day, got an official birthplace in 1966. That year the members of Congress and President Lyndon Johnson named Waterloo, New York, the "birthplace" of Memorial Day. People in several other towns still say their town held the first one.

**The Monday holidays.** Under a 1968 bill called the Uniform Monday Holiday bill, several holidays would move to Mondays. Robert McClory, a member of the House of Representatives from Illinois, took it through the House Judiciary Committee. He was a Republican, a member of one of the country's two main political parties. That committee of House members worked on the bill before the full House voted.

Four business groups backed it: the US Chamber of Commerce, the National Association of Manufacturers, the National Association of Travel Organizations and the National Retail Federation. McClory said it would give families more time together and more chances to visit historic places. Representative H. R. Gross of Iowa asked whether store clerks would get the days off or spend them selling. McClory answered that labor unions supported the bill.

President Johnson signed it on June 28, 1968, and it took effect in 1971. Under the law, Washington's Birthday fell on the third Monday in February, Memorial Day on the last Monday in May and Veterans Day on the fourth Monday in October. In the same law, the members of Congress made Columbus Day a federal holiday, on the second Monday in October.

McClory had also wanted to rename Washington's Birthday "Presidents' Day." He dropped the idea to win the votes of Virginia's lawmakers. No act of Congress and no order of a president changed the federal name, although many people call it Presidents' Day.

Veterans' groups objected to moving Veterans Day, and 46 states kept November 11 or went back to it. In 1975 the members of Congress put Veterans Day back on November 11.

### Kwanzaa, from 1966

Maulana Karenga, a Black activist who led a group called Us in the Los Angeles area, created Kwanzaa in 1966. The Root, a news site, says members of Us created it together. Kwanzaa runs for seven days, from December 26 to January 1. In 1965 Karenga wrote seven principles, the Nguzo Saba, and families talk about one of them on each night of Kwanzaa. The first is Umoja, the Swahili word for unity. Swahili is a language spoken in East Africa. The name Kwanzaa comes from a Swahili phrase meaning "first fruits." The last day ends with a feast called Karamu.

At first Karenga said that Kwanzaa gave Black Americans "an alternative to the existing holiday." In 1997 he wrote that it "was not created to give people an alternative to their own religion or religious holiday."

**The crimes.** A California court convicted Karenga in 1971 of two crimes, felony assault and false imprisonment. Felony assault is a serious crime of attacking a person. False imprisonment means holding people against their will so they cannot leave. The charges came from what was done to two women at his home in Inglewood, California. The Root describes the crimes as torturing the two women. The women, Deborah Jones and Gail Davis, were members of his group.

At the trial, Jones and Brenda Karenga testified that Karenga believed the two women were plotting to poison him. Jones testified that the two women were ordered to take off their clothes. Then they were whipped with an electrical cord and beaten with a karate baton. By one fuller version of the report, they were also hit on the head with toasters.

She testified that a hot soldering iron, a tool that heats metal to join wires, was put in Davis's mouth and pressed against Davis's face. One of Jones's own big toes was squeezed in a vise, a clamp that tightens with a screw. Jones said Karenga himself put detergent and running water hoses in their mouths. The news report of her testimony does not say who did each of the other acts.

Karenga was sentenced to one to ten years in prison and was released on parole in 1975. Parole is an early release from prison under rules. He has denied the charges and called them "trumped up," which means made up, and "politically motivated." He says he was one of many people the FBI went after for political reasons.

**After the trial.** People went on keeping Kwanzaa after the trial and Karenga's years in prison. The US Postal Service issued the first Kwanzaa stamp in 1997, and that year President Bill Clinton sent the first Kwanzaa message from a president. Counts of how many Americans celebrate Kwanzaa are only rough estimates. One estimate in 2009 put the number between 500,000 and 2 million. In a 2019 National Retail Federation poll, 2.6 percent of the people who celebrated a winter holiday said they planned to celebrate Kwanzaa.

### Juneteenth comes back, 1968 to 1980

People in the civil rights movement brought Juneteenth back. In Atlanta, students in the movement wore Juneteenth Freedom buttons. The Poor People's March on Washington ended on June 19, 1968. The marchers took the celebration home to their own cities, among them Milwaukee and Minneapolis. People in those two cities still hold some of the largest Juneteenth events.

Al Edwards, a Texas state lawmaker from Houston and a Democrat, a member of the other main political party, brought a bill to make Juneteenth a Texas state holiday. Texas lawmakers passed it in 1979, and Governor Bill Clements signed it. The first Juneteenth celebration held by the state of Texas took place in 1980.

### Thanksgiving as a day of mourning, from 1970

The Wampanoag leader Frank James and other Native people gathered on Cole's Hill in Plymouth, above Plymouth Rock, on Thanksgiving Day, November 26, 1970, for the first National Day of Mourning. About 500 Native people came.

The gathering has been held every Thanksgiving since then. United American Indians of New England organizes it. Many who come go without food from the evening before.

**The arrests, 1997.** Plymouth police stopped the marchers from walking through the center of town on Thanksgiving Day 1997. Earlier that day, people dressed as Pilgrims had walked the same road. The marchers' group and other accounts say police used pepper spray, a spray made from hot peppers that burns the eyes and skin. One witness, Chris Groden, told the Associated Press that police sprayed mace, a similar spray, straight into several people's eyes.

The police arrested 25 marchers. They charged them with disorderly conduct, which means disturbing public order, and with unlawful assembly, which means gathering where the law does not allow it. The records do not name the officers.

**The settlement.** The charges were dropped in October 1998, when the town and the marchers' group reached an agreement. Plymouth officials agreed that the marchers could walk on Thanksgiving without a permit, forever. The town paid $135,000 in all. By the marchers' group's account, $100,000 went to a fund for teaching about Metacom, $20,000 to the lawyers of the American Civil Liberties Union and $15,000 to two plaques.

One plaque stands on Cole's Hill. The other stands in Post Office Square in Plymouth and tells of Metacom, the Wampanoag leader. He was killed in 1676 in an ambush led by the English captain Benjamin Church. The English then put his head on a pole in that square and left it there for 25 years.

### Frank James (Wamsutta)

> **Who:** A Wampanoag leader whose speech was stopped in 1970 and who started the National Day of Mourning.
>
> **When and where:** Massachusetts, 1970.

**Invited to speak, then told his speech was out of place.**

In September 1970, Massachusetts officials planning the celebration of the 350th anniversary of the Pilgrims' landing invited Frank James to speak. Governor Francis Sargent was among the organizers. James was Aquinnah Wampanoag, and he led the Wampanoag Tribe of Gay Head. His Wampanoag name was Wamsutta, the same name as Massasoit's eldest son, a Wampanoag leader of the 1600s.

James wrote his speech from the Pilgrims' own records, including William Bradford's history and *Mourt's Relation*, a book of Pilgrim writings printed in London in 1622. It began: "I speak to you as a man, a Wampanoag Man."

In the speech, James wrote that within four days of landing, the Pilgrims "had robbed the graves of my ancestors and stolen their corn and beans." He wrote that "before 50 years were to pass, the Wampanoag would no longer be a free people."

The organizers read the speech in advance. A state commerce official told him that "the theme of the anniversary celebration is brotherhood and anything inflammatory would have been out of place." Inflammatory means likely to make people angry. United American Indians of New England says he refused to give a speech written by a public relations person, someone paid to shape what the public thinks of an event. James did not speak at the celebration.

On Thanksgiving Day 1970, he spoke instead on Cole's Hill in Plymouth, beside the statue of the Wampanoag leader Massasoit. Accounts differ on whether he read the same speech or a changed one. That year he founded United American Indians of New England.

### Fifteen years to get King's day, 1968 to 1983

It took 15 years of campaigning to make Martin Luther King Jr.'s birthday a national holiday. James Earl Ray, a white man, shot and killed King in Memphis on April 4, 1968, and pleaded guilty the next year. Chapter 25 tells the killing and the later dispute over whether others planned it.

**The first bill.** Four days after the killing, Representative John Conyers of Michigan brought a bill to Congress for a national holiday on King's birthday, January 15. The House members on the committee in charge of the bill took no action on it. Members of the Southern Christian Leadership Conference, the group King had led, gathered 3 million signatures on petitions in the early 1970s. In 1973 lawmakers in Illinois made the first state King holiday. State lawmaker Harold Washington was the bill's sponsor, the lawmaker who brought it forward.

**Four or five votes short.** Coretta Scott King, King's widow, spoke for the holiday before Congress in 1979. That November the members of the House voted 252 to 133 for it. Under the rules for that vote, the bill needed two-thirds of the votes, and it fell short. The Congressional Research Service, a group that studies laws for Congress, counts it as four votes short. The King Institute at Stanford University counts five.

**Stevie Wonder's song.** The singer Stevie Wonder released "Happy Birthday," a song asking for the holiday, in 1980. His money paid for a lobbying office, an office whose staff pressed lawmakers to vote for the bill. Petitions reached more than 6 million signatures. On January 15, 1983, more than 100,000 people rallied at the Washington Monument.

**The Senate.** The members of the House passed the bill 338 to 90 on August 2, 1983. In the Senate, Jesse Helms of North Carolina led the opposition. He called for the FBI's secret recordings of King to be made public. The King Institute says he wanted to hurt King's reputation. A court had sealed the recordings until 2027. He also gave senators a 300-page paper that claimed King had ties to communists, people who wanted the government to own all land and businesses. Senator Daniel Patrick Moynihan called it a "packet of filth" and stamped on it.

Helms's plan to open the FBI records lost, 3 votes to 90. Other senators said another paid day off would cost too much.

Senators passed the bill 78 to 22 on October 19, 1983. Reagan had wanted a day of remembrance, not a paid holiday. He signed the law on November 2, 1983. The first King holiday was kept on January 20, 1986.

### The states that held out, 1986 to 1999

The 1983 law made King's birthday a federal holiday. Each state's leaders decided for themselves whether to keep the day. By January 1989, 44 states kept a King holiday.

Some state lawmakers joined King's day to a day for Confederate generals. The Confederacy was the group of Southern states that fought the Union in the Civil War to keep slavery. Alabama's holiday was named for Robert E. Lee and King, and Mississippi's for King and Lee. Arkansas lawmakers combined King and Lee from 1985. Virginia's lawmakers called their day Lee-Jackson-King Day, for Lee, the Confederate general Thomas "Stonewall" Jackson and King.

In Arizona, Governor Bruce Babbitt made King's day a paid state holiday by his own order in 1986. His successor, Evan Mecham, canceled it in January 1987. Mecham said Babbitt had no legal power to create it. Groups across the country moved their conventions out of Arizona. Stevie Wonder and other musicians refused to perform there.

**The Super Bowl.** Arizona voters voted no in November 1990 on two questions on the ballot about a King holiday. Officials of the National Football League then took the 1993 Super Bowl away from Arizona and moved it to Pasadena, California. *PHOENIX* magazine says the game was to be played in Tempe, next to Phoenix, and the Pima County Public Library says Phoenix. People there had expected about $200 million from the game. In November 1992, 61 percent of Arizona voters approved Martin Luther King Jr./Civil Rights Day. Arizona is the only state whose voters approved the holiday themselves.

New Hampshire's lawmakers made a "Civil Rights Day" in 1991. In June 1999 they renamed it for King. New Hampshire was the last state to name a day for King.

### Liz Byrd

> **Who:** A Cheyenne schoolteacher and lawmaker who brought the King holiday bill to Wyoming's legislature nine times.
>
> **When and where:** Wyoming, 1981 to 1990.

**Nine bills in nine years before Wyoming said yes.**

Liz Byrd brought a bill for a Martin Luther King Jr. holiday before the Wyoming legislature, the state's lawmakers, nine times. In 1990 the lawmakers passed it. Her full name was Harriett Elizabeth Byrd. Her grandfather Charles Rhone had come to Wyoming Territory as a boy in 1876.

Officials at the University of Wyoming did not accept her application. Her son believes it was because she was Black. She earned her teaching degree at West Virginia State College in 1949. Cheyenne school officials turned her down at first too, WyoHistory says probably because of her race. They hired her in 1959. A reference book, *Black America: A State-by-State Historical Encyclopedia*, calls her the first fully certified full-time Black teacher in Wyoming. She taught second grade for most of her 37 years as a teacher.

She served in the Wyoming House of Representatives from 1981 to 1988. In 1989 she became the first Black member of the Wyoming Senate.

One Republican who voted against her King holiday bill was Loren Willford. He said a Wyoming holiday should honor someone who had been in Wyoming, such as Chief Washakie, a Shoshone leader, or Jim Bridger, a fur trapper and guide. In 1990 the lawmakers passed the holiday with a longer name, "Martin Luther King, Jr./Wyoming Equality Day." Her son said she never liked the added words but took them rather than lose the bill again. Another account gives the year as 1991.

She died on January 27, 2015, at 88. Governor Matt Mead ordered flags lowered in her honor.

### Pride marches, and Columbus Day renamed, 1970 to 1999

Several thousand people marched for gay and lesbian rights in New York City on June 28, 1970. They walked 51 blocks, from Sheridan Square in Greenwich Village to the Sheep Meadow in Central Park. Their permit came two hours before the start. The march came one year after police raided the Stonewall Inn, a gay bar in the city. The organizers' counts ranged from 3,000 to 20,000, and the *New York Times* put the march on its front page. Craig Rodwell and three others had proposed a yearly march in 1969.

**Pride Month.** The New York march has been held every June since 1970. People call these marches Pride marches. On June 11, 1999, President Bill Clinton proclaimed June "Gay and Lesbian Pride Month." It was the first time a president had proclaimed it.

**Columbus Day renamed.** Columbus's men enslaved Taino people, as Chapter 1 tells, and Native groups and others protested a national day in his honor. In 1977, people at a United Nations conference in Geneva, Switzerland, discussed replacing Columbus Day with a day for Indigenous peoples.

The 500th anniversary of Columbus's first voyage came in 1992. That year a group from the San Francisco Bay Area called Resistance 500 persuaded the city council of Berkeley, California, to declare October 12 a "Day of Solidarity with Indigenous People." Solidarity means standing together. The council members renamed the day Indigenous Peoples Day.

**If you remember one thing:** After 1950 the fights were over whose days counted, and the longest one, for Martin Luther King Jr.'s birthday, took from 1968 to 1983 in Congress and until 1999 in the last state.

In 1950: the federal holidays were New Year's Day, Washington's Birthday, Memorial Day, the Fourth of July, Labor Day, Armistice Day, Thanksgiving and Christmas, and not one was named for a Black American or for the Native nations.

In 2000: King's day was a federal holiday and every state had named a day for him, Juneteenth was a Texas state holiday, Berkeley kept Indigenous Peoples Day, and a president had proclaimed Pride Month.

**Next:** Juneteenth becomes the newest federal holiday in 2021, and two presidents disagree about Columbus Day.

## 2000 to Today

**Era 10 of 10 · 2000 to Today · about 7 minutes**

Since 2000 the members of Congress have added one federal holiday, Juneteenth, in 2021. Lawmakers in Virginia and Arkansas stopped joining King's day to days for Confederate generals. Alabama and Mississippi still honor Robert E. Lee on the same Monday as King.

In 2021 President Joe Biden became the first president to proclaim Indigenous Peoples' Day. In 2025 President Donald Trump proclaimed Columbus Day only, and the Associated Press reported that he stayed silent on Juneteenth. Some states also added days for other communities, such as Lunar New Year in New York's schools and Diwali in California. As of September 2026, Juneteenth, King's day and Columbus Day are all still federal holidays.

### The end of most combined days, 2000 to 2020

South Carolina's governor, Jim Hodges, signed a law in May 2000 that gave all state workers King's day off. South Carolina was the last state to do so. Before then, state workers there could choose King's day or one of three Confederate holidays.

**Virginia.** Virginians kept Lee-Jackson-King Day from 1984 to 2000. It honored the two Confederate generals and King on the same day. From 2000 to 2020 Virginia had two separate holidays. In April 2020 Virginia's governor, Ralph Northam, signed a law under which Lee-Jackson Day ended and Election Day became a state holiday. Northam said the old day "commemorates a lost cause. It's time to move on." A lost cause is a cause that has failed. CNN reported that both generals had enslaved people and had fought to keep slavery.

Arkansas lawmakers moved Lee's day off King's day in 2017. Alabama and Mississippi still honor Lee's birthday on the same Monday as King's day.

### Juneteenth becomes a federal holiday, 2021

Juneteenth, the June 19 celebration of the end of slavery in Texas, became a federal holiday in 2021. On May 25, 2020, Derek Chauvin, a Minneapolis police officer, killed George Floyd. That June, many Juneteenth gatherings called for changes in the way police do their work.

**The vote.** The senators passed the Juneteenth National Independence Day Act in June 2021. On June 16, 2021, the members of the House passed it 415 votes to 14, according to the House's own record of the vote. All 14 votes against it came from Republicans. President Biden signed it on June 17, 2021. It was the first new federal holiday since King's day in 1983.

The leaders of each state still decide whether state workers get the day off. In 2025 the Congressional Research Service, which studies laws for Congress, counted 31 states and Washington, D.C., with a permanent paid Juneteenth holiday. PolitiFact, a fact-checking news site, reported that count in June 2026. Alabama was the most recent state to add it, in May 2025. PolitiFact also reported that New Mexico names the day each year, and that the governors of Kansas and Kentucky have declared it. Private employers do not have to give the day off.

**Juneteenth 2025.** President Trump signed no proclamation for the day on Juneteenth 2025, the Associated Press reported. The White House had said earlier that he planned to sign one. "I'm not tracking his signature on a proclamation today," his press secretary, Karoline Leavitt, said. President Trump said that America has "too many non-working holidays," CBS News reported.

**Park fees.** In December 2025, CBS News reported a change in the National Park Service's list of days with free entry to the parks. The 2026 list no longer included Martin Luther King Jr. Day and Juneteenth, which President Biden's officials had made free-entry days. It added June 14, which is Flag Day and President Trump's birthday. The change affects only park fees. Both days are still federal holidays.

### Opal Lee

> **Who:** A retired Fort Worth teacher who organized Juneteenth celebrations for about 40 years and campaigned for it to become a national holiday.
>
> **When and where:** Fort Worth, Texas, 1939 to today.

**At 89 she walked toward Washington, 2.5 miles at a time.**

Opal Lee was the best-known campaigner for making Juneteenth a national holiday. She was there when President Biden signed the law on June 17, 2021, and he asked the crowd to stand and cheer for her. She was born Opal Flake in Marshall, Texas, in 1926, and her family moved to Fort Worth when she was nine.

In June 1939, her parents bought a house at 940 East Annie Street in Fort Worth, in a white neighborhood. On June 19, 1939, when she was 12, a white mob of about 500 people drove the family out. The mob dragged the family's furniture out and burned it, and burned the house to the ground.

Lee remembered that police officers were there and did not stop the mob. She said her father came home from work with a gun. The police told him that if he fired, they would let the mob have the family. No record names anyone in the mob, and no record shows that anyone was arrested.

She became a teacher after she graduated from Wiley College in 1953. When she retired in 1977, she helped found the Tarrant County Black Historical and Genealogical Society. She began planning Fort Worth's Juneteenth celebrations, and she led them for about 40 years.

**The walk.** In 2016, when she was 89, she organized a walk of 1,400 miles from her home in Texas to Washington, D.C. The walk drew attention across the country to Juneteenth. Her family worried about her health. So she walked about 300 miles herself, in pieces of 2.5 miles each. The 2.5 miles stand for the two and a half years it took for the news of freedom to reach Texas. Her petition for the holiday gathered 1.6 million signatures, according to the National Women's History Museum.

President Biden gave her the Presidential Medal of Freedom, the country's highest honor for a civilian, a person who is not in the military, on May 3, 2024. That year builders put up a new house for her on the lot where her family's house had burned. She paid $10 for the land, KERA News reported in 2024.

On Juneteenth 2026, nearly 600 people walked Opal's Walk for Freedom in Fort Worth, the Fort Worth Report counted. Lee did not attend. Her family led the walk while she rested, a few months before her 100th birthday.

### Two presidents, two Octobers: Indigenous Peoples' Day and Columbus Day, 2021 to 2026

President Biden proclaimed Indigenous Peoples' Day on October 8, 2021. He wrote that for generations "Federal policies systematically sought to assimilate and displace Native people and eradicate Native cultures." To assimilate people means to make them give up their own ways and take on someone else's, to displace them means to push them off their land, and to eradicate means to wipe out. Biden also proclaimed Columbus Day each year from 2021 to 2024. In 2020 Colorado's lawmakers replaced Columbus Day in their state with Cabrini Day, named for an Italian American nun.

**October 2025.** President Trump proclaimed Columbus Day in October 2025 and did not mention Indigenous Peoples' Day. His proclamation said of Columbus, "Left-wing radicals toppled his statues, vandalized his monuments, tarnished his character." NPR reported a count by the Pew Research Center, a group that studies public life. In 2025 Pew researchers counted 30 states and three territories that recognize Columbus Day in some way. They also counted 17 states and Washington, D.C., that honor Indigenous people on that day. Some states do both.

The National Day of Mourning is still held at noon on Cole's Hill in Plymouth every Thanksgiving. The most recent one was on November 27, 2025. Only Native people speak, and many of those who come go without food from the evening before. Frank James's granddaughter, Kisha James, helps organize it.

### Pride Month, and new days for more communities

President Barack Obama proclaimed Lesbian, Gay, Bisexual and Transgender Pride Month in 2009. President Biden added more groups to the name in 2022.

Halloween, on October 31, is not a federal holiday, but Americans spend billions of dollars on it. The National Retail Federation, a trade group for stores, has surveyed shoppers each year since 2005. In September 2026 it reported that Halloween spending had reached a record $13.1 billion in 2025. Its survey forecast $13.5 billion for 2026. These are estimates from a survey, not counts of actual sales.

Americans also began to keep more communities' days. Cinco de Mayo, the fifth of May, marks the Mexican army's defeat of French troops at Puebla, Mexico, on May 5, 1862. Latinos in California began celebrating it during the Civil War, according to David Hayes-Bautista, a scholar at the University of California, Los Angeles. Hayes-Bautista says it is scarcely observed in Mexico. It is not Mexico's Independence Day, which is September 16.

New York's governor, Kathy Hochul, signed a law in September 2023 that closes all the state's public schools for Lunar New Year, the start of the year in calendars based on the moon. California's governor, Gavin Newsom, signed a law in October 2025 making Diwali a state holiday from 2026. California was the third state to do so, after Pennsylvania and Connecticut. Diwali is the festival of lights, kept mostly by Hindus, Sikhs, Jains and Buddhists.

**The three questions, answered**

- Who decided when Americans would give thanks, and why did it take until 1941 to fix the date? Governors and church elders set the days one at a time, until Lincoln proclaimed a national Thursday in 1863 at Sarah Josepha Hale's request. Every president after him named the day by proclamation, so when Franklin Roosevelt moved it in 1939 to help stores, sixteen states refused by the National Archives' count, and Congress ended the confusion with the 1941 law.
- Which days did Black Americans make their own, from election days to Juneteenth? Black governors' election days in New England from about 1749, January 1 from 1808, July 5 in New York in 1827, August 1 after 1834, and Juneteenth from 1866, which Congress made a federal holiday in 2021.
- Why did President Harrison proclaim the first Columbus Day in 1892, and why do some states no longer keep it? He proclaimed it for the 400th anniversary of Columbus's landing, a year and a half after a New Orleans mob lynched eleven Italian American men, and some writers say the holiday was partly meant to calm Italy. Native groups and others object to honoring a man whose men enslaved Taino people. Since Berkeley in 1992, cities and 17 states have used the day to honor Indigenous peoples, and some of those states keep Columbus Day too.

**What changed:** Ten eras ago the Faith Keepers and the Sun-priests set the days. By 2021 a majority in Congress did, and the days they chose included one, Juneteenth, that freed people in Texas had kept for 155 years without asking anyone.

**Five dates to keep**

- Fall 1621: the harvest meal at Plymouth, called the first Thanksgiving only from 1841.
- October 3, 1863: Lincoln proclaims a national Thanksgiving on the last Thursday in November.
- June 19, 1865: General Granger announces in Galveston that slavery has ended in Texas.
- October 21, 1892: the first national Columbus Day.
- June 17, 2021: President Biden signs the law making Juneteenth a federal holiday.

**Not known:** No surviving record gives the first name of the boy Brown, killed by a Pope wagon in Boston on November 5, 1764, or says who was driving it.

**Where to go:** Cole's Hill in Plymouth, Massachusetts, where the statue of Massasoit stands and the National Day of Mourning is held at noon every Thanksgiving.

**Next:** This is the last of the 37 chapters. Chapter 1, Exploration and Discovery, is where the grid begins.
