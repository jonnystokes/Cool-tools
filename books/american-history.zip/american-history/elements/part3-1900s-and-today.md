<!-- hb-chapter id="13" slug="elements" title="The Elements" part="3" mode="prose" file="part3" -->

# Chapter 13: The Elements



<!-- hb-time:start id="1900-1950" order="08" chapter="elements" label="1900 to 1950" state="full" progress="written" -->
## 1900 to 1950

<!-- hb-zoom level="era" -->
In 1937, people made an element for the first time, using material from a machine at Berkeley, California. An element is a substance made of only one kind of atom, and atoms are the tiny pieces that everything is made of. By the end of 1949, teams working in the United States had made or found seven more elements. They were astatine, neptunium, plutonium, curium, americium, promethium and berkelium.

In the same fifty years, the elements Americans dug up and used poisoned people who worked with them. Supervisors told women who painted watch dials to shape their brushes with their lips. The women swallowed radium, and many of them died of radium poisoning. At the plants that made a lead additive for gasoline, at least 15 workers died of lead poisoning in the 1920s. Arsenic from a copper smelter in Montana killed farm animals. From 1941, Navajo and other Native miners dug uranium. Navajo miners later reported that no one had told them of its dangers.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The gas well that put out the fire" -->
Helium is an element, a gas that does not burn. In May 1903, a drilling company struck a roaring gas well on William Greenwell's farm near Dexter, Kansas. The people of Dexter planned a celebration. They pushed a burning bale of hay toward the gas to light a giant flame, and the gas put the fire out. Local people made fun of it as "wind gas."

Erasmus Haworth was a Kansas geologist, a scientist who studies rocks and the Earth. He carried samples of the gas to the University of Kansas. There the chemists Hamilton P. Cady and David F. McFarland tested it. On December 7, 1905, they showed that the gas was 1.84 percent helium. Scientists had thought helium was rare on Earth. Cady and McFarland found large amounts of it in the natural gas under the Great Plains.

Airships flew in World War I, and helium became valuable to armies because it does not burn. In 1925 the members of Congress passed the Helium Act. Under it, federal workers, meaning people who worked for the national government, began producing helium and storing it underground in the Bush Dome of the Cliffside gas field, near Amarillo, Texas. That store became the Federal Helium Reserve. For decades it held nearly all of the world's supply of helium.

Under a 1927 law, no one could sell American helium to other countries. For that reason, the German airship *Hindenburg* flew on hydrogen, a gas that burns. On May 6, 1937, the *Hindenburg* caught fire and burned at Lakehurst, New Jersey. After the fire, President Franklin D. Roosevelt considered selling helium to Germany. In 1938 Hitler took over Austria and made it part of Germany. Harold Ickes then refused to sell. Ickes was the Secretary of the Interior, the head of the federal department in charge of public lands.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Radium on the watch dials" -->
Radium is an element that Marie and Pierre Curie found in France in 1898. Radium is radioactive, which means its atoms break apart on their own and give off radiation. Radiation is energy that shoots out of an atom as it breaks apart. Some of it travels as tiny, fast particles that can damage the living cells of a body. The kind that radium gives off is called alpha radiation.

In the early 1900s, workers at American companies mixed radium into paint so that watch numbers glowed in the dark. Other sellers put radium into tonics, drinks they claimed would make people healthy.

Two doctors, Sabin Albin von Sochocky and George S. Willis, founded the Radium Luminous Materials Corporation in New Jersey in 1914. After World War I, the company was reorganized and renamed the U.S. Radium Corporation, with a plant in Orange, New Jersey. At its biggest, the company employed as many as 250 young women, some only 15 years old. Its treasurer, the officer in charge of its money, Arthur Roeder, replaced von Sochocky as president in January 1921. Howard Barker was the vice president and chief physicist.

In Ottawa, Illinois, the Radium Dial Company ran another dial-painting plant. It belonged to the Standard Chemical Company of Pittsburgh, and Joseph Kelly was its president.

The National Institute of Standards and Technology is a federal science laboratory. A history it published states that more than 3,000 girls and young women painted radium dials across the country in the 1910s and 1920s. Northern Public Radio gives about 4,000. The two counts differ, and neither comes with a list of the painters.
<!-- /hb-zoom -->

<!-- hb-story:start slug="radium-girls-elements" name="The Radium Girls" movie="" kind="ordinary" status="verified" -->
### The Radium Girls

> **Who:** Young women, some of them teenagers, who painted glowing radium numbers on watch and instrument dials and were poisoned by the paint.
> **When and where:** The U.S. Radium Corporation in Orange, New Jersey, from 1917, and the Radium Dial Company in Ottawa, Illinois, into the 1930s.

From 1917, young women at the U.S. Radium Corporation plant in Orange, New Jersey, painted watch numbers with radium paint. To shape each brush to a fine tip, they drew it between their lips. This was called lip-pointing, and the method went by the words "lip, dip, paint." Each time a painter lip-pointed, she swallowed a little radium. The women went home glowing, and some people called them ghost girls.

Their supervisors told them to lip-point and said the paint was safe. Von Sochocky, one of the company's founders, grew worried about lip-pointing and told the painters to stop. The supervisors contradicted him, according to Northern Public Radio. Arthur Roeder was the company's president from January 1921, and he still signed papers for the company in 1926. Lip-pointing at the company went on until after 1926. No surviving record names the New Jersey supervisors.

Radium belongs to the same chemical family as calcium, the mineral in bones and teeth. So the painters' bodies took the swallowed radium into their bones and teeth, the way they take in calcium. There the radium kept giving off radiation from inside the body. Radiation damaged the bone marrow, the soft center of the bones that makes blood cells, until the marrow stopped making them. Doctors call this aplastic anemia. The jawbone died and broke down, which doctors call necrosis of the jaw. Some women got bone cancer.

A history published by the National Institute of Standards and Technology states that the radiation "had eaten away their bones from the inside out." Some women's spines collapsed, and they had to wear braces. Their jawbones shattered under light pressure. When doctors examined dial painters' bodies after death, they found 99 percent of the radioactivity in the skeleton.

Grace Fryer began painting dials at the Orange plant on April 10, 1917, and worked there until 1920. Amelia Maggia, called Mollie, painted dials at the company until she died in 1922. In 1924 a dentist, Theodor Blum, found damage to Grace Fryer's jawbone of a kind he had never seen.

Edwin Leman, a chemist at the company, died of aplastic anemia on June 5, 1925. Sarah Maillefer, a dial painter, died on June 18, 1925. Harrison Martland was the medical examiner of Essex County, New Jersey, the doctor who looks into sudden and suspicious deaths there. He examined Leman's body. Martland gave the jaw disease the name "radium jaw."

In May 1927 the lawyer Raymond Berry sued the company for five women. They were Grace Fryer, Katherine Schaub, Quinta Maggia Macdonald, Albina Maggia Larice and Edna Hussman. Mollie Maggia's body was dug up on October 25, 1927. It held 48.4 micrograms of radium. A microgram is one millionth of a gram. Her body held 500 times the amount later set as the limit for a human body.

Company officials first offered each woman $10,000, with her medical and legal costs taken out of it. The women refused. In June 1928 they accepted $10,000 each, a pension of $600 a year and their medical bills. A committee of three doctors had to approve the bills. A pension is money paid every year for the rest of a person's life. Some accounts give the amount each woman got as $15,000. A federal judge, William Clark, arranged the deal on June 4, and the agreement was signed on June 8. The company's officials admitted no blame, and Berry took 10 percent. Von Sochocky, one of the two doctors who founded the company, died of radium poisoning on November 14, 1928. Grace Fryer died in 1933.

In Illinois, the Radium Dial Company advertised for painters in Ottawa in September 1922. The advertisement named a Miss Murray as the person young women should apply to. Catherine Wolfe, who later married and took the name Donohue, described how Miss Murray taught them to point the brushes between their teeth. Supervisors at Radium Dial told the women the paint was safe, and even healthy. They kept the women lip-pointing. From 1925, Radium Dial's managers hired doctors to examine the painters. The doctors told one painter, Peg Looney, that she was very healthy. Nobody told her that she had tested positive for radiation, her niece said later.

Catherine Wolfe Donohue painted dials there and began to feel sick in 1925. Radium Dial's managers fired her in 1931. In her own words, "my limping was causing much talk." She lost half her body weight, and parts of her jaw fell out.

The lawyer Leonard J. Grossman took Catherine Donohue's case for no pay. The case went before the Illinois Industrial Commission, a state board that decided claims by workers hurt on the job. At a hearing on February 10, 1938, she brought a box of pieces of bone that she said had come from her jaw. When the judge asked her doctor about her chances of living, she collapsed. Several men carried her from the room. She weighed 71 pounds. The hearing moved to her home. On April 5, 1938, the hearing officer ruled that her work at Radium Dial had made her sick. The officer awarded her $5,661, which included a pension of $277 a year for life. On July 6, 1938, the members of the Illinois Industrial Commission threw out the company's appeal and added $730.

Catherine Donohue died on July 27, 1938, at the age of 35. According to NPR Illinois, she weighed less than 60 pounds when she died. Grossman said hers was the eleventh death among women who had done that work at the plant. Northern Public Radio later counted fifteen Ottawa workers dead of radium. Radium Dial's lawyers appealed all the way to the United States Supreme Court and lost, and the case ended in October 1938. Because Radium Dial had left Illinois, the Ottawa women together collected only $10,000.

Joseph Kelly lost his post as Radium Dial's president in 1934. He opened a new dial company, Luminous Processes, a few blocks away and hired many of the same workers. That plant ran until 1976. That year, officials of the Nuclear Regulatory Commission, a federal agency, found radiation there 1,666 times the allowed level.
<!-- hb-story:end slug="radium-girls-elements" -->

<!-- hb-zoom level="span" label="Radium sold as medicine" -->
William J. A. Bailey owned Bailey Radium Laboratories in East Orange, New Jersey. He sold Radithor, which was radium dissolved in water. Bailey had falsely claimed degrees from Harvard and from Vienna. In 1927 he had pleaded guilty to practicing medicine without the right to do it. His company sold more than 400,000 bottles of Radithor at $1 each.

Eben Byers was a rich Pittsburgh businessman. In 1927 he hurt his arm at a party on a train after the Harvard-Yale football game, and he began drinking Radithor to heal it. Accounts of how much he drank differ. The Museum of Radiation and Radioactivity at Oak Ridge Associated Universities says he averaged three bottles a day for about two years from December 1927. Other accounts give about 1,400 bottles in all. He stopped in 1930, when his teeth began falling out.

The radium destroyed his bones. A government investigator reported that his whole upper jaw except two front teeth, and most of his lower jaw, had been removed. The rest of his bones were slowly breaking down, and holes were forming in his skull. Byers gave testimony to the Federal Trade Commission, the federal office that acts against companies that cheat or mislead buyers. On December 19, 1931, the commission's officials ordered Bailey to stop claiming that Radithor was harmless or that it healed people. Byers died months later, in 1932, at the age of 51.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Lead in gasoline and paint" -->
Lead is a soft, heavy metal and an element. Lead poisoning is the harm lead does to the body once a person swallows it or breathes it in. The National Institute for Occupational Safety and Health (NIOSH) is the federal office that studies dangers at work. Its list of what large doses of lead do includes paralysis, which means a person cannot move part of the body. The list also includes madness, gout (painful, swollen joints), colic (sharp pains in the belly) and death.

Thomas Midgley Jr., a researcher at General Motors (GM), found that adding tetraethyl lead to gasoline stopped engine "knock." Tetraethyl lead is a liquid made of lead joined with other chemicals. Knock is a pinging sound in an engine that runs on gasoline. Charles Kettering ran GM's research. In August 1924, GM and Standard Oil of New Jersey formed the Ethyl Gasoline Corporation to sell tetraethyl lead. The DuPont company made it.

The workers who made tetraethyl lead died of lead poisoning, and the counts of the dead differ. Bill Kovarik counted them in a 2005 article in a journal about workers' health. Standard Oil ran the Bayway refinery in Elizabeth, New Jersey, a plant that turned oil into gasoline and other products. Seven men died there in October 1924, and 33 went to the hospital. Between September 1923 and the fall of 1924, ten more workers died at a DuPont plant in Deepwater, New Jersey. At GM's laboratory in Dayton, Ohio, at least two died, and 40 went to the hospital. Kovarik's numbers add up to at least 19 dead. Other accounts give five dead at Bayway and 35 in the hospital. In 2021, NIOSH counted 15 worker deaths from making tetraethyl lead in the 1920s.

Kovarik describes how the work poisoned the men. The tanks that held the chemicals were not closed off from the workers, who had to open them between steps. Workers squeezed half-melted lead through metal grates with shovels and with their boots. At Bayway, poisoned men had to be held down and tied into straitjackets, coats that pin a person's arms to the body. Kovarik's account does not say who restrained them. Their bodies were black and blue from muscle spasms they could not stop. They saw things that were not there, such as flying insects, and some could suddenly turn violent or want to kill themselves. Workers called tetraethyl lead "loony gas."

Frank Mann was the Bayway plant supervisor in 1924. He said, "These men probably went insane because they worked too hard." A month before the deaths, in September 1924, engineers from DuPont had visited Bayway and called its safety measures "grossly inadequate." Joseph G. Leslie, a Bayway worker poisoned there, was kept in a mental hospital for 40 years. Only his wife, Gertrude, and later his son knew he was alive. Everyone else believed he had died. Kovarik does not say who sent Leslie to the hospital or who spread the story that he was dead. Kovarik names no manager of the Deepwater plant or the Dayton laboratory apart from Midgley and Kettering.

On October 30, 1924, Midgley held a press conference. He poured tetraethyl lead on his hands and breathed its vapor for about 60 seconds, to show it was safe. A few months earlier, lead had made him seriously ill. At the same event he acknowledged the two deaths in Dayton. He also said more than 50 workers were "under observation" for lead poisoning.

The Surgeon General is the head of the Public Health Service, the federal office in charge of the nation's health. On May 20, 1925, Surgeon General Hugh Cumming brought more than 100 people from industry and from public health to a meeting in Washington. Frank Howard of Standard Oil said the industry could not give up "what has come to the industry like a gift from heaven." Yandell Henderson studied how the body works at Yale. He called tetraethyl lead "one of the most dangerous things in the country today." Alice Hamilton of Harvard told Kettering there were "thousands of things better than lead."

In 1926 the members of a Surgeon General's committee reported "no good grounds" for a ban and asked for more study. The Ethyl company paid Robert Kehoe of the University of Cincinnati to study lead. Kehoe set out the industry's "safe level" theory, the claim that lead below a certain amount did no harm. That claim stayed the industry's position for decades.

Painters also used paint that contained lead. NIOSH states that between 1925 and 1927, more painters died of lead poisoning than workers in all other jobs combined. The International Labour Organization is a world body that sets rules for workplaces. In November 1921, delegates at its conference in Geneva agreed on a treaty that banned lead paint for the insides of buildings. The ban took effect in 1923 in the countries that accepted it. The United States did not belong to the organization until 1934, and it was still outside the ban in 2017.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Mercury in Danbury's hat shops" -->
The hatters of Danbury, Connecticut, the workers who made hats there, kept breathing mercury at work after 1900. They used it to turn fur into felt, the thick cloth of pressed fur that hats were made of. In 1913 Connecticut lawmakers added mercury poisoning to the state's workmen's compensation law. Under a law of that kind, employers pay workers who are hurt or made sick by their jobs.

In 1922, Alice Hamilton examined 100 Danbury hatters and found 43 with mercury poisoning. Some shook so hard from tremors that they could not feed themselves. The union hatters kept demanding investigations. A union is a group of workers who join together to bargain with their employers. Grace Mailhouse Burnham, who had set up the Workers' Health Bureau, found a way to make felt without mercury in the Soviet Union. She could not get the hat manufacturers to agree to use it. Government researchers made a full study only in 1937. They found many hatters poisoned by mercury. They also found that drinking and smoking had not caused the hatters' symptoms, as some manufacturers and insurance companies had claimed in court. The historian Shirley Wajda's account of the Danbury shakes names no factory owner.

Officials of the Public Health Service then worked out an agreement with the hatters' unions and the hat manufacturers in the 26 states that made hats. Under it, hat shops stopped using mercury. On December 1, 1941, Connecticut Governor Robert A. Hurley announced his state's ban. He said "it was possible to manufacture good fur felt hats without making physical wrecks out of hundreds of workers." The hat shops used hydrogen peroxide in place of mercury. Mercury is still in Danbury's soil and in the mud of the Still River.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Arsenic smoke in Montana" -->
Arsenic is an element and a strong poison. A smelter is a plant where workers melt ore, rock that contains a metal, to get the metal out of it. In 1902 the Anaconda Copper Mining Company started its Washoe smelter at Anaconda, Montana, about 25 miles from the copper mines of Butte. When the smelter melted copper ore, arsenic went up its smokestack with the smoke. Farmers nearby reported livestock dying in the smelter's first year.

In 1904 farmers in the Deer Lodge Valley formed an association to sue the company. The case was *Bliss v. Anaconda Copper Mining Co.* Fred J. Bliss filed it in 1905. His 320-acre farm lay about five miles from the smelter. In 1909 the judges of a federal appeals court found that arsenic had poisoned the farmers' livestock and crops. The judges still refused to close the smelter.

The company's officers then bought out many of the farmers. From the rest they bought "smoke easements." An easement is a legal right to use land that someone else owns. A smoke easement gave the company the right to send its smoke over a farm. The 1909 court ruling and the EPA's history of the site do not name the officers who ran the smelter or chose the buyouts. Neither counts the people harmed by the arsenic.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Uranium from Navajo land" -->
Uranium is a heavy metal element. Its atoms break apart slowly and give off radiation. From 1941, Native American miners, among them Navajo, Pueblo and Hopi people, worked in uranium and vanadium mines in the Southwest. Vanadium is another metal element. In 1943 the Vanadium Corporation of America began mining uranium in secret on Navajo land.

The Environmental Protection Agency (EPA) is the federal office whose staff work to protect the country's air, water and land. EPA staff report that from 1944 to 1986, miners working for mining companies dug nearly 30 million tons of uranium ore out of Navajo land. They mined under leases with the Navajo Nation. A lease is an agreement to use land for a set time in return for payment.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="A false first, and the machine at Berkeley" -->
In 1931 the physicist Fred Allison of Alabama Polytechnic, now Auburn University, announced two new elements. He called element 85 "alabamine" and element 87 "virginium." He said he had found them with a machine he used in his lab. Scientists at other labs tried his method and could not get the same results. They showed that the signals Allison saw came from his equipment, not from any element. Scientists stopped accepting his claims. A Berkeley team made the real element 85 in 1940.

Ernest Lawrence built his first cyclotron at Berkeley, California, in 1930 and 1931. A cyclotron is a machine that whirls tiny charged particles in a spiral up to high speed. When the fast particles hit a target, they can turn atoms of one element into atoms of another. With his machines, Berkeley's Radiation Laboratory became the source of most of the new elements made in the United States.
<!-- /hb-zoom -->

<!-- hb-story:start slug="ernest-lawrence-elements" name="Ernest Lawrence" movie="" kind="famous" status="verified" -->
### Ernest Lawrence

> **Who:** The physicist who invented the cyclotron, the machine behind most of the elements discovered in the United States.
> **When and where:** Berkeley, California, from the 1930s to the 1950s. He won the Nobel Prize in Physics in 1939 and died in 1958.

After his first cyclotron of 1930 and 1931, Ernest O. Lawrence and his teams built larger ones. The 60-inch cyclotron of 1939 had a magnet that weighed 220 tons. The Radiation Laboratory at Berkeley became an independent laboratory in 1936.

Lawrence won the Nobel Prize in Physics in 1939. The Nobel Prize is an international award given each year for work in science and other fields.

Lawrence's machines made the material for several new elements. A metal sheet from his 37-inch cyclotron held the technetium that Segrè and Perrier found. Teams used his 60-inch cyclotron to make astatine and plutonium in 1940. Lawrence died in 1958. Element 103, lawrencium, carries his name.
<!-- hb-story:end slug="ernest-lawrence-elements" -->

<!-- hb-zoom level="span" label="Elements made by people" -->
The periodic table is a chart that lists the elements in order, with elements that act alike grouped together. Dmitri Mendeleev published his periodic table in Russia in 1869. His table had a gap at element 43, below manganese. Early in 1937, Lawrence mailed a thin sheet of a metal called molybdenum to Emilio Segrè in Palermo, Sicily. The sheet had been part of the 37-inch cyclotron. Segrè and the mineralogist Carlo Perrier, a scientist who studies minerals, took a few billionths of a gram of element 43 out of it. They named it technetium, from a Greek word meaning "artificial." Technetium was the first element made by people. Italian scientists did the chemistry, and the material came from an American machine.

Dale R. Corson, Kenneth R. MacKenzie and Segrè made element 85 at Berkeley in 1940. They struck the element bismuth with alpha particles in the 60-inch cyclotron. Element 85 was the element Allison had called "alabamine." In 1947 its makers named it astatine, from a Greek word for "unstable."

Also in 1940, Edwin McMillan and Philip Abelson found element 93 in uranium that had been struck in the cyclotron. It was the first element heavier than uranium. Uranium was named for the planet Uranus, so they named element 93 neptunium, for Neptune, the next planet out.

On December 14, 1940, Glenn Seaborg, McMillan, Joseph W. Kennedy and Arthur C. Wahl made element 94 in the 60-inch cyclotron. On the night of February 23 and 24, 1941, they proved by chemistry that it was a new element. They did it in Room 307 of Gilman Hall at Berkeley, which is now a National Historic Landmark. They named the element plutonium, for the planet Pluto. Seaborg chose the symbol Pu instead of "Pl" as a joke, because "pee-yoo" is what people say about a bad smell. The members of the naming committee accepted it. Government officials kept the work secret from the start. During World War II, American scientists used plutonium and uranium to build atomic bombs.

Seaborg's circle made element 96 in the summer of 1944, with Ralph A. James and Albert Ghiorso on the team. They named it curium, for Marie and Pierre Curie. Element 95 came next, in 1944 and 1945, with Leon O. Morgan also on the team. It was named americium, for the Americas. Much of this work took place at the Metallurgical Laboratory, a secret wartime lab in Chicago.

On November 11, 1945, Seaborg was a guest on a children's radio show called *Quiz Kids*. A boy asked him whether any new elements had turned up during the war. Seaborg said yes, elements 95 and 96. He told the boy five days before he planned to announce them to the American Chemical Society, a national group of chemists.

Jacob A. Marinsky, Lawrence E. Glendenin and Charles D. Coryell found element 61 in 1945 at Clinton Laboratories in Oak Ridge, Tennessee. The lab is now Oak Ridge National Laboratory. They found the element in the leftovers of uranium atoms that had been split. Grace Mary Coryell, Charles Coryell's wife, suggested the name promethium. It honors Prometheus, who stole fire from the gods in Greek stories. The team announced the element in 1947. Promethium is still the only element ever discovered in Tennessee.

In December 1949, Stanley G. Thompson, Ghiorso and Seaborg made element 97 at Berkeley. They struck americium with alpha particles in the 60-inch cyclotron. They named it berkelium, for Berkeley.
<!-- /hb-zoom -->

<!-- hb-story:start slug="emilio-segre-elements" name="Emilio Segrè" movie="" kind="famous" status="verified" -->
### Emilio Segrè

> **Who:** An Italian physicist who stayed in the United States after Benito Mussolini and his officials barred Jews like him from university jobs in Italy, and who helped find two elements.
> **When and where:** Palermo, Sicily, and Berkeley, California, from 1937 into the 1940s. He lived in the United States from 1938 and died in 1989.

Emilio Segrè worked with Carlo Perrier in Palermo in 1937. From the metal sheet that Ernest Lawrence mailed them, they identified technetium, the first element made by people.

In the summer of 1938, Segrè was visiting Berkeley. While he was there, he learned that Benito Mussolini and his officials in Italy had issued new racial laws against Jews. Under them, Italian officials took university jobs away from Jews, and Segrè was Jewish. He stayed in the United States and became an American citizen.

At Berkeley, Segrè helped make astatine in 1940. With Glenn Seaborg, he showed in 1941 that atoms of plutonium-239 could be split. He won the Nobel Prize in Physics in 1959 for his work on the antiproton. The antiproton is a tiny particle with the opposite electric charge of the proton, one of the particles in the center of every atom.
<!-- hb-story:end slug="emilio-segre-elements" -->

<!-- hb-story:start slug="glenn-seaborg" name="Glenn Seaborg" movie="" kind="famous" status="verified" -->
### Glenn Seaborg

> **Who:** The chemist whose teams found plutonium and nine more elements, and the first person to see an element named for him while he was alive.
> **When and where:** Berkeley, California, and wartime Chicago, from 1940 to 1974. He died in 1999.

Glenn T. Seaborg led the team that made plutonium in December 1940 and proved it was a new element in February 1941. In all, he helped discover ten elements, numbers 94 through 102 and number 106. One of the ten, nobelium, was later credited to scientists at Dubna in the Soviet Union.

In 1951, Seaborg shared the Nobel Prize in Chemistry with Edwin McMillan for their work on the elements heavier than uranium. From 1961 to 1971, he was chairman of the Atomic Energy Commission, the federal agency in charge of atomic energy.

In 1997 element 106 was named seaborgium, after him. Seaborg joked that a letter addressed only in element names would reach him: Seaborgium, Lawrencium, Berkelium, Californium, Americium. That stood for Seaborg, at the Lawrence laboratory, in the city of Berkeley, in California, in America.
<!-- hb-story:end slug="glenn-seaborg" -->
<!-- hb-time:end id="1900-1950" -->

<!-- hb-time:start id="1950-2000" order="09" chapter="elements" label="1950 to 2000" state="full" progress="written" -->
## 1950 to 2000

<!-- hb-zoom level="era" -->
Scientists at Berkeley and other American labs made or claimed elements 98 through 106 from 1950 to 1974. Scientists at Dubna, a lab in the Soviet Union, claimed several of the same elements. The two sides argued for decades over who had found them first. In 1992 and 1993, the members of an international panel gave some credit to Berkeley, some to Dubna, and split the rest.

In the same years, uranium mining on Navajo land reached its peak. Miners breathed radioactive gas underground, and most small mines had no fresh air blown in until the 1960s or later. Government researchers and mine owners did not tell the miners the danger. Hundreds of miners died of lung disease and cancer. Scientists also showed that lead was harming children's brains. Between 1971 and 1996, federal officials limited and then banned lead in house paint and in gasoline for cars.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Elements from Berkeley and from a bomb test" -->
Early in 1950, Kenneth Street Jr., Stanley G. Thompson, Albert Ghiorso and Glenn Seaborg made element 98 at Berkeley. They struck curium with helium particles. They announced the element on March 17, 1950, and named it californium, for the state and its university.

Elements 99 and 100 turned up in the dust of a hydrogen bomb test called Ivy Mike. The test took place at Enewetak Atoll in the Pacific Ocean on November 1, 1952. A hydrogen bomb is a bomb far more powerful than the first atomic bombs. An atoll is a ring of small coral islands. The Ivy Mike blast wiped out one of the atoll's islands, Elugelab, turning it to vapor. Drone planes with no one aboard flew through the mushroom cloud, carrying filter papers to catch the dust. Workers then shipped tons of coral from the blast site to Berkeley. In the dust and coral, Ghiorso and teams from Berkeley, Argonne and Los Alamos found two new elements. In the blast, uranium atoms had soaked up huge numbers of neutrons. A neutron is one of the tiny particles in the center of an atom.

Government officials classified the discoveries, which means they kept them secret. The scientists published them on August 1, 1955, with the names einsteinium and fermium. By then both of the men they honored had died. Enrico Fermi died in November 1954, and Einstein died in April 1955. Neither man was told that an element would carry his name.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Seventeen atoms, one at a time" -->
In 1955 a Berkeley team made element 101 from about a billion atoms of einsteinium. That was all the einsteinium that existed. The team was Ghiorso, Bernard G. Harvey, Gregory R. Choppin, Thompson and Seaborg. They struck the einsteinium with particles, and the new atoms flew off onto a gold foil. Ghiorso had worked out this way of catching atoms. The team dissolved the foil and rushed it through the chemistry.

They made 17 atoms of element 101 in all. It was the first element identified one atom at a time. In the scientists' own telling, Ghiorso wired the detector to the building's fire alarm, so the bell rang for each new atom. He forgot to disconnect it, and the alarm later emptied the building late at night.

The team named element 101 mendelevium, for Dmitri Mendeleev, the Russian who made the periodic table. That was during the Cold War, the long contest between the United States and the Soviet Union. Seaborg asked the United States government for approval before he used a Russian's name. A French chemist later told Ghiorso that the name did more for American and Soviet relations than most diplomacy. Diplomacy is the work of officials who handle dealings between countries.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The fight over elements 102 to 106" -->
Scientists in three countries worked on element 102. In 1957 a team in Stockholm, Sweden, claimed it and named it nobelium, for Alfred Nobel. The Swedish team then took back its claim. Berkeley scientists claimed the element in 1958. Scientists at Dubna did experiments on it in 1966.

The International Union of Pure and Applied Chemistry (IUPAC) is the world organization of chemists that approves element names. A joint panel of chemists and physicists, called the Transfermium Working Group, studied who had found what. Transfermium means the elements after fermium, element 100. Its report came out in 1992 and 1993. The panel's members credited Dubna with element 102. IUPAC's officials kept the Swedish name nobelium anyway, because scientists had used it for more than 30 years.

Ghiorso, Torbjørn Sikkeland, Almon E. Larsh and Robert M. Latimer made element 103 at Berkeley in 1961. Dubna scientists did important work on it from 1965 to 1967. The Working Group's members split the credit between the two labs. The element kept the name lawrencium, for Ernest Lawrence.

Dubna scientists claimed element 104 in 1964, and Berkeley scientists claimed it in 1969. For element 105, the Dubna claim came in 1968 and the Berkeley claim in 1970. Each side gave the elements its own names and argued for them in science journals for decades. The Working Group's members split the credit for both. They credited Berkeley alone with element 106, made there in 1974.

In 1994 IUPAC's officials proposed a rule against naming elements for living people. Under that rule, IUPAC's officials could not have approved the Berkeley name, seaborgium. In 1997 they approved the final names. Element 104 was named rutherfordium, after the scientist Ernest Rutherford, and element 105 dubnium, after the town of Dubna. Element 106 became seaborgium. Glenn Seaborg was the first person to see an element named for him while he was alive. He kept a periodic table with seaborgium on it until he died in 1999.
<!-- /hb-zoom -->

<!-- hb-story:start slug="albert-ghiorso" name="Albert Ghiorso" movie="" kind="famous" status="verified" -->
### Albert Ghiorso

> **Who:** The builder of instruments who helped discover more elements than anyone else in history, without ever earning a doctorate.
> **When and where:** Berkeley, California, from 1944 to 1974, with work into the 1990s. He died in 2010.

Albert Ghiorso helped discover 12 elements, americium through seaborgium, numbers 95 to 106. Guinness World Records lists that as the most elements discovered or co-discovered by one person. He never earned a doctorate, the highest university degree.

Ghiorso built the tools the element hunters needed, among them the detectors. He worked out the method of catching new atoms on a foil, which his team used to find mendelevium in 1955. He also ran the HILAC, a machine at Berkeley that sped up particles to make new elements. In the stories his colleagues told, he wired the mendelevium counter to a fire alarm. Another of their stories has him driving fresh, radioactive samples across the lab in a Volkswagen car.
<!-- hb-story:end slug="albert-ghiorso" -->

<!-- hb-story:start slug="darleane-hoffman-elements" name="Darleane Hoffman" movie="" kind="famous" status="verified" -->
### Darleane Hoffman

> **Who:** A nuclear chemist who proved that plutonium, an element people had made in labs, also occurs in nature.
> **When and where:** Los Alamos, New Mexico, from 1953, and Berkeley, California, from 1984. She died in 2025, at the age of 98.

Darleane C. Hoffman was a nuclear chemist, a chemist who studies atoms that break apart and give off radiation. She began work at Los Alamos in 1953. In 1971 she found traces of plutonium-244 in ancient rock from the Mountain Pass mine in California. Plutonium had been known only as an element made in labs. Her find showed that tiny amounts of it also occur naturally on Earth.

Hoffman showed that atoms of fermium-257 could split in two on their own. She was the first woman to lead a science division at Los Alamos. From 1984 she led work at Berkeley on the chemistry of the heaviest elements, studying them one atom at a time.

She won the National Medal of Science in 1997. In 2000 she won the Priestley Medal of the American Chemical Society, named for Joseph Priestley. She was the second woman ever to receive it.
<!-- hb-story:end slug="darleane-hoffman-elements" -->

<!-- hb-zoom level="span" label="Elements at home" -->
Many home smoke detectors hold a speck of americium-241, about a third of a millionth of a gram. The americium gives off alpha particles inside a small chamber. The particles let a tiny electric current run through the air in the chamber. Smoke that drifts in disturbs the current, and the alarm goes off.

Silicon is an element that was discovered in Sweden in 1824. Computer chips are made of it, and Silicon Valley takes its name from the element in the chips made there.

By 1996 the federal helium program owed $1.4 billion. That year the members of Congress passed the Helium Privatization Act and ordered the Federal Helium Reserve sold.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Uranium miners on Navajo land" -->
The Atomic Energy Commission (AEC) was the federal agency in charge of atomic energy. EPA staff state that the AEC was the only buyer until 1966 and kept buying ore until 1970. Doug Brugge and Rob Goble, writing in the *American Journal of Public Health* in 2002, say the government was the only buyer from World War II until 1971.

About 10,000 people worked in uranium mining in all, and about a quarter of them were Navajo. The mining peaked in the middle of the 1950s, with about 750 mines working. The companies named in the records include the Vanadium Corporation of America, Kerr-McGee, the United Nuclear Corporation and Hydro Resources Inc.

When uranium atoms break apart, they turn into radon, a radioactive gas. Radon atoms then break apart into radioactive specks called radon daughters. Miners breathed them in. Brugge and Goble explain that the daughters stay in the lungs next to delicate cells and hit those cells with strong doses of radiation. The harm named in the records is lung cancer and lung fibrosis. Lung fibrosis is scarring that makes the lungs stiff, so that breathing gets harder.

Navajo miners report that no one told them about the dangers of uranium mining, and that they got no protective equipment and no ventilation. Ventilation means the fans and shafts that blow fresh air into a mine and push radon out. Scientists already knew about the danger from uranium mines in Europe. Brugge and Goble found that few protections reached American miners before 1962, and they came slowly after that.

Members of a federal panel, the Advisory Committee on Human Radiation Experiments, traced who made these choices in their 1995 report. In 1948 Merril Eisenbud, a safety expert in the AEC's New York office, urged the AEC to write safety rules into its contracts to buy ore. Officials of two AEC divisions, Biology and Medicine and Raw Materials, rejected his advice. They said the law gave the AEC no power over safety in the mines.

From 1950, Public Health Service workers led by Duncan Holaday and Victor Archer followed the miners to measure their cancer risk. The researchers tracked 3,415 miners, and 779 of them were Native American. Brugge and Goble found that the researchers did not tell the miners about the risks they were studying. At first the researchers left the minority miners out of the results. The researchers said they wanted "a homogeneous population," which means a group of people who are all alike.

Duncan Holaday later testified in court that the researchers made a spoken agreement with the mine owners not to tell the miners what they found. The researchers made that deal so the owners would let them into the mines.

Staff of the AEC and of the Public Health Service met on January 25, 1951. The staff at that meeting believed the radon in the mines was at levels that would cause cancer. They agreed that ventilation could lower it, but they called it "unrealistic" to set a limit the mine owners had to meet.

Wilhelm Hueper, a cancer researcher at the National Cancer Institute, warned about radon. In 1952 Shields Warren of the AEC asked the institute's director to stop Hueper from giving his lung cancer figures in a speech to the Colorado Medical Society. Hueper's figures showed lung cancer in 40 to 75 percent of the radioactive ore miners in Europe. The director ordered Hueper to cut them, and Hueper did not give the speech. Warren then asked that Hueper be fired. Hueper kept his job, but Victor Archer later said Hueper was forbidden to travel west of the Mississippi River for his research. The 1995 committee report that gives Archer's account does not say who gave that order.

Public Health Service officials urged the mining companies to ventilate. Some large mines got ventilation in the 1950s and 1960s, but most small mines got none until the 1960s or later. The first federal radon limit for these mines came in 1967, from Secretary of Labor Willard Wirtz. The committee's members found that the mine owners, the state governments and the federal government all had a duty to ventilate the mines after 1951.

In 1984, in a case called *Begay v. United States*, a federal judge found that Public Health Service officials, working under the Surgeon General, decided not to warn the miners because they feared many would quit. The judge still ruled that the miners could not sue the United States government. In the ruling, the judge wrote that the miners' situation "cries for redress," meaning that it called out to be put right, and called it a "tragedy of the nuclear age."

No surviving record gives a full count of the Navajo miners who died. Linda M. Richards, writing in 2013 for *Distillations*, the magazine of the Science History Institute, reported that by the early 1980s, "hundreds of Indian miners had died from lung diseases and cancers." Brugge and Goble cite a study from 2000 that found 94 deaths from lung cancer among Navajo people from 1969 to 1993. Of those 94, 63 had been uranium miners. The members of the 1995 federal committee reported that by 1990, 410 of the 4,100 miners in the Public Health Service study had died of lung cancer. About 75 such deaths would have been expected in a group that size.

Harris Charley was a Navajo uranium miner. His records show he breathed 1,192 "working level months" of radon, a unit that measures how much radon a miner breathed over time. He died of lung fibrosis in 1986. His son, Perry H. Charley, became an environmental scientist. Perry Charley worked with Stewart Udall, a former Secretary of the Interior, to investigate the miners' illnesses. In 1996 he helped start the Uranium Education Program at Diné College. Diné is the Navajo people's own name for themselves. Navajo organizers, among them Harry Tome, Perry Charley and Phil Harrison, pushed for help for the miners from the 1960s on.

On October 5, 1990, the members of Congress passed the Radiation Exposure Compensation Act. President George H. W. Bush signed it on October 15, 1990. Under it, a uranium worker made sick by radiation on the job could claim one payment of $100,000, if the worker met the law's rules.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The spill at Church Rock" -->
On July 16, 1979, an earthen dam broke near Church Rock, New Mexico. The United Nuclear Corporation owned the dam, which held waste from its uranium mill. A mill is a plant that takes uranium out of the crushed rock. Tailings are the ground-up rock left behind after the uranium is taken out.

Accounts of the spill give different amounts. Richards gives 1,000 tons of radioactive tailings and 93 million gallons of acid, radioactive water. New Mexico's Environmental Improvement Division, the state office that checked for pollution, gives 1,100 tons and 94 million gallons. The waste ran at least 80 miles down the Rio Puerco, a river that flows past the homes of about 1,700 Navajo people.

A curie is a unit that measures radioactivity. The Church Rock spill released 46 curies of radiation. The accident at the Three Mile Island nuclear power plant, four months earlier, released 13. The U.S. Geological Survey called Church Rock "the largest accidental radioactive release in the United States." The Environmental Improvement Division's own report reached a different view. Its authors concluded that the spill's effects "on people and the environment were quite limited." They wrote that the water pumped out of the mines into the Puerco River might be a greater long-term danger.

Within a few hours, officials of the Environmental Improvement Division began testing the river. They ordered United Nuclear to stop sending waste to the broken pond. United Nuclear stopped milling for about three months. No official declared an emergency or ordered anyone to leave. New Mexico's governor, Bruce King, turned down the Navajo Nation's request to have the area declared a federal disaster area, according to news accounts. The state's report on the spill names no United Nuclear official as responsible for the dam.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Lead: the proof and the bans" -->
In the 1960s, thousands of American children each year went to the hospital with lead encephalopathy, and about one in four of them died. Encephalopathy means swelling and damage of the brain. A 2007 review in the journal *Environmental Health Perspectives* states those numbers.

David Rosner and Gerald Markowitz, writing in the *American Journal of Public Health* in 2012, describe where the lead came from. Before the 1960s, they write, the poisoned children usually lived in old, poorly kept slum housing. The children had swallowed flakes of lead paint and went into convulsions, fits of violent shaking they could not control. Rosner and Markowitz call lead paint in older buildings the major source of lead around children. The 2007 review names the main ones to blame: the paint and pigment industry, the oil industry and a few scientists paid by industry. Lead harms a child's growing brain. It lowers intelligence and causes trouble with reading, paying attention and behavior. The review states that no safe level of lead is known.

Clair Patterson, a geochemist at Caltech, measured lead in the air at about 1,000 times its natural level. A geochemist is a scientist who studies the chemistry of rocks and the Earth. In a paper in 1965, Patterson called Kehoe's "safe level" idea "an ill-defined opinion unsupported by any evidence." In the 1970s, Herbert Needleman, a children's doctor in Pittsburgh, measured the lead in the baby teeth of about 2,500 schoolchildren. Children with more lead in their teeth did worse in school. Scientists paid by the lead industry challenged his work. Later reviews backed his findings, according to Kovarik.

In 1971 the members of Congress passed the Lead-Based Paint Poisoning Prevention Act. Under that law, homes built or repaired with federal money could have only limited amounts of lead paint. In 1972 the limit for lead in paint was set at 0.5 percent. In 1978 officials of the U.S. Consumer Product Safety Commission banned lead paint in all homes. From then on, house paint could hold no more than 0.06 percent lead. Homes built before 1978 are still likely to have some lead paint.

EPA officials began work on a rule to cut the lead in gasoline in 1972 and 1973. Gas stations began selling unleaded gasoline, and car makers built cars for it, in 1975 and 1976. The Clean Air Act's ban on leaded gasoline for cars and trucks took effect on January 1, 1996. On January 29, 1996, EPA Administrator Carol M. Browner announced the last step in 25 years of cutting lead out of gasoline. She said the amount of lead in children's blood had fallen 70 percent.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Poisoned ground put on the cleanup list" -->
The Superfund program is the federal program for cleaning up the country's most dangerous waste sites. The National Priorities List is the list of sites chosen for that cleanup. In 1983 EPA officials put both the Anaconda smelter site in Montana and the Church Rock mill on the list.

Smelting at Anaconda stopped in 1980. EPA staff count nearly 100 years of smelting at the whole site, and it left arsenic, cadmium, copper, lead and zinc over more than 200 square miles. EPA lists Atlantic Richfield as the company responsible for the cleanup.
<!-- /hb-zoom -->
<!-- hb-time:end id="1950-2000" -->

<!-- hb-time:start id="2000-today" order="10" chapter="elements" label="2000 to Today" state="full" progress="written" -->
## 2000 to Today

<!-- hb-zoom level="era" -->
Joint Russian and American teams made elements 114 through 118 between 1998 and 2010. The atoms formed at Dubna, in Russia. Scientists from American labs brought detectors and, for element 117, the only target material in the world that would work. In 2015 and 2016, IUPAC's officials recognized the last four elements of the seventh row of the periodic table and gave them names.

EPA staff were still counting old uranium mines and cleaning up poisoned ground. As of June 2026, they count 523 abandoned uranium mines on the Navajo Nation. From 2014 to 2015, after managers appointed by Michigan's governor switched the water supply of Flint, Michigan, the water carried lead from old pipes to the city's people.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Finishing the seventh row" -->
Scientists at the Joint Institute for Nuclear Research in Dubna, Russia, worked with scientists from Lawrence Livermore National Laboratory in California. For elements 115 and 117, scientists from Oak Ridge National Laboratory and Vanderbilt University joined them. The first atom of element 114 formed at Dubna in December 1998. Element 116 followed in 2000.

In May 2012, IUPAC's officials named element 114 flerovium, for Russia's Flerov Laboratory. They named element 116 livermorium, for the Livermore laboratory and the city of Livermore, California.

On December 30, 2015, IUPAC's officials recognized elements 113, 115, 117 and 118. That filled the seventh row of the periodic table. IUPAC's officials announced the names on November 28, 2016. Scientists at RIKEN, a research institute in Japan, made element 113, the first element discovered in Asia, and it became nihonium. Element 115 was named moscovium, for the region around Moscow, and element 117 tennessine, for Tennessee.

Element 118 became oganesson, for Yuri Oganessian, the Dubna physicist who led the hunt for these heavy elements. It was only the second element named for a living person, after seaborgium. His colleagues asked him to leave the conference call before they voted on the name. IUPAC's officials credited these elements to the joint teams, made up of scientists from several countries who worked together.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Tennessine and the berkelium target" -->
The partnership on element 117 began when Joe Hamilton of Vanderbilt University introduced Jim Roberto of Oak Ridge to Yuri Oganessian. To make element 117, the Dubna team needed a target made of berkelium-249. The only place that could make it was a research reactor at Oak Ridge National Laboratory. The berkelium spent 250 days in the reactor. Oak Ridge chemists then spent 90 days working on it. They ended up with 22 milligrams. A milligram is one thousandth of a gram.

The berkelium was shipped in June 2009. Russian customs officials, who check what comes into a country at its border, twice rejected the paperwork, so the package crossed the Atlantic Ocean five times. At Dubna, scientists fired a beam of calcium-48 atoms at the target for six months. They made six atoms of element 117. The team published the discovery in April 2010.

Tennessee became the second American state named on the periodic table, after California. The atoms of tennessine formed in Russia. Promethium, found at Oak Ridge in 1945, is still the only element discovered in Tennessee.
<!-- /hb-zoom -->

<!-- hb-story:start slug="clarice-phelps" name="Clarice Phelps" movie="" kind="famous" status="verified" -->
### Clarice Phelps

> **Who:** A nuclear chemist at Oak Ridge National Laboratory and a U.S. Navy veteran. Her laboratory's staff profile describes her as the first Black woman involved in the discovery of an element.
> **When and where:** Oak Ridge National Laboratory, Tennessee, from 2009. Her berkelium work began in 2010, and the laboratory recognized her in 2019.

Clarice Phelps served in the U.S. Navy and graduated from Tennessee State University. She joined Oak Ridge National Laboratory in 2009. Her first job there was as a nuclear operations technician.

From 2010 she worked in the laboratory's Nuclear Security and Isotope Technology Division. There she was part of a team that helped purify berkelium-249. To purify a substance means to remove everything else from it. Scientists used that berkelium to confirm the discovery of element 117. The berkelium for the first run at Dubna had shipped in June 2009, before she began this work.

A 2019 news release from Oak Ridge National Laboratory described her as "the first African American woman to be involved with the discovery of an element, tennessine." That first is her laboratory's claim. IUPAC's officials credited Oak Ridge as a laboratory, not its scientists one by one. Also in 2019, she was named to the Periodic Table of Younger Chemists, a project of IUPAC and the International Younger Chemists Network.
<!-- hb-story:end slug="clarice-phelps" -->

<!-- hb-zoom level="span" label="Toward element 120, and the end of federal helium" -->
In 2024 the Heavy Element Group at Berkeley Lab made two atoms of livermorium in a new way. They fired a beam of titanium-50 at plutonium-244 in the lab's 88-Inch Cyclotron. Berkeley Lab's news center reported the result on July 23, 2024. The test showed that the method could work for element 120. Element 120 would start the eighth row of the periodic table, and it would be the heaviest atom ever made. The Berkeley team began runs to make it in 2025, firing titanium-50 at californium-249. As of August 2026, no one had announced a discovery.

Federal officials sold the Federal Helium System to Messer, a company that sells industrial gases. The system included the reserve, the Cliffside gas field and a pipeline 423 miles long. The sale was completed in June 2024. Messer's accepted bids, opened in January 2024, totaled $423.35 million. Officials of the Bureau of Land Management, a federal agency, stated in 2024 that the sale in the end sent about $460 million to the U.S. Treasury. The Treasury is the government's money office. Helium is still scarce. Hospitals need it for MRI machines, which take pictures of the inside of the body. Rocket makers and computer chip makers use it too.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Uranium on Navajo land today" -->
Elsie Mae Begay, a Navajo woman, lived in Monument Valley below the abandoned Skyline uranium mine. Two of her sons who had lived with her died, one of lung cancer and the other of a tumor. Linda Richards, who reported her story in 2013, calls them rare cancers. Richards does not say whether doctors linked the sons' cancers to the mine.

Begay's family hogan, a traditional Navajo house, gave off radiation up to 100 times the acceptable level, the Associated Press reported. When her children were young, they had played in piles of uranium tailings, the ground-up rock left over after uranium is taken out. Richards writes that people testing Navajo homes found dangerous radioactivity where families had built with mine debris or mixed it into concrete floors. EPA officials treated the Begay hogan as nuclear waste. In 2001 men in radiation suits took it apart and hauled it away.

In 2005 the members of the Navajo Nation Council passed the Diné Natural Resources Protection Act. Under it, uranium mining is banned on Navajo land.

The counts of old mines differ. EPA staff count 523 abandoned uranium mines on the Navajo Nation as of June 2026. They have money to study and clean up 230 of them, and they list 46 as priority mines. In 2013, Richards counted at least 1,032 abandoned mine sites on Navajo land. She also counted 38 water sources with more radioactive elements than health limits allow.

By June 2026, EPA's agreements and settlements over the mines were worth more than $1.7 billion. A settlement is an agreement to pay money to end a legal fight. One of the settlements was made in 2015 with the Tronox company in bankruptcy court, the court that handles a company that cannot pay its debts. An EPA page updated in September 2026 states that EPA officials have added the Lukachukai Mountains Mining District to the Superfund list.

By March 2001, about 3,975 uranium workers had applied for payments under the Radiation Exposure Compensation Act, according to Brugge and Goble. The law ran out for a time. The members of Congress renewed it as part of the One Big Beautiful Bill Act, which became law on July 4, 2025. According to the Department of Justice in September 2026, workers must file claims by December 31, 2027. A uranium worker who qualifies receives $100,000, paid once.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Lead in the water of Flint" -->
Flint, Michigan, is a majority-Black city. In April 2014, emergency managers appointed by Michigan Governor Rick Snyder switched Flint's water supply. An emergency manager is an official appointed by the state to run a city in place of its elected leaders. Flint had been getting Detroit's water, drawn from Lake Huron. The new supply came from the Flint River.

Governor Snyder later appointed the Flint Water Advisory Task Force to find out what went wrong. Its 2016 report states that Flint's emergency manager Ed Kurtz approved using the Flint River. Darnell Earley, the emergency manager in April 2014, oversaw the switch. A timeline published by the Centers for Disease Control and Prevention (CDC), the federal health agency, states that the river water had no corrosion control. Corrosion control is a treatment that keeps water from eating into pipes.

Detroit's water carried a chemical called orthophosphate, which protects pipes from corrosion. The Flint River water had none, and it was high in chloride, a salt. The river water ate into the city's old pipes. Between 10 and 80 percent of Flint's service lines were made of lead, according to an estimate published in 2016 in the *American Journal of Public Health*. Service lines are the pipes that carry water from the main line under the street into each house. Lead was in the water for about 18 months, reporters for NPR, a national radio network, said in 2023.

Mona Hanna-Attisha was a children's doctor at Hurley Medical Center in Flint. She and her colleagues compared blood tests of 1,473 children in Flint with 2,202 outside the city. Their study was published in 2016. Among Flint children under 5, the share with high lead in their blood rose from 2.4 percent in 2013 to 4.9 percent in 2015. In the parts of the city with the most lead in the water, it rose from 4.0 to 10.6 percent. Children absorb 40 to 50 percent of the lead they swallow in water. Adults absorb 3 to 10 percent. Babies who drank formula mixed with tap water were at the highest risk.

Miguel Del Toral, an EPA expert on lead in water, warned officials of Michigan's Department of Environmental Quality (MDEQ) on February 27, 2015. He wrote that MDEQ's instructions for collecting water samples made the lead readings come out low. He also wrote that a federal rule, the Lead and Copper Rule, required Flint to have corrosion control. The same day, Stephen Busch of MDEQ wrote back that Flint had working corrosion control. The task force found that this was wrong. On April 25, 2015, Del Toral asked Pat Cook of MDEQ how Flint could meet the rules with no corrosion control. Cook, Busch and Mike Prysby of MDEQ then traded e-mails about his question. In July 2015 Brad Wurfel, MDEQ's spokesman, wrote that Flint's residents "do not need to worry about lead in the water supply."

In September 2015, Hanna-Attisha and her colleagues at Hurley Medical Center told pregnant women and children to stop drinking the water. Flint was connected again to a regional water system in 2015. Snyder asked for federal help on January 14, 2016. President Barack Obama declared a federal emergency in Flint on January 16, 2016. EPA officials issued their own emergency order on January 21.

Legionnaires' disease is a lung infection, a kind of pneumonia, caused by bacteria that grow in poorly treated water. From June 2014 to October 2015, Genesee County, where Flint is, had 90 cases. State health officials counted 10 dead in one report and 12 in another. In 2018, NPR reporters linked the outbreak to low chlorine in Flint's water. Chlorine is a chemical that kills germs in drinking water. Reporters for the PBS program *Frontline* found more deaths from pneumonia that the official count missed. The official count is disputed.

In April 2016, Michigan Attorney General Bill Schuette, the state's top lawyer, charged Busch, Prysby and Mike Glasgow of Flint with crimes, according to news reports. In December 2016 he charged Earley and the emergency manager who followed him, Gerald Ambrose, along with others. In June 2017 he charged the state health director, Nick Lyon, with involuntary manslaughter, which means causing a person's death through carelessness, without meaning to kill. He also charged the state's chief medical executive, Eden Wells.

In January 2021, two more lawyers for the people of Michigan brought new charges. They were Solicitor General Fadwa Hammoud, a top lawyer in the Michigan attorney general's office, and Kym Worthy, the lawyer who brings criminal cases for Wayne County. Snyder faced two counts of willful neglect of duty, which means knowingly failing to do his job. Lyon and Wells each faced nine counts of involuntary manslaughter. Earley faced three counts and Ambrose four counts of misconduct in office, which means breaking the law while doing a government job. Howard Croft, Nancy Peeler, Richard Baird and Jarrod Agen were charged too. In 2022 the judges of the Michigan Supreme Court ruled that the one-judge grand jury used to charge them broke the state constitution. A one-judge grand jury is a single judge who decides alone whether to charge someone with a crime. The 2021 cases ended on October 31, 2023, with no one found guilty.

Flint's people sued. On November 10, 2021, U.S. District Judge Judith Levy approved a settlement, an agreement to pay money to end the lawsuits, of $626.25 million for more than 90,000 Flint residents and businesses.
<!-- /hb-zoom -->
<!-- hb-time:end id="2000-today" -->
