<!-- hb-chapter id="17" slug="money" title="Money" part="4" mode="prose" file="part3" -->

# Chapter 17: Money



<!-- hb-time:start id="1900-1950" order="08" chapter="money" label="1900 to 1950" state="full" progress="written" -->
## 1900 to 1950

<!-- hb-zoom level="era" -->
Between 1900 and 1950, members of Congress and two presidents set up two guards for people's savings. One was the Federal Reserve, a bank for the nation's banks. The other was deposit insurance, a government promise to pay savers back if their bank fails. Both are still in place to guard against bank runs, times when many people rush to take their money out of a bank at once. In the Gold Standard Act of March 14, 1900, members of Congress made gold the only metal behind the dollar, at $20.67 an ounce. After that, silver was no longer a standard in law. Members of Congress created the Federal Reserve in 1913, six years after the Panic of 1907, and deposit insurance in 1933, after thousands of banks had failed. In 1933 President Franklin Roosevelt also ordered Americans to turn in their gold coins. From 1934 on, a dollar in an American's hand was paper that could not be traded for gold.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The Panic of 1907" -->
In October 1907 depositors, the people who kept money in banks, rushed to pull their money out of New York's trust companies. A trust company was a kind of bank that took deposits and managed people's money. The country had no central bank, a bank for the country's banks, to stop the run, so a private banker, J.P. Morgan, organized the rescue.

The trouble began with a failed attempt to corner the stock of United Copper. To corner a stock means to buy up so much of it that the buyers can set its price. When the attempt failed, the banks of the men behind it were ruined, and depositors grew afraid of other banks linked to those men.

On October 22, 1907, so many depositors demanded their money from the Knickerbocker Trust Company that its officers stopped paying out money. It was one of the largest trust companies in New York. Depositors then ran on the Trust Company of America and others, standing in lines around the block. Some hired people to hold their place in line. Charles T. Barney, the Knickerbocker's former president, shot himself on November 14, 1907.

A central bank holds the cash other banks keep on hand, called their reserves, and lends to them in a crisis.
<!-- /hb-zoom -->

<!-- hb-story:start slug="jp-morgan-money" name="J.P. Morgan" movie="" kind="famous" status="verified" -->
### J.P. Morgan

> **Who:** A New York banker who ran the rescue in the Panic of 1907 from his own library.
> **When and where:** New York City, October and November 1907.

J.P. Morgan was 70 years old when he took charge of stopping the Panic of 1907. He worked from his private library at 36th Street and Madison Avenue in New York City.

Under Morgan's rescue, teams of examiners went through the books of the trust companies. They decided which ones were sound enough to save. Officials of the Treasury, the government department in charge of its money, deposited $25 million of the government's money with Morgan's group of banks. Morgan also got the presidents of banks and trust companies to promise money to shared rescue funds.

On the night of November 2 to 3, 1907, Morgan gathered the presidents of the trust companies in his library and had the doors locked. In the account told by the Morgan Library & Museum and others, he kept the key in his pocket. He kept the presidents in the room until they agreed to put up $25 million to save the weakest trusts. They signed the deal near 5 in the morning. Memoirs differ on small details, such as who held the key and the exact hour. Today the exhibition on the panic at the Morgan Library & Museum describes the locked-door meeting.

People at the time drew a lesson from the panic: the country's money system had depended on one 70-year-old private banker. In 1908 members of Congress passed the Aldrich-Vreeland Act. In it they created the National Monetary Commission to design a better system.
<!-- hb-story:end slug="jp-morgan-money" -->

<!-- hb-zoom level="span" label="Jekyll Island and the Federal Reserve, 1913" -->
The Federal Reserve, the central bank of the United States, began with a secret meeting in November 1910. Six men traveled to the Jekyll Island Club, on an island off Georgia. To keep the trip secret, they traveled as a duck-hunting party. They were Senator Nelson Aldrich, Treasury official A. Piatt Andrew, the bankers Henry Davison, Frank Vanderlip and Paul Warburg, and Aldrich's secretary, Arthur Shelton. On the island they wrote a plan for a central bank.

The men who were there did not admit to the meeting in public until the 1930s. Today the Federal Reserve's published history describes the trip. Members of Congress never passed their plan, called the Aldrich Plan. Three years later they used much of its design in the law they did pass.

President Wilson signed the Federal Reserve Act on December 23, 1913. The act provided for twelve Reserve Banks in different parts of the country, run under a board in Washington. The Reserve Banks opened on November 16, 1914.

The Federal Reserve is a bank for banks. It holds their reserves, which are the money a bank keeps on hand instead of lending it out, and it moves money between them. Its officers can lend to a sound bank that is facing a run, so the bank can pay its depositors and stay open.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Black-owned banks, and Greenwood's losses" -->
In the early 1900s Black Americans started their own banks, among them Maggie Lena Walker in Richmond and Jesse Binga in Chicago. Black depositors and business owners later lost money when banks failed and when a white mob burned Tulsa's Black district in 1921.

Maggie Lena Walker opened the St. Luke Penny Savings Bank in Richmond, Virginia, in November 1903, and became its first president. She was the first Black woman to found a bank in the United States. On the first day, people deposited more than $8,000, in amounts from 31 cents to over $100. During the Great Depression of the 1930s, Walker merged it with other Black-owned banks into the Consolidated Bank and Trust Company. That bank lasted into the 2000s as the longest continuously run Black-owned bank in the country. Walker lived from 1864 to 1934.

Jesse Binga opened a private bank in Chicago in 1908, mainly for Black customers, because many bank managers turned them away. In 1921 he opened the Binga State Bank. Binga lived at 5922 South Park Avenue, in a white neighborhood. His home and his offices were bombed at least five times. The records do not say who set the bombs.

In 1930 Illinois state officials closed the Binga State Bank when it could not meet a requirement to hold $400,000 in cash. Accounts date the closing to June or to July 31, 1930. Binga lost his own fortune. Many depositors lost their savings, and the records do not count them. In 1933 a jury found Binga guilty of embezzlement, which means taking money a person was trusted to look after. A judge sentenced him to ten years in prison. Governor Dwight H. Green of Illinois pardoned him in 1941. A pardon is an official act that forgives a crime and ends the punishment.

On May 31 and June 1, 1921, a white mob attacked Greenwood, the Black district of Tulsa, Oklahoma, where about 10,000 people lived. The mob included men whom the Tulsa police had deputized, which means sworn in as temporary officers. National Guard units took part in the attack. The attackers destroyed more than 1,000 homes and businesses. Estimates of the number of people killed run from 50 to 300. The count is uncertain because many of the dead were never identified and lie in unmarked graves. Most Black Tulsans lost their homes, and thousands lived in tents through the winter of 1921 to 1922. No white person went to prison for the murders or the burning. An all-white grand jury blamed Black Tulsans. A grand jury is a group of citizens who decide whether to charge people with crimes.

Greenwood's residents filed more than $1.8 million in damage claims with the city of Tulsa between June 1921 and June 1922. All but one of the claims were turned down. A 2021 Brookings study of the claims does not name the officials who turned them down. The one claim paid went to a white shop owner, for guns taken from his store. Officers of the insurance companies refused to pay for the burned property. They called the attack a "riot," and their policies did not cover riot damage. No rebuilding money came from the city, the state or the federal government.

Greenwood's residents rebuilt the district. In 1925 the National Negro Business League held its national meeting in Greenwood. "Negro" was a common word for Black people at the time. By the 1940s Greenwood had 242 Black-owned businesses.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="1930 to 1933: the runs, the holiday and deposit insurance" -->
From 1930 to 1933 more than 9,000 American banks failed, and their depositors lost about $1.34 billion. Federal deposit insurance did not begin until 1934, so the losses fell on the depositors.

Banks had failed at a rate of more than 600 a year even in the 1920s, mostly small banks in farm country. The count grew after 1929. The Federal Deposit Insurance Corporation, or FDIC, is the government agency that insures bank deposits. Its later records list 1,350 banks that suspended, meaning they closed their doors or stopped paying depositors, in 1930. They list 2,293 in 1931, 1,453 in 1932 and 4,000 in 1933. That makes 9,096 in all. A fact sheet from the Franklin D. Roosevelt Presidential Library gives the number as about 9,000 of the country's 25,000 banks. By an estimate on the history website ushistory.org, about nine million savings accounts had been lost by March 1933.

On December 11, 1930, the Bank of United States in New York City failed. It was the largest bank failure in the country up to then. It had about 400,000 depositors. Many were immigrants who worked in the clothing factories, and small savers in the Bronx and Brooklyn.

A history published by the FDIC in 1998 states that Federal Reserve officials "did little to ease the liquidity problems of banks." Liquidity means having cash on hand to pay depositors. Most of the banks that failed in 1930 had not joined the Federal Reserve system, and its officials felt no responsibility for them.

On February 14, 1933, the governor of Michigan closed every bank in the state for eight days. That left 900,000 depositors unable to reach their money. Runs then spread from state to state.

Franklin Roosevelt became president in March 1933. On March 6, two days after he took office, he closed every bank in the country. This was called the bank holiday. On March 9 members of Congress passed the Emergency Banking Act. On the night of Sunday, March 12, Roosevelt gave the first of his radio talks called fireside chats. About 60 million people listened. He explained in simple terms how banks work, and he said money was safer in a reopened bank than under the mattress. Banks reopened from March 13 to 15, after federal officials reviewed them. When they opened, people put in more money than they took out.

On April 5, 1933, Roosevelt signed Executive Order 6102, a written order from the president. It required Americans to turn in their gold coins, gold bars and gold certificates to the government at $20.67 an ounce. A gold certificate was a paper note that could be traded for gold. Americans could keep small keepsakes and collections. In the Gold Reserve Act of January 30, 1934, members of Congress moved all the gold the country used as money to the Treasury. They set a new price of $35 an ounce. From then on, Americans could not trade their dollars for gold. Foreign governments still could.

Between those two gold measures, on June 16, 1933, members of Congress created the Federal Deposit Insurance Corporation, the FDIC, in the Banking Act. Its insurance began on January 1, 1934, and covered each depositor up to $2,500. In July 1934 the limit rose to $5,000. If an insured bank failed, its depositors would be paid back from the insurance fund, up to the limit. With that promise, depositors no longer had a reason to rush to the bank to get their money out first.
<!-- /hb-zoom -->

<!-- hb-story:start slug="lydia-lobsiger" name="Lydia Lobsiger" movie="" kind="ordinary" status="verified" -->
### Lydia Lobsiger

> **Who:** The first depositor in the United States to be paid back by federal deposit insurance.
> **When and where:** East Peoria, Illinois, 1934. Her grave record gives her life as 1870 to 1956.

Lydia Lobsiger received the first federal deposit insurance check ever paid. It was for $1,250 and dated July 3, 1934.

Her bank was the Fond du Lac State Bank of East Peoria, Illinois. It failed in the spring of 1934. It was the first bank with FDIC insurance to fail. The insurance had begun only a few months earlier, on January 1, 1934.

From 1930 to 1933, before the insurance began, depositors in failed banks had lost about $1.34 billion. When Lobsiger's bank failed, reporters at newspapers across the country wrote that a depositor with a small account had not lost her savings.
<!-- hb-story:end slug="lydia-lobsiger" -->

<!-- hb-zoom level="span" label="War bonds" -->
During World War II, about 85 million Americans, roughly half the country, lent money to the government by buying war bonds. Together they paid in about $185.7 billion.

One kind was the Series E bond. A buyer paid $18.75 for it and got back $25 ten years later. Children bought war stamps for 10 cents or 25 cents each and saved them toward a bond.

From 1942 to 1945, officials of the Treasury and the Office of Education ran a program called Schools at War. Students bought stamps and bonds toward goals set at their schools. About 200,000 schools and 30 million students took part. They raised more than $2 billion. Their money paid the price of at least 90,000 jeeps and several thousand airplanes for the armed forces. Eleanor Roosevelt spoke in support of the program on the radio on September 25, 1942.
<!-- /hb-zoom -->
<!-- hb-time:end id="1900-1950" -->

<!-- hb-time:start id="1950-2000" order="09" chapter="money" label="1950 to 2000" state="full" progress="written" -->
## 1950 to 2000

<!-- hb-zoom level="era" -->
The dollar lost its last link to gold in 1971. In the same years Americans began to pay with plastic cards and take cash from machines. On August 15, 1971, President Nixon ended the right of foreign governments to trade dollars for gold. Since then no metal has stood behind the dollar. Prices rose fast for about seventeen years, from about 1965 to 1982, and a dollar saved in 1965 bought about a third as much in 1982. Paul Volcker, head of the Federal Reserve, stopped that rise in the early 1980s by letting interest rates rise past 20 percent.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Plastic: the charge card and the credit card" -->
The first card that people could use to pay at many different businesses was the Diners Club card, in 1950. Frank McNamara started the company with Ralph Schneider and other partners. The first cards were made of cardboard. At first a couple dozen restaurants in New York took them. The first use was at Major's Cabin Grill in February 1950.

The Diners Club card was a charge card. The holder had to pay the whole bill each month. A story often told says that McNamara had the idea in 1949 after he forgot his wallet at dinner. Matty Simmons, the company's first publicity man, was there. He said later that the story was made up for publicity. According to Simmons, McNamara simply had the idea and worked on it.

In September 1958, officers of Bank of America mailed about 60,000 ready-to-use cards, called BankAmericards, to people in Fresno, California. None of those people had asked for a card. The BankAmericard was a true credit card. The holder could pay part of the bill and owe the rest later. About 22 percent of the accounts fell behind on payments, against the 4 percent the bank's officers had planned for. There was also fraud, which means cheating to get money or goods. The bank lost millions of dollars in the card's first years. In 1970 members of Congress banned mailing credit cards to people who had not asked for them. Officers of Bank of America licensed the card to other banks across the country, and in 1976 it was renamed Visa.

Until 1974, a lender who turned down a woman for credit because she was a woman broke no federal law. A blog post by the Consumer Financial Protection Bureau, a federal agency, states that "discrimination against women applying for credit was common." Lenders who made mortgages, or home loans, "often discounted a married woman's income, especially if she was of childbearing age." That means they counted her pay as worth less when they decided whether to lend to her. Lenders were more likely to turn down single women. In October 1974 members of Congress passed the Equal Credit Opportunity Act. Under the act, it became illegal for lenders to treat people differently because of their sex or whether they were married. In March 1976 members of Congress added race, color, religion, national origin, age, and receiving public assistance. Public assistance is money from a government aid program.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The ATM" -->
The first automated teller machine in the United States, a machine that pays out cash without a bank clerk, opened on September 2, 1969. It stood at a Chemical Bank branch in Rockville Centre, New York. Docutel, a company in Dallas, built the machine, called the Docuteller, from an idea by Don Wetzel. The bank's advertisement said, "On September 2, our banks will open at 9:00 and never close again."
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="August 15, 1971: the last tie to gold" -->
After 1934, Americans could not trade dollars for gold, but foreign governments still could, at $35 an ounce. This deal was part of an agreement among countries made after World War II, called the Bretton Woods system. By 1971 far more dollars were held outside the country than the United States had gold to pay for them. Foreign governments were trading in dollars for American gold, and the country's gold was running down. It was a run on the nation's gold.

President Nixon spent a weekend at Camp David with his advisers. They included Arthur Burns, the chairman of the Federal Reserve, John Connally, the Treasury Secretary, and Paul Volcker, a Treasury official. On Sunday night, August 15, 1971, Nixon announced that Treasury officials would no longer trade gold for the dollars foreign governments turned in. He called the change temporary. No president has reversed it.

Since that night the dollar has been fiat money. Fiat money is money backed by no metal. It is worth what it can buy. People accept it because it is legal tender, which means the law says it must be accepted to pay a debt, and because they trust the government that prints it. The greenbacks of 1862 worked the same way.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The Great Inflation" -->
From about 1965 to 1982, prices in the United States rose fast year after year. Economists call this the Great Inflation. Inflation means prices going up, so that each dollar buys less.

In the early 1960s prices had risen 1 or 2 percent a year. Food prices rose more than 20 percent over the year to late 1973. Prices overall rose about 11 percent in 1974. That year President Ford started a campaign called "Whip Inflation Now," with buttons that said WIN. Prices went on rising. At the peak, in 1979 and 1980, they rose more than 1 percent a month, and for all of 1980 they rose 13.5 percent.

A dollar saved in 1965 bought about a third as much in 1982, so savings put aside in 1965 had lost about two-thirds of their buying power. Borrowing became costly. In October 1981 the average interest rate on a 30-year home mortgage, a loan to buy a house, was 18.63 percent. That is the highest rate ever recorded in the Freddie Mac survey of home loan rates.
<!-- /hb-zoom -->

<!-- hb-story:start slug="bruce-bent-henry-brown" name="Bruce Bent and Henry Brown" movie="" kind="ordinary" status="verified" -->
### Bruce Bent and Henry Brown

> **Who:** Two men who met at a pension company and set up the first money market fund, a way for small savers to earn more than the legal limit on bank interest.
> **When and where:** The United States, 1969 to 1973. Bent was born in 1937. Brown lived from 1926 to 2008.

Bruce Bent and Henry Brown set up a fund that let ordinary savers earn the higher interest that only large investors could get before.

Since 1933 a federal rule called Regulation Q had forbidden banks to pay more than a set rate of interest on a savings account. Federal Reserve officials first put it in place in September 1933. In July 1973 Federal Reserve officials raised the limit on an ordinary bank savings account from 4.5 percent to 5 percent. Most banks paid exactly the limit. In 1974 prices rose about 11 percent. Money in a savings account at 5 percent lost about 6 percent of its buying power that year.

Large investors could earn more by buying short-term debt from the government and from large companies, such as Treasury bills, which are short loans to the government. Only large investors could buy that debt directly. Bent and Brown met while working at TIAA-CREF, a pension company. In August 1969 Bent proposed a fund that would pool the money of many small savers and buy that debt for them.

They set up the Reserve Fund in 1970. A saver needed $1,000 to start, and each share cost $100. The fund opened to savers in 1971 or 1972, depending on the source. Bent and Brown had no sales staff. They phoned financial advisers and handed out brochures. On January 7, 1973, the reporter Robert D. Hershey Jr. wrote an article about the fund in the *New York Times*. By the end of 1973 it held $100 million.

Federal Reserve History counts 1 money market fund in 1972, 36 in 1975, 90 in 1980 and 649 in 1990. The limits of Regulation Q were phased out by 1986 under a law members of Congress passed in 1980. The Reserve Fund later grew into the Reserve Primary Fund, which held about $62 billion in 2008.
<!-- hb-story:end slug="bruce-bent-henry-brown" -->

<!-- hb-story:start slug="paul-volcker" name="Paul Volcker" movie="" kind="famous" status="verified" -->
### Paul Volcker

> **Who:** The chairman of the Federal Reserve who brought down the Great Inflation with interest rates above 20 percent, at the cost of a recession with 10.8 percent unemployment.
> **When and where:** Washington, D.C., 1979 to 1983.

Paul Volcker stopped the Great Inflation by letting interest rates rise past 20 percent. He was six feet seven inches tall and known for smoking cheap cigars. President Jimmy Carter appointed him chairman of the Federal Reserve in August 1979. In 1979 and 1980 prices were rising more than 1 percent a month.

On Saturday night, October 6, 1979, Volcker announced a new policy. He and the other Federal Reserve officials would control how much money was in the economy. They would let interest rates rise as high as that took them. The federal funds rate, the rate banks charge one another for overnight loans, passed 20 percent in 1981.

In the recession of 1981 and 1982, unemployment reached 10.8 percent, the highest since the 1930s. A recession is a time when business shrinks and people lose jobs. Farmers drove tractors to the Federal Reserve's building in protest. Home builders in debt mailed sawed-off pieces of two-by-four lumber to the Federal Reserve.

Inflation fell from 13.5 percent in 1980 to 3.2 percent in 1983. Prices next rose as fast as in late 1981 in the 12 months to June 2022, when they rose 9.1 percent.
<!-- hb-story:end slug="paul-volcker" -->

<!-- hb-zoom level="span" label="The savings and loan crisis" -->
From 1989 to 1995, federal officials closed 747 failed savings and loans. Kenneth Robinson, writing for the Federal Reserve's history website, estimates that taxpayers paid as much as $124 billion of the cost. A savings and loan, also called a thrift, took in people's savings and made long-term home loans at fixed interest rates.

When interest rates climbed in the late 1970s and early 1980s, the thrifts lost money. Under Regulation Q, thrifts could not pay savers the rates they could get elsewhere. The old fixed-rate home loans they held lost value. By 1983 closing the thrifts that could not pay their debts would have cost about $25 billion. Their insurance fund, the Federal Savings and Loan Insurance Corporation, or FSLIC, held only $6 billion. In the Garn-St Germain Act of 1982, members of Congress let thrifts make new kinds of loans beyond home mortgages. Many of those loans carried more risk.

In 1989 members of Congress passed a law. In it they closed the FSLIC and moved thrift deposit insurance to the FDIC. They also created the Resolution Trust Corporation to shut down failed thrifts. By the end of 1995 its officials had closed the 747 savings and loans, which together held more than $407 billion in loans and other property. Savers with insured accounts were paid in full.

Banks failed in the same years. FDIC records count 120 failed insured banks in 1985, 145 in 1986, 203 in 1987 and 280 in 1988. In 1984 federal officials rescued Continental Illinois National Bank, which held $45 billion in loans and other property, instead of letting it fail.
<!-- /hb-zoom -->
<!-- hb-time:end id="1950-2000" -->

<!-- hb-time:start id="2000-today" order="10" chapter="money" label="2000 to Today" state="full" progress="written" -->
## 2000 to Today

<!-- hb-zoom level="era" -->
Most American payments today are made by credit or debit card. In 2024 cards made up 65 percent of payments, according to the Federal Reserve's yearly payment diary, and in 2025 Americans used cash for 14 percent. Runs came back. In 2008 savers ran from money market funds, and in 2023 depositors ran from Silicon Valley Bank and other banks. Both times, federal officials promised to cover money that no insurance protected. Since 2009 people have also used digital coins, such as bitcoin, that no government and no bank puts out.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="2008: the run comes back" -->
In September 2008 savers ran on money market funds, the kind of fund Bruce Bent and Henry Brown had started. In a money market fund, the managers pool many people's money to buy short-term loans to the government and to large companies. Many people treated these funds like bank accounts. A share was meant to stay worth exactly $1. The funds had no deposit insurance.

On September 15, 2008, the large financial firm Lehman Brothers failed. The next day, the Reserve Primary Fund "broke the buck," which means its shares fell below $1, to 97 cents. The fund held $62.5 billion, and $785 million of it was in Lehman's debt. According to a study in the *Journal of Financial Crises*, published by Yale University, investors pulled more than $40 billion out of the fund in two days. On September 17 alone they pulled about $144.5 billion out of money market funds across the country.

On September 19, 2008, Treasury officials announced a guarantee for money market funds. President George W. Bush approved it, and Treasury Secretary Henry Paulson put up to $50 billion of the Treasury's Exchange Stabilization Fund behind it. The guarantee worked like deposit insurance, set up within a week, and the run stopped. Later, officials of the Securities and Exchange Commission charged Bruce Bent and his son with fraud over the Reserve Primary Fund's collapse. On November 12, 2012, a jury cleared them of the fraud charges.

Banks failed too. From 2008 through 2013, 489 insured banks failed, according to a history the FDIC published in 2017. Their failures cost the deposit insurance fund about $73 billion. IndyMac failed on July 11, 2008, with losses of about $12 billion, the most costly failure in the FDIC's history. Washington Mutual failed on September 25, 2008. It held $307 billion in loans and other property, which made it the largest bank failure in the country's history. On October 3, 2008, members of Congress raised the deposit insurance limit from $100,000 to $250,000. In 2010 they made the $250,000 limit permanent.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Money issued by nobody" -->
Bitcoin is a digital coin that no government and no bank puts out. It runs on a public record of who owns which coins, kept by many computers that check one another's work.

On October 31, 2008, a person or group using the name Satoshi Nakamoto published a paper describing Bitcoin. On January 3, 2009, Nakamoto started the system by creating its first block of records. The code of that first block includes a headline from that day's *Times* of London: "Chancellor on brink of second bailout for banks." The Chancellor is the British government's top money official, and a bailout is government money given to businesses in trouble. No one has shown who Nakamoto is.

People hold bitcoin as an investment, hoping its price will rise, and others use it to pay for things. Economists disagree about whether it is money, property owned for its value, or a bet on a price.
<!-- /hb-zoom -->

<!-- hb-story:start slug="laszlo-hanyecz" name="Laszlo Hanyecz" movie="" kind="ordinary" status="verified" -->
### Laszlo Hanyecz

> **Who:** A programmer who made the first recorded purchase with bitcoin: two pizzas for 10,000 coins.
> **When and where:** Florida, May 22, 2010.

On May 22, 2010, Laszlo Hanyecz paid 10,000 bitcoins for two pizzas. It was the first recorded time anyone traded bitcoin for a real thing.

Hanyecz was a programmer in Florida who had worked on Bitcoin's code. He wrote the first version of the Bitcoin program for Apple's Mac computers, and he was the first to use a computer's graphics card to create new bitcoins, which is called mining. In May 2010 he posted an offer on the Bitcoin forum, a website where users wrote to one another. He would give 10,000 bitcoins to anyone who got two large pizzas delivered to him. A forum user named jercos took the deal and ordered the pizzas. The pizzas cost jercos about $25. At the time of the offer, the 10,000 bitcoins were worth about $41, according to the bitcoin.it wiki.

The same wiki estimates that at the high point of May 2025, those 10,000 coins would have been worth about $1.1 billion. In a 2019 interview, reported by the news site CoinDesk, Hanyecz said, "A trade happens because both parties think they're getting a good deal." May 22 is now marked each year as Bitcoin Pizza Day.
<!-- hb-story:end slug="laszlo-hanyecz" -->

<!-- hb-zoom level="span" label="Payday loans" -->
A payday loan is a small loan meant to be paid back from the borrower's next paycheck. Researchers at the Consumer Financial Protection Bureau, a federal agency, released a study of these loans on April 24, 2013. They found that a $350 payday loan with the typical fee of $15 for every $100 borrowed cost an annual percentage rate of 391 percent. An annual percentage rate is the cost of a loan over a full year, written as a share of the amount borrowed.

Storefront payday lenders charged fees of $10 to $20 for every $100 borrowed, the study found. Nearly half of payday borrowers took out more than 10 loans in a year, and 14 percent took out 20 or more. The typical borrower was in debt to a payday lender 199 days of the year.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Inflation returns, 2021 to 2026" -->
Prices rose fast again from 2021 to 2023, and Federal Reserve officials raised interest rates faster than at any time since Volcker. In the 12 months to June 2022, prices rose 9.1 percent, according to the Bureau of Labor Statistics. That was the largest rise since November 1981. Energy prices rose 41.6 percent that year and food prices 10.4 percent. Federal Reserve officials raised their main interest rate from near zero in March 2022 to more than 5 percent in 2023. By the middle of 2023, prices were rising at close to 3 percent a year.

Economists still disagree about the causes, as a report by the Congressional Research Service, which does research for members of Congress, describes. The causes they name include broken supply chains (the network of factories, ships and trucks that moves goods), federal spending on pandemic relief and higher energy prices.

In the 12 months to August 2026, prices rose 3.4 percent, the Bureau of Labor Statistics reported. Energy prices rose 16.3 percent, and food prices 2.7 percent.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="FTX and stablecoins" -->
FTX was a company where people bought, sold and kept cryptocurrency, digital money such as bitcoin. In November 2022 it went bankrupt, which means it could not pay what it owed and went to court to settle its debts. Its founder was Sam Bankman-Fried. According to the *Washington Post*, he had used customers' money to buy luxury real estate, to make investments and to give political donations.

In November 2023 a federal jury found him guilty of wire fraud, conspiracy to commit fraud and conspiracy to commit money laundering. Wire fraud is cheating people using phones, email or the internet. A conspiracy is a plan by two or more people to commit a crime. Money laundering is hiding where money from a crime came from. On March 28, 2024, Judge Lewis Kaplan sentenced him to 25 years in prison and ordered him to give up more than $11 billion.

The people running the bankruptcy paid customers back what their accounts were worth on the day FTX filed for bankruptcy in November 2022. On that day one bitcoin sold for $16,080. By May 2024 it sold for close to $62,675, according to CBS News. Customers who had held bitcoin did not get back that later value. Another payment went out to customers on July 31, 2026. An FTX press release in 2026 states that, after it, customer claims had received 105 percent of their value in all, and small claims 120 percent. Payments above 100 percent were interest added to the claims. FTX's chief executive, John Ray, described the plan in 2024 as "100% of bankruptcy claim amounts plus interest."

On July 18, 2025, President Trump signed the GENIUS Act, a law with rules for stablecoins. A stablecoin is a digital coin that the company behind it promises to trade for a fixed amount, such as one dollar. Under the law, a company that puts out stablecoins must hold at least one dollar of approved reserves, such as cash, insured bank deposits or Treasury bills, for every coin. The law states that stablecoins are not federally insured, according to a 2025 report by the Congressional Research Service. In the 1800s, before national paper money, banks chartered by the states printed their own notes. Each note was only that bank's promise to pay in coin. A stablecoin works the same way: a private promise to pay, backed by what the company holds, with no federal insurance behind it.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="2023: the run on Silicon Valley Bank" -->
In March 2023 federal officials protected every depositor at two failed banks, including money above the insurance limit. On March 9, 2023, depositors took $42 billion out of Silicon Valley Bank in California in a single day. About 88 percent of the bank's deposits were above the $250,000 insurance limit. If the bank failed, the owners of that money stood to lose it. On March 10, officials of California's Department of Financial Protection and Innovation closed the bank. On Sunday, March 12, officials of New York's Department of Financial Services closed Signature Bank. About 90 percent of its deposits were uninsured.

Also on March 12, Treasury Secretary Janet Yellen, after consulting the president, used an emergency power. She protected every depositor at both banks, insured or not. On March 27, 2023, FDIC Chairman Martin Gruenberg told Congress that FDIC officials estimated the cost at about $20 billion for Silicon Valley Bank and $2.5 billion for Signature Bank. They planned to collect that money from other banks through special fees, not from taxpayers. On May 1, 2023, California officials closed First Republic Bank, and JPMorgan Chase took over all its deposits.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Cash fades, and the penny ends" -->
In 2025 cash was the third most used way to pay in the United States, after credit cards and debit cards. Federal Reserve researchers track this with the Diary of Consumer Payment Choice, in which people record the payments they make.

In 2016 cash was the most used way to pay, at about a third of all payments. In 2024 cash was used for 14 percent of payments, credit cards for 35 percent and debit cards for 30 percent. Adults aged 18 to 24 paid by phone 45 percent of the time that year. In 2025 people made about 47 payments a month, according to the diary's report released in May 2026. Cash was 14 percent of them, about 6 a month. It was the sixth year in a row that cash came third. People aged 55 and older paid cash about 10 times a month, against about twice for people aged 18 to 24. In the countryside the count was about 9 a month, and in cities and suburbs about 6. Ninety percent of people said they planned to keep using cash.

In the 2024 budget year, each penny cost the U.S. Mint 3.69 cents to make and ship. The Mint's losses on pennies came to about $85 million that year. On February 9, 2025, President Trump said he had told the Treasury Secretary to stop making new pennies. A PBS and Associated Press report at the time said it was unclear whether he had that power, because members of Congress set the rules for coins. On November 12, 2025, at a ceremony at the Philadelphia Mint, the last pennies made for everyday use were struck. The first federal cents had been made 232 years earlier, in 1793. The expected savings were about $56 million a year. Pennies already made are still legal tender.

On September 14, 2026, members of the House of Representatives passed the Common Cents Act, and senators passed it on September 28, 2026. The bill would end penny production in law. When a customer paid cash and exact change was not available, the total would round up or down to the nearest five cents. Payments by card or check would not round. As of October 2, 2026, the bill was waiting for President Trump's signature.
<!-- /hb-zoom -->
<!-- hb-time:end id="2000-today" -->
