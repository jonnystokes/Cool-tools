<!-- hb-chapter id="19" slug="big-business" title="Big Business and Its Power" part="4" mode="prose" file="part3" -->

# Chapter 19: Big Business and Its Power



<!-- hb-time:start id="1900-1950" order="08" chapter="big-business" label="1900 to 1950" state="full" progress="written" -->
## 1900 to 1950

<!-- hb-zoom level="era" -->
Between 1895 and 1904, owners and bankers joined more than 1,800 manufacturing firms into 157 large corporations. Federal lawyers and judges then began to break some of the biggest apart. The largest, U.S. Steel, issued more than a billion dollars in stock in 1901. Stock is the shares, or parts of ownership, that a company sells to investors. Presidents Theodore Roosevelt and William Howard Taft had their lawyers sue the biggest combinations. In 1911 the justices of the Supreme Court ruled that Standard Oil and the American Tobacco Company had broken the law, and under court orders both were split apart.

Members of Congress passed two more antitrust laws in 1914. Antitrust laws are laws against trusts, which are giant combinations of companies run as one business, and against other deals that block competition. After the stock market crash of 1929, members of Congress passed a law in 1934 that made companies selling stock report their finances to the public. During the Second World War, federal officials gave about two-thirds of the value of their main war contracts to 100 companies.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The great merger movement and U.S. Steel" -->
In a merger, two or more companies join into one. The 157 large combinations formed between 1895 and 1904, and more than 60 of them formed in 1899 alone. Naomi Lamoreaux, in her book *The Great Merger Movement in American Business*, names the causes. Factories cost a great deal to build, and industries grew fast after 1887. A depression is a long time when many businesses fail and many people lose their jobs. After the depression of 1893 began, rival owners cut their prices against each other in price wars. The owners had made agreements, called pools, to hold prices up. The price wars went on anyway.

Lamoreaux writes that "there was nothing natural or inevitable" about these combinations. Inevitable means certain to happen. Most of them used more money and work to make the same goods than the new rivals that soon appeared did, and in her words they "quickly lost their positions of market dominance," which means they lost their lead in their markets. The firms that built barriers against rivals, such as U.S. Steel through its control of iron ore, kept their lead longer.

U.S. Steel was set up as a corporation in New Jersey in February 1901. The banker J. P. Morgan put it together. Morgan bought Carnegie Steel for Andrew Carnegie's asking price of $480 million. Other companies went in with it, among them Federal Steel, National Steel, National Tube and American Bridge. So did the Lake Superior Consolidated Iron Mines, whose ore came from Ojibwe land in Minnesota. Charles M. Schwab was president from 1901 to 1903, and Elbert H. Gary was chairman from 1901 to 1927.

The new company issued stock with a stated value of about $1.4 billion. Accounts give figures from $1.403 billion to $1.466 billion. It was the first company in the world with more than a billion dollars in stock. Government investigators at the federal Bureau of Corporations put the real value of what the company owned at about $682 million, about half the stock issued. Stock issued for more than the property behind it is called watered stock. According to the financial data firm Finaeon, when the shares first traded in 1901, buyers valued them at about $765 million in all. The market value of the stock did not pass $1 billion until 1916.

U.S. Steel made about two-thirds of all the steel in the United States at the start. Kenneth Warren, in his book *Big Steel*, counts 65.7 percent in 1901. Another count gives 67 percent in 1902. EBSCO's reference entry gives a lower figure for the start, 44.8 percent, which no other count matches. That year the company employed 168,000 people. By 1911 its share had fallen to between 40 and 50 percent, depending on who counts.
<!-- /hb-zoom -->

<!-- hb-story:start slug="jp-morgan" name="J.P. Morgan" movie="" kind="famous" status="verified" -->
### J.P. Morgan

> **Who:** The Wall Street banker who put companies together, among them U.S. Steel in 1901 and the Northern Securities Company.
> **When and where:** New York, 1901 to 1904.

J. P. Morgan was a banker on Wall Street, in New York City, who joined rival companies into single giant ones. Around 1900 he led a wave of these mergers.

In December 1900 Charles M. Schwab, then president of Carnegie Steel, gave a speech at the University Club. The speech led Morgan to the steel deal. Carnegie named a price of $480 million for his company, and Morgan accepted it at once. Morgan then formed U.S. Steel in 1901 and sat on its finance committee.

In 1901 Morgan and the railroad owner James J. Hill also formed the Northern Securities Company. It was a holding company, which is a company that owns controlling shares in other companies and does little else. Northern Securities controlled three railroads: the Great Northern, the Northern Pacific, and the Chicago, Burlington and Quincy. In 1902 President Theodore Roosevelt's Justice Department lawyers sued to break it up.
<!-- hb-story:end slug="jp-morgan" -->

<!-- hb-story:start slug="ida-tarbell-big-business" name="Ida Tarbell" movie="" kind="famous" status="verified" -->
### Ida Tarbell

> **Who:** The reporter whose history of Standard Oil, built from court records and sworn testimony, showed how John D. Rockefeller built Standard Oil.
> **When and where:** New York and the Pennsylvania oil region, 1900 to 1904.

Ida Tarbell spent most of five years, by her own count, tracing from public records how John D. Rockefeller built Standard Oil. Her family moved into Titusville in 1870, when she was 13. In 1872 her father, Franklin Tarbell, signed a pledge with other oil producers not to sell oil to Standard Oil. She began the work in 1900.

Tarbell read hundreds of thousands of documents from across the country. She used court records and depositions. A deposition is sworn testimony that is taken outside a courtroom and written down. She also interviewed employees and lawyers. The writer Mark Twain arranged for her to meet Henry H. Rogers, an officer of Standard Oil, and she interviewed him too.

Her *History of the Standard Oil Company* came out in 19 parts in *McClure's* magazine, from November 1902 to October 1904. In 1904 it was published as a book in two volumes.

In one part, Tarbell told the story of a Cleveland widow, Mrs. Backus, who sold her late husband's plant for making oil for machines to Rockefeller in 1878. Tarbell wrote that he paid her next to nothing. Rockefeller's biographer Ron Chernow gives a different account. He says the plant was out of date, that the widow asked for as much as $200,000, and that Rockefeller paid $79,000, which included $10,000 added on top. The two accounts of that sale do not agree. Chernow calls Rockefeller's buyouts of his Cleveland rivals in 1872 "one of the most shameful episodes in his career."

Rockefeller called Tarbell "That poisonous woman." He told his advisers, "Not a word about that misguided woman."
<!-- hb-story:end slug="ida-tarbell-big-business" -->

<!-- hb-story:start slug="theodore-roosevelt-big-business" name="Theodore Roosevelt" movie="TR: The Story of Theodore Roosevelt (American Experience, 1996)" kind="famous" status="verified" -->
### Theodore Roosevelt

> **Who:** The president known as the trust-buster. Lawyers in his Justice Department won the Northern Securities case and brought 44 antitrust suits in seven and a half years.
> **When and where:** Washington, 1901 to 1909.
> **Movie:** *TR: The Story of Theodore Roosevelt*, an American Experience documentary first shown on PBS in October 1996.

Theodore Roosevelt is known as the trust-buster, but the president after him brought more antitrust suits. In 1902 Roosevelt's Justice Department lawyers sued the Northern Securities Company, J. P. Morgan and James J. Hill's railroad holding company, under the Sherman Act. The Sherman Act is the federal law of 1890 against deals that block trade and against attempts to become the only seller of something.

On 14 March 1904 the justices of the Supreme Court ruled 5 to 4 for the government and upheld the order to break the company up. Justice John M. Harlan wrote for the majority. Justice Oliver Wendell Holmes disagreed. He wrote, "Great cases like hard cases make bad law."

Roosevelt's lawyers brought 44 antitrust suits in seven and a half years. William Howard Taft, the next president, had his lawyers bring more in four years. One count gives 75 and another gives 99. In 1911 Taft's lawyers sued U.S. Steel. Roosevelt then accused Taft of being unable to tell the good trusts from the bad ones.
<!-- hb-story:end slug="theodore-roosevelt-big-business" -->

<!-- hb-zoom level="span" label="Standard Oil and American Tobacco are broken up, 1911" -->
In May 1911 the justices of the Supreme Court ruled against Standard Oil and the American Tobacco Company, and both companies were split apart. On 15 May they ruled that Standard Oil of New Jersey had broken the Sherman Act. Chief Justice Edward D. White wrote the court's decision and its reasons. He wrote that the Sherman Act banned only "unreasonable" limits on trade. This test is called the rule of reason. The justices gave the company six months to break itself up. Standard Oil was split into 34 separate companies.

Rockefeller was worth about $300 million in May 1911 and more than $900 million by the end of 1913. According to Chernow, Roosevelt said that Wall Street's prayer was now, "Oh Merciful Providence, give us another dissolution." Providence means God's care, and a dissolution is the breakup of a company. In 1916 newspaper headlines called Rockefeller the world's first billionaire. Companies that grew out of Standard Oil later became Exxon, Mobil and Chevron.

On 29 May 1911 the justices ruled against the American Tobacco Company. They found that James B. Duke, Benjamin N. Duke, George W. Watts, R. J. Reynolds and others had broken the Sherman Act "by seeking to monopolize practically all sectors of the tobacco industry." To monopolize means to become the only seller, with no real rivals. In November 1911 federal judges in New York divided the company's property among a new American Tobacco Company, Liggett and Myers, P. Lorillard, R. J. Reynolds and others. James B. Duke's tie to American Tobacco ended that year.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Two new laws, 1914" -->
In 1914 members of Congress passed two laws that added to the Sherman Act. The second one named business practices the Sherman Act had left vague. President Woodrow Wilson signed the Federal Trade Commission Act on 26 September 1914. Under it, "unfair methods of competition" became illegal, and a new Federal Trade Commission had the power to make companies obey that rule. The commission opened on 16 March 1915.

Wilson signed the Clayton Antitrust Act on 15 October 1914. It banned several practices by name. One was price discrimination, which means charging different buyers different prices for the same goods. Others were deals that tied a buyer to one seller, mergers that cut down competition, and the same people sitting on the boards of competing companies. The Clayton Act also stated "that the labor of a human being is not a commodity or article of commerce." A commodity is a thing that is bought and sold. Under that section, federal lawyers and judges could no longer treat unions as illegal combinations. In 1894 they had used the Sherman Act that way against the railroad workers of the Pullman boycott.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Ludlow, 1914" -->
At Ludlow, Colorado, on 20 April 1914, soldiers of the Colorado National Guard, the state's part-time army, burned the tent camp of striking coal miners. The mine owners were paying the Guard's costs. At least 19 people were killed, 13 of them women and children. Most of the strikers worked for the Colorado Fuel and Iron Company, whose main stockholder, the person who owned the most shares, was John D. Rockefeller Jr.

The miners struck in September 1913. In October men in a company armored car known as the "Death Special" fired on their tent camp at Forbes and killed one person. Governor Elias M. Ammons sent the Colorado National Guard.

On 20 April 1914 fighting broke out at the tent camp at Ludlow. Nobody knows who fired the first shot. Guardsmen set the tents on fire. Thirteen women and children had hidden in a pit dug under a tent, and they suffocated there. Suffocate means to die from lack of air. One guardsman and five miners were also killed. Guardsmen shot the strike leader Louis Tikas three times in the back. President Wilson sent the U.S. Army on 28 April. The strike ended in December 1914, and the union won none of its goals.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Leaded gasoline, 1924 to 1926" -->
In the 1920s, three of the largest companies in the country kept selling a lead fuel additive after workers who made it died. Tetraethyl lead is a liquid made with lead. Researchers at General Motors added it to gasoline to stop engines from knocking. In August 1924 General Motors and Standard Oil of New Jersey formed the Ethyl Gasoline Corporation to sell it. DuPont made it.

Workers died at plants and a laboratory of all three companies. In October 1924, seven men died and 33 went to the hospital after working at Standard Oil's Bayway refinery in Elizabeth, New Jersey. A refinery is a plant that turns crude oil into fuel. Bill Kovarik, who wrote a history of leaded gasoline in 2005, gives those counts. Other accounts count five dead. Kovarik counts ten more dead at a DuPont plant and at least two dead at General Motors' laboratory in Dayton, Ohio. Poisoned workers at Bayway were "black and blue from uncontrolled muscle spasms." Some had to be tied into straitjackets, which are coats that hold a person's arms tight against the body.

On 20 May 1925 the Surgeon General, the head of the federal public health service, called a meeting about the additive. Frank Howard of Standard Oil said the industry could not give up "what has come to the industry like a gift from heaven." The companies kept selling it. Robert Kehoe, a scientist paid by the Ethyl company, then set out a theory of a "safe level" of lead that the companies relied on for decades.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Who controlled the corporations, 1932" -->
In 1932 two writers showed that the 200 largest corporations outside banking held about half of the country's corporate wealth, and that hired managers, not owners, ran them. In their book *The Modern Corporation and Private Property*, Adolf Berle and Gardiner Means counted the 200 largest corporations outside banking. By 1930 those 200 held 49.2 percent of the country's corporate wealth. The scholar Gerald F. Davis later worked out that if that trend had continued, they would have held all of it by 1959.

Berle and Means also found that ownership of these companies was split among many scattered shareholders, the people who owned their shares, so the managers made the decisions.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The Securities and Exchange Commission, 1934" -->
After the stock market crash of 1929, members of Congress passed a law that made companies selling stock report their finances to the public. President Franklin D. Roosevelt signed the Securities Exchange Act on 6 June 1934. Under it, the members of a new Securities and Exchange Commission, or SEC, watched over the stock markets. The yearly and quarterly reports that such companies still file with the SEC began with this law.

Roosevelt made Joseph P. Kennedy the first chairman of the SEC in the summer of 1934. Accounts give June or 1 July. Kennedy had made money in the stock market using the same practices the new law banned. He had given, lent and raised money for Roosevelt's 1932 campaign. Newspaper writers said the choice was "like putting the fox in the hen house." In private, Roosevelt answered, "set a thief to catch a thief." Both sayings meant the same thing: Roosevelt had put a man who had used those practices in charge of stopping them. Kennedy resigned in September 1935.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Spies, guns and company police, 1936 to 1940" -->
From 1936 to 1940, senators on a committee led by Senator Robert M. La Follette Jr. of Wisconsin held hearings on how employers fought unions. Witnesses told the senators that company managers had planted spies inside unions. Company managers had stored up weapons, among them submachine guns, rifles and tear gas. They had also hired their own police forces.

On Memorial Day, 30 May 1937, during a steel strike, several hundred men, women and children marched toward the Republic Steel plant in Chicago to support the strikers. Republic Steel's chairman was Tom M. Girdler. At the plant, 264 Chicago police threw tear gas at the marchers, fired their guns and beat them with clubs. The police killed 10 people and shot 40, and more than 90 people were hurt in all. The senators on the La Follette committee found that the police had used "excessive force."
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Hawaii's Big Five" -->
In Hawaii, five companies known as the Big Five controlled about 94 percent of the islands' sugar crop by 1920. They were C. Brewer and Company, Theo H. Davies and Company, H. Hackfeld and Company, Castle and Cooke, and Alexander and Baldwin. The historian Carol MacLennan gives the 94 percent figure. The same people sat on the boards of several of the firms, and together they controlled shipping, banking and stores in the islands. Four of the firms together owned nearly three-quarters of the Matson shipping line, which carried 80 percent of the cargo between the mainland and Hawaii.

In 1893 members of a group called the Committee of Safety organized the overthrow of the Hawaiian Kingdom. They pressed for the United States to annex the islands, which means to take them over. Some children of Big Five partners were members of that committee. The Big Five's plantations stood on the land of Native Hawaiians, the Kanaka Maoli. From 1893 into the 1950s, the owners of the Big Five dominated Hawaii's economy and government.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="War contracts, 1940 to 1944" -->
During the Second World War, a small number of large companies received most of the government's war business. Robert Higgs, writing for the Independent Institute in 1995, gives the figures for prime contracts from 1940 to 1944. A prime contract is a contract made directly between the government and a company. The 100 companies with the most contract money received about two-thirds of the value of those contracts. The top 10 received about 30 percent. General Motors alone received nearly 8 percent.

Federal officials also paid for new factories and rented them to private companies. As of 30 June 1944, just 26 companies had the use of half the value of all those government-paid factories.
<!-- /hb-zoom -->
<!-- hb-time:end id="1900-1950" -->

<!-- hb-time:start id="1950-2000" order="09" chapter="big-business" label="1950 to 2000" state="full" progress="written" -->
## 1950 to 2000

<!-- hb-zoom level="era" -->
The largest American companies of these years had workers by the hundreds of thousands. General Motors was the largest private employer in the country in 1979. The Bell telephone system had about a million workers in the early 1980s. From the 1970s, business leaders organized to win influence in Washington, and by 1982 more than 2,400 firms had registered lobbyists there. A lobbyist is a person paid to persuade lawmakers.

Some companies kept selling products that studies linked to disease and death. In 1954 tobacco companies paid for advertisements in which they disputed studies linking smoking to lung cancer. In 1994 heads of tobacco companies told a House hearing that they did not believe nicotine is addictive. AT&T's leaders agreed with federal lawyers to split up the Bell System, and the split took effect in 1984. In 1999 federal lawyers won a ruling that Microsoft held a monopoly. In 2001 an appeals court agreed that Microsoft had broken the law to keep it.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="General Motors" -->
In the 1950s General Motors was the country's largest car maker, and in 1953 it sold more to the armed forces than any other company. In 1954 it sold 54 percent of new cars, by the Associated Press's count. The encyclopedia Britannica lists GM at 40 to 45 percent of all car sales through the 1950s and 1960s. In 1955 GM became the first company to earn more than a billion dollars in profit in one year. In the first three quarters of 1955 alone it made $912,887,537 in profit. *TIME* magazine wrote, "Never before in history has one corporation made so much in so short a time." GM's workforce in the United States peaked at 618,365 in 1979. That made it the largest private employer in the country.

In January 1953 President Dwight D. Eisenhower chose GM's president, Charles E. Wilson, as Secretary of Defense. He gave up a salary of $600,000 a year for one of $22,000. Wilson owned 40,000 shares of GM stock, and GM sold more to the armed forces than any other company. As Secretary of Defense he could make decisions that helped or hurt GM, so at his hearing senators pressed him on that conflict. Senator Robert C. Hendrickson asked whether Wilson could make a decision that went strongly against GM's interest. Wilson answered, "Yes, sir, I could. I cannot conceive of one because, for years, I thought what was good for our country was good for General Motors, and vice versa." Vice versa means the other way around. People soon repeated his words as "What is good for General Motors is good for the country."

In 1965 Ralph Nader wrote a book called *Unsafe at Any Speed*. In it, Nader criticized the safety of GM's Corvair car. GM managers hired private detectives to look into Nader's private life. In 1966 GM's president, James M. Roche, apologized to a Senate committee. That same year members of Congress passed the National Traffic and Motor Vehicle Safety Act, the first federal rules for how cars must be built. Nader sued GM for invading his privacy and settled for $425,000. He used the money to start groups that work for consumers. GM stopped making the Corvair in 1969.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Eisenhower's warning, 1961" -->
On 17 January 1961, in his farewell speech, President Dwight D. Eisenhower warned the country about the power of the arms makers and the armed forces together. He said, "in the councils of government, we must guard against the acquisition of unwarranted influence, whether sought or unsought, by the military-industrial complex." The councils of government are the places where leaders make decisions. Acquisition means getting, and unwarranted means without good reason. By the military-industrial complex he meant the ties between the armed forces and the companies that made their weapons. Those were the same kinds of large companies that had received most of the war contracts of 1940 to 1944.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The conglomerate" -->
A conglomerate is one company that owns many businesses that have nothing to do with each other. Harold Geneen ran the company ITT from 1959 to 1977. In those years ITT bought between 250 and 350 companies, depending on the count, in more than 80 countries. They included the Sheraton hotel chain, Avis car rental, the Hartford insurance company and Continental Baking, the maker of Wonder Bread. ITT's yearly sales grew from about $700 million to $17 billion, and it became the eleventh-largest corporation in the country. Geneen believed that good managers could make a success of any business.

In 1966 ITT's leaders tried to buy the ABC television network for $700 million, and federal antitrust officials stopped the deal. In Chile, officials under President Salvador Allende took over ITT's company there. ITT later admitted that it had given the CIA, the American spy agency, $350,000 for "political" purposes in Chile.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Business organizes in Washington" -->
In the 1970s, heads of large companies built up their own political power in Washington. On 23 August 1971 the lawyer Lewis F. Powell Jr. sent a private memo to Eugene B. Sydnor Jr. of the U.S. Chamber of Commerce, a national group of businesses. Its title was "Attack On American Free Enterprise System." Powell wrote that critics of business now came from "the college campus, the pulpit, the media" and from politicians. The pulpit here means preachers in churches. He urged business leaders to keep "constant surveillance," or a close watch, on textbooks and television programs. On 21 October 1971, less than two months later, President Richard Nixon nominated Powell to the Supreme Court. The newspaper columnist Jack Anderson made the memo public in September 1972. That year the Chamber's leaders set up a 40-person working group on the memo. In late 1973 they approved plans for business to act in education, in communications, in politics and in the courts.

On 13 October 1972 three groups of company heads joined to form the Business Roundtable. Its founders included John D. Harper of Alcoa and Roger Blough, the retired head of U.S. Steel. They set out to fight the growing power of unions, especially construction unions.

Company heads opened offices in Washington and hired lobbyists. Corporations with public affairs offices in Washington went from 100 in 1968 to more than 500 in 1978. Firms with registered lobbyists went from 175 in 1971 to 2,445 in 1982. Companies also set up political action committees. A political action committee, or PAC, collects money and gives it to candidates. Officials of the Federal Election Commission counted 89 company PACs at the end of 1974, 294 in May 1976 and 1,206 at the end of 1980.

From 1978 to 1980 members of Congress voted to remove federal rules on three industries. President Jimmy Carter signed each law: for airlines on 24 October 1978, for banks on 31 March 1980 and for trucking on 1 July 1980.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Products that hurt people, and what the companies said" -->
From 1954 to 1994, heads of tobacco companies publicly disputed the evidence that smoking causes disease and that nicotine is addictive. On 4 January 1954 the major American tobacco companies ran an advertisement called "A Frank Statement to Cigarette Smokers" in more than 400 newspapers. It reached about 43 million people. In it, the companies disputed new scientific studies that linked smoking cigarettes to lung cancer. The public relations firm Hill and Knowlton, a company paid to shape what the public thinks of its clients, designed it.

Addison Yeaman, the chief lawyer of the Brown and Williamson tobacco company, wrote a memo on 17 July 1963. In it he said that to protect its earnings, the industry must "either a) disprove the theory of causal relationship or b) discover the carcinogen or carcinogens...and demonstrate our ability to remove or neutralize them." A causal relationship here meant that smoking causes cancer. Disprove means to show that something is false. A carcinogen is a substance that causes cancer, and to neutralize something is to make it harmless.

At a hearing in the House of Representatives on 14 April 1994, Representative Ron Wyden asked seven tobacco company heads whether nicotine is addictive. William Campbell of Philip Morris answered, "I believe nicotine is not addictive, yes." James Johnston of R. J. Reynolds said cigarettes "clearly do not meet the classic definition of addiction." Joseph Taddeo of U.S. Tobacco said, "I don't believe that nicotine or our products are addictive."

Four cigarette makers, Philip Morris, R. J. Reynolds, Brown and Williamson and Lorillard, signed an agreement with the attorneys general of 46 states on 23 November 1998. An attorney general is a state's chief lawyer. The states had sued to get back what they spent treating sick smokers. The companies agreed to pay at least $206 billion over the first 25 years and to limit their advertising.

Asbestos is a mineral that separates into thin, strong fibers. Builders used it to fireproof and insulate buildings. When people breathe asbestos fibers in, the fibers can stay in the lungs for years. They scar the lungs and can cause asbestosis, a lung disease that brings shortness of breath, coughing and lasting lung damage. They can also cause mesothelioma, a cancer of the thin linings of the chest and belly. The illness can take 10 to 40 years or more to show. Johns-Manville was once the largest maker of asbestos products in the country. In 1981 it faced 9,300 lawsuits brought by 12,800 people who sued over illness from asbestos. In August 1982 the company's leaders filed for bankruptcy, a court process for a company that cannot pay its debts. The filing put all the injury lawsuits against the company on hold. By the end of 1988, a fund set up in the bankruptcy to pay injury claims had paid more than 12,600 claims, for almost $500 million in all.

On 3 December 1984 more than 40 tons of a poison gas called methyl isocyanate leaked from a pesticide plant in Bhopal, India, a factory that made poisons to kill insects. Union Carbide India Limited ran the plant. It was part of the American company Union Carbide. Union Carbide's leaders had first planned to close the plant, which was losing money. Instead they cut many jobs, including maintenance engineers, to run it for less, according to a report by France's environment ministry. The same report says that on 2 December 1984 the plant's senior managers ordered the cleaning of pipes that led to a machine meant to clean escaping gas. According to a 2005 medical review by Edward Broughton, a broken valve let about a ton of water used for cleaning pipes into a tank of the gas.

That gas-cleaning machine had been turned off. Broughton's review says that happened three weeks before the leak. The French report dates it to 23 October 1984, about six weeks before. The same report says the plant's cooling unit had been shut down since June 1984 to cut its use of electricity by 18 percent. Neither report names the people who turned off the machine or shut down the cooling unit.

The gas damaged people's eyes, causing redness and sores, and it filled their lungs with fluid. According to Britain's Health and Safety Executive, a government safety agency, the gas killed about 2,000 people in the first hours. Broughton's review gives about 3,800 dead at once, and 15,000 to 20,000 early deaths reported over the next twenty years. At first Union Carbide's leaders tried to keep the company free of legal blame. Later they said the company accepted "moral responsibility," and it paid $470 million to the government of India.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The Bell System is split, 1984" -->
In the early 1980s AT&T's Bell System held about $150 billion in property and employed about a million people. Justice Department lawyers sued AT&T in 1974. In January 1982 AT&T's leaders and the Justice Department's lawyers agreed that AT&T would give up its local telephone companies. Judge Harold H. Greene approved the deal with changes, and the case was closed on 24 August 1982.

On 1 January 1984 the local companies became seven regional companies, called the Baby Bells. AT&T kept its long-distance service, its research center, Bell Labs, and its equipment maker, Western Electric. It kept $34 billion of the $149.5 billion in property it had held the day before, and it had 636,000 fewer workers.
<!-- /hb-zoom -->

<!-- hb-story:start slug="bill-gates" name="Bill Gates" movie="Inside Bill's Brain: Decoding Bill Gates (2019)" kind="famous" status="verified" -->
### Bill Gates

> **Who:** The head of Microsoft when federal and state lawyers sued it for keeping an illegal monopoly on the software that runs personal computers.
> **When and where:** Redmond, Washington, and Washington, D.C., 1998 to 2001.
> **Movie:** *Inside Bill's Brain: Decoding Bill Gates* (2019), a Netflix series directed by Davis Guggenheim.

Bill Gates founded Microsoft and ran it as its chief executive until January 2000, so he was in charge when a federal judge found that it held an illegal monopoly. Microsoft made Windows, the operating system that ran most personal computers. An operating system is the main program that runs a computer and the other programs on it.

On 18 May 1998 lawyers for the Justice Department, the attorneys general of twenty states and the District of Columbia sued Microsoft. The main question in the case was whether Microsoft could bundle its web browser, Internet Explorer, with Windows. A web browser is the program people use to look at websites. To bundle it meant to build it into Windows, which made it harder for rival browsers such as Netscape Navigator to win users.

Gates answered the government lawyers' questions in a deposition that was filmed on videotape. A deposition is sworn testimony taken outside a courtroom. A person who was there called him "evasive and nonresponsive." According to *Businessweek* magazine, the government lawyers used snippets of emails to show that many of his denials were false.

On 5 November 1999 Judge Thomas Penfield Jackson found that Microsoft held a monopoly. On 7 June 2000 he ordered the company split into two, one for Windows and one for its other software. On 28 June 2001 seven judges of the federal appeals court upheld the finding that Microsoft had illegally kept its monopoly. They threw out the breakup order, partly because Jackson had talked about the case to reporters while it was still going on.

On 6 September 2001, Attorney General John Ashcroft announced that the Justice Department would no longer seek a breakup. On 1 November 2001 the government's lawyers settled with Microsoft. Microsoft's leaders agreed to share some of its technical information with other companies. They also accepted a panel of three investigators with full access to its systems.
<!-- hb-story:end slug="bill-gates" -->

<!-- hb-story:start slug="steve-young-vlasic" name="Steve Young" movie="Is Wal-Mart Good for America? (FRONTLINE, 2004)" kind="ordinary" status="verified" -->
### Steve Young

> **Who:** A Vlasic pickle executive who described what it was like to sell to Walmart.
> **When and where:** The late 1990s to January 2001. His account was published in December 2003.
> **Movie:** *Is Wal-Mart Good for America?* (FRONTLINE, PBS, 2004), a documentary about Walmart.

Steve Young watched Walmart's buyers push his company's pickles to a price that left almost no profit. He was vice president of grocery marketing for pickles at Vlasic. The reporter Charles Fishman told his story in *Fast Company* magazine in December 2003.

In the late 1990s a Walmart buyer saw Vlasic's gallon jar of pickles. The buyer began talking about it with Pat Hunn, the head of Vlasic's Walmart sales team. The jar went into every Walmart, about 3,000 stores, at $2.97. At that price Vlasic and Walmart each made a penny or two a jar, if that. Young said each store sold about 80 jars a week, which came to 240,000 gallons of pickles a week.

Walmart was 30 percent of Vlasic's business. Young says shoppers who used to buy Vlasic's pickle spears and chips at supermarkets bought the cheap gallon jar instead. He says Vlasic's profits from pickles fell by 25 percent or more.

Young says Vlasic asked to raise the price. He remembers the Walmart buyers' answer: "If you do that, all the other products of yours we buy, we'll stop buying." He called it "a clear threat." Hunn remembers the buyers saying, "We want the $2.97 gallon of pickles. If you don't do it, we'll see if someone else might." Later, Walmart's buyers let Vlasic shrink the jar to just over half a gallon, at $2.79. Vlasic filed for bankruptcy in January 2001. Everyone involved agrees the gallon jar was not a critical factor in that failure.
<!-- hb-story:end slug="steve-young-vlasic" -->
<!-- hb-time:end id="1950-2000" -->

<!-- hb-time:start id="2000-today" order="10" chapter="big-business" label="2000 to Today" state="full" progress="written" -->
## 2000 to Today

<!-- hb-zoom level="era" -->
In September 2026 three American companies, Nvidia, Apple and Alphabet, were each worth more than $4 trillion, according to the investment website The Motley Fool. In the same years federal lawyers took four of the largest technology companies to court over monopoly power. Walmart employed about 1.6 million people in the United States in 2026, by its own count. That is about 2.6 times General Motors' American workforce at its peak in 1979.

A federal jury convicted Enron's former chief executives of fraud in 2006. Lehman Brothers failed in 2008, and members of Congress set aside $700 billion that year to rescue banks and other companies. The four technology companies taken to court were Google, Meta, Amazon and Apple. By September 2026 judges had ruled twice that Google broke the law and once for Meta, and the Amazon and Apple cases had not come to trial.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="How big, in numbers" -->
A company's market value is the price of one share times the number of shares. It changes every day the stock market is open. On 29 October 2025 Nvidia became the first company worth $5 trillion, according to the business news network CNBC. On 7 September 2026, The Motley Fool listed the three most valuable companies in the world. Nvidia was worth about $5.6 trillion, Apple about $4.7 trillion and Alphabet about $4.1 trillion.

Walmart reported $713.2 billion in revenue, the money it took in, for the year that ended on 31 January 2026. Its 2026 annual report records about 2.1 million workers around the world, about 1.6 million of them in the United States. About 92 percent of its American workers were paid by the hour. At that time it had more than 10,900 stores in 19 countries. Amazon's yearly report to the government for 2025 states that it employed about 1,576,000 people at the end of that year. It also used independent contractors, who are paid for each job and are not employees, and temporary workers. Neither group is counted in that number.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Fraud and harm at the top" -->
Courts found that leaders of several large companies of these years had deceived the public, and Purdue Pharma's leaders admitted it in guilty pleas. Enron was an energy company in Houston, Texas. On 2 December 2001 it filed for bankruptcy. Enron's workers had much of their retirement savings in Enron stock. At the end of 2000, 62 percent of the money in the company's retirement plan was in its own shares, according to the Congressional Research Service, which does research for Congress. The shares fell from more than $80 each in January 2001 to less than 70 cents in January 2002.

A lawsuit claimed that Enron had blocked its workers from moving their retirement money out of Enron stock while the price fell. On 25 May 2006 a federal jury in Houston convicted Enron's former chief executives, Kenneth L. Lay and Jeffrey K. Skilling, of conspiracy and fraud, according to the Justice Department. Conspiracy means planning a crime together with others. Fraud means lying or cheating to get money.

On 17 August 2006 federal Judge Gladys Kessler ruled that the major tobacco companies had broken the federal racketeering law. Racketeering here means running a business through a pattern of fraud. She found that the companies had "defrauded the American people by lying for decades about the health risks of smoking and their marketing to children." She wrote that they had "marketed and sold their lethal products with zeal, with deception, with a single-minded focus on their financial success, and without regard for the human tragedy or social costs that success exacted." Zeal means great eagerness, and exacted means took as its price. She ordered them to publish statements about the harm of smoking and about how addictive nicotine is.

Purdue Pharma made OxyContin, a pain pill. OxyContin is an opioid, a drug from the same family of chemicals as heroin. According to the federal Centers for Disease Control and Prevention, the first wave of opioid overdose deaths, from 1999, came from prescription opioids, after doctors wrote more opioid prescriptions in the 1990s. CDC researchers count about 806,000 Americans who died of opioid overdoses from 1999 to 2023, from all kinds of opioids.

In May 2007 the company pleaded guilty to misleading the public about the risk of becoming addicted to OxyContin, and it agreed to pay $600 million. Its president, Michael Friedman, its top lawyer, Howard R. Udell, and its former chief medical officer, Paul D. Goldenheim, also pleaded guilty. They admitted to misbranding, which means selling a drug with false or misleading claims about it, and together they paid $34.5 million. On 24 November 2020 the company pleaded guilty to three federal felonies, which are serious crimes. When Purdue pleaded guilty in 2020, no member of the Sackler family, which owned Purdue, was charged with a crime.

On 16 June 2025, 55 state and territorial attorneys general joined a $7.4 billion settlement with Purdue and the Sacklers, according to the New York attorney general's office. On 28 April 2026 federal Judge Madeline Cox Arleo sentenced Purdue to pay $5.5 billion, as CNBC and Reuters reported. She said she could not send Purdue's executives or owners to prison, because the Justice Department had charged only the company. More than 40 people spoke at the sentencing. Judge Arleo said, "Your government failed you." On 1 May 2026 New York's attorney general announced that Purdue had shut down. A new company, Knoa Pharma, took over, with no role for the Sacklers.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The 2008 rescue" -->
In 2008 the investment bank Lehman Brothers failed, and members of Congress voted public money to rescue banks and other companies. On 15 September 2008 Lehman Brothers filed the largest bankruptcy in the country's history. It had about $639 billion in property and $619 billion in debts, according to the reference publisher EBSCO. Its chief executive was Richard S. Fuld Jr. Investigators later looked into whether Lehman's executives, Fuld among them, had moved money and raised their own pay just before the bankruptcy. EBSCO's entry states that Fuld "walked away with $480 million" but does not say over what years he received it.

In March 2010 Anton R. Valukas, an investigator named by the bankruptcy court, reported on deals that Lehman called Repo 105. Lehman's managers had used them to make the firm's books look stronger at the end of each quarter, the three-month periods for which companies report their results. In 2011 officials of the Securities and Exchange Commission reported that it would be hard to prove that Lehman had broken the law. No Lehman executive was charged with a crime.

On 3 October 2008 members of Congress passed the Emergency Economic Stabilization Act, which allowed up to $700 billion to rescue banks and other companies. Federal officials paid out $443.5 billion in all, and most of it was paid back. In December 2023 auditors at the Government Accountability Office, which checks federal spending for Congress, put the final cost at $31.1 billion. The Capital Purchase Program, which put money into banks, made a profit of $16.3 billion. The rescue of the insurance company AIG cost $15.2 billion, the loans to car makers cost $12.1 billion and the housing programs cost $31.4 billion. The car loans began with $13.4 billion that President George W. Bush announced in December 2008.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Antitrust returns" -->
In the 2020s, government lawyers brought monopoly cases against four of the largest technology companies. By September 2026 they had won two cases against Google and lost one against Meta, and two more were waiting for trial.

Federal Judge Amit P. Mehta ruled on 5 August 2024 that Google had illegally kept monopolies in general internet search and in search advertising. On 2 September 2025 he refused to make Google sell its Chrome browser or its Android phone software. Then, on 5 December 2025, he ordered Google to share its search index and some user data with rival companies. A search index is the huge list of web pages that a search engine keeps. A committee of five technical experts was to oversee it. Google's lawyers appealed. In late July 2026 Justice Department lawyers filed a brief, a written argument, with the appeals court, according to the news service Courthouse News. They asked the court to keep the ruling. They also asked it to ban Google's large payments to companies such as Apple. Those payments make Google the search engine that the companies' products use unless the user changes it.

In a second case, federal Judge Leonie Brinkema ruled in April 2025 that Google had illegally monopolized the tools that websites use to sell advertising space. On 16 September 2026 the court made public her opinion on what Google must do. She refused to make Google sell its advertising exchange, the online market where websites sell ad space to advertisers. She ordered new rules for how the tools work. The National Law Review reported the opinion in an article by a writer for Chamber of Progress, a group funded by the technology industry.

The Federal Trade Commission's case against Meta was about its purchases of Instagram in 2012 and WhatsApp in 2014. The trial began on 14 April 2025. On 18 November 2025 Judge James Boasberg ruled for Meta. He found that Meta did not hold a monopoly, because TikTok and YouTube competed with it. FTC lawyers appealed on 20 January 2026, and in August 2026 the appeals court had not yet set a date to hear the case.

FTC lawyers and 17 state attorneys general sued Amazon on 26 September 2023 for keeping an illegal monopoly. Judge John H. Chun set the trial for 29 March 2027. He will decide the case himself, without a jury. Apple was sued on 21 March 2024 by Justice Department lawyers and 16 state attorneys general, for monopolizing the market for smartphones. On 30 June 2025 Judge Julien Neals refused Apple's request to throw the case out.
<!-- /hb-zoom -->

<!-- hb-story:start slug="lina-khan" name="Lina Khan" movie="" kind="famous" status="verified" -->
### Lina Khan

> **Who:** A law student whose 2017 article argued that the people who enforce antitrust law were missing Amazon's kind of power, and who later led the Federal Trade Commission.
> **When and where:** New Haven, Connecticut, and Washington, D.C., 2017 to 2025.

Lina Khan argued that the judges and officials who enforce antitrust law had stopped looking at the kind of power Amazon held, and she later ran the agency that sued Amazon. In 2017, while she was a student at Yale Law School, she published an article called "Amazon's Antitrust Paradox" in the *Yale Law Journal*. A paradox is something that seems to contradict itself. She argued that those judges and officials had come to judge competition mainly by whether prices went up. In her view, that test missed the power Amazon built by accepting losses while it spread into selling, delivery, cloud computing and publishing. Cloud computing means renting out computer storage and computing power over the internet. Amazon could use its place in one business to gain in another.

On 15 June 2021 members of the Senate confirmed her to the Federal Trade Commission by a vote of 69 to 28. President Joe Biden chose her as the commission's chair, and she was sworn in the same day. At 32 she was the youngest chair in the agency's history, according to CNBC. Under her, FTC lawyers sued Amazon in 2023 and carried on the case against Meta.

In 2023 Robert D. Atkinson and Michael R. Ward of the Information Technology and Innovation Foundation, a research group funded partly by technology companies, argued in a report that her 2017 analysis misread the economics of online markets. Khan served as chair until 20 January 2025, and she left the commission on 31 January 2025. The FTC lost the Meta case at trial in November 2025.
<!-- hb-story:end slug="lina-khan" -->

<!-- hb-zoom level="span" label="Corporate money in politics" -->
Since 2010, corporations and unions have been able to spend without limit on elections, as long as they do not work directly with a candidate. On 21 January 2010, in *Citizens United v. Federal Election Commission*, the justices of the Supreme Court ruled 5 to 4 that "the Government may not suppress political speech based on the speaker's corporate identity." The case began with a film that a non-profit corporation had made to attack Hillary Clinton. Federal law had barred the group from advertising it close to the election. After the ruling, committees called super PACs could raise and spend unlimited sums. Researchers at the Brennan Center for Justice, a law and policy institute, count about $6.4 billion that super PACs spent on federal elections from 2010 to 2022. In the 2024 election they spent at least $2.7 billion. That year, spending by groups that do not have to name their donors passed $1 billion. Such spending is called dark money.

Companies and other groups also pay lobbyists. In 2025 organizations spent $5.08 billion on lobbying the federal government, according to OpenSecrets, a group that tracks money in politics. It was the first year above $5 billion. That year 15,768 organizations reported lobbying. The U.S. Chamber of Commerce spent the most, $72.1 million.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Working for a company without being employed by it" -->
Some companies now pay people for work without hiring them as employees. Ride and delivery companies call their drivers independent contractors. An independent contractor is a worker who is paid for each job and is not counted as an employee. The federal law on the minimum wage and overtime pay, the Fair Labor Standards Act, covers employees. It does not cover independent contractors, according to the Department of Labor.

How many Americans do this kind of work depends on the question asked. Researchers at the Bureau of Labor Statistics, the federal agency that counts jobs, found 1.6 million people in May 2017 who found work through an app or a website. That was 1.0 percent of all workers. Researchers at the Pew Research Center, a research group, found in 2021 that 16 percent of American adults had ever earned money through an online job app, and 9 percent had done so in the past year.
<!-- /hb-zoom -->
<!-- hb-time:end id="2000-today" -->
