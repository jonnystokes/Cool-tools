<!-- hb-chapter id="05" slug="migration" title="Migration Across America" part="2" mode="prose" file="part1" -->

# Chapter 05: Migration Across America



<!-- hb-time:start id="before-1500" order="01" chapter="migration" label="Before 1500" state="full" progress="written" -->
## Before 1500

<!-- hb-zoom level="era" -->
People were moving across this land for thousands of years before any European saw it. The first people came on foot from Asia during the ice age. Their descendants kept moving after that. Some built towns and later left them, and whole peoples traveled south over a long time. Many families moved with the seasons to hunt, fish and gather food.

Hundreds of Native nations lived here. There were no horses and no wagons. Trails and trade paths crossed the continent, and later newcomers followed many of them.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Cahokia and Chaco Canyon: towns people built and left" -->
Cahokia was the largest town north of Mexico. It stood on the Mississippi River, near where the city of St. Louis is today, on the Illinois side. People lived there from about the year 700 to about 1400. Around 1100, between 10,000 and 20,000 people lived in the city. Some estimates put as many as 50,000 people in the area around it. That made Cahokia about as big as London was at the time.

By about 1350 most of the people of Cahokia had moved away, and by the 1400s the town was nearly empty. Nobody knows for sure why they left. The main explanations are drought, floods, and a shortage of wood and food. A drought is a long time with little or no rain. No single cause has been settled.

Chaco Canyon, in what is now New Mexico, was a center of the Ancestral Puebloan people, the ancestors of today's Pueblo peoples. Around 1140, after a run of bad droughts, people started to leave the canyon. By the end of the 1100s most of them had gone. They moved out and joined the Pueblo communities of the Southwest.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The Navajo and Apache move south" -->
The ancestors of the Navajo and the Apache came from the far north. They lived in what is now western Canada and eastern Alaska. The Navajo call themselves the Diné. Their long move south is called the Athabascan migration.

Over a long time, groups of them moved south. They traveled along the edge of the Rocky Mountains and the Great Plains toward the Southwest. Accounts differ about when they arrived. Many place their arrival between the 1400s and about 1525. Others argue that they came earlier, in the 1200s.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Seasonal rounds and trade paths" -->
Many peoples moved in a pattern called a seasonal round. A seasonal round is a yearly circuit from one camp to the next. Over a year, a family moved between its fishing places, its hunting grounds and the spots where wild plants ripened.

Trade goods also moved across the land. Traders passed turquoise, seashells, copper and obsidian from nation to nation along trade paths. Obsidian is a natural black glass made by volcanoes. Some of these goods ended up hundreds of miles from where they were found.
<!-- /hb-zoom -->
<!-- hb-time:end id="before-1500" -->

<!-- hb-time:start id="1500s" order="02" chapter="migration" label="The 1500s" state="full" progress="written" -->
## The 1500s

<!-- hb-zoom level="era" -->
In the 1500s the whole land from coast to coast was still Native land. Europeans reached its edges, but no crowds of settlers moved across the interior. Two things changed in this century. Spanish colonists brought horses back to North America. Then, in 1598, Juan de Oñate led Spanish colonists north into what is now New Mexico. They came with their families, wagons and herds, and they meant to stay.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The horse comes back" -->
Horses lived in North America during the ice age. They died out here thousands of years ago. Spanish sailors and colonists brought them back.

Christopher Columbus carried horses on his second voyage across the Atlantic, in 1493. Spanish expeditions, groups of men sent out to explore, then brought horses onto the mainland. Francisco Vázquez de Coronado's expedition had them from 1540 to 1542, and Juan de Oñate's colonists brought them to New Mexico in 1598. Horses changed how people lived on the Great Plains in the next century, the 1600s.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Oñate's colony on the Camino Real, 1598" -->
Juan de Oñate and his colonists left Santa Bárbara, a town in northern New Spain, in January 1598. New Spain was the Spanish colony that included Mexico. Earlier Spanish expeditions had followed the Conchos River north. Oñate's column, the long line of people, wagons and animals, cut straight across the Chihuahuan Desert instead.

In late April the column reached the Rio Grande at El Paso del Norte, near where El Paso, Texas, and Ciudad Juárez, Mexico, stand today. On April 30, 1598, Oñate claimed New Mexico for Spain in a ceremony called La Toma, which means "the taking." In July he set up the colony's headquarters at San Juan Pueblo, which its people call Ohkay Owingeh.

The colonists moved onto land that was the homeland of the Pueblo peoples. Families from Chaco Canyon had joined the Pueblo communities after the droughts of the 1100s, about 400 years earlier. The road the colonists traveled was later called El Camino Real de Tierra Adentro, the royal road of the interior. It ran from Mexico City to northern New Mexico. With his march, Oñate made that road more than 600 miles longer. Its stretch inside the United States is a National Historic Trail today.

Before Oñate, two groups of Spanish colonists had come to what is now the United States by sea. In 1559 Tristán de Luna y Arellano brought about 1,500 people in 11 ships to Pensacola Bay, in what is now Florida. They were soldiers, colonists, enslaved people and Aztec allies. A hurricane a month later sank many of the ships, and in 1561 Spanish ships took the survivors back to Mexico. In 1565 Pedro Menéndez de Avilés founded St. Augustine, also in Florida, with about 600 settlers.
<!-- /hb-zoom -->

<!-- hb-story:start slug="juan-de-onate" name="Juan de Oñate" movie="" kind="famous" status="verified" -->
### Juan de Oñate

> **Who:** The Spanish leader of the first known colonists to travel over land, with families, wagons and herds, into what is now the United States.
> **When and where:** From Santa Bárbara in northern New Spain to San Juan Pueblo (Ohkay Owingeh), New Mexico, January to July 1598.

Juan de Oñate led a colony north in 1598, and its people meant to stay. His column had about 400 men, about 130 of them with their families, and 83 wagons and carts. The colonists also drove more than 7,000 head of livestock, which means farm animals. Horses were among them.

The colony included soldiers, Franciscan friars, farmers, workers and servants. A friar is a man who belongs to a Catholic religious order, and the Franciscans were one of those orders. Enslaved people also walked in the column. The surviving records do not say how many.

In December 1598 Oñate's nephew, Juan de Zaldívar, went to Acoma Pueblo with about thirty soldiers to demand food. In the Acoma people's own account, the soldiers also raped an Acoma woman. Rape means forcing a person into sex. The Acoma killed Zaldívar and between eleven and fourteen of his men.

In January 1599 Oñate sent Zaldívar's brother, Vicente de Zaldívar, with about seventy soldiers. Acoma stands on top of a mesa, a steep hill with a flat top. The soldiers climbed it, killed Acoma men, women and children, and burned much of the town.

Nobody counted the Acoma dead at the time. Estimates run from about 300 to about 1,500. About 800 is the number given most often. Pueblo leaders gave that number in a 2023 statement from the All Pueblo Council of Governors. Its members are the 20 Pueblo nations of New Mexico and Texas, and each of those nations is led by a governor.

The soldiers captured about 500 people. In February 1599 Oñate sentenced the men over 25 to have a foot cut off. He also sentenced them to be forced to work as slaves for twenty years. Reporters for AP and NPR, and Pueblo leaders, say it was the right foot. News reports and the Acoma's own account, passed down since 1599, give the number of men whose feet were cut off as 24. Two historians, Marc Simmons and John Kessell, doubt that the feet were ever cut off. Simmons had once written that they were.

Oñate sentenced boys and men from 12 to 25, and girls and women over 12, to twenty years of forced work as slaves as well. He ordered the children under 12 taken from their families and given to the friars. A National Park Service page on the Camino Real states that about 70 Acoma girls were sent down the road to convents in Mexico. A convent is a home for nuns, women who have given their lives to the church. The same page states that probably none of the girls ever came home. Pueblo leaders count 60 children taken to Mexico, and they say none came home.
<!-- hb-story:end slug="juan-de-onate" -->
<!-- hb-time:end id="1500s" -->

<!-- hb-time:start id="1600s" order="03" chapter="migration" label="The 1600s" state="full" progress="written" -->
## The 1600s

<!-- hb-zoom level="era" -->
In the 1600s the biggest change in how people moved came from the horse. Horses spread among the Native nations of the Plains and the Rocky Mountains. People on horseback could travel farther and faster than on foot, and they could follow the buffalo herds.

English, Dutch and other colonists settled along the Atlantic coast in this century. Jamestown was founded in 1607 and Plymouth in 1620. Almost none of them went far inland. The Appalachian Mountains were hard to cross, and many Native nations lived on the far side of them. The few colonists who moved inland went short distances. Thomas Hooker's group walked from Massachusetts to the Connecticut River in about two weeks.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The horse spreads to Native nations" -->
There are two accounts of how horses spread. The timing is still not settled.

The older account starts with the Pueblo Revolt of 1680. In 1675 the Spanish governor, Juan Francisco Treviño, had ordered the arrest of 47 Pueblo medicine men, who were religious leaders, on a charge of sorcery, or witchcraft. Spanish officials sentenced four of them to be hanged. They hanged three, and the fourth killed himself. Treviño's men whipped the others in public and put them in prison. Pueblo people went to Santa Fe and demanded that the prisoners be let go, and the Spanish freed them. One of the freed men was Popé, a religious leader of the Tewa, one of the Pueblo peoples. In 1680 Popé led the Pueblo peoples of what is now New Mexico in a rising against Spanish rule. They killed about 400 Spaniards and drove the rest out of New Mexico for more than a decade. The Spanish left behind large numbers of horses, perhaps more than 1,500. It was the largest number of horses to pass into Native hands at one time.

In that account, the horses then moved north and east through trade. The Ute, Navajo and Apache got them first, and then the Comanche, Kiowa and Shoshone. Over the next few decades horses reached the nations of the northern Plains, among them the Lakota, Crow, Cheyenne, Blackfoot and Nez Perce.

The newer account comes from a study published in 2023 in the journal *Science*. The archaeologist William Taylor led it, working with Lakota, Comanche, Pawnee and other Native partners. An archaeologist studies the past through the things people left behind. The team tested horse bones from Kansas, New Mexico and Wyoming to find their age. Some dated from the 1500s and 1600s.

Marks on the teeth and bones showed that people had put bridles on these horses and fed them corn. So people were keeping and caring for them. The team found that many nations across the Plains and the Rocky Mountains had horses by the early 1600s. That is decades before the Pueblo Revolt. The finding matches what Native people have long said in their nations' own histories, passed down by word of mouth.

Over the next century, horses changed how the Comanche, Lakota, Cheyenne and the other Plains nations hunted and traveled.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The first colonial moves inland" -->
In 1636 two English ministers moved out of the colony of Massachusetts Bay and started new towns in what are now Connecticut and Rhode Island. Thomas Hooker chose to go. He led about 100 members of his church west to the Connecticut River.

The other minister, Roger Williams, did not choose. The leaders of Massachusetts ordered him out of the colony for what he preached. He taught that the government should not force religious beliefs on people. He fled in the winter rather than be sent back to England. Wampanoag people helped him survive. Then, with help from Wampanoag and Narragansett people, he traveled by canoe to a freshwater spring at a place called Moshassuck. He settled there with the permission of the Narragansett and named the place Providence. In 1638 two Narragansett sachems, or leaders, named Miantonomi and Canonicus signed a deed for the settlement. A deed is a signed paper that says who owns a piece of land.
<!-- /hb-zoom -->

<!-- hb-story:start slug="thomas-hooker" name="Thomas Hooker" movie="" kind="famous" status="verified" -->
### Thomas Hooker

> **Who:** A minister who led about 100 members of his church from Massachusetts to the Connecticut River, where they settled Hartford.
> **When and where:** From Newtown (now Cambridge), Massachusetts, to Hartford, Connecticut, May and June 1636.

Thomas Hooker was the pastor of the church at Newtown, a town that is now Cambridge, Massachusetts. A pastor is the minister who leads a church. In May and June of 1636 he led about 100 members of his church west to the Connecticut River. The walk took about two weeks.

They drove 160 cattle with them and lived partly on the cows' milk. They followed Native trails. Later people called the route the Old Connecticut Path. John Winthrop, a leader of Massachusetts Bay, wrote about the departure in his journal on May 31, 1636: "Mr. Hooker, pastor of the church of Newtown, and most of his congregation, went to Connecticut." A congregation is the people who belong to a church. Winthrop also noted that Hooker's wife rode on a horse litter, a stretcher carried by horses.

The place where they settled was Suckiaug, which means "black earth." It was the main village of the River Indians, and their sachem, or leader, was Sequassen. In 1636 Sequassen and his people signed the land over by deed to Samuel Stone and William Goodwin, two men in Hooker's group. The land ran along the river between the towns of Wethersfield and Windsor, and six miles west of the river.

Nobody wrote the deed into the official land records at the time. The settlers and the Native owners argued over its terms for generations. The histories of the deed do not say what Sequassen's people received for the land. Dutch traders had also built a fort there, the House of Hope, before Hooker's group came. The town the settlers built there is Hartford. In 1639 the people of Hartford and the towns near it adopted a plan of government called the Fundamental Orders of Connecticut.
<!-- hb-story:end slug="thomas-hooker" -->
<!-- hb-time:end id="1600s" -->

<!-- hb-time:start id="1700-1750" order="04" chapter="migration" label="1700 to 1750" state="full" progress="written" -->
## 1700 to 1750

<!-- hb-zoom level="era" -->
Settler families began moving inland from the Atlantic coast in the first half of the 1700s. Land near the coast had filled up, and it had grown expensive. Families moved into the valleys and hills behind the older settlements, an area colonists called the backcountry. The main route inland was the Great Wagon Road.

Native nations were moving too. After a war with colonists in North Carolina, the Tuscarora walked north to New York. On the southern Plains, the Comanche moved in on horseback and took control, and many Apache there fled south. The country beyond the Appalachian Mountains was still Native land.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The Great Wagon Road and the backcountry" -->
The Great Wagon Road ran about 730 miles. It started in Philadelphia and went southwest through the Shenandoah Valley of Virginia. Then it ran down through the hill country of the Carolinas, called the Piedmont, toward Augusta, Georgia. Heavy traffic began in the 1720s.

Many of the families on the road were German or Scots-Irish. The Scots-Irish were Protestants, Christians whose churches had split from the Catholic Church. Their families had moved from Scotland to the north of Ireland in the 1600s and then on to America. Both groups had come to Pennsylvania and found land there too costly. The Germans were called the "Pennsylvania Dutch." The word Dutch came from *Deutsch*, the German word for German. Moravians, members of a Protestant Christian church from central Europe, came along the road as well.

The road followed an older Native path. Colonists called it the "Indian Road." When settlers began arriving in the Shenandoah Valley in about 1729, Shawnee people were the main residents near the present-day town of Winchester, Virginia. Iroquois, Delaware and Conoy people also used the valley. The Iroquois were the Haudenosaunee, a league of six nations, also called the Six Nations. The valley's north-south trail was a war path between the Seneca and Delaware nations to the north and the Catawba nation to the south.

In 1744 officials sent by Virginia's governor, William Gooch, met Six Nations leaders at Lancaster, Pennsylvania. A treaty is a written agreement between nations, and the one they signed there is the Treaty of Lancaster. In it, Gooch's officials bought the Six Nations' claim to the valley, meaning their right to the land. Under the treaty, colonists also got the right to use the Indian Road. Accounts of how much the officials paid do not agree. After 1744, even more settlers traveled the road.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The Tuscarora walk north, 1713 to 1722" -->
The Tuscarora nation moved about 500 miles north, from North Carolina toward Pennsylvania and New York, after colonists defeated them in war. The move took from 1713 to 1722, and they traveled in stages.

The war ended at Neoheroka, a Tuscarora fort on Contentnea Creek in what is now Greene County, North Carolina. Colonel James Moore of South Carolina led the attack. He commanded militia from both Carolinas and Native warriors who fought on the colonists' side. Militia were colonists called up to fight as soldiers. The siege began on March 1, 1713. In a siege, an army surrounds a fort or town and attacks it until the people inside give up or are beaten. Moore's men dug under an outer wall and set the fort on fire. It fell on March 23.

History pages from North Carolina's state government list 950 Native people killed or captured at Neoheroka. They list about 1,000 Tuscarora sold into slavery during the whole war. The colonists and allies who won the war sold these captives. Those state pages do not name who bought them. The colonists' side also forced more than 3,000 other Native people from their homes. About 200 colonists and about 1,000 Native people died in the war.

About 1,500 Tuscarora survivors made the walk north. The Oneida nation sponsored them in the Haudenosaunee league, which means the Oneida backed their joining. In 1722 the Tuscarora became its sixth nation.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The Comanche move onto the southern Plains" -->
By the early 1700s the Comanche had moved onto the southern Plains. They became the strongest power there. The land they held became known as Comanchería, which means Comanche country.

Apache groups were already living on the southern Plains. The Handbook of Texas, a history reference, states that by 1700 the Comanche, Wichita and Tejas Indians were "better armed through trade with the French." Those nations took control of the southern Plains, and the Apache began moving southwest. Many Apache, most of all the Lipan and the Mescalero, "fled southward into Central Texas as well as into northern Mexico."
<!-- /hb-zoom -->
<!-- hb-time:end id="1700-1750" -->

<!-- hb-time:start id="1750-1800" order="05" chapter="migration" label="1750 to 1800" state="full" progress="written" -->
## 1750 to 1800

<!-- hb-zoom level="era" -->
In 1755 British officers began forcing French-speaking Acadians out of Nova Scotia, north of the British colonies. They removed about 10,000 to 11,500 people, and about 2,600 to 3,000 of them later made their way to Louisiana.

Large crowds of settlers crossed the Appalachian Mountains for the first time after 1775. From that year, as many as 300,000 of them went through the Cumberland Gap into Kentucky and beyond by about 1810. After the Revolutionary War ended in 1783, more settlers moved into the Ohio Valley. The land they moved onto belonged to Native nations. In 1785 and 1787 the members of Congress passed two laws that set out how western land would be measured, sold and governed.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The Acadians forced from Nova Scotia, 1755" -->
The Acadians were French-speaking Catholic farm families in Nova Scotia and the land around it, in what is now eastern Canada. Between 14,000 and 18,000 Acadians lived there in 1755. Nova Scotia was a British colony. Charles Lawrence was the colony's lieutenant governor, one of the top British officials there. On July 28, 1755, Lawrence and his council of advisers in Halifax decided to remove the Acadians from the colony. Admiral Boscawen, a navy commander, and Chief Justice Belcher, the colony's top judge, sat on the council that day. Some council members had recently come from New England and wanted the Acadians' farmland.

Lawrence had first asked Acadian delegates, men chosen to speak for their villages, to swear loyalty to Britain with no conditions. When they refused, Lawrence and his council had them jailed. Lieutenant Colonel John Winslow commanded New England troops. On September 5, 1755, he ordered every Acadian male aged 10 and older at Grand-Pré to gather in the church there at 3 p.m. He held them there. The order read to them said that their land, houses, cattle and other livestock now belonged to the Crown, meaning the British king. They could keep their money and household goods, and they would be removed from the colony. Winslow wrote that the order was "very disagreeable to my nature," but that his job was "to obey such orders as I receive." Colonel Robert Monckton and Major John Handfield led arrests and removals in other districts.

Charles Morris, a New Englander, drew up the plan. Soldiers would surround the churches on a Sunday morning and capture as many men as they could. Then they would break the earth walls that kept the sea off the Acadians' fields, and burn their houses and crops. In 1755 New England and British soldiers did burn many Acadian houses, barns and churches. Around the Minas Basin, where Grand-Pré stands, they set fire to about 700 houses, barns and other buildings. When the men refused to go, the soldiers threatened their families with bayonets. A bayonet is a blade fixed to the end of a gun. By the fall of 1755, soldiers had put about 1,100 Acadians on ships bound for South Carolina, Georgia and Pennsylvania.

British officers and soldiers kept removing Acadians until 1764. One count gives about 10,000 Acadians forced out between 1755 and 1763. Another gives about 11,500 between 1755 and 1764. British ships carried them to the thirteen colonies, to England and to France. Many Acadians escaped into the forests, and British soldiers hunted them for the next five years. In French the forced removal is called *Le Grand Dérangement*, the great upheaval.

Counts of how many Acadians died differ. One count says close to 5,000 died of disease, shipwreck or violence. Other counts put the dead at as many as half of those forced out. In one group of about 3,100 Acadians removed in 1758, about 1,649 died by drowning or disease.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The road to Louisiana and the Cajuns" -->
Between 1764 and 1785, about 2,600 to 3,000 Acadians made their way to Louisiana. Louisiana was then a Spanish colony. The largest group came in 1785. That year, Spanish officials paid for seven ships that carried 1,596 Acadians from Nantes, in France, to Louisiana. The first of them reached New Orleans on July 29, 1785.

The Acadians settled along the bayous and prairies west of New Orleans. A bayou is a slow-moving stream through low, wet land. Their descendants are the Cajuns. The word Cajun comes from the word Acadian.
<!-- /hb-zoom -->

<!-- hb-story:start slug="joseph-broussard" name="Joseph Broussard (Beausoleil)" movie="" kind="famous" status="verified" -->
### Joseph Broussard (Beausoleil)

> **Who:** An Acadian who fought the British removal of his people, then led one of the first Acadian groups to Louisiana.
> **When and where:** Acadia (Nova Scotia and New Brunswick), 1755 to 1762. New Orleans and the Attakapas district of Louisiana, 1765. Born about 1702, died 1765.

Joseph Broussard led about 200 Acadians to Louisiana in 1765. He was one of the first Acadians to settle there. People called him Beausoleil. He was born in about 1702.

When British officers began forcing the Acadians out in 1755, Broussard organized armed resistance. He and his men raided British troops. British soldiers captured him and held him at Halifax until 1763. That year Britain and France signed the Treaty of Paris, a peace agreement that ended their war.

In late 1764 Broussard and about 600 Acadians hired a ship to carry them to Saint-Domingue, the island colony that is now Haiti. In February 1765 he and about 193 to 200 of them sailed on to Louisiana. They reached New Orleans in late February. On April 8, 1765, colonial officials named him a militia captain, an officer over citizen soldiers. They also made him the commander of the "Acadians of the Attakapas." The Attakapas district was the area around the present-day town of St. Martinville.

A sickness spread through the new settlement that year. Most accounts say it was yellow fever. Broussard died of it in October 1765. Officials at Parks Canada, the Canadian government office that runs historic sites, have named him a National Historic Person. Canadian officials give that title to people who were important in Canada's history.
<!-- hb-story:end slug="joseph-broussard" -->

<!-- hb-zoom level="span" label="The Wilderness Road and the Cumberland Gap" -->
The Cumberland Gap is a low notch through the mountains near the place where Kentucky, Virginia and Tennessee meet. In 1775 Daniel Boone and about 30 axmen cut a road through it called the Wilderness Road. As many as 300,000 settlers traveled that road into Kentucky and beyond between 1775 and about 1810. Kentucky filled with settlers and became a state in 1792.

Boone cut the road for Richard Henderson's Transylvania Company, a business formed to buy up wild land and open it to settlers. From March 14 to 17, 1775, at Sycamore Shoals on the Watauga River, Henderson got a deed from Cherokee leaders. Attakullakulla, Oconostota and Old Tassel were among them. The deed covered about 20 million acres between the Cumberland and Ohio rivers. That was most of Kentucky and part of Tennessee. In return the Cherokee received trade goods. One estimate values the goods at about 10,000 British pounds.

Dragging Canoe, Attakullakulla's son, spoke against selling land that the Cherokee nation held in common, and he rejected the sale. Other nations had claims to the land too. The Shawnee had once lived on part of it. The Tennessee Encyclopedia describes the Cherokee claim as the strongest of these. By buying the land, Henderson broke a British rule of 1763, the Royal Proclamation, which banned private buyers from buying Native land. Officials in Virginia and North Carolina and members of the Continental Congress, the meeting of leaders from the colonies, all refused to accept Henderson's colony as lawful.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Into the Ohio Valley, and a grid laid over the land" -->
The Revolutionary War ended in 1783. Settlers then moved in large numbers into the Ohio Valley and the Northwest Territory. The Northwest Territory was the land north of the Ohio River that later became the states of Ohio, Indiana, Illinois, Michigan and Wisconsin. It was the land of the Shawnee, Miami, Delaware and other nations. In the 1790s those nations and the settlers fought each other.

On May 20, 1785, the members of Congress adopted the Land Ordinance. An ordinance is a law. Under it, surveyors measured the western land into squares called townships, each six miles on a side. Each township was divided into 36 sections of 640 acres. In the law, the members of Congress set aside one section in every township to pay for public schools. Because of that grid, much of the American countryside is laid out in squares today.

On July 13, 1787, the members of Congress passed the Northwest Ordinance. In it they wrote the rules for governing the territory, set out how parts of it could become new states equal to the original thirteen, and banned slavery north of the Ohio River. Five states later came from the territory.
<!-- /hb-zoom -->
<!-- hb-time:end id="1750-1800" -->
