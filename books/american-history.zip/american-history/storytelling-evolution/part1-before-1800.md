<!-- hb-chapter id="34" slug="storytelling-evolution" title="Storytelling Evolution" part="9" mode="prose" file="part1" -->

# Chapter 34: Storytelling Evolution



<!-- hb-time:start id="before-1500" order="01" chapter="storytelling-evolution" label="Before 1500" state="full" progress="written" -->
## Before 1500

<!-- hb-zoom level="era" -->
Before 1500, people in Native nations here acted out stories. A dancer in a mask took on the part of a spirit or an animal. Dancers did this in religious ceremonies and to ask the animals to give themselves to hunters. Among the Pueblo peoples, men carved dolls of these spirits so that girls would learn who each one was.

Some of what is known about these traditions comes from the nations themselves. Haudenosaunee leaders published a policy on their masks in 1995, and an Ojibwe teacher explained his people's storytelling rules in 2024. Older evidence survives in the ground. People built wide open squares called plazas and large round rooms for ceremonies, and they painted masked figures on walls and pots.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Playing someone who is not you" -->
The Pueblo peoples, among them the Hopi, are Native nations of the Southwest. In their religion, katsinam are spirit beings. There are more than 500 of them. Pueblo men wear katsina masks and special clothing in dances. People believe that the spirit shown on the mask is present with or inside the dancer while the dance goes on. Men also carve katsina dolls and give them to girls, so the girls learn who each spirit is.

Homol'ovi is a group of ancestral Hopi settlements near Winslow, in what is now Arizona. Ancestral means belonging to the people who lived there long ago, whose descendants live there now. Archaeologists are scientists who dig up and study what people left behind long ago. A review published by the Archaeological Conservancy states that the katsina religion reached Homol'ovi around 1350.

In what is now Alaska, the Yup'ik people held a winter ceremony in which dancers wore masks and took on the spirits of the animals the masks showed. Ann Fienup-Riordan, quoted in *Archaeology* magazine in 2015, said that the dancers asked the animals to give themselves to hunters in the coming year. After a dance, people usually burned the masks, broke them or left them out on the tundra, the flat treeless land of the far north. People lived at Nunalleq, a village near Quinhagak, from 1300 to the 1650s. Archaeologists dug up masks there that are the oldest complete Yup'ik masks anywhere. The masks were made before 1650, while people lived in the village.

Medicine societies among the Haudenosaunee use masks of wood and of cornhusk. The Haudenosaunee are six nations whose lands stretch across what is now New York State and into Canada. In 1995 the Grand Council of the Haudenosaunee published a policy on these masks. The policy defines a medicine society only as Haudenosaunee who have taken part in the medicine. It states that all the masks are sacred, whatever their size or age, and that only members of a medicine society should make masks. It also states that the masks must not be shown in public, and that photographs and drawings of them should not be used in public displays. The Haudenosaunee have not published a date for when the societies began.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Rules about who tells what, and when" -->
Some nations set rules about which stories may be told, by whom, and at what time of year. An Ojibwe teacher described his people's rules in 2024. A Tlingit heritage group describes the Tlingit rules.

Ojibwe people tell their sacred stories, called aadizookaanag, only in winter. James Vukelich Kaagegaabaw is of Turtle Mountain Ojibwe descent. In 2024 he said that tellers wait until the lakes freeze over and snow covers the ground. By then the amphibians and reptiles, animals such as frogs and snakes, are asleep for the winter, and so are the bears. He said the spirits in the stories are thought to be asleep too, and "you wouldn't want to be thought of as gossiping about them." If someone tells the stories out of season, he said, "a frog or a toad may jump into your bed."

The Tlingit live in Southeast Alaska. They belong to clans, large family groups that trace back to the same ancestors. Each clan owns its crests, the animal and spirit figures that stand for the clan. It also owns the stories, songs and names that go with each crest. The Tlingit word for this sacred clan property is at.óow. The Sealaska Heritage Institute, led by Rosita Worl, published the first list of Tlingit clan crests in 2023. Its writers say that a clan got the right to a crest when an ancestor met a spirit being or what they call an "animal person." They add that a clan "often acquired" the right "as payment for the life of an ancestor," and the article does not say more about that payment. Clan members hold the crest and its stories through the generations.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Places built to hold a crowd" -->
At Cahokia, in what is now Illinois across the Mississippi River from St. Louis, people built a Grand Plaza of about 47 acres. It was the largest of the city's five plazas. The builders cut down a ridge of sand and moved the sand to fill low places and make a level surface. R. Thunen of the University of North Florida writes that archaeologists see the plazas as the places where people from all around gathered for their most important ceremonies, meetings and social events.

At Chaco Canyon, in what is now northwestern New Mexico, the people of Chaco built a great kiva called Casa Rinconada. A kiva is a round room, partly underground, used for ceremonies. Casa Rinconada is about 63 feet across inside, with a bench around the wall and 34 small openings, called niches, set into the wall. A tunnel 39 feet long ran under the floor. Through it, a person, perhaps a leader of the ceremonies, could enter the kiva unseen and then come up suddenly in front of the people there. The Chaco Research Archive states that building probably began in about the middle of the 1000s and that people stopped using the kiva in the early 1100s.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="What the record does not have" -->
No person from before 1500 in this land who acted, danced or told stories is named in any surviving record.
<!-- /hb-zoom -->
<!-- hb-time:end id="before-1500" -->

<!-- hb-time:start id="1500s" order="02" chapter="storytelling-evolution" label="The 1500s" state="thin" progress="written" -->
## The 1500s

<!-- hb-zoom level="era" -->
The first European play on record in what is now the United States was acted on April 30, 1598, on the bank of the Rio Grande. Spanish soldiers and priests acted it, and they made Manso people, who lived near their camp, take part. The Spanish belonged to an expedition, a large group of soldiers, priests and settlers, led by Juan de Oñate. They had come north from Mexico to take New Mexico for the king of Spain. Later that year Oñate's soldiers acted a second play at a pueblo, a Native town, farther north. No other European play acted in this land in the 1500s is on record.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="April 30, 1598: the play at the river" -->
Oñate's expedition reached the Rio Grande near present-day San Elizario, Texas, on April 20, 1598. On April 30 the colonists held a Mass of thanksgiving, a Catholic church service, in a chapel that Oñate had ordered set up in a grove of cottonwood trees. That day Oñate also read out a statement called "La Toma," which means "the taking." In it he claimed for King Philip II of Spain all the land that the river drained. Accounts differ on whether he read it before or after the play. Manso people lived near the camp.

After the Mass the expedition put on a play nearby. Captain Marcos Farfán de los Godos, one of Oñate's officers, wrote it. The stage was bare ground, and a canvas curtain hung between two tree trunks behind it. Soldiers and friars played the main parts. Friars are Catholic priests who belong to a religious order.

Members of the expedition made Manso people found near the camp take part in the play, the historian Marc Simmons writes. Simmons does not say who gave the order. In the play the Manso acted the parts of the Pueblo people who lived farther north. An officer who watched described the story. Friars arrive in New Mexico, and the Native people there kneel and ask to be baptized. Baptism is the Catholic ceremony with water that makes a person a member of the church. At the end, the people watching cheered and fired their guns into the air. No copy of the script survives, and its title is not known.
<!-- /hb-zoom -->

<!-- hb-story:start slug="marcos-farfan-de-los-godos" name="Marcos Farfán de los Godos" movie="" kind="ordinary" status="verified" -->
### Marcos Farfán de los Godos

> **Who:** A captain in Juan de Oñate's expedition who wrote the first European play on record in what is now the United States.
> **When and where:** The Rio Grande near present-day San Elizario, Texas, April 30, 1598.

Marcos Farfán de los Godos wrote the play that Oñate's expedition acted on April 30, 1598. He came from the city of Seville, in Spain. He passed muster with two servants, 16 horses, a tent, weapons and armor. Passing muster means he was checked, and what he brought was written on the expedition's list of men, called a muster roll.

Farfán opened the play himself with a speech, in which he said he was unworthy to have written such a poor play and offered it for the fun of his fellow soldiers and of Oñate.

In November 1598 Farfán led a party west from the Hopi villages to look for mines. They reached the Verde Valley, in what is now Arizona. Near present-day Jerome they marked out 14 or 15 mining claims, pieces of ground where they said they had the right to dig for ore, rock that holds metal. What happened to Farfán after 1599, and when he died, is not known.
<!-- hb-story:end slug="marcos-farfan-de-los-godos" -->

<!-- hb-zoom level="span" label="The same expedition at Acoma" -->
About eight months after the play, men of the same expedition attacked Acoma Pueblo. Acoma is a town built on top of a mesa, a steep hill with a flat top.

In early December 1598, Oñate's nephew Juan de Zaldívar and his soldiers climbed the mesa and demanded food. The All Pueblo Council of Governors is a council of the leaders of the Pueblo nations. In 2023 its leaders said that the soldiers had demanded food and supplies. They said the soldiers had also forced the Acoma to promise loyalty to the king of Spain. In the Acoma people's own account, as the Rio Grande Sun newspaper reported it in 2019, the soldiers also raped an Acoma woman. Rape means forcing a person into sex. Acoma people killed Zaldívar and between 11 and 14 of his men. Accounts differ on the number.

In January 1599 Oñate sent Zaldívar's brother, Vicente de Zaldívar, with about 70 soldiers. Oñate declared a war "by fire and blood." The soldiers fought their way up the mesa. Over two or three days of fighting, they killed Acoma men, women and children and burned much of the pueblo. No one counted the Acoma dead. Published estimates run from about 300 to about 1,500. The figure given most often is about 800 men, women and children, and it is the figure the Pueblos themselves use. The soldiers took about 500 people prisoner.

In February 1599 Oñate put the prisoners on trial and sentenced them. Every Acoma man over 25 was to have one foot cut off and to be forced to work for Spanish masters for twenty years, as their slaves. Males from 12 to 25, and females over 12, got the same twenty years of forced work. Oñate ordered the old people handed over as slaves to the Plains Apache, and children under 12 taken from their families and given to the friars. Under that order, Acoma girls were taken south to Mexico and placed in convents, houses where nuns live. The National Park Service's account gives about 70 girls, and the All Pueblo Council of Governors gives 60 children. The records do not name the men who took them. None is known to have come home. Oñate also sentenced two Hopi men captured in the fighting to have their right hands cut off.

Oñate's sentence is in the written record. Acoma people have passed down their own account since 1599: Oñate had the right feet of 24 captive men cut off. The Associated Press, NPR and the New York Times have reported that number. No one has traced it to a written record from the time. The historians Marc Simmons and John Kessell doubt that the cutting was carried out.

In 1612 or 1613 Spanish officials charged Oñate with 30 crimes. In 1614 judges in Mexico found him guilty of 12 of them, including using too much force at Acoma. The judges ordered him out of New Mexico for life and barred him from Mexico City for four years. One account says five years. They also fined him 6,000 ducats, which were Spanish gold coins.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Los Moros y Cristianos" -->
Oñate's soldiers acted a second play in 1598, after the expedition reached a Tewa pueblo. The Spanish renamed it San Juan and made it their first capital. Today that pueblo is called Ohkay Owingeh. The play was *Los Moros y Cristianos*, which means *The Moors and the Christians*. The Moors were Muslims. The play shows the battles between Muslims and Christians in Spain from the 700s to the 1400s. The leaders of each side make long speeches, and the battle scenes are full of clashing weapons.

New Mexicans have acted the play now and then in recent times, most of all a group of actors from Chimayó. Actors performed it at the University of New Mexico in 1998, for the 400th anniversary of Oñate's colony.
<!-- /hb-zoom -->
<!-- hb-time:end id="1500s" -->

<!-- hb-time:start id="1600s" order="03" chapter="storytelling-evolution" label="The 1600s" state="thin" progress="written" -->
## The 1600s

<!-- hb-zoom level="era" -->
The first play in English on record in what is now the United States is known only from the orders of a Virginia county court in 1665. A man named Edward Martin had reported the actors to the court, and the court tried them. In New Mexico, Spanish priests went into Pueblo ceremonial rooms and burned the masks used in the dances. In 1680 the Pueblos drove the Spanish out and brought back their own ceremonies.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Plays stopped in England, and a play at Harvard" -->
England's lawmakers meet in Parliament, which has two parts, the House of Lords and the House of Commons. On September 2, 1642, members of both houses ordered that "Public Stage Plays shall cease" for as long as "these sad causes and set Times of Humiliation do continue." The order calls those times "Public Calamities" and "Seasons of Humiliation," set aside for "sad and pious Solemnity." It means times of public trouble, kept for sad and serious worship. The order describes plays as "Spectacles of Pleasure, too commonly expressing lascivious Mirth and Levity." Spectacles are shows, and mirth means fun. Lascivious means rude about sex, and levity means joking about serious things.

In 1690 students at Harvard College, in Cambridge, Massachusetts, acted *Gustavus Vasa*, a tragedy by Benjamin Colman. A tragedy is a serious play with a sad ending. Local officials disapproved of the play. Arthur Hornblow, who wrote a history of the American theatre in 1919, called it the first play written by an American to be acted in America.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="August 27, 1665: a play, a complaint and a court" -->
On August 27, 1665, three men named Cornelius Watkinson, Philip Howard and William Darby acted a play called *Ye Bare and Ye Cubb* in Accomack County, Virginia. The court record does not say where. A local history site, Secrets of the Eastern Shore, says they acted it at Fowkes Tavern near Pungoteague. A man named Edward Martin reported the play to the court. John Fawsett, the king's attorney for the county, brought the case. The king's attorney was the lawyer who brought cases to court in the king's name.

On November 16, 1665, Fawsett accused the three men in the county court. The judges of the court ordered the men to come to the next court "in those habilemts that they then acted in." Habilemts is the court clerk's short spelling of habiliments, an old word for clothes, so the men had to come in their costumes. They also had to bring a written copy of the verses and speeches. The judges ordered the sheriff to hold Watkinson and Howard until they gave security, a promise backed by money or property that they would come back. They ordered him to arrest Darby.

At a court in January 1666, the judges found the three men "not guilty of fault." They ordered Edward Martin, who had reported the men, to pay all the costs of the case. The record does not say whether the men acted the play in front of the judges. The court orders are the only record of the play from its own time.
<!-- /hb-zoom -->

<!-- hb-story:start slug="william-darby-1665" name="William Darby" movie="" kind="ordinary" status="verified" -->
### William Darby

> **Who:** One of the three men who acted *Ye Bare and Ye Cubb* in Virginia in 1665, and the one the sheriff was ordered to arrest.
> **When and where:** Accomack County, Virginia, August 27, 1665, and the county court, November 1665 to January 1666.

William Darby is one of the first people on record to act a play in English in what is now the United States. The Accomack County court record calls him an "actour" of *Ye Bare and Ye Cubb*. Later writers say he wrote the play or helped write it. The reference book *American Eras* lists it as "*Ye Bare and Ye Cubb*, by William Darby." Writers at the Oscar G. Brockett Center for Theatre History call him "one of the piece's authors."

In November 1665 the judges ordered the sheriff to arrest Darby "to answere at his ma'ties suit." That meant he had to answer a case brought in the name of His Majesty, the king. For the other two actors, the judges ordered only that they be held until they gave security that they would come back. In January 1666 the judges found all three men not guilty.

The court record is the only account of Darby from his own time. It does not say what work he did, when he was born or when he died.
<!-- hb-story:end slug="william-darby-1665" -->

<!-- hb-zoom level="span" label="Pueblo ceremonies attacked, and brought back" -->
In New Mexico, Spanish officials and priests tried to end the Pueblo ceremonies that the masked dancers performed. Franciscan friars had set up Catholic churches in several Pueblo towns. The Franciscans are one group of Catholic friars. From 1656 to 1665, the Franciscan leader Alonso de Posada forbade the Pueblo people to hold their ceremonies. He ordered the missionaries, priests sent to win people over to Christianity, to go into the kivas, burn the masks there, and take or destroy the sacred objects. Armed Spanish soldiers protected the missionaries while they did it.

In 1675 Governor Juan Francisco Treviño ordered the arrest of 47 Pueblo religious leaders for sorcery. Sorcery means using magic to do harm. Spanish officials sentenced four of the men to death by hanging. They hanged three of them, and the fourth killed himself. They shamed the others, whipped them in public and put them in prison. Pueblo men then came to Santa Fe and demanded that the prisoners be freed, and the Spanish let them go. One of the men freed was Po'pay of Ohkay Owingeh.

Po'pay planned a revolt of all the Pueblo towns at once. He sent runners carrying knotted ropes to the towns, and the people in each town untied one knot a day. When the last knot was gone, the revolt would begin. On August 9, 1680, the Spanish caught two of the runners, Pedro Omtua and Nicolas Catua of Tesuque Pueblo, and tortured them. Dennis Zotigh's account for the Smithsonian does not say how. When Po'pay learned the two had been caught, he started the revolt a day early, on August 10. Pueblo fighters killed about 400 people, including 21 of the 33 Spanish priests in New Mexico. About 2,000 settlers who survived fled south to El Paso. After the Spanish left, the Pueblo people destroyed the churches and went back to their own religious ceremonies. The Spanish stayed away for 12 years.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="What the record does not show" -->
In the 1600s English colonists enslaved Africans. They owned them as property and forced them to work without pay. Writers for the American Battlefield Trust state that religion, storytelling, music and dancing were important parts of enslaved people's lives, and helped them keep African ways alive from parents to children. No record from the 1600s describes a performance by an enslaved person in the English colonies. The earliest known picture of a stick dance, a dance of enslaved people, is a watercolor called *The Old Plantation*, painted in the late 1700s.
<!-- /hb-zoom -->
<!-- hb-time:end id="1600s" -->

<!-- hb-time:start id="1700-1750" order="04" chapter="storytelling-evolution" label="1700 to 1750" state="thin" progress="written" -->
## 1700 to 1750

<!-- hb-zoom level="era" -->
Two of the first actors in the first playhouse in the English colonies were servants, bound by contract to the man who built it. That playhouse went up in Williamsburg, Virginia, between 1716 and 1718. Builders in Charleston, South Carolina, put up a theatre made for plays in 1735 and 1736. A British actor, Anthony Aston, worked in the colonies in the early 1700s. In Boston, a judge of the colony's high court wrote against acting a play. The preacher George Whitefield, who had prepared to act plays as a schoolboy, preached in the colonies. According to newspaper reports that Benjamin Franklin read, Whitefield once preached to 25,000 people in the fields.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The first actors and the first playhouses" -->
The British actor Anthony Aston reached Charleston, South Carolina, in about 1702 and wrote a play about the colony there. Accounts give his arrival as 1701, 1702 or 1703. No copy of his play survives.

In 1716 a merchant named William Levingston signed a contract with Charles Stagg and his wife, Mary Stagg. The Staggs were his indentured servants. An indentured servant was a person bound by a contract to work for a master for a set number of years. Under the contract, Levingston agreed to build a playhouse in Williamsburg, and the Staggs agreed to act and dance in it. The first play on record there was acted in 1718. Lieutenant Governor Alexander Spotswood, the colony's leader at the time, sponsored it. No list of the plays acted in Levingston's playhouse survives.

Williamsburg stands on land that the Paspahegh and Chiskiack peoples used before the English came. Both belonged to Tsenacomoco, a group of nations that spoke related Algonquian languages and that Powhatan led until 1618.

In Charleston, a company of actors put on Thomas Otway's tragedy *The Orphan* on January 24, 1735. They acted it in the "Court-room" of Charles Shepheard's tavern on Broad Street, a room that colony officials rented for trials. The company gave six shows through March. A ticket cost forty shillings in South Carolina money. A shilling was a unit of money, and South Carolina money was worth less than English money, so the ticket was worth a little less than six English shillings.

Most of the actors' names are not recorded. A dancer named Henry Holt probably led them. Builders then put up a theatre on Dock Street, made for plays. It opened on February 12, 1736, with George Farquhar's comedy *The Recruiting Officer*.

The Etiwan people lived on the Charleston peninsula until 1672. That year the colony's Grand Council, the group of men who governed it, decided to build the town there. Colonists paid the Etiwan in trade goods to move away. Maurice Mathews, one of the colonists who probably arranged it, wrote in 1680 that the settlers paid the Etiwan "to remove them from their old habitations," meaning their old homes.

In Philadelphia, a company led by Walter Murray and Thomas Kean gave its first show on August 22, 1749, and acted Joseph Addison's tragedy *Cato* that month.
<!-- /hb-zoom -->

<!-- hb-story:start slug="anthony-aston" name="Anthony Aston" movie="" kind="ordinary" status="verified" -->
### Anthony Aston

> **Who:** A British lawyer who became an actor and wrote a play about South Carolina while he was there.
> **When and where:** Charleston, the Albemarle region of North Carolina, New York and Virginia, about 1701 to 1703.

Anthony Aston told his own story in the preface to his play *The Fool's Opera*, printed in 1730 or 1731. A preface is a short piece at the front of a book in which the writer speaks to the reader. Aston listed himself as "a gentleman, lawyer, poet, actor, soldier, sailer, exciseman, publican." An exciseman collected taxes on goods, and a publican ran a tavern.

He wrote that he reached Charleston "full of lice, shame, poverty, nakedness and hunger." There he "turned player and poet and wrote one play on the subject of the country." A player was an actor. That play does not survive.

He then spent about a month in the Albemarle region of North Carolina, where two settlers, Allen and Abraham Waights, supported him. On the way to New York, a storm blew his ship off course to the coast of Virginia. In New York he spent a winter "acting, writing, courting, fighting." Then he sailed to Virginia, and later he went back to England.
<!-- hb-story:end slug="anthony-aston" -->

<!-- hb-story:start slug="william-levingston" name="William Levingston" movie="" kind="ordinary" status="verified" -->
### William Levingston

> **Who:** A merchant and dancing teacher who built the first playhouse in the English colonies, with two indentured servants as his actors.
> **When and where:** New Kent County and Williamsburg, Virginia, 1716 to 1723.

William Levingston built the first theatre in the English colonies, in Williamsburg, Virginia. Before that, he ran a dancing school that traveled around New Kent County. Charles and Mary Stagg were its star dancers, and they were his indentured servants.

Their contract, dated July 11, 1716, and recorded at Yorktown, set out how the theatre would work. Charles Stagg was an actor, a violin player and a dancer. Mary Stagg was an actor. The three agreed to share the costs of costumes, music and everything else needed to put on plays.

On November 21, 1716, Levingston bought land in Williamsburg. On it he built a house, a kitchen, a stable, a bowling alley and the theatre. He borrowed money from Dr. Archibald Blair with the property as security. In 1723 Blair foreclosed, which means he took the property because the debt was not paid.

Charles Stagg died in Williamsburg in 1735 or early 1736. After his death, Mary Stagg earned her living by holding dancing parties. College of William and Mary students acted plays in the theatre in 1735 and 1736. In 1745 a group of Virginia men bought the building and gave it to Williamsburg to use as a town hall.
<!-- hb-story:end slug="william-levingston" -->

<!-- hb-zoom level="span" label="Boston against plays" -->
On March 2, 1714, Samuel Sewall, a judge of the Massachusetts high court who later became its chief justice, wrote a letter against a plan to act a play in the Council Chamber in Boston. The Council Chamber was the room where the colony's council met. Sewall wrote that even the Romans had not been so set on plays as to "turn their Senate House into a Play-House." He went on: "Let not Christian Boston goe beyond Heathen Rome in the practice of Shamefull vanities." No record shows that the play was ever acted.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Preaching as performance" -->
George Whitefield was an English preacher who first came to the colonies in 1738. He made a preaching tour of the colonies from 1739 to 1741. According to newspaper reports that Benjamin Franklin read, Whitefield once preached outdoors to 25,000 people. As a schoolboy of about twelve in Gloucester, England, he wrote later, he "was very fond of reading plays." He stayed away from school "for days together to prepare myself for acting them."

Franklin heard Whitefield preach from the courthouse steps on Market Street in Philadelphia. Franklin wanted to know how far the preacher's voice carried. He walked backward down the street until he could no longer hear clearly. Then he worked out how many people could stand in a half circle that size, giving each person two square feet. He "computed that he might well be heard by more than thirty thousand."

Franklin also noticed that Whitefield spoke each sermon better every time he repeated it on tour. By then "every accent, every emphasis, every modulation of voice, was so perfectly well turn'd and well plac'd." Modulation means raising and lowering the voice. Franklin wrote that a preacher who traveled could improve a sermon "by so many rehearsals." A rehearsal is a practice run of a performance.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Pinkster and Black election days" -->
In New York, enslaved Black people gathered for a holiday called Pinkster, with music and dancing. In Connecticut, Black communities chose their own governor.

Dutch settlers brought Pinkster to New Netherland, later New York, in the 1620s. The oldest written account of Pinkster appeared in the *New-York Weekly Journal* in March 1737. It describes a gathering in fields outside New York City, with African-style musical instruments. Enslavers gave the people they held time off for the holiday. For many enslaved Africans it was a chance to see loved ones and family members who lived some distance away. Africans and Europeans alike drank, played games, made music and danced at these gatherings, with dances called the jig, the breakdown and the double shuffle.

In Connecticut, Black communities held their own elections for a governor, possibly as early as 1749. A man named Hercules served as governor at New London in 1749. The voting took place the day after the white colonists' elections, and the celebration went on for a full week. Some of the clothes people wore were borrowed from the men and women who enslaved them. By custom, the enslaver of the man elected was expected to help pay for food, decorations and liquor.
<!-- /hb-zoom -->
<!-- hb-time:end id="1700-1750" -->

<!-- hb-time:start id="1750-1800" order="05" chapter="storytelling-evolution" label="1750 to 1800" state="full" progress="written" -->
## 1750 to 1800

<!-- hb-zoom level="era" -->
A family company of actors from London landed in Virginia in 1752 and toured the colonies. One reference work describes their *Merchant of Venice* in Williamsburg that year as the beginning of truly professional theatre in America. Between 1750 and 1761, lawmakers in Massachusetts, Pennsylvania and Rhode Island passed laws against plays. In 1774, as the fight with Britain grew, the delegates to the First Continental Congress promised to discourage plays. Shortly before the war, the leading company of actors left for the West Indies. During the war, British soldiers acted a play in Boston, and American officers acted a play at Valley Forge. After the war the actors came back. The first plays by American writers that professional actors performed reached the stage in these years, and one of them brought a new character to it, the plain-spoken Yankee.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Laws against plays" -->
In 1750 members of the Massachusetts General Court, the colony's lawmakers, passed "An Act for preventing Stage-Plays, and other Theatrical Entertainments." The act stated that plays "tend to increase immorality, impiety, and a contempt of religion." Impiety means a lack of respect for God. The act set fines for anyone who put on a play or took part in one.

On May 31, 1759, members of the Pennsylvania House of Representatives voted through a law against acting plays, with a fine of five hundred pounds. Two years later the lawmakers of Rhode Island passed "an act to Prevent Stage Plays and other Theatrical Entertainments." In 1762 members of the New Hampshire House of Representatives refused to let a company of actors into the town of Portsmouth. They said that plays had a "peculiar influence on the minds of young people and greatly endanger their morals." Peculiar here means special, and morals are a person's ideas of right and wrong.

On May 5, 1766, New Yorkers learned that members of the British Parliament had voted to end the Stamp Act. The Stamp Act was a British tax that many colonists had protested. A crowd tore down the theatre in Chapel Street, where a comedy called *The Twin Rivals* was advertised for that night. David Malinsky, writing in the *Journal of the American Revolution* in 2013, says that the New York Sons of Liberty did it. The Sons of Liberty were secret groups of colonists, sometimes violent, who fought the Stamp Act. Malinsky writes that the crowd severely beat an actor who was dressed as a woman and killed a small child. The older accounts record only that the theatre was destroyed. No record names the child, the actor, or who led the crowd.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="1752: the first touring company" -->
In 1752 the London actor Lewis Hallam led a company of actors to Virginia. It included members of his family, among them his son Lewis, about twelve years old. It opened in Williamsburg with Shakespeare's *The Merchant of Venice* on September 15, 1752. William Dunlap, an early historian of the American stage, gave the date as September 5. The company acted tragedies by Shakespeare and Joseph Addison, and comedies by William Congreve and Richard Steele. *Hamlet*, *Othello* and *Richard III* were among its plays.

The company played Williamsburg, Annapolis, Philadelphia and New York. Hallam had trouble getting permission to act in New York and Philadelphia, and he did not even try in Boston. In New York, Hallam built a theatre on Nassau Street in 1754.

Lewis Hallam then died in Jamaica, where the company had gone to perform. His widow, Sarah Hallam, married the actor and manager David Douglass. In 1758 they formed the American Company. Douglass built a theatre in Philadelphia in 1759. In Annapolis he opened a brick theatre on March 3, 1760, that held five to six hundred people.

Charles Daly, writing in 1896, says Douglass also built a theatre in Chapel Street, New York, in 1761. Gabriel Furman's notes name another man, Phil Miller, as its builder.
<!-- /hb-zoom -->

<!-- hb-story:start slug="lewis-hallam-younger" name="Lewis Hallam the Younger" movie="" kind="famous" status="verified" -->
### Lewis Hallam the Younger

> **Who:** A boy in the first touring company of actors in the colonies, who grew up to be the leading actor and manager of the American Company.
> **When and where:** Born about 1740 in England. Came to Virginia in 1752. Died in Philadelphia on November 1, 1808.

Lewis Hallam the Younger spent about fifty years on the stage in America. He was about twelve years old when his father's company landed in Virginia in 1752. The historian William Dunlap got that story from Hallam himself.

In 1758, at eighteen, Hallam became the leading man of the American Company, which his mother and stepfather ran. He acted in *The Prince of Parthia* in 1767, the first play by an American writer that professional actors staged. He also acted in *The Contrast* in 1787.

His mother died in 1774, and his stepfather retired to Jamaica. Hallam then took over the family company. Shortly before the Revolution, he moved to the West Indies. He brought the company back in 1784 or 1785, depending on the account, and managed it until 1796. He kept acting until shortly before he died. *Encyclopaedia Britannica* describes him as "known as a quarrelsome and financially inept manager," which means he argued with people and handled money badly.
<!-- hb-story:end slug="lewis-hallam-younger" -->

<!-- hb-story:start slug="nancy-hallam" name="Nancy Hallam" movie="" kind="ordinary" status="verified" -->
### Nancy Hallam

> **Who:** An actress and singer in the American Company, and the subject of an early painting of an actress in a role in America.
> **When and where:** Annapolis, Maryland, 1770 and 1771.

Nancy Hallam was an actress whom the painter Charles Willson Peale painted in the costume of one of her roles. She was the niece of Sarah Hallam Douglass. She trained as a singer in England from 1760 to 1765, and she was acting with the American Company by 1766. In 1769 she moved from the parts of young women to leading roles.

In 1770 in Annapolis, she played Imogen in Shakespeare's *Cymbeline*. Imogen is a princess who disguises herself as a young man named Fidele. On September 6, 1770, the *Maryland Gazette* printed a letter signed only with the initials "Y.Z." It praised her "Delicacy of Manner" and "the Musick of her Tongue."

Peale painted her dressed as Fidele, and the painting was on view by September 1771. Colonial Williamsburg owns it today. Nancy Hallam went back to Britain in 1773. What happened to her after that, and when she died, is not known.
<!-- hb-story:end slug="nancy-hallam" -->

<!-- hb-zoom level="span" label="The first American plays" -->
Thomas Godfrey wrote a tragedy called *The Prince of Parthia*. The American Company acted it at the Southwark Theatre in Philadelphia on April 24, 1767. It was the first play by an American writer that professional actors performed. Godfrey had died of a disease called yellow fever in 1763, so he never saw it on the stage.

Mercy Otis Warren of Massachusetts wrote plays in which she attacked the policies of the colony's British governor. They were printed without her name. The first appeared in a newspaper, the *Massachusetts Spy*. At the time, Massachusetts law banned acting plays.

Royall Tyler wrote a comedy called *The Contrast*. It opened at the John Street Theatre in New York in 1787. It was the first comedy by an American that professional actors performed. Tyler wrote it after he met Thomas Wignell, the American Company's leading comic actor. Its leading character, Jonathan, has rough, plain-spoken manners. He is a Yankee, a word that can mean a person from New England. Playwrights after Tyler kept writing Yankee characters like him. *Encyclopaedia Britannica* describes Jonathan as "the predecessor of many such in years to follow," meaning the first of many characters like him.
<!-- /hb-zoom -->

<!-- hb-story:start slug="mercy-otis-warren" name="Mercy Otis Warren" movie="" kind="famous" status="verified" -->
### Mercy Otis Warren

> **Who:** A Massachusetts writer who used plays to attack the royal government at a time when Massachusetts law banned acting them.
> **When and where:** Born in Barnstable, Massachusetts, on September 14, 1728. Wrote plays from 1772 to 1779. Died in 1814.

Mercy Otis Warren wrote five plays against the royal government in Massachusetts and signed none of them. Her first, *The Adulateur*, came out in 1772 in the *Massachusetts Spy* newspaper. In it she attacked the policies of the British governor of Massachusetts. *The Defeat* followed in 1773, *The Group* in 1775, *The Blockheads* in 1776 and *The Motley Assembly* in 1779.

The National Women's History Museum's biography of her states that she likely left her name off the plays to avoid being punished, and also so that readers would take her work seriously even though a woman wrote it. In 1805 she published a history of the American Revolution in three volumes.
<!-- hb-story:end slug="mercy-otis-warren" -->

<!-- hb-zoom level="span" label="Congress against plays, and armies acting them" -->
The First Continental Congress was a meeting of delegates, men chosen by each colony to speak for it. On October 20, 1774, they signed an agreement called the Continental Association. In its eighth article they promised to "discourage every species of extravagance and dissipation." Extravagance means spending too much, and dissipation means wasting time and money on pleasure. The list that followed named horse racing, cockfighting, "shews, plays, and other expensive diversions and entertainments." Shortly before the war, the American Company left for the West Indies.

British soldiers acted a play in Boston while American troops surrounded the city. On December 2, 1775, they staged *Zara*, a tragedy by the British writer Aaron Hill, in Faneuil Hall. The poster states that it was put on "by a Society of Ladies and Gentlemen." General John Burgoyne wrote a prologue for it, a speech given before the play begins. Francis Rawdon-Hastings, a British officer, is said to have read it. The money from tickets went to the widows and children of soldiers.

American officers at Valley Forge acted Joseph Addison's *Cato* in the spring of 1778. Lieutenant Colonel William Bradford Jr. wrote in a letter that "Cato was performed before a very numerous & splendid audience." He wrote that "His Excellency and Lady" were there, and that the performance was "admirable." His letter uses only that title and gives no names. Accounts date the performance May 4 or May 11, 1778. The audience was officers and their guests. Shawn David McGhee, writing in the *Journal of the American Revolution* in 2024, argues that it may have been a reading of the play rather than a full staging.

In October 1778 the delegates to Congress asked the states to stop "theatrical entertainments." On October 16 the delegates voted that any official who would "act, promote, encourage or attend such plays, shall be deemed unworthy to hold such office."
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="After the war" -->
Lewis Hallam the Younger brought the American Company back from the West Indies in 1784 or 1785 and started it up again.

The Massachusetts law of 1750 still banned plays. In 1791 a group of men who wanted a theatre in Boston tried and failed to get it repealed, which means ended by a vote. In 1792 they opened the "New Exhibition Room" on Board Alley anyway. They sometimes advertised its plays as "moral lectures," talks meant to teach right from wrong. Governor John Hancock forced it to close in June 1793.
<!-- /hb-zoom -->
<!-- hb-time:end id="1750-1800" -->
