<!-- hb-chapter id="35" slug="styles" title="Styles" part="9" mode="prose" file="part3" -->

# Chapter 35: Styles



<!-- hb-time:start id="1900-1950" order="08" chapter="styles" label="1900 to 1950" state="full" progress="written" -->
## 1900 to 1950

<!-- hb-zoom level="era" -->
New man-made materials went into the things Americans wore and handled every day in the first half of the 1900s. Leo Baekeland made Bakelite, a hard plastic, in 1907. Chemists at the DuPont company made nylon in 1935, and it went on sale as women's stockings in 1939. In the 1920s many women cut their hair short and wore shorter, looser dresses. Black women built companies that sold hair products to Black customers, and Madam C. J. Walker and Annie Malone each grew rich from that work.

Government officials also used clothes and hair to control people. In 1902 the U.S. commissioner of Indian affairs, the head of the federal office for Native affairs, told reservation officials to make Native men cut their hair. Reservations were lands the government had set aside for Native nations. In 1942 officials in Washington limited how much cloth a dress or a suit could use. In June 1943, servicemen in Los Angeles beat Mexican American young men and tore off their zoot suits, outfits with very wide pants and long coats. Police officers then arrested many of the bloodied young men.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The order to cut Native men's hair, 1902" -->
William A. Jones was the U.S. commissioner of Indian affairs, the head of the federal office for Native affairs. On January 11, 1902, he sent a letter to the superintendents, the officials who ran the federal reservations and the offices on them. In it he told them to make Native men cut their hair and wrote: "The wearing of long hair by the male population of your agency is not in keeping with the advancement they are making, or will soon be expected to make, in civilization." He called short hair "a great step in advance."

Jones wrote that "Indian costume and blanket" should be discouraged, and that "Indian dances and so-called Indian feasts should be prohibited." He claimed that the paint Native people wore caused "the majority of blindness among the Indians of the United States." He told the superintendents they could force men to obey by holding back their rations and their jobs. Rations were the food and supplies that officials handed out on reservations. Each superintendent had to report his progress by June 30, 1902.

Charles Burton was the superintendent for the Hopi and the Navajo. The historian Tisa Wenger writes that he reportedly used "whips, guns, and sheep shears" to enforce the order. The surviving accounts do not say how many men were forced to cut their hair.

The letter drew an outcry, and writers at *Harper's Weekly* criticized it in February 1902. Jones backed down. Officials then received new instructions to use "persuasion and example, rather than force."
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Shirtwaists, short hair and short skirts" -->
The shirtwaist, the blouse cut like a man's shirt, stayed the everyday top for working women in the early 1900s. Young immigrant women sewed shirtwaists in New York factories. The Triangle Waist Company made them on the top floors of a building in New York. On March 25, 1911, a fire there killed 146 workers. Most of them were young immigrant women, and some were only 14. A stairwell door on the ninth floor was locked, and dozens of workers jumped from the windows. The owners, Max Blanck and Isaac Harris, were tried for manslaughter, a killing the law treats as less serious than murder. The jury found them not guilty on December 27, 1911, because the prosecutors could not prove that the owners knew the doors were locked.

In the 1920s many women cut their hair into a short style called a bob. Dresses hung straight from the shoulders, with the waistline low on the hips. This slim, straight shape is often called the flapper look. Hemlines, the bottom edges of skirts, rose until 1926 and then began to fall.

Many women gave up stiff, formal layers for lighter, looser clothes. With new fabrics such as jersey, a soft knitted cloth, and "artificial silk," a man-made cloth that looked like silk, more women could dress in the new styles. Fashion historians at the Fashion Institute of Technology call this change a "democratization of fashion," which means that fashion spread to ordinary people.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Hair care built by Black women" -->
Annie Turnbo was born on August 9, 1877, in Metropolis, Illinois. Her parents had been enslaved in Kentucky. She made a hair product she called Wonderful Hair Grower and sold it door to door. In 1902 she moved to St. Louis and opened a shop. She later named her company Poro.

In 1918 she opened Poro College in St. Louis. It was a building that held a factory, a store, rooms where students slept, a gym, a chapel and an auditorium. Nearly 200 people worked there. About 75,000 women, in several parts of the world, trained in her Poro system. She later became known as Annie Malone. In 1924 she paid nearly $40,000 in taxes.
<!-- /hb-zoom -->

<!-- hb-story:start slug="madam-cj-walker" name="Madam C. J. Walker" movie="Two Dollars and a Dream (1987)" kind="famous" status="verified" -->
### Madam C. J. Walker

> **Who:** A Black businesswoman, born to parents who had been enslaved, who built a hair-care company and trained thousands of women to sell her products.
> **When and where:** St. Louis, Denver and Indianapolis, 1889 to 1919.
> **Movie:** *Two Dollars and a Dream* (1987), a documentary about her life by Stanley Nelson.

Madam C. J. Walker built a company that made hair products for Black women. She trained thousands of women to sell them. She was born Sarah Breedlove on December 23, 1867, in Delta, Louisiana. Her parents had been enslaved.

Her parents died when she was 7, and she married at 14. In 1889 she moved to St. Louis, where she washed clothes for pay and worked as a cook. Her hair began to fall out. A skin disease, harsh hair products, poor food and a home without running water all played a part. In 1904 she began using Annie Turnbo's hair product, and she became one of Turnbo's sales agents in St. Louis.

In July 1905 she moved to Denver and began selling her own product, "Madam Walker's Wonderful Hair Grower." She married Charles Joseph Walker in 1906 and took his name. In 1910 she moved her company to Indianapolis and built a factory there.

By 1917, according to her company, nearly 20,000 women had trained with it. According to the National Women's History Museum, she employed 40,000 people. She gave money to the YWCA, the Young Women's Christian Association. She also gave $5,000 to the NAACP, the National Association for the Advancement of Colored People, for its work against lynching, the killing of a person by a mob without a trial.

She died on May 25, 1919. Accounts of her wealth differ. One account puts it between half a million and a million dollars. According to the National Women's History Museum, it was more than $1 million.
<!-- hb-story:end slug="madam-cj-walker" -->

<!-- hb-zoom level="span" label="Plastics and nylon" -->
In 1907 the chemist Leo Baekeland made Bakelite. He heated two chemicals, phenol and formaldehyde, under pressure. Bakelite was the first plastic made entirely from chemicals, rather than from plants or animals. He got a patent for his method on December 7, 1909. A patent is a government paper that gives an inventor the right to be the only one to make an invention for a set number of years. Makers used Bakelite for jewelry, telephones, radios and billiard balls, and in cars.

Nylon went on sale as women's stockings. On October 24, 1939, the DuPont company sold its first 4,000 pairs to the wives of its employees in Wilmington, Delaware. They sold out in three hours. On May 16, 1940, called Nylon Day, four million pairs went on sale in stores across the country at about $1.15 a pair. They sold out in two days. Some sources give the date as May 15.

Japanese forces attacked Pearl Harbor, in Hawaii, on December 7, 1941. For the rest of World War II, DuPont's nylon went into parachutes, tire cords, ropes and other war goods instead of stockings. Stockings came back in 1945. In Pittsburgh, 40,000 people stood in a line more than a mile long for 13,000 pairs.
<!-- /hb-zoom -->

<!-- hb-story:start slug="wallace-carothers" name="Wallace Carothers" movie="" kind="famous" status="verified" -->
### Wallace Carothers

> **Who:** The chemist who led the DuPont laboratory where nylon was made.
> **When and where:** DuPont's research station, called the Experimental Station, 1928 to 1937.

Wallace Carothers led the team at DuPont that made two of the most widely used man-made materials of the 1900s, neoprene and nylon. In April 1930 his team made neoprene, a man-made rubber. On February 28, 1935, Gerard Berchet, a chemist working under Carothers, made half an ounce of the nylon later used in stockings.

Carothers was born on April 27, 1896, in Burlington, Iowa. He started work at DuPont's Experimental Station on February 6, 1928.

Carothers had depression. Depression is an illness that brings long periods of deep sadness and makes it hard to think and to work. He wrote: "I suffer from neurotic spells of diminished capacity." He meant that at times his mind could not work as well as usual. In the summer of 1936 he was treated in a psychiatric hospital, a hospital for illnesses of the mind. His sister Isobel died in January 1937.

On April 29, 1937, at age 41, Carothers killed himself in Philadelphia by taking cyanide, a poison. His daughter, Jane, was born in November 1937, seven months after his death. DuPont officials announced nylon to the public on October 27, 1938.
<!-- hb-story:end slug="wallace-carothers" -->

<!-- hb-story:start slug="ann-lowe" name="Ann Lowe" movie="" kind="ordinary" status="verified" -->
### Ann Lowe

> **Who:** A Black dressmaker from Alabama who made gowns for rich families in Tampa and New York, while the wider public hardly knew her name.
> **When and where:** Alabama, New York and Tampa, 1898 to 1950.

Ann Lowe made gowns for Jacqueline Kennedy, the actress Olivia de Havilland and the heiress Marjorie Merriweather Post, but she stayed almost unknown to the wider public. She was born about 1898 in Clayton, Alabama, into a family of Black dressmakers. Her great-grandmother was an enslaved woman, and her great-grandfather was a plantation owner.

Her mother, Jane, and her grandmother, Georgia, made dresses for well-known families in Montgomery, and Ann learned the trade from them. Her mother died in 1914, when Ann was 16, and Ann took over the business.

In 1917 she went to the S. T. Taylor Design School in New York. She was taught in a classroom by herself, apart from the white students. The accounts of her life do not name who ordered it. She was ready to graduate after six months. She then made gowns in Tampa, Florida, and opened her own dress shop there in 1920.

In 1928 she moved to New York with $20,000. For years she made gowns to order for stores such as Henri Bendel, Neiman Marcus and Saks Fifth Avenue. The actress Olivia de Havilland wore a gown Lowe made when she accepted her Academy Award in 1946. The credit for that dress went to the name "Sonia Rosenberg," not to Lowe. The record does not say who gave that credit.

In 2023 the Winterthur Museum showed 40 of her gowns. The museum's description of the show describes her work as part of "a legacy of Black women's knowledge and skills that began as enslaved labor."
<!-- hb-story:end slug="ann-lowe" -->

<!-- hb-zoom level="span" label="Cloth rules in World War II, 1942 to 1946" -->
On April 8, 1942, officials of the War Production Board issued General Limitation Order L-85. The War Production Board was the federal agency whose officials controlled materials during the war. Its chairman was Donald M. Nelson. The order set how long and how wide women's coats, dresses, suits and skirts could be.

The order banned hoods, capes and scarves attached to coats, and belts and hems more than 2 inches wide. A hem is the folded-up bottom edge of a piece of clothing. It also banned cuffs, turned-back bands of cloth, on long jacket sleeves and on slacks, which are loose pants. It banned pleats, tucks or gathers, which are folds or bunches of extra cloth, all over a garment. Wedding gowns, dresses for pregnant women, children's clothes, burial gowns and religious robes did not fall under the rules. The rules lasted until 1946.

On December 27, 1941, Stanley Marcus, a co-owner of the Neiman-Marcus department stores, was asked to head the board's section for women's and children's clothing. Makers and stores that broke the rules could be fined or jailed. In April 1942 the board's officials also limited the elastic used in bras and in girdles, tight underwear that shaped the waist and hips. Nylon and rubber went to the military.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The zoot suit attacks in Los Angeles, June 1943" -->
A zoot suit had high-waisted, very wide pants that narrowed at the ankle and a long coat with wide lapels, the folded-back flaps at the front of a coat below the collar. It began among Black men in Harlem, in New York. In Los Angeles in the early 1940s young Mexican American men wore it. So did some Filipino American and Japanese American young men, and some Mexican American young women. The War Production Board's officials had stopped the making of zoot suits because they used so much cloth.

From June 3 to June 8, 1943, sailors, soldiers and Marines, joined by civilians, went through the Mexican American neighborhoods of Los Angeles. They hunted young men in zoot suits, beat them, tore off their clothes and burned the suits in street fires. The National WWII Museum says the attacks began on June 3 with about 50 sailors. Another account says about 11 sailors started them, and about 200 joined the next day. By the later days, thousands of servicemen had joined.

More than 150 people were injured. Los Angeles police officers stood by while the attackers claimed they were defending themselves. The officers arrested bloodied and bruised Mexican American men for "disturbing the peace." They arrested nearly 600 Mexican Americans, by the National WWII Museum's count, or more than 500 by another count. The police arrested far fewer servicemen, and no soldiers were arrested for the beatings.

On June 8, 1943, Navy and Marine Corps commanders ordered their men to stay out of Los Angeles, and the attacks stopped. Members of the Los Angeles City Council voted for a resolution, a statement of what they wanted, to make wearing a zoot suit in the city a crime. No such law was ever passed.

Governor Earl Warren of California chose a committee to study the attacks. Its members reported that most of the people attacked were Mexican Americans or Black people. On the cause of the attacks, they wrote that "the existence of race prejudice cannot be ignored." Race prejudice means hating or looking down on people because of their race.
<!-- /hb-zoom -->
<!-- hb-time:end id="1900-1950" -->

<!-- hb-time:start id="1950-2000" order="09" chapter="styles" label="1950 to 2000" state="full" progress="written" -->
## 1950 to 2000

<!-- hb-zoom level="era" -->
After the mid-1950s, the people who designed American clothes began to take their ideas from teenagers, and plastics went into everyday clothes and furniture. In the 1950s young men copied the jeans, white T-shirts and leather jackets that film stars wore. The first suits made partly of polyester, a plastic made into thread, went on sale in 1951. From 1950 the furniture company Herman Miller sold chairs that the designers Charles and Ray Eames had shaped from plastic and glass fiber.

People also went to court over clothes and hair. In 1969 seven of the nine justices, the judges of the Supreme Court, the highest court in the country, ruled that students could wear black armbands to school to protest a war. Judges disagreed about boys' long hair, and in 1981 a federal judge allowed an airline to ban a Black woman's braids. In 1995 state and federal officers found 72 Thai workers held behind razor wire in El Monte, California, sewing clothes that were sold in American chain stores.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Jeans, T-shirts and teenagers in the 1950s" -->
In the early 1950s the leading women's style was still the "New Look" that Christian Dior showed in 1947. It had a tight waist and a full skirt. By the middle of the decade, dressmakers cut dresses straighter and slimmer, and designers began to take ideas from teenagers.

Young men took up a working-class look: jeans, a white T-shirt and a leather jacket, with the hair greased back. Marlon Brando wore it in the film *The Wild One* in 1953, and James Dean wore it in *Rebel Without a Cause* in 1955. Fashion historians at the Fashion Institute of Technology describe the look as young people turning away from their parents' generation. Young men who wore it got a reputation as rebels and troublemakers. By the end of the decade, boys wore jeans to most places.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Polyester and wash-and-wear" -->
Two British chemists, John Rex Whinfield and James Tennant Dickson, patented polyester in 1941. In 1946 the DuPont company bought the right to make it in the United States, and DuPont named its polyester fiber Dacron.

On May 8, 1951, Hart, Schaffner & Marx of New York began selling men's suits made of cloth that was 55 percent Dacron and 45 percent wool. According to the Hagley Museum and Library, it was the first polyester fiber sold to the public anywhere in the world. The makers of the cloth liked it because it did not crease or wear through easily and was easy to clean. In 1953 DuPont opened a Dacron plant in Kinston, North Carolina.

Clothes made with Dacron could be washed and worn without ironing, so they were sold as "wash and wear." Most of the ironing time they saved was women's time.

In the 1970s, with man-made cloth, people could buy fashionable styles at any price. Polyester and other man-made fabrics were so common that people called the decade the "Polyester Decade." Men wore leisure suits, a casual kind of suit often made of man-made cloth, as a cheap stand-in for a regular suit. People dancing at disco clubs wore satin, sequins (tiny shiny disks sewn onto cloth) and Lycra, a stretchy man-made cloth. By the late 1970s people wore sweatshirt cloth and leggings, once clothes for the gym, every day.
<!-- /hb-zoom -->

<!-- hb-story:start slug="charles-ray-eames" name="Charles and Ray Eames" movie="Eames: The Architect and the Painter (2011)" kind="famous" status="verified" -->
### Charles and Ray Eames

> **Who:** A husband and wife who designed furniture of molded plywood and plastic, meant to be sold cheaply to families in small homes after World War II.
> **When and where:** Los Angeles, 1941 to 1978.
> **Movie:** *Eames: The Architect and the Painter* (2011), a documentary about them in the PBS series American Masters.

Charles and Ray Eames designed chairs that could be made from a few parts, so that good chairs could be sold at low prices. From 1950 the furniture company Herman Miller sold their chairs with seats molded in one piece from fiberglass. Fiberglass is plastic that hardens around threads of glass. The Eameses described their aim as "getting the most of the best to the greatest number of people for the least."

Charles Eames was born on June 17, 1907, in St. Louis, Missouri, and studied architecture. Ray Kaiser was born on December 15, 1912, in Sacramento, California, and trained as a painter. They married in June 1941 and moved to Los Angeles.

During World War II they made leg splints of molded plywood for wounded servicemen, with money from the Navy. Plywood is made of thin sheets of wood glued together. A splint holds a broken bone still. In 1945 and 1946 they used the same method to make plywood chairs.

In 1948 the Museum of Modern Art in New York held a contest for low-cost furniture for the small homes being built after the war. The Eameses entered a chair seat made in one piece of stamped steel, and they won second place. Managers at Herman Miller would not pay $80,000 for a machine to press the steel. So the Eameses used fiberglass instead. The military had used it in the war.

Workers at Zenith Plastics of Los Angeles shaped the seats in metal molds on hydraulic presses, machines that press with the force of liquid under pressure. The first colors were greige, a gray-beige, elephant-hide gray and parchment. Buyers could put the same seat on metal legs, wooden legs or rockers.

In 1956 the Eameses designed a costly lounge chair of leather and molded rosewood plywood. Ray called it "comfortable and un-designy." Its first label said "designed by Charles Eames." While she was alive, Ray got less credit than writers, museums and filmmakers have given her since her death.

Charles died on August 21, 1978. Ray died on August 21, 1988, ten years later to the day.
<!-- hb-story:end slug="charles-ray-eames" -->

<!-- hb-zoom level="span" label="Ann Lowe's wedding gown, 1953" -->
In 1953 Janet Auchincloss hired Ann Lowe, the Black dressmaker in New York, to make the wedding dress for her daughter, Jacqueline Bouvier. Lowe also made the bridesmaids' dresses. Jacqueline Bouvier married Senator John F. Kennedy that September. The wedding dress used 50 yards of ivory silk taffeta, a smooth, crisp silk cloth, and cost $500.

Ten days before the wedding, water flooded Lowe's workroom. She and her workers made the ruined dresses again. Lowe paid the extra cost herself and did not tell the family. She got no public credit for the dress until after Lee Harvey Oswald shot and killed President Kennedy in Dallas on November 22, 1963.

Her rich customers often talked her out of charging hundreds of dollars for her gowns. After she paid her workers, she often lost money, and at the height of her career she was almost broke. In 1962 she lost her New York shop because she had not paid her taxes. The same year doctors removed her right eye because of glaucoma, a disease in which pressure inside the eye destroys the nerve that carries sight. She declared bankruptcy in 1963. Bankruptcy is a step in court for a person who cannot pay what he or she owes. In 1968 she opened a new shop on Madison Avenue, and she retired in 1972. She died on February 25, 1981.
<!-- /hb-zoom -->

<!-- hb-story:start slug="mary-beth-tinker" name="Mary Beth Tinker" movie="" kind="famous" status="verified" -->
### Mary Beth Tinker

> **Who:** A 13-year-old junior high student who wore a black armband to school to protest the Vietnam War. She was suspended, and her case led to a Supreme Court ruling on students' rights.
> **When and where:** Des Moines, Iowa, December 1965 to February 1969.

On December 16, 1965, Mary Beth Tinker, 13, wore a black armband to Warren Harding Junior High School in Des Moines, Iowa. She wore it to protest the Vietnam War. School officials sent her home and suspended her.

That December a group of adults and students had met at the home of Christopher Eckhardt's family in Des Moines. They decided to wear black armbands through the holidays to object to the war and to call for a truce, an agreement to stop fighting. On December 14 the principals of the Des Moines schools agreed that any student who wore an armband would be told to take it off. A student who refused would be suspended.

Christopher Eckhardt, 16, wore an armband to his high school on the same day as Mary Beth. Her brother John, 15, wore his the next day. School officials suspended all three. They did not go back to school until after New Year's Day. Her younger brother Paul, 8, and her sister Hope, 11, also wore armbands, but the rule did not cover elementary schools.

The three students' fathers sued the school district for them, with help from the Iowa Civil Liberties Union. The Tinker family received hate mail and threats to kill them. No surviving record names who sent them. A federal judge ruled for the school district, and the judges of the appeals court, a higher court that checks the rulings of lower courts, split evenly.

On February 24, 1969, seven of the nine Supreme Court justices ruled for the students. Justice Abe Fortas wrote that students do not "shed their constitutional rights to freedom of speech or expression at the schoolhouse gate." He meant that students keep the right to free speech that the Constitution gives every American. He called the armbands "a silent, passive expression of opinion, unaccompanied by any disorder or disturbance." That means the students stated their opinion quietly and caused no trouble. Justices Hugo Black and John Harlan disagreed.
<!-- hb-story:end slug="mary-beth-tinker" -->

<!-- hb-zoom level="span" label="Long hair and braids at school" -->
In the Tinker case, seven justices protected the armbands as a way of speaking. They did not decide what students could wear or how they could cut their hair. Justice Fortas wrote that the case did not concern "the length of skirts or the type of clothing, to hair style." Boys with long hair lost some court cases and won others.

In September 1966 three Dallas boys tried to enroll at W. W. Samuell High School. They were Phillip Ferrell, Stephen Webb and Paul Jarvis, and they played in a band called Sounds Unlimited. School officials turned them away because of their "Beatle" haircuts. In 1968 the judges of a federal appeals court sided with the school. In 1970 Chesley Karr of El Paso, Texas, challenged his school's rule that a boy's hair could not hang over his ears or his collar. He lost. In 1972, in a case called Arnold v. Carpenter, judges on a different federal appeals court ruled for long-haired students.

The Supreme Court justices never agreed to hear a school hair case. In 1971 Justice Hugo Black wrote that he could not see why "anyone should think the Federal Constitution imposes on the United States courts the burden of supervising the length of hair that public school students should wear." Justice William O. Douglas disagreed when the other justices turned such cases away.

One of those cases came from Pawnee boys in Oklahoma. The Pawnee Nation once lived in Nebraska and northern Kansas. The Sioux attacked the Pawnee there for four decades. In 1874 the Pawnee began a two-year removal to Indian Territory, which later became Oklahoma. A removal means the whole nation had to move away from its homeland. Some accounts say the Pawnee were forced to go. The US government's agent for the Pawnee chose their new reservation, on land that had belonged to the Cherokee. The boys wore their hair parted in the middle with a long braid on each side, to follow "the old traditional ways." One of them said it was "one way of telling people that I am proud [to be an Indian]."

On April 24, 1972, officials at Pawnee Junior High School suspended the boys with no end date, under a rule that a boy's hair could not reach his collar or his ears. The first name on their case is Norman New Rider. Federal appeals judges ruled that the school could keep its rule. On December 10, 1973, the Supreme Court justices refused to hear the case. Justices Douglas and Thurgood Marshall disagreed. Douglas wrote that the boys were telling other students of "their pride in being Indian."
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The Afro, braids and a court ruling" -->
Before the 1960s many Black Americans straightened their hair. The creams they used to straighten it, called relaxers, often held lye, a chemical that could burn the scalp and the ears. In the 1960s many Black men and women in the "Black is beautiful" movement began wearing their hair natural. The Afro, hair combed out into a round shape, became a sign of Black pride. Angela Davis wore one in 1969. A person could keep up an Afro at home without paying a hairdresser.

Renee Rogers was an airport operations agent for American Airlines. The airline's managers had a rule against an all-braided hairstyle for workers in her job. They told her to wear a hairpiece over her braids at work. She sued. On December 1, 1981, federal Judge Abraham Sofaer ruled for the airline.

Judge Sofaer ruled that a person can change a hairstyle but cannot change the texture of his or her hair. So, he ruled, the braid rule was not race or sex discrimination under the Civil Rights Act of 1964. Discrimination means treating people worse because of who they are. The airline's lawyers said the style had been made popular by the actress Bo Derek, in the 1979 film *10*. Rogers said braids had a long history for Black women.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Sneakers and hip-hop in the 1980s" -->
In New York in the 1980s, hip-hop groups such as Run DMC wore white Adidas sneakers, jeans, hooded sweatshirts, gold chains and baseball caps.

Nike began selling its Air Jordan basketball shoe, made for the player Michael Jordan, on April 1, 1985. NBA officials fined Jordan $5,000 a game for wearing shoes in colors that broke the league's rules. Reports of the shoe's sales in its first year range from $126 million to more than $150 million.

On May 2, 1989, James David Martin, 17, killed Michael Eugene Thomas, 15, to take his Air Jordans. Thomas was a ninth grader at Meade Senior High School in Anne Arundel County, Maryland, and he had bought the shoes for $115.50. Martin led him into the woods near the school, raped him and strangled him to death. Rape means forcing a person into a sexual act. Then Martin took the shoes and ran. He pleaded guilty to voluntary manslaughter, killing a person on purpose but without planning it ahead, a crime the law treats as less serious than murder. He was sentenced to seven years in prison.

In May 1990 the writer Rick Telander published a cover story in the magazine *Sports Illustrated*, "Your Sneakers or Your Life," about young people robbed for their sneakers and jackets, some of them killed. Police gave different estimates of how often such robberies happened. Each count covered a single city, such as Atlanta or Chicago. Richard Lapchick of Northeastern University called the reports "grossly exaggerated."
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Slavery in a California sewing shop, 1995" -->
On August 2, 1995, state and federal officers and El Monte police raided a group of seven apartments in El Monte, California, near Los Angeles. Inside they found 72 garment workers, people who sew clothes for a living, from Thailand. They had been held there and forced to sew.

Suni Manasurangkun, whom the workers called "Auntie," ran the shop with her sons. Recruiters in Thailand had promised the workers jobs, given them false passports and brought them to Los Angeles. The bosses took the passports and told each worker that he or she owed about $5,000 for the trip. A high fence topped with razor wire surrounded the apartments, and armed guards watched the workers. The guards showed them a picture of a man who had been beaten after he tried to escape. The records do not name who beat him.

The workers sewed about 84 hours a week, from early morning to midnight, for about $1.60 an hour. Some of them had not been outside the fence for as long as seven years. The officers learned of the shop after a woman escaped through a second-floor window. A letter written in pencil, with a map drawn by hand, reached the authorities. It said: "Very Dangerous. Please bring much manpower."

The clothes carried "Made in the USA" labels and were sold in chain stores including Mervyn's, Montgomery Ward and Miller's Outpost. In February 1996 Suni Manasurangkun, three of her sons and three other people pleaded guilty to federal crimes. They were sentenced to up to seven years in prison. Two of her sons escaped the country and were never caught. The workers sued the stores and clothing companies that had sold the clothes. In 1997 those companies agreed to pay the workers wages they were owed, and the lawsuits ended. The amount was $4 million by one account and more than $4.5 million by another.
<!-- /hb-zoom -->

<!-- hb-story:start slug="rotchana-cheunchujit-sussman" name="Rotchana Cheunchujit" movie="" kind="ordinary" status="verified" -->
### Rotchana Cheunchujit

> **Who:** A garment worker from Thailand who was held in the El Monte sewing shop until officers freed her in 1995.
> **When and where:** El Monte, California, the early 1990s to 1995.

Rotchana Cheunchujit sewed blouses and other clothes in the El Monte shop for five to seven cents a piece. That came to about $300 to $500 a month. The owners took half her pay first. Then they made the workers buy food and supplies from the owners' own store, at high prices. The bosses told her she owed about $5,000.

She came from Thailand, where she had heard that jobs in Los Angeles paid three times as much. She left her two young children with her mother there, hoping the job would help her family. The smugglers who brought her said that for about $4,800 they would get her to the United States and set her up with a job. She could pay them back from her wages. She arrived in 1994.

She was 24 and in bed when federal agents broke down the door in the early hours of August 2, 1995. Someone called out in Thai: "We're here to help you." "We were in shock," she said. "We didn't know what was going on." Immigration officers then held her and the other workers for nine days, until Asian American groups paid their bail, money paid to a court so that a person can go free while a case goes on.

Later she became a US citizen, learned English and was reunited with her children. She married Steve Sussman, a professor at the University of Southern California, and took his name. She spoke up for other garment workers and opened a vegetarian Thai restaurant in Arcadia, California.
<!-- hb-story:end slug="rotchana-cheunchujit-sussman" -->
<!-- hb-time:end id="1950-2000" -->

<!-- hb-time:start id="2000-today" order="10" chapter="styles" label="2000 to Today" state="full" progress="written" -->
## 2000 to Today

<!-- hb-zoom level="era" -->
Americans threw away 17 million tons of cloth in 2018, most of it clothing, by the count of the US Environmental Protection Agency. That was almost twice the 9.5 million tons they threw away in 2000. Around the world, clothing sales more than doubled between 2000 and 2015, and people wore each piece fewer times, according to a 2017 report by the Ellen MacArthur Foundation.

Almost all the clothes sold in the United States are sewn in other countries. Some are sewn in Bangladesh, where a factory fire in 2012 and a building collapse in 2013 killed more than 1,200 people, most of them garment workers. Some of them had been sewing clothes for American stores. In Los Angeles, garment workers were paid by the piece, often a few cents for each piece they sewed. Starting in 2022, a California law required pay by the hour, at least the minimum wage, the lowest hourly pay the law allows. After that, piece pay was allowed only as a bonus.

California lawmakers passed the first law against punishing workers or students for the natural texture of their hair, or for braids, locs or twists, in 2019. Lawmakers in about 30 states have passed such laws since. Locs are long ropes of hair, also called dreadlocks. Members of the CROWN Coalition, the group that worked for the first of those laws, counted the states.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Where the clothes come from" -->
About 97 percent of the clothes and shoes bought in the United States are made in other countries, most of them in Asia. The American Apparel & Footwear Association, a group of clothing and shoe companies, gave that figure in April 2025, from its latest data.

Workers in Bangladesh are among those who sew clothes for American stores. In the year from 2021 to 2022, the country's garment factories earned $42.6 billion, about 82 percent of the money Bangladesh earned from goods sold to other countries. About 4 million people worked in them. The International Labour Organization studies work and workers around the world. According to its 2023 report, the typical garment worker in Bangladesh was a woman of 23 who had moved to the city from a farming area.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="The Tazreen fire and the Rana Plaza collapse" -->
On November 24, 2012, a fire started in a ground-floor warehouse of the Tazreen Fashions factory, on the edge of Dhaka, Bangladesh. The building had nine floors. All three of its staircases led down through the ground floor, where the fire was. The fire killed at least 112 people, by the first count reported by the Associated Press. Later counts run from 117 to 124. Twelve people died jumping from windows.

Police arrested three supervisors and accused them of padlocking the exits. One survivor, Mohammad Ripu, said a manager told the workers: "The fire alarm had just gone out of order. Go back to work."

Workers at Tazreen had been sewing clothes sold by Walmart and other companies. In May 2011, inspectors checking the factory for Walmart had rated it high-risk. That same year Sridevi Kalavakolanu, Walmart's director of ethical sourcing, said that fire and electrical upgrades in factories were "not financially feasible for the brands." She meant they cost too much. Her job was checking how the companies that made goods for Walmart treated their workers. After the fire, Walmart officials said a supplier, one of the companies that made clothes for Walmart, had sent work to the factory without permission, and they stopped doing business with that supplier.

Rana Plaza was a nine-story building in Savar, near Dhaka, with five garment factories on its upper floors. About 5,000 people worked in them. The building stood on a pond that had been filled in, and it was built in 2006 without proper permits, the government's written permission to build. Its owner, Sohel Rana, had the upper floors added without a permit. They were not built to hold the weight of factory machines and generators.

On April 23, 2013, a Bangladeshi television channel showed cracks in the building. The shops and the bank on the lower floors closed. Sohel Rana told reporters that the building was safe. Factory managers ordered the garment workers back the next morning. Managers at the Ether Tex factory threatened to hold back a month's pay from any worker who stayed away.

The building fell at about 9 in the morning on April 24, 2013. Counts of the dead run from 1,129 to 1,136. The Clean Clothes Campaign, a group that works for garment workers' rights, gives 1,134. Counts of the injured run from 1,524 to nearly 2,600. Some trapped workers could be freed only by amputating an arm or a leg, which means cutting it off.

Researchers for the Clean Clothes Campaign found at least 29 brands with recent orders at the factories in Rana Plaza. They included two American companies, Cato Fashions and The Children's Place. News reports also linked Walmart. Officials of J.C. Penney said that one factory there had made a small amount of clothing for another brand that Penney stores sold.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="After Rana Plaza" -->
After the collapse, officials of more than 200 clothing companies, most of them European, signed a safety agreement that bound them by law. Officials of Walmart and 14 other North American companies did not sign it. In July 2013 leaders of 17 North American store chains, including Walmart, Gap, Target and Macy's, announced a safety plan of their own. It had no promise, binding by law, to pay for repairs to the factories.

Clothing brands paid into a fund for the families of the dead and for injured workers. The fund reached its target only after more than two years, when the last brands, such as Benetton, paid in. By October 2015, more than $34 million had been paid out, according to the International Labour Organization. According to the Clean Clothes Campaign, some of the brands linked to the building never paid.

The husband of a worker who died and a worker who was injured sued J.C. Penney, The Children's Place and Walmart in a Delaware court. On May 4, 2016, the judge threw out the case, ending it without a trial, for two reasons. The law of Bangladesh allowed one year to bring such a case, and that year had passed. The judge also ruled that the companies were not the workers' employers. So under Delaware law the companies were not required to keep those workers safe. No court has found an American company responsible for the deaths at Tazreen or Rana Plaza.

Sohel Rana was arrested near the border with India on April 28 or 29, 2013. He was still held in custody in April 2026. In 2017 a judge sentenced him to three years in prison for hiding his wealth. As of April 2026, judges in his murder trial had heard 145 of the 594 listed witnesses. The trial had not ended, *The Business Standard*, a newspaper in Dhaka, reported.
<!-- /hb-zoom -->

<!-- hb-zoom level="span" label="Paid by the piece in Los Angeles" -->
Clothes are still sewn in Los Angeles, often in small shops that open and close quickly. In 2020 workers there were paid about 5 to 12 cents for each piece they sewed, according to the news site *CalMatters*. They worked about 10 hours a day, five and a half days a week, for about $300 a week in cash. That came to about $5.50 an hour, when the city's minimum wage was $15. That year, at least 375 workers at the Los Angeles Apparel factory caught COVID-19, and four of them died.

On September 27, 2021, Governor Gavin Newsom signed the Garment Worker Protection Act, which State Senator María Elena Durazo wrote. From January 1, 2022, garment shops in California had to pay at least the minimum wage by the hour. They could pay by the piece only as a bonus on top. Workers could also claim unpaid wages from the brands and stores that sold the clothes.

In 2021 Marissa Nuncio, director of the Garment Worker Center in Los Angeles, said that the law applied to more than 45,000 garment workers in California. Most of them were immigrant women. In 2023 Remake, a group that works for garment workers, reported that a year after the law took effect some workers were earning the minimum wage, and others still reported wages they were owed and never paid.
<!-- /hb-zoom -->

<!-- hb-story:start slug="francisco-tzul" name="Francisco Tzul" movie="" kind="ordinary" status="verified" -->
### Francisco Tzul

> **Who:** A garment worker from Guatemala who sewed clothes in Los Angeles for decades, often for a few cents a piece, and told lawmakers about his work.
> **When and where:** Los Angeles and Sacramento, the 1990s to 2021.

Francisco Tzul had sewn clothes in Los Angeles for decades by 2020, for pay as low as a few cents a piece. He came from Guatemala. In 2020 he was 56 and was living in the United States without legal papers. He has told his story in interviews with the news sites *CalMatters* in 2020 and Knock LA in 2021.

In the 1990s he watched Kathie Lee Gifford's television talk show and recognized her name. It was on the labels of clothes he sewed. He was paid a few cents a piece, about a dollar for each finished item. He shared a one-bedroom apartment with three friends.

In 2020 he sewed face masks at the Los Angeles Apparel factory for $15 an hour. He caught COVID-19 there. "My respiratory system was completely blocked and I wasn't able to breathe at all," he said. He spent 10 days in the hospital. When he came out, his roommates told him to leave. Staff at the Garment Worker Center found him a hotel room for two weeks.

In 2021 he went to Sacramento to tell California's lawmakers about his work. He called the day the Garment Worker Protection Act was signed the best day of his life.
<!-- hb-story:end slug="francisco-tzul" -->

<!-- hb-zoom level="span" label="Hair and the CROWN Act" -->
On July 3, 2019, California became the first state with a CROWN Act. The name stands for "Creating a Respectful and Open World for Natural Hair." Under the law, employers and public schools may not treat people worse because of the texture of their hair or because of styles such as braids, locs and twists. Locs are also called dreadlocks. State Senator Holly Mitchell wrote the law with a group of supporters. The group included civil rights organizations and the company Dove.

New Jersey's governor, Phil Murphy, signed a CROWN Act on December 19, 2019. By July 2025, 27 states and Washington, D.C., had such laws, according to a list that GovDocs published. Pennsylvania's governor, Josh Shapiro, signed one on November 25, 2025. In September 2026 the CROWN Coalition, the group that worked for the first law, counted 30 states.

Members of the US House of Representatives passed a national CROWN Act in 2020 and again in 2022. Senators never voted on it. In September 2026 the United States had no national law against hair discrimination.

In 2020 guards at a prison in Louisiana handcuffed Damon Landor to a chair and shaved off his dreadlocks. He had grown them for decades because of a promise he made as part of his Rastafarian religion, and he had three weeks left in his sentence. He showed the guards a court decision, and they threw it in the trash. On June 23, 2026, six of the nine Supreme Court justices ruled that he could not sue the guards for money under a federal law that protects the religious freedom of people in prison.
<!-- /hb-zoom -->

<!-- hb-story:start slug="andrew-johnson-wrestler" name="Andrew Johnson" movie="" kind="ordinary" status="verified" -->
### Andrew Johnson

> **Who:** A high school wrestler in New Jersey whose locs were cut beside the mat so he could compete. His case led to a state law against hair discrimination.
> **When and where:** Buena, New Jersey, December 2018 to December 2019.

On December 19, 2018, the team's athletic trainer cut off Andrew Johnson's locs beside the wrestling mat, while the crowd watched, so that Johnson could wrestle. The referee, Alan Maloney, had told Johnson that his hair broke the rules. Maloney rejected the cover Johnson wore over his locs and gave him 90 seconds to cut his hair or lose the match. Johnson was a junior at Buena Regional High School, and this was a home match.

The trainer who cut his hair was a white staff member. Johnson won the match in overtime. A local sports reporter, Mike Frankel, posted a video of the haircut. NBC News reported that the video had been viewed more than 14.5 million times.

Johnson's family said that Maloney had arrived late. The family said he had missed the weigh-ins, where referees check each wrestler before a match, and had raised no problem with the hair there. In 2016 Maloney had been accused of calling a Black referee an insulting name for Black people at a party. He was suspended for it, and then allowed back after an appeal.

In September 2019 officials of the New Jersey Division on Civil Rights and of the state's school sports association agreed that Maloney would be suspended for two seasons. They also agreed that all wrestling officials in the state would be trained that the rule is about the length of hair, not its style. On December 19, 2019, one year after the match, Governor Phil Murphy signed New Jersey's CROWN Act.
<!-- hb-story:end slug="andrew-johnson-wrestler" -->

<!-- hb-zoom level="span" label="Where old clothes go" -->
In 1960 Americans threw away about 1.8 million tons of cloth. In 2018, the latest year the US Environmental Protection Agency has counted, they threw away 17 million tons. About 13 percent of old clothes and shoes were recycled that year. Another 3.2 million tons of cloth were burned to make power, and 11.3 million tons went to landfills.

The Ellen MacArthur Foundation reported in 2017 that, around the world, one garbage truck's worth of cloth is dumped or burned every second.

In April 2026 ThredUp, a company that sells used clothing online, published a report with the research firm GlobalData. It stated that in 2025, sales of used clothes in the United States grew nearly four times as fast as sales of clothes in general. ThredUp's researchers expect sales of used clothes to reach $78.8 billion a year by 2030. Nearly half of the shoppers they surveyed said they find used items through social media.
<!-- /hb-zoom -->
<!-- hb-time:end id="2000-today" -->
